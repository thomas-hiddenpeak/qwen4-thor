from pathlib import Path
import copy,json,shutil,subprocess
from tools.native_tts import voice_service_acceptance as d
from tools.serve_recovery import profile_evidence as evidence
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'tts-checkpoint-witness-01'
base=copy.deepcopy(d.read(V/'voice-sdk-tls-02/plan.json')['http'])
base.update(output=str(O/'run'),limits=dict(d.LIMITS,posts=6,seconds=600),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
base['sources']={n:d.sha(R/n) for n in base['sources']}
base['acceptance'].update(scope='same builtin fixed Speech/Chat sentences after checkpoint sampling fix; independent unhinted full ASR; whole bytes for versioned profile witnesses',performance='NOT_CLAIMED',old_greedy_evidence_unchanged=True)
assert d.defaults()==base['defaults']
assert all(d.sha(R/n)==h for n,h in base['production_sources'].items())
assert shutil.disk_usage(R).free>(256<<20)+16*1024*1024
paths=[Path(__file__).resolve(),V/'tts_checkpoint_witness_01.py',R/'tools/serve_recovery/profile_evidence.py']
p=dict(format='q4t-checkpoint-tts-witness-v1',http=base,requests=evidence.tts_requests(),sources={str(x.relative_to(R)):d.sha(x) for x in paths},limitations=['not full voice quality','listening pending','not profile qualification'])
O.mkdir();d.save(O/'plan.json',p)
text='冻结采样后内置音色完整见证：原固定Speech MP3/Chat WAV文本各一次，\n1主模型、6 POST（含两独立无提示ASR和核心前后）、600秒；保留旧\n贪心完整音频和证据，成功后分版本接入主/轻profile，不修改旧验收。\n'
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 冻结checkpoint采样完整音频见证\n\n'+text+'\n为什么：采样修复后的字节身份变化需独立内容证明；下一步：通过后版本化验收器。\n\n')]:
 q=R/n;s=q.read_text();assert m in s;t=q.with_suffix('.edit');t.write_text(s.replace(m,m+c,1));t.replace(q)
print(json.dumps(dict(plan=str(O/'plan.json'),bounds=base['limits'])))

from pathlib import Path
import base64,json
from tools.native_tts.voice_service_acceptance import read,save,sha,defaults,check_wave
from tools.serve_recovery.profile_evidence import TTS_TEXT
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'tts-checkpoint-witness-01';O=V/'tts-checkpoint-content-02'
assert read(P/'run/result.json')['status']=='FAILED' and 'load bound: native_tts_health' in read(P/'run/result.json')['error']
assert read(P/'lease/exit.json')['status']=='COMMAND_FAILED'
assert read(P/'run/chat.http.json')['status']==read(P/'run/chat-ready.http.json')['status']==200
c=read(P/'run/chat-config.wire')['native_tts_health'];assert c['load_attempts']==3 and c['state']=='ready' and c['load_failures']==c['compute_failures']==0
r=read(P/'run/chat.wire');assert r['choices'][0]['finish_reason']=='stop';a=r['choices'][0]['message']['audio'];assert a['transcript']==TTS_TEXT
O.mkdir();wave=base64.b64decode(a['data'],validate=True);check_wave(wave);f=O/'retained-chat.wav';f.write_bytes(wave)
base=read(P/'plan.json')['http'];assert defaults()==base['defaults']
sources={n:sha(R/n) for n in base['sources']}
for f0 in [Path(__file__).resolve(),V/'tts_checkpoint_content_02.py',P/'run/chat.wire',P/'run/result.json',P/'lease/exit.json',P/'run/chat-config.wire']:sources[str(f0.relative_to(R))]=sha(f0)
binaries=dict(decoder=R/'.q4t-work/serve-native-tts-20261118/http-candidate-01/q4t-speech-decode',asr=R/'.q4t-work/serve-audio-native-20261117/validated-binaries/q4t_asr_replay-compute-01')
plan=dict(format='q4t-retained-tts-content-v1',output=str(O/'run'),input=dict(path=str(f),sha256=sha(f)),expected=TTS_TEXT,defaults=defaults(),sources=sources,binaries={k:dict(path=str(v),sha256=sha(v)) for k,v in binaries.items()},limits=dict(main_models=0,asr_loads=1,decoder_runs=1,features_runs=1,http_posts=0,seconds=300,artifact_mib=16,disk_headroom_mib=256),reuse='full actual HTTP Chat audio; original load-count failure preserved; no repeated synthesis')
# Bind the independently verified full ASR asset directory.
for n,row in base['auxiliary_assets']['asr'].items():
 p=Path(base['directories']['asr'])/n;assert sha(p)==row['sha256'];plan['sources'][str(p)]=row['sha256']
save(O/'plan.json',plan)
text='采样见证首轮4 POST/83.326秒，Speech无提示ASR通过，Chat完整200；\n注册驱动复用的TTS两次加载上限未计入ASR后再加载，按3次观察失败，\n原件保留。实际第三次ready且零失败、readiness200、清理通过。冻结\n仅原Chat全音频补识别：0主模型/0HTTP/1ASR/300秒，不重复合成。\n'
for n,m,c0 in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 保留加载预算失败，只补原Chat内容识别\n\n'+text+'\n为什么：错误在复用驱动预算，不能把它掩盖或重复已生成输出。下一步：内容通过后分版本保存见证。\n\n')]:
 p=R/n;s=p.read_text();t=p.with_suffix('.edit');t.write_text(s.replace(m,m+c0,1));t.replace(p)
print(json.dumps(dict(plan=str(O/'plan.json'),limits=plan['limits'])))

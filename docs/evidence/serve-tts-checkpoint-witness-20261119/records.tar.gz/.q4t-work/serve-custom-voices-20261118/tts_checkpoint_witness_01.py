from pathlib import Path
import base64,inspect,json,sys,textwrap
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts import voice_service_acceptance as direct
from tools.serve_recovery import profile_evidence as evidence
read,save,sha,require=direct.read,direct.save,direct.sha,direct.require
LIMITS=dict(direct.LIMITS,posts=6,seconds=600)
direct.LIMITS=LIMITS
# Same verified startup path, with the exact managed profile default token cap.
original=textwrap.dedent(inspect.getsource(direct.Stage.start))
require(original.count("'--max-tokens', '64'")==1,'startup adaptation drift')
namespace=dict(vars(direct));exec(original.replace("'--max-tokens', '64'","'--max-tokens', '256'"),namespace)
class Stage(direct.Stage):
    start=namespace['start']
    def __init__(self,phase):
        self.phase=phase;super().__init__(phase['http'])
        require(phase['requests']==evidence.tts_requests(),'fixed request drift')
        for n,h in phase['sources'].items():require(sha(R/n)==h,'witness source drift')
    def business(self):
        self.core('core-before');rows=self.phase['requests']
        status,raw=self.post('speech','/v1/audio/speech',rows['speech'])
        require(status==200,'checkpoint Speech failed');(self.out/'speech.mp3').write_bytes(raw)
        self.transcribe('speech-asr',raw,evidence.TTS_TEXT)
        status,raw=self.post('chat','/v1/chat/completions',rows['chat'])
        require(status==200,'checkpoint Chat failed');value=json.loads(raw)
        audio=evidence.message(value,'stop')['audio']
        require(audio['transcript']==evidence.TTS_TEXT,'checkpoint Chat text differs')
        encoded=base64.b64decode(audio['data'],validate=True);direct.check_wave(encoded)
        (self.out/'chat.wav').write_bytes(encoded)
        self.transcribe('chat-asr',encoded,evidence.TTS_TEXT)
        self.core('core-after');require(self.counts['posts']==6,'witness checklist incomplete')
        save(self.out/'witness.json',dict(sampling_profile='qwen3-tts-checkpoint-seed0-v1',
            engine=self.plan['binaries']['engine'],requests=rows,whole_audio={
              kind:dict(bytes=p.stat().st_size,sha256=sha(p)) for kind,p in
              [('speech',self.out/'speech.mp3'),('chat',self.out/'chat.wav')]},
            speech_quality=read(self.out/'speech-asr.quality.json'),
            chat_quality=read(self.out/'chat-asr.quality.json'),
            old_greedy_witness_unchanged=True,listening='PENDING',performance='NOT_CLAIMED'))
if __name__=='__main__':
    p=read(Path(sys.argv[1]));Path(p['http']['output']).mkdir(exist_ok=False)
    with direct.lifecycle.child_subreaper():Stage(p).run()

from pathlib import Path
import base64,fcntl,json,shutil,tarfile,hashlib
from tools.native_tts.voice_service_acceptance import read,save,sha,defaults,normalize,lifecycle
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'tts-checkpoint-witness-01';C=V/'tts-checkpoint-content-02';O=R/'docs/evidence/serve-tts-checkpoint-witness-20261119'
first=read(P/'run/result.json');second=read(C/'run/result.json');assert first['status']=='FAILED' and second['status']=='PASS_RETAINED_CHAT_FULL_AUDIO_UNHINTED_ASR'
plan=read(C/'plan.json');assert defaults()==plan['defaults'];assert all(sha(R/n)==h for n,h in plan['sources'].items())
leases={}
for d,status in [(P,'COMMAND_FAILED'),(C,'COMPLETED')]:
 e=read(d/'lease/exit.json');q=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()];assert e['status']==status and all(x['status']=='OK' for x in q) and q[-1]['pids']==[]
 leases[d.name]=dict(status=status,all_nvml_ok=True,nvml_queries=len(q))
cleanup=read(P/'run/cleanup.json');assert not cleanup['remaining'] and cleanup['model_exit']==0 and cleanup['ports_released'] and cleanup['lease_continuously_held']
with lifecycle.guard.common_lock().open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
chat=read(P/'run/chat.wire');a=chat['choices'][0]['message']['audio'];raw=base64.b64decode(a['data'],validate=True);assert sha(Path(plan['input']['path']))==hashlib.sha256(raw).hexdigest()
expected=plan['expected'];speech_quality=read(P/'run/speech-asr.quality.json');assert normalize(speech_quality['response']['text'])==normalize(expected)==normalize(second['quality']['text'])
O.mkdir(exist_ok=False)
witness=dict(format='q4t-fixed-tts-witness-v2',sampling_profile='qwen3-tts-checkpoint-seed0-v1',engine=read(P/'plan.json')['http']['binaries']['engine'],requests=read(P/'plan.json')['requests'],whole_audio=dict(speech=dict(bytes=(P/'run/speech.mp3').stat().st_size,sha256=sha(P/'run/speech.mp3')),chat=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())),speech_quality=speech_quality,chat_quality=second['quality'],chat_finish=chat['choices'][0]['finish_reason'],chat_usage=chat['usage'],health=read(P/'run/chat-config.wire')['native_tts_health'],limits=read(P/'run/chat-config.wire')['native_tts_limits'])
save(O/'witness.json',witness)
summary=dict(status='PASS_FIXED_BUILTIN_FULL_AUDIO_CONTENT_CHECKPOINT_SAMPLING',initial_driver_failure_preserved=True,initial_attempts=first['counts'],initial_seconds=first['seconds'],content_continuation=second,leases=leases,old_greedy_evidence_unchanged=True,profiles_qualified=False,full_voice_quality=False,listening='PENDING',default_replaced=False)
save(O/'result.json',summary)
files=set()
for d in (P,C):
 for f in d.rglob('*'):
  if f.is_file() and f.suffix not in ('.wav','.f32'):files.add(f)
for n in ['tts_checkpoint_witness_01.py','prepare_tts_checkpoint_witness_01.py','tts_checkpoint_content_02.py','prepare_tts_checkpoint_content_02.py','archive_tts_checkpoint_witness_01.py']:files.add(V/n)
assert shutil.disk_usage(R).free>(256<<20)+sum(f.stat().st_size for f in files)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(f.relative_to(R)):dict(bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(files)},whole_chat_wav_embedded_in_original_wire=True,original_audio_and_features_retained=True))
(O/'README.md').write_text('''# checkpoint采样后的内置完整音频见证

复用原固定请求：Speech为ryan、Speak calmly、MP3；Chat为仅音频WAV。
两者文本均为“Hello, this is a native speech test.”，没有改变采样seed
或搜索候选。当前C05完整Speech 58368字节，Chat 111404字节；身份见
witness.json。旧贪心见证及旧发行均保持，不用新输出重签旧证据。

首轮1主模型、4 POST、83.326秒：Speech独立无提示ASR通过，Chat
200完整音频、stop终态。继承的注册驱动只允许TTS两次加载，未计入
Speech→ASR→Chat的第三次加载，在事后观察处失败。原结果FAILED、
原wire与加载限制不改写；实际TTS ready、零失败，核心readiness200。

仅对已生成的完整Chat做补验：0主模型/0HTTP/1ASR、6.338秒，复用
已验证解码和独立ASR，不重复合成。两段均完整识别原词，仅句号与
逗号差异；按事前规范化规则通过。未使用目标文字或语言提示。

两阶段严格租约NVML均正常，末次无GPU进程，原模型正常退出、自有
清理/端口和锁释放确认。此见证证明固定请求的完整内容与字节身份；
主/轻profile、恢复切换和完整音色质量仍须分别验收，正常听感待验。
无性能收益或长稳主张，默认rev316未替换。
''')
print(json.dumps(dict(status=summary['status'],audio=witness['whole_audio'],leases=leases,files=len(files))))

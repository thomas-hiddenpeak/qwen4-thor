from pathlib import Path
import json,os,shutil,subprocess,sys,time,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts import chat_acceptance as chat
from tools.native_tts.voice_service_acceptance import read,save,sha,require,defaults,normalize,lifecycle
V=R/'.q4t-work/serve-custom-voices-20261118';W=R/'.q4t-work/serve-audio-native-20261117'
def run(plan):
 out=Path(plan['output']);out.mkdir(exist_ok=False);started=time.monotonic();result=dict(status='FAILED',steps=[])
 lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);lifecycle.verify_lease(lease,lifecycle.guard.common_lock())
 require(plan['limits']==dict(main_models=0,asr_loads=1,decoder_runs=1,features_runs=1,http_posts=0,seconds=300,artifact_mib=16,disk_headroom_mib=256),'bound drift')
 for n,h in plan['sources'].items():require(sha(R/n)==h,'source drift '+n)
 for row in [plan['input'],*plan['binaries'].values()]:require(sha(Path(row['path']))==row['sha256'],'input drift')
 require(defaults()==plan['defaults'],'default drift')
 def command(name,args,timeout,env=None):
  require(shutil.disk_usage(R).free>=256<<20,'disk headroom')
  require(sum(p.stat().st_size for p in out.rglob('*') if p.is_file())<=16<<20,'artifact limit')
  elapsed=time.monotonic()-started;require(elapsed<260,'deadline')
  with (out/(name+'.log')).open('xb') as log:
   r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=min(timeout,260-elapsed),pass_fds=(lease,))
  result['steps'].append(dict(name=name,args=args,returncode=r.returncode));save(out/'progress.json',result);require(r.returncode==0,name+' failed')
 try:
  save(out/'decode-plan.json',dict(schema='q4t-speech-http-decode-v1',cases=[dict(plan['input'],format='wav')]))
  command('decode',[plan['binaries']['decoder']['path'],'--speech-http-decode',str(out/'decode-plan.json'),str(out/'decoded')],60)
  env=dict(os.environ,PYTHONPATH=str(W/'reference-deps'),PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='',USE_TORCH='0')
  command('features',[str(R/'.q4t-work/refenv/bin/python'),'-B',str(Path(__file__).resolve()),str(Path(sys.argv[1]).absolute()),'features'],60,env)
  command('asr',[plan['binaries']['asr']['path'],str(W/'assets-01'),str(out/'features/plan-0.json'),str(out/'asr')],120)
  d=read(out/'asr/case-0/result.json');raw=(out/'asr/case-0/text.txt').read_text()
  require(d['eos'] and 0<d['generated_tokens']<=64 and '<asr_text>' in raw,'ASR incomplete')
  text=raw.split('<asr_text>',1)[1];save(out/'quality.json',dict(expected=plan['expected'],text=text,response=d))
  require(normalize(text)==normalize(plan['expected']),'independent content differs')
  result.update(status='PASS_RETAINED_CHAT_FULL_AUDIO_UNHINTED_ASR',quality=read(out/'quality.json'),main_models=0,http_posts=0,asr_loads=1)
 except BaseException:result['error']=traceback.format_exc();raise
 finally:
  result.update(seconds=time.monotonic()-started,defaults_unchanged=defaults()==plan['defaults']);save(out/'result.json',result)
if __name__=='__main__':
 p=read(Path(sys.argv[1]))
 if len(sys.argv)>2:
  chat.LIMITS=dict(chat.LIMITS,decode_cases=1,gpu_asr_loads=1);chat.features(Path(p['output']))
 else:
  with lifecycle.child_subreaper():run(p)

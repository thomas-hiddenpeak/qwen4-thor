"""Fixed read-only source retrieval; no model execution or runtime dependency."""
import hashlib,json,pathlib,shutil,time,urllib.request
W=pathlib.Path(__file__).resolve().parent;P=W/'assets-01';P.mkdir(exist_ok=False)
meta=json.loads((W/'metadata-01/model-api.json').read_bytes());rev=meta['sha'];assert rev=='0f99f2d0ebe89ac095bcc5903c4dd8f72b367286'
plan=dict(model='speechbrain/spkrec-ecapa-voxceleb',revision=rev,files=['embedding_model.ckpt','mean_var_norm_emb.ckpt','example1.wav','example2.flac'],asset_and_conversion_bytes_limit=200000000,seconds_limit=600,free_disk_floor=6*1024**3,gpu_actions=0)
(P/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rows=[];total=0;start=time.monotonic()
try:
 for name in plan['files']:
  spec=next(v for v in meta['siblings'] if v['rfilename']==name);url=f'https://huggingface.co/{plan["model"]}/resolve/{rev}/{name}';dest=P/name
  assert shutil.disk_usage(P).free-spec['size']-84000000>=plan['free_disk_floor']
  with urllib.request.urlopen(url,timeout=30) as source,dest.open('xb') as target:
   while data:=source.read(1024*1024):
    total+=len(data);assert total+84000000<=plan['asset_and_conversion_bytes_limit'] and time.monotonic()-start<600
    assert target.tell()+len(data)<=spec['size'];target.write(data)
  raw=dest.read_bytes();assert len(raw)==spec['size']
  digest=hashlib.sha256(raw).hexdigest()
  if spec.get('lfs'):assert digest==spec['lfs']['sha256']
  else:assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==spec['blobId']
  rows.append(dict(name=name,bytes=len(raw),sha256=digest,url=url))
 (P/'receipt.json').write_text(json.dumps(dict(status='PASS_FIXED_ASSET_FETCH',files=rows,seconds=time.monotonic()-start,bytes=total,free_disk=shutil.disk_usage(P).free,gpu_actions=0),indent=2)+'\n')
 print(json.dumps(dict(status='PASS_FIXED_ASSET_FETCH',bytes=total,seconds=time.monotonic()-start)))
except BaseException as error:
 (P/'failure.json').write_text(json.dumps(dict(status='FAILED',error=repr(error),files=rows,bytes=total,seconds=time.monotonic()-start),indent=2)+'\n');raise

import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-speaker-contract-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu=read(W/'cpu-01/result.json');plan=read(W/'cpu-01/plan.json');fetch=read(W/'assets-01/receipt.json');conversion=read(W/'native-assets-01/conversion.json')
assert cpu['status']=='PASS' and cpu['tests']==8 and cpu['seconds']<180
assert all(sha(R/n)==h for n,h in plan['sources'].items())
assert conversion['model_sha256']==plan['asset_sha256'] and not conversion['cuda_initialized'] and not conversion['tensor_values_changed']
assert fetch['bytes']+conversion['model_bytes']<200000000 and fetch['seconds']+conversion['seconds']<600
assert fetch['free_disk']-conversion['model_bytes']>=6*1024**3
before=read(R/'docs/evidence/serve-audio-auxiliary-delivery-20261118/acceptance.json')['current']
for name,key in [('q4t','engine_binary_sha256'),('q4t.release.json','engine_release_sha256'),('service.release.json','service_release_sha256')]:assert sha(R/'build'/name)==before[key]
files={}
for d in ['cpu-01','build-01','metadata-01']:
 for p in (W/d).rglob('*'):
  if p.is_file():files[str(p.relative_to(W))]=p
for name in ['assets-01/plan.json','assets-01/receipt.json','native-assets-01/conversion.json','native-assets-01/config.json','native-assets-01/config-provenance.json','fetch_assets.py','archive_contract.py']:files[name]=W/name
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
a=dict(status='ACCEPT_NATIVE_SPEAKER_ASSET_CONTRACT',cpu_tests=8,cpu_seconds=cpu['seconds'],gpu_actions=0,source_files=plan['sources'],model_revision='0f99f2d0ebe89ac095bcc5903c4dd8f72b367286',source_revision='c0241278f93ef02cd5191f03caf4e5f8e1292bf6',original_sha256=conversion['source_sha256'],converted_sha256=conversion['model_sha256'],tensor_count=len(conversion['tensors']),tensor_values_changed=False,asset_and_conversion_bytes=fetch['bytes']+conversion['model_bytes'],asset_and_conversion_seconds=fetch['seconds']+conversion['seconds'],default_rev286_unchanged=True,model_execution=False,http_verified=False,published=False,whole_task_complete=False,archive_sha256=sha(O/'records.tar.gz'))
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生说话人后端资产合同

8项针对性CPU通过，{cpu['seconds']:.3f}秒、0GPU。固定官方ECAPA
权重231张量、F32/I64及全部区间核对；错误/重复/越界、取消和失败
owner保持通过。独立构建零警告。原始LFS SHA及转换后每张量原始
字节已校验，没有改dtype或数值，不在服务中读取pickle。

取得与转换共{a['asset_and_conversion_bytes']:,}字节/
{a['asset_and_conversion_seconds']:.3f}秒，满足200MB/600秒和6GiB磁盘
预留。一次原始GitHub元数据TLS超时后改用同提交的GitHub API，
各文件blob/SHA已核对；不是模型/测试失败。来源、作者及Apache-2.0
许可见项目third_party/licenses/speechbrain。

当前仅资产/结构合同通过，尚未执行原生speaker模型或diarized API。
下一步实际80维特征及ECAPA计算、真实聚类/参考/输出/恢复交付；
全部master继续，默认rev286保持，PR45冻结head不含后续实现。
''')
p=R/'docs/STATUS.md';s=p.read_text();needle='[原生说话人分离](SERVE_NATIVE_DIARIZATION_2026-11-18.md)开始DI01：\n固定ECAPA官方资产和原生计算合同，首组8CPU/180秒、0GPU；\n后续真实聚类/已知参考/JSON/SSE、恢复与交付全部保留。PR45已冻结\nf3268465等待最终CI，后续开发留在本地提交，不混入已验发行。';new=f'''[原生说话人资产8项CPU通过](evidence/serve-speaker-contract-20261118/README.md)
（{cpu['seconds']:.3f}秒、0GPU），231张量/实际权重/取消与坏输入合同
已核对，独立构建零警告。继续真实80维特征、ECAPA计算和全部
聚类/参考/API/恢复交付；不是接口可用。默认rev286保持，PR45
冻结f3268465等待最终CI，后续本地提交不混入已验发行。''';assert needle in s;p.write_text(s.replace(needle,new,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();s=s.replace('# 2026-11-18 开发日志\n\n',f'''# 2026-11-18 开发日志

## 说话人原始资产与原生布局合同通过（2026-11-18）

8CPU/{cpu['seconds']:.3f}秒、0GPU，真实231张量和固定模型/特征
元数据核对，坏dtype/重复/越界与取消原子性通过；独立构建零警告。
官方83MB权重按LFS SHA取得，CPU转换逐字节保持原数据，服务无
Torch依赖。原因：说话人功能必须来自真实声音计算与独立数值合同。
下一步80维特征/ECAPA执行、真实聚类/参考/API/恢复和全部master；
默认rev286未变，PR45冻结head独立验收。
[证据](../evidence/serve-speaker-contract-20261118/README.md)。

''',1);p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';v=read(p);t=next(t for t in v['tasks'] if t['id']=='A10');t['native_diarization_20261118'].update(state='asset_contract_cpu_pass_native_execution_pending',evidence='evidence/serve-speaker-contract-20261118/README.md',cpu_tests=8,cpu_seconds=cpu['seconds'],converted_sha256=conversion['model_sha256'],tensor_count=len(conversion['tensors']));p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:a[k] for k in ['status','cpu_tests','cpu_seconds','tensor_count','asset_and_conversion_bytes']}))

import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-speaker-features-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(W/'features-cpu-01/result.json');plan=read(W/'features-cpu-01/plan.json');ref=read(W/'features-reference-02/reference.json');assert v['status']=='PASS' and len(plan['cases'])==8 and not ref['cuda_initialized']
assert all(sha(R/n)==h for n,h in plan['sources'].items())
errors=[float(x) for x in re.findall(r'maximum absolute error ([0-9.eE+-]+)',(W/'features-cpu-01/stdout.txt').read_text())];assert len(errors)==6 and max(errors)<=0.002
files={}
for folder in ['features-cpu-01','features-build-01','features-reference-02']:
 for p in (W/folder).iterdir():
  if p.is_file():files[str(p.relative_to(W))]=p
for name in ['feature_reference-attempt01.py','features-reference-attempt01.json','archive_features.py']:files[name]=W/name
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
a=dict(status='ACCEPT_NATIVE_SPEAKER_FEATURES',cpu_cases=8,reference_cases=6,seconds=v['seconds'],reference_seconds=ref['seconds'],max_absolute_errors=errors,absolute_error_limit=0.002,gpu_actions=0,model_constructions=0,original_reference_setup_failure_preserved=True,reference_adaptations=ref['adaptations'],source_files=plan['sources'],archive_sha256=sha(O/'records.tar.gz'),http_verified=False,published=False,whole_task_complete=False)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生说话人80维特征通过

8CPU/{v['seconds']:.3f}秒、0GPU。6组固定PCM的完整矩阵与固定官方
SpeechBrain图比较，最大绝对误差{max(errors):.9g}，冻结门槛0.002；
采样率/长度/帧预算/非有限/溢出和前中末取消的输出原子性通过。
独立构建零警告。原ASR实现未变，不额外重复完整模型或性能矩阵。

参考从固定原文件AST提取未修改STFT/Filterbank/Fbank等定义，
省略无关导入、CPU float32精度装饰器为空操作；单条无padding的
句均值用等价全时轴mean。首轮因类型注解FilterProperties导入
失败，0例执行；修正为延期类型注解后6例通过，原失败脚本保留，
未改变计算或门槛。未构造speaker模型，未验证说话人接口。

继续原生ECAPA实际计算、真实聚类/已知参考/流式输出与恢复交付，
全部master仍active；默认rev286保持，PR45冻结head不混入此组。
''')
p=R/'docs/STATUS.md';s=p.read_text();old='说话人特征组已固定8CPU/180秒、0GPU：官方完整矩阵差分及预算/\n取消边界，保持独立80维声学合同。随后ECAPA实际计算、真实说话人\n输出/恢复和全部master继续；PR45最终head仍独立检查。';new=f'''[说话人特征8项CPU通过](evidence/serve-speaker-features-20261118/README.md)，
{v['seconds']:.3f}秒、0GPU，六组完整矩阵最大误差{max(errors):.6f}≤0.002；
预算/坏输入/取消通过。原参考类型注解失败保留，修复只涉导入。
继续ECAPA实际计算、真实说话人输出/恢复和全部master；PR45最终
head独立检查，本组尚未执行模型或交付API。''';assert old in s;p.write_text(s.replace(old,new,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();s=s.replace('# 2026-11-18 开发日志\n\n',f'''# 2026-11-18 开发日志

## 说话人特征完整矩阵与边界通过（2026-11-18）

8CPU/{v['seconds']:.3f}秒、0GPU，六组官方完整矩阵最大误差
{max(errors):.6f}≤0.002，坏输入/预算/取消原子性通过。首轮参考因
无关类型注解导入失败，0例执行；延期注解修复后6例通过，原失败
保留，计算/门槛未变。原因：确保独立speaker前处理遵守训练合同。
下一步ECAPA真实计算与说话人业务/恢复，全部master继续。
[证据](../evidence/serve-speaker-features-20261118/README.md)。

''',1);p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p);t=next(t for t in j['tasks'] if t['id']=='A10');t['speaker_features_20261118']=a|dict(evidence='evidence/serve-speaker-features-20261118/README.md');p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:a[k] for k in ['status','cpu_cases','seconds','max_absolute_errors']}))

"""Archive completed native Realtime text/tool STOPPED delivery; preserve original failures."""
from pathlib import Path
import hashlib,json,re,tarfile,os
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-02';FIRST=W/'delivery-01'
O=R/'docs/evidence/serve-realtime-chat-delivery-20261120'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  raw=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(raw);p.chmod(mode)
result=read(D/'result.json');composition=read(W/'publication-composition.json');capacity=read(W/'retired-intents-01/result.json');current=result['publication']['current'];release=read(R/'build/service.release.json')
assert result['status']=='PASS_NATIVE_REALTIME_CHAT_DELIVERED' and result['publication']['revision']==356
assert result['state']=='STOPPED' and result['new_gpu_starts']==0 and len(result['commands'])==20
assert sum(r['returncode']==0 for r in result['commands'])==19 and result['commands'][3]['returncode']==1
assert result['outer']['enabled'] and result['outer']['charged_total']==0
assert current['manifest_sha256']==composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t')==current['engine_binary_sha256'] and sha(R/'build/service.release.json')==current['service_release_sha256']
for n,h in result['preserved'].items():assert sha(R/'build/service-native-state'/n)==h,n
assert capacity['status']=='PASS_REVERSIBLE_INTENT_ARCHIVE' and capacity['deleted_files']==0 and capacity['protected_unchanged']
assert release['native_realtime_conversation_targeted_accepted'] and release['native_semantic_vad_targeted_accepted'] and release['native_reference_icl_targeted_accepted']
assert not release['voice_listening_and_similarity_accepted'] and release['voice_listening_deferred']
files={}
for directory in (FIRST,D,W/'retired-intents-01'):
 for path in directory.iterdir():
  if path.is_file() and not path.is_symlink():files[str(path.relative_to(W))]=path
for path in (W/'retired-intents-01').glob('batch-*/*.json'):files[str(path.relative_to(W))]=path
for name in ('numeric-intermediates-archive-01','cpu-cache-archive-01','host-cache-archive-01','generated-dependencies-archive-01','rebuildable-cache-cleanup-01'):
 directory=W/name
 for path in directory.iterdir():
  if path.is_file() and path.suffix in ('.json','.py'):files[str(path.relative_to(W))]=path
for name in ('archive_delivery_02.py','deliver_realtime_chat_01.py','continue_delivery_02.py','archive_delivery_intents.py','archive_numeric_intermediates.py','publication-composition.json'):
 files[name]=W/name
secrets=[]
def collect(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(item,str) and len(item)>=24:secrets.append(item.encode())
   else:collect(item)
 elif isinstance(value,list):
  for item in value:collect(item)
for path in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(path))
for name,path in files.items():
 raw=path.read_bytes();assert not any(secret in raw for secret in secrets),name;assert b'-----BEGIN '+b'PRIVATE KEY-----' not in raw,name
assert not O.exists();O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for name,path in sorted(files.items()):archive.add(path,arcname=name,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 seen=set()
 for member in archive:
  assert member.isfile() and member.name in index and member.name not in seen
  raw=archive.extractfile(member).read();assert len(raw)==index[member.name]['bytes'] and hashlib.sha256(raw).hexdigest()==index[member.name]['sha256'];seen.add(member.name)
 assert seen==index.keys()
clients=read(R/'build/service-native-state/client-limits/policy.json')['state']['policy']['clients']
limits={c['id']:{k:c[k] for k in ('requests_per_minute','tokens_per_minute','max_output_tokens')} for c in clients}
assert limits=={'alpha':dict(requests_per_minute=30,tokens_per_minute=6000,max_output_tokens=3457),'beta':dict(requests_per_minute=1,tokens_per_minute=6000,max_output_tokens=256)}
acceptance=dict(status='ACCEPT_NATIVE_REALTIME_CHAT_DELIVERY',revision=356,current=current,state='STOPPED',successful_commands=19,command_attempts=20,seconds=result['seconds'],new_gpu_starts=0,outer_enabled=True,outer_charged_total=0,persistent_client_limits=limits,usage_reset=False,profile_history_and_cooldown_preserved=True,original_capacity_failure_preserved=True,original_request_reused=result['original_request_reused'],retired_intents_archived=8,deleted_files=0,maintenance_seconds=capacity['seconds'],manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_to_retained_automatic_fault_actually_tested=True,reciprocal_automatic_fault_additionally_injected=False,reciprocal_registration_and_stopped_rollback_verified=True,older_engine_fallback=False,previous_rev346_preserved=True,original_tls_answer_quality='FAIL',model_quality_policy='record_exact_source_answer_separately',original_version_environment_abort_preserved=True,original_failures_preserved=True,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,full_model_quality=False,performance_claim=False,long_stability_run=False,full_openai_compatibility=False,listening_and_similarity_accepted=False,listening_deferred_by_owner=True,all_master_tasks_active=True)
save(O/'acceptance.json',acceptance)
(O/'README.md').write_text(f'''# 原生 Realtime 文本与工具对话可回退交付 rev356

默认引擎 `{current['engine_binary_sha256']}`，服务包
`{current['manifest_sha256']}`。19 项 STOPPED 发布、实际整根回退与再次
前进通过，{result['seconds']:.3f} 秒、20 次命令尝试，0 新增 GPU；服务保持
STOPPED，outer 启用且累计启动 0。前驱 rev346 及恢复入口保留。

本次交付 `/v1/realtime` 原生文本与函数工具对话：共享正常模型准入，
支持真实工具回填、流式终态、逐轮 RPM/TPM、取消及实际 token 结算。
[主轻资格](../serve-realtime-chat-primary-light-20261119/README.md)和
[保留/TLS/整包恢复](../serve-realtime-chat-managed-20261120/README.md)
覆盖实际资料工具和已配置的转录、语义 VAD、ICL/语音等能力保持。
恢复三组 4 模型、63 HTTP+21 Realtime/15 WebSocket/1 CUDA 探测，
{composition['service_seconds']:.3f} 秒、{composition['nvml_queries']} 次正常 NVML，自有资源释放。

原首次发布因 intent 128/128 容量拒绝，默认和 journal 均未切换；
8 条已退休请求通过现有维护工具原子迁出，0 删除，可按原计划恢复。
沿同一请求与原验收元数据继续完成，原 FAIL 不改写。维护另用
{capacity['seconds']:.3f} 秒。已完成的 CPU 缓存及 speaker 数值中间结果
保留 SHA 和无损恢复入口；未删除模型或合格程序，原路径复核须先恢复。

alpha RPM30/beta RPM1、两端 TPM6000、alpha 输出3457及已用额度保持；
私有验收夹具 TPM60000 未覆盖持久策略。profile 历史/冷却、版本周期
与 outer 预算保持。候选→保留实际自动整包恢复通过；反向完成登记
及 STOPPED 根回退，未另注入反向自动故障。

原 TLS 指令不遵循仍是模型质量 FAIL，按用户确认与恢复协议分别记录；
默认采样参数不改。原整包 NVML ENV_ABORT、路径复核、诊断及数值/
声纹失败均保留，用户延期听感仍待验。后续成功不能追认原错误。

PR #52 最终提交检查及实际合入另记。Realtime Prompt、音频、MCP、
追踪、Live 与其余 master 持续实施；此交付不表示完整 OpenAI 兼容、
全模型质量、性能或长稳通过。
''')
intro=f'[rev356原生Realtime文本/工具交付](evidence/serve-realtime-chat-delivery-20261120/README.md)\n完成：19项STOPPED检查、20次命令尝试/{result["seconds"]:.3f}秒，实际整根\n回退再前进，0新增GPU。首轮intent容量拒绝保留；8条退休记录\n可逆归档后沿原请求完成，全部配额/用量/恢复历史和预算保持。\n默认rev356 STOPPED，PR #52待最终检查合入；随后继续Prompt、\n音频/MCP/追踪/Live与全部master。原TLS质量FAIL、NVML ENV_ABORT、\n数值/声纹失败及用户延期听感保持，不将阶段交付当总目标完成。\n\n'
p=R/'docs/STATUS.md';detach(p);s=p.read_text()
rows={'发布':'rev356；服务包 `'+current['manifest_sha256']+'`','Generation':'`'+current['generation_sha256']+'`','引擎':'`'+current['engine_binary_sha256']+'`','引擎发布记录':'`'+current['engine_release_sha256']+'`','Guardian':'`'+release['guardian_sha256']+'`','原生入口':'`'+release['ingress_sha256']+'`','默认容量':'单流、ctx8192、prefill2048、主文本输出256、MTP k=3；inflight8/queue3；TTS 200帧、alpha输出3457/RPM30/TPM6000；参考ICL、Realtime转录/语义VAD/文本与函数工具对话','人工整包回退':'保留控制根 `'+acceptance['manual_root']+'`；同已验对话引擎、参考和周期保持；前驱rev346另保留','自动payload回退':'候选→保留控制包 `'+acceptance['automatic_payload']+'` 实际恢复已验；反向登记与STOPPED回退已验，未另注入反向故障；不是旧引擎回退'}
for name,value in rows.items():
 s,count=re.subn(r'^\| '+re.escape(name)+r' \| .* \|$',lambda _:f'| {name} | {value} |',s,count=1,flags=re.M);assert count==1,name
p.write_text(s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);head,body=p.read_text().split('\n',1)
p.write_text(head+'\n\n## 原生 Realtime 文本/工具 rev356 可回退交付\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：已验能力必须随默认、恢复根和客户状态一起交付。首轮遗漏\nintent容量预检，真实拒绝后归档8条退休记录，再沿原请求继续；\n没有重跑GPU，也没有清空任何历史或额度。数值中间结果只无损压缩，\n保留逐文件SHA与恢复脚本，模型和合格程序未动。\n\n下一步：PR #52最终检查与合入，继续Prompt及全部master任务；\n模型质量失败和延期听感单列，默认采样不改。\n'+body)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);entry=acceptance|dict(evidence='evidence/serve-realtime-chat-delivery-20261120/README.md')
g['native_realtime_chat_delivery_20261120']=entry
for task in g['tasks']:
 if task['id'] in ('A01','A10','A12','N06','R05','R06','Q01','Q02'):task['native_realtime_chat_delivery_20261120']=dict(revision=356,evidence=entry['evidence'])
 if task['id']=='Q02':task.update(state='rev356_delivered_pr52_final_checks_pending_remaining_master_active',latest_release=entry,remaining_required=['Realtime Chat final-head CI and actual main merge','Delivery of every remaining implementation'])
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev356 or then-current default; pending host/camera maintenance handoff remains required.'
g['native_tts_progress']['managed']['latest_service_revision']=356
g['realtime_progress'].update(state='native_transcription_semantic_vad_text_tools_delivered_rev356_audio_mcp_prompt_tracing_live_pending',text_conversation_delivered=True,tool_conversation_delivered=True,conversation_delivery=entry,full_realtime_api_qualified=False,next='Implement actual native Prompt lookup and immutable snapshots, then audio/MCP/tracing/Live; continue every remaining master task and preserve owner-deferred listening.')
g['next_task']='Realtime Chat final-head CI/main integration; implement native Prompt lookup/snapshots, audio/MCP/tracing/Live and every remaining A/N/R/Q task. Preserve original failures and owner-deferred listening.'
save(p,g)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [rev356原生Realtime文本/工具交付](evidence/serve-realtime-chat-delivery-20261120/README.md)：实际根回退、配额/恢复预算保持及原质量失败分开记录。\n')
p=R/'docs/SERVE_REALTIME_2026-11-19.md';detach(p);s=p.read_text().replace('真实业务、恢复及可回退交付；对话/工具/音频输出与Live继续实现。','真实业务、恢复及可回退交付；文本/函数工具对话现已交付rev356，\nPrompt、音频输出、MCP、追踪与Live继续实现。',1)
s=s.replace('## 已有阶段证据\n','## 已有阶段证据\n\n[rev356文本/工具可回退交付](evidence/serve-realtime-chat-delivery-20261120/README.md)：\n19项STOPPED成功检查、原容量失败保留，实际回退再前进；默认\nSTOPPED、配额/历史/预算保持。PR #52合入另记，其余master继续。\n',1);p.write_text(s)
p=R/'README.md';detach(p);s=p.read_text()
old='语音输出及assistant音频历史已交付rev326；Realtime工作分支候选的\n手动转录现已通过[官方SDK/原生WSS真实业务](docs/evidence/serve-realtime-transcription-business-20261119/README.md)，\n支持实际PCM/G.711、逐轮配额与取消回收。默认rev326尚不包含该候选，\n自动分段、对话/Live及完整恢复组合继续按总计划推进。'
new='语音输出及assistant音频历史已交付；当前rev356包含Realtime手动/\n自动转录、语义VAD和文本/函数工具对话，支持原生WebSocket/TLS、\n工具回填、逐轮配额与取消结算，已完成[实际恢复和可回退交付](docs/evidence/serve-realtime-chat-delivery-20261120/README.md)。\n原TLS随机回答的模型质量失败单独保留，默认采样未改。Realtime\nPrompt、音频输出、MCP、追踪及Live继续按总计划实现。'
assert old in s;s=s.replace(old,new,1)
old='当前只是编码组件候选，真实Speech HTTP、生成流式和4倍语速\n内容仍须完成，不能据此宣称语音输出已交付。'
new='真实Speech HTTP及生成流式已完成针对性验收；4倍语速保留直接\nASR质量限制，并按用户确认做速度归一化内容复核，正常听感仍待验。'
assert old in s;s=s.replace(old,new,1);p.write_text(s)
print(json.dumps({k:acceptance[k] for k in ('status','revision','successful_commands','seconds','files')}))

"""Continue original STOPPED publication after reversible intent-capacity maintenance."""
from pathlib import Path
import os,json,runpy,time,subprocess
W=Path(__file__).resolve().parent
base=runpy.run_path(str(W/'deliver_realtime_chat_01.py'))
p=base['p'];preserved=base['preserved'];profiles=base['profiles'];version=base['version'];exact=base['exact'];publication=base['publication']
R=base['R'];DEFAULT=base['DEFAULT'];STATE=base['STATE'];OLD=base['OLD'];D=W/'delivery-01';OUT=W/'delivery-02'
failed=p.read(D/'result.json');review=p.read(D/'review.json');ids=p.read(D/'requests.json')
p.require(failed['status']=='FAILED' and len(failed['commands'])==4 and failed['commands'][-1]['label']=='capability-upgrade' and failed['commands'][-1]['returncode']==1 and all(r['returncode']==0 for r in failed['commands'][:3]),'original failure differs')
p.require(p.read(W/'retired-intents-01/result.json')['status']=='PASS_REVERSIBLE_INTENT_ARCHIVE','intent capacity not restored')
p.require(preserved()==review['preserved'] and profiles()==review['previous_profiles'],'original protected state changed')
current=publication.status(STATE)
p.require(current['ready'] and current['revision']==346 and current['current']==review['previous']['current'] and not publication.intent_path(STATE,ids['upgrade']).exists(),'original transaction advanced')
p.require(len(list((STATE/'service-publication-intents').iterdir()))+5<=publication.MAX_INTENTS,'capacity inadequate for five planned publishes')
os.umask(0o077);OUT.mkdir(mode=0o700)
p.save(OUT/'plan.json',dict(scope=__doc__,original_result=dict(path=str(D/'result.json'),sha256=p.sha(D/'result.json')),request_ids=ids,original_request_reused=True,maximum_commands=16,maximum_seconds=700,maximum_command_seconds=180,original_seconds=failed['seconds'],new_gpu_starts=0,driver_sha256=p.sha(__file__)))
def run():
 review=p.read(D/'review.json');roots=review['roots'];ids=p.read(D/'requests.json');cli=Path(roots['candidate']['package'])/'bin/q4t';rows=[];started=time.monotonic();expected_profiles=review['previous_profiles']
 def call(label,args):
  p.require(len(rows)<16 and time.monotonic()-started<700,'STOPPED command/time bound');raw=list(map(str,args));r=subprocess.run(raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=min(180,700-(time.monotonic()-started)))
  (OUT/(label+'.stdout')).write_text(r.stdout);(OUT/(label+'.stderr')).write_text(r.stderr);rows.append(dict(label=label,argv=raw,returncode=r.returncode));p.save(OUT/'progress.json',dict(commands=rows,seconds=time.monotonic()-started));print(json.dumps(dict(step=label,returncode=r.returncode,seconds=time.monotonic()-started)),flush=True)
  p.require(r.returncode==0,'delivery command failed: '+label);p.require(preserved()==review['preserved'],'core/client/outer changed');p.require(profiles()==expected_profiles,'profile migration/budget changed');return json.loads(r.stdout)
 def publish(label,name,previous,revision,key):
  t=roots[name];return call(label,[cli,'service','publish','--state',STATE,'--default-root',DEFAULT,'--package',t['package'],'--manifest-sha256',t['manifest_sha256'],'--service-release',D/(name+'-service.release.json'),'--expected-manifest-sha256',previous,'--expected-revision',revision,'--request-id',ids[key]])
 def register(name,previous):
  v=call(name+'-register',[DEFAULT/'q4t','service','version-register','--state',STATE,'--registration',D/(name+'-registration.json'),'--expected-cycle',previous]);p.require(v['registered'] and not v['fallback_consumed'],'registration failed');return version()
 try:
  expected_profiles=review['expected_profiles']
  value=publish('capability-upgrade','candidate',OLD,346,'upgrade');p.require(value['durable'] and value['revision']==348,'explicit actual semantic VAD capability upgrade')
  candidate_state=register('candidate',review['previous_version']['registry']['cycle_id']);p.save(OUT/'candidate-cycle.json',candidate_state)
  value=publish('anchor-publish','retained',roots['candidate']['manifest_sha256'],348,'anchor');p.require(value['durable'] and value['revision']==350,'anchor publication');generation=value['current']['generation_sha256']
  anchor_state=register('retained',candidate_state['registry']['cycle_id']);p.save(OUT/'anchor-cycle.json',anchor_state)
  value=publish('candidate-publish','candidate',roots['retained']['manifest_sha256'],350,'candidate');p.require(value['durable'] and value['revision']==352,'candidate publication');exact(candidate_state,version())
  value=call('rollback',[cli,'service','publish-rollback','--state',STATE,'--default-root',DEFAULT,'--package',roots['candidate']['package'],'--manifest-sha256',roots['candidate']['manifest_sha256'],'--generation-sha256',generation,'--expected-manifest-sha256',roots['candidate']['manifest_sha256'],'--expected-revision',352,'--request-id',ids['rollback']]);p.require(value['durable'] and value['revision']==354,'root rollback');exact(anchor_state,version())
  p.require(call('rollback-check',[DEFAULT/'q4t','service','check','--state',STATE])['desired']=='STOPPED','retained root failed')
  p.require(call('rollback-outer',[DEFAULT/'q4t','service','outer-status','--state',STATE])['enabled'],'retained outer absent')
  value=publish('forward','candidate',roots['retained']['manifest_sha256'],354,'forward');p.require(value['durable'] and value['revision']==356,'forward');exact(candidate_state,version())
  for action in ('check','status','observe'):
   v=call('default-'+action,[DEFAULT/'q4t','service',action,'--state',STATE]);p.require(v['status']=='PASS' if action=='check' else v['state']=='STOPPED','default health')
  pro=call('profiles',[DEFAULT/'q4t','service','profiles-status','--state',STATE]);p.require(pro['selected']=='primary','profile selected changed')
  ver=call('version',[DEFAULT/'q4t','service','version-status','--state',STATE]);p.require(ver['cycle_id']==candidate_state['registry']['cycle_id'] and not ver['fallback_consumed'],'cycle changed')
  outer=call('outer',[DEFAULT/'q4t','service','outer-status','--state',STATE]);p.require(outer['enabled'] and outer['charged_total']==0,'outer budget changed')
  final=call('publication',[DEFAULT/'q4t','service','publish-status','--state',STATE]);p.require(final['ready'] and final['revision']==356 and final['current']['manifest_sha256']==roots['candidate']['manifest_sha256'],'default differs')
  p.save(OUT/'result.json',dict(status='PASS_NATIVE_REALTIME_CHAT_DELIVERED',seconds=failed['seconds']+time.monotonic()-started,continuation_seconds=time.monotonic()-started,commands=failed['commands']+rows,successful_commands=19,command_attempts=20,original_capacity_failure_preserved=True,original_request_reused=ids['upgrade'],original_result=dict(path=str(D/'result.json'),sha256=p.sha(D/'result.json')),publication=final,retained_anchor_generation=generation,profiles=pro,versions=ver,outer=outer,anchor_cycle=anchor_state,candidate_cycle=candidate_state,final_cycle=version(),preserved=review['preserved'],expected_profiles=expected_profiles,state='STOPPED',new_gpu_starts=0,all_master_tasks_active=True));print(json.dumps(dict(status='PASS_NATIVE_REALTIME_CHAT_DELIVERED',revision=356,commands=len(rows))))
 except BaseException as error:
  p.save(OUT/'result.json',dict(status='FAILED',commands=rows,error=repr(error),seconds=time.monotonic()-started));raise

run()

from pathlib import Path
import gzip,hashlib,json,os,shutil
out=Path(__file__).resolve().parent;root=out.parents[2]
for row in json.loads((out/'plan.json').read_bytes())['files']:
 path=root/row['path']
 if path.exists():
  assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'];continue
 path.parent.mkdir(parents=True,exist_ok=True)
 with gzip.open(out/row['archive'],'rb') as source,path.open('xb') as target:
  shutil.copyfileobj(source,target);target.flush();os.fsync(target.fileno())
 assert path.stat().st_size==row['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
 path.chmod(row['mode']);os.utime(path,ns=(row['atime_ns'],row['mtime_ns']))

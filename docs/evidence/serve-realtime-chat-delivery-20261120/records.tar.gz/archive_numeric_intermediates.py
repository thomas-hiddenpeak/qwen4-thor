"""Preserve completed speaker numerical intermediates in lossless files."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import time

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
SOURCE = ROOT / '.q4t-work/serve-diarization-20261118/component-01/run'
OUT = W / 'numeric-intermediates-archive-01'
OUT.mkdir(mode=0o700)
(OUT / 'files').mkdir(mode=0o700)
files = sorted(p for name in ('native', 'reference')
               for p in (SOURCE / name).rglob('*.f32') if p.is_file())
assert len(files) == 72 and sum(p.stat().st_size for p in files) == 205472256
started = time.monotonic()
records = []
for index, path in enumerate(files):
    st = path.stat()
    assert not path.is_symlink() and st.st_nlink == 1
    records.append(dict(path=str(path.relative_to(ROOT)), bytes=st.st_size,
                        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                        inode=st.st_ino, mode=st.st_mode & 0o777,
                        mtime_ns=st.st_mtime_ns, atime_ns=st.st_atime_ns,
                        archive=f'files/{index:03}.f32.gz'))
(OUT / 'plan.json').write_text(json.dumps(dict(files=records,
    scope='Completed generated f32 intermediates only; no model assets',
    maximum_files=72,maximum_original_bytes=205472256,new_gpu_starts=0),indent=2)+'\n')
(OUT / 'restore.py').write_text('''from pathlib import Path
import gzip,hashlib,json,os,shutil
out=Path(__file__).resolve().parent;root=out.parents[2]
for row in json.loads((out/'plan.json').read_bytes())['files']:
 path=root/row['path']
 if path.exists():
  assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'];continue
 path.parent.mkdir(parents=True,exist_ok=True)
 with gzip.open(out/row['archive'],'rb') as source,path.open('xb') as target:
  shutil.copyfileobj(source,target);target.flush();os.fsync(target.fileno())
 assert path.stat().st_size==row['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
 path.chmod(row['mode']);os.utime(path,ns=(row['atime_ns'],row['mtime_ns']))
''')
done = []
for row, path in zip(records, files):
    archive = OUT / row['archive']
    with archive.open('xb') as target:
        with gzip.GzipFile(filename='', mode='wb', fileobj=target,
                           compresslevel=6, mtime=0) as compressed:
            with path.open('rb') as source: shutil.copyfileobj(source, compressed)
        target.flush();os.fsync(target.fileno())
    with gzip.open(archive,'rb') as stream:
        digest=hashlib.file_digest(stream,'sha256').hexdigest()
    assert digest == row['sha256']
    assert path.stat().st_ino == row['inode']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    path.unlink()
    done.append(dict(path=row['path'],archive_bytes=archive.stat().st_size,
                     archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
    (OUT / 'progress.json').write_text(json.dumps(done,indent=2)+'\n')
result=dict(status='PASS_LOSSLESS_NUMERICAL_INTERMEDIATES_ARCHIVE',
    files=len(done),original_bytes=sum(v['bytes'] for v in records),
    archive_bytes=sum(v['archive_bytes'] for v in done),
    seconds=time.monotonic()-started,model_assets_unchanged=True,
    original_numerical_results_unchanged=True,new_gpu_starts=0,
    free_bytes=shutil.disk_usage(ROOT).free)
(OUT / 'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

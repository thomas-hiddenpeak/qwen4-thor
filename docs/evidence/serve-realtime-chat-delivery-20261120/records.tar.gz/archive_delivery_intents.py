"""Reversibly retire eight obsolete intents after original publication capacity failure."""
from pathlib import Path
import json,os,signal,sys,time,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import publication_intent_archive as archive
from tools.serve_service.package import sha,save,require
OUT=W/'retired-intents-01';STATE=ROOT/'build/service-native-state'
SELECTED=['ee230623-07b5-4102-806e-b13631b64e7d','2273f03c-e7b3-482e-9ff6-79f981eb2bfc','d41f8084-f100-4048-938a-013b7247afb7','5c164ec6-62fa-4166-9928-fde334d208e0','dbe8245d-e095-4a45-b589-cce055c7204b','4c04e9ff-8248-4666-9ca2-d7cddadcf713','9e8fbcf4-5c1d-4846-bf04-0aaabae94b08','c2845c34-081c-4eab-887d-7ecf20c94c46']
def protected():
 paths=[ROOT/p for p in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json')]
 paths += [p for p in STATE.rglob('*') if p.is_file() and (p.name=='ledger.json' or p.name=='policy.json')]
 return {str(p):sha(p) for p in paths}
def deadline(*_):raise TimeoutError('offline intent archive deadline')
os.umask(0o077);OUT.mkdir(mode=0o700);before=protected();started=time.monotonic();steps=[]
save(OUT/'plan.json',dict(scope=__doc__,maximum_seconds=240,maximum_operations=4,selected=SELECTED,protected=before,driver_sha256=sha(__file__),original_failure=dict(path=str(W/'delivery-01/result.json'),sha256=sha(W/'delivery-01/result.json')),original_reason='publication intent capacity reached: active 128/128; target generation prepared but intent absent and journals stable rev346',new_gpu_starts=0,deleted_files=0))
signal.signal(signal.SIGALRM,deadline);signal.alarm(240)
try:
 for batch in range(2):
  label='batch-'+str(batch+1)
  prepared=archive.prepare(STATE,OUT/label,SELECTED[batch*4:batch*4+4]);save(OUT/(label+'-prepared.json'),prepared);steps.append(label+'-prepared')
  require(protected()==before,'protected state changed')
  result=archive.apply(prepared['plan'],prepared['sha256']);save(OUT/(label+'-applied.json'),result);steps.append(label+'-applied')
  require(protected()==before and result['status']=='RETIRED' and result['deleted_files']==0,'archive/state mismatch')
  print(json.dumps(dict(step=label,status='RETIRED',count=4)),flush=True)
 count=len(list((STATE/'service-publication-intents').iterdir()));require(count==120,'active intent count differs')
 result=dict(status='PASS_REVERSIBLE_INTENT_ARCHIVE',seconds=time.monotonic()-started,steps=steps,active_intents=count,protected_unchanged=True,new_gpu_starts=0,deleted_files=0)
 save(OUT/'result.json',result);print(json.dumps(result),flush=True)
except BaseException:
 save(OUT/'result.json',dict(status='FAILED',seconds=time.monotonic()-started,steps=steps,failure=traceback.format_exc(),protected_unchanged=protected()==before,new_gpu_starts=0));raise
finally:signal.alarm(0)

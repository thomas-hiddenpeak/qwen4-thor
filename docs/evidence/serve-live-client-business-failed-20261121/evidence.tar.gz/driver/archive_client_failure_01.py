import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'client-business-01';O=R/'docs/evidence/serve-live-client-business-failed-20261121';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
result=read(P/'result.json');cleanup=read(P/'cleanup.json');lease=read(P/'lease/exit.json');plan=read(P/'plan.json');assert result['status']=='FAIL' and not cleanup['remaining'] and cleanup['model_exit']==0
queries=[json.loads(v) for v in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(q['status']=='OK' and q['returncode']==0 for q in queries)
rows=[json.loads(v) for v in (P/'client.events.jsonl').read_text().splitlines()];events=[r['event'] for r in rows if r['direction']=='server'];transcripts=[e for e in events if e['type'].endswith('transcript.delta')];assert not any(e['type']=='session.delegation.created' for e in events)
actual=read(P/'live-drained.json');summary=dict(status='FAIL_CLIENT_HANDOFF_BUSINESS_NOT_ACCEPTED',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],plan_sha256=sha((P/'plan.json').read_bytes()),record=plan['record'],actual_model_starts=1,actual_admitted_work=actual['q4t_client_rate_admitted_total{client="alpha"}'],actual_settled_tokens=actual['q4t_client_rate_settled_tokens_total{client="alpha"}'],original_counts_are_reserved_budget_not_actual_generations=True,seconds=result['seconds'],transcripts=transcripts,original_answer='明白。',missing_client_delegation=True,operator_stop_reason=read(P/'bounded-operator-stop.json'),empty_sdk_receipt_after_actor_termination=True,default_unchanged=True,environment_abort=False,nvml_queries=len(queries),all_nvml_queries_ok=True,cleanup_confirmed=True,main_not_delivered=True,master_active=True)
files={}
for n in ['counts.json','result.json','cleanup.json','before.json','live-drained.json','client.events.jsonl','client.sdk.json','client.stderr','bounded-operator-stop.json','failed-driver-sources.tar.gz','model.log','lease/exit.json','lease/nvml-queries.jsonl']:
 files['original/'+n]=(P/n).read_bytes()
files['driver/archive_client_failure_01.py']=Path(__file__).read_bytes()
idx={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,raw in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(raw);i.mode=0o600;i.mtime=0;t.addfile(i,io.BytesIO(raw));idx[n]=dict(sha256=sha(raw),bytes=len(raw))
summary['archive_sha256']=sha((O/'evidence.tar.gz').read_bytes())
(O/'index.json').write_text(json.dumps(idx,indent=2)+'\n');(O/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['status','actual_model_starts','actual_admitted_work','seconds','nvml_queries','cleanup_confirmed']},ensure_ascii=False))

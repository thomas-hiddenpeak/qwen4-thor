import ast, hashlib, json, os, time, typing, unicodedata
from pathlib import Path
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
from transformers import Qwen2TokenizerFast
start=time.monotonic()
root=Path.cwd(); a=root/'.q4t-work/serve-audio-aligner-20261117'; w=root/'.q4t-work/serve-audio-native-20261117'
source=a/'metadata-01/qwen3_forced_aligner.py'
module=ast.parse(source.read_text()); cls=next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='Qwen3ForceAlignProcessor')
namespace={'List':typing.List,'unicodedata':unicodedata}
exec(compile(ast.Module(body=[cls],type_ignores=[]),str(source),'exec'),namespace)
processor=namespace['Qwen3ForceAlignProcessor'].__new__(namespace['Qwen3ForceAlignProcessor'])
tokenizer=Qwen2TokenizerFast.from_pretrained(a/'assets-01',local_files_only=True)
old=json.loads((w/'model-cases-01/plan.json').read_text()); rows=[]
for i,case in enumerate(old['cases']):
 text=(w/f'compute-gpu-01/run/native/case-{i}/text.txt').read_text().split('<asr_text>',1)[1]
 words,prompt=processor.encode_timestamp(text,case['language'])
 prompt=prompt.replace('<|audio_pad|>','<|audio_pad|>'*case['audio_tokens'])
 ids=tokenizer.encode(prompt,add_special_tokens=False)
 assert ids.count(151705)==2*len(words) and ids.count(151676)==case['audio_tokens']
 rows.append({**{k:v for k,v in case.items() if k not in ('tokens','prompt','max_new_tokens','audio_start')},'tokens':ids,'words':words,'text':text,'audio_start':1})
plan={'status':'PREPARED_CPU_ONLY','cases':rows,'reference_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'tokenizer_config_sha256':hashlib.sha256((a/'assets-01/tokenizer_config.json').read_bytes()).hexdigest()}
(a/'alignment-cases-01.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
old['cases']=[dict(c,max_new_tokens=4) for c in old['cases']]
(a/'asr-regression-cases-01.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n')
import sys
t=sys.modules.get('torch');assert t is None or not t.cuda.is_initialized()
print(json.dumps({'status':'PREPARED_CPU_ONLY','seconds':time.monotonic()-start,'gpu':0,'cases':[{'language':c['language'],'frames':c['frames'],'words':len(c['words']),'tokens':len(c['tokens'])} for c in rows]}))

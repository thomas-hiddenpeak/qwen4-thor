// GPT-2 style Byte-Level BPE tokenizer implementation.
//
// See include/q4t/text/tokenizer.h for the contract. The algorithm mirrors the
// reference `tokenizers` library: NFC-normalize, split on the Unicode
// pre-tokenize regex, map each piece through the GPT-2 byte alphabet, then run
// ranked BPE merges with a lazy-deletion priority queue.
#include "q4t/text/tokenizer.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <charconv>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <initializer_list>
#include <limits>
#include <map>
#include <queue>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include <unicode/normlzr.h>
#include <unicode/bytestream.h>
#include <unicode/edits.h>
#include <unicode/normalizer2.h>
#include <unicode/parseerr.h>
#include <unicode/uregex.h>
#include <unicode/unistr.h>
#include <unicode/utypes.h>

#include "q4t/io/json.h"

namespace q4t {
namespace text {

namespace {

// The pinned GPT-2 pre-tokenize regex. Matches the exact pattern in the target
// model's tokenizer.json (pre_tokenizer.pretokenizers[0].pattern.Regex).
constexpr std::string_view kPretokenizeRegex =
    "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?"
    "[\\p{L}\\p{M}]+|\\p{N}| ?[^\\s\\p{L}\\p{M}\\p{N}]+"
    "[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+";

constexpr std::string_view kEmbeddingRegex =
    "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?"
    "\\p{L}+|\\p{N}| ?[^\\s\\p{L}\\p{N}]+"
    "[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+";
constexpr uint32_t kEmbeddingEos = 151643;

std::string_view ProfileRegex(TokenizerProfile profile) {
  return profile == TokenizerProfile::kQwen4Exp ? kPretokenizeRegex
                                               : kEmbeddingRegex;
}

// Fixed official ASR added-token metadata (Apache-2.0 attribution in
// third_party/licenses/qwen3-asr). IDs 151677..151703 are <blank1>..<blank27>.
std::string AsrAddedToken(uint32_t id) {
  constexpr std::array<std::string_view, 34> names{
      "<|endoftext|>", "<|im_start|>", "<|im_end|>",
      "<|object_ref_start|>", "<|object_ref_end|>", "<|box_start|>",
      "<|box_end|>", "<|quad_start|>", "<|quad_end|>", "<|vision_start|>",
      "<|vision_end|>", "<|vision_pad|>", "<|image_pad|>", "<|video_pad|>",
      "<tool_call>", "</tool_call>", "<|fim_prefix|>", "<|fim_middle|>",
      "<|fim_suffix|>", "<|fim_pad|>", "<|repo_name|>", "<|file_sep|>",
      "<tool_response>", "</tool_response>", "<think>", "</think>",
      "<|audio_start|>", "<|audio_end|>", "<tts_pad>", "<tts_text_bos>",
      "<tts_text_eod>", "<tts_text_bos_single>", "<non_speech>",
      "<|audio_pad|>"};
  if (id >= 151643 && id < 151677) return std::string(names[id - 151643]);
  if (id >= 151677 && id <= 151703)
    return "<blank" + std::to_string(id - 151676) + ">";
  return id == 151704 ? "<asr_text>" : "";
}

bool AsrTokenMetadata(const io::Json& token, uint32_t id,
                      bool alignment = false) {
  const auto expected = alignment && id == 151705 ? "<timestamp>"
                                                  : AsrAddedToken(id);
  if (expected.empty() || token.GetString("content") != expected ||
      token.object.size() != 7)
    return false;
  for (const char* field : {"normalized", "single_word", "lstrip", "rstrip"}) {
    const auto* value = token.Find(field);
    if (!value || !value->IsBool() || value->boolean) return false;
  }
  const auto* special = token.Find("special");
  const bool expected_special = !(id >= 151657 && id <= 151668) &&
                                 id != 151675 && id != 151704 && id != 151705;
  return special && special->IsBool() && special->boolean == expected_special;
}

struct AddedToken {
  std::uint32_t id = 0;
  std::string content;
  bool special = false;
};

struct MergeRule {
  std::uint32_t rank = 0;
  std::uint32_t result_id = 0;
};

struct TokenizerData {
  TokenizerLimits limits;
  TokenizerProfile profile = TokenizerProfile::kQwen4Exp;
  // GPT-2 byte alphabet: byte value -> the token string for that byte.
  std::array<std::string, 256> byte_encoder{};
  // Reverse of byte_encoder: code point -> byte value.
  std::unordered_map<std::uint32_t, std::uint8_t> byte_decoder;
  // byte value -> base vocab token id (the single-byte token).
  std::array<std::uint32_t, 256> byte_token_ids{};
  // token string -> base vocab id.
  std::unordered_map<std::string, std::uint32_t> vocabulary;
  // base vocab id -> token string (contiguous, size == base vocab size).
  std::vector<std::string> id_to_token;
  // (left_id << 32 | right_id) -> merge rule.
  std::unordered_map<std::uint64_t, MergeRule> merges;
  std::vector<AddedToken> added_tokens;
  std::unordered_map<std::uint32_t, std::size_t> added_by_id;
  URegularExpression* regex = nullptr;

  ~TokenizerData() {
    if (regex != nullptr) {
      uregex_close(regex);
    }
  }
};

std::uint64_t PairKey(std::uint32_t left, std::uint32_t right) noexcept {
  return (static_cast<std::uint64_t>(left) << 32U) |
         static_cast<std::uint64_t>(right);
}

// Build the GPT-2 byte-level alphabet. Bytes 33-126, 161-172, and 174-255 map
// to themselves; the remaining 100 bytes map to code points 256+.
bool InitializeByteMapping(TokenizerData& data, std::string* err) {
  std::array<bool, 256> direct{};
  for (std::uint32_t v = 33; v <= 126; ++v) direct[v] = true;
  for (std::uint32_t v = 161; v <= 172; ++v) direct[v] = true;
  for (std::uint32_t v = 174; v <= 255; ++v) direct[v] = true;
  std::uint32_t extension = 0;
  for (std::uint32_t v = 0; v <= 255; ++v) {
    const std::uint32_t cp = direct[v] ? v : 256U + extension++;
    // Encode the code point as UTF-8 into byte_encoder[v].
    if (cp < 0x80) {
      data.byte_encoder[v].push_back(static_cast<char>(cp));
    } else if (cp < 0x800) {
      data.byte_encoder[v].push_back(static_cast<char>(0xC0 | (cp >> 6)));
      data.byte_encoder[v].push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
      data.byte_encoder[v].push_back(static_cast<char>(0xE0 | (cp >> 12)));
      data.byte_encoder[v].push_back(static_cast<char>(
          0x80 | ((cp >> 6) & 0x3F)));
      data.byte_encoder[v].push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
    if (!data.byte_decoder.emplace(cp, static_cast<std::uint8_t>(v)).second) {
      *err = "duplicate GPT-2 byte mapping";
      return false;
    }
  }
  return true;
}

// Decode a single UTF-8 code point at `offset`, advancing `offset`.
bool DecodeUtf8At(std::string_view input, std::size_t* offset,
                  std::uint32_t* codepoint) {
  const std::size_t start = *offset;
  if (start >= input.size()) return false;
  const unsigned char* b =
      reinterpret_cast<const unsigned char*>(input.data() + start);
  auto cont = [&](std::size_t i) -> bool {
    return start + i < input.size() &&
           (b[i] & 0xC0) == 0x80;
  };
  std::uint32_t cp = 0;
  std::size_t len = 0;
  if (b[0] < 0x80) {
    cp = b[0];
    len = 1;
  } else if ((b[0] & 0xE0) == 0xC0 && cont(1)) {
    cp = ((b[0] & 0x1F) << 6) | (b[1] & 0x3F);
    len = 2;
  } else if ((b[0] & 0xF0) == 0xE0 && cont(1) && cont(2)) {
    cp = ((b[0] & 0x0F) << 12) | ((b[1] & 0x3F) << 6) | (b[2] & 0x3F);
    len = 3;
  } else if ((b[0] & 0xF8) == 0xF0 && cont(1) && cont(2) && cont(3)) {
    cp = ((b[0] & 0x07) << 18) | ((b[1] & 0x3F) << 12) |
         ((b[2] & 0x3F) << 6) | (b[3] & 0x3F);
    len = 4;
  } else {
    return false;
  }
  // Reject overlong encodings and surrogates.
  if (len == 2 && cp < 0x80) return false;
  if (len == 3 && cp < 0x800) return false;
  if (len == 4 && cp < 0x10000) return false;
  if (cp >= 0xD800 && cp <= 0xDFFF) return false;
  *codepoint = cp;
  *offset = start + len;
  return true;
}

bool ValidateUtf8(std::string_view input) {
  std::size_t offset = 0;
  std::uint32_t cp = 0;
  while (offset < input.size()) {
    if (!DecodeUtf8At(input, &offset, &cp)) return false;
  }
  return true;
}

// Validate the top-level schema is the expected BPE + ByteLevel + NFC shape.
bool SameJson(const io::Json& actual, const io::Json& expected) {
  if (actual.type != expected.type) return false;
  if (actual.IsString()) return actual.str == expected.str;
  if (actual.IsNumber()) return actual.number == expected.number;
  if (actual.IsBool()) return actual.boolean == expected.boolean;
  if (actual.IsArray()) {
    if (actual.array.size() != expected.array.size()) return false;
    for (size_t i = 0; i < actual.array.size(); ++i)
      if (!SameJson(actual.array[i], expected.array[i])) return false;
  }
  if (actual.IsObject()) {
    if (actual.object.size() != expected.object.size()) return false;
    for (const auto& [key, value] : expected.object) {
      const auto* found = actual.Find(key);
      if (!found || !SameJson(*found, value)) return false;
    }
  }
  return true;
}

bool EmbeddingPostprocessor(const io::Json& root) {
  constexpr char expected[] = R"({"type":"Sequence","processors":[
    {"type":"ByteLevel","add_prefix_space":false,"trim_offsets":false,
     "use_regex":false},
    {"type":"TemplateProcessing",
     "single":[{"Sequence":{"id":"A","type_id":0}},
               {"SpecialToken":{"id":"<|endoftext|>","type_id":0}}],
     "pair":[{"Sequence":{"id":"A","type_id":0}},
             {"Sequence":{"id":"B","type_id":0}},
             {"SpecialToken":{"id":"<|endoftext|>","type_id":0}}],
     "special_tokens":{"<|endoftext|>":{"id":"<|endoftext|>",
       "ids":[151643],"tokens":["<|endoftext|>"]}}}]})";
  io::Json value;
  const auto* processor = root.Find("post_processor");
  return processor && io::ParseJson(expected, &value).ok() &&
         SameJson(*processor, value);
}

bool ValidateSchema(const io::Json& root, TokenizerProfile profile,
                    std::string* err) {
  if (profile != TokenizerProfile::kQwen4Exp &&
      profile != TokenizerProfile::kQwen3Embedding &&
      profile != TokenizerProfile::kQwen3Asr &&
      profile != TokenizerProfile::kQwen3Aligner) {
    *err = "unknown tokenizer profile";
    return false;
  }
  if (root.GetString("version") != "1.0") {
    *err = "tokenizer version is not 1.0";
    return false;
  }
  const io::Json* model = root.Find("model");
  if (model == nullptr || !model->IsObject()) {
    *err = "missing model object";
    return false;
  }
  if (model->GetString("type") != "BPE") {
    *err = "model.type is not BPE";
    return false;
  }
  if (model->GetBool("byte_fallback") || model->GetBool("ignore_merges") ||
      model->GetBool("fuse_unk")) {
    *err = "unsupported BPE flags (byte_fallback/ignore_merges/fuse_unk)";
    return false;
  }
  const io::Json* normalizer = root.Find("normalizer");
  if (normalizer == nullptr || !normalizer->IsObject() ||
      normalizer->GetString("type") != "NFC") {
    *err = "normalizer must be NFC";
    return false;
  }
  const io::Json* pre = root.Find("pre_tokenizer");
  if (pre == nullptr || !pre->IsObject() ||
      pre->GetString("type") != "Sequence") {
    *err = "pre_tokenizer must be a Sequence";
    return false;
  }
  const io::Json* pretoks = pre->GetArray("pretokenizers");
  if (pretoks == nullptr || pretoks->array.size() != 2) {
    *err = "pre_tokenizer must have exactly 2 pretokenizers";
    return false;
  }
  const io::Json& split = pretoks->array[0];
  const io::Json& bytelvl = pretoks->array[1];
  if (!split.IsObject() || split.GetString("type") != "Split" ||
      split.GetString("behavior") != "Isolated" ||
      split.GetBool("invert")) {
    *err = "pre_tokenizer[0] must be Split/Isolated/non-invert";
    return false;
  }
  const io::Json* pattern = split.Find("pattern");
  if (pattern == nullptr || !pattern->IsObject() ||
      pattern->GetString("Regex") != ProfileRegex(profile)) {
    *err = "pre_tokenizer[0].pattern.Regex does not match the pinned regex";
    return false;
  }
  if (!bytelvl.IsObject() || bytelvl.GetString("type") != "ByteLevel" ||
      bytelvl.GetBool("add_prefix_space") || bytelvl.GetBool("use_regex")) {
    *err = "pre_tokenizer[1] must be ByteLevel (no prefix space)";
    return false;
  }
  const io::Json* decoder = root.Find("decoder");
  if (decoder == nullptr || !decoder->IsObject() ||
      decoder->GetString("type") != "ByteLevel" ||
      decoder->GetBool("add_prefix_space")) {
    *err = "decoder must be ByteLevel (no prefix space)";
    return false;
  }
  if (profile == TokenizerProfile::kQwen3Embedding &&
      !EmbeddingPostprocessor(root)) {
    *err = "embedding EOS postprocessor does not match the pinned contract";
    return false;
  }
  if (profile == TokenizerProfile::kQwen3Asr ||
      profile == TokenizerProfile::kQwen3Aligner) {
    for (const char* field : {"post_processor", "truncation", "padding"}) {
      const auto* value = root.Find(field);
      if (!value || !value->IsNull()) {
        *err = "ASR tokenizer must not add, truncate or pad tokens";
        return false;
      }
    }
  }
  return true;
}

// Parse model.vocab + model.merges into the data structures.
bool ParseModel(const io::Json& root, TokenizerData& data, std::string* err) {
  const io::Json* model = root.Find("model");
  const io::Json* vocab = model->Find("vocab");
  if (vocab == nullptr || !vocab->IsObject()) {
    *err = "model.vocab must be an object";
    return false;
  }
  if (vocab->object.size() > data.limits.max_vocab_size) {
    *err = "vocabulary exceeds max_vocab_size";
    return false;
  }
  const size_t expected_vocab = data.profile == TokenizerProfile::kQwen4Exp
                                    ? Tokenizer::kPinnedBaseVocabSize
                                    : kEmbeddingEos;
  if (vocab->object.size() != expected_vocab) {
    *err = "base vocabulary size does not match the pinned tokenizer";
    return false;
  }
  data.vocabulary.reserve(vocab->object.size());
  data.id_to_token.resize(vocab->object.size());
  std::vector<bool> seen(vocab->object.size(), false);
  for (const auto& kv : vocab->object) {
    const io::Json& value = kv.second;
    if (!value.IsNumber()) {
      *err = "vocabulary value is not a number";
      return false;
    }
    const int64_t integer = value.AsInt(-1);
    if (integer < 0 || static_cast<uint64_t>(integer) >= vocab->object.size()) {
      *err = "vocabulary id out of range";
      return false;
    }
    const auto id = static_cast<uint64_t>(integer);
    if (seen[id]) {
      *err = "vocabulary ids are not unique";
      return false;
    }
    seen[id] = true;
    data.id_to_token[id] = kv.first;
    data.vocabulary.emplace(kv.first, static_cast<std::uint32_t>(id));
  }
  if (std::find(seen.begin(), seen.end(), false) != seen.end()) {
    *err = "vocabulary ids are not contiguous";
    return false;
  }
  // Resolve the single-byte token ids.
  for (std::size_t byte = 0; byte < data.byte_encoder.size(); ++byte) {
    const auto found = data.vocabulary.find(data.byte_encoder[byte]);
    if (found == data.vocabulary.end()) {
      *err = "vocabulary is missing a GPT-2 byte token";
      return false;
    }
    data.byte_token_ids[byte] = found->second;
  }
  // Parse merges.
  const io::Json* merges = model->Find("merges");
  if (merges == nullptr || !merges->IsArray()) {
    *err = "model.merges must be an array";
    return false;
  }
  if (merges->array.size() > data.limits.max_merges) {
    *err = "merges exceed max_merges";
    return false;
  }
  const size_t expected_merges =
      data.profile == TokenizerProfile::kQwen4Exp
          ? Tokenizer::kPinnedMergeCount
          : 151387;
  if (merges->array.size() != expected_merges) {
    *err = "merge count does not match the pinned tokenizer";
    return false;
  }
  data.merges.reserve(merges->array.size());
  for (std::size_t rank = 0; rank < merges->array.size(); ++rank) {
    const io::Json& entry = merges->array[rank];
    std::string left, right;
    if (data.profile == TokenizerProfile::kQwen3Embedding) {
      if (!entry.IsArray() || entry.array.size() != 2 ||
          !entry.array[0].IsString() || !entry.array[1].IsString() ||
          entry.array[0].str.empty() || entry.array[1].str.empty()) {
        *err = "embedding merge entry must be a two-token array";
        return false;
      }
      left = entry.array[0].str;
      right = entry.array[1].str;
    } else {
      if (!entry.IsString()) {
        *err = "merge entry must be a string";
        return false;
      }
      const std::string& text = entry.str;
      const std::size_t sep = text.find(' ');
      if (sep == std::string::npos || sep == 0 || sep + 1 >= text.size() ||
          text.find(' ', sep + 1) != std::string::npos) {
        *err = "merge entry must contain exactly two tokens";
        return false;
      }
      left = text.substr(0, sep);
      right = text.substr(sep + 1);
    }
    const auto left_id = data.vocabulary.find(left);
    const auto right_id = data.vocabulary.find(right);
    const auto result_id = data.vocabulary.find(left + right);
    if (left_id == data.vocabulary.end() ||
        right_id == data.vocabulary.end() ||
        result_id == data.vocabulary.end()) {
      *err = "merge references a token absent from the vocabulary";
      return false;
    }
    const auto inserted = data.merges.emplace(
        PairKey(left_id->second, right_id->second),
        MergeRule{static_cast<std::uint32_t>(rank), result_id->second});
    if (!inserted.second) {
      *err = "duplicate merge pair";
      return false;
    }
  }
  return true;
}

// Parse added_tokens (dynamic: the target model embeds 33, ids 248044+).
bool ParseAddedTokens(const io::Json& root, TokenizerData& data,
                      std::string* err) {
  const io::Json* tokens = root.GetArray("added_tokens");
  if (tokens == nullptr) {
    *err = "added_tokens must be an array";
    return false;
  }
  if (tokens->array.size() > data.limits.max_added_tokens) {
    *err = "added tokens exceed max_added_tokens";
    return false;
  }
  if (data.profile == TokenizerProfile::kQwen3Embedding &&
      tokens->array.size() != 26) {
    *err = "embedding added-token count differs";
    return false;
  }
  const bool alignment = data.profile == TokenizerProfile::kQwen3Aligner;
  if ((data.profile == TokenizerProfile::kQwen3Asr || alignment) &&
      tokens->array.size() != (alignment ? 63 : 62)) {
    *err = "ASR added-token count differs";
    return false;
  }
  data.added_tokens.reserve(tokens->array.size());
  for (const io::Json& token : tokens->array) {
    if (!token.IsObject()) {
      *err = "added token must be an object";
      return false;
    }
    const io::Json* id = token.Find("id");
    const io::Json* content = token.Find("content");
    if (id == nullptr || !id->IsNumber() || content == nullptr ||
        !content->IsString()) {
      *err = "added token must have numeric id and string content";
      return false;
    }
    const int64_t integer = id->AsInt(-1);
    if (integer < 0 || integer > std::numeric_limits<uint32_t>::max()) {
      *err = "added token id must be an exact uint32";
      return false;
    }
    const auto token_id = static_cast<uint32_t>(integer);
    if ((data.profile == TokenizerProfile::kQwen3Asr || alignment) &&
        !AsrTokenMetadata(token, token_id, alignment)) {
      *err = "ASR added-token contract differs";
      return false;
    }
    if (token_id < data.id_to_token.size()) {
      *err = "added token id collides with the base vocabulary";
      return false;
    }
    if (data.profile == TokenizerProfile::kQwen3Embedding &&
        (token_id >= kEmbeddingEos + 26 || token.GetBool("normalized") ||
         token.GetBool("single_word") || token.GetBool("lstrip") ||
         token.GetBool("rstrip") ||
         (token_id == kEmbeddingEos &&
          (content->str != "<|endoftext|>" || !token.GetBool("special"))))) {
      *err = "embedding added-token contract differs";
      return false;
    }
    AddedToken added;
    added.id = token_id;
    added.content = content->str;
    added.special = token.GetBool("special");
    if (!data.added_by_id.emplace(added.id, data.added_tokens.size())
             .second) {
      *err = "duplicate added token id";
      return false;
    }
    data.added_tokens.push_back(std::move(added));
  }
  return true;
}

bool CompileRegex(TokenizerData& data, std::string* err) {
  UErrorCode status = U_ZERO_ERROR;
  // Convert the UTF-8 pattern to UTF-16. uregex_open copies the pattern
  // contents, so the temporary UnicodeString may be destroyed afterwards.
  const icu::UnicodeString pattern = icu::UnicodeString::fromUTF8(
      icu::StringPiece(ProfileRegex(data.profile).data(),
                       static_cast<int32_t>(ProfileRegex(data.profile).size())));
  UParseError pe;
  data.regex =
      uregex_open(pattern.getBuffer(), pattern.length(), 0, &pe, &status);
  if (U_FAILURE(status) || data.regex == nullptr) {
    *err = std::string("could not compile tokenizer regex: ") +
           u_errorName(status);
    data.regex = nullptr;
    return false;
  }
  return true;
}

struct BpeNode {
  std::uint32_t token_id = 0;
  std::size_t previous = std::numeric_limits<std::size_t>::max();
  std::size_t next = std::numeric_limits<std::size_t>::max();
  std::uint32_t generation = 0;
  bool alive = true;
};

struct BpeCandidate {
  std::uint32_t rank = 0;
  std::size_t left = 0;
  std::size_t right = 0;
  std::uint32_t left_generation = 0;
  std::uint32_t right_generation = 0;
};

struct CandidateLater {
  bool operator()(const BpeCandidate& a, const BpeCandidate& b) const noexcept {
    if (a.rank != b.rank) return a.rank > b.rank;
    return a.left > b.left;
  }
};

// Run ranked BPE merges on a single pre-tokenized piece (already a valid
// UTF-8 byte string of GPT-2 byte tokens).
bool EncodingCancelled(const EncodeOptions& options, std::string* err) {
  if (!options.cancelled || !options.cancelled()) return false;
  *err = "encoding cancelled";
  return true;
}

bool EncodeBpePiece(const TokenizerData& data, std::string_view piece,
                    std::vector<std::uint32_t>* output, std::string* err,
                    const EncodeOptions& options) {
  if (EncodingCancelled(options, err)) return false;
  if (piece.empty()) return true;
  std::vector<BpeNode> nodes(piece.size());
  for (std::size_t i = 0; i < piece.size(); ++i) {
    if ((i & 1023) == 0 && EncodingCancelled(options, err)) return false;
    nodes[i].token_id =
        data.byte_token_ids[static_cast<std::uint8_t>(piece[i])];
    nodes[i].previous =
        i == 0 ? std::numeric_limits<std::size_t>::max() : i - 1;
    nodes[i].next = i + 1 < piece.size() ? i + 1
                                         : std::numeric_limits<std::size_t>::max();
  }
  std::priority_queue<BpeCandidate, std::vector<BpeCandidate>, CandidateLater>
      candidates;
  auto add_candidate = [&](std::size_t left) {
    if (left == std::numeric_limits<std::size_t>::max() ||
        !nodes[left].alive ||
        nodes[left].next == std::numeric_limits<std::size_t>::max()) {
      return;
    }
    const std::size_t right = nodes[left].next;
    const auto rule =
        data.merges.find(PairKey(nodes[left].token_id, nodes[right].token_id));
    if (rule != data.merges.end()) {
      candidates.push(BpeCandidate{rule->second.rank, left, right,
                                   nodes[left].generation,
                                   nodes[right].generation});
    }
  };
  for (std::size_t i = 0; i + 1 < nodes.size(); ++i) {
    if ((i & 1023) == 0 && EncodingCancelled(options, err)) return false;
    add_candidate(i);
  }
  std::size_t work = 0;
  while (!candidates.empty()) {
    if ((work++ & 1023) == 0 && EncodingCancelled(options, err)) return false;
    const BpeCandidate c = candidates.top();
    candidates.pop();
    BpeNode& left = nodes[c.left];
    BpeNode& right = nodes[c.right];
    if (!left.alive || !right.alive || left.next != c.right ||
        left.generation != c.left_generation ||
        right.generation != c.right_generation) {
      continue;
    }
    const auto rule =
        data.merges.find(PairKey(left.token_id, right.token_id));
    if (rule == data.merges.end() || rule->second.rank != c.rank) continue;
    left.token_id = rule->second.result_id;
    ++left.generation;
    right.alive = false;
    ++right.generation;
    left.next = right.next;
    if (right.next != std::numeric_limits<std::size_t>::max()) {
      nodes[right.next].previous = c.left;
    }
    add_candidate(left.previous);
    add_candidate(c.left);
  }
  std::size_t current = 0;
  while (current != std::numeric_limits<std::size_t>::max()) {
    if ((work++ & 1023) == 0 && EncodingCancelled(options, err)) return false;
    if (output->size() >= data.limits.max_tokens) {
      *err = "encoded output exceeds max_tokens";
      return false;
    }
    output->push_back(nodes[current].token_id);
    current = nodes[current].next;
  }
  return true;
}

// NFC-normalize `segment` (valid UTF-8), split on the pre-tokenize regex, and
// BPE-encode every piece into `output`.
bool EncodeNormalSegment(const TokenizerData& data, std::string_view segment,
                         std::vector<std::uint32_t>* output,
                         std::string* err, const EncodeOptions& options) {
  if (EncodingCancelled(options, err)) return false;
  if (segment.empty()) return true;
  if (!ValidateUtf8(segment)) {
    *err = "input is not valid UTF-8";
    return false;
  }
  if (segment.size() >
      static_cast<std::size_t>(std::numeric_limits<std::int32_t>::max())) {
    *err = "input exceeds ICU string length";
    return false;
  }
  UErrorCode status = U_ZERO_ERROR;
  const icu::Normalizer2* normalizer = icu::Normalizer2::getNFCInstance(status);
  if (U_FAILURE(status) || normalizer == nullptr) {
    *err = std::string("could not acquire ICU NFC normalizer: ") +
           u_errorName(status);
    return false;
  }
  const icu::UnicodeString unicode = icu::UnicodeString::fromUTF8(
      icu::StringPiece(segment.data(),
                       static_cast<std::int32_t>(segment.size())));
  icu::UnicodeString normalized;
  normalizer->normalize(unicode, normalized, status);
  if (EncodingCancelled(options, err)) return false;
  if (U_FAILURE(status)) {
    *err = std::string("ICU NFC normalization failed: ") +
           u_errorName(status);
    return false;
  }
  // Point the compiled regex at the normalized subject text. The buffer must
  // remain valid (unmodified) for the duration of matching.
  uregex_setText(data.regex, normalized.getBuffer(), normalized.length(),
                 &status);
  if (U_FAILURE(status)) {
    *err = std::string("could not set tokenizer regex text: ") +
           u_errorName(status);
    return false;
  }
  std::string piece;
  std::int32_t previous_end = 0;
  auto encode_span = [&](std::int32_t start, std::int32_t end) -> bool {
    const icu::UnicodeString sub =
        normalized.tempSubStringBetween(start, end);
    piece.clear();
    sub.toUTF8String(piece);
    if (piece.size() > data.limits.max_input_bytes) {
      *err = "normalized piece exceeds max_input_bytes";
      return false;
    }
    return EncodeBpePiece(data, piece, output, err, options);
  };
  UErrorCode mstatus = U_ZERO_ERROR;
  bool found = uregex_find(data.regex, -1, &mstatus);
  while (found && !U_FAILURE(mstatus)) {
    if (EncodingCancelled(options, err)) return false;
    const std::int32_t start = uregex_start(data.regex, 0, &mstatus);
    const std::int32_t end = uregex_end(data.regex, 0, &mstatus);
    if (U_FAILURE(mstatus) || start < previous_end || end <= start) {
      *err = "tokenizer regex returned invalid match offsets";
      return false;
    }
    if (start > previous_end && !encode_span(previous_end, start)) {
      return false;
    }
    if (!encode_span(start, end)) {
      return false;
    }
    previous_end = end;
    found = uregex_findNext(data.regex, &mstatus);
  }
  if (U_FAILURE(mstatus)) {
    *err = std::string("tokenizer regex matching failed: ") +
           u_errorName(mstatus);
    return false;
  }
  if (previous_end < normalized.length() &&
      !encode_span(previous_end, normalized.length())) {
    return false;
  }
  return true;
}

// Encode the full text, matching added/special tokens as whole substrings
// before the byte-level BPE path. This mirrors the `tokenizers` library and
// transformers' Qwen2Tokenizer: a special marker such as 超级用户 is emitted as
// its added-token id (248045) rather than being BPE-encoded into byte tokens.
// The earliest occurrence wins; at the same position the longest content wins.
bool EncodeImpl(const TokenizerData& data, std::string_view text,
                std::vector<std::uint32_t>* output, std::string* err,
                const EncodeOptions& options) {
  if (EncodingCancelled(options, err)) return false;
  if (text.size() > data.limits.max_input_bytes) {
    *err = "input exceeds max_input_bytes";
    return false;
  }
  output->clear();
  output->reserve(std::min(text.size(), data.limits.max_tokens));
  if (!options.recognize_special_tokens)
    return EncodeNormalSegment(data, text, output, err, options);
  std::size_t cursor = 0;
  // Each marker advances its own search frontier. A missing marker stays
  // missing instead of rescanning the remaining input after every match.
  std::vector<std::size_t> next(data.added_tokens.size(), 0);
  while (cursor < text.size()) {
    if (EncodingCancelled(options, err)) return false;
    std::size_t match_position = std::string_view::npos;
    const AddedToken* matched = nullptr;
    for (std::size_t i = 0; i < data.added_tokens.size(); ++i) {
      const AddedToken& token = data.added_tokens[i];
      if (token.content.empty()) continue;
      if (cursor == 0 || next[i] < cursor) {
        if (EncodingCancelled(options, err)) return false;
        next[i] = text.find(token.content, cursor);
        if (options.stats) {
          ++options.stats->special_searches;
          options.stats->special_search_bytes += next[i] == std::string_view::npos
              ? text.size() - cursor
              : next[i] - cursor + token.content.size();
        }
      }
      const std::size_t position = next[i];
      if (position != std::string_view::npos &&
          (match_position == std::string_view::npos ||
           position < match_position ||
           (position == match_position &&
            token.content.size() > matched->content.size()))) {
        match_position = position;
        matched = &token;
      }
    }
    if (matched == nullptr) {
      return EncodeNormalSegment(data, text.substr(cursor), output, err, options);
    }
    if (match_position > cursor &&
        !EncodeNormalSegment(data,
                             text.substr(cursor, match_position - cursor),
                             output, err, options)) {
      return false;
    }
    if (output->size() >= data.limits.max_tokens) {
      *err = "encoded output exceeds max_tokens";
      return false;
    }
    output->push_back(matched->id);
    cursor = match_position + matched->content.size();
  }
  return true;
}

}  // namespace

struct Tokenizer::Impl {
  TokenizerData data;
};

Tokenizer::Tokenizer(std::unique_ptr<Impl> impl) noexcept
    : impl_(std::move(impl)) {}
Tokenizer::~Tokenizer() = default;
Tokenizer::Tokenizer(Tokenizer&&) noexcept = default;
Tokenizer& Tokenizer::operator=(Tokenizer&&) noexcept = default;

Status Tokenizer::LoadJson(std::string_view json, const TokenizerLimits& limits,
                           std::unique_ptr<Tokenizer>* out,
                           TokenizerProfile profile) {
  if (json.size() > limits.max_tokenizer_bytes) {
    return Status::Fail("tokenizer JSON exceeds max_tokenizer_bytes");
  }
  io::Json root;
  io::JsonParseLimits parse_limits;
  parse_limits.reject_duplicate_keys =
      profile != TokenizerProfile::kQwen4Exp;
  Status parse = io::ParseJson(std::string(json), &root, false, parse_limits);
  if (!parse.ok()) return parse;
  return LoadDocument(root, limits, out, profile);
}

Status Tokenizer::LoadDocument(const io::Json& root,
                               const TokenizerLimits& limits,
                               std::unique_ptr<Tokenizer>* out,
                               TokenizerProfile profile) {
  if (!out) return Status::Fail("tokenizer output is null");
  std::string err;
  if (!ValidateSchema(root, profile, &err)) {
    return Status::Fail("tokenizer schema mismatch: " + err);
  }
  auto impl = std::make_unique<Impl>();
  impl->data.limits = limits;
  impl->data.profile = profile;
  if (!InitializeByteMapping(impl->data, &err)) {
    return Status::Fail(err);
  }
  if (!ParseModel(root, impl->data, &err)) {
    return Status::Fail("tokenizer model error: " + err);
  }
  if (!ParseAddedTokens(root, impl->data, &err)) {
    return Status::Fail("tokenizer added_tokens error: " + err);
  }
  if (!CompileRegex(impl->data, &err)) {
    return Status::Fail(err);
  }
  *out = std::unique_ptr<Tokenizer>(new Tokenizer(std::move(impl)));
  return Status();
}

Status Tokenizer::Load(const std::string& path, const TokenizerLimits& limits,
                       std::unique_ptr<Tokenizer>* out,
                       TokenizerProfile profile) {
  std::ifstream file(path, std::ios::binary);
  if (!file) {
    return Status::Fail("could not open tokenizer file: " + path);
  }
  std::string json((std::istreambuf_iterator<char>(file)),
                   std::istreambuf_iterator<char>());
  return LoadJson(json, limits, out, profile);
}

Status Tokenizer::LoadQwen3Asr(std::string_view vocab_json,
                              std::string_view merges_text,
                              std::string_view config_json,
                              const TokenizerLimits& limits,
                              std::unique_ptr<Tokenizer>* out) {
  return LoadQwen3Speech(vocab_json, merges_text, config_json, limits, out,
                          TokenizerProfile::kQwen3Asr);
}

Status Tokenizer::LoadQwen3Aligner(std::string_view vocab_json,
                              std::string_view merges_text,
                              std::string_view config_json,
                              const TokenizerLimits& limits,
                              std::unique_ptr<Tokenizer>* out) {
  return LoadQwen3Speech(vocab_json, merges_text, config_json, limits, out,
                          TokenizerProfile::kQwen3Aligner);
}

Status Tokenizer::LoadQwen3Speech(std::string_view vocab_json,
                              std::string_view merges_text,
                              std::string_view config_json,
                              const TokenizerLimits& limits,
                              std::unique_ptr<Tokenizer>* out,
                                 TokenizerProfile profile) {
  const bool alignment = profile == TokenizerProfile::kQwen3Aligner;
  size_t remaining = limits.max_tokenizer_bytes;
  for (const auto bytes : {vocab_json, merges_text, config_json}) {
    if (bytes.size() > remaining)
      return Status::Fail("ASR tokenizer exceeds max_tokenizer_bytes");
    remaining -= bytes.size();
  }
  if (config_json.size() > 65536)
    return Status::Fail("ASR tokenizer config exceeds 64 KiB");
  io::Json config, vocab;
  io::JsonParseLimits parse_limits;
  parse_limits.max_depth = 8;
  parse_limits.max_values = 4096;
  parse_limits.max_string_bytes = 65536;
  parse_limits.reject_duplicate_keys = true;
  if (auto s = io::ParseJson(std::string(config_json), &config, false,
                             parse_limits); !s)
    return s;
  if (!config.IsObject()) return Status::Fail("ASR tokenizer config object");
  for (const auto& [name, expected] :
       std::initializer_list<std::pair<const char*, const char*>>{
           {"tokenizer_class", "Qwen2Tokenizer"},
           {"processor_class", "Qwen3ASRProcessor"},
           {"eos_token", "<|im_end|>"}, {"pad_token", "<|endoftext|>"},
           {"audio_bos_token", "<|audio_start|>"},
           {"audio_eos_token", "<|audio_end|>"},
           {"audio_token", "<|audio_pad|>"},
           {"image_token", "<|image_pad|>"},
           {"video_token", "<|video_pad|>"},
           {"vision_bos_token", "<|vision_start|>"},
           {"vision_eos_token", "<|vision_end|>"}, {"errors", "replace"}})
    if (config.GetString(name) != expected)
      return Status::Fail(std::string("ASR tokenizer differs: ") + name);
  for (const char* name : {"add_bos_token", "add_prefix_space",
                            "clean_up_tokenization_spaces",
                            "split_special_tokens"}) {
    const auto* value = config.Find(name);
    if (!value || !value->IsBool() || value->boolean)
      return Status::Fail(std::string("ASR tokenizer differs: ") + name);
  }
  for (const char* name : {"bos_token", "unk_token"}) {
    const auto* value = config.Find(name);
    if (!value || !value->IsNull())
      return Status::Fail(std::string("ASR tokenizer differs: ") + name);
  }
  if (const auto* eos = config.Find("add_eos_token");
      eos && (!eos->IsBool() || eos->boolean))
    return Status::Fail("ASR tokenizer must not insert EOS");
  if (config.GetInt("model_max_length", -1) != 131072)
    return Status::Fail("ASR tokenizer context differs");
  const auto* extra = config.Find("extra_special_tokens");
  if (!extra || !extra->IsObject() || extra->object.size() != 7)
    return Status::Fail("ASR tokenizer extra special tokens differ");
  for (const char* name : {"audio_bos_token", "audio_eos_token", "audio_token",
                            "image_token", "video_token", "vision_bos_token",
                            "vision_eos_token"})
    if (extra->GetString(name) != config.GetString(name))
      return Status::Fail("ASR tokenizer extra special token mapping differs");
  constexpr std::array<uint32_t, 19> kAdditional{
      151644, 151645, 151646, 151647, 151648, 151649, 151650,
      151651, 151652, 151653, 151654, 151655, 151656, 151669,
      151670, 151671, 151672, 151674, 151676};
  const auto* additional = config.GetArray("additional_special_tokens");
  if (!additional || additional->array.size() != kAdditional.size())
    return Status::Fail("ASR tokenizer additional special tokens differ");
  for (size_t i = 0; i < kAdditional.size(); ++i)
    if (!additional->array[i].IsString() ||
        additional->array[i].str != AsrAddedToken(kAdditional[i]))
      return Status::Fail("ASR tokenizer additional special token differs");
  const auto* added = config.Find("added_tokens_decoder");
  if (!added || !added->IsObject() || added->object.size() != (alignment ? 63 : 62) ||
      added->object.size() > limits.max_added_tokens)
    return Status::Fail("ASR tokenizer added tokens differ/exceed budget");
  io::Json tokens;
  tokens.type = io::Json::Type::kArray;
  for (const auto& [id_text, metadata] : added->object) {
    uint32_t id = 0;
    const auto [end, error] = std::from_chars(
        id_text.data(), id_text.data() + id_text.size(), id);
    if (error != std::errc{} || end != id_text.data() + id_text.size() ||
        std::to_string(id) != id_text || !metadata.IsObject())
      return Status::Fail("ASR tokenizer added token id/object");
    auto token = metadata;
    io::Json number;
    number.type = io::Json::Type::kNumber;
    number.number = id;
    token.object.emplace_back("id", std::move(number));
    if (!AsrTokenMetadata(token, id, alignment))
      return Status::Fail("ASR tokenizer added token semantics differ");
    tokens.array.push_back(std::move(token));
  }
  parse_limits.max_depth = 2;
  parse_limits.max_values = 1 + 2 * std::min(size_t{151643},
                                           limits.max_vocab_size);
  parse_limits.max_string_bytes = std::min(vocab_json.size(),
                                            limits.max_tokenizer_bytes);
  if (auto s = io::ParseJson(std::string(vocab_json), &vocab, false,
                             parse_limits); !s)
    return s;
  if (!vocab.IsObject()) return Status::Fail("ASR vocabulary object");
  constexpr std::string_view kHeader = "#version: 0.2\n";
  if (!merges_text.starts_with(kHeader))
    return Status::Fail("ASR merges version differs");
  const auto string = [](std::string_view value) {
    io::Json result;
    result.type = io::Json::Type::kString;
    result.str = value;
    return result;
  };
  const auto object = [](std::initializer_list<
                           std::pair<std::string, io::Json>> fields) {
    io::Json result;
    result.type = io::Json::Type::kObject;
    result.object = fields;
    return result;
  };
  io::Json merges;
  merges.type = io::Json::Type::kArray;
  for (size_t start = kHeader.size(); start < merges_text.size();) {
    const auto newline = merges_text.find('\n', start);
    const auto end = newline == merges_text.npos ? merges_text.size() : newline;
    if (end == start || merges.array.size() >= limits.max_merges ||
        merges.array.size() >= 151387)
      return Status::Fail("ASR merges empty line/excess entries");
    merges.array.push_back(string(merges_text.substr(start, end - start)));
    start = end + (end < merges_text.size());
  }
  io::Json no;
  no.type = io::Json::Type::kBool;
  io::Json sequence;
  sequence.type = io::Json::Type::kArray;
  sequence.array.push_back(object({
      {"type", string("Split")},
      {"pattern", object({{"Regex", string(kEmbeddingRegex)}})},
      {"behavior", string("Isolated")}, {"invert", no}}));
  sequence.array.push_back(object({{"type", string("ByteLevel")},
                                   {"add_prefix_space", no},
                                   {"use_regex", no}}));
  auto root = object({
      {"version", string("1.0")},
      {"normalizer", object({{"type", string("NFC")}})},
      {"post_processor", io::Json{}}, {"padding", io::Json{}},
      {"truncation", io::Json{}},
      {"pre_tokenizer", object({{"type", string("Sequence")},
                                 {"pretokenizers", std::move(sequence)}})},
      {"decoder", object({{"type", string("ByteLevel")},
                            {"add_prefix_space", no}})}});
  auto model = object({{"type", string("BPE")}});
  model.object.emplace_back("vocab", std::move(vocab));
  model.object.emplace_back("merges", std::move(merges));
  root.object.emplace_back("model", std::move(model));
  root.object.emplace_back("added_tokens", std::move(tokens));
  return LoadDocument(root, limits, out, profile);
}

Status Tokenizer::Encode(std::string_view text,
                         std::vector<std::uint32_t>* out,
                         const EncodeOptions& options) const {
  if (options.stats) *options.stats = {};
  std::string err;
  if (!EncodeImpl(impl_->data, text, out, &err, options) ||
      EncodingCancelled(options, &err)) {
    if (err == "encoding cancelled" || !options.recognize_special_tokens)
      out->clear();
    return Status::Fail(err);
  }
  if (impl_->data.profile == TokenizerProfile::kQwen3Embedding &&
      options.add_special_tokens) {
    if (out->size() >= impl_->data.limits.max_tokens) {
      out->clear();
      return Status::Fail("embedding EOS exceeds max_tokens");
    }
    out->push_back(kEmbeddingEos);
  }
  return Status();
}

Status Tokenizer::Decode(const std::vector<std::uint32_t>& ids,
                         bool skip_special_tokens, std::string* out) const {
  const TokenizerData& data = impl_->data;
  if (ids.size() > data.limits.max_tokens) {
    return Status::Fail("decode input exceeds max_tokens");
  }
  out->clear();
  std::string byte_symbols;
  auto flush = [&]() -> bool {
    std::string bytes;
    bytes.reserve(byte_symbols.size());
    std::size_t offset = 0;
    while (offset < byte_symbols.size()) {
      std::uint32_t cp = 0;
      if (!DecodeUtf8At(byte_symbols, &offset, &cp)) {
        return false;
      }
      const auto decoded = data.byte_decoder.find(cp);
      if (decoded == data.byte_decoder.end()) return false;
      bytes.push_back(static_cast<char>(decoded->second));
    }
    byte_symbols.clear();
    if (out->size() > data.limits.max_input_bytes ||
        bytes.size() > data.limits.max_input_bytes - out->size()) {
      return false;
    }
    out->append(bytes);
    return true;
  };
  for (const std::uint32_t id : ids) {
    if (id < data.id_to_token.size()) {
      const std::string& token = data.id_to_token[id];
      if (byte_symbols.size() >
          data.limits.max_input_bytes - token.size()) {
        return Status::Fail("decoded output exceeds max_input_bytes");
      }
      byte_symbols += token;
      continue;
    }
    const auto added = data.added_by_id.find(id);
    if (added == data.added_by_id.end()) {
      return Status::Fail("token id is outside the vocabulary");
    }
    if (!flush()) {
      return Status::Fail("decoded output exceeds max_input_bytes");
    }
    const AddedToken& token = data.added_tokens[added->second];
    if (!skip_special_tokens || !token.special) {
      if (out->size() > data.limits.max_input_bytes ||
          token.content.size() >
              data.limits.max_input_bytes - out->size()) {
        return Status::Fail("decoded output exceeds max_input_bytes");
      }
      out->append(token.content);
    }
  }
  if (!flush()) {
    return Status::Fail("decoded output exceeds max_input_bytes");
  }
  return Status();
}

Status Tokenizer::EchoByteOffsets(std::string_view source,
                                  const std::vector<std::uint32_t>& ids,
                                  bool normalized,
                                  std::vector<size_t>* offsets,
                                  const EncodeOptions& options) const {
  offsets->clear();
  if (source.size() > impl_->data.limits.max_input_bytes)
    return Status::Fail("echo prompt exceeds tokenizer byte limit");
  std::string decoded;
  auto result = Decode(ids, false, &decoded);
  if (!result) return result;
  UErrorCode status = U_ZERO_ERROR;
  icu::Edits edits;
  std::string normal;
  if (normalized) {
    const auto* nfc = icu::Normalizer2::getNFCInstance(status);
    if (U_FAILURE(status) || !nfc)
      return Status::Fail("echo NFC normalizer unavailable");
    icu::StringByteSink<std::string> sink(&normal);
    nfc->normalizeUTF8(0, icu::StringPiece(source.data(), source.size()), sink,
                       &edits, status);
    if (U_FAILURE(status)) return Status::Fail("echo NFC normalization failed");
  }
  if (decoded != (normalized ? normal : source))
    return Status::Fail("echo tokens do not match the original prompt");
  auto iterator = edits.getFineIterator();
  size_t destination = 0;
  std::vector<size_t> prepared;
  prepared.reserve(ids.size());
  for (size_t i = 0; i < ids.size(); ++i) {
    if (i % 256 == 0 && options.cancelled && options.cancelled())
      return Status::Fail("echo offset mapping cancelled");
    size_t original = destination;
    if (normalized) {
      if (!iterator.findDestinationIndex(static_cast<int32_t>(destination),
                                          status) || U_FAILURE(status))
        return Status::Fail("cannot map echo token to NFC source");
      original = iterator.sourceIndex();
      if (!iterator.hasChange())
        original += destination - iterator.destinationIndex();
    }
    prepared.push_back(original);
    std::string piece;
    result = Decode({ids[i]}, false, &piece);
    if (!result) return result;
    destination += piece.size();
  }
  if (destination != decoded.size())
    return Status::Fail("echo token lengths do not match prompt");
  *offsets = std::move(prepared);
  return Status();
}

std::size_t Tokenizer::BaseVocabSize() const noexcept {
  return impl_->data.id_to_token.size();
}
std::size_t Tokenizer::MergeCount() const noexcept {
  return impl_->data.merges.size();
}
std::size_t Tokenizer::AddedTokenCount() const noexcept {
  return impl_->data.added_tokens.size();
}
std::uint32_t Tokenizer::VocabSize() const noexcept {
  return static_cast<std::uint32_t>(impl_->data.id_to_token.size() +
                                    impl_->data.added_tokens.size());
}

}  // namespace text
}  // namespace q4t

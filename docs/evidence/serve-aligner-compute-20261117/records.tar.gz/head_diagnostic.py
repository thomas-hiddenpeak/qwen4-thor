import os,sys,time,json,subprocess,struct
from pathlib import Path
import numpy as np
root=Path.cwd();a=root/'.q4t-work/serve-audio-aligner-20261117';w=root/'.q4t-work/serve-audio-native-20261117'
sys.path.insert(0,str(root/'tools/native_asr'));from acceptance import digest,defaults
out=a/'head-diagnostic-01/run';out.mkdir(parents=True,exist_ok=False);lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);os.fstat(lease)
plan=json.loads((a/'head-diagnostic-plan.json').read_text());assert plan['limits']['gpu_model_loads']==1 and plan['limits']['cases']==1
start=time.monotonic();result={'status':'RUNNING','plan':plan,'defaults_before':defaults(),'runs':[],'identities':{}}
for p in [a/'compute-build/q4t_aligner_replay',a/'head-diagnostic-case-01.json',root/'tools/native_asr/aligner_reference.py',Path(__file__)]:result['identities'][str(p)]=digest(p)
env=dict(os.environ,PYTHONPATH=str(w/'reference-deps'),PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='8')
commands=[('native',[str(a/'compute-build/q4t_aligner_replay'),str(a/'assets-01'),str(a/'head-diagnostic-case-01.json'),str(out/'native')]),('reference',[str(root/'.q4t-work/refenv/bin/python'),'-B',str(root/'tools/native_asr/aligner_reference.py'),'--assets',str(a/'assets-01'),'--official-source',str(w/'official-src'),'--plan',str(a/'head-diagnostic-case-01.json'),'--output',str(out/'reference')])]
def bf16(path):return (np.fromfile(path,'<u2').astype(np.uint32)<<16).view(np.float32).astype(np.float64)
try:
 for name,cmd in commands:
  step=time.monotonic();record={'name':name,'command':cmd};result['runs'].append(record)
  with (out/(name+'.log')).open('wb') as log:
   try:r=subprocess.run(cmd,env=env,pass_fds=(lease,),stdout=log,stderr=subprocess.STDOUT,timeout=120-(step-start));record['exit']=r.returncode
   finally:record['seconds']=time.monotonic()-step
  assert r.returncode==0,name+' failed'
 p=a/'assets-01/model.safetensors'
 with p.open('rb') as f:
  length=struct.unpack('<Q',f.read(8))[0];header=json.loads(f.read(length));head=header['thinker.lm_head.weight'];first,last=head['data_offsets'];assert head['shape']==[5000,1024] and last-first==10240000
  f.seek(8+length+first);raw=f.read(last-first);assert len(raw)==last-first
 weights=(np.frombuffer(raw,'<u2').astype(np.uint32)<<16).view(np.float32).astype(np.float64).reshape(5000,1024)
 checks=[];details=[]
 for name in ('native','reference'):
  fresh=out/name/'case-0';prior=a/'compute-gpu-01/run'/name/'case-1'
  for fn in ('logits.bf16','encoder.bf16','classes.u32'):
   checks.append({'side':name,'check':'capture_preserves_'+fn,'passed':digest(fresh/fn)==digest(prior/fn)})
  hidden=bf16(fresh/'selected.bf16').reshape(72,1024);saved=bf16(fresh/'logits.bf16').reshape(72,5000)
  exact=hidden@weights.T;absolute=np.abs(hidden)@np.abs(weights).T
  exponent=np.frexp(np.abs(exact))[1];step=np.exp2(np.maximum(exponent-8,-133).astype(np.float64));rounded=np.rint(exact/step)*step
  gamma=(1024*2**-24)/(1-1024*2**-24);bound=step/2+gamma*absolute
  error=np.abs(saved-exact);checks.append({'side':name,'check':'all_head_values_within_BF16_rounding_and_FP32_dot_bound','passed':bool((error<=bound).all()),'values':int(error.size),'max_error':float(error.max()),'max_error_to_bound':float((error/bound).max())})
  # Deliberately corrupt one observed divergent winner to exercise this check.
  damaged=saved.copy();damaged[12,int(saved[12].argmax())]+=1
  checks.append({'side':name,'check':'one_unit_corruption_rejected','passed':not bool((np.abs(damaged-exact)<=bound).all())})
  for slot in (12,41):
   exact_class=int(rounded[slot].argmax());actual_class=int(saved[slot].argmax());checks.append({'side':name,'slot':slot,'check':'independent_rounded_head_argmax','passed':exact_class==actual_class,'expected':exact_class,'actual':actual_class})
   ids=np.argsort(-exact[slot],kind='stable')[:3];details.append({'side':name,'slot':slot,'top_classes':ids.tolist(),'fp64':exact[slot,ids].tolist(),'rounded_bf16':rounded[slot,ids].tolist(),'saved_bf16':saved[slot,ids].tolist()})
 result['checks']=checks;result['details']=details
 result['selected_hidden_relative_l2']=float(np.linalg.norm(bf16(out/'native/case-0/selected.bf16')-bf16(out/'reference/case-0/selected.bf16'))/np.linalg.norm(bf16(out/'reference/case-0/selected.bf16')))
 assert all(c['passed'] for c in checks),'head operand review failed'
 result['status']='PASS_HEAD_OPERAND_REVIEW_PENDING_LEASE'
except Exception as error:result['status']='FAILED';result['error']=str(error)
finally:
 result['seconds']=time.monotonic()-start;result['defaults_after']=defaults();result['defaults_unchanged']=result['defaults_before']==result['defaults_after']
 if not result['defaults_unchanged']:result['status']='FAILED'
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result.get(k) for k in ('status','seconds','error','selected_hidden_relative_l2')}));sys.exit(0 if result['status'].startswith('PASS') else 1)

from pathlib import Path
import re,json,subprocess,hashlib
W=Path(__file__).parent
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
for n in files:
 if not n.endswith(('.cpp','.h')):continue
 diff=subprocess.check_output(['git','diff','--unified=0','--',n],text=True);lines=[]
 for b,c in re.findall(r'^@@.*\+(\d+)(?:,(\d+))? @@',diff,re.M):
  if c!='0':lines+=['--lines='+b+':'+str(int(b)+int(c or '1')-1)]
 if lines:subprocess.run(['clang-format','-i',*lines,n],check=True)
new=[]
for n in files:
 if not n.startswith('tests/') or not n.endswith('.cpp'):continue
 prior=set(re.findall(r'Q4T_TEST\(\s*(\w+)',subprocess.check_output(['git','show','HEAD:'+n],text=True)))
 new += [x for x in re.findall(r'Q4T_TEST\(\s*(\w+)',Path(n).read_text()) if x not in prior]
assert len(new)==18,new
affected=['realtime_composed_input_emits_ga_items_without_duplicate_session','realtime_composed_input_private_transcript_still_drives_context','realtime_composed_input_delete_waiter_preserves_generation_boundary','realtime_composed_input_settings_do_not_rewrite_an_accepted_turn','realtime_composed_input_recovery_preserves_audio_context_and_clock','realtime_session_native_input_wait_freezes_manual_request','realtime_session_native_input_wait_cancel_does_not_execute','realtime_session_native_input_failure_never_uses_stale_turn','realtime_session_native_input_admission_handoff_precedes_next_asr','realtime_session_idle_empty_turn_reaches_actual_chat_planner','realtime_finite_input_interleaves_borrowed_ring_without_replay','realtime_finite_input_owner_rejections_are_atomic','realtime_finite_input_deadline_and_delete_prevent_execution','realtime_mixed_audio_history_stale_part_cannot_update_reused_item','realtime_mixed_audio_history_failure_never_becomes_partial_success','realtime_chat_capabilities_bind_real_storage_and_pending_processors','realtime_chat_capabilities_do_not_require_transcription_backend','realtime_wire_response_references_use_exact_separate_sdk_shape']
assert len(affected)==18
p=W/'mixed-entry-plan-01.json';plan=json.loads(p.read_text());plan.update(new_tests=new,affected_tests=affected,tests=new+affected);p.write_text(json.dumps(plan,indent=2)+'\n')
p=Path('tools/release/required_host_tests.txt');s=p.read_text();p.write_text(s+''.join(n+'\n' for n in new if n not in s))
p=Path('tools/serve_audit/inventory.json');v=json.loads(p.read_text());v['duplex_mixed_entry_20261120']=dict(state='development_targeted_cpu_pending',scope=plan['scope'],tests=new,limits=plan['limits'],default_revision=376)
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
def refresh(x):
 if isinstance(x,dict):
  for k,z in list(x.items()):
   if k in changed and isinstance(z,str) and len(z)==64 and Path(k).is_file():x[k]=hashlib.sha256(Path(k).read_bytes()).hexdigest()
   else:refresh(z)
 elif isinstance(x,list):
  for z in x:refresh(z)
refresh(v);p.write_text(json.dumps(v,indent=2)+'\n')
s=(W/'build_finite_input_01.py').read_text().replace('finite-input-build-01','mixed-entry-build-01').replace('b1207ef300e6d99b1a3d123678eb7976ff8d5bf0ea2db0dc4bee5df317aa0c03','53501b78b0d4c68cd34c3ce14caffed1cb523869526b89741a49e7fdb9673f53').replace('independent finite audio preparation and shared native queue ownership','mixed direct item and request-owned inline audio composition');(W/'build_mixed_entry_01.py').write_text(s)
s=(W/'run_finite_input_cpu_01.py').read_text().replace('finite-input-cpu-01','mixed-entry-cpu-01').replace('finite-input-build-01','mixed-entry-build-01').replace('finite-input-plan-01','mixed-entry-plan-01').replace('len(new)==22','len(new)==36').replace('tests=22','tests=36');(W/'run_mixed_entry_cpu_01.py').write_text(s)
p=Path('docs/STATUS.md');s=p.read_text();at=s.index('\n## 当前实际默认');s=s[:at]+'''
直接混合音频入口已完成成组开发，待针对性验证：item.create按真实
内容索引处理/检索/删除全部音频；response.create临时输入由请求负责
清理，不进入默认上下文。客户端transcript单独限额保存，仅供公开
参考，模型采用实际处理结果；空波形不伪造ASR调用或空闲提示。
冻结18新+18相关CPU和20来源反例/120秒/0GPU；真实业务仍待统一短验。
''' +s[at:];p.write_text(s)
p=Path('docs/log/2026-11-20.md');s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 直接混合音频与单次回答输入接线开发

日期：2026-11-20。

做了什么：item.create组合有限音频原生队列与同一历史，逐段映射真实
转写、检索和删除；response.create把内联音频转为精确generation引用，
请求终态/取消/失败清理临时历史和音频，保留实际借用直到join。固定
OpenAI JS 7.47.0明确用户transcript只供参考，现以独立16MiB总额保存，
仅公开投影回填，不能成为模型文本；空波形不伪造ASR或空闲提示。
冻结18新+18相关CPU/20来源反例/120秒，尚待构建与验证；0GPU，默认
rev376保持。

为什么：单项多段音频与单次回答不能另建不受控生命周期，用户参考
文字也不能替代真实识别。所有音频子项接受后才发布父项，失败回滚
不留下可执行上下文。

下一步：针对CPU与来源验证、必要runtime构建、真实WSS/ASR/TTS、
受影响恢复交付和全部master。
''' +s[i:])
print(json.dumps({'new':len(new),'affected':len(affected),'prepared':True}))

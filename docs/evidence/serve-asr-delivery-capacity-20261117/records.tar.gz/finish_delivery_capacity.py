"""Archive only unreferenced records, preserving live state and all budgets."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from tools.serve_recovery import maintenance, publication, version_registration
from tools.serve_service import package as p

os.umask(0o077)
S = R/'build/service-native-state'
O = W/'capacity-02'
p.require(not O.exists(), 'preserve previous archive')
O.mkdir(mode=0o700)
initial = publication.status(S)
p.require(initial['ready'] and initial['revision'] == 266 and
    initial['current']['manifest_sha256'] == '82e625f293255134244fe8dd2222943a51a604cdc67e583b20ec3ebf5721dee2',
    'default predecessor changed')
status = p.read(W/'maintenance-before-02.json')
p.require(status['publication_revision'] == initial['revision'] and
    status['manifest_sha256'] == initial['current']['manifest_sha256'], 'selection observation changed')
old = p.read(W/'capacity-01/selection.json')
selected = old['selected']
old_result = p.read(W/'capacity-01/result.json')
p.require(old_result['status'] == 'FAILED' and len(old_result['commands']) == 2 and
    all(row['returncode'] == 0 for row in old_result['commands']), 'unexpected predecessor')
receipt = p.read(W/'capacity-01/intents-apply.stdout')
p.require(receipt['status'] == 'RETIRED' and receipt['deleted_files'] == 0 and
    receipt['model_actions'] is False, 'prior archive missing')
p.require({k:v for k,v in old['initial'].items() if k!='request_ids'} ==
    {k:v for k,v in initial.items() if k!='request_ids'} and
    set(old['initial']['request_ids'])-set(initial['request_ids']) == set(selected['intents']) and
    set(initial['request_ids']) <= set(old['initial']['request_ids']), 'unexpected publication change')
prior_delivery = p.read(R/'.q4t-work/serve-native-maintenance-20261117/delivery-01/result.json')
p.require(all(p.sha(S/name) == digest for name,digest in prior_delivery['preserved'].items()),
    'default core/client/outer/profile changed since accepted rev266')
p.require(p.read(S/'version-selection/policy.json')['state']['policy'] == prior_delivery['final_cycle'],
    'default version budget changed since accepted rev266')
p.save(O/'selection.json', dict(selected=selected, initial=initial, prior=old_result,
    intentional_change='Only the four selected request IDs left the active publication intent list'))
def protected():
    return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and
        (f.name == 'ledger.json' or f.relative_to(S).parts[0].startswith(
            ('client-', 'outer-', 'profile-selection', 'version-selection')))}
before = protected(); p.save(O/'protected-before.json', before); rows = []; archives = {'intents':p.read(W/'capacity-01/intents-plan.stdout')}; started = time.monotonic()
def call(label, args):
    p.require(len(rows) < 5 and time.monotonic()-started < 270, 'maintenance budget exhausted')
    argv = list(map(str, [R/'build/q4t', 'service', *args]))
    result = subprocess.run(argv, capture_output=True, text=True, timeout=30)
    (O/(label+'.stdout')).write_text(result.stdout)
    (O/(label+'.stderr')).write_text(result.stderr)
    rows.append(dict(label=label, argv=argv, returncode=result.returncode))
    p.require(result.returncode == 0, 'maintenance failed: '+label)
    value = json.loads(result.stdout)
    p.require(value['model_actions'] is False and protected() == before and publication.status(S) == initial,
              'default, state or budget changed')
    return value
try:
    for kind, ids in selected.items():
        if kind == 'intents':
            continue
        flags = [value for identity in ids for value in ('--select', identity)]
        plan = call(kind+'-plan', ['maintenance-plan', '--state', S, '--kind', kind,
                    *flags, '--output', O/(kind+'-archive')])
        result = call(kind+'-apply', ['maintenance-apply', '--state', S, '--kind', kind,
                    '--plan', plan['plan'], '--plan-sha256', plan['sha256']])
        p.require(result['status'] == 'RETIRED' and result['deleted_files'] == 0,
                  'archive incomplete or destructive')
        archives[kind] = plan
    after = call('final-status', ['maintenance-status', '--state', S])
    p.require(all(after['pools'][k]['used'] == status['pools'][k]['used']-len(ids)
                  for k, ids in selected.items()), 'pool capacity differs')
    p.save(O/'result.json', dict(status='PASS_DELIVERY_CAPACITY_RESERVED', seconds=time.monotonic()-started,
        commands=rows, original_commands=old_result['commands'], archives=archives, protected=before, pools=after['pools'], default_unchanged=True,
        recovery_budget_unchanged=True, deleted_files=0, model_actions=0))
    print(json.dumps(dict(status='PASS_DELIVERY_CAPACITY_RESERVED', commands=len(rows),
                         seconds=time.monotonic()-started)))
except BaseException as error:
    p.save(O/'result.json', dict(status='FAILED', error=repr(error), commands=rows, archives=archives,
                               seconds=time.monotonic()-started))
    raise

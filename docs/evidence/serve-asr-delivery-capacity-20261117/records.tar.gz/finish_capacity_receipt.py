import json
from pathlib import Path
import subprocess
import sys
import time
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]; W = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from tools.serve_service import package as p
from tools.serve_recovery import publication
S = R/'build/service-native-state'; O = W/'capacity-03'; O.mkdir(mode=0o700)
before = p.read(W/'capacity-02/protected-before.json')
initial = p.read(W/'capacity-02/selection.json')['initial']
plan = W/'capacity-02/versions-archive/plan.json'; value = p.read(plan)
for row in value['cycles']:
    assert not (S/'version-registrations'/(row['cycle_id']+'.json')).exists()
    assert p.sha(plan.parent/(row['cycle_id']+'.json')) == row['sha256']
    for checkpoint in row['checkpoints']:
        assert p.sha(plan.parent/('checkpoint-'+checkpoint['name'])) == checkpoint['sha256']
assert all(p.sha(S/name) == digest for name,digest in before.items())
assert publication.status(S) == initial
started = time.monotonic(); rows = []
try:
    operations = [('versions-resume', ['maintenance-apply', '--state', S, '--kind', 'versions',
        '--plan', plan, '--plan-sha256', p.sha(plan)]),
        ('final-status', ['maintenance-status', '--state', S])]
    values = {}
    for name, args in operations:
        argv = list(map(str, [R/'build/q4t', 'service', *args]))
        result = subprocess.run(argv, capture_output=True, text=True, timeout=90)
        (O/(name+'.stdout')).write_text(result.stdout); (O/(name+'.stderr')).write_text(result.stderr)
        rows.append(dict(label=name, argv=argv, returncode=result.returncode))
        assert result.returncode == 0, name
        values[name] = json.loads(result.stdout)
        assert all(p.sha(S/key) == digest for key,digest in before.items())
        assert publication.status(S) == initial
    assert values['versions-resume']['status'] == 'RETIRED'
    assert values['versions-resume']['deleted_files'] == 0
    assert values['versions-resume']['model_actions'] is False
    old = p.read(W/'capacity-01/selection.json')
    assert all(values['final-status']['pools'][k]['used'] ==
        old['pools'][k]['used']-len(ids) for k,ids in old['selected'].items())
    seconds = time.monotonic()-started
    total = seconds+sum(p.read(W/name/'result.json')['seconds'] for name in ('capacity-01', 'capacity-02'))
    assert total < 300
    p.save(O/'result.json', dict(status='PASS_DELIVERY_CAPACITY_RESERVED', commands=rows,
        executed_commands_including_timeout=8, seconds=seconds, cumulative_seconds=total,
        pools=values['final-status']['pools'], preserved=before, original_failures_preserved=True,
        prior_completed_operations_reused=True, default_unchanged=True,
        recovery_budget_unchanged=True, deleted_files=0, model_actions=0))
    print(json.dumps(dict(status='PASS_DELIVERY_CAPACITY_RESERVED', cumulative_seconds=total,
                         executed_commands_including_timeout=8)))
except BaseException as error:
    p.save(O/'result.json', dict(status='FAILED', error=repr(error), commands=rows,
                               seconds=time.monotonic()-started))
    raise

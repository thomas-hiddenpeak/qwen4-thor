"""Explicit native configuration/PCM CPU evidence; no deployment state."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

W = Path(__file__).resolve().parent
R = W.parents[1]
O = R / 'docs/evidence/serve-live-configuration-pcm-cpu-20261121'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
c = read(W / 'configuration-cpu-02/result.json')
p = read(W / 'pcm-cpu-01/result.json')
assert c['status'] == p['status'] == 'PASS'
assert c['tests'] == 9 and p['tests'] == 12
assert c['protected_unchanged'] and p['protected_unchanged']
assert read(W / 'configuration-cpu-01/result.json')['status'] == 'BUILD_FAIL'
assert read(W / 'configuration-inventory-reviewed-02.json')['inventory_current']
files = {}
for folder in ('configuration-plan-01', 'configuration-cpu-01',
               'configuration-cpu-02', 'pcm-plan-01', 'pcm-cpu-01'):
    for path in sorted((W / folder).iterdir()):
        assert path.is_file()
        assert path.suffix in {'.json', '.log', '.txt', '.cpp'}
        files[folder + '/' + path.name] = path
for name in ('configuration_cpu_01.py', 'configuration_cpu_02.py',
             'pcm_cpu_01.py', 'archive_configuration_pcm_01.py',
             'configuration-inventory-before.json',
             'configuration-inventory-reviewed.json',
             'configuration-inventory-reviewed-02.json'):
    files['driver/' + name] = W / name
for name in ('CMakeLists.txt', 'cmake/ChatProtocolIdentity.cmake',
             'cmake/HostTestSources.cmake',
             'include/q4t/server/live_configuration.h',
             'src/server/live_configuration.cpp',
             'tests/server_live_configuration_test.cpp',
             'include/q4t/server/realtime_speech_encoder.h',
             'src/server/realtime_speech_encoder.cpp',
             'tests/server_realtime_speech_encoder_test.cpp',
             'tests/server_realtime_speech_execution_test.cpp'):
    files['source/' + name] = R / name
assert not O.exists()
O.mkdir()
index = {}
with tarfile.open(O / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        raw = path.read_bytes()
        index[name] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), 0o600, 0
        archive.addfile(info, io.BytesIO(raw))
(O / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
result = dict(status='PASS_LIVE_CONFIGURATION_PCM_CPU', configuration_tests=9,
              pcm_tests=12, configuration_cpu_seconds=c['cpu_seconds'],
              pcm_cpu_seconds=p['cpu_seconds'],
              configuration_build_seconds=c['build_seconds'],
              pcm_build_seconds=p['build_seconds'],
              host_binary_sha256=p['binary_sha256'],
              original_build_and_inventory_failures_preserved=True,
              count_and_backend_callbacks='controlled CPU fixtures; native integration pending',
              actual_audio_converter=True, resampler_math_unchanged=True,
              realtime_public_pcm_contract_unchanged=True,
              live_business_accepted=False, default_changed=False,
              new_gpu_starts=0, default_revision=426, master_goal_active=True,
              archive_sha256=sha(O / 'evidence.tar.gz'))
(O / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))

from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-prompt-driver-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
p=read(W/'business-cpu-plan-01.json');r=read(W/'business-cpu-01/result.json');b=read(W/'engine-build-01/result.json');assert r['status']=='PASS' and b['status']=='BUILD_PASS' and b['warnings']==0
files={}
for folder in ('business-cpu-01','engine-build-01'):
 for f in (W/folder).iterdir():
  if f.is_file() and f.name!='previous_q4t':files[str(f.relative_to(W))]=f
for name in ('business-cpu-plan-01.json','prepare_business_cpu.py','archive_business_cpu.py','build_engine_01.py'):files[name]=W/name
for f,h in p['sources'].items():
 assert sha(R/f)==h;files['source/'+f]=R/f
O.mkdir();index={n:dict(bytes=f.stat().st_size,sha256=sha(f)) for n,f in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
a=dict(status='PASS_REALTIME_PROMPT_BUSINESS_DRIVER_CPU',python_tests=6,javascript_syntax_checks=1,seconds=r['seconds'],build=b,proposed_business=p['proposed_business'],actual_business_accepted=False,new_gpu_starts=0,default_revision=356,default_unchanged=True,archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime Prompt 真实业务驱动 CPU

6项Python反例及1项JS语法检查通过，0.296秒/0GPU。真实SDK驱动
使用固定OpenAI 7.47.0/ws 8.21.0和原生TLS；CPU只验证验收器会拒绝
重放、终态或流式篡改、虚构用量、错误答案/来源、缺失实际取消增量、
跨客户错误、模板版本变化和计划扩大，不能当成真实SDK模型业务。

实际候选`f20c3b764137d5511221398c09732c8b32d87490799022fe989340eb2b82a3be`
已构建（332.107秒、零警告）；`f5af36c6`原程序和默认rev356完整保留。

接下来冻结一个模型进程、13次Realtime+2次Chat、2个WSS、最多32次
原生注册/文件HTTP、900秒，同一严格GPU租约。覆盖算术模板版本固定/
单轮覆盖/null、真实项目记录上传、红绿PNG、实际验收记录生成CSV、
两客户Prompt/文件隔离、一次RPM含CSV内部模型步骤、真实工具回填、
模板删除后的快照及输出后取消/新请求。核对实际用量、配额账本和清理。
不做完整性能或全模型质量测试，不能把本准备阶段记为业务已验收。

全部Serve master继续，草稿PR #53保留；能力保持和可回退交付仍需完成。
''')
intro='[Prompt业务驱动CPU通过](evidence/serve-realtime-prompt-driver-cpu-20261120/README.md)：\n6项反例+1项JS语法、0.296秒/0GPU，候选`f20c3b76`零警告构建。\n继续冻结单模型/13 Realtime+2 Chat/2WSS/32原生HTTP/900秒的\n真实业务短验，包含CSV内部模型步骤与一次RPM、真实PNG/文本、\n跨客户模板/文件隔离、版本和工具/取消。默认rev356保持，\n尚无Prompt实际业务资格；全部master继续。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## Prompt真实业务驱动CPU通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：拒绝错误验收证据后再使用实际GPU，不以模拟结果代替业务。\n\n下一步：同租约有界真实SDK业务、能力保持和可回退交付，全部master继续。\n'+t)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['realtime_progress']['prompt_driver_cpu_20261120']=a|dict(evidence='evidence/serve-realtime-prompt-driver-cpu-20261120/README.md');save(p,g)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [Realtime Prompt业务驱动CPU](evidence/serve-realtime-prompt-driver-cpu-20261120/README.md)：候选已构建，真实文件/模板/SDK业务待验。\n')
print(json.dumps(a))

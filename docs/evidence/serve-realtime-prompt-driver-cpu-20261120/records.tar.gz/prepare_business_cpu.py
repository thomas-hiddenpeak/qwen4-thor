from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
files=['tools/serve_realtime/prompt_acceptance.py','tools/serve_realtime/prompt_sdk.mjs','tools/serve_realtime/test_prompt_acceptance.py','.github/workflows/host-checks.yml']
plan=dict(scope='Bounded actual Prompt business driver negative receipt CPU and JS syntax; no model execution. Actor uses pinned official TLS/WSS client; reused transport evidence does not certify new business.',python_tests=6,javascript_syntax_checks=1,maximum_seconds=120,new_gpu_starts=0,sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files},proposed_business=dict(model_starts=1,response_creates=13,chats=2,websockets=2,http_operations=32,seconds=900,actual_primary_and_file_model_usage=True,full_performance_or_model_quality_matrix=False),runtime_build=json.loads((W/'engine-build-01/result.json').read_text()))
p=W/'business-cpu-plan-01.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
intro='Prompt实际推理候选`f20c3b76`已零警告构建（332.107秒），\n原`f5af36c6`和默认rev356身份保持。真实SDK驱动已编写，先冻结\n6项Python反例+1项JS语法/120秒/0GPU；通过后冻结单模型、13次\nRealtime+2次Chat、2WSS/32原生HTTP/900秒，覆盖模板固定/覆盖/\n删除、真实文件/PNG/CSV、跨客户隔离、工具闭环、取消和一次RPM\n实际结算。不做完整性能/质量矩阵；实际资格及可回退交付继续。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Prompt候选构建与真实SDK驱动准备\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：CPU所有权证据不能替代实际模型、文件和跨客户业务；\n新驱动须拒绝伪造终态/用量/来源，再按既定界限实际运行。\n\n下一步：驱动CPU检查、固定来源并持同一严格GPU租约短验，\n然后能力保持和可回退交付，全部master继续。\n'+b)
print(json.dumps(plan['proposed_business']))

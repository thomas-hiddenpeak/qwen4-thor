#!/usr/bin/env python3
"""Bounded acquisition of one explicitly pinned, public ASR checkpoint."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
REV = '5eb144179a02acc5e5ba31e748d22b0cf3e303b0'
SHA = '79d6cbd4c98c7bbffe9db2edac07f56cd6637d0d5944b27f6c2b8353840323ea'
MAX_BYTES = 2_000_000_000
RESERVE = 8 * 1024**3
START = time.monotonic()
DEADLINE = START + 1800
OUT = ROOT / 'assets-01'
REPORT = ROOT / 'asset-acquisition-01.json'
result = {'revision': REV, 'files': [], 'model_actions': 0,
          'limits': {'bytes': MAX_BYTES, 'seconds': 1800,
                     'free_disk_reserve': RESERVE}}


def save():
    REPORT.write_text(json.dumps(result, indent=2) + '\n')


try:
    metadata = json.loads((ROOT / 'Qwen3-ASR-0.6B-metadata.json').read_text())
    assert metadata['sha'] == REV and not metadata['private']
    files = [x for x in metadata['siblings'] if x['rfilename'] != '.gitattributes']
    weights = next(x for x in files if x['rfilename'] == 'model.safetensors')
    assert weights['lfs']['sha256'] == SHA
    expected = sum(x['size'] for x in files)
    assert expected <= MAX_BYTES
    result['expected_bytes'] = expected
    result['free_disk_before'] = shutil.disk_usage(ROOT).free
    assert result['free_disk_before'] - expected >= RESERVE
    OUT.mkdir(mode=0o700)
    for spec in files:
        name = spec['rfilename']
        assert Path(name).name == name
        url = f'https://huggingface.co/Qwen/Qwen3-ASR-0.6B/resolve/{REV}/{name}'
        partial = OUT / (name + '.part')
        sha256 = hashlib.sha256()
        blob = hashlib.sha1(f"blob {spec['size']}\0".encode())
        count = 0
        assert time.monotonic() < DEADLINE
        req = urllib.request.Request(url, headers={'User-Agent': 'q4t-native-asr-asset-qualification'})
        with urllib.request.urlopen(req, timeout=30) as response, partial.open('xb') as f:
            assert response.status == 200
            while True:
                assert time.monotonic() < DEADLINE, 'asset acquisition deadline'
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                assert count <= spec['size'], 'unexpected excess asset bytes'
                assert shutil.disk_usage(ROOT).free - len(chunk) >= RESERVE
                f.write(chunk)
                sha256.update(chunk)
                blob.update(chunk)
            f.flush()
            os.fsync(f.fileno())
        assert count == spec['size'], 'asset truncated'
        digest = sha256.hexdigest()
        if 'lfs' in spec:
            assert digest == spec['lfs']['sha256'], 'LFS SHA256 differs'
        else:
            assert blob.hexdigest() == spec['blobId'], 'Git blob differs'
        destination = OUT / name
        partial.rename(destination)
        destination.chmod(0o444)
        result['files'].append({'name': name, 'bytes': count,
                                'sha256': digest, 'blob_sha1': blob.hexdigest(),
                                'url': url})
        save()
        print(name, count, digest, flush=True)
    result['status'] = 'PASS_ASSET_IDENTITY_ONLY'
except Exception as exc:
    result['status'] = 'FAILED'
    result['error'] = f'{type(exc).__name__}: {exc}'
    raise
finally:
    result['seconds'] = time.monotonic() - START
    result['free_disk_after'] = shutil.disk_usage(ROOT).free
    save()

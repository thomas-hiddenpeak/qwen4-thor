"""Instantiate every catalogued regular native method with its own resource namespace."""
import json, re
from pathlib import Path
root=Path.cwd()
routes=json.loads((root/'tools/serve_audit/inventory.json').read_bytes())['native_routes']
for route in sorted(routes):
    method,path=route.split()
    if method=='OPTIONS':continue
    names={'id':'record_a','version':'1','model':'qwen3.8-flash-next','response_id':'resp_a','credential_id':'cred_a',
           'item_id':'item_a','completion_id':'chatcmpl_a','conversation_id':'conv_a','call_id':'rtc_a',
           'session_id':('live_a' if '/live/' in path else 'cksess_a' if '/chatkit/' in path else 'agent_session_a'),
           'thread_id':'cthr_a' if '/chatkit/' in path else 'thread_a','assistant_id':'asst_a','container_id':'cntr_a',
           'run_id':'evalrun_a' if '/evals/' in path else 'run_a','message_id':'msg_a','consent_id':'cons_a',
           'file_id':'cfile_a' if '/containers/' in path else 'file_a','output_item_id':'outputitem_a',
           'vector_store_id':'vs_a','webhook_endpoint_id':'whe_a'}
    if '/chatkit/attachments/' in path:
        names.update(session_id='cksess_'+'0'*64,file_id='file_'+'0'*32)
    print(method,re.sub(r'\{([^}]+)\}',lambda m:names.get(m[1],m[1].removesuffix('_id')+'_a'),path))

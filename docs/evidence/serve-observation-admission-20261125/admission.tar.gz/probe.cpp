#define main q4t_ingress_program_entry
#include "src/service/ingress_main.cpp"
#undef main
#include <iostream>
#include "q4t/server/client_request.h"
#include "q4t/server/http_connection.h"

int main() {
  using namespace q4t::server;
  GatewayClientPolicy policy;
  std::string token(64, 'a');
  const auto json = R"({"version":1,"gateway_token":")" + token +
      R"(","clients":[{"id":"alpha","max_inflight":1,"max_control_inflight":1,)" +
      R"("max_prompt_tokens":64,"max_output_tokens":16,"max_body_bytes":1024}]})";
  ClientAdmission admission;
  if (!ParseGatewayClientPolicy(json, &policy) || !admission.Configure(std::move(policy))) return 1;
  ClientIdentity id;
  for (std::string method, path; std::cin >> method >> path;) {
    bool ops = false;
    bool allowed = q4t::service::ingress::Route(method, path, &ops);
    HttpRequestHeaders headers;
    headers.client_id="alpha";
    headers.gateway_token=token;
    int status=0;
    ClientLease lease;
    auto classified = ClassifyHttpConnection(method,path);
    if (AdmitClientRequest(method,path,&headers,admission,&lease,&id,&status)) status=200;
    std::string lane="none";
    for(auto [k,n] : {std::pair{ClientLane::kData,"data"},{ClientLane::kControl,"control"},{ClientLane::kCancel,"cancel"},
        {ClientLane::kRealtime,"realtime"},{ClientLane::kSideband,"sideband"},{ClientLane::kTunnelPoll,"tunnel_poll"},{ClientLane::kTunnelResponse,"tunnel_response"}}) {
      if (lease.Holds(id,k)) lane=n;
    }
    std::cout<<method<<" "<<path<<" "<<allowed<<" "<<ops<<" "<<kHttpConnectionClasses[static_cast<size_t>(classified)]<<" "<<status<<" "<<lane<<"\n";
  }
}

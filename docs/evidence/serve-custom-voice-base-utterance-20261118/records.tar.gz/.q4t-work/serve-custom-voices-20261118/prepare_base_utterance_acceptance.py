from pathlib import Path
R=Path.cwd();p=R/'tools/native_tts/base_utterance_acceptance.py';assert not p.exists();s=(R/'tools/native_tts/utterance_acceptance.py').read_text();start=s.index('try:\n    from .acceptance');end=s.index('\n\ndef main():',start)
s=s[:start]+'''if __package__:
    from . import base_acceptance as component
    from . import utterance_acceptance as utterance
    from .speaker_acceptance import pair
else:
    import base_acceptance as component
    import utterance_acceptance as utterance
    from speaker_acceptance import pair

ROOT, defaults, digest = component.ROOT, component.defaults, component.digest
LIMITS = dict(utterance.LIMITS, gpu_speaker_loads=1, speaker_stages=94,
              minimum_free_mib=256, artifact_mib=16)
CONTRACT = dict(utterance.CONTRACT, native_sample_condition=True,
                speaker_cosine=0.99999999, speaker_relative_l2=0.0001,
                speaker_max_abs=0.001, registered_voice_api_qualified=False)
DRIVERS = ('base_utterance_replay.cpp', 'base_utterance_acceptance.py',
           'utterance_acceptance.py', 'base_acceptance.py', 'acceptance.py',
           'speaker_acceptance.py')


def validate_plan(plan):
    assert plan['schema'] == 'q4t-native-base-tts-utterance-v1'
    assert plan['limits'] == LIMITS and plan['contract'] == CONTRACT
    assert len(plan['cases']) == 2
    conditions = []
    samples = set()
    for expected, row in zip(component.CASES, plan['cases']):
        condition = {k: v for k, v in row.items() if k not in
            ('reference_pcm', 'reference_pcm_sha256')}
        conditions.append(condition)
        path = Path(row['reference_pcm'])
        assert path.is_file() and 1280 * 4 <= path.stat().st_size <= 1440000 * 4
        assert path.stat().st_size % 4 == 0
        assert digest(path) == row['reference_pcm_sha256']
        samples.add(row['reference_pcm_sha256'])
    component.validate_plan(dict(schema='q4t-native-base-tts-component-fp32-v1',
        limits=component.LIMITS, thresholds=component.THRESHOLDS,
        cases=conditions, eos_qualified=False, audio_qualified=False))
    assert len(samples) == 2


def validate_native(record):
    assert record['status'] == 'PASS_UTTERANCE_PENDING_CONTENT_CHECK'
    assert record['gpu_model_loads'] == 3 and record['cases'] == 2
    assert record['speaker_stages'] == 94
    assert 4 <= record['frames'] < 320
    assert 0 < record['generation_advances'] <= 48000
    assert 0 < record['codec_advances'] <= 4096
''' +s[end:]
s=s.replace('    args.output.mkdir(parents=True, exist_ok=False)', '''    component_result = json.loads(Path(plan['component_result']).read_text())
    component_lease = json.loads(Path(plan['component_lease']).read_text())
    assert component_result['status'] == 'PASS_COMPONENT_PENDING_LEASE_RECONCILIATION'
    assert len(component_result['comparisons']) == 134
    assert all(row['passed'] for row in component_result['comparisons'])
    assert component_lease['status'] == 'COMPLETED' and component_lease['child_returncode'] == 0
    space = os.statvfs(args.output.parent)
    assert space.f_bavail * space.f_frsize >= 256 * 1024**2
    args.output.mkdir(parents=True, exist_ok=False)''')
s=s.replace("        assert nr['status'] == 'PASS_UTTERANCE_PENDING_CONTENT_CHECK'\n        assert nr['gpu_model_loads'] == nr['cases'] == 2\n        assert 4 <= nr['frames'] < 320\n        assert 0 < nr['generation_advances'] <= 48000\n        assert 0 < nr['codec_advances'] <= 4096\n        prepared = asr_fixture", '''        validate_native(nr)
        result['speaker_comparisons'] = [dict(case=i, **pair(
            args.output / 'native' / f'case-{i}' / 'speaker.f32',
            Path(row['speaker_embedding']), 2048,
            dict(cosine=CONTRACT['speaker_cosine'],
                 relative_l2=CONTRACT['speaker_relative_l2'],
                 max_abs=CONTRACT['speaker_max_abs'])))
            for i, row in enumerate(plan['cases'])]
        assert all(row['passed'] for row in result['speaker_comparisons'])
        prepared = utterance.asr_fixture''')
s=s.replace('for index, case in enumerate(CASES):', "for index, case in enumerate(plan['cases']):").replace('**content_check(', '**utterance.content_check(').replace("result['status'] = 'PASS_UTTERANCE_PENDING_LEASE_RECONCILIATION'", "result['status'] = 'PASS_BASE_UTTERANCE_PENDING_LEASE_RECONCILIATION'")
s=s.replace("        result['artifacts'] =", """        result['artifact_bytes'] = sum(p.stat().st_size for p in args.output.rglob('*') if p.is_file())
        if result['artifact_bytes'] > 16 * 1024**2:
            result.update(status='FAILED', error='artifact storage budget exceeded')
        result['artifacts'] =""")
s=s.replace('import unicodedata\nimport wave\n','')
p.write_text(s)

from pathlib import Path
import subprocess,json,time,hashlib,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'base-utterance-build-01';O.mkdir(exist_ok=False);assert shutil.disk_usage(V).free>256*1024**2
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=R/'tools/native_tts/base_utterance_replay.cpp';x=p.with_suffix('.edit');x.write_bytes(subprocess.run(['clang-format',str(p)],check=True,capture_output=True).stdout);x.replace(p)
prior=json.loads((V/'base-compute-build-01/plan.json').read_text());assert all(sha(R/n)==h for n,h in prior['sources'].items())
objects=[str(V/'base-compute-build-01'/f'{i}.o') for i in range(1,11)]
sources=['tools/native_tts/base_utterance_replay.cpp','src/audio/tts_speaker_layout.cpp','src/audio/tts_speaker_features.cpp','src/audio/tts_speaker_model.cu','src/audio/tts_codec_layout.cpp','src/audio/tts_codec.cu','src/audio/tts_codec_dense.cu','src/audio/tts_codec_conv.cu','src/server/tts_assets.cpp','src/server/tts_upload.cpp','src/server/model_assets.cpp','src/server/grammar_process.cpp','src/server/worker_io_broker.cpp']
headers=['include/q4t/server/tts_assets.h','include/q4t/server/tts_upload.h','include/q4t/server/model_assets.h','include/q4t/server/grammar_process.h','src/server/worker_io_broker.h','src/server/model_assets_protocol.h','src/server/model_asset_io.h','include/q4t/audio/tts_speaker_layout.h','include/q4t/audio/tts_speaker_model.h','include/q4t/audio/tts_speaker_features.h','include/q4t/audio/tts_codec.h','include/q4t/audio/tts_codec_layout.h','src/audio/tts_codec_internal.h']
nv='/usr/local/cuda-13.3/bin/nvcc';commands=[]
for i,n in enumerate(sources):
 o=O/f'{i}.o';objects.append(str(o));commands.append([nv,'-std=c++23','-O3','-arch=sm_110a','-ccbin','g++-14','-Iinclude','-Ithird_party','-DQ4T_TTS_TRACE=1','-Xcompiler=-Wall,-Wextra,-Werror','-c',n,'-o',str(o)])
commands.append([nv,'-arch=sm_110a','-ccbin','g++-14',*objects,'-lcublasLt','-lpthread','-licui18n','-licuuc','-licudata','-o',str(O/'q4t_tts_base_utterance')])
plan=dict(commands=commands,sources={n:sha(R/n) for n in sources+headers},reused_source_hashes=prior['sources'],reused_objects={str(Path(o).relative_to(R)):sha(Path(o)) for o in objects[:10]},gpu_actions=0,model_loads=0);(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic();rows=[]
for i,cmd in enumerate(commands):
 with (O/f'{i}.log').open('wb') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(command=cmd,exit_code=r.returncode))
 if r.returncode:break
result=dict(status='PASS_BUILD_ONLY' if r.returncode==0 else 'FAIL_BUILD',seconds=time.monotonic()-start,steps=rows,warnings=sum(p.read_text().count('warning:') for p in O.glob('*.log')))
if r.returncode==0:result['binary_sha256']=sha(O/'q4t_tts_base_utterance')
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='steps'}));raise SystemExit(r.returncode)

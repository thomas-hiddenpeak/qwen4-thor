from pathlib import Path
R=Path.cwd();p=R/'tools/native_tts/base_utterance_replay.cpp';assert not p.exists();s=(R/'tools/native_tts/utterance_replay.cpp').read_text();s=s.replace('// Bounded full-utterance generation; content checked by independent ASR.','// Native Base asset/voice/synthesis pipeline; full audio checked independently.');s=s.replace('#include "q4t/audio/tts_codec.h"','#include "q4t/audio/tts_codec.h"\n#include "q4t/audio/tts_speaker_features.h"\n#include "q4t/audio/tts_speaker_model.h"\n#include "q4t/server/tts_upload.h"')
start=s.index('  constexpr auto variant =');end=s.index('  size_t total_advances =',start)
s=s[:start]+'''  constexpr auto variant = audio::TtsVariant::kBase17B;
  Require(runtime::ReadSystemMemory().CanAllocate(
              3 * server::kNativeTtsBaseFileBytes + (2ULL << 30)),
          "insufficient unified RAM for Base qualification");
  server::TtsHostAssets assets;
  server::GrammarControl control;
  control.compile_deadline = Clock::now() + std::chrono::seconds(60);
  control.counters = std::make_shared<server::GrammarWorkerCounters>();
  control.cancelled = [&] {
    return Clock::now() - started >= std::chrono::seconds(600);
  };
  server::GrammarFailure failure;
  Check(server::LoadTtsAssets(directory, &assets, control, &failure, true,
                              server::kTtsAssetStagingBytes, {variant, true}));
  Require(assets.variant == variant && assets.speaker_layout.tensors.size() == 76 &&
              control.counters->started == 2 && control.counters->reaped == 2 &&
              control.counters->active == 0,
          "Base verified asset ownership differs");
  Device device_weights(server::kNativeTtsWeightBytes);
  Device codec_weights(audio::TtsConfig::kCodecDecoderBytes);
  Device speaker_weights(audio::TtsSpeakerConfig::kDeviceBytes);
  server::TtsBoundWeights bound;
  Check(server::UploadTtsWeights(assets,
      {static_cast<uint8_t*>(device_weights.value), server::kNativeTtsWeightBytes},
      {static_cast<uint8_t*>(codec_weights.value), audio::TtsConfig::kCodecDecoderBytes},
      &bound, control.cancelled));
  audio::TtsSpeakerDeviceWeights speaker;
  Check(server::UploadTtsSpeakerWeights(assets,
      {static_cast<uint8_t*>(speaker_weights.value), audio::TtsSpeakerConfig::kDeviceBytes},
      &speaker, control.cancelled));
  auto tokenizer = std::move(assets.tokenizer);
  assets = {};  // Release all host source bytes before request workspaces.
  const auto& weights = bound.talker;
  const auto& decoder_weights = bound.codec;
  size_t speaker_stages = 0;
''' +s[end:]
start=s.index('    audio::TtsPrompt prompt;');end=s.index('    Check(audio::ValidateTtsPrompt(prompt));',start)
s=s[:start]+'''    const auto source = ReadFile(item.GetString("reference_pcm"), 1440000 * 4);
    Require(!source.empty() && source.size() % 4 == 0 &&
                trace::HexDigest(trace::Sha256(source)) ==
                    item.GetString("reference_pcm_sha256"),
            "voice sample identity differs");
    std::vector<float> samples(source.size() / 4);
    std::memcpy(samples.data(), source.data(), source.size());
    audio::TtsSpeakerFeatures features;
    Check(audio::ComputeTtsSpeakerFeatures(samples, 24000, {}, &features,
                                           control.cancelled));
    std::vector<float> condition(2048);
    {
      audio::TtsSpeakerWorkspace layout;
      Check(audio::PlanTtsSpeakerWorkspace(features.frames, 5625,
                                            300ULL << 20, &layout));
      Device workspace(layout.bytes);
      audio::TtsSpeakerRun run;
      Check(run.Begin(speaker, features.mel, features.frames, workspace.value,
                       layout.bytes));
      for (int stage = 0; stage < audio::TtsSpeakerRun::kStages; ++stage) {
        checkpoint();
        Require(++speaker_stages <= 94, "speaker stage budget exceeded");
        Check(run.NextStage());
      }
      Check(run.Finish(condition));
    }
    Save<float>(case_output / "speaker.f32", condition);
    audio::TtsPrompt prompt;
    Check(audio::PlanTtsBasePrompt(
        std::vector<int32_t>(text.begin(), text.end()),
        std::vector<int32_t>(instruction.begin(), instruction.end()),
        condition, item.GetString("language"), item.GetBool("non_streaming"),
        512, &prompt));
''' +s[end:]
s=s.replace('<< "\\\"gpu_model_loads\\\":2,\\\"cases\\\":2,\\\"frames\\\":" << total_frames','<< "\\\"gpu_model_loads\\\":3,\\\"speaker_stages\\\":" << speaker_stages\n         << ",\\\"cases\\\":2,\\\"frames\\\":" << total_frames')
s=s.replace('int main(int argc, char** argv) {\n  try {','''int main(int argc, char** argv) {
  const int worker = server::MaybeRunModelAssetWorker(argc, argv);
  if (worker >= 0) return worker;
  try {''').replace('usage: q4t_tts_utterance ASSETS PLAN OUTPUT','usage: q4t_tts_base_utterance ASSETS PLAN OUTPUT')
assert 'gpu_model_loads\\\":3' in s
p.write_text(s)

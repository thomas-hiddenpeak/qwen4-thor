// GPT-2 style Byte-Level BPE tokenizer for q4t.
//
// Decodes the exact tokenizer.json shipped with the target model
// (Qwen3.8-Flash-Next / qwen4_exp): a BPE model with a GPT-2 byte-level
// pre-tokenizer (Regex Split + ByteLevel) and an NFC normalizer. Encoding
// applies NFC normalization, splits on the Unicode pre-tokenize regex (via
// ICU 74), maps each piece through the GPT-2 byte alphabet, and runs ranked
// BPE merges. Decoding reverses the byte-level mapping.
//
// The loader is fail-closed: it rejects schema drift (wrong vocab/merge
// counts, an unexpected pre_tokenizer/decoder/normalizer) instead of
// guessing at a related tokenizer configuration.
#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

#include "q4t/status.h"

namespace q4t {
namespace io {
struct Json;
}
namespace text {

// Distinct, pinned model contracts; never infer a profile from loose schema.
enum class TokenizerProfile {
  kQwen4Exp, kQwen3Embedding, kQwen3Asr, kQwen3Aligner, kQwen3Tts
};

// Resource limits enforced while loading the tokenizer JSON and while
// encoding/decoding caller-controlled text.
struct TokenizerLimits {
  std::size_t max_tokenizer_bytes = 64'000'000;
  std::size_t max_vocab_size = 300'000;
  std::size_t max_merges = 300'000;
  std::size_t max_added_tokens = 256;
  std::size_t max_input_bytes = 4'000'000;
  std::size_t max_tokens = 4'000'000;
};

// Optional per-call work accounting; these are searched spans, not CPU cycles.
struct EncodeStats {
  std::size_t special_searches = 0;
  std::size_t special_search_bytes = 0;
};

struct EncodeOptions {
  // Cooperative checkpoints surround normalization/matching and bound BPE
  // loop work. An individual ICU call or string search is not preempted.
  std::function<bool()> cancelled = {};
  EncodeStats* stats = nullptr;
  // Qwen3 Embedding's trained postprocessor appends EOS. The Qwen4 profile
  // remains raw regardless of this option. Token-ID inputs bypass Encode.
  bool add_special_tokens = true;
  // Caller text inside a trained template must not introduce structural
  // markers. False sends every byte through the ordinary BPE path. This is
  // separate from the profile's optional EOS postprocessor above. Literal
  // mode clears partial tokens on any failure, so no truncated context leaks.
  bool recognize_special_tokens = true;
};

// GPT-2 style Byte-Level BPE tokenizer loaded from tokenizer.json.
//
// Decode reads immutable tables. Encode reuses the ICU regex handle and must
// be serialized by the caller; const this does not make that handle immutable.
class Tokenizer {
 public:
  // Pinned invariants of the target model's tokenizer.json. The loader fails
  // closed unless these hold.
  static constexpr std::size_t kPinnedBaseVocabSize = 248'044;
  static constexpr std::size_t kPinnedMergeCount = 247'587;

  ~Tokenizer();
  Tokenizer(Tokenizer&&) noexcept;
  Tokenizer& operator=(Tokenizer&&) noexcept;
  Tokenizer(const Tokenizer&) = delete;
  Tokenizer& operator=(const Tokenizer&) = delete;

  // Load and validate tokenizer.json from disk. On success *out owns the
  // tokenizer and Status is ok; on failure Status carries a message and *out
  // is left unchanged.
  static Status Load(const std::string& path, const TokenizerLimits& limits,
                     std::unique_ptr<Tokenizer>* out,
                     TokenizerProfile profile = TokenizerProfile::kQwen4Exp);
  // Load and validate from an in-memory JSON document.
  static Status LoadJson(std::string_view json, const TokenizerLimits& limits,
                         std::unique_ptr<Tokenizer>* out,
                         TokenizerProfile profile = TokenizerProfile::kQwen4Exp);

  // The official ASR asset has vocab/merges/config rather than tokenizer.json.
  // Construct its exact pinned BPE contract natively, with no conversion tool
  // or runtime Transformers dependency. No implicit BOS/EOS is inserted.
  static Status LoadQwen3Asr(std::string_view vocab_json,
                            std::string_view merges_text,
                            std::string_view config_json,
                            const TokenizerLimits& limits,
                            std::unique_ptr<Tokenizer>* out);

  // CustomVoice has only 33 added tokens and audio padding at 151675.
  // It must not inherit ASR's 151676 padding or transcription-only tokens.
  static Status LoadQwen3Tts(std::string_view vocab_json,
                            std::string_view merges_text,
                            std::string_view config_json,
                            const TokenizerLimits& limits,
                            std::unique_ptr<Tokenizer>* out);

  // Alignment has one additional, non-special <timestamp> token (151705).
  // Keep it distinct so ASR cannot silently accept an alignment checkpoint.
  static Status LoadQwen3Aligner(std::string_view vocab_json,
                                std::string_view merges_text,
                                std::string_view config_json,
                                const TokenizerLimits& limits,
                                std::unique_ptr<Tokenizer>* out);

  // Encode text into token ids. Added/special tokens are matched as whole
  // strings before the byte-level BPE path, mirroring the reference
  // `tokenizers` behavior.
  // Cancellation clears partial output. Options and statistics are call-local.
  Status Encode(std::string_view text, std::vector<std::uint32_t>* out,
                 const EncodeOptions& options = {}) const;
  // Decode token ids into text. skip_special_tokens drops added tokens whose
  // `special` flag is true (base tokens are never special).
  Status Decode(const std::vector<std::uint32_t>& ids,
                bool skip_special_tokens, std::string* out) const;
  // Map actual token starts back to the original echoed prompt. String inputs
  // use NFC edits; token-ID inputs use exact decoded bytes (no normalization).
  // A token starting inside a normalized cluster maps to that source cluster.
  Status EchoByteOffsets(std::string_view source,
                         const std::vector<std::uint32_t>& ids,
                         bool normalized, std::vector<size_t>* offsets,
                         const EncodeOptions& options = {}) const;

  std::size_t BaseVocabSize() const noexcept;
  std::size_t MergeCount() const noexcept;
  std::size_t AddedTokenCount() const noexcept;
  // Total decodable id space (base + added).
  std::uint32_t VocabSize() const noexcept;

 private:
  static Status LoadQwen3Speech(std::string_view vocab_json,
                               std::string_view merges_text,
                               std::string_view config_json,
                               const TokenizerLimits& limits,
                               std::unique_ptr<Tokenizer>* out,
                               TokenizerProfile profile);
  static Status LoadDocument(const io::Json& root,
                             const TokenizerLimits& limits,
                             std::unique_ptr<Tokenizer>* out,
                             TokenizerProfile profile);
  struct Impl;
  explicit Tokenizer(std::unique_ptr<Impl> impl) noexcept;
  std::unique_ptr<Impl> impl_;
};

}  // namespace text
}  // namespace q4t

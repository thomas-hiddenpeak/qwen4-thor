// Fixed official Qwen3-TTS Base metadata; provenance in tests/fixtures/tts.
#pragma once

#include <string_view>

namespace q4t::audio::tts_detail {
inline constexpr std::string_view kBaseConfig17B = R"json(
{
  "architectures": [
    "Qwen3TTSForConditionalGeneration"
  ],
  "assistant_token_id": 77091,
  "im_end_token_id": 151645,
  "im_start_token_id": 151644,
  "tts_bos_token_id": 151672,
  "tts_eos_token_id": 151673,
  "tts_pad_token_id": 151671,
  "model_type": "qwen3_tts",
  "tokenizer_type": "qwen3_tts_tokenizer_12hz",
  "tts_model_size": "1b7",
  "tts_model_type": "base",
  "speaker_encoder_config": {
    "enc_dim": 2048,
    "sample_rate": 24000
  },
  "talker_config": {
    "attention_bias": false,
    "attention_dropout": 0,
    "code_predictor_config": {
      "_name_or_path": "",
      "add_cross_attention": false,
      "architectures": null,
      "attention_bias": false,
      "attention_dropout": 0,
      "bad_words_ids": null,
      "begin_suppress_tokens": null,
      "bos_token_id": null,
      "chunk_size_feed_forward": 0,
      "cross_attention_hidden_size": null,
      "decoder_start_token_id": null,
      "diversity_penalty": 0.0,
      "do_sample": false,
      "early_stopping": false,
      "encoder_no_repeat_ngram_size": 0,
      "eos_token_id": null,
      "exponential_decay_length_penalty": null,
      "finetuning_task": null,
      "forced_bos_token_id": null,
      "forced_eos_token_id": null,
      "head_dim": 128,
      "hidden_act": "silu",
      "hidden_size": 1024,
      "id2label": {
        "0": "LABEL_0",
        "1": "LABEL_1"
      },
      "initializer_range": 0.02,
      "intermediate_size": 3072,
      "is_decoder": false,
      "is_encoder_decoder": false,
      "label2id": {
        "LABEL_0": 0,
        "LABEL_1": 1
      },
      "layer_types": [
        "full_attention",
        "full_attention",
        "full_attention",
        "full_attention",
        "full_attention"
      ],
      "length_penalty": 1.0,
      "max_length": 20,
      "max_position_embeddings": 65536,
      "max_window_layers": 28,
      "min_length": 0,
      "model_type": "qwen3_tts_talker_code_predictor",
      "no_repeat_ngram_size": 0,
      "num_attention_heads": 16,
      "num_beam_groups": 1,
      "num_beams": 1,
      "num_code_groups": 16,
      "num_hidden_layers": 5,
      "num_key_value_heads": 8,
      "num_return_sequences": 1,
      "output_attentions": false,
      "output_hidden_states": false,
      "output_scores": false,
      "pad_token_id": null,
      "prefix": null,
      "problem_type": null,
      "pruned_heads": {},
      "remove_invalid_values": false,
      "repetition_penalty": 1.0,
      "return_dict": true,
      "return_dict_in_generate": false,
      "rms_norm_eps": 1e-06,
      "rope_scaling": null,
      "rope_theta": 1000000,
      "sep_token_id": null,
      "sliding_window": null,
      "suppress_tokens": null,
      "task_specific_params": null,
      "temperature": 1.0,
      "tf_legacy_loss": false,
      "tie_encoder_decoder": false,
      "tie_word_embeddings": false,
      "tokenizer_class": null,
      "top_k": 50,
      "top_p": 1.0,
      "dtype": null,
      "torchscript": false,
      "typical_p": 1.0,
      "use_bfloat16": false,
      "use_cache": true,
      "use_sliding_window": false,
      "vocab_size": 2048
    },
    "codec_bos_id": 2149,
    "codec_eos_token_id": 2150,
    "codec_think_id": 2154,
    "codec_language_id": {
        "chinese": 2055,
        "english": 2050,
        "german": 2053,
        "italian": 2070,
        "portuguese": 2071,
        "spanish": 2054,
        "japanese": 2058,
        "korean": 2064,
        "french": 2061,
        "russian": 2069
    },
    "codec_nothink_id": 2155,
    "codec_pad_id": 2148,
    "codec_think_bos_id": 2156,
    "codec_think_eos_id": 2157,
    "spk_id": {
    },
    "spk_is_dialect": {
    },
    "head_dim": 128,
    "hidden_act": "silu",
    "hidden_size": 2048,
    "initializer_range": 0.02,
    "intermediate_size": 6144,
    "max_position_embeddings": 32768,
    "model_type": "qwen3_tts_talker",
    "num_attention_heads": 16,
    "num_code_groups": 16,
    "num_hidden_layers": 28,
    "num_key_value_heads": 8,
    "position_id_per_seconds": 13,
    "rms_norm_eps": 1e-06,
    "rope_scaling": {
      "interleaved": true,
      "mrope_section": [
        24,
        20,
        20
      ],
      "rope_type": "default",
      "type": "default"
    },
    "rope_theta": 1000000,
    "sliding_window": null,
    "text_hidden_size": 2048,
    "text_vocab_size": 151936,
    "use_cache": true,
    "use_sliding_window": false,
    "vocab_size": 3072
  },
  "transformers_version": "4.57.3"
}

)json";
}  // namespace q4t::audio::tts_detail

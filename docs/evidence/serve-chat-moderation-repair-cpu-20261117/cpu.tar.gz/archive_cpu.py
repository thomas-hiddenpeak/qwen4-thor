import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
files=[]
for stem in ['build-host-01','build-engine-01','host-cpu-01','source-gate-01','generated-check-01']:
 row=read(W/(stem+'.json'));assert row['exit_code']==0 and row['default_unchanged']
 if stem.startswith('build-'):assert not re.search(r'\bwarning:|\berror:',(W/(stem+'.stdout')).read_text()+(W/(stem+'.stderr')).read_text())
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
assert '10 tests, 10 passed, 0 failed, 0 skipped' in (W/'host-cpu-01.stdout').read_text()
for n in ['required-cpu.txt','run.py','archive_cpu.py']:files.append((W/n,n))
for n in ['src/server/moderation.cpp','tests/server_moderation_test.cpp','tools/serve_protocol/chat_moderation_acceptance.py']:files.append((R/n,n))
out=R/'docs/evidence/serve-chat-moderation-repair-cpu-20261117';out.mkdir()
with tarfile.open(out/'cpu.tar.gz','w:gz') as tar:
 for p,n in files:tar.add(p,arcname=n)
result=dict(status='PASS_CLASSIFIER_DATA_CPU',cpp_cases=10,source_anchors=726,source_negative_controls=7,zero_warning_builds=True,engine_binary_sha256=sha(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t'),source_sha256=sha(R/'src/server/moderation.cpp'),runtime_accepted=False,original_failure_input_unchanged=True,refusal_protection_unchanged=True,default_revision=196,default_unchanged=True,gpu_starts=0,files=len(files),archive_sha256=sha(out/'cpu.tar.gz'),master_complete=False)
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'README.md').write_text('''# 分类任务与引用数据修复CPU接受

2026-11-17，10项直接moderation CPU通过，包括新增的引用记录边界
回归：威胁和注入样本文本原样保留在JSON records，不进入system或
固定任务字段；没有添加工具/放宽512输出限制。原错误/截断、模型
绑定、预算、媒体适用类别和score/block策略保持通过。

隔离host/engine零警告构建、726来源/7负控及生成物一致性通过，
默认rev196保持、0GPU。原26/8中其余未变依赖的结果继续保留。
CPU不证明模型已能完成分类，下一步必须用原失败输入真实补验；
不改阈值、不伪造分数、不把模型拒绝或503当作成功分类。
''')
print(json.dumps(result))

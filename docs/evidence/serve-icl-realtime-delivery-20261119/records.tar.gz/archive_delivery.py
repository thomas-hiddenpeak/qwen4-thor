"""Record stopped ICL/Realtime publication, preserving every original failure."""
from pathlib import Path
import hashlib,json,re,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-01'
O=R/'docs/evidence/serve-icl-realtime-delivery-20261119'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
result=read(D/'result.json');composition=read(W/'publication-composition.json');capacity=read(W/'capacity-01/result.json');ci=read(W/'ci-wiring-01.json');current=result['publication']['current'];release=read(R/'build/service.release.json')
assert result['status']=='PASS_NATIVE_ICL_REALTIME_DELIVERED' and result['publication']['revision']==336
assert result['state']=='STOPPED' and result['new_gpu_starts']==0 and len(result['commands'])==19
assert all(r['returncode']==0 for r in result['commands']) and result['outer']['enabled'] and result['outer']['charged_total']==0
assert current['manifest_sha256']==composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t')==current['engine_binary_sha256'] and sha(R/'build/service.release.json')==current['service_release_sha256']
for n,h in result['preserved'].items():assert sha(R/'build/service-native-state'/n)==h,n
assert capacity['status']=='PASS_DELIVERY_CAPACITY_RESERVED' and capacity['deleted_files']==0 and capacity['default_unchanged'] and capacity['recovery_budget_unchanged']
assert ci['count']==62 and ci['executed']==0 and ci['workflow_sha256']==sha(R/'.github/workflows/host-checks.yml')
assert release['native_reference_icl_targeted_accepted'] and release['native_realtime_transcription_targeted_accepted']
assert not release['voice_listening_and_similarity_accepted'] and release['voice_listening_deferred']
files={}
for d in [D,W/'capacity-01']:
 for p in d.iterdir():
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(W))]=p
for p in (W/'capacity-01').glob('*-archive/*.json'):files[str(p.relative_to(W))]=p
for n in ['archive_delivery.py','deliver_icl_realtime.py','reserve_delivery_capacity.py','maintenance-before-02.json','publication-composition.json','ci-wiring-01.json','ops-package-composition-03.json','prepare_ops_packages_03.py','prepare_ops_packages_03b.py','ops-packages-03.stderr','ops-packages-03b.stderr','delivery-archive-failure-01.json']:
 files[n]=W/n
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ['api_key','gateway_token','shared_secret','private_key','token'] and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for n,p in files.items():
 raw=p.read_bytes();assert not any(s in raw for s in secrets),n;assert b'-----BEGIN '+b'PRIVATE KEY-----' not in raw,n
assert not O.exists();O.mkdir();save(O/'index.json',{n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()})
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
acceptance=dict(status='ACCEPT_NATIVE_ICL_REALTIME_DELIVERY',revision=336,current=current,state='STOPPED',commands=19,seconds=result['seconds'],new_gpu_starts=0,outer_enabled=True,outer_charged_total=0,persistent_rpm=30,persistent_tpm=6000,alpha_output_limit=3457,usage_reset=False,fixture_tpm_not_installed_to_existing_state=True,manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_to_retained_automatic_fault_actually_tested=True,reciprocal_automatic_fault_additionally_injected=False,reciprocal_registration_and_stopped_rollback_verified=True,older_engine_fallback=False,previous_rev326_preserved=True,strict_actual_finalizers_all_passed=True,original_failures_preserved=True,profile_history_and_cooldown_preserved=True,retired_intents_archived=5,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,maintenance_seconds=capacity['seconds'],ci_contracts_discovered=62,ci_local_reexecutions=0,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,full_model_quality=False,performance_claim=False,long_stability_run=False,full_openai_compatibility=False,listening_and_similarity_accepted=False,listening_deferred_by_owner=True,all_master_tasks_active=True)
save(O/'acceptance.json',acceptance)
(O/'README.md').write_text(f'''# 原生参考ICL与Realtime可回退交付 rev336

默认引擎 `{current['engine_binary_sha256']}`，服务包
`{current['manifest_sha256']}`。19项STOPPED发布、实际整根回退与再次
前进通过，{result['seconds']:.3f}秒，0新增GPU；服务保持STOPPED，outer启用
且累计启动0。前驱rev326及恢复入口完整保留。

本次交付参考音频ICL及Realtime转录：真实参考条件进入Speech/Chat，
实时转录支持持续输入、VAD/降噪、历史/删除与处理后波形取回。
[主轻实际资格](../serve-icl-realtime-primary-light-20261119/README.md)和
[Guardian恢复三组](../serve-icl-realtime-managed-recovery-20261119/README.md)
验证同一持久参考跨网关/整包恢复保持，未完成任务中断结算，显式新
会话恢复业务，不自动重放输入。修复后4模型、63HTTP+5Realtime、
595.196秒、554次正常NVML；原ops失败保留，累计5模型/65HTTP+5Realtime。

RPM30、TPM6000、alpha输出3457与已用额度保持；私有验收包中的
TPM60000没有覆盖持久策略。profile历史/冷却、版本周期和outer预算
保持。5旧intent、2旧generation、2旧registration通过维护API可恢复
归档，0删除。回退目标 `{acceptance['manual_root']}` 使用同一已验
引擎和不同保留控制器；实际验证候选→保留自动恢复和STOPPED根
回退，反向完成资格登记，未另注入反向自动故障，也不宣称旧引擎回退。

62项ICL/Realtime恢复合同接入CI，本机只核对名称加载，复用已过CPU
证据；CI结果和主线合入另记。原exact-code失败、声纹一致性失败及
用户延期听感保持，严格浮点边界接受不能替代音色质量。语义VAD、
Realtime对话/Live、提示词音色及其他master缺口继续实现，不把本阶段
交付称为完整OpenAI兼容、全模型质量、性能或长稳通过。
''')
p=R/'docs/STATUS.md';s=p.read_text();intro=f'[rev336参考ICL/Realtime可回退交付](evidence/serve-icl-realtime-delivery-20261119/README.md)\n完成：19项STOPPED检查/{result["seconds"]:.3f}秒，实际整根回退再前进，\n0新增GPU，原配额/用量/恢复历史/预算保持，默认仍STOPPED。62项\n恢复合同接入CI；接着主线合入、语义VAD/对话/Live及全部master。\n原exact-code/声纹失败与用户延期听感保持。\n\n'
rows={'发布':'rev336；服务包 `'+current['manifest_sha256']+'`','Generation':'`'+current['generation_sha256']+'`','引擎':'`'+current['engine_binary_sha256']+'`','引擎发布记录':'`'+current['engine_release_sha256']+'`','Guardian':'`'+release['guardian_sha256']+'`','原生入口':'`'+release['ingress_sha256']+'`','默认容量':'单流、ctx8192、prefill2048、主文本输出256、MTP k=3；inflight8/queue3；TTS 200帧、alpha输出3457/RPM30/TPM6000；参考ICL与Realtime转录','人工整包回退':'保留控制根 `'+acceptance['manual_root']+'`；同已验ICL/Realtime引擎，参考和周期保持；前驱rev326另保留','自动payload回退':'候选→保留控制包 `'+acceptance['automatic_payload']+'` 实际恢复已验；反向登记与STOPPED回退已验，未另注入反向故障；不是旧引擎回退','外部依赖':'原生入口/自监护不要求nginx/systemd；ASR/对齐/VAD/speaker/分离/TTS及参考编码器按部署启用；健康核心与辅助故障隔离；SDK仅客户端/验收依赖'}
for name,value in rows.items():
 s,count=re.subn(r'^\| '+re.escape(name)+r' \| .* \|$',lambda _:f'| {name} | {value} |',s,count=1,flags=re.M);assert count==1,name
p.write_text(s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-19.md';head,body=p.read_text().split('\n',1);p.write_text(head+'\n\n## 参考ICL/Realtime rev336可回退发行\n\n- 日期：2026-11-19。\n- 做了什么：'+intro.replace('(evidence/','(../evidence/')+'- 为什么：已验协议、实际计算和恢复须进入可用发行，不能停在研究候选。\n- 下一步：主线检查合入，继续语义VAD/Realtime对话/Live及全部master；\n  用户延期听感和原失败记录保持。\n'+body)
p=R/'docs/serve-master-goals-v2.json';g=read(p);entry=acceptance|dict(evidence='evidence/serve-icl-realtime-delivery-20261119/README.md')
for task in g['tasks']:
 if task['id'] in ['A01','A02','A10','A12','N06','R06','Q01','Q02']:task['icl_realtime_delivery_20261119']=entry
 if task['id']=='Q02':task['latest_release']=entry;task['remaining_required']=['ICL/Realtime final-head CI and actual main merge','Delivery of every remaining implementation']
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev336 or then-current default; pending host/camera maintenance handoff remains required.'
g['native_tts_progress']['managed']['icl_realtime_delivery']=entry;g['native_tts_progress']['managed']['state']='reference_icl_realtime_delivered_rev336_main_pending';g['native_tts_progress']['managed']['default_changed']=True
g['realtime_progress']['state']='native_transcription_delivered_rev336_conversation_live_semantic_pending';g['realtime_progress']['delivered']=True;g['realtime_progress']['transcription_service_qualified']=True;g['realtime_progress']['full_realtime_api_qualified']=False;g['realtime_progress']['delivery']=entry
g['next_task']='ICL/Realtime final-head CI/main integration; implement semantic VAD, conversation/Live and every remaining A/N/R/Q task. Preserve original failures and owner-deferred listening.'
g['next']='Continue all remaining Serve master implementation, targeted verification and delivery; this reversible publication is not total goal completion.'
save(p,g)
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev336参考ICL/Realtime可回退交付](evidence/serve-icl-realtime-delivery-20261119/README.md)：原生实时转录、持久参考、预算保持与整包回退。\n')
print(json.dumps({k:acceptance[k] for k in ['status','revision','commands','seconds','files']}))

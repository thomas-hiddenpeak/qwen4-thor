"""Source-only operational projection repair; immutable prior evidence preserved."""
import copy, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle, version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent
REPAIR='source/tools/serve_ops/contracts.py'
ROWS=[('service-package-02','2e157f2edecf771139385d404fa68f2805a26e5ceeb427ec2311bb7392c9813b','service-package-03'),
      ('retained-01','e5a0aab81ffba9f0b9d821892ac8347d27a7d11377cd656b6e77c6d97ec94142','retained-02'),
      ('tls-package-01','84aeacf0bf046e5ec5619a1680f78b1a75c3eae7677d4be0fd96e08d437a23ec','tls-package-02')]
CONTROL={'tools/serve_recovery/bundle.py','tools/serve_recovery/profile_evidence.py',
         'tools/serve_recovery/progress.py','tools/serve_service/package.py',
         'tools/serve_ops/contracts.py'}
def main():
 os.umask(0o077)
 p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit source first')
 protected={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
 old=(ROOT/'build/service').resolve(strict=True)
 p.require({n for n in bundle.SOURCES if p.sha(ROOT/n)!=p.sha(old/'source'/n)}==CONTROL,'unreviewed control delta')
 receipts=[]
 for prior,wanted,name in ROWS:
  src=W/prior/'bundle';out=W/name;dest=out/'bundle';p.require(not out.exists() or name=='service-package-03' and (out/'first-preparation-failure.json').is_file(),'preserve prior composition')
  before=bundle.verify(src,wanted);p.require(p.sha(src/REPAIR)!=p.sha(ROOT/'tools/serve_ops/contracts.py'),'missing repair')
  # Only immutable new bundle links are shared. Detach every changed path first.
  if not out.exists():
   out.mkdir(mode=0o700)
   def copy_file(source,target):
    if Path(source)==src/'engine/q4t':os.link(source,target)
    else:shutil.copy2(source,target)
    return target
   shutil.copytree(src,dest,symlinks=True,copy_function=copy_file)
  f=dest/REPAIR;f.unlink();shutil.copyfile(ROOT/'tools/serve_ops/contracts.py',f);f.chmod(0o400)
  value=copy.deepcopy(before);value['files'][REPAIR]=p.sha(f)
  f=dest/'manifest.json';f.unlink();p.save(f,value);f.chmod(0o400);digest=p.sha(f)
  f=dest/'bin/q4t';f.unlink();f.write_bytes(bundle.launcher(digest,value['python']['path']));f.chmod(0o500)
  p.require(bundle.verify(dest,digest)==value and bundle.verify(src,wanted)==before,'immutable package verification failed')
  p.require({n for n,h in value['files'].items() if before['files'][n]!=h}=={REPAIR},'unreviewed package change')
  p.require(value['engine_manifest_sha256']==before['engine_manifest_sha256'],'engine package changed')
  if name!='retained-02':p.require(all(p.sha(dest/'source'/n)==p.sha(ROOT/n) for n in bundle.SOURCES),'current source mismatch')
  receipt=dict(package=str(dest),manifest_sha256=digest,engine_binary_sha256=p.sha(dest/'engine/q4t'),recovery_accepted=False)
  p.save(out/'receipt.json',receipt)
  p.save(out/'review.json',dict(status='OBSERVATION_REPAIR_COMPOSITION_PENDING',prior=dict(package=str(src),manifest_sha256=wanted),candidate=receipt,changed=[REPAIR],total_control_delta_from_default=sorted(CONTROL),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),only_immutable_engine_shared=True,previous_failure_preserved=True,engine_and_qualification_unchanged=True,default_unchanged=True,model_actions=0,driver_sha256=p.sha(Path(__file__))))
  receipts.append(receipt);print(name,digest,flush=True)
 primary,retained,tls=receipts
 permit=version_contract.compatible(version_contract.payload(primary),version_contract.payload(retained));p.require(permit['automatic'],'fallback compatibility changed')
 p.save(W/'ops-package-composition-03.json',dict(status='PREPARED_FOR_ACTUAL_RECOVERY',packages=receipts,compatibility=permit,protected=protected,default_unchanged=True))
 p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
if __name__=='__main__':main()

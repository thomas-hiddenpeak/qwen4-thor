from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;P=W/'main-01';O=R/'docs/evidence/serve-realtime-chat-main-20261120'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
a=read(P/'after.json');head=a['headRefOid'];merge=a['mergeCommit']['oid'];assert a['state']=='MERGED';assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()==merge
assert subprocess.run(['git','merge-base','--is-ancestor',head,merge]).returncode==0
for run in ('44574396311','44574379603'):
 v=read(P/f'ci-{run}.json');assert v['conclusion']=='success' and v['headSha']==head
assert sha(R/'build/q4t')=='f5af36c6c5d7232f9b180be8c9100616d0cfbe73b30f77135cb4b91a12eb609d'
proof=dict(status='PASS_NATIVE_REALTIME_CHAT_MAIN_MERGED',pr=a['url'],head=head,merge=merge,merged_at=a['mergedAt'],ci_runs=[44574396311,44574379603],default_revision=356,default_unchanged=True,new_gpu_starts=0,prompt_development_merged=False,branch_retained_for_unique_prompt_commits_and_uncommitted_integration=True,all_master_tasks_active=True)
save(P/'proof.json',proof)
assert not O.exists();O.mkdir();files={p.name:p for p in P.iterdir() if p.is_file()};files['archive_main_01.py']=Path(__file__);index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
save(O/'acceptance.json',proof|dict(archive_sha256=sha(O/'records.tar.gz')))
(O/'README.md').write_text(f'''# 原生 Realtime 文本／工具服务合入主线

[PR #52]({a['url']}) 已于 {a['mergedAt']} 合并。
两组公开host CI均在实际提交 `{head}` 上通过；
main合并点 `{merge}`。完整检查/合并回执见归档。

包含已验文本与工具会话、主轻资格、Guardian恢复组合及rev356
可回退发行。原TLS回答质量FAIL、NVML环境中断、数值/声纹失败与
延期听感仍保留，不将模型质量错误记为正确。默认程序仍为rev356，
本次仅合入与来源核验，0新增GPU。

后续Prompt注册表、设置组件与会话接线未进入该PR。当前工作分支
有独有提交和未提交开发，继续保留，不删除其证据路径。Prompt、
音频/MCP/追踪/Live及其余master任务继续，总目标仍active。
''')
e='evidence/serve-realtime-chat-main-20261120/README.md'
intro=f'[PR #52已合入主线]({e})：两组最终CI通过，main合并点\n`{merge[:9]}`；已验文本/工具服务与rev356交付入主线，后续\nPrompt开发未混入。默认rev356 STOPPED、原模型质量/环境失败及\n听感待验保持；继续Prompt及全部master，工作分支因独有开发保留。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## PR #52完成检查并合入主线\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：通过后的实际代码合并解除后续开发阻塞，阶段交付与后续\n未验实现保持明确边界。两组CI原件及默认程序SHA已核验。\n\n下一步：继续Prompt完整实现/针对性验证与全部master；不停止总目标。\n'+b)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['native_realtime_chat_main_20261120']=proof|dict(evidence=e);g['native_realtime_chat_delivery_20261120']['main_integration_pending']=False;g['native_realtime_chat_delivery_20261120']['main_merge_commit']=merge
for task in g['tasks']:
 if task['id']=='Q02':
  task['state']='rev356_delivered_pr52_merged_remaining_master_active';task['latest_mainline_merge']=a|dict(evidence=e);task['latest_release']['main_integration_pending']=False;task['latest_release']['main_merge_commit']=merge
save(p,g)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+f'\n- [原生Realtime文本/工具主线合入]({e})：PR #52双CI通过，rev356交付进main；后续master继续。\n')
print(json.dumps(proof))

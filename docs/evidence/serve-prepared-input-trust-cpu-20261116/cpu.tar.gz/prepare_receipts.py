import pathlib,json,tarfile,hashlib,shutil,fcntl,socket,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tools/evalscope'))
from tools.evalscope import gpu_exclusive as guard
from tools.serve_audit.check_inventory import current_surface,INVENTORY
w=pathlib.Path('.q4t-work/serve-native-video-diagnostic-20261116');b=w/'business-01';r=json.loads((b/'result.json').read_text());l=json.loads((b/'lease/exit.json').read_text());c=json.loads((b/'cleanup.json').read_text());qs=[json.loads(x) for x in (b/'lease/nvml-queries.jsonl').read_text().splitlines()];es=[json.loads(x) for x in (b/'lease/events.jsonl').read_text().splitlines()];assert l['status']=='COMPLETED' and all(q['status']=='OK' for q in qs) and not any(x.get('conflicts') for x in es) and not c['remaining'] and c['ports_released']
current=guard.processes();assert all(int(pid) not in current or current[int(pid)]['start_ticks']!=v['start_ticks'] for pid,v in c['owned'].items())
for port in [18186,18187,18188]:
 with socket.socket() as s:s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',port))
with pathlib.Path(l['lock_path']).open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
e=pathlib.Path('docs/evidence/serve-native-video-diagnostic-20261116');e.mkdir()
s=dict(status='DIAGNOSIS_COMPLETE_NOT_BUSINESS_ACCEPTANCE',result=r,diagnosis=json.loads((b/'diagnostic-summary.json').read_text()),lease=l,cleanup=c,nvml_queries=len(qs),nvml_all_ok=True,owned_processes_gone=True,ports_free=True,lock_released=True,default_unchanged=True)
(e/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
files=[p for p in b.iterdir() if p.is_file() and p.name!='mcp-policy.json'];files.extend(p for p in (b/'lease').iterdir() if p.is_file());files.extend(w/x for x in ['gpu-diagnostic-01.json','gpu-diagnostic-01.stdout','gpu-diagnostic-01.stderr','diagnose.py','development-plan.json'])
with tarfile.open(e/'business.tar.gz','w:gz') as ar:
 for p in sorted(files):ar.add(p,arcname=str(p.relative_to(w)))
(e/'README.md').write_text(f'''# 视频拒答三组固定诊断

2026-11-16，同一f35af0fd引擎，1启动/3创建/{r['seconds']:.3f}秒。
三组均正确red→blue：去掉结构化约束；原schema加通用数据/指令
信任说明；带真实历史工具调用和同一说明。原视频与问题未变，说明
没有颜色答案提示，不修改refusal协议。这支持语义适配问题的判断，
不能证明模型所有情境的行为，也不作为无额外客户端说明的业务通过。

工具组复用首次真实read_clip调用和实际VP9字节，新增模型工具发起0
次，明确是历史输入诊断，不冒充新业务工具执行。{len(qs)}项NVML均OK，
无检测到竞争；自有进程身份、端口和锁均已核验释放，默认rev134不变。
下一步将通用说明放入私有原生模型适配，实际原请求不加instructions，
重新验收功能闭环；所有历史失败保持。
''')
w=pathlib.Path('.q4t-work/serve-prepared-input-trust-20261116');cur=current_surface(ROOT);old=json.loads(INVENTORY.read_text())
for key in ['fields','completion_fields','routes','native_routes']:assert set(old[key])==set(cur[key])
assert old['whitelists']==cur['whitelists'];changes=[p for p,h in cur['sources_sha256'].items() if old['sources_sha256'].get(p)!=h];assert changes==['src/server/responses_plan.cpp'],changes
for p in changes:old['sources_sha256'][p]=cur['sources_sha256'][p]
INVENTORY.write_text(json.dumps(old,indent=2,ensure_ascii=False)+'\n')
files=changes+['tests/server_responses_plan_test.cpp','tests/server_responses_files_test.cpp','tests/server_responses_mcp_state_test.cpp','tools/serve_audit/inventory.json']
cpp=json.loads(pathlib.Path('.q4t-work/serve-native-video-followup-20261116/development-plan.json').read_text())['cpu_cpp']+['responses_plan_prepared_data_is_evidence_without_instruction_authority']
f=dict(cpp=cpp,source_hashes={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in files},reused='20 native timing and snapshot CPU tests from unchanged dependency code; fixed official SDK driver CPU from prior phases',gpu_limits={'starts':1,'creates':8,'seconds':900});(w/'freeze-01.json').write_text(json.dumps(f,indent=2)+'\n');(w/'required-01.txt').write_text('\n'.join(cpp)+'\n')
for p in files:
 d=w/'source-01'/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
p=pathlib.Path('docs/STATUS.md');s=p.read_text();marker='## 最近完成的实现和验证\n';p.write_text(s.replace(marker,marker+'''
[帧时长业务](evidence/serve-native-video-intervals-business-failure-20261116/README.md)
仍拒答，未验收；随后[三组固定诊断](evidence/serve-native-video-diagnostic-20261116/README.md)
均答对，指向“来源可信度/指令权威”语义与结构化输出的组合问题。
当前原生适配为真实准备文件/MCP结果加入通用数据说明，保留refusal
协议、原问题/答案、权限和像素；普通文本不添加。5项直接CPU后再
最多1启动/8创建/900秒原业务，默认rev134保持，总目标继续。
''',1))
p=pathlib.Path('docs/log/2026-11-16.md');s=p.read_text();h,rest=s.split('\n\n',1);p.write_text(h+'\n\n'+'''## 固定诊断定位来源信任语义，接入原生适配

- 日期：2026-11-16。帧显示区间补齐后首个原业务仍拒答，失败保留。
  随后同引擎1启动/3创建固定诊断均正确：去schema、保留schema并
  澄清资料与指令权威的区别、实际历史工具输入。诊断不当作业务通过。
- 改动：只对真实准备文件或非空MCP投影添加原生模型说明；来源可
  作为事实材料，不能作为指令，不假称读取缺失内容；客户端原策略
  和refusal保持。普通文本计划不变，不修改原业务问题或期望答案。
- 下一步：5项直接CPU、来源核对，再最多1启动/8创建/900秒原请求
  闭环。前述所有失败仍保留，rev134不变，全部master继续。
- 证据：[固定诊断](../evidence/serve-native-video-diagnostic-20261116/README.md)。

'''+rest)
print({'cpp':len(cpp),'diagnostic_nvml':len(qs)})

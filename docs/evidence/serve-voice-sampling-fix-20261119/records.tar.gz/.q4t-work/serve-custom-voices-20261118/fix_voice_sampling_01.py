from pathlib import Path
import json
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';p=R/'src/server/chat_tts_execution.cpp';s=p.read_text();a='  audio::TtsSampling sampling;\n  sampling.sample = false;';b='  // Use the fixed checkpoint policy for both acoustic code generators.\n  // Forcing greedy here can repeat one sentence without reaching natural EOS.\n  const audio::TtsSampling sampling;';assert s.count(a)==1;s=s.replace(a,b);t=p.with_suffix('.cpp.edit');t.write_text(s);t.replace(p)
required=['tts_voice_language_tokens_and_sampling_defaults_are_not_silent','tts_code_sampling_respects_suppression_penalty_and_top_k','tts_code_sampling_seed_top_p_and_invalid_values','tts_generation_state_eos_and_budget_do_not_return_partial_frames']
plan={'scope':'Use checkpoint-declared sampling in Speech and Chat TTS instead of forced greedy, keep natural EOS and budgets','required':required,'cases':4,'cpu_seconds':60,'gpu':0,'diagnostic':'voice-eos-diagnostic-01','http_continuation':{'starts':1,'posts':18,'seconds':1200,'max_frames':200,'seed':0},'no_full_performance_or_quality_matrix':True,'defaults_unchanged':True}
(V/'voice-sampling-fix-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
update='原句有界诊断已完成：贪心200帧无EOS且只读第一句；checkpoint双层\n采样47帧自然EOS、独立ASR完整两句，31.401秒、严格租约完成。修正\nSpeech/Chat服务强制贪心覆盖，保持原200帧/seed=0及数值计算；\n冻结4项直接CPU/60秒后继续原18POST接口验收，默认保持。\n'
p=R/'docs/STATUS.md';s=p.read_text().replace('# 当前状态（2026-11-18）','# 当前状态（2026-11-19）',1).replace('## 正在推进\n\n','## 正在推进\n\n'+update+'\n',1);t=p.with_suffix('.md.edit');t.write_text(s);t.replace(p)
p=R/'docs/log/2026-11-19.md';assert not p.exists();p.write_text('# 2026-11-19 开发日志\n\n## 2026-11-19：按原句诊断修复语音服务的强制贪心\n\n'+update+'\n为什么：服务忽略了固定generation_config的do_sample，独立新请求\n复现排除了前请求状态污染。下一步针对CPU和原接口清单，保留未结束\n音频/首次HTTP失败，不放宽EOS或帧预算。\n')
p=R/'docs/log/README.md';s=p.read_text();marker='| 日期 |';print(s[:700]);
if '| [2026-11-18]' in s:
 s=s.replace('| [2026-11-18]', '| [2026-11-19](2026-11-19.md) | 音色真实HTTP、生成策略修复与后续收口 |\n| [2026-11-18]',1)
elif '- [2026-11-18]' in s:
 s=s.replace('- [2026-11-18]','- [2026-11-19](2026-11-19.md) — 音色HTTP与生成策略修复\n- [2026-11-18]',1)
else:raise RuntimeError('log index shape')
t=p.with_suffix('.md.edit');t.write_text(s);t.replace(p)

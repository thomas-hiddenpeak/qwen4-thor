from pathlib import Path
import json,hashlib,subprocess,shutil,time,signal,os
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';plan=json.loads((V/'voice-sampling-fix-plan-01.json').read_text());O=V/'voice-sampling-fix-cpu-01';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();H=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';(O/'required.txt').write_text('\n'.join(plan['required'])+'\n')
start=time.monotonic();cmd=[str(H),'--required-list',str(O/'required.txt')];r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60);(O/'tests.log').write_text(r.stdout)
result={'status':'PASS' if r.returncode==0 else 'FAILED','command':cmd,'cases':4,'seconds':time.monotonic()-start,'returncode':r.returncode,'binary_sha256':sha(H),'unchanged_host_binary_reused':True,'gpu':0};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);print(r.stdout,flush=True)
if r.returncode:raise SystemExit(r.returncode)
O=V/'voice-sampling-fix-build-01';O.mkdir(exist_ok=False);B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';before=json.loads((V/'voice-http-03/run/plan.json').read_text())['defaults'];assert shutil.disk_usage(R).free>256<<20
start=time.monotonic();cmd=['cmake','--build',str(B),'--target','q4t','--parallel','4'];reason=None;minimum=shutil.disk_usage(R).free
with (O/'engine.log').open('wb') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  minimum=min(minimum,shutil.disk_usage(R).free)
  if minimum<256<<20 or time.monotonic()-start>600:
   reason='DISK_RESERVE_ABORT' if minimum<256<<20 else 'BUILD_TIMEOUT';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.5)
log=(O/'engine.log').read_text(errors='replace');warnings=[x for x in log.splitlines() if 'warning:' in x]
result={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'warnings':warnings,'abort':reason,'minimum_free_bytes':minimum,'defaults_unchanged':all(sha(R/n)==v for n,v in before.items())}
if p.returncode==0:result['binary_sha256']=sha(B/'q4t')
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if p.returncode or warnings or reason:print(log[-6000:]);raise SystemExit(1)
C=V/'voice-service-candidate-03';C.mkdir(exist_ok=False)
assert shutil.disk_usage(R).free>(256<<20)+(B/'q4t').stat().st_size
for source,target in [('q4t','q4t'),('CMakeCache.txt','CMakeCache.txt'),('generated/q4t/server/chat_protocol_sources.json','chat_protocol_sources.json')]:shutil.copy2(B/source,C/target)
sources=json.loads((C/'chat_protocol_sources.json').read_text());drift=[p for p,h in sources.items() if sha(R/p)!=h];assert not drift
(C/'identity.json').write_text(json.dumps({'engine_sha256':sha(C/'q4t'),'production_source_count':len(sources),'production_source_drift':drift,'runtime_http_qualified':False,'default_replaced':False},indent=2)+'\n');print('candidate',sha(C/'q4t'),flush=True)

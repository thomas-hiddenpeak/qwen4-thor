from pathlib import Path
import hashlib,json,subprocess,time,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-eos-diagnostic-build-01';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
p=R/'tools/native_tts/utterance_replay.cpp';s=p.read_text();original=sha(p)
def rep(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
rep('prompt.prefill.size(), 160,','prompt.prefill.size(), 200,')
rep('generation.Begin(weights, prompt, 160, {.sample = false},\n                           {.sample = false, .repetition_penalty = 1.0f}, 42,','generation.Begin(weights, prompt, 200,\n                           {.sample = item.GetBool("sample")},\n                           {.sample = item.GetBool("sample"), .repetition_penalty = 1.0f}, 0,')
rep('Require(++total_advances <= 48000','Require(++total_advances <= 60000')
rep('    Require(generation.ended() && !generation.at_limit() && codes.size() >= 2 &&\n                codes.size() < 160,\n            "utterance failed to reach natural EOS within frozen budget");','    // Diagnosis preserves partial audio and failed EOS; never acceptance.\n    Require(codes.size() >= 2 && codes.size() <= 200, "diagnostic frame bound");')
rep('    report << "{\\\"frames\\\":" << codes.size() << ",\\\"eos\\\":true,"\n           << "\\\"at_limit\\\":false,\\\"samples\\\":" << pcm.size()','    report << "{\\\"frames\\\":" << codes.size()\n           << ",\\\"eos\\\":" << (generation.ended() ? "true" : "false")\n           << ",\\\"at_limit\\\":" << (generation.at_limit() ? "true" : "false")\n           << ",\\\"samples\\\":" << pcm.size()')
rep('PASS_UTTERANCE_PENDING_CONTENT_CHECK','DIAGNOSTIC_OBSERVATIONS_NOT_ACCEPTANCE')
source=O/'replay.cpp';source.write_text(s)
objects=[];source_hashes={};provenance=[]
for directory,indices in [('base-compute-build-01',range(1,11)),('base-utterance-build-01',range(4,8))]:
 prior=json.loads((V/directory/'plan.json').read_text())
 for name,h in prior['sources'].items():
  if name.startswith(('include/','src/audio/','src/text/','src/quant/','src/io/','src/trace/','src/runtime/')):
   assert sha(R/name)==h,name;source_hashes[name]=h
 for i in indices:
  obj=V/directory/f'{i}.o';assert obj.is_file();objects.append(str(obj));provenance.append({'path':str(obj),'sha256':sha(obj),'source_command':prior['commands'][i]})
assert shutil.disk_usage(R).free>256<<20
nv='/usr/local/cuda-13.3/bin/nvcc';binary=O/'q4t_tts_eos_diagnostic'
commands=[[nv,'-std=c++23','-O3','-arch=sm_110a','-ccbin','g++-14','-Iinclude','-Ithird_party','-DQ4T_TTS_TRACE=1','-Xcompiler=-Wall,-Wextra,-Werror','-c',str(source),'-o',str(O/'replay.o')],[nv,'-arch=sm_110a','-ccbin','g++-14',str(O/'replay.o'),*objects,'-lcublasLt','-lpthread','-licui18n','-licuuc','-licudata','-o',str(binary)]]
plan={'original_replay_sha256':original,'derived_source_sha256':sha(source),'runtime_sources':source_hashes,'reused_objects':provenance,'commands':commands,'gpu':0};(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic();rows=[]
for i,cmd in enumerate(commands):
 with (O/f'{i}.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'command':cmd,'exit_code':r.returncode})
 if r.returncode:break
result={'status':'PASS_BUILD_ONLY' if r.returncode==0 else 'FAILED_BUILD','seconds':time.monotonic()-start,'warnings':sum(p.read_text().count('warning:') for p in O.glob('*.log')),'steps':rows}
if not r.returncode:result['binary_sha256']=sha(binary)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)

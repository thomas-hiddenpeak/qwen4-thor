from pathlib import Path
import hashlib,json,os,sys,subprocess,time,signal,shutil
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_service.package import require,save,sha,read
from tools.native_tts.acceptance import defaults
from tools.native_tts.utterance_acceptance import normalize
from tools.serve_grammar_reap import acceptance as lifecycle
V=R/'.q4t-work/serve-custom-voices-20261118';T=R/'.q4t-work/serve-native-tts-20261118';W=R/'.q4t-work/serve-audio-native-20261117'

def features(plan,out):
 os.environ['USE_TORCH']='0';os.environ['CUDA_VISIBLE_DEVICES']=''
 import numpy as np
 import soxr
 import transformers
 from transformers import Qwen2TokenizerFast,WhisperFeatureExtractor
 require(transformers.__version__=='4.57.6' and soxr.__version__=='0.5.0.post1','reference dependency drift')
 tokenizer=Qwen2TokenizerFast.from_pretrained(W/'assets-01',local_files_only=True)
 extractor=WhisperFeatureExtractor.from_dict(read(W/'assets-01/preprocessor_config.json'))
 template=tokenizer.encode('<|im_start|>system\n<|im_end|>\n<|im_start|>user\n<|audio_start|><|audio_pad|><|audio_end|><|im_end|>\n<|im_start|>assistant\n',add_special_tokens=False)
 require(template.index(151676)==9 and template.count(151676)==1,'ASR template')
 target=out/'features';target.mkdir(exist_ok=False);cases=[]
 for index in range(2):
  source=out/f'native/case-{index}';record=read(source/'result.json');pcm=np.fromfile(source/'pcm.f32','<f4')
  require(pcm.size==record['frames']*1920==record['samples'] and 2<=record['frames']<=200,'partial audio identity')
  require(np.isfinite(pcm).all() and max(abs(pcm))<=1,'PCM nonfinite or clipped')
  data=soxr.resample(pcm,24000,16000,quality='HQ').astype('<f4');frames=data.size//160
  mel=extractor._np_extract_fbank_features(data[None,:],'cpu')[0];require(mel.shape==(128,frames),'mel shape')
  p=target/f'{index}-pcm.f32';data.tofile(p);m=target/f'{index}-mel.f32';mel.astype('<f4').tofile(m)
  tokens=frames//100*13+((frames%100)+7)//8
  cases.append(dict(frames=frames,samples=int(data.size),audio_tokens=tokens,audio_start=9,max_new_tokens=128,tokens=template[:9]+[151676]*tokens+template[10:],pcm=str(p),pcm_sha256=sha(p),mel=str(m),mel_sha256=sha(m)))
 save(target/'plan.json',dict(cases=cases))


def run(plan,out):
 require(plan['schema']=='q4t-tts-eos-diagnostic-v1' and len(plan['cases'])==2,'diagnostic plan shape')
 require(plan['limits']==dict(seconds=1200,main_models=0,http_posts=0,talker_loads=1,codec_loads=1,asr_loads=1,cases=2,frames_per_case=200,seed=0,artifact_mib=64,disk_reserve_mib=256),'budget drift')
 require(plan['cases'][0]==dict(plan['cases'][1],sample=False) and plan['cases'][1]['sample'] is True,'only checkpoint sampling may differ')
 require(plan['cases'][0]['text']==read(V/'voice-http-03/run/fixture-sample.request.body')['input'],'failed request text changed')
 lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);lifecycle.verify_lease(lease,lifecycle.guard.common_lock())
 require(defaults()==plan['defaults'],'default drift')
 for p,h in plan['sources'].items():require(sha(R/p)==h,'source drift '+p)
 for row in plan['binaries'].values():require(sha(row['path'])==row['sha256'],'binary drift')
 out.mkdir(exist_ok=False);started=time.monotonic();result={'status':'FAILED','steps':[]}
 def budget():
  require(time.monotonic()-started<1160,'diagnostic time bound')
  require(shutil.disk_usage(R).free>=256<<20,'disk reserve')
  require(sum(p.stat().st_size for p in out.rglob('*') if p.is_file())<=64<<20,'artifact limit')
 def command(name,args,seconds,env=None):
  budget();begin=time.monotonic()
  with (out/(name+'.log')).open('xb') as log:
   r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,pass_fds=(lease,),env=env,timeout=min(seconds,max(1,1160-(time.monotonic()-started))))
  result['steps'].append(dict(name=name,command=args,returncode=r.returncode,seconds=time.monotonic()-begin));save(out/'progress.json',result)
  require(r.returncode==0,'diagnostic subprocess failed: '+name);budget()
 try:
  command('native',[plan['binaries']['native']['path'],str(T/'assets-1b7-01'),str(Path(sys.argv[1]).absolute()),str(out/'native')],600)
  env=dict(os.environ,PYTHONPATH=str(W/'reference-deps'),PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='')
  command('features',[str(R/'.q4t-work/refenv/bin/python'),'-B',str(Path(__file__).resolve()),str(Path(sys.argv[1]).absolute()),str(out),'features'],60,env)
  command('asr',[plan['binaries']['asr']['path'],str(W/'assets-01'),str(out/'features/plan.json'),str(out/'asr')],300)
  observations=[]
  for i,case in enumerate(plan['cases']):
   generation=read(out/f'native/case-{i}/generation.json');receipt=read(out/f'asr/case-{i}/result.json');raw=(out/f'asr/case-{i}/text.txt').read_text()
   require(receipt['eos'] and 0<receipt['generated_tokens']<=128 and '<asr_text>' in raw,'ASR incomplete')
   text=raw.split('<asr_text>',1)[1]
   observations.append(dict(sample=case['sample'],generation=generation,transcript=text,exact_content=normalize(text)==normalize(case['text'])))
  result.update(status='DIAGNOSTIC_OBSERVED_NOT_HTTP_ACCEPTANCE',observations=observations,
   greedy_failure_reproduced=not observations[0]['generation']['eos'],
   checkpoint_sampling_content_passed=observations[1]['generation']['eos'] and observations[1]['exact_content'])
 finally:
  result.update(seconds=time.monotonic()-started,defaults_unchanged=defaults()==plan['defaults']);save(out/'result.json',result)
  require(result['defaults_unchanged'],'default changed')
 print(json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':
 plan=read(Path(sys.argv[1]));out=Path(sys.argv[2]).absolute()
 if len(sys.argv)==4:features(plan,out)
 else:
  with lifecycle.child_subreaper():run(plan,out)

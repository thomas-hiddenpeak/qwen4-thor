"""Failure cleanup must keep all frontend shutdown ahead of lease release."""
from types import SimpleNamespace
import unittest

from tools.serve_retention import stage


class Driver(unittest.TestCase):
    def test_client_failure_stops_front_before_backend_before_join(self):
        seen=[]
        process=SimpleNamespace(poll=lambda:None,wait=lambda timeout:seen.append('front-exited'))
        fixture=SimpleNamespace(fronts={1:{'process':process}},cleaning=False,
            front_cli=lambda *a:seen.append('front-stop'),stop_backend=lambda:seen.append('backend-stop'))
        with self.assertRaisesRegex(ValueError,'broken client'):
            with stage.Run.concurrent_requests(fixture) as pool:
                self.assertEqual(pool.submit(lambda:1).result(),1)
                raise ValueError('broken client')
        self.assertEqual(seen,['front-stop','front-exited','backend-stop'])
        self.assertTrue(fixture.cleaning)

# SRV-12e 跨运行目录配额与显式私有留存

实际缺口：后端和网关分别有单代次日志轮转，但反复启动创建的新目录
没有总预算、留存和私有日志读取的统一入口。已有诊断 bundle 的保留
工具不覆盖这些运行目录。本批补新受管目录的生命周期，不删除或导入
既有验收原件，不改默认程序、生产包或已经准备的用户 day 计划。

## 合同

`tools/serve_retention/runner.py` 为显式 opt-in 入口，无 timer、恢复
脚本、常驻安装或自动模型重启。`init` 只创建新私有 store；`run` 在
新 generation 中运行已校验包内的 backend 或 gateway 入口，支持当前
后端 v4/托管网关 v2，继续使用原生产 GPU guard 和停止协议。

- store/root/generation 的 UID、权限、随机 store ID 和 inode 绑定；
  仅新建在 build/.q4t-work 内，拒绝 symlink、hardlink、未知对象和
  意外目录。原模型/reference 只读、已有验收目录不归本工具管理。
- 启动前在 store flock 内预占：后端 96MiB、网关 32MiB；默认 256MiB/
  16 个代次，14 天留存策略。活跃或未封存目录始终按完整预占额计账，
  已封存目录按已核验文件字节计账。容量不足先拒绝，绝不静默清理。
- 这是受管代次的启动预算，单代次日志仍由已有轮转器限制；运行中
  四次/秒检查文件量和目录预算，超额或观察失败停止自有入口。
  不把轮询、逻辑文件字节或此 namespace 预算称为文件系统 quota、
  全盘块占用或物理 RAM 硬保护。包、模型、外部缓存及其他任务另计。
- wrapper stdout 2×256KiB；托管原始状态/日志留在 generation/run。
  wrapper 和固定子入口绑定 parent-death，generation flock 传入子入口；
  停止先走固定包内正式 stop，异常只清理自有进程树。失败和清理分开。
- 必须实际 controller/worker/backend/nginx 身份退出、组退出、原终态
  明确 cleanup 后才能封存。wrapper 被杀或终态缺失保持 UNSEALED，
  即使目录很老也不删除。显式 reconcile 只读核验进程后新增封存证明，
  不发送信号、不改写旧状态、不把 FAILED 改为 STOPPED。
- `plan` 保存完整当前库存与待删清单；`prune --plan` 重新核对全库存、
  私有目录/file identity/hash，且仅删除已封存代次。每批最多 2 个。
  先持久化 gc 意图、同目录原子改名，再 descriptor-safe 删除；中断
  后禁止新准入，`resume-prune` 只接受该意图下未改动的剩余文件。
  新增/变更/未知文件留下并拒绝继续，不追认未经授权的删除。
- `tail` 只读已封存私有记录，最多 256KiB，写入 store 之外的新 0600
  文件；不向终端输出日志，不承诺自动脱敏。凭证/原始日志不进 Git。

同 UID/管理员为可信控制面；flock 是合作协议，SHA 是身份而非签名。
源代码是事实来源，未知/异常状态不以目录年龄、PID 文件或记录单独
推断已清理。用户原 vLLM 恢复 unit 保持 masked，不启用任何自动恢复。

## 有界验证

统一 CPU 组覆盖容量/计数/TTL、原件保护、活跃/未知保留、计划变更、
symlink/hardlink、删除中断/篡改后的显式恢复、日志有界私有读取；
实际子进程正常/失败/未知退出、wrapper 死亡和不发信号 reconcile；
核对当前真实 v4/v2 包入口，不启动模型、HTTP 或 GPU。

CPU 通过后另冻结一次真实模型与两个显式网关代次的短验；普通、严格
JSON、真实资料工具/回填、SSE排空和重新接入，停止全部网关后再停
后端，所有 HTTP/清理仍在同一原租约内。验证实际封存、跨代次保留/
私有读取/显式清理与默认/day不变；具体启动/请求/时限在驱动冻结。
不执行小时/天级测试，不用单代次成功外推跨机器部署或长稳。

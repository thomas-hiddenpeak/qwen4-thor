"""Freeze the retention group before running CPU and real process contracts."""
import io
import json
import os
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[2]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT))
from tools.serve_retention import test_retention as test, runner as r

BASE=test.BASE
SOURCES=sorted(set((*r.gateway.SOURCES,
    'tools/serve_retention/store.py','tools/serve_retention/runner.py',
    'tools/serve_retention/exec_managed.py','tools/serve_retention/test_retention.py',
    'tools/serve_retention/cpu.py','docs/SERVE_RETENTION_2026-11-04.md')))


def run():
    os.umask(0o077)
    output=BASE/'cpu-01';output.mkdir(parents=True,mode=0o700)
    sources={name:r.pkg.sha(ROOT/name) for name in SOURCES}
    for name in sources:
        path=output/'source'/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes((ROOT/name).read_bytes())
    log=io.StringIO();result=unittest.TextTestRunner(stream=log,verbosity=2).run(test.suite())
    (output/'tests.log').write_text(log.getvalue())
    value=dict(passed=result.wasSuccessful(),tests_run=result.testsRun,failures=len(result.failures),
        errors=len(result.errors),sources=sources,default={n:r.pkg.sha(ROOT/n) for n in
            ('build/q4t','build/q4t.release.json')},models_started=0,http_started=0,gpu_started=0)
    r.pkg.save(output/'result.json',value);print(log.getvalue(),end='')
    r.require(result.wasSuccessful(),'CPU failed; preserve original and rerun only affected cases')
    return {k:v for k,v in value.items() if k!='sources'}


if __name__=='__main__':print(json.dumps(run()))

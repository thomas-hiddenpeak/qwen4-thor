"""Compose five exact MCP recovery stages, preserving all original failures."""
import json,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import bundle,version_contract,profile_record,profile_evidence
from tools.serve_realtime import mcp_managed
require(not (W/'publication-composition.json').exists(),'preserve prior composition')
group=read(W/'managed-group-03.json');qualification=read(W/'qualified-profiles-02/acceptance.json')
require(qualification['status']=='ACCEPT_MCP_PRIMARY_LIGHT','actual current qualifications required')
roots={k:{n:v[n] for n in ('package','manifest_sha256')} for k,v in group['stages'].items()}
for root in roots.values():
 manifest=bundle.verify(root['package'],root['manifest_sha256'])
 for name in ('primary','light'):
  path=Path(root['package'])/('profile-'+name+'.json')
  profile_evidence.validate(profile_record.read(path),manifest['recovery_profiles'],name,sha(path))
rows=[];accepted={}
for label,stage in group['stages'].items():
 path=Path(stage['output']);plan=read(path/'plan.json');result=read(path/'execution/result.json');guard=read(path/'lease/exit.json')
 events=[json.loads(s) for s in (path/'lease/events.jsonl').read_text().splitlines()]
 queries=[json.loads(s) for s in (path/'lease/nvml-queries.jsonl').read_text().splitlines()]
 require(result['status']=='PASS_BOUNDED_FEATURE_SERVICE' and result['failure'] is None and result['cleanup_failure'] is None and guard['status']=='COMPLETED' and guard['child_returncode']==0 and guard['command']==plan['command'] and guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] is True and queries and all(q['status']=='OK' and q['returncode']==0 and not q['observed_errors'] for q in queries) and not any(e.get('conflicts') for e in events) and events[-1]['event']=='lease_released','actual environment/business differs: '+label)
 require(result['budget']['counts']==read(path/'execution/counts.json')['counts'] and all(result['budget']['counts'][k]==stage['limits'][k] for k in ('starts','chats','websocket_sessions','probes')),'actual stage counts differ')
 stop=read(path/'execution/stopped-ledger.json');require(stop['desired']=='STOPPED' and stop['active']==dict(controller=None,gateway=None,model=None),'owned roles not cleared')
 receipt={k:dict(path=str(path/f),sha256=sha(path/f)) for k,f in [('release','service-release.json'),('decision','decision.json')]}
 version_contract.accepted_fallback(receipt,version_contract.payload(roots[label]))
 decision=read(path/'decision.json');accepted[label]=decision
 require(decision['actual_business']['result_sha256']==sha(path/'execution/result.json'),'finalized result changed')
 observed=mcp_managed.check(path/'execution',plan);quality=read(path/'execution/media-usage.json')
 require(observed==quality['mcp'],'actual MCP observations changed')
 rows.append(dict(label=label,path=str(path),package=roots[label],default_policy=stage['default_policy'],counts={k:result['budget']['counts'][k] for k in ('starts','chats','websocket_sessions','probes')},strict_lease_seconds=decision['actual_business']['strict_lease_seconds'],nvml_queries=len(queries),actual_reads=quality['actual_reads'],authenticated_history=quality['authenticated_history'],model_quality_status=quality['model_quality_status'],quality=quality,result_sha256=sha(path/'execution/result.json'),guard_sha256=sha(path/'lease/exit.json'),acceptance=receipt))
totals={k:sum(row['counts'][k] for row in rows) for k in ('starts','chats','websocket_sessions','probes')}
require(all(totals[k]==group['total'][k] for k in totals),'cumulative frozen model/request budget differs')
bootstrap=W/'managed-configured-retained-01';original=read(bootstrap/'lease/exit.json')
require(original['status']=='COMMAND_FAILED' and all(v==0 for v in read(bootstrap/'execution/counts.json')['counts'].values()) and not (bootstrap/'execution/initialized.json').exists(),'original zero-model failure changed')
events=[json.loads(s) for s in (bootstrap/'lease/events.jsonl').read_text().splitlines()];queries=[json.loads(s) for s in (bootstrap/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and q['returncode']==0 for q in queries) and events[-1]['event']=='lease_released','bootstrap environment differs')
seconds=sum(row['strict_lease_seconds'] for row in rows)+events[-1]['monotonic']-events[0]['monotonic']
version_failed=W/'managed-configured-version-01'
failed=read(version_failed/'execution/result.json');failed_guard=read(version_failed/'lease/exit.json')
require(failed['status']=='FAILED' and failed['cleanup_failure'] is None and failed_guard['status']=='COMMAND_FAILED' and all(failed['budget']['counts'][k]==0 for k in ('starts','chats','websocket_sessions','probes')),'original version failure changed')
failed_events=[json.loads(s) for s in (version_failed/'lease/events.jsonl').read_text().splitlines()]
failed_queries=[json.loads(s) for s in (version_failed/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(failed_events[-1]['event']=='lease_released' and failed_queries and all(q['status']=='OK' and q['returncode']==0 and not q['observed_errors'] for q in failed_queries),'original version environment invalid')
seconds+=failed_events[-1]['monotonic']-failed_events[0]['monotonic']
require(seconds<group['total']['seconds'],'aggregate strict lease budget exceeded')
require(sum(row['actual_reads'] for row in rows)==5 and sum(row['authenticated_history'] for row in rows)==2,'real remote reads/history coverage differs')
prior=R/'.q4t-work/serve-realtime-duplex-20261120/publication-composition.json'
value=dict(status='ACCEPT_NATIVE_REALTIME_MCP_SERVICE_COMPOSITION',candidate=roots['default-version'],automatic_fallback=roots['default-retained'],modern_retained_root=roots['default-retained'],candidate_service_acceptance=accepted['default-version'],modern_service_acceptance=accepted['default-retained'],binary_sha256=accepted['default-version']['engine_binary_sha256'],protocol_sha256='78696063ccaaddf09704dbed2566122fd92824ae0d356057a90e5cb35b6df2c7',stages=rows,counts=totals,actual_model_starts=totals['starts'],service_work_items=totals['chats'],websocket_sessions=totals['websocket_sessions'],device_probes=totals['probes'],service_seconds=seconds,nvml_queries=sum(row['nvml_queries'] for row in rows)+len(queries)+len(failed_queries),nvml_all_ok=True,cleanup_complete=True,actual_reads=5,authenticated_history=2,original_zero_model_failure_preserved=True,original_finalizer_import_order_failure_preserved=True,original_zero_model_version_failure_preserved=True,guardian_repair=dict(source_delta=['src/service/guardian_main.cpp'],cpu_evidence='docs/evidence/serve-mcp-guardian-subtree-cpu-20261120/README.md',fixed_candidate_and_retained_roots=True,configured_version_uses_fixed_root=True,prior_TLS_root_retains_original_identity=True),model_quality_status='FAIL' if any(row['model_quality_status']=='FAIL' for row in rows) else 'PASS',original_profile_model_quality_failures_preserved=True,full_model_quality=False,performance_claim=False,older_engine_fallback=False,default_unchanged=True,publication_pending=True,all_master_tasks_complete=False,
primary_light_evidence=dict(path=str(W/'qualified-profiles-02/acceptance.json'),sha256=sha(W/'qualified-profiles-02/acceptance.json')),
tls_composition=dict(path=str(W/'managed-tls-02/decision.json'),sha256=sha(W/'managed-tls-02/decision.json'),explicit_private_policy=True,not_default_package=True),
configured_policy_composition={label:dict(path=str(Path(group['stages'][label]['output'])/'decision.json'),sha256=sha(Path(group['stages'][label]['output'])/'decision.json')) for label in ('configured-retained','configured-version')},
unchanged_backend_recovery_source=dict(path=str(prior),sha256=sha(prior),scope='Existing source-bound primary/light evidence preserves unchanged voice/duplex/other backend contracts; new MCP recovery and default policy isolation are verified separately. This does not claim another full backend matrix.'),
candidate_whole_package_gpu_run=True,default_policy_unchanged=True,private_test_policy_shipped=False,automatic_request_or_tool_replay=False)
save(W/'publication-composition.json',value)
print(json.dumps({k:value[k] for k in ('status','counts','service_seconds','nvml_queries','model_quality_status')}))

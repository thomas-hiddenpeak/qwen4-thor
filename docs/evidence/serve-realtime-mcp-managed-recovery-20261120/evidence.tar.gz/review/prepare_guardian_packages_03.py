"""Reseal only the fixed Guardian and exact native build receipt."""
from pathlib import Path
import copy,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R));sys.dont_write_bytecode=True;os.umask(0o077)
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as p
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
B=R/'.q4t-work/serve-custom-tools-20261108/engine-build'
built=p.read(W/'guardian-subtree-build-01/result.json')
assert built['status']=='PASS' and built['warnings']==0 and p.sha(B/'q4t-guardian')==built['guardian_sha256']
assert p.read(W/'guardian-subtree-cpu-01/result.json')['status']=='PASS'
assert p.read(W/'version-worker-diagnostic-07/result.json')['status']=='PASS'
protected={n:p.sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')}
rows=[]
changed={'bin/q4t-guardian','native-build.json'}
for source_name,target_name in [('service-package-01','service-package-03'),('retained-01','retained-03'),('configured-package-01','configured-package-03')]:
 source=W/source_name/'bundle';out=W/target_name;assert not out.exists()
 old=bundle.verify(source,p.sha(source/'manifest.json'));native=p.read(source/'native-build.json')
 delta={n for n,h in native['source_files'].items() if p.sha(R/n)!=h}
 assert delta=={'src/service/guardian_main.cpp'} and set(native['source_files'])==bundle.NATIVE_SOURCES
 out.mkdir(mode=0o700);target=out/'bundle'
 def cp(src,dst):
  path=Path(src);name=path.relative_to(source).as_posix()
  if name not in changed|{'manifest.json','bin/q4t'} and path.suffix != '.json' and path.stat().st_mode & 0o222==0:
   os.link(src,dst);return dst
  return shutil.copy2(src,dst)
 shutil.copytree(source,target,symlinks=True,copy_function=cp)
 native['guardian_sha256']=built['guardian_sha256'];native['source_files']['src/service/guardian_main.cpp']=p.sha(R/'src/service/guardian_main.cpp')
 (target/'bin/q4t-guardian').chmod(0o700);shutil.copyfile(B/'q4t-guardian',target/'bin/q4t-guardian');(target/'bin/q4t-guardian').chmod(0o500)
 (target/'native-build.json').chmod(0o600);p.save(target/'native-build.json',native);(target/'native-build.json').chmod(0o400)
 manifest=copy.deepcopy(old)
 for name in changed:manifest['files'][name]=p.sha(target/name)
 (target/'manifest.json').chmod(0o600);p.save(target/'manifest.json',manifest);(target/'manifest.json').chmod(0o400)
 digest=p.sha(target/'manifest.json');(target/'bin/q4t').chmod(0o700)
 (target/'bin/q4t').write_bytes(bundle.launcher(digest,manifest['python']['path']));(target/'bin/q4t').chmod(0o500)
 assert bundle.verify(target,digest)==manifest
 assert {n for n,h in manifest['files'].items() if old['files'][n]!=h}==changed
 row=dict(package=str(target),manifest_sha256=digest,previous=dict(package=str(source),manifest_sha256=p.sha(source/'manifest.json')),changed_files=sorted(changed),native_source_delta=sorted(delta),engine_unchanged=True,profile_qualifications_unchanged=True,default_unchanged=True,actual_business_pending=True)
 p.save(out/'guardian-repair-review.json',row);p.save(out/'receipt.json',dict(package=str(target),manifest_sha256=digest));rows.append(row)
for a,b in [(rows[0],rows[1]),(rows[2],dict(package=str(W/'configured-retained-01/bundle'),manifest_sha256=p.sha(W/'configured-retained-01/bundle/manifest.json')))]:
 left,right=[version_contract.payload({k:v[k] for k in ('package','manifest_sha256')}) for v in (a,b)]
 assert version_contract.compatible(left,right)['automatic']
assert all(p.sha(R/n)==h for n,h in protected.items())
p.save(W/'guardian-repair-packages-03.json',dict(status='SEALED_NATIVE_REPAIR_BUSINESS_PENDING',packages=rows,new_gpu_actions=0,protected=protected))
print(json.dumps([dict(package=v['package'],manifest_sha256=v['manifest_sha256']) for v in rows]))

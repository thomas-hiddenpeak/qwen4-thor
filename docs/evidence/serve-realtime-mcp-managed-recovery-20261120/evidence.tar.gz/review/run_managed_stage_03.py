from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
name=sys.argv[1];group=json.loads((W/'managed-group-03.json').read_text());stage=group['stages'][name]
O=Path(stage['output']);plan=json.loads((O/'plan.json').read_text())
assert plan['limits']==stage['limits'] and plan['package']['manifest_sha256']==stage['manifest_sha256']
assert plan['mcp_recovery']['default_policy']==stage['default_policy']
cmd=[sys.executable,'-B',str(R/'tools/evalscope/gpu_exclusive.py'),'--compute-backend','nvml','--inherit-lease','--output',str(O/'lease'),'--',*plan['command']]
with (O/'guard-stdout.txt').open('xb') as out,(O/'guard-stderr.txt').open('xb') as err:
 result=subprocess.run(cmd,stdout=out,stderr=err,timeout=stage['limits']['seconds']+20)
print(json.dumps(dict(exit_code=result.returncode,stage=str(O))),flush=True)
print((O/'guard-stdout.txt').read_text()[-3500:],flush=True);print((O/'guard-stderr.txt').read_text()[-2000:],flush=True)
if result.returncode:raise SystemExit(result.returncode)
cmd=[sys.executable,'-I','-B',str(R/'tools/serve_realtime/mcp_service_acceptance.py'),'finalize','--plan',str(O/'plan.json')]
result=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
(O/'finalize-stdout.txt').write_text(result.stdout);(O/'finalize-stderr.txt').write_text(result.stderr)
print(result.stdout[-2500:],flush=True);print(result.stderr[-2500:],flush=True)
raise SystemExit(result.returncode)

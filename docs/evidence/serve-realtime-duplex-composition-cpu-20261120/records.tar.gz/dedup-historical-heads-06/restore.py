from pathlib import Path
import hashlib,json,os,shutil,stat
w=Path(__file__).resolve().parent;j=json.loads((w/'plan.json').read_text());rows=j['files'];blob=Path(j['blob'])
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
anchor=Path(rows[0]['path']);source=blob if blob.exists() else anchor
assert sha(source)==j['sha256']
for row in rows[1:]:
 p=Path(row['path']);assert p.is_file() and not p.is_symlink() and sha(p)==row['sha256']
 if p.stat().st_ino==source.stat().st_ino:
  tmp=p.with_name(p.name+'.q4t-independent-restore');assert not tmp.exists()
  shutil.copyfile(source,tmp);assert sha(tmp)==row['sha256']
  os.chmod(tmp,row['mode']);os.utime(tmp,ns=(row['atime_ns'],row['mtime_ns']))
  with tmp.open('rb') as f:os.fsync(f.fileno())
  os.replace(tmp,p)
 assert p.stat().st_nlink==1 and stat.S_IMODE(p.stat().st_mode)==row['mode'] and p.stat().st_mtime_ns==row['mtime_ns']
assert sha(anchor)==j['sha256']
if blob.exists():
 assert anchor.stat().st_ino==blob.stat().st_ino and anchor.stat().st_nlink==2
 blob.unlink()
assert anchor.stat().st_nlink==1
os.chmod(anchor,rows[0]['mode']);os.utime(anchor,ns=(rows[0]['atime_ns'],rows[0]['mtime_ns']))
(w/'restored.json').write_text(json.dumps({'status':'RESTORED_INDEPENDENT_ORIGINAL_HEAD_FILES','paths':len(rows),'sha256':j['sha256']},indent=2)+'\n')
print('Restored independent original paths, modes, times and exact content')

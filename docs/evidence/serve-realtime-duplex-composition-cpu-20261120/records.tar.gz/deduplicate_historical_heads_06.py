"""Exact historical delivery heads only; keep every path and reversible metadata."""
from pathlib import Path
import hashlib,json,os,shutil,stat
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent
O=W/'dedup-historical-heads-06';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def save(p,v):
 with p.open('w') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def syncdir(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
rows=json.loads((W/'historical-heads-06.json').read_text());assert len(rows)==14
expected='21522eabb4ab4f816d9f76eefe317a17e7ba668ebe838809eb4be87d84ef75c1'
assert len({(x['device'],x['bytes'],x['sha256'],x['mode'],x['uid'],x['gid'],x['mtime_ns']) for x in rows})==1
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json','.q4t-work/serve-custom-tools-20261108/engine-build/q4t','.q4t-work/serve-file-search-20261112/host/q4t_host_tests']}
inodes=set()
for row in rows:
 p=Path(row['path']);s=p.lstat();assert p.is_relative_to(R/'.q4t-work') and not p.is_symlink() and stat.S_ISREG(s.st_mode) and s.st_nlink==1
 assert (s.st_dev,s.st_ino,s.st_size,stat.S_IMODE(s.st_mode),s.st_mtime_ns)==(row['device'],row['inode'],row['bytes'],row['mode'],row['mtime_ns']) and sha(p)==expected
 assert str(p) not in protected
 inodes.add((s.st_dev,s.st_ino))
unreadable=[]
for proc in Path('/proc').glob('[0-9]*'):
 for fd in [proc/'exe',*(proc/'fd').glob('*')]:
  try:s=fd.stat();assert (s.st_dev,s.st_ino) not in inodes,str(fd)
  except (PermissionError,FileNotFoundError,ProcessLookupError):pass
 try:
  for line in (proc/'maps').read_text().splitlines():
   fields=line.split();major,minor=(int(x,16) for x in fields[3].split(':'))
   assert (os.makedev(major,minor),int(fields[4])) not in inodes,str(proc)
 except PermissionError:unreadable.append(proc.name)
 except (FileNotFoundError,ProcessLookupError):pass
blob=O/'head.bf16';free=shutil.disk_usage(R).free
plan=dict(scope=__doc__,files=rows,blob=str(blob),sha256=expected,protected=protected,free_before=free,unreadable_process_maps=unreadable,mode_after=0o444,restore='restore.py',operations=[])
save(O/'plan.json',plan)
(O/'restore.py').write_text('''from pathlib import Path
import hashlib,json,os,shutil,stat
w=Path(__file__).resolve().parent;j=json.loads((w/'plan.json').read_text());rows=j['files'];blob=Path(j['blob'])
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
anchor=Path(rows[0]['path']);source=blob if blob.exists() else anchor
assert sha(source)==j['sha256']
for row in rows[1:]:
 p=Path(row['path']);assert p.is_file() and not p.is_symlink() and sha(p)==row['sha256']
 if p.stat().st_ino==source.stat().st_ino:
  tmp=p.with_name(p.name+'.q4t-independent-restore');assert not tmp.exists()
  shutil.copyfile(source,tmp);assert sha(tmp)==row['sha256']
  os.chmod(tmp,row['mode']);os.utime(tmp,ns=(row['atime_ns'],row['mtime_ns']))
  with tmp.open('rb') as f:os.fsync(f.fileno())
  os.replace(tmp,p)
 assert p.stat().st_nlink==1 and stat.S_IMODE(p.stat().st_mode)==row['mode'] and p.stat().st_mtime_ns==row['mtime_ns']
assert sha(anchor)==j['sha256']
if blob.exists():
 assert anchor.stat().st_ino==blob.stat().st_ino and anchor.stat().st_nlink==2
 blob.unlink()
assert anchor.stat().st_nlink==1
os.chmod(anchor,rows[0]['mode']);os.utime(anchor,ns=(rows[0]['atime_ns'],rows[0]['mtime_ns']))
(w/'restored.json').write_text(json.dumps({'status':'RESTORED_INDEPENDENT_ORIGINAL_HEAD_FILES','paths':len(rows),'sha256':j['sha256']},indent=2)+'\\n')
print('Restored independent original paths, modes, times and exact content')
''')
os.link(rows[0]['path'],blob);os.chmod(blob,0o444);syncdir(O)
for row in rows[1:]:
 p=Path(row['path']);s=p.lstat();assert s.st_ino==row['inode'] and s.st_nlink==1 and sha(p)==expected
 tmp=p.with_name(p.name+'.q4t-dedup-link');assert not tmp.exists()
 os.link(blob,tmp);os.replace(tmp,p);syncdir(p.parent)
 assert p.stat().st_ino==blob.stat().st_ino and sha(p)==expected
 plan['operations'].append(dict(path=str(p),status='EXACT_READONLY_LINKED'))
 save(O/'plan.json',plan)
# Exercise one real independent restoration and re-sharing, including metadata.
row=rows[-1];p=Path(row['path']);tmp=p.with_name(p.name+'.q4t-roundtrip')
assert not tmp.exists();shutil.copyfile(blob,tmp);assert sha(tmp)==expected
os.chmod(tmp,row['mode']);os.utime(tmp,ns=(row['atime_ns'],row['mtime_ns']))
with tmp.open('rb') as f:os.fsync(f.fileno())
os.replace(tmp,p);syncdir(p.parent)
assert p.stat().st_nlink==1 and stat.S_IMODE(p.stat().st_mode)==row['mode'] and p.stat().st_mtime_ns==row['mtime_ns'] and sha(p)==expected
os.link(blob,tmp);os.replace(tmp,p);syncdir(p.parent)
assert all(sha(Path(row['path']))==expected and Path(row['path']).stat().st_ino==blob.stat().st_ino and stat.S_IMODE(Path(row['path']).stat().st_mode)==0o444 for row in rows)
assert all(sha(n)==h for n,h in protected.items())
result=dict(status='EXACT_HISTORICAL_HEADS_SHARED_READONLY',paths=len(rows),content_sha256=expected,original_paths_and_bytes_preserved=True,permissions_changed_to_readonly=True,shared_links=blob.stat().st_nlink,duplicate_allocated_bytes_released=sum(row['blocks']*512 for row in rows[1:]),free_before=free,free_after=shutil.disk_usage(R).free,actual_independent_restore_and_rededup_path=rows[-1]['path'],original_metadata_in_plan=True,protected_unchanged=True,models_and_reference_untouched=True,gpu_actions=0,restore=str(O/'restore.py'))
save(O/'result.json',result);print(json.dumps(result))

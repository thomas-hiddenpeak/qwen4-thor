from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;B=W/'cancel-usage-business-01';O=R/'docs/evidence/serve-realtime-duplex-cancel-usage-http-20261120';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
a=read(B/'acceptance.json');assert a['status']=='PASS_LIGHT_AUDIO_CANCEL_USAGE' and a['environment']['cleanup_complete']
plan=read(B/'plan.json');assert all(sha(R/n)==h for n,h in {**plan['sources'],**plan['protected']}.items())
raw=read(B/'light-duplex-barge_in.sdk.json');response=raw['responses'][0]['response'];assert response['status']=='cancelled'
review=dict(acceptance=a,binary_sha256=plan['binary_sha256'],protocol_sha256=plan['identity']['protocol_sha256'],usage=response['usage'],observations=read(B/'observations.json'),postflight_original_failure=read(B/'postflight-original-failure.json'),master_active=True);save(O/'review.json',review)
rows=[];omitted=[];token=read(B/'client-policy.json')['gateway_token'].encode()
paths=[f for f in B.iterdir() if f.is_file() and f.name!='client-policy.json']+[f for f in (B/'lease').iterdir() if f.is_file()]+[W/'cancel_usage_business_01.py',W/'finalize_cancel_usage_02.py',Path(__file__)]
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for f in paths:
  if token in f.read_bytes():omitted.append(dict(path=str(f.relative_to(W)),sha256=sha(f)));continue
  n=str(f.relative_to(W));tar.add(f,arcname=n,recursive=False);rows.append(dict(path=n,bytes=f.stat().st_size,sha256=sha(f)))
save(O/'index.json',dict(records=rows,omitted=omitted,archive_sha256=sha(O/'records.tar.gz')))
(O/'README.md').write_text('''# 实际语音取消用量分类修复通过

2026-11-20，候选ecd6cc23。同一严格租约1轻量模型、1官方WSS、2原生
工作、67.303秒，65次NVML正常。首个实际PCM块后送入用户录音，VAD
将默认回答取消，ASR完整识别中文；没有自动重放或额外回答。

取消终态输出436 tokens分为文字100、音频336；输入225，总661。
另有原生ASR76 tokens，总737准确结算，预留/会话/内存归零。模型
退出0，所属进程/端口/锁释放。原候选及默认rev376保持STOPPED。

原在线驱动和严格guard均通过；postflight误用了要求两模型的旧
环境函数，因此单模型清理被拒绝。原错误记录保留，改由独立有界
离线核对确切一次模型清理、NVML、端口、锁、身份和实际结算，没有
再启动GPU或伪造第二份清理记录。最终验收通过，尚未颁主轻资格或
发布为默认；原模型质量失败也没有被追认为成功。

继续将主档、轻量已通过的双向行为和这份取消修复证据按源码依赖
组合，封装原生恢复包并执行受影响Guardian/入口恢复与可回退交付。
不重跑未改变的后端/全模型矩阵，全部master保持active。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认');p.write_text(s[:i]+'''
[取消分类实际补验通过](evidence/serve-realtime-duplex-cancel-usage-http-20261120/README.md)：
候选ecd6cc23，1轻量模型/1WSS/2工作/67.303秒，65NVML正常、清理通过。
真实音频VAD取消后保留文字100/音频336/输出436，含输入及ASR共737
准确结算。旧postflight误要求两模型的错误保留，单模型离线核实通过，
没有重跑GPU。接着组合主轻资格、原生恢复包、恢复短验和可回退交付；
默认rev376未替换，原质量失败保持，全部master继续。
''' +s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 真实语音取消分类、结算和清理通过

日期：2026-11-20。

做了什么：ecd6cc23实际1模型/1WSS/2工作/67.303秒，65NVML正常。
VAD取消后文字100/音频336/总输出436均保留；输入和ASR合计737准确
结算且资源释放。在线PASS；postflight旧函数要求两模型的原错误保留，
单模型离线身份/监控/清理核实通过，没有追加GPU掩盖工具失败。

为什么：按真实计量修复生产分类，而非把总量正确等同明细完整。
不改模型、采样与原配额结算，不追认此前模型错答为成功。

下一步：主轻证据按依赖组合、原生恢复包、受影响恢复及可回退交付，
继续全部master，默认rev376保持STOPPED。
''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['realtime_progress']['duplex_input_20261120'].update(state='cancel_usage_actual_pass_profile_composition_and_recovery_pending',cancel_usage_business=dict(evidence=str(O.relative_to(R)/'README.md'),result=review));save(p,v)
print(json.dumps(dict(archive=str(O),bytes=(O/'records.tar.gz').stat().st_size)))

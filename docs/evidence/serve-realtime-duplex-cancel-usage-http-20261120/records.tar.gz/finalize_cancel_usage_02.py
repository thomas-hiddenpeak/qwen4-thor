"""Offline one-model postflight; retain the original two-model-helper failure."""
from pathlib import Path
import fcntl,json,runpy,sys
W=Path(__file__).parent;R=W.parents[1];sys.path.insert(0,str(R))
p=runpy.run_path(str(W/'cancel_usage_business_01.py'));read,save,sha,require=[p[k] for k in ('read','save','sha','require')]
B=W/'cancel-usage-business-01';plan=read(B/'plan.json');result=read(B/'result.json');p['check_plan'](plan)
require(result['status']==p['SUCCESS'] and 0<result['seconds']<=420 and
 all(result['counts'][k]==p['LIMITS'][k] for k in p['LIMITS'] if k not in ('seconds','controls')) and
 result['counts']['controls']<=400,'actual bounded work differs')
for n,h in {**plan['sources'],**plan['protected'],**plan['native_assets']}.items():require(sha(R/n)==h,'postflight drift: '+n)
require(sha(plan['binary'])==plan['binary_sha256'],'binary drift')
p['full'].bundle.check_assets(plan['model'],plan['model_assets'])
lease=B/'lease';exit=read(lease/'exit.json');queries=[json.loads(l) for l in (lease/'nvml-queries.jsonl').read_text().splitlines()];clean=read(B/'cleanup.json')
require(exit['status']=='COMPLETED' and exit['child_returncode']==0 and exit['compute_backend']=='nvml' and exit['lease_inherited_by_child'] is True,'guard failure')
require(queries and all(q['status']=='OK' and q['returncode']==0 and not q['observed_errors'] for q in queries),'NVML observation failure')
require(result['counts']['starts']==1 and clean['remaining']==[] and clean['model_exit']==0 and clean['ports_released'] is True and clean['lease_continuously_held'] is True,'one actual model cleanup failed')
entry=read(B/'light-duplex-entry-cleanup.json');require(entry['exit_code']==0 and entry['port_released'],'entry cleanup failed')
events=[json.loads(l) for l in (lease/'events.jsonl').read_text().splitlines()];require(events[-1]['event']=='lease_released' and not any(e.get('conflicts') for e in events),'lease conflict or not released')
guard=p['encrypted'].foreground.base.lifecycle.guard;current=guard.processes()
require(not any(current.get(int(pid),{}).get('start_ticks')==v['start_ticks'] for pid,v in clean['owned'].items()),'owned process remains')
p['full'].background.probe_ports((18588,18589,18590))
with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
row=p['duplex'].read_observed(B/'light-duplex-sessions-observed.json')['barge_in'];journal=[json.loads(l) for l in (B/'light-duplex-barge_in.events.jsonl').read_text().splitlines()]
observed=p['checks'].observe(row['session'],p['evidence'].PHRASE,plan['duplex']['source'],journal)
require(observed==read(B/'observations.json')['barge_in'],'original business changed')
for name in ('before','after'):p['evidence'].state(row[name])
require(row['after']['admitted']-row['before']['admitted']==2 and row['after']['settled']-row['before']['settled']==observed['visible_tokens'] and all(q['status']=='PASS' for q in observed['quality']),'settlement or ASR failure')
save(B/'postflight-original-failure.json',dict(status='FAIL',phase='finalize_only',error='full.environment requires exactly two cleanups but the frozen stage has one model',driver_sha256=sha(W/'cancel_usage_business_01.py'),run_status_unchanged=result['status'],additional_gpu_starts=0))
save(B/'acceptance.json',dict(status=p['SUCCESS'],environment=dict(status='PASS',env_abort=False,all_queries_ok=True,nvml_queries=len(queries),cleanup_complete=True),counts=result['counts'],seconds=result['seconds'],default_unchanged=True,original_failures_preserved=True,qualification_issued=False,postflight='one actual model verified offline; original helper mismatch retained'))
print(json.dumps(read(B/'acceptance.json')))

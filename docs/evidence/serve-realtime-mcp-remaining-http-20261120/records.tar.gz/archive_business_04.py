from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;S=W/'sdk-business-04';O=R/'docs/evidence/serve-realtime-mcp-remaining-http-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
accepted=read(S/'acceptance.json');assert accepted['status']=='ACCEPT_REALTIME_MCP_REMAINING_LIGHT'
files={'archive_business_04.py':Path(__file__),'finalize_remaining_01.py':W/'finalize_remaining_01.py'}
for n in ['plan.json','result.json','counts.json','cleanup.json','acceptance.json','observations.json','finalizer-original-failure.json','light-mcp.sdk.json','light-mcp.events.jsonl','light-mcp-observed.json','light-mcp.stderr','light-peer-results.json','light-entry-cleanup.json','light-config.json','light-capabilities.json','lease/exit.json','lease/events.jsonl','lease/nvml-queries.jsonl']:
 files['sdk-business-04/'+n]=S/n
for n in ['plan.json','result.json','stdout.txt','stderr.txt']:files['finalizer-repair-01/'+n]=W/'finalizer-repair-01'/n
for p in (W/'finalizer-repair-01/original-source').rglob('*'):
 if p.is_file():files['original-source/'+str(p.relative_to(W/'finalizer-repair-01/original-source'))]=p
for n,h in read(W/'finalizer-repair-01/result.json')['sources'].items():assert sha(R/n)==h;files['finalizer-source/'+n]=R/n
for n in ('mcp_checks.py','mcp_lifecycle.py','mcp_sdk.mjs'):files['source/tools/serve_realtime/'+n]=R/'tools/serve_realtime'/n
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
value=dict(accepted,cumulative_actual_model_starts=4,cumulative_actual_model_jobs=10,cumulative_model_stage_seconds=210.1021238109093,cumulative_nvml_ok_queries=202,original_model_quality_failures_preserved=True,all_master_tasks_complete=False);save(O/'acceptance.json',value)
(O/'README.md').write_text('''# 实际MCP回执丢失与核心问答补验

2026-11-20。严格同一GPU租约内，1次轻档模型启动、2次生成、1个官方
SDK WSS连接及原生TLS入口，48.636秒通过。明确新user任务后，远端
实际读取docs/MODEL.md一次，刻意丢回执；客户端获得mcp_result_unknown，
不自动重放。下一user普通问答返回42；1019 tokens准确结算，预留、
活动、会话、主机字节归零，两次生成均有唯一终态。模型/入口正常
退出、端口/锁释放，48次NVML均正常。远端保留的一个会话有有限期
密封目录所有者，本地清理与远端恢复状态分别记录。

初次离线finalizer误调用固定双启动helper，虽实际清理完整仍失败。
原失败保留；修正为精确匹配冻结启动数，3项CPU通过。以原执行源码
和修复源码分别绑定后重新做离线收尾，没有再次启动GPU。旧驱动结果
标签含PRIMARY_LIGHT，这次实际只验上述两项轻档；本接受记录明确
收窄到实际执行清单，不能据标签宣称整组全部通过。

此前主档查询/拒绝审批/故障后问答、轻档审批查询/标题引用证据复用。
原32token错答和轻档无关拒答均保留，未将其追认为正确。累计4次模型
启动、10次实际生成、210.102秒、202次NVML正常；所有原失败单列。
默认rev396 STOPPED保持。后续主轻资格、服务恢复与可回退发行继续，
总目标active；本记录不代替完整OpenAI兼容或整模型质量验收。

公共归档显式排除私有入口配置、证书私钥、MCP策略和对象存储；
本机完整现场保留。[接受记录](acceptance.json) · [索引](index.json) ·
[原始业务、失败与修复](records.tar.gz)。
''')
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m.update(state='required_sdk_tasks_observed_original_model_failures_preserved_qualification_recovery_pending',remaining_http=value,remaining_http_evidence='evidence/serve-realtime-mcp-remaining-http-20261120/README.md');save(p,d)
p=R/'docs/STATUS.md';s=p.read_text().replace('helper写死双启动而失败，正以3项CPU修正，原执行记录保持、不重跑\nGPU。累计4启动/10生成；资格/恢复及可回退发行继续，默认保持。','''helper写死双启动而失败，3项CPU修复及[离线收尾已通过](evidence/serve-realtime-mcp-remaining-http-20261120/README.md)，
原执行记录保持、未重跑GPU。累计4启动/10生成/210.102秒；资格/恢复
及可回退发行继续，默认保持。''');p.write_text(s)
p=R/'docs/log/2026-11-20.md';p.write_text('''## MCP剩余实际故障业务收尾完成

日期：2026-11-20。

做了什么：[1启动/2生成的剩余业务接受](../evidence/serve-realtime-mcp-remaining-http-20261120/README.md)，
准确结算1019 tokens，48次NVML正常，模型/入口/端口/锁清理完成。
固定双启动的离线finalizer错误经3项CPU修复，原执行源码和修复源码
分别绑定，原失败保留，GPU不重跑。公共归档排除所有私有凭据文件。

为什么：按实际工作项复用先前通过证据，旧PRIMARY_LIGHT标签不能
扩大本轮仅两项轻档的结论；原模型质量失败继续独立记录。

下一步：生成新MCP能力的主轻资格，开发对应TLS/控制器/回退恢复
验证并可回退发行、main合入；总目标active、默认rev396保持。

'''+p.read_text())
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[剩余真实故障业务通过](evidence/serve-realtime-mcp-remaining-http-20261120/README.md)：
1轻档启动/2生成/48.636秒，unknown不重放、普通问答42、结算/清理正常。
离线finalizer双启动计数错误修复，3CPU通过、不重跑GPU。累计4模型/
10生成/210.102秒；原失败保留，继续主轻资格、恢复及发行。\n''')
print(json.dumps({k:value[k] for k in ['status','cumulative_actual_model_starts','cumulative_actual_model_jobs','cumulative_nvml_ok_queries']}))

"""Offline one-start postflight; preserves the frozen driver and failed finalizer."""
from pathlib import Path
import fcntl,json,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_realtime import mcp_acceptance as m, mcp_checks, mcp_lifecycle
from tools.serve_service.package import read,require,save,sha
out=W/'sdk-business-04';plan=read(out/'plan.json');result=read(out/'result.json');repair=read(W/'finalizer-repair-01/result.json')
require(repair['status']=='PASS','targeted finalizer CPU')
for n,h in repair['sources'].items():require(sha(R/n)==h,'reviewed repair source drift')
changed={}
for n,h in {**plan['sources'],**plan['protected'],**plan['native_assets']}.items():
 if sha(R/n)==h:continue
 require(n in repair['sources'],'unreviewed postflight change: '+n)
 original=W/'finalizer-repair-01/original-source'/n
 require(sha(original)==h,'original execution source lost')
 changed[n]=dict(original_sha256=h,finalizer_sha256=sha(R/n))
m.check_plan(plan)
require(plan['format']==m.FINISH_FORMAT and result['status']==m.SUCCESS and
        0<result['seconds']<=900 and all(result['counts'][k]==v for k,v in m.FINISH_LIMITS.items() if k not in ('seconds','controls')),'frozen actual budget')
lease=out/'lease';queries=[json.loads(l) for l in (lease/'nvml-queries.jsonl').read_text().splitlines()];events=[json.loads(l) for l in (lease/'events.jsonl').read_text().splitlines()]
environment=m.full.environment(read(lease/'exit.json'),queries,[read(out/'cleanup.json')],expected_starts=1)
require(all(not q['observed_errors'] for q in queries) and not any(e.get('conflicts') for e in events) and events[-1]['event']=='lease_released','actual guard or release failure')
witness=read(out/'light-mcp-observed.json');journal=[json.loads(l) for l in (out/'light-mcp.events.jsonl').read_text().splitlines()]
observed=mcp_checks.observe_unknown(witness['session'],journal,witness['remote'],plan['document_source'],witness['before'],witness['after'])
require(all(q['status']=='PASS' for q in observed['quality']),'actual ordinary quality')
retention=mcp_lifecycle.retained(journal,read(out/'light-peer-results.json'),out/'application-objects','client:'+m.encrypted.CLIENT)
require(read(out/'light-entry-cleanup.json')['exit_code']==0,'entry did not exit')
m.full.background.probe_ports(tuple(plan[k] for k in ('port','operations_port','public_port','private_peer_port')))
guard=m.encrypted.foreground.base.lifecycle.guard
with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
value=dict(status='ACCEPT_REALTIME_MCP_REMAINING_LIGHT',counts=result['counts'],seconds=result['seconds'],environment=environment,observations=observed,mcp_lifecycle=retention,original_finalizer_failure_preserved=True,original_finalizer_failure_sha256=sha(out/'finalizer-original-failure.json'),source_repair=changed,default_unchanged=True,qualification_issued=False,managed_recovery=False,gpu_rerun=False)
require(not (out/'acceptance.json').exists(),'preserve postflight');save(out/'acceptance.json',value);print(json.dumps(value))

import hashlib, importlib.util, json, subprocess, tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-speaker-runtime-cpu-20261118'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=read(D/'runtime-cpu-01/result.json');s=read(D/'runtime-schema-cpu-01/result.json')
assert c['returncode']==s['returncode']==0 and c['tests']==13 and s['tests']==4
assert c['seconds']<=180 and s['seconds']<=60
assert '13 tests, 13 passed, 0 failed, 0 skipped' in (D/'runtime-cpu-01/tests.log').read_text()
for name in ['runtime-cpu-01','runtime-schema-cpu-01']:
 p=read(D/name/'plan.json')
 for f,h in p['sources'].items():assert sha(R/f)==h,f
for f,h in read(D/'runtime-cpu-01/plan.json')['protected'].items():assert sha(R/f)==h,f
assert not list((D/'runtime-cpu-01/tmp').iterdir())
for name in ['runtime-build-01','runtime-build-02','runtime-host-build-01']:
 assert read(D/name/'result.json')['returncode']==0
 assert 'warning:' not in (D/name/'build.log').read_text()
manifest=R/'.q4t-work/serve-custom-tools-20261108/engine-build/generated/q4t/server/chat_protocol_sources.json'
for f,h in read(manifest).items():assert sha(R/f)==h,f
(D/'runtime-cpu-01/compiled-sources.json').write_bytes(manifest.read_bytes())
spec=importlib.util.spec_from_file_location('audit',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
actual=m.current_surface(R);inv=read(m.INVENTORY);changed=[f for f in sorted(inv['sources_sha256'].keys()|actual['sources_sha256'].keys()) if inv['sources_sha256'].get(f)!=actual['sources_sha256'].get(f)]
assert len(changed)==22
for k in ['fields','completion_fields','routes','native_routes']:assert set(inv[k])==set(actual[k])
assert inv['whitelists']==actual['whitelists']
inv['sources_sha256']=actual['sources_sha256'];inv['speaker_runtime_review_20261118']={'anchors':changed,'scope':'Independent ECAPA loading/execution, literal bounded audio references, real VAD/word alignment to diarized JSON/SSE, optional config and health. CPU accepted; actual HTTP and overlap still pending.','evidence':['docs/evidence/serve-speaker-runtime-cpu-20261118/README.md']}
m.INVENTORY.write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n')
with (D/'runtime-cpu-01/inventory.log').open('w') as f:rc=subprocess.run(['/usr/bin/python3','-B',str(R/'tools/serve_audit/check_inventory.py'),'--self-check'],stdout=f,stderr=subprocess.STDOUT,timeout=60).returncode
assert rc==0
O.mkdir();files=[Path(__file__).resolve(),D/'runtime-schema-setup-failure.json',D/'voice-fixtures-01/plan.json',D/'voice-fixtures-01/receipt.json']
for name in ['runtime-build-01','runtime-build-02','runtime-host-build-01','runtime-cpu-01','runtime-schema-generation-01','runtime-schema-cpu-01']:
 files += [f for f in (D/name).rglob('*') if f.is_file()]
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for f in sorted(files):t.add(f,arcname=str(f.relative_to(D)),recursive=False)
a=dict(status='ACCEPT_SPEAKER_RUNTIME_TARGETED_CPU',cpp_tests=13,schema_tests=4,cpp_seconds=c['seconds'],schema_seconds=s['seconds'],gpu_loads=0,http_requests=0,real_reference_pcm_codec=True,own_worker_cleanup_complete=True,candidate_engine_sha256=sha(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t'),compiled_sources_sha256=sha(manifest),original_schema_graph_failure_preserved=True,inventory_anchors_reviewed=22,inventory_negative_controls=7,default_revision=286,defaults_unchanged=True,speaker_http_accepted=False,overlap_implemented=False,all_master_tasks_active=True,archive_sha256=sha(O/'records.tar.gz'))
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Speaker运行时接入针对性CPU验证（2026-11-18）

13C++/{c['seconds']:.3f}秒、4schema/{s['seconds']:.3f}秒通过，0GPU/HTTP。
真实PCM编解码校验2/10秒两端及边外拒绝，私有作用域/取消、内联
数据URL、配置依赖/预算、可选健康与delta/segment关联通过；原
ASR/VAD/aligner配置和实际历史JSON/流合同保护通过，自有worker清理。

运行时已连接原生ECAPA、真实VAD/对齐和diarized_json，独立错误
不改变核心readiness；CUDA故障仍保留保护。所有编译源码SHA与当前
文件一致、零警告，22锚点/7门禁负控通过。一次schema生成选错旧
type graph失败保留，改用与既有schema身份一致的保留图后重新生成。

本组仍不是实际语音或HTTP验收，默认rev286未变。3段官方说话人
样例共257092字节按固定commit/git blob/SHA取得，只保存身份记录，
音频留本地。下一步真实语音/双SDK及服务恢复交付，重叠检测分离与
全部master继续；未做完整性能/模型质量或长稳。
''')
p=R/'docs/serve-master-goals-v2.json';data=read(p);task=next(t for t in data['tasks'] if t['id']=='A10');task['speaker_runtime_20261118']=dict(a,evidence='evidence/serve-speaker-runtime-cpu-20261118/README.md')
data['next_task']='A10 real native diarization HTTP/SDK qualification, service recovery/delivery and overlap implementation; all remaining master tasks'
data['next']='Complete real speaker business and usable recovery/delivery, overlap detection/separation and remaining audio/A/N/R/Q tasks. PR45 is merged. No phase-level total completion.'
p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n',f'''## 正在推进

[Speaker运行时17项CPU通过](evidence/serve-speaker-runtime-cpu-20261118/README.md)：
13C++/{c['seconds']:.3f}秒、4schema/{s['seconds']:.3f}秒，0GPU/HTTP；真实参考PCM
编解码、配置/取消及原音频保护通过。编译身份已核对、零警告；旧
type graph生成失败保留并纠正。继续真实语音/SDK、服务恢复交付、
重叠检测分离及全部master；默认rev286不变。

''',1))
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);p.write_text(h+f'''

## Speaker运行时/参考/schema 17项通过（2026-11-18）

13C++/{c['seconds']:.3f}秒、4schema/{s['seconds']:.3f}秒，0GPU/HTTP；真实PCM
边界、作用域/取消、独立配置/健康和原音频保护通过。运行时完整
源码身份核对、零警告，22锚点/7门禁负控通过。旧类型图生成失败
保留并改用身份匹配的原图；官方3语音身份已固定。原因：需实际
完整API且保留依赖隔离。下一步真实语音/双SDK和服务恢复交付、
重叠路径及全部master，默认rev286不变。
[证据](../evidence/serve-speaker-runtime-cpu-20261118/README.md)。
'''+b)
print(json.dumps(a))

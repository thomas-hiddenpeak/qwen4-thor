"""Explicit durable project queries. Never starts/stops services or retries."""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools.project_tasks import store, engine, transport, migration


def submit(root, binding, key, question, client, **options):
    spec = engine.specification(binding, question, **options)
    name = store.task_name(binding["client_id"], key)
    _, created = store.create(root, name, spec)
    with store.open_task(root, name) as ledger:
        state = engine.replay(ledger)
        store.require(state["execution_spec"] == spec, "idempotency key conflicts with existing task")
        result = (engine.run(ledger, binding, client) if created else
                  engine.public(ledger, state))
        return dict(result, created=created)


def resume(root, binding, key, client, **options):
    name = store.task_name(binding["client_id"], key)
    with store.open_task(root, name) as ledger:
        return engine.run(ledger, binding, client, **options)


def inspect(root, binding, key):
    name = store.task_name(binding["client_id"], key)
    try:
        with store.open_task(root, name, exclusive=False) as ledger:
            engine.check_binding(ledger, binding)
            return engine.public(ledger, engine.replay(ledger))
    except BlockingIOError:
        return dict(task_id=name, state="ACTIVE", automatic_retry=False)


def resolve(root, binding, key, decision, revision, reason):
    name = store.task_name(binding["client_id"], key)
    with store.open_task(root, name) as ledger:
        return engine.resolve(ledger, binding, decision, revision, reason)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("init", "submit", "inspect", "resume", "resolve",
                                           "plan-migration", "apply-migration"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--max-tasks", type=int, default=16)
    parser.add_argument("--profile", type=Path)
    parser.add_argument("--key")
    parser.add_argument("--question")
    parser.add_argument("--max-requests", type=int)
    parser.add_argument("--max-tools", type=int)
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--no-stream", action="store_true")
    parser.add_argument("--decision", choices=("discard-request", "repeat-read", "abandon"))
    parser.add_argument("--revision")
    parser.add_argument("--reason")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--plan-sha256")
    args = parser.parse_args()
    if args.action != "submit":
        store.require(all(value is None for value in (args.question, args.max_requests,
            args.max_tools, args.max_tokens)) and not args.no_stream,
            "question and request budgets apply only to submit; resume keeps the saved contract")
    store.require(args.action in ("plan-migration", "apply-migration") or
        args.plan is None and args.plan_sha256 is None, "migration parameters require a migration command")
    if args.action == "init":
        result = store.init(args.root, args.max_tasks)
    else:
        store.require(args.profile is not None and args.key is not None,
                      "private profile and idempotency key required")
        value, binding = transport.profile(args.profile)
        if args.action == "submit":
            result = submit(args.root, binding, args.key, args.question,
                transport.Client(value), max_requests=4 if args.max_requests is None else args.max_requests,
                max_tools=8 if args.max_tools is None else args.max_tools,
                max_tokens=512 if args.max_tokens is None else args.max_tokens, stream=not args.no_stream)
        elif args.action == "inspect":
            result = inspect(args.root, binding, args.key)
        elif args.action == "resume":
            result = resume(args.root, binding, args.key, transport.Client(value))
        elif args.action == "plan-migration":
            store.require(args.plan is not None and args.plan_sha256 is None,
                          "new private plan path required")
            result = migration.prepare(args.root, binding, args.key, args.plan, args.reason)
        elif args.action == "apply-migration":
            store.require(args.plan is not None and args.plan_sha256 is not None,
                          "exact private plan and digest required")
            result = migration.apply(args.root, binding, args.key, args.plan, args.plan_sha256)
        else:
            result = resolve(args.root, binding, args.key, args.decision,
                             args.revision, args.reason)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get("state", "COMPLETED") == "COMPLETED" or result.get("no_execution") else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        # Raw HTTP bodies and private profile values never enter terminal errors.
        print(json.dumps(dict(error=type(error).__name__, automatic_retry=False)), file=sys.stderr)
        raise SystemExit(1)

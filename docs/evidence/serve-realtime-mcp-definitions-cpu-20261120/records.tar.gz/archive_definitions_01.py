"""Freeze explicit CPU receipts and source without private service state."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / 'docs/evidence/serve-realtime-mcp-definitions-cpu-20261120'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
first = read(W / 'definition-cpu-01/result.json')
second = read(W / 'definition-cpu-02/result.json')
build = read(W / 'definition-build-03/result.json')
assert first['status'] == 'FAIL' and second['status'] == 'PASS'
assert build['status'] == 'BUILD_PASS' and build['warnings'] == 0
assert '18 tests, 17 passed, 1 failed, 0 skipped' in (
    W / 'definition-cpu-01/stdout.txt').read_text()
assert '1 tests, 1 passed, 0 failed, 0 skipped' in (
    W / 'definition-cpu-02/stdout.txt').read_text()
protected = read(W / 'definition-build-03/plan.json')['protected']
assert all(sha(Path(p)) == h for p, h in protected.items())
assert sha(R / '.q4t-work/serve-file-search-20261112/host/q4t_host_tests') == build['binary_sha256']
assert sha(W / 'original-definition-source.cpp') == first['sources']['src/server/realtime_mcp_definitions.cpp']
files = {n: W / n for n in [
    'definition-plan-initial.json', 'definition-plan.json', 'required.txt',
    'definition-repair-plan.json', 'repair-required.txt',
    'build_definitions_01.py', 'build_definitions_02.py',
    'build_definitions_03.py', 'original-definition-source.cpp',
    'archive_definitions_01.py', 'definition-build-01/review.json']}
for phase in ['definition-build-01', 'definition-build-02', 'definition-build-03']:
    for name in ['plan.json', 'result.json', 'build.log']:
        files[phase + '/' + name] = W / phase / name
for phase in ['definition-cpu-01', 'definition-cpu-02']:
    for name in ['result.json', 'stdout.txt', 'stderr.txt']:
        files[phase + '/' + name] = W / phase / name
for name in ['include/q4t/server/realtime_mcp_definitions.h',
             'src/server/realtime_mcp_definitions.cpp',
             'tests/server_realtime_mcp_definitions_test.cpp',
             'cmake/HostTestSources.cmake', 'cmake/ChatProtocolIdentity.cmake']:
    files['source/' + name] = R / name
secrets = set()


def collect(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {'api_key', 'gateway_token', 'token', 'authorization'} and isinstance(child, str) and len(child) >= 24:
                secrets.add(child.encode())
            else:
                collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)


D = R / '.q4t-work/serve-realtime-duplex-20261120'
for p in [D / 'service-package-01/clients.json',
          R / 'build/service/engine/client-policy.json',
          R / 'build/service/gateway-policy.json',
          D / 'credential-remediation-01/retained/bundle/engine/client-policy.json']:
    collect(read(p))
for name, path in files.items():
    data = path.read_bytes()
    assert not any(secret in data for secret in secrets), name
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----\s+[A-Za-z0-9+/=]{10,}', data), name
O.mkdir()
with tarfile.open(O / 'records.tar.gz', 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
index = {n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}
with tarfile.open(O / 'records.tar.gz', 'r:gz') as archive:
    assert set(archive.getnames()) == set(index)
    for member in archive:
        data = archive.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == index[member.name]['sha256']
        assert not any(secret in data for secret in secrets)
save = lambda p, x: p.write_text(json.dumps(x, indent=2, ensure_ascii=False) + '\n')
save(O / 'index.json', dict(files=index, archive_sha256=sha(O / 'records.tar.gz')))
acceptance = dict(status='PASS_REALTIME_MCP_DEFINITION_TRANSACTIONS_CPU',
    distinct_cases=18, case_executions=19, initial_passed=17, initial_failed=1,
    affected_repair_passed=1, reused_passed_cases=17,
    cpu_seconds=first['seconds'] + second['seconds'],
    source_builds_zero_warnings=2, initial_relink_not_component_acceptance=True,
    original_failure_preserved=True, original_source_sha_verified=True,
    host_binary_sha256=build['binary_sha256'], runtime_connected=False,
    actual_mcp_network_tested=False, gpu_starts=0, http_requests=0,
    default_revision=396, default_unchanged=True, service_state='STOPPED',
    full_realtime_mcp_complete=False, all_master_tasks_active=True,
    public_secret_scan_matches=0,
    source_identity=sha(R / 'src/server/realtime_mcp_definitions.cpp'))
save(O / 'acceptance.json', acceptance)
(O / 'README.md').write_text(f'''# Realtime MCP会话定义事务：针对性CPU

2026-11-20。同连接的完整定义、标签复用、按次覆盖和凭据事务已实现。
新连接不能继承旧连接，完整目标声明不继承旧凭据，label引用可显式
清除或替换凭据。公共投影去掉authorization及全部headers；公开函数
内容保持原样，不因其中出现同名字段而误删用户数据。

失败更新、重复标签、过期/重复提交不能改写已确认状态。最多64个
记忆定义，待提交的私有定义、活动副本和公共投影一起受4MiB存储限额
约束；移出当前tools后仍可在同连接按标签引用，超限显式拒绝。
连接的执行可用集合由后续目录导入决定，本组件不凭声明创建工具。

冻结18项：首次17通过/1失败（{first['seconds']:.6f}秒）。SDK将函数
parameters声明为通用类型，原实现因此接受了字符串schema。现复用
现有原生函数输入校验；只重验该受影响项通过（{second['seconds']:.6f}秒），
其余17项按未改分支复用。原失败、原host及逐字节核对的失败源码保留，
没有改变预期结果。共18个用例/19次执行。实际两次源码构建零警告。
更早一次只修改根CMake，独立host入口未登记新文件，重新链接得到旧
binary；该次明确不算新组件构建或验证通过，登记来源后才进行测试。

这是定义事务组件验证，尚未接通Realtime公开运行时，未导入实际MCP
目录或执行网络工具。默认rev396和runtime保持STOPPED，0GPU/0HTTP。
下一步继续异步目录、审批/调用事件、实际SDK业务、恢复与可回退交付；
PR #55独立收尾，所有master任务继续。

[计划](../../SERVE_REALTIME_MCP_2026-11-20.md)、[结果](acceptance.json)、
[索引](index.json)、[原始记录](records.tar.gz)。
''')
print(json.dumps(acceptance))

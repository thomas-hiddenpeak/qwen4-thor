"""One start/four creates: actual managed joint MTP and visual dispatch."""
import argparse,copy,http.client,json,re,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_responses import video_acceptance as video
from tools.serve_responses import file_integration_acceptance as files
from tools.serve_chat_storage import acceptance as chats
from tools.serve_service import capacity,package,supervisor
from tools.serve_ops import contracts
from tools.serve_service.package import read,save,sha,require
from tools.serve_protocol import build_contract as api
from jsonschema import Draft202012Validator
LIMITS=dict(starts=1,chats=4,controls=2000,seconds=600)
WORK=Path(__file__).resolve().parent
PROFILE=capacity.normalize(dict(version=2,allow_media=True,max_seq=1,max_len=8192,max_prefill=2048,max_tokens=256,max_inflight_requests=8,max_queued_requests=2))

def requests():
    text=dict(model=video.foreground.MODEL,temperature=0,enable_thinking=False,max_completion_tokens=128,
        messages=[dict(role='user',content='Return exactly the numbers 1 through 12 in ascending order, as a JSON array, without any other text.')])
    raw=copy.deepcopy(video.requests()['stream']);raw.pop('stream');raw.pop('stream_options');raw.pop('text')
    raw['input'][0]['content'][1]['text']+=' Return only the JSON object, without Markdown.'
    return dict(before=text,video=raw,pdf=files.requests()['pdf'],after=copy.deepcopy(text))

class Stage(video.background.Stage):
    limits=LIMITS;request_templates=staticmethod(requests)
    success_status='PASS_MANAGED_JOINT_VISION_BUSINESS'
    sdk_chat=chats.Stage.sdk_chat
    def start(self):
        video.background.probe_ports((self.plan['port'],self.plan['operations_port']))
        cfg=package.settings(self.plan['port'],0,operations_port=self.plan['operations_port'],capacity_profile=self.plan['profile'])
        args=package.command(WORK/'candidate-01',dict(settings=cfg,model_dir=self.plan['model']))
        args+=['--object-store-dir',str(self.out/'objects')]
        save(self.out/'model-command.json',args);self.budget('starts')
        with (self.out/'model.log').open('xb',buffering=0) as log:
            self.model=subprocess.Popen(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,pass_fds=(self.lease,))
        self.model_identity=video.base.lifecycle.guard.processes()[self.model.pid];self.history[self.model.pid]=self.model_identity
        save(self.out/'model-identity.json',dict(pid=self.model.pid,**self.model_identity))
        end=time.monotonic()+180
        while time.monotonic()<end:
            self.same_model()
            try:
                if self.http('/readyz',timeout=1)[0]==200:break
            except (OSError,http.client.HTTPException):pass
            time.sleep(.1)
        else:raise TimeoutError('joint media/MTP startup')
        for name in ('capabilities','config'):
            status,raw=self.http('/v1/'+name,label='initial-'+name);require(status==200,'missing '+name)
            save(self.out/(name+'.json'),json.loads(raw))
        caps=read(self.out/'capabilities.json');config=read(self.out/'config.json')
        require(caps['runtime']['mtp_enabled'] and caps['runtime']['media_enabled'],'joint runtime not loaded')
        require(caps['file_inputs']['native_video']['model_media_enabled'] and not caps['file_inputs']['native_video']['requires_mtp_disabled'],'video declaration mismatch')
        observed=contracts.configuration(config,version=5)
        capacity.observation(self.plan['profile'],observed)
        require(all(observed[k]==v for k,v in supervisor.expected_configuration(self.plan['profile']).items()),'managed effective capacity differs')
        self.client.protocol_sha256=caps['protocol_source_sha256']
    def mtp_steps(self):
        rows=re.findall(r'\[mtp-accept\] request=(\S+) draft_counts=([0-9,]+)',(self.out/'model.log').read_text())
        return {name:[int(x) for x in counts.split(',')] for name,counts in rows}
    def text(self,label):
        before=self.mtp_steps();result=self.sdk_chat(label,'create',self.plan['requests'][label]);self.drained(label)
        require(result['choices'][0]['finish_reason']=='stop' and json.loads(result['choices'][0]['message']['content'])==list(range(1,13)),'ordinary text list differs')
        after=self.mtp_steps();added=after.keys()-before.keys()
        require(len(added)==1 and sum(after[next(iter(added))])>0,'actual MTP step missing')
        save(self.out/(label+'-mtp.json'),dict(new_request=next(iter(added)),draft_counts=after[next(iter(added))],same_pid=True))
    def business(self):
        self.text('before');before=self.mtp_steps()
        count=self.http('/v1/responses/input_tokens',files.tokens.count_request(self.plan['requests']['video']),label='video-count')
        require(count[0]==200,'video count failed');count=json.loads(count[1]);self.budget('controls')
        raw=self.sdk('video','create',self.plan['requests']['video']);video.color_answer(raw);self.drained('video')
        require(count['input_tokens']==raw['usage']['input_tokens'],'video count mismatch')
        require(self.mtp_steps()==before,'visual request entered text draft')
        pdf=self.sdk_chat('pdf','create',self.plan['requests']['pdf']);files.pdf_answer(pdf);self.drained('pdf')
        require(self.mtp_steps()==before,'PDF request entered text draft')
        self.text('after');self.drained('final')
        stages=re.findall(r'event=stage stage=media ',(self.out/'model.log').read_text())
        require(len(stages)==2,'two actual visual executions not observed')
        save(self.out/'business-summary.json',dict(starts=1,creates=4,managed_command=True,joint_mtp_vision_loaded=True,media_executions=len(stages),text_mtp_requests=len(self.mtp_steps()),video_without_grammar=True,actual_video_colors=True,pdf_number_color=True,input_tokens_parity=True,same_model_pid=True,full_performance_or_quality_claim=False))

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run']);args=p.parse_args();out=WORK/'business-01'
    if args.mode=='prepare':
        rows=requests()
        for name in ['before','pdf','after']:Draft202012Validator(api.vision_schema() if name=='pdf' else api.chat_schema()).validate(rows[name])
        require(not video.background.wire_errors(rows['video'],'response_create'),'video schema')
        video.background.prepare(argparse.Namespace(binary=WORK/'candidate-01/q4t',output=out,port=18186),rows=rows,limits=LIMITS,scope=__doc__)
        plan=read(out/'plan.json');plan['profile']=PROFILE
        for f in [Path(__file__),ROOT/files.PDF,video.ASSETS/video.CLIPS[1],WORK/'candidate-01/chat_protocol_sources.json']:
            plan['sources'][str(f.relative_to(ROOT))]=sha(f)
        for f in ['tools/serve_service/capacity.py','tools/serve_service/package.py','tools/serve_service/supervisor.py','tools/serve_ops/contracts.py','tools/serve_chat_storage/run_sdk.mjs','tools/serve_chat_storage/acceptance.py']:
            plan['sources'][f]=sha(ROOT/f)
        plan['planned'].update(starts=1,creates=4,model_steps=4)
        plan['mutations']=['own model/storage only; graceful cleanup; no restart or request retry; default unchanged']
        plan['derived_requests']=['two identical ordinary text requests require actual MTP steps; original VP8 input without grammar, explicit JSON-only instruction; existing PDF request/oracle', 'one video count control; actual media-stage and MTP logs distinguish decode paths']
        save(out/'plan.json',plan)
    else:
        with video.base.lifecycle.child_subreaper():Stage(read(out/'plan.json')).run()
if __name__=='__main__':main()

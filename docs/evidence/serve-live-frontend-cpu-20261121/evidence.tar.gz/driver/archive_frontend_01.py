"""Publish bounded Live output/worker receipts and preserve original failures."""
import hashlib, importlib.util, io, json, subprocess, tarfile
from pathlib import Path
W=Path(__file__).resolve().parent; R=W.parents[1]
O=R/'docs/evidence/serve-live-frontend-cpu-20261121'
read=lambda p:json.loads(p.read_text()); sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
runs=[read(W/f'frontend-cpu-0{i}/result.json') for i in (1,2,3)]
assert [x['status'] for x in runs]==['BUILD_FAIL','FAIL','PASS']
for i in (1,2):
 plan=read(W/f'frontend-cpu-0{i}/plan.json')
 with tarfile.open(W/f'frontend-cpu-0{i}/failed-source.tar.gz','r:gz') as t:
  for n,h in plan['sources'].items():assert sha(t.extractfile(n).read())==h,n
assert all(x['sources_unchanged'] and x['protected_unchanged'] for x in runs[1:])
last=read(W/'frontend-cpu-03/plan.json'); first=read(W/'frontend-cpu-02/plan.json')
assert {n for n,h in first['sources'].items() if h!=last['sources'][n]}=={'tests/server_live_frontend_work_test.cpp'}
spec=importlib.util.spec_from_file_location('inventory',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=R/'tools/serve_audit/inventory.json';inventory=read(p);actual=m.current_surface(R)
expected={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','include/q4t/server/live_audio_output.h','src/server/live_audio_output.cpp','include/q4t/server/live_frontend_work.h','src/server/live_frontend_work.cpp'}
diff={n for n,h in actual['sources_sha256'].items() if inventory['sources_sha256'].get(n)!=h}
save(W/'frontend-inventory-before.json',dict(changed_sources=sorted(diff),errors=m.check(inventory,actual)))
assert diff==expected,(diff,expected)
# Semantics reviewed: original 24k receipt/finite message verifier, Live-only
# conversion, no extra model/quota owner, bounded queue, same-owner history,
# failed/uncertain delivery never replayed, cancellation joins actual borrower.
for n in sorted(expected):inventory['sources_sha256'][n]=actual['sources_sha256'][n]
inventory['live_frontend_review_20261121']=dict(sources=sorted(expected),evidence='docs/evidence/serve-live-frontend-cpu-20261121/README.md',status='CPU verified worker/output preparation; actual model/handler not yet bound',no_route_accepted=True)
save(p,inventory)
r=subprocess.run(['python3','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(W/'frontend-inventory-reviewed.json').write_text(r.stdout);assert r.returncode==0,r.stdout
files={}
for folder in ('frontend-plan-01','frontend-cpu-01','frontend-cpu-02','frontend-cpu-03'):
 for p in sorted((W/folder).iterdir()):
  assert p.is_file()
  if p.suffix=='.md':continue # Official full guides remain private; metadata only.
  files[folder+'/'+p.name]=p.read_bytes()
for name in ('frontend_cpu_01.py','frontend_cpu_02.py','frontend_cpu_03.py','archive_frontend_01.py','frontend-inventory-before.json','frontend-inventory-reviewed.json'):
 files['driver/'+name]=(W/name).read_bytes()
for n,h in last['sources'].items():
 raw=(R/n).read_bytes();assert sha(raw)==h,n;files['accepted/'+n]=raw
assert not O.exists();O.mkdir();index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,raw in sorted(files.items()):
  index[n]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(n)
  info.size,info.mode,info.mtime=len(raw),0o600,0;t.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
result=dict(status='PASS_NATIVE_LIVE_FRONTEND_CPU_PREPARATION',original_build_failure_preserved=True,original_cpu_tests=10,original_cpu_pass=6,original_cpu_fail=4,targeted_repair_tests=4,distinct_tests=10,production_changed_after_first_cpu=False,original_cpu_seconds=runs[1]['cpu_seconds'],repair_cpu_seconds=runs[2]['cpu_seconds'],host_binary_sha256=runs[2]['binary_sha256'],inventory_reviewed_sources=6,inventory_mutation_checks=22,real_model_business_accepted=False,new_gpu_starts=0,default_revision=426,default_changed=False,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',result);print(json.dumps(result))

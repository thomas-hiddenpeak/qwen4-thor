import hashlib,json,os,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'frontend-cpu-03';H=R/'.q4t-work/serve-file-search-20261112/host';assert not O.exists();O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
sources={n:sha(R/n) for n in ['CMakeLists.txt', 'cmake/ChatProtocolIdentity.cmake', 'cmake/HostTestSources.cmake', 'include/q4t/server/live_audio_output.h', 'src/server/live_audio_output.cpp', 'include/q4t/server/live_frontend_work.h', 'src/server/live_frontend_work.cpp', 'tests/server_live_frontend_work_test.cpp', 'src/server/realtime_response_output.cpp', 'src/server/realtime_speech_encoder.cpp', 'src/server/realtime_speech_execution.cpp', 'src/server/realtime_conversation.cpp', 'src/server/realtime_speech_history.cpp', 'src/server/responses_item_shape.cpp', 'src/server/contracts/openai_live_types_v1.json', 'include/q4t/server/request_control.h']}
protected={str(p.relative_to(R)):sha(p) for p in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service/manifest.json',R/'build/service-native-state/ledger.json']}
commands=[['cmake','-S',str(R/'tests/host'),'-B',str(H)],['cmake','--build',str(H),'--target','q4t_host_tests','--parallel','2']]
save(O/'plan.json',dict(sources=sources,protected=protected,commands=commands,required_tests=str(W/'frontend-plan-01/required-03.txt'),reason='Frozen Live audio receipt/conversion and actual frontend worker ownership/backpressure; CPU controlled execution, real model binding and route pending.',build_limit_seconds=600,cpu_limit_seconds=60,gpu_actions=0))
rows=[];start=time.monotonic()
try:
 for i,c in enumerate(commands):
  with (O/(str(i)+'-build.log')).open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=max(1,600-(time.monotonic()-start)))
  rows.append(dict(command=i,returncode=r.returncode));assert r.returncode==0,'build '+str(i)
  assert 'warning:' not in (O/(str(i)+'-build.log')).read_text().lower(),'build warning'
 assert (H/'generated/q4t/server/live_types_data.h').read_bytes()==(W/'shape-cpu-01/generated/q4t/server/live_types_data.h').read_bytes(),'compiled graph differs'
 build_seconds=time.monotonic()-start;c=[str(H/'q4t_host_tests'),'--required-list',str(W/'frontend-plan-01/required-03.txt')];start=time.monotonic()
 with (O/'cpu.log').open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 result=dict(status='PASS' if r.returncode==0 else 'FAIL',returncode=r.returncode,build_seconds=build_seconds,cpu_seconds=time.monotonic()-start,tests=4,commands=rows,command=c,binary_sha256=sha(H/'q4t_host_tests'),sources_unchanged=all(sha(R/n)==h for n,h in sources.items()),protected_unchanged=all(sha(R/n)==h for n,h in protected.items()),gpu_actions=0)
 save(O/'result.json',result);print(json.dumps(result));print((O/'cpu.log').read_text());assert r.returncode==0
except BaseException as error:
 if not (O/'result.json').exists():save(O/'result.json',dict(status='BUILD_FAIL',error=str(error),commands=rows,seconds=time.monotonic()-start,gpu_actions=0))
 raise

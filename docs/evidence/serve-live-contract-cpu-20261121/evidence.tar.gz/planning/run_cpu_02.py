"""Complete only the missing native JSON escape link, retaining original build."""
import hashlib,json,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[2];OLD=W.parent/'shape-cpu-01';O=W.parent/'shape-cpu-02';assert not O.exists();O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n');read=lambda p:json.loads(p.read_text())
prior=read(OLD/'plan.json');assert all(sha(Path(n))==h for n,h in prior['sources'].items());assert read(OLD/'result.json')['status']=='BUILD_FAIL'
compile=prior['commands'][0][:-4]+['-c',str(R/'src/server/http_response.cpp'),'-o',str(O/'http_response.o')]
link=['g++-14','-Wl,--gc-sections',*map(str,[OLD/(str(i)+'.o') for i in range(8)]),str(O/'http_response.o'),'-o',str(O/'q4t_live_shape_tests')]
save(O/'plan.json',dict(previous_plan_sha256=sha(OLD/'plan.json'),sources={**prior['sources'],str(R/'src/server/http_response.cpp'):sha(R/'src/server/http_response.cpp')},retained_objects={str(OLD/(str(i)+'.o')):sha(OLD/(str(i)+'.o')) for i in range(8)},commands=[compile,link],required_tests=prior['required_tests'],scope='Build driver omitted existing JSON-escape source; runtime unchanged; no prior CPU tests executed.',protected=prior['protected']))
start=time.monotonic();rows=[]
for i,c in enumerate([compile,link]):
 with (O/(str(i)+'-build.log')).open('w') as f:r=subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 rows.append(dict(command=i,returncode=r.returncode));assert r.returncode==0
build_seconds=time.monotonic()-start;c=[str(O/'q4t_live_shape_tests'),'--required-list',str(OLD/'required.txt')];start=time.monotonic()
with (O/'cpu.log').open('w') as f:r=subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,timeout=30)
result=dict(status='PASS' if r.returncode==0 else 'FAIL',returncode=r.returncode,tests=6,build_seconds=build_seconds,cpu_seconds=time.monotonic()-start,commands=rows,command=c,binary_sha256=sha(O/'q4t_live_shape_tests'),sources_unchanged=all(sha(Path(n))==h for n,h in read(O/'plan.json')['sources'].items()),protected_unchanged=all(sha(R/n)==h for n,h in prior['protected'].items()),gpu_actions=0)
save(O/'result.json',result);print(json.dumps(result));print((O/'cpu.log').read_text());assert r.returncode==0

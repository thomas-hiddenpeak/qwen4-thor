from pathlib import Path
import hashlib,json,shutil,subprocess
W=Path(__file__).resolve().parent;R=W.parents[2];S=W/'overlay';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R),'preserve other work'
for n,h in json.loads((W/'identity-before-promotion.json').read_text()).items():assert sha(R/n)==h,n
for p in S.rglob('*'):
 if not p.is_file():continue
 q=R/p.relative_to(S);assert not q.exists() or str(p.relative_to(S))=='src/server/responses_item_shape.cpp';q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for n in ('generate_item_types.mjs','item_shape_vectors.mjs'):shutil.copyfile(W/n,R/'tools/serve_responses'/n)
p=R/'cmake/HostTestSources.cmake';s=p.read_text();key='  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_realtime_shape_test.cpp\n';assert s.count(key)==1;p.write_text(s.replace(key,key+'  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_live_shape_test.cpp\n'))
p=R/'cmake/ChatProtocolIdentity.cmake';s=p.read_text();key='  cmake/realtime_types.h.in\n';assert s.count(key)==1;s=s.replace(key,key+'  include/q4t/server/live_shape.h\n  src/server/contracts/openai_live_types_v1.json\n  cmake/live_types.h.in\n');s+='''
file(READ "${Q4T_PROTOCOL_ROOT}/src/server/contracts/openai_live_types_v1.json"
  Q4T_LIVE_TYPES)
string(FIND "${Q4T_LIVE_TYPES}" ")q4t_types\\\"" live_delimiter)
if(NOT live_delimiter EQUAL -1)
  message(FATAL_ERROR "live type graph contains its C++ literal delimiter")
endif()
configure_file("${CMAKE_CURRENT_LIST_DIR}/live_types.h.in"
  "${Q4T_CHAT_PROTOCOL_INCLUDE_DIR}/q4t/server/live_types_data.h" @ONLY)
''';p.write_text(s)
plan=(W/'plan.md').read_text().replace('# Live 原生应用服务接续计划（待追踪 PR #57 收尾后接入主工作树）','# Live 原生应用服务实现计划').replace('现有准备均为源码/合同准备，未修改默认包或运行模型。','L01源码已接入工作树；6项针对性原生CPU通过，Live 808与Realtime 476个SDK正反例无差异。首轮独立链接漏掉既有JSON转义函数，原失败保留；补齐链接后通过，运行时未为此改写。尚未接入服务路由或模型业务，默认rev426保持STOPPED，未运行新GPU。PR #57仍按其冻结提交完成检查/合入，本组后续单独提交。')
p=R/'docs/SERVE_LIVE_2026-11-21.md';assert not p.exists();p.write_text(plan)
p=R/'docs/STATUS.md';s=p.read_text().replace('## 正在推进\n','## 正在推进\n\n[Live合同源码](SERVE_LIVE_2026-11-21.md)已接入工作树：6项针对性CPU\n通过，808个Live和476个Realtime SDK正反例无差异；首轮独立构建\n漏链接既有函数的失败保留。原生路由/模型业务尚待实现，默认rev426\n不变。该组在PR #57合入后单独提交，继续L02—L06及全部总任务。\n');p.write_text(s)
p=R/'docs/log/2026-11-21.md';p.write_text('''## Live原生合同接续与针对性CPU

日期：2026-11-21。

做了什么：固定官方SDK的16个Live类型根，941节点；复用C++有界
校验器并加入16 MiB实际存储计量，接入构建/测试清单。独立SDK编译器
提供808个Live正反例；6项原生CPU通过，既有476个Realtime例子保持。
独立构建最初漏链接已有JSON转义函数，原失败保留，补齐后零警告。
没有运行模型，默认rev426 STOPPED不变。本组待PR #57合入后单独提交。
另8个本任务退役快照可逆压缩释放102298211字节，SHA/恢复脚本保留。

为什么：Live拥有独立生命周期、委派及累计音频用量，不能只改Realtime
事件名。合同校验先建立，但不把类型通过宣称为执行或兼容全部完成。

下一步：核对生成物/宿主构建入口，接通原生主WSS、持续音频与实际
ASR/LLM/TTS，再执行全部Live及其他Serve子任务。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';d=json.loads(p.read_text());d['native_live_20261121']=dict(state='contract_source_cpu_pass_runtime_pending',plan='SERVE_LIVE_2026-11-21.md',master_active=True,default_revision=426,default_changed=False,gpu_starts=0,type_roots=16,type_nodes=941,live_sdk_vectors=808,realtime_regression_vectors=476,distinct_native_cpu_tests=6,original_build_failure_preserved=True,subtasks=[dict(id='L0'+str(i),state='source_cpu_verified' if i==1 else 'planned',title=t) for i,t in enumerate(['有界合同与原生校验','主WSS与持续语音业务','委派与上下文','存储/sideband/fork','WebRTC/SIP媒体接入','组合验收与可回退交付'],1)],all_remaining_master_tasks_required=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('Live contract promoted without changing default or pushing PR #57')

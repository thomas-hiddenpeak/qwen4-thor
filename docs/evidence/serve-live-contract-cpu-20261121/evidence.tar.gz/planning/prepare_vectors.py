from pathlib import Path
R=Path(__file__).resolve().parents[3];W=Path(__file__).parent
s=(R/'tools/serve_responses/item_shape_vectors.mjs').read_text();s=s.replace("const realtime = graph.profile ===", "const live = graph.profile === 'q4t-openai-live-types-v1';\nconst realtime = graph.profile ===")
s=s.replace('if (!realtime) vectors.push(', 'if (!realtime && !live) vectors.push(')
a=s.index('const types = realtime ? {');b=s.index('const directory = ',a)
s=s[:a]+'''const liveTypes = {
  client_event: ['live', 'ClientEvent'], server_event: ['live', 'ServerEvent'],
  session_start: ['live', 'SessionConfig'], session_update: ['live', 'SessionUpdateConfig'],
  session: ['live', 'SessionResource'], media_create: ['live', 'LiveCreateParams'],
  media_created: ['live', 'LiveCreateResponse'],
  sideband_client: ['sideband/sideband', 'ConnectClientEvent'],
  sideband_server: ['sideband/sideband', 'ConnectServerEvent'],
  fork_client: ['forks/forks', 'ForkClientEvent'],
  fork_server: ['forks/forks', 'ForkServerEvent'],
  session_accept: ['sessions', 'SessionAcceptParams'],
  session_fork: ['sessions', 'SessionForkParams'],
  session_forked: ['sessions', 'SessionForkResponse'],
  session_refer: ['sessions', 'SessionReferParams'],
  session_reject: ['sessions', 'SessionRejectParams'],
};
const types = live ? Object.fromEntries(Object.entries(liveTypes).map(([k,v])=>[k,v[1]])) : realtime ? {
  conversation_item: 'ConversationItem', client_event: 'RealtimeClientEvent',
  server_event: 'RealtimeServerEvent', response_create: 'RealtimeResponseCreateParamsWithReferencesParam',
  session: 'RealtimeSessionCreateRequest', response: 'RealtimeResponse',
} : {input_item:'ResponseInputItem',output_item:'ResponseOutputItem',conversation_item:'ConversationItem'};
if(live) vectors.push(
 {name:'manual_start_native_model_pcm',shape:'client_event',positive:true,input:{type:'session.start',event_id:'s1',session:{model:'q4t',audio:{format:{type:'audio/pcm',rate:16000}},store:false}}},
 {name:'manual_start_model_missing',shape:'client_event',input:{type:'session.start',session:{audio:{format:{type:'audio/pcm',rate:24000}}}}},
 {name:'manual_pcm_bad_rate',shape:'session_start',input:{model:'q4t',audio:{format:{type:'audio/pcm',rate:44100}}}},
 {name:'manual_update_voice_is_not_mutable',shape:'session_update',input:{audio:{output:{voice:'alloy'}}}},
 {name:'manual_nullable_delegation_and_empty_triggers',shape:'session_update',positive:true,input:{delegation:null,triggers:[]}},
 {name:'manual_initial_history',shape:'session_start',positive:true,input:{model:'q4t',input:[{role:'user',content:[{type:'input_text',text:'hello'}]}]}},
 {name:'manual_append_has_no_realtime_alias',shape:'client_event',input:{type:'input_audio_buffer.append',audio:'AA=='}},
 {name:'manual_usage_is_duration',shape:'server_event',positive:true,input:{type:'session.usage.updated',event_id:'e1',usage:{seconds:0.25}}},
 {name:'manual_tokens_do_not_replace_duration',shape:'server_event',input:{type:'session.usage.updated',event_id:'e1',usage:{total_tokens:42}}},
 {name:'manual_closed_snapshot_remains_active',shape:'server_event',positive:true,input:{type:'session.closed',event_id:'e2',reason:'close_requested',session:{id:'live_1',expires_at:1000,model:'q4t',status:'active'},usage:{seconds:0.25}}},
 {name:'manual_closed_without_usage',shape:'server_event',input:{type:'session.closed',event_id:'e2',reason:'close_requested',session:{id:'live_1',expires_at:1000,model:'q4t',status:'active'}}},
 {name:'manual_thinking_silent_context',shape:'client_event',positive:true,input:{type:'session.thinking.append',content:'working',delegation_id:null}},
);
''' +s[b:]
s=s.replace('let source = realtime ?', "let source = live ? Object.entries(liveTypes).map(([shape,[file,name]])=>`import type { ${name} } from ${JSON.stringify(resolve(sdk,'src/resources/live/'+file+'.ts'))};`).filter((x,i,a)=>a.indexOf(x)===i).join('\\n')+'\\n' : realtime ?")
s=s.replace("const file = resolve(sdk, realtime ? 'src/resources/realtime/realtime.ts'", "const file = resolve(sdk, live ? 'src/resources/live/'+liveTypes[shape][0]+'.ts' : realtime ? 'src/resources/realtime/realtime.ts'")
s=s.replace("profile: realtime ? 'q4t-sdk-realtime-shape-oracle-v1'", "profile: live ? 'q4t-sdk-live-shape-oracle-v1' : realtime ? 'q4t-sdk-realtime-shape-oracle-v1'")
p=W/'item_shape_vectors.mjs';assert not p.exists();p.write_text(s)

"""Bounded native wire validation against independently compiled SDK cases."""
import hashlib,json,os,re,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[2];O=W.parent/'shape-cpu-01';S=W/'overlay';assert not O.exists();O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
G=O/'generated/q4t/server';G.mkdir(parents=True)
for n,var in [('live','Q4T_LIVE_TYPES'),('realtime','Q4T_REALTIME_TYPES'),('responses_item','Q4T_ITEM_TYPES')]:
 base=S if n=='live' else R
 graph=base/'src/server/contracts'/('openai_item_types_v1.json' if n=='responses_item' else 'openai_'+n+'_types_v1.json')
 template=base/'cmake'/(n+'_types.h.in')
 (G/(n+'_types_data.h')).write_text(template.read_text().replace('@'+var+'@',graph.read_text()))
files=[S/'src/server/responses_item_shape.cpp',S/'tests/server_live_shape_test.cpp',R/'tests/server_realtime_shape_test.cpp',R/'tests/test_main.cpp',R/'src/io/json.cpp',R/'src/server/input_contract.cpp',R/'src/server/realtime_conversation.cpp',R/'src/trace/sha256.cpp']
names=['live_shape_matches_actual_sdk_type_oracle','live_shape_duplicate_keys_and_bounded_error_path','live_shape_large_owned_string_rejected_before_schema_walk','live_shape_invalid_root_does_not_accept_an_empty_object','realtime_shape_matches_actual_sdk_type_oracle','realtime_shape_duplicate_keys_and_bounded_error_path']
(O/'required.txt').write_text('\n'.join(names)+'\n')
protected={str(p.relative_to(R)):sha(p) for p in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service/manifest.json',R/'build/service-native-state/ledger.json']}
sources={str(p):sha(p) for p in [*files,*sorted((R/'include').rglob('*.h')),*sorted((S/'include').rglob('*.h')),*sorted(G.glob('*.h')),W/'oracle-01/vectors.json',S/'tests/fixtures/live/sdk_vectors.json',R/'tests/fixtures/realtime/sdk_vectors.json',Path(__file__)]}
objects=[O/(str(i)+'.o') for i in range(len(files))];flags=['-std=c++23','-O2','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-I'+str(S/'include'),'-I'+str(R/'include'),'-I'+str(O/'generated'),'-I'+str(R/'src/server')]
commands=[['g++-14',*flags,'-c',str(p),'-o',str(obj)] for p,obj in zip(files,objects)]+[['g++-14','-Wl,--gc-sections',*map(str,objects),'-o',str(O/'q4t_live_shape_tests')]]
save(O/'plan.json',dict(source_scope='Private Live preparation, same real native validator and measurements; no model/network substitutes.',sources=sources,commands=commands,required_tests=names,build_limit_seconds=180,cpu_limit_seconds=30,protected=protected,gpu_actions=0))
started=time.monotonic();rows=[]
try:
 for i,c in enumerate(commands):
  with (O/(str(i)+'-build.log')).open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=max(1,180-(time.monotonic()-started)))
  rows.append(dict(command=i,returncode=r.returncode,log_sha256=sha(O/(str(i)+'-build.log'))));assert r.returncode==0, 'build failed '+str(i)
 build_seconds=time.monotonic()-started
 c=[str(O/'q4t_live_shape_tests'),'--required-list',str(O/'required.txt')];start=time.monotonic()
 with (O/'cpu.log').open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 result=dict(status='PASS' if r.returncode==0 else 'FAIL',build_seconds=build_seconds,cpu_seconds=time.monotonic()-start,returncode=r.returncode,tests=len(names),command=c,logs=rows,binary_sha256=sha(O/'q4t_live_shape_tests'),sources_unchanged=all(sha(Path(n))==h for n,h in sources.items()),protected_unchanged=all(sha(R/n)==h for n,h in protected.items()),gpu_actions=0)
 save(O/'result.json',result);print(json.dumps(result));print((O/'cpu.log').read_text());assert r.returncode==0
except BaseException as error:
 if not (O/'result.json').exists():save(O/'result.json',dict(status='BUILD_FAIL',error=str(error),logs=rows,seconds=time.monotonic()-started,gpu_actions=0))
 raise

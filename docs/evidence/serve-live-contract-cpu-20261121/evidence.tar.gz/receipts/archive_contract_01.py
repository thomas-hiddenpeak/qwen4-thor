"""Publish explicit L01 source and CPU receipts; no private deployment state."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

W = Path(__file__).resolve().parent
R = W.parents[1]
P = W / 'planning-01'
O = R / 'docs/evidence/serve-live-contract-cpu-20261121'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
first = read(W / 'shape-cpu-01/result.json')
fixed = read(W / 'shape-cpu-02/result.json')
host = read(W / 'host-integration-01/result.json')
generated = read(W / 'generator-compatibility-01/result.json')
assert first['status'] == 'BUILD_FAIL'
assert fixed['status'] == host['status'] == generated['status'] == 'PASS'
assert host['tests'] == 6 and host['protected_unchanged']
assert all(v['unchanged'] for v in generated['outputs'])
files = {}
for folder in ('shape-cpu-01', 'shape-cpu-02', 'host-integration-01',
               'generator-compatibility-01'):
    for p in sorted((W / folder).iterdir()):
        if p.suffix in {'.log', '.json', '.txt', '.stdout', '.stderr'}:
            files[folder + '/' + p.name] = p
for name in ('sources.json', 'conversations-source.json', 'plan.md',
             'identity-before-promotion.json', 'prepare_graph.py',
             'prepare_native_shape.py', 'prepare_vectors.py',
             'run_cpu_01.py', 'run_cpu_02.py', 'promote_contract.py',
             'oracle-01/sdk-concrete-cases.mts',
             'oracle-01/sdk-shape-cases.mts'):
    files['planning/' + name] = P / name
for name in ('inventory-before-review.json', 'inventory-reviewed.json',
             'host_integration_01.py', 'archive_contract_01.py',
             'retired-previous-01/plan.json', 'retired-previous-01/result.json',
             'retired-previous-01/restore.py', 'archive-attempt-01/result.json'):
    files['receipts/' + name] = W / name
for name in ('cmake/ChatProtocolIdentity.cmake', 'cmake/HostTestSources.cmake',
             'cmake/live_types.h.in', 'include/q4t/server/live_shape.h',
             'src/server/responses_item_shape.cpp',
             'src/server/contracts/openai_live_types_v1.json',
             'tests/server_live_shape_test.cpp',
             'tests/fixtures/live/sdk_vectors.json',
             'tools/serve_responses/generate_item_types.mjs',
             'tools/serve_responses/item_shape_vectors.mjs'):
    files['source/' + name] = R / name
sdk = Path(read(P / 'sources.json')['sdk_directory'])
files['reference/LICENSE.openai-js'] = sdk / 'LICENSE'
index = {}
assert not O.exists()
O.mkdir()
with tarfile.open(O / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        raw = path.read_bytes()
        index[name] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), 0o600, 0
        archive.addfile(info, io.BytesIO(raw))
(O / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
result = dict(status='PASS_LIVE_NATIVE_CONTRACT_CPU', distinct_tests=6,
              successful_test_executions=12, live_sdk_vectors=808,
              realtime_sdk_vectors=476, concrete_sdk_compiler_checks=3096,
              initial_link_failure_preserved=True,
              standalone_cpu_seconds=fixed['cpu_seconds'],
              host_cpu_seconds=host['cpu_seconds'],
              host_build_seconds=host['build_seconds'],
              host_binary_sha256=host['binary_sha256'],
              generator_compatibility=True, inventory_mutation_checks=22,
              live_business_accepted=False, new_gpu_starts=0,
              default_revision=426, default_changed=False,
              master_goal_active=True, archive_sha256=sha(O / 'evidence.tar.gz'))
(O / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))

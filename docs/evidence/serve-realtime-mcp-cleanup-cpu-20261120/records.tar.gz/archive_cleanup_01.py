from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-mcp-cleanup-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
first=read(W/'cleanup-cpu-01/result.json');r=read(W/'cleanup-cpu-02/result.json');assert first['status']=='FAIL' and r['status']=='PASS' and r['tests']==2
assert all(sha(R/p)==h for p,h in r['sources'].items())
assert sha(W/'cleanup-original-test.cpp')==first['sources']['tests/server_mcp_transport_test.cpp']
files={n:W/n for n in ['cleanup-plan.json','cleanup-repair-plan.json','cleanup-applied-repair-plan.json','cleanup-required.txt','cleanup-repair-required.txt','cleanup-original-test.cpp','archive_cleanup_01.py']}
for i in range(1,4):
 for n in [f'build_cleanup_0{i}.py',f'cleanup-build-0{i}/plan.json',f'cleanup-build-0{i}/result.json',f'cleanup-build-0{i}/build.log']:files[n]=W/n
 assert read(W/f'cleanup-build-0{i}/result.json')['warnings']==0
for i in range(1,3):
 for n in [f'run_cleanup_cpu_0{i}.py',f'cleanup-cpu-0{i}/result.json',f'cleanup-cpu-0{i}/stdout.txt',f'cleanup-cpu-0{i}/stderr.txt']:files[n]=W/n
files.update({'source/'+p:R/p for p in r['sources']});O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_REALTIME_MCP_CLEANUP_AND_AUXILIARY_SESSION_FAILURE_CPU',distinct_cases=10,case_executions=12,initial_passed=8,initial_failed=2,affected_recheck_passed=2,unchanged_passes_reused=8,cpu_seconds=first['seconds']+r['seconds'],builds_zero_warnings=3,intermediate_identical_relink_after_edit_assertion_no_cpu=True,binary_sha256=r['binary_sha256'],runtime_connected=False,gpu_actions=0,llm_requests=0,default_revision=396,default_unchanged=True,service_state='STOPPED',all_master_tasks_active=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP清理与辅助会话存储隔离：CPU

2026-11-20。10项不同CPU用例完成，累计12次执行/0.729秒。首次8通过、
2失败：夹具用了无效connector ID；另一夹具重复保存同一session，
原生幂等路径没有增加版本，因此并未制造预期冲突。修正为有效协议
枚举及实际lost状态变化，且要求revision确实+1，重验2项通过；8项
未改来源复用，原失败和源码保留。未降低权限或故障判断条件。

修正命令的精确替换断言曾失败，后续shell仍构建了相同源码，未运行
CPU；该中间构建也保留。实际修正后第三次构建完成，3次均零警告。

新增原worker已join后的原生清理：核对密封进程/response/原调用，
未发调用失败、未发布审批拒绝，真实已知结果保持；旧连接不能取消
已经由新response接续的审批。清理不会发tools/call或重启模型。

修复否决审批依赖可选路由的问题：路由消失仍可本地否决；批准和
执行继续必须有当前路由。额外验证了最终BindSession的实际存储CAS
冲突：原工具unknown终态已落盘且仍返回，维护错误单列，再次执行
不发送第二次调用。此前标为待验的这个具体组合现已有真实证据。

全部为本机CPU与原生HTTP/对象存储夹具，0模型/GPU。公开Realtime
MCP仍待会话接线和真实模型闭环；默认rev396 STOPPED。继续异步
审批/调用所有者、公开事件和取消/删除，再完成SDK业务与恢复。

[结果](acceptance.json) · [索引](index.json) · [失败、修复与源码](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text().replace('清理接线时发现拒绝审批仍依赖可选路由解析，已修正为本地否决；\n补原执行者清理和会话存储冲突隔离，冻结10项CPU/120秒待验。','[清理与辅助会话存储10项CPU](evidence/serve-realtime-mcp-cleanup-cpu-20261120/README.md)\n完成：8项首轮通过、2项夹具修正后通过，原失败保留。失路由仍可\n否决审批；旧连接不能取消新执行者，会话存储冲突保留已落盘终态。');p.write_text(s)
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[清理/辅助失败10项CPU完成](evidence/serve-realtime-mcp-cleanup-cpu-20261120/README.md)：\n首轮8通过/2失败，修正无效connector枚举及没有实际变化的CAS夹具，\n2项重验通过，8项复用；累计12次执行/0.729秒。原失败保留，中间\n替换断言失败后的同源码构建也记录，未追加CPU。最终会话存储冲突\n的实际故障分支已覆盖，继续公开会话集成；0模型/GPU、默认保持。\n''')
p=R/'docs/log/2026-11-20.md';p.write_text('''## MCP清理与辅助会话存储隔离10项CPU完成

日期：2026-11-20。

做了什么：[10项不同用例](../evidence/serve-realtime-mcp-cleanup-cpu-20261120/README.md)
首轮8通过/2失败，修正无效connector ID和未实际改版本的CAS夹具后
2项通过，8项复用。原失败保留；替换断言失败后的相同源码构建未
运行CPU，也一并记录。3次构建零警告，累计12用例执行/0.729秒。

为什么：可选路由失效不能阻止本地否决，原worker退出后的清理不能
取消新审批接续者；最终会话存储冲突也不能丢已落盘工具终态或重放。
实际冲突路径现已补齐，不再只是记录待验。

下一步：异步会话调用所有者、审批事件和公开接线，继续SDK业务、
真实模型工具闭环及恢复。默认rev396 STOPPED，0模型/GPU，总目标active。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m['state']='native_execution_cleanup_and_auxiliary_failure_cpu_accepted_session_integration_next';m['cleanup_cpu']=a;m['cleanup_evidence']='evidence/serve-realtime-mcp-cleanup-cpu-20261120/README.md';m['execution_remaining']=['Connect asynchronous call ownership to public Realtime session and actual model bindings','Complete SDK, real model tool loop, recovery and usable delivery'];save(p,d)
print(json.dumps(a))

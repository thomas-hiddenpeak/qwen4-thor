new observed value

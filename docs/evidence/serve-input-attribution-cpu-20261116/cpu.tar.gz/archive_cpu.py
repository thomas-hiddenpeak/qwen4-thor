import hashlib,json,re,subprocess,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
required=(W/'required-01.txt').read_text().splitlines()
assert len(required)==18
host=(W/'host-test-01.stdout').read_text();assert '18 tests, 18 passed, 0 failed, 0 skipped' in host
assert 'Ran 5 tests' in (W/'python-contracts-01.stderr').read_text() and '\nOK' in (W/'python-contracts-01.stderr').read_text()
assert json.loads((W/'differential-01/result.json').read_text())['passed']
stems=['host-build-01','host-test-01','engine-build-01','application-generate-01','generated-01','application-check-01','generated-check-01','source-check-01','python-contracts-01','differential-01']
for stem in stems:
 d=json.loads((W/(stem+'.json')).read_text());assert d['exit_code']==0 and d['default_unchanged']
 if 'build' in stem:
  assert not re.search(r'\bwarning:|\berror:',(W/(stem+'.stdout')).read_text()+(W/(stem+'.stderr')).read_text())
save(W/'generation-source-selection.json',dict(kind='operator_observation_of_failed_preparation_command',argv=['python3','-B','tools/serve_responses/build_contract.py','--types','.q4t-work/serve-responses-20261108/application-types.json'],exit_code=1,diagnostic="KeyError: 'compacted_response'",resolution='Use current published graph with matching recorded SHA from docs/evidence/serve-input-tokens-cpu-20261110/application-types.json; correct stale README; no runtime or test oracle changed'))
e=R/'docs/evidence/serve-input-attribution-cpu-20261116';e.mkdir()
files=[]
for stem in stems:
 for suffix in ('json','stdout','stderr'):files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for p in (W/'differential-01').iterdir():
 if p.is_file():files.append((p,'differential/'+p.name))
for n in ('freeze-01.json','freeze-02.json','required-01.txt','cases-01.txt','run.py','generation-source-selection.json','archive_cpu.py'):files.append((W/n,n))
for p,n in files:assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),n
with tarfile.open(e/'cpu.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda v:v[1]):t.add(p,arcname=n)
binary=R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t'
summary=dict(status='PASS_TARGETED_CPU',cpp_tests=18,schema_client_driver_tests=5,native_schema_cases=16,source_anchors=715,source_negative_controls=7,binary_sha256=sha(binary),zero_warning_builds=True,default_revision=158,default_unchanged=True,gpu_runs=0,business_pending=True,master_complete=False,archive_sha256=sha(e/'cpu.tar.gz'))
save(e/'acceptance.json',summary)
(e/'README.md').write_text('''# 输入归属、实际档位与默认合同：针对性 CPU 通过

2026-11-16，18项C++、5项schema/客户端/驱动、16项schema与原生解析
对照通过。715来源锚点/7负控、公开生成物一致性检查通过，主机/
引擎/probe零警告。候选引擎 `'''+summary['binary_sha256']+'''`。

覆盖128个Unicode字符/null、客户端作用域摘要且不进入提示、日志写入
失败不影响结果、JSON/SSE各片段实际default档位、私有存储与隔离、
Responses新medium缺省、旧queued有效effort和原请求/事件保持。
旧129—4096字符归属只凭原请求/快照/两事件一致恢复；错配/超限不执行。
现有pro queued与namespace恢复也通过，未重放started任务。

旧README指向缺少compact/input_tokens的类型图，准备生成时报KeyError；
改用与当前发布SHA一致的归档图并修正文档，原观察记录保留。
应用schema内嵌Chat流式定义同步补入上阶段padding，实际生成结构差异已核对。

本组为非性能改动，0GPU；rev158默认未改，尚未业务验收/发行。
下一步冻结最多1启动/6生成/900秒实际JSON/SSE、文档工具/SHA续答、
请求归属和存储闭环；全部master继续，不以CPU通过代替总任务完成。
''')
# PR31 final-head receipt is independent of this candidate.
e=R/'docs/evidence/serve-pr31-merged-20261116';e.mkdir()
for n in ('before.json','after.json','merge.stdout','merge.stderr'):(e/n).write_bytes((W/'pr31-merge'/n).read_bytes())
d=json.loads((e/'after.json').read_text());assert d['state']=='MERGED'
for tip in (d['headRefOid'],d['mergeCommit']['oid']):subprocess.run(['git','merge-base','--is-ancestor',tip,'origin/main'],cwd=R,check=True)
save(e/'ancestry.json',dict(head=d['headRefOid'],merge=d['mergeCommit']['oid'],origin_main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=R,text=True).strip(),both_ancestors=True))
(e/'README.md').write_text('''# PR31 已实际合 main

精确head `3b37dabf2a53927454544b1472d50eab6aa2921a` 两组host-contracts
成功，PR31于2026-11-16T10:24:09Z实际合main，合并提交
`8015dbc82a1e95ded758bfda4cf867410effbbec`。已fetch并验证head及merge
均在origin/main中。rev158 Chat样式/padding/迁移及可回退发行进入主线。

下一组归属/tier/Responses默认改动保留在当前工作树，未混入本PR。
活动分支和证据路径继续使用；默认/GPU未改变，全部master继续。
''')
print(json.dumps(summary))

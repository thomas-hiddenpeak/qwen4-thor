import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'client-business-03';O=R/'docs/evidence/serve-live-close-health-original-20261121';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
result=read(P/'result.json');cleanup=read(P/'cleanup.json');plan=read(P/'plan.json');sdk=read(P/'client.sdk.json');assert result['status']=='FAIL' and cleanup['remaining']==[] and cleanup['model_exit']==0
assert sdk['status']=='PASS' and sdk['close_code']==1000 and 'actual speech backend health' in result['error']
queries=[json.loads(v) for v in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(q['status']=='OK' and q['returncode']==0 for q in queries)
files={}
for n in ['counts.json','result.json','cleanup.json','before.json','live-drained.json','final-drained.json','final-config.http.json','final-config.wire','core-after.wire','query-fixture.json','query.pcm','observation.json','client.events.jsonl','client.sdk.json','client.stderr','model.log','lease/exit.json','lease/nvml-queries.jsonl']:
 files['original/'+n]=(P/n).read_bytes()
for n in ['src/server/chat_tts_backend.cpp','src/server/asr_service.cpp','src/server/live_audio_input.cpp','src/server/realtime_transcription_session.cpp']:
 files['original-source/'+n]=(R/n).read_bytes()
for p in sorted((R/'tools/serve_live').glob('*')):
 if p.is_file():files['original-source/'+str(p.relative_to(R))]=p.read_bytes()
files['driver/archive_client_failure_03.py']=Path(__file__).read_bytes();idx={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o600;i.mtime=0;t.addfile(i,io.BytesIO(b));idx[n]=dict(sha256=sha(b),bytes=len(b))
summary=dict(status='ORIGINAL_FAIL_FINAL_HEALTH_ASSERTION',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],plan_sha256=sha((P/'plan.json').read_bytes()),actual_model_starts=1,actual_admitted_work=4,alpha_asr_frontend_admitted=3,gamma_core_admitted=1,seconds=result['seconds'],sdk_protocol='PASS',quality='ASR_QUERY_AND_PROJECT_VERSION_AND_CORE_PASS',normal_close=1000,asr_state='metadata_ready',tts_state='ready',default_unchanged=True,environment_abort=False,nvml_queries=len(queries),all_nvml_queries_ok=True,cleanup_confirmed=True,main_not_delivered=True,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
(O/'index.json').write_text(json.dumps(idx,indent=2)+'\n');(O/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(O/'README.md').write_text('''# Live第三轮原始结果：最终健康断言失败

原始驱动结果与租约命令结果仍为FAIL/COMMAND_FAILED。实际ASR、客户端
委派/真实项目资料读取与回填、语音rev426、session.closed/1000关闭以及
关闭后的普通Chat=42均通过。alpha实际准入3、结算1730 tokens，无额外
尾部ASR，预留归零。共1启动/4实际工作/64.040秒，61次NVML正常，
资源和租约清理完成，默认不变。

失败位置是最终健康检查错误地要求两种语音模型都常驻ready。源码
`ActivateAuxiliaryFamily(true)`在TTS前释放ASR权重，`AsrHealth::Released`
将它置为metadata_ready/device_bytes=0，保留有效元数据。本轮ASR/TTS的
reason均none，load/compute failures均0，cleanup pending为false。

这份原始结果不改标。修正检查器后，必须独立复核已保存的完整业务、
源码身份、真实资源结算与健康记录，并补反例；复核不需要另跑GPU，
也不把COMMAND_FAILED伪造成COMPLETED。总计划与Live后续任务继续。

原始来源/日志见[evidence.tar.gz](evidence.tar.gz)、[索引](index.json)及
[结果](result.json)。不包含私钥或客户/网关配置。
''')
print(json.dumps(summary,ensure_ascii=False))

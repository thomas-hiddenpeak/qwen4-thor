from pathlib import Path
import json,shlex,subprocess,hashlib,time,copy
W=Path(__file__).parent.resolve();R=W.parents[2];B=R/'.q4t-work/serve-file-search-20261112/host';S=W.parent/'profiles-01'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
link=shlex.split((B/'CMakeFiles/q4t_host_tests.dir/link.txt').read_text());objects=[str((B/n).resolve()) for n in link if n.endswith('.o') and '/src/' in n];tail=link[link.index('-o')+2:]
cmd=['g++-14','-std=c++23','-O2','-Wall','-Wextra','-Werror','-DQ4T_ENABLE_XGRAMMAR=1','-I'+str(R),'-I'+str(R/'include'),str(W/'probe.cpp'),*objects,*tail,'-o',str(W/'probe')]
save(W/'build-plan.json',dict(command=cmd,objects={n:sha(n) for n in objects},probe_sha256=sha(W/'probe.cpp'),gpu_starts=0));start=time.monotonic()
r=subprocess.run(cmd,cwd=B,capture_output=True,timeout=120);(W/'build.stdout').write_bytes(r.stdout);(W/'build.stderr').write_bytes(r.stderr);assert r.returncode==0 and b'warning:' not in r.stderr,r.stderr[-3000:]
policy='逐字抄写本条用户消息中第一段语音的原始转写，仅输出其中第一个完整句子一次。保持原语言，不翻译，不包含前后的文字说明或第二段语音，不增加任何解释。如果收到的是原生空闲未检测到语音的提示，只输出 READY。'
records={}
for mode,label in [('manual','mixed'),('vad','vad_auto')]:
 raw=S/('primary-duplex-'+mode+'.sdk.json');value=json.loads(raw.read_text());events=value['events'];response=next(x['response'] for x in value['responses'] if x['label']==label)
 at=next(i for i,e in enumerate(events) if e['type']=='response.created' and e['response']['id']==response['id'])
 settings=[e['session'] for e in events[:at] if e['type']=='session.updated'][-1]
 item=next(e['item'] for e in events[:at] if e['type']=='conversation.item.done' and (e['item'].get('id')=='mixed_input' if mode=='manual' else e['item'].get('role')=='user'))
 completed=[e for e in events if e['type']=='conversation.item.input_audio_transcription.completed' and e['item_id']==item['id']]
 client=[json.loads(l)['event'] for l in (S/('primary-duplex-'+mode+'.events.jsonl')).read_text().splitlines() if json.loads(l)['direction']=='client']
 request=next(e['response'] for e in client if e['type']=='response.create' and e['response'].get('metadata',{}).get('acceptance_case')==label) if mode=='manual' else {}
 fixture=dict(settings=settings,response=request,item=item,completions=completed)
 save(W/(label+'-before.fixture.json'),fixture)
 changed=copy.deepcopy(fixture);changed['settings']['instructions']=policy
 if mode=='manual': changed['response']['instructions']=policy
 save(W/(label+'-after.fixture.json'),changed)
 variants={}
 for phase in ('before','after'):
  f=W/(label+'-'+phase+'.fixture.json');r=subprocess.run([str(W/'probe')],input=f.read_bytes().replace(b'\n',b' '),capture_output=True,timeout=30)
  assert r.returncode==0,(r.returncode,r.stderr);v=json.loads(r.stdout);save(W/(label+'-'+phase+'.json'),v);(W/(label+'-'+phase+'.prompt')).write_text(v['prompt']);variants[phase]=v
 before,after=variants['before'],variants['after'];expected=copy.deepcopy(before)
 old=before['request']['messages'][0]['content'];expected['request']['messages'][0]['content']=policy;expected['prompt']=before['prompt'].replace(old,policy)
 assert before['prompt'].count(old)==1 and expected==after
 assert before['request']['temperature']==1 and 'REFERENCE_ONLY_NEVER_SPOKEN' not in before['prompt']
 assert before['prompt'].count('甚至出现交易几乎停滞的情况。')==(2 if mode=='manual' else 1)
 records[label]=dict(raw_sha256=sha(raw),response_id=response['id'],actual=response['output'][0]['content'][0]['text'],prompt_sha256={p:sha(W/(label+'-'+p+'.prompt')) for p in variants},only_caller_instructions_change=True,actual_asr_preserved=True,not_live_prompt_capture=True)
save(W/'review.json',dict(status='PASS_PRODUCTION_PROMPT_RECONSTRUCTION',records=records,seconds=time.monotonic()-start,gpu_starts=0,model_quality_failure_preserved=True,policy=policy));print(json.dumps(dict(status='PASS',seconds=time.monotonic()-start,labels=list(records))))

from pathlib import Path
import json,hashlib,subprocess,time,os,re
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profile-followup-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
files=['tools/serve_recovery/'+p.name for p in (R/'tools/serve_recovery').glob('*duplex*.py')]+['tools/serve_realtime/'+n for n in ('duplex_sdk.mjs','duplex_checks.py','duplex_quality_checks.py')]+['tools/serve_audit/inventory.json','.github/workflows/host-checks.yml']
commands=[['python3','-B','-m','unittest','-v','tools.serve_recovery.test_profile_duplex_followup','tools.serve_recovery.test_profile_duplex'],['node','--check','tools/serve_realtime/duplex_sdk.mjs'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
plan=dict(scope='Only original two model quality failures, actual wire/accounting counterexamples, caller-only task clarification and immutable evidence; no model or runtime changes',limits=dict(tests=21,seconds=120,source_counterexamples=20,gpu_starts=0),commands=commands,sources={n:sha(R/n) for n in files},protected={n:sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')})
save('plan.json',plan);started=time.monotonic();runs=[];status='PASS'
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=max(.1,120-(time.monotonic()-started)),env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O)))
 (O/f'{i}.stdout').write_bytes(r.stdout);(O/f'{i}.stderr').write_bytes(r.stderr);runs.append(dict(command=cmd,exit_code=r.returncode))
 if r.returncode:status='FAIL';break
match=re.search(r'Ran (\d+) tests',(O/'0.stderr').read_text());tests=int(match[1]) if match else 0
if tests!=21:status='FAIL'
assert all(sha(R/n)==h for n,h in plan['protected'].items())
result=dict(status=status,tests=tests,seconds=time.monotonic()-started,commands=runs,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

from pathlib import Path
import json,hashlib,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OLD=W/'profile-followup-cpu-01';O=W/'profile-followup-cpu-02';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
old=json.load(open(OLD/'plan.json'));result=json.load(open(OLD/'result.json'))
assert result['tests']==21 and result['commands'][0]['exit_code']==0 and result['commands'][1]['exit_code']==0
excluded={'tools/serve_audit/inventory.json','.github/workflows/host-checks.yml','tools/serve_recovery/profile_duplex_followup_targeted.py'}
assert all(sha(R/n)==h for n,h in old['sources'].items() if n not in excluded)
assert (R/'tools/serve_recovery/profile_duplex_followup_targeted.py').read_text()==(OLD/'original-driver.py').read_text().replace("profile-followup-cpu-01'","profile-followup-cpu-02'")
plan=dict(scope='Fix an extra source anchor outside the global collector, retain it in the scoped review; fix CI continuation. Reuse all 21 unchanged passing Python cases and SDK syntax.',sources={n:sha(R/n) for n in old['sources']},protected=old['protected'],original_sha256=sha(OLD/'result.json'),reused_python_cases=21,gpu_starts=0)
save('plan.json',plan);start=time.monotonic()
r=subprocess.run(['python3','-B','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,capture_output=True,timeout=120);(O/'source.stdout').write_bytes(r.stdout);(O/'source.stderr').write_bytes(r.stderr)
# Parse the actual CI command containing the new module, without executing its full matrix.
lines=(R/'.github/workflows/host-checks.yml').read_text().splitlines();at=next(i for i,l in enumerate(lines) if 'tools.serve_recovery.test_profile_duplex_followup' in l)
a=at
while 'python3 -B -m unittest' not in lines[a]:a-=1
b=at
while lines[b].rstrip().endswith('\\'):b+=1
script='\n'.join(l.strip() for l in lines[a:b+1])+'\n'
(O/'ci-command.sh').write_text(script)
check=subprocess.run(['bash','-n'],input=script.encode(),capture_output=True,timeout=10);(O/'ci.stderr').write_bytes(check.stderr)
assert 'tools.serve_recovery.test_profile_duplex_followup' in script and 'tools.serve_recovery.test_profile_speech_cancel' in script
assert all(sha(R/n)==h for n,h in old['protected'].items())
status='PASS' if r.returncode==check.returncode==0 else 'FAIL';value=dict(status=status,seconds=time.monotonic()-start,source_counterexamples=20,ci_syntax=check.returncode,reused_python_cases=21,new_python_executions=0,gpu_starts=0,default_unchanged=True,original_gate_failure_preserved=True)
save('result.json',value);print(json.dumps(value));raise SystemExit(status!='PASS')

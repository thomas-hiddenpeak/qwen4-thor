from pathlib import Path
import json,hashlib,pprint,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profiles-01';P=W/'profile-prompt-01'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
sys.path.insert(0,str(R))
from tools.serve_recovery import ledger
review={n:sha(O/n) for n in ['plan.json','result.json','cleanup.json','lease/exit.json','lease/nvml-queries.jsonl','lease/events.jsonl','primary-duplex-observed.json','primary-realtime-business.json','primary-semantic-business.json','primary-capabilities.json','primary-config.json','primary-realtime-entry-cleanup.json','primary-semantic-entry-cleanup.json','primary-duplex-entry-cleanup.json']}
review.update({'prompt/'+n:sha(P/n) for n in ['probe.cpp','build-plan.json','review.json','mixed-before.json','mixed-after.json','vad_auto-before.json','vad_auto-after.json']})
requests={label:{variant:json.load(open(P/(label+'-'+variant+'.json')))['request'] for variant in ('before','after')} for label in ('mixed','vad_auto')}
s=(R/'tools/serve_recovery/profile_duplex_followup_source.py')
assert not s.exists()
s.write_text('"""Frozen original failures and production-planner reconstruction, no GPU oracle."""\n\nREVIEW = '+pprint.pformat(review,sort_dicts=True,width=88)+'\n\nORIGINAL = '+repr(ledger.digest(json.load(open(O/'primary-duplex-observed.json'))))+'\n\nREQUESTS = '+pprint.pformat(requests,sort_dicts=False,width=88)+'\n')
print('frozen',len(review),'source files')

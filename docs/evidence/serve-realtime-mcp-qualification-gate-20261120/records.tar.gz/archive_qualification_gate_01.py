from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-mcp-qualification-gate-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
cpu=read(W/'qualification-cpu-03/result.json');assert cpu['status']=='PASS'
files={'archive_qualification_gate_01.py':Path(__file__),'qualify_profiles_01.py':W/'qualify_profiles_01.py'}
for n in ('plan.json','result.json','stdout.txt','stderr.txt'):files['qualification-cpu-03/'+n]=W/'qualification-cpu-03'/n
for p in (W/'qualification-cpu-03/original-source').rglob('*'):
 if p.is_file():files['original-source/'+str(p.relative_to(W/'qualification-cpu-03/original-source'))]=p
for n,h in cpu['sources'].items():assert sha(R/n)==h;files['source/'+n]=R/n
for n in ('plan.json','failure.json','environment-composition.json'):files['qualified-profiles-01/'+n]=W/'qualified-profiles-01'/n
partials={p.name:dict(bytes=p.stat().st_size,sha256=sha(p),accepted=False) for p in (W/'qualified-profiles-01/qualified').glob('*.json')}
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz'),private_unaccepted_partial_records=partials))
value=dict(status='PASS_SHARED_MCP_CAPABILITY_GATE_CPU',tests=11,seconds=cpu['seconds'],original_qualification_failure_preserved=True,original_registry_issued=False,new_qualification_issued=False,gpu_actions=0,runtime_changed=False,default_unchanged=True);save(O/'acceptance.json',value)
(O/'README.md').write_text('''# 完整资格能力门遗漏修复

2026-11-20。首次生成完整MCP主轻资格时，通用conversation_enabled仍
要求mcp出现在pending_execution并遗漏已实现声明，拒绝新真实能力。
原失败保留，未签发registry，两个部分文件不获准使用。专用检查通过
不能替代整条交付链检查，本次没有删除MCP目标或绕过能力校验。

补共用能力声明及严格类型验证后，11项针对性CPU/0.615秒通过：实际
新声明、旧v20、更早会话、同来源复用和错误类型/重放声明反例。之前
42项组件证据按身份复用；运行时没有改变，新增GPU 0。旧未验文件的
摘要登记在索引，本机原件保留。

下一步重新离线生成资格，随后服务恢复/发行；默认rev396保持，
总目标active。[结果](acceptance.json) · [索引](index.json) ·
[原失败、源码与检查](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text().replace('冻结11项针对性CPU后重新离线生成；不重跑GPU，恢复/发行继续。','[11项针对性CPU通过](evidence/serve-realtime-mcp-qualification-gate-20261120/README.md)，\n接着重新离线生成；不重跑GPU，恢复/发行继续。');p.write_text(s)
p=R/'docs/log/2026-11-20.md';p.write_text('''## 共用MCP能力门修复通过针对性CPU

日期：2026-11-20。

做了什么：[11项CPU通过](../evidence/serve-realtime-mcp-qualification-gate-20261120/README.md)，
0.615秒；原资格失败及未获准部分文件摘要保留，未签发registry。
真实新声明与旧版本共存验证通过，严格bool/int和重放声明反例覆盖。

为什么：修复完整资格链发现的真实缺口，不改GPU运行时或删减能力。

下一步：重新离线签发主轻资格，接着同能力封包与原生恢复短验；
总目标active，默认保持。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['realtime_progress']['mcp_20261120'].update(state='shared_capability_gate_repaired_retrying_offline_qualification',qualification_gate_cpu=value,qualification_gate_evidence='evidence/serve-realtime-mcp-qualification-gate-20261120/README.md');save(p,d)
print(json.dumps(value))

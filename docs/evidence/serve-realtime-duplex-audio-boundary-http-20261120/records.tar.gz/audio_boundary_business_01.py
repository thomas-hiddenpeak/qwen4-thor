"""Two-profile native duplex repair, no unrelated backend or full matrix.

One strict lease, at most two models / 32 jobs / four WSS / 1200 seconds.
Keep every quality result and inspect both profiles once; never retry a task.
This driver records business evidence, not a managed qualification certificate.
"""
import argparse
import copy
import fcntl
import json
from pathlib import Path
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
from tools.serve_recovery import profile_duplex_targeted as prior
from tools.serve_recovery import profile_duplex as duplex
from tools.serve_recovery import profile_duplex_evidence as evidence
from tools.serve_service.package import read, require, save, sha

WORK = Path(__file__).parent
full, encrypted = prior.full, prior.encrypted
LIMITS = dict(starts=2, chats=32, controls=1200, seconds=1200,
              websocket_sessions=4, ingress_starts=2)
FORMAT = 'q4t-duplex-audio-boundary-business-v1'
BINARY = '485a38a3a998e03f86ac0897fe712631a2a23b56f18423c56e400d274faf2dbb'
PROTOCOL = '4cbfc8b3998463b7d3487da34de2f831b989ea883511ec14beded0dd65c97f92'
SUCCESS = 'PASS_AUDIO_BOUNDARY_BUSINESS'


def check_plan(plan):
    require(plan['targeted_format'] == FORMAT and plan['limits'] == LIMITS and
            plan['requests'] == {} and plan['automatic_retries'] is False and
            plan['binary_sha256'] == BINARY and
            plan['identity']['protocol_sha256'] == PROTOCOL and
            plan['planned'] == {k:v for k,v in LIMITS.items() if k not in ('seconds','controls')},
            'frozen repair identity or budget changed')
    original = read(WORK/'profiles-03/plan.json')
    for key in ('profiles', 'native_assets', 'model_assets'):
        require(plan[key] == original[key], 'repair changed backend/capacity')
    require(plan['base']['settings'] == original['base']['settings'] and
            plan['duplex']['instruction_policy'] == 'original_language_v1',
            'repair changed sampling/backend settings')
    for name,h in plan['reviewed_sources'].items():
        require(sha(ROOT/name) == h, 'reviewed compiled repair source changed')


def prepare(out):
    require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),
            'commit the reviewed repair before running')
    cpu = WORK/'audio-boundary-cpu-01'
    require(read(cpu/'result.json')['status'] == 'PASS', 'repair CPU incomplete')
    for name,h in read(cpu/'plan.json')['sources'].items():
        require(sha(ROOT/name) == h, 'repair CPU source drift')
    plan = read(WORK/'profiles-03/plan.json')
    out.mkdir(mode=0o700, parents=True)
    build = ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
    base,binding = full.candidate_build_base(plan['base'],build/'q4t',build)
    current = read(WORK/'audio-boundary-runtime-01/plan.json')['sources']
    current.update(read(build/'generated/q4t/server/chat_protocol_sources.json'))
    old = read(WORK/'profile-source-04/review.json')
    old = {**old['unchanged'],**old['added'],
           **{n:v['after'] for n,v in old['changed'].items()}}
    changed = {n:dict(before=old[n],after=h) for n,h in current.items()
               if n in old and h != old[n]}
    added = {n:h for n,h in current.items() if n not in old}
    require(set(changed) == {'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake',
        'cmake/HostTestSources.cmake','src/server/chat_audio_inputs.cpp',
        'src/server/realtime_conversation.cpp'} and set(added) == {
        'include/q4t/server/audio_transcript.h','src/server/audio_transcript.cpp'} and
        not set(old)-set(current), 'unreviewed runtime change')
    save(out/'source-review.json',dict(changed=changed,added=added,
        unchanged={n:h for n,h in current.items() if old.get(n)==h},
        original_stage_status='FAILED',new_business_required=True))
    plan.update(targeted_format=FORMAT, limits=LIMITS, output=str(out),
        port=18548, operations_port=18549, scope=__doc__, binary=str(build/'q4t'),
        binary_sha256=BINARY, base=base, candidate_identity=binding,
        identity=dict(plan['identity'],binary_sha256=BINARY,protocol_sha256=PROTOCOL),
        reviewed_sources=current, source_commit=subprocess.check_output(
            ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        planned={k:v for k,v in LIMITS.items() if k not in ('seconds','controls')})
    plan['sources'] = {n:sha(ROOT/n) for n in plan['sources']}
    plan['sources'].update({str(Path(__file__).resolve()):sha(Path(__file__))})
    plan['sources'].update({str(cpu/n):sha(cpu/n) for n in ('plan.json','result.json')})
    plan['sources'].update({str(out/'source-review.json'):sha(out/'source-review.json')})
    plan['sources'].update(current)
    plan['duplex'] = duplex.prepare(WORK/'idle-business-01/run/plan.json',out,18550,plan['sdk'])
    plan['duplex']['instruction_policy'] = 'original_language_v1'
    plan['sources'].update(plan['duplex']['files'])
    check_plan(plan)
    for name,h in plan['protected'].items():require(sha(name)==h,'default changed')
    save(out/'plan.json',plan)
    print(json.dumps(dict(plan=str(out/'plan.json'),limits=LIMITS)),flush=True)


class Stage(prior.Stage):
    limits = LIMITS
    success_status = SUCCESS

    def __init__(self,plan):
        check_plan(plan)
        encrypted.Stage.__init__(self,plan)
        self.counts.update(websocket_sessions=0,ingress_starts=0)
        self.quality = []

    def profile_business(self):
        sessions = duplex.run_sessions(self,('manual','vad'))
        value = dict(format=evidence.FORMAT,
                     source=self.plan['duplex']['source'],sessions=sessions)
        duplex.save_observed(self.out/(self.profile_name+'-duplex-observed.json'),value)
        def quality(mode,rows):
            self.quality.extend(dict(profile=self.profile_name,mode=mode,**r) for r in rows)
        evidence.original_business(value,quality_check=quality)
        save(self.out/'quality.json',self.quality)

    def business(self):
        full.Stage.business(self)
        require(all(r['status']=='PASS' for r in self.quality),
                'audio boundary original model quality failed')


def finalize(out):
    plan=read(out/'plan.json');check_plan(plan);result=read(out/'result.json')
    require(result['status']==SUCCESS and result['binary_sha256']==BINARY and
        0<result['seconds']<=LIMITS['seconds'] and
        set(result['counts'])==set(LIMITS)-{'seconds'} and
        all(type(result['counts'][k]) is int and
            result['counts'][k]==LIMITS[k] for k in LIMITS if k not in ('seconds','controls')) and
        type(result['counts']['controls']) is int and result['counts']['controls']<=1200,
        'bounded two-profile business incomplete')
    for name,h in {**plan['sources'],**plan['protected'],**plan['native_assets']}.items():
        require(sha(ROOT/name)==h,'postflight source drift')
    lease=out/'lease';queries=[json.loads(l) for l in (lease/'nvml-queries.jsonl').read_text().splitlines()]
    clean=[read(out/n) for n in ('primary-cleanup.json','cleanup.json')]
    environment=full.environment(read(lease/'exit.json'),queries,clean)
    events=[json.loads(l) for l in (lease/'events.jsonl').read_text().splitlines()]
    require(events[-1]['event']=='lease_released' and not any(e.get('conflicts') for e in events),
            'strict lease cleanup or competition')
    for name in ('primary','light'):
        entry=read(out/(name+'-duplex-entry-cleanup.json'))
        require(entry['exit_code']==0 and entry['port_released'],'entry not cleaned')
        evidence.business(duplex.read_observed(out/(name+'-duplex-observed.json')))
    full.background.probe_ports((plan['port'],plan['operations_port'],18550))
    guard=encrypted.foreground.base.lifecycle.guard
    with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    save(out/'acceptance.json',dict(status=SUCCESS,environment=environment,
        counts=result['counts'],seconds=result['seconds'],default_unchanged=True,
        qualification_issued=False,managed_recovery=False,original_failures_preserved=True))


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('prepare','run','finalize'))
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output.resolve()
    require(out.is_relative_to(WORK.resolve()),'private stage directory required')
    if a.mode=='prepare':prepare(out)
    elif a.mode=='finalize':finalize(out)
    else:
        def interrupted(_signum,_frame):raise TimeoutError('bounded repair interruption')
        signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGALRM,interrupted)
        signal.alarm(LIMITS['seconds'])
        try:Stage(read(out/'plan.json')).run()
        finally:signal.alarm(0)

import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-live-fixture-cpu-20261121';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cpu=read(W/'fixture-cpu-01/result.json');driver=read(W/'fixture-driver-cpu-01/result.json');built=read(W/'native-build-03/result.json')
assert cpu['status']==driver['status']=='PASS' and built['status']=='BUILD_PASS'
assert cpu['sources_unchanged'] and cpu['protected_unchanged'] and built['sources_unchanged'] and built['default_unchanged']
files={}
for folder in ['fixture-plan-01','fixture-cpu-01','fixture-driver-cpu-01']:
 for p in sorted((W/folder).iterdir()):
  if p.is_file():files[folder+'/'+p.name]=p.read_bytes()
for n in ['plan.json','result.json','0.stdout','0.stderr','1.stdout','1.stderr']:
 files['native-build-03/'+n]=(W/'native-build-03'/n).read_bytes()
for n in ['fixture_cpu_01.py','fixture_driver_cpu_01.py','build_native_03.py','archive_fixture_cpu_01.py','fixture-inventory-before.json','fixture-inventory-reviewed.json']:
 files['driver/'+n]=(W/n).read_bytes()
for n,h in (read(W/'fixture-cpu-01/plan.json')['sources']|driver['sources']).items():
 raw=(R/n).read_bytes();assert sha(raw)==h,n;files['accepted/'+n]=raw
index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as archive:
 for n,raw in sorted(files.items()):
  index[n]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(raw),0o600,0;archive.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
summary=dict(status='PASS_LIVE_FIXTURE_CPU_PREPARATION',native_tests=21,new_native_tests=12,direct_protections=9,native_cpu=cpu,driver_cpu=driver,native_build=built,reviewed_sources=15,inventory_mutation_checks=28,new_gpu_starts=0,default_changed=False,real_fixture_business_pending=True,distinct_live_native_tests=130,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',summary)
(O/'README.md').write_text('''# Live原生音频片段播放CPU准备

21项原生CPU通过：12新增、9直接保护。真实队列/线程/LiveSession组合
验证完整PCM24校验后才打断、四种协商输出格式、极短音频不补样、
每tick有界且按源时长播放、实际借用者释放后才输出，以及原取消用量
保持。播放中丢弃新输入且不重放，保留用户静音，前缀半样本不跨播放
拼接；上下文追加原子拒绝，确认计时器暂停调度。正常关闭排空播放，
断线/失败不发布played或closed成功。played只表示服务端队列排空。

输入处理器暂停新VAD/准入时，仍排空实际ASR借用者和输出；默认
Realtime路径保持。真实主入口为30秒最长片段和旧借用者清理保留45秒
关闭窗口，59分钟生命期及15秒输出仍落在原3600秒外层限制内。

宿主构建99.557秒零警告，21项0.364059秒。另5项专用驱动反例、SDK语法
和驱动解析通过（0.209438秒）；既有业务观察器、健康/等待逻辑按未变
SHA复用。实际引擎和入口正式构建零警告，精确身份/耗时见
[result.json](result.json)。15来源语义复核、28项清单反例通过。

累计130项不同原生Live CPU；模型回调仍为受控夹具。本组新增GPU0，
默认rev426保持，真实播放后资料查询闭环短验继续：严格同一租约、
1启动/1片段/1ASR+2前台+1普通Chat/600秒，不做性能矩阵。其他Live和
全部master任务继续，当前不宣称完整Live或新默认发行通过。

[原始构建/测试/来源](evidence.tar.gz)、[逐项SHA索引](index.json)。
''')
p=R/'docs/STATUS.md';s=p.read_text();old='Live音频fixture已进入实现：完整PCM24校验后才打断，复用原生格式\n转换器，按源音频时间播放；输入丢弃/静音保持、实际借用者排空、\n上下文原子拒绝及关闭/断线边界正成组接入。尚未构建或测试，未记通过。\n'
new='[Live音频片段21项CPU](evidence/serve-live-fixture-cpu-20261121/README.md)\n通过，另5项专用驱动反例通过；实际引擎构建零警告。累计130项不同\n原生Live CPU，播放/输入丢弃/静音保持/实际排空已准备，正在推进\n1启动/1片段/4工作/600秒真实SDK短验。默认未改，不把CPU当业务通过。\n'
assert old in s;p.write_text(s.replace(old,new,1))
p=R/'docs/log/2026-11-21.md';p.write_text('## Live音频片段21项CPU和正式构建通过\n\n日期：2026-11-21。做了什么：12项新增与9项直接保护全部通过，\n宿主构建99.557秒零警告，CPU执行0.364059秒；5项驱动反例/解析\n通过，未变观察器及等待检查按SHA复用。15来源语义复核、28项\n清单反例通过；实际引擎构建'+f"{built['seconds']:.3f}"+'秒零警告。为什么：播放、\n静音和取消必须绑定真实样本/线程，不能以事件形状代替执行。下一步：\n严格租约1启动/1片段/4工作/600秒，验证播放后真实资料查询恢复；\n默认未改，本组GPU新增0，总计划继续。\n\n'+p.read_text())
p=R/'docs/SERVE_LIVE_2026-11-21.md';p.write_text(p.read_text()+'\n[音频片段21项原生CPU](evidence/serve-live-fixture-cpu-20261121/README.md)通过，\n其中12新增，累计130项不同原生Live CPU；5项专用驱动反例和正式\n引擎构建通过。完整校验、所有权排空、输入丢弃/静音、上下文拒绝、\n自然播放与取消边界已实现；真实SDK播放后业务恢复短验继续。\n')
p=R/'docs/serve-master-goals-v2.json';master=read(p);live=master['native_live_20261121'];live.update(distinct_native_cpu_tests=130,fixture_cpu_tests=21,fixture_cpu_new=12,fixture_cpu_evidence='evidence/serve-live-fixture-cpu-20261121/README.md',fixture_state='native_cpu_and_build_pass_actual_sdk_business_pending');save(p,master)
print(json.dumps(dict(status=summary['status'],archive_sha256=summary['archive_sha256'],files=len(files))))

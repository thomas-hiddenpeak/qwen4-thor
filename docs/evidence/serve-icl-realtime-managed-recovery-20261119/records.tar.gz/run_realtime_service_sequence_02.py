"""Three bounded actual ICL/Realtime Guardian stages; separate full strict leases, stop on first failure."""
import hashlib,json,os,signal,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
protected=['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']
def defaults():return {n:sha(R/n) for n in protected}
F=W/'service-sequence-plan-02.json'
assert not F.exists()
assert shutil.disk_usage(W).free>=176*1024**2
frozen=dict(status='FROZEN_BEFORE_EXECUTION',previous_failure=dict(directory='retained-service-02',model_starts=1,http_requests=2,seconds=50.31709480518475,preserved=True),cumulative_limits=dict(model_starts=5,http_requests=65,realtime_tasks=5,seconds=1551),scope='Three separate complete strict leases: same ICL reference persists through native gateway and whole payload recovery. TLS gateway fault interrupts an actual unfinished continuous ASR stream; whole payload fault follows a completed settled ASR task with its socket still open. Recovery uses explicit new client connections, never automatic input replay. Verify original metrics, actual quota settlement, processed waveforms, isolation and resource cleanup. All previous native audio/input/Chat/voice obligations retained. No performance/full numerical/long stability matrix.',aggregate_limits=dict(model_starts=4,counted_http_requests=63,counted_model_work=68,websocket_sessions=5,cuda_probes=1,seconds=1500),stage_artifact_limit=32*1024**2,aggregate_artifact_limit=96*1024**2,min_free_before_stage=176*1024**2,initial_free=shutil.disk_usage(W).free,defaults=defaults(),stage_plan_hashes={n:sha(W/n/'plan.json') for n in ['retained-service-03','tls-service-03']},pending_version_plan=dict(scenario='tool_version',starts=2,chats=26,websocket_sessions=2,probes=1,seconds=600,depends_on='finalized retained-service-03 receipt'),driver_sha256=sha(Path(__file__)),automatic_request_retry=False)
save(F,frozen);records=[]
def call(label,command,seconds):
 start=time.monotonic();timed_out=False
 with (W/(label+'.stdout')).open('xb') as stdout,(W/(label+'.stderr')).open('xb') as stderr:
  child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=child.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 value=dict(label=label,command=command,returncode=code,seconds=time.monotonic()-start,timed_out=timed_out);records.append(value);save(W/'service-sequence-result-02.json',records);print(json.dumps(value),flush=True)
 if code or timed_out:
  print((W/(label+'.stderr')).read_text()[-2500:],flush=True);raise SystemExit(code or 1)
 return value

def run(name):
 out=W/name;plan=read(out/'plan.json');assert defaults()==frozen['defaults'];assert shutil.disk_usage(W).free>=frozen['min_free_before_stage']
 scope=dict(plan_sha256=sha(out/'plan.json'),limits=plan['limits'],max_artifact_bytes=frozen['stage_artifact_limit'],default_identity=frozen['defaults'],initial_free=shutil.disk_usage(W).free,strict_complete_stage_lease=True)
 save(out/'resource-scope.json',scope)
 command=['/usr/bin/python3','-B',str(R/'tools/evalscope/gpu_exclusive.py'),'--compute-backend','nvml','--inherit-lease','--output',str(out/'lease'),'--',*plan['command']]
 save(out/'lease-command.json',command)
 record=call(name+'-launch',command,plan['limits']['seconds']+60);save(out/'launch.json',record)
 result=read(out/'execution/result.json');print(json.dumps(dict(stage=name,status=result['status'],seconds=result['seconds'],counts=result['budget']['counts'])),flush=True)
 call(name+'-finalize',['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'finalize','--plan',str(out/'plan.json')],120)
 size=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert size<=frozen['stage_artifact_limit'];assert defaults()==frozen['defaults'];save(out/'resource-result.json',dict(status='PASS',artifact_bytes=size,default_unchanged=True,free=shutil.disk_usage(W).free));print(read(out/'decision.json')['acceptance'],flush=True)

for name in ['retained-service-03','tls-service-03']:run(name)
name='version-service-02'
command=['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'prepare','--scenario','tool_version','--package',str(W/'service-package-03/bundle'),'--output',str(W/name),'--retained',str(W/'retained-02/bundle'),'--release',str(W/'retained-service-03/service-release.json'),'--decision',str(W/'retained-service-03/decision.json'),'--separator-audio',str(R/'.q4t-work/serve-overlap-20261118/http-05/mixed.wav'),'--voice-fixtures',str(R/'.q4t-work/serve-custom-voices-20261118/voice-profiles-inputs-02/voices.json'),'--realtime-reference',str(W/'profiles-05/plan.json')]
call(name+'-prepare',command,120)
plan=read(W/name/'plan.json');assert plan['limits']==dict(starts=2,chats=26,probes=1,controls=2500,seconds=600,websocket_sessions=2)
save(W/'version-plan-binding-02.json',dict(plan_sha256=sha(W/name/'plan.json'),original_sequence_plan_sha256=sha(F)))
run(name)
total=sum(sum(p.stat().st_size for p in (W/n).rglob('*') if p.is_file()) for n in ['retained-service-03','tls-service-03','version-service-02']);assert total<=frozen['aggregate_artifact_limit'];save(W/'service-aggregate-resource-02.json',dict(status='PASS',artifact_bytes=total));print('ALL_THREE_FROZEN_ICL_REALTIME_STAGES_FINALIZED',flush=True)

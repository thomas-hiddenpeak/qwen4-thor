"""Losslessly retain duplicate historical test tools, not service binaries."""
from pathlib import Path
import hashlib,json,tarfile,os,stat,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'retained-cpu-fixture-binaries-01';assert not O.exists();O.mkdir();started=time.monotonic();root=R/'.q4t-work/serve-host-observation-20261104';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();canonical={name:root/'notification'/name for name in ['prometheus','promtool']};digests={n:sha(p) for n,p in canonical.items()};rows=[]
for name in canonical:
 for p in sorted((root/'cpu-fixtures').glob('tmp*/notify/'+name)):
  assert p.is_file() and not p.is_symlink() and sha(p)==digests[name];s=p.stat();assert s.st_uid==os.getuid() and s.st_nlink==1
  rows.append(dict(path=str(p),member=name,sha256=digests[name],bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns))
assert len(rows)==8 and sum(x['bytes'] for x in rows)<1300*1024**2
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:exe=os.readlink(proc/'exe');cmd=(proc/'cmdline').read_bytes()
 except (OSError,PermissionError):continue
 assert all(exe!=x['path'] and x['path'].encode() not in cmd for x in rows),'historical fixture tool still active'
plan=dict(scope='Only eight identical historical temporary CPU-fixture executables; canonical notification tools stay at original paths',files=rows,canonical={n:dict(path=str(p),sha256=digests[n]) for n,p in canonical.items()},minimum_available_during_archive=96*1024**2,maximum_archive_bytes=150*1024**2,model_actions=0)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');archive=O/'payloads.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for n,p in canonical.items():
  t.add(p,arcname=n,recursive=False);assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>96*1024**2
assert archive.stat().st_size<150*1024**2
with tarfile.open(archive) as t:
 for n in canonical:assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==digests[n]
# Archive and restoration manifest are durable before removing redundant copies.
for p in [archive,O/'plan.json']:
 with p.open('rb') as f:os.fsync(f.fileno())
for row in rows:
 p=Path(row['path']);assert sha(p)==row['sha256'];p.unlink()
assert all(sha(p)==digests[n] for n,p in canonical.items())
result=dict(status='LOSSLESS_DUPLICATE_FIXTURES_ARCHIVED',raw_bytes=sum(x['bytes'] for x in rows),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),files=len(rows),seconds=time.monotonic()-started,free_bytes=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,canonical_tools_unchanged=True,models_and_receipts_unchanged=True)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'restore.py').write_text('''from pathlib import Path
import json,hashlib,tarfile,os
w=Path(__file__).resolve().parent;p=json.loads((w/'plan.json').read_bytes());r=json.loads((w/'result.json').read_bytes());a=w/'payloads.tar.gz'
assert hashlib.sha256(a.read_bytes()).hexdigest()==r['archive_sha256']
with tarfile.open(a) as t:
 for row in p['files']:
  dest=Path(row['path']);data=t.extractfile(row['member']).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
  if dest.exists():assert hashlib.sha256(dest.read_bytes()).hexdigest()==row['sha256'];continue
  tmp=dest.with_name(dest.name+'.restore');assert not tmp.exists();tmp.write_bytes(data);tmp.chmod(row['mode']);os.utime(tmp,ns=(row['mtime_ns'],row['mtime_ns']));tmp.rename(dest)
print('Exact historical fixture payloads restored; no process started')
''');print(json.dumps(result))

from pathlib import Path
import json,hashlib,tarfile,os
w=Path(__file__).resolve().parent;p=json.loads((w/'plan.json').read_bytes());r=json.loads((w/'result.json').read_bytes());a=w/'payloads.tar.gz'
assert hashlib.sha256(a.read_bytes()).hexdigest()==r['archive_sha256']
with tarfile.open(a) as t:
 for row in p['files']:
  dest=Path(row['path']);data=t.extractfile(row['member']).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
  if dest.exists():assert hashlib.sha256(dest.read_bytes()).hexdigest()==row['sha256'];continue
  tmp=dest.with_name(dest.name+'.restore');assert not tmp.exists();tmp.write_bytes(data);tmp.chmod(row['mode']);os.utime(tmp,ns=(row['mtime_ns'],row['mtime_ns']));tmp.rename(dest)
print('Exact historical fixture payloads restored; no process started')

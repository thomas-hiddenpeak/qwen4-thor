from pathlib import Path
import hashlib,json,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-custom-voice-metadata-20261118';assert not O.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
cpu=read(W/'component-cpu-01/result.json');build=read(W/'component-build-01/result.json');inv=read(W/'component-cpu-01/inventory.json');assert cpu['status']=='PASS' and cpu['unique_cases']==12 and build['status']=='PASS' and build['warnings']==0 and inv['inventory_current']
files={}
for n in ['metadata-01','component-build-01','component-cpu-01','retained-cpu-fixture-binaries-01']:
 for p in (W/n).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.name not in ['payloads.tar.gz','q4t_tts_base_contracts']:files[str(p.relative_to(W))]=p
for n in ['component-plan-01.json','acquire_metadata.py','archive_component.py','archive_old_fixture_binaries.py','cache-inventory-01.json']:files[n]=W/n
for p in files.values():assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in p.read_bytes()
O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz',compresslevel=9) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz') as t:
 for f in t.getmembers():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==index[f.name]['sha256']
result=dict(status='BASE_METADATA_CPU_QUALIFIED_RUNTIME_PENDING',cpu_unique=12,cpu_seconds=cpu['seconds'],build_seconds=build['seconds'],warnings=0,source_anchors=inv['reviewed_source_anchors'],negative_source_controls=inv['mutation_checks'],gpu_loads=0,full_asset_verified=False,runtime_api_accepted=False,default_changed=False,fixture_archive=read(W/'retained-cpu-fixture-binaries-01/result.json'),archive_sha256=sha(O/'records.tar.gz'),master_complete=False)
put(O/'index.json',json.dumps(index,indent=2)+'\n');put(O/'result.json',json.dumps(result,indent=2)+'\n')
put(O/'README.md','''# 自定义音色Base元数据合同通过

原生Base 1.7B配置与480张量图（含76个声纹张量）已实现；10新CPU
和2个直接受影响的CustomVoice旧合同全部通过，12项/0.064秒，
构建8.374秒零警告。917来源锚点与13负控通过，0GPU。真实官方
张量头部是独立形状/存储证据，未把生成图拿来当自己的唯一对照。

校验覆盖Base/CustomVoice交叉绑定、2048维/24kHz配置、缺失/重复/
额外字段、全部声纹权重dtype/shape、重叠/空洞、非整数和非有限值。
尚未获取完整3.857GB权重；真实声纹计算、条件合成、ID注册/隔离与
服务恢复都继续实施，不能把本项CPU通过当作自定义音色已可用。

测试前磁盘门不足时未执行用例，没有降低256MiB门槛。八个旧CPU
夹具的重复Prometheus/promtool副本共1,200,655,776字节，已逐SHA
无损归档为114,092,755字节，保留逐路径恢复脚本。原辅助服务程序、
模型、验收记录和默认rev316保持；归档本体本机保留，摘要/清单
随本证据保存，避免把可恢复副本重复上传Git。

[结果](result.json)、[逐文件摘要](index.json)、[原件](records.tar.gz)。
[完整接续计划](../../SERVE_CUSTOM_VOICES_2026-11-18.md)保持全部任务。
''')
p=R/'docs/STATUS.md';s=p.read_text();put(p,s.replace('## 正在推进\n\n','## 正在推进\n\n[自定义音色Base 12项CPU通过](evidence/serve-custom-voice-metadata-20261118/README.md)，\n0.064秒、构建零警告，917来源/13负控；0GPU，默认rev316保持。\n480张量含76声纹参数，完整权重/计算/持久注册继续；旧八份CPU\n辅助程序副本已无损归档并保留恢复脚本，磁盘门未降低。\n\n',1))
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);put(p,h+'\n\n## 自定义音色Base固定合同12 CPU通过（2026-11-18）\n\n已实现官方Base配置与480张量图，含76声纹张量；10新+2旧针对\n合同0.064秒全过，8.374秒零警告，917来源/13负控，0GPU。未暴露\n虚假的音色注册成功，默认rev316保持。磁盘不足先0用例停止，\n八份历史辅助程序复制件逐SHA无损归档并可按原路径恢复，释放\n约1.087GB。下一步原生声纹前端/计算、真实条件与持久注册；完整\n权重仍待安全容量准备，总目标继续。\n[证据](../evidence/serve-custom-voice-metadata-20261118/README.md)。\n'+b)
p=R/'docs/SERVE_NATIVE_TTS_2026-11-18.md';put(p,p.read_text()+'\n自定义音色接续见[Base与注册实施计划](SERVE_CUSTOM_VOICES_2026-11-18.md)。\n[12项元数据CPU证据](evidence/serve-custom-voice-metadata-20261118/README.md)\n已过，实际权重/声纹/条件合成与HTTP注册仍待实施，不关闭TTS总项。\n')
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['native_tts_progress']['custom_voice']=dict(state=result['status'],plan='SERVE_CUSTOM_VOICES_2026-11-18.md',evidence='evidence/serve-custom-voice-metadata-20261118/README.md',cpu_unique=12,gpu_loads=0,model_revision='fd4b254389122332181a7c3db7f27e918eec64e3',full_asset_verified=False,runtime_api_accepted=False,default_changed=False);put(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size)))

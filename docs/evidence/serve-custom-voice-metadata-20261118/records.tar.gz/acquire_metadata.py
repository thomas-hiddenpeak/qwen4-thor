"""Bounded official Base-model metadata acquisition, never loads a model."""
from pathlib import Path
import urllib.request,json,hashlib,struct,time,os
W=Path(__file__).resolve().parent;O=W/'metadata-01';assert not O.exists();O.mkdir();started=time.monotonic();model='Qwen/Qwen3-TTS-12Hz-1.7B-Base';limit=2*1024**2;total=0;files=[]
(O/'plan.json').write_text(json.dumps(dict(model=model,seconds=240,maximum_download_bytes=limit,gpu_loads=0,complete_weights_download=False,files=['repository metadata','config.json','generation_config.json','model.safetensors header only']),indent=2)+'\n')
def get(url,name,start=None,end=None):
 global total
 assert time.monotonic()-started<240
 headers={'User-Agent':'q4t-native-custom-voice-metadata/1'}
 if start is not None:headers['Range']=f'bytes={start}-{end}'
 with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as r:
  if start is not None:assert r.status==206 and r.headers.get('Content-Range','').startswith(f'bytes {start}-{end}/')
  else:assert r.status==200
  value=r.read(limit-total+1);total+=len(value);assert total<=limit
  if start is not None:assert len(value)==end-start+1
 p=O/name;p.write_bytes(value);files.append(dict(name=name,url=url,bytes=len(value),sha256=hashlib.sha256(value).hexdigest()));return value
result=dict(status='RUNNING',files=files,gpu_loads=0)
try:
 meta=json.loads(get('https://huggingface.co/api/models/'+model+'?blobs=true','repository.json'));rev=meta['sha'];result['revision']=rev;base='https://huggingface.co/'+model+'/resolve/'+rev+'/'
 for name in ['config.json','generation_config.json']:
  b=get(base+name,name);item=next(s for s in meta['siblings'] if s['rfilename']==name);assert hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==item['blobId']
 item=next(s for s in meta['siblings'] if s['rfilename']=='model.safetensors');result['complete_weight_identity']=item
 prefix=get(base+'model.safetensors?download=true&q4t=header-prefix','header-size.bin',0,7);size=struct.unpack('<Q',prefix)[0];assert 0<size<512*1024
 raw=get(base+'model.safetensors?download=true&q4t=header-body','header.json',8,8+size-1);h=json.loads(raw);result.update(header_bytes=size,tensors=len(h)-('__metadata__' in h),data_bytes=item['size']-8-size,status='METADATA_ONLY_NOT_FULL_ASSET_ACCEPTANCE')
except BaseException as e:result.update(status='FAILED',error=repr(e))
finally:
 result.update(seconds=time.monotonic()-started,download_bytes=total);(O/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},ensure_ascii=False));assert result['status']=='METADATA_ONLY_NOT_FULL_ASSET_ACCEPTANCE'

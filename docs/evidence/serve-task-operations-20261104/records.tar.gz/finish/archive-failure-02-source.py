"""Offline collector correction; retain the frozen audit and all raw failures."""
import argparse
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools.project_tasks import operations_report as report

s, pkg = report.s, report.pkg


def public_bytes(raw, secrets):
    # A literal regex/string in a source file is not a PEM block. Actual PEM
    # headers occupy a complete line. Raw credential bytes are always denied.
    return all(secret not in raw for secret in secrets) and not re.search(
        rb'(?m)^-----BEGIN [A-Z ]*PRIVATE KEY-----\r?$', raw)


def collect():
    data = {}
    for name in ('plan.json', 'run.stdout', 'run.stderr'):
        data[name] = (s.ATTEMPT/name).read_bytes()
    for name in ('cpu-import-01.json', 'python-dependencies.json'):
        data[name] = (s.BASE/name).read_bytes()
    for folder in ('cpu', 'cpu-entry-fix', 'execution', 'postflight', 'plans'):
        root = s.BASE if folder.startswith('cpu') else s.ATTEMPT
        for path in sorted((root/folder).rglob('*')):
            if path.is_file():
                pkg.regular(path)
                data[str(path.relative_to(root))] = path.read_bytes()
    plan = s.check()
    for name in plan['prior_attempt']:
        data['original/'+name] = (s.BASE/name).read_bytes()
    for name in plan['historical']['sources']:
        data['historical-source/'+name] = (s.HISTORICAL/name).read_bytes()
    for path in sorted(s.TASKS.rglob('*')):
        if path.is_file():
            pkg.regular(path)
            data['tasks/'+str(path.relative_to(s.TASKS))] = path.read_bytes()
    for name in report.READERS:
        data['current-source/'+name] = (ROOT/name).read_bytes()
    front = pkg.read(plan['frontend'])
    secrets = [c['api_key'].encode() for c in front['clients']]
    secrets.append(pkg.read(plan['policy'])['gateway_token'].encode())
    original = data['cpu-entry-fix/source/tools/project_tasks/operations_report.py']
    pkg.require(public_bytes(original, secrets), 'source literal mistaken for key')
    pkg.require(not public_bytes(b'-----BEGIN PRIVATE KEY-----\nfixture\n', secrets),
                'PEM header accepted')
    pkg.require(not public_bytes(b'{"secret":"'+secrets[0]+b'"}', secrets),
                'credential bytes accepted')
    data['finish/collector-checks.json'] = json.dumps(dict(status='PASS_OFFLINE_COLLECTOR',
        assertions=3, original_source_sha256=report.sha(original),
        model_starts=0, http_requests=0)).encode()+b'\n'
    data['finish/archive-failure-01.json'] = (s.BASE/'archive-failure-01.json').read_bytes()
    data['finish/operations_finish.py'] = Path(__file__).read_bytes()
    for name, raw in data.items():
        pkg.require(public_bytes(raw, secrets), 'private credential or PEM block: '+name)
    return data


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('seal', 'verify'))
    args = parser.parse_args()
    if args.action == 'seal':
        report.collect = collect
        report.seal()
    result = report.verify()
    manifest = pkg.read(report.DEST/'manifest.json')
    pkg.require(pkg.sha(Path(__file__)) == manifest['records']['finish/operations_finish.py'],
                'offline collector identity changed')
    print(json.dumps(result))

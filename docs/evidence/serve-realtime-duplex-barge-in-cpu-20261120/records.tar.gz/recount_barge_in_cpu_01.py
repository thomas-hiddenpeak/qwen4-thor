from pathlib import Path
import json,re,hashlib
w=Path(__file__).parent;a=w/'barge-in-scope-cpu-01';b=w/'barge-in-scope-cpu-02';p=w/'barge_in_business_01.py';r=json.loads((a/'result.json').read_text())
assert r['status']=='FAIL' and all(c['exit_code']==0 for c in r['commands'])
assert int(re.search(r'Ran (\d+) tests?',(a/'0.stderr').read_text())[1])==1
assert '\nOK\n' in (a/'0.stderr').read_text() and 'ℹ pass 1' in (a/'3.stdout').read_text()
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();plan=json.loads((a/'plan.json').read_text())
plan.update(verification='Offline correction of singular unittest count; original commands exited 0, no tests rerun',original_plan_sha256=sha(a/'plan.json'))
changed={Path(k).resolve() for k,h in plan['sources'].items() if sha(Path(k))!=h};assert changed=={p.resolve()}
plan['sources']={k:sha(Path(k)) for k in plan['sources']};plan['sources'].update({str(q):sha(q) for q in a.iterdir() if q.is_file()})
(b/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');r.update(status='PASS',tests=1,verification=plan['verification'],new_test_executions=0)
(b/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

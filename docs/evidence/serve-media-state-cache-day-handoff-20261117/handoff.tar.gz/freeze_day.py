import hashlib
import json
import os
import subprocess
import tarfile
import time
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
S = W/'validation-src'
O = W/'frozen-handoff-01'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def protected():
    return {str(R/n): sha(R/n) for n in (
        'build/q4t', 'build/q4t.release.json', 'build/service/manifest.json',
        'build/service.release.json', 'build/service-native-state/ledger.json')}
os.umask(0o077)
assert not S.exists() and not O.exists()
before = protected()
v = read(W/'delivery-01/result.json')
assert v['status'] == 'PASS_MEDIA_STATE_CACHE_DELIVERED'
current = v['publication']['current']
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
O.mkdir()
with (O/'worktree.stdout').open('x') as out, (O/'worktree.stderr').open('x') as err:
    subprocess.run(['git','worktree','add','--detach',str(S),commit], cwd=R,
                   stdout=out, stderr=err, check=True, timeout=120)
package = Path(current['package'])
links = {'q4t': package/'engine/q4t',
         'q4t.release.json': package/'engine/q4t.release.json',
         'service': package,
         'service.release.json': W/'delivery-01/candidate-service.release.json'}
(S/'build').mkdir()
for name, path in links.items():
    (S/'build'/name).symlink_to(path)
assert subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=S,text=True).strip() == str(R/'.git')
steps = []
for name, argv in (
    ('prepare', ['/usr/bin/python3','-I','-B','tools/serve_soak/native_stage.py',
                 'prepare','--profile','day','--package','build/service',
                 '--output','.q4t-work/day-01']),
    ('check', ['/usr/bin/python3','-I','-B','tools/serve_soak/native_stage.py',
               'check','--plan','.q4t-work/day-01/plan.json'])):
    start = time.monotonic()
    with (O/(name+'.stdout')).open('x') as out, (O/(name+'.stderr')).open('x') as err:
        result = subprocess.run(argv,cwd=S,stdout=out,stderr=err,timeout=90)
    step = dict(name=name,argv=argv,cwd=str(S),exit_code=result.returncode,
                seconds=time.monotonic()-start)
    (O/(name+'.json')).write_text(json.dumps(step,indent=2)+'\n')
    steps.append(step)
    assert result.returncode == 0, name
assert protected() == before
plan = read(S/'.q4t-work/day-01/plan.json')
assert plan['package']['manifest_sha256'] == current['manifest_sha256']
assert not (S/'.q4t-work/day-01/execution').exists()
a = dict(status='PASS_FROZEN_DAY_HANDOFF',source_commit=commit,workspace=str(S),
         revision=214,package=plan['package'],service_id=plan['service_id'],
         plan=str(S/'.q4t-work/day-01/plan.json'),
         plan_sha256=sha(S/'.q4t-work/day-01/plan.json'),sources=len(plan['sources']),
         links={n:str(p) for n,p in links.items()}, protected_default=before,
         production_unchanged=True,same_git_common_dir=True,steps=steps,
         model_actions=0,executed=False,owner='user')
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
P = R/'docs/evidence/serve-media-state-cache-day-handoff-20261117'
P.mkdir()
with tarfile.open(P/'handoff.tar.gz','w:gz') as tar:
    for p in sorted(O.iterdir()):
        tar.add(p,arcname='review/'+p.name,recursive=False)
    for n in ('plan.json','handoff.json'):
        tar.add(S/'.q4t-work/day-01'/n,arcname=n,recursive=False)
    tar.add(W/'freeze_day.py',arcname='freeze_day.py',recursive=False)
a['archive_sha256'] = sha(P/'handoff.tar.gz')
(P/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(P/'README.md').write_text('''# rev214独立快照长稳交接

当前精确包及源码快照的day prepare/check通过，0模型动作。私有服务
与生产默认均STOPPED，未占GPU。源码快照固定commit，build固定已验
包及发布记录；后续开发和默认切换不会改本计划。共享原GPU租约锁。

24小时由用户显式执行，未安装后台任务；rev204及更早的快照、包和
计划均按原身份保留。当前引擎的针对性功能验收与前驱rev188连续
short分别记录，不把旧长稳驱动短验说成当前引擎重跑。执行、状态和
清理入口见[交接文档](../../SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)。
''')
p=R/'docs/SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md'
s=p.read_text()
start=s.index('当前rev204');end=s.index('## 当前已准备的入口')
s=s[:start]+f'''当前rev214包`{current['manifest_sha256']}`
已完成媒体状态缓存/视觉分块、原视频数值修复、图片/schema/私有缓存、
主轻及保留组合的真实功能验收；新引擎正式接受6启动26请求。
[业务证据](evidence/serve-media-state-cache-business-20261117/README.md)、
[交付证据](evidence/serve-media-state-cache-delivery-20261117/README.md)保留原失败和
诊断，累计13启动60请求。发布迁移模块补验为CPU及实际STOPPED切换，
不冒称新整包GPU重跑。连续60秒长稳驱动短验属于前驱rev188，
[原证据](evidence/serve-native-soak-business-20261116/README.md)按原身份保留。

[当前独立快照day prepare/check](evidence/serve-media-state-cache-day-handoff-20261117/README.md)
已完成，24小时未运行。快照固定`{commit[:8]}`及rev214包，不依赖活动
工作区和未来默认指针。用户选择维护窗口显式开展。

'''+s[end:]
s=s.replace('93294db6-abf0-47ea-9577-ed128d30c934',plan['service_id'])
s=s.replace('serve-chat-moderation-repair-20261117/validation-src','serve-media-state-cache-20261117/validation-src')
s=s.replace('此计划继续验证rev204','此计划继续验证rev214')
s=s.replace('把rev204证据移称新版本证据','把rev214证据移称新版本证据')
s=s.replace('原工作区day-01及更早计划保留','原rev204独立快照、工作区day-01及更早计划保留')
p.write_text(s)
p=R/'docs/STATUS.md';s=p.read_text().replace('用户day准备独立新快照，rev204原入口保留。','用户day独立快照已prepare/check、未运行，rev204原入口保留。');p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
    if task['id']=='Q03':
        task['current_native_day_handoff']=a|dict(evidence='evidence/serve-media-state-cache-day-handoff-20261117/README.md')
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/log/2026-11-17.md';head,rest=p.read_text().split('\n',1)
p.write_text(head+'''\n
## rev214独立长稳交接已固定

2026-11-17：当前源码与精确发布包固定到新的detached快照，day prepare/
check通过，0模型动作，生产默认及账本不变。原rev204入口与证据保留；
长稳仍由用户执行，后续开发不会漂移计划身份。下一步PR38最终检查/
实际合main和其余全部master任务。
'''+rest)
print(json.dumps({k:a[k] for k in ('status','source_commit','revision','service_id','sources','model_actions')}))

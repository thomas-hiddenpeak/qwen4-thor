"""Archive the exact native auxiliary delivery and its interrupted maintenance."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
D=W/'delivery-01';O=R/'docs/evidence/serve-audio-auxiliary-delivery-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');composition=read(W/'publication-composition.json')
assert v['status']=='PASS_NATIVE_AUDIO_AUXILIARY_DELIVERED' and v['publication']['revision']==286
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands'])
assert v['state']=='STOPPED' and v['new_gpu_starts']==0 and v['outer']['charged_total']==0
c=v['publication']['current'];assert c['manifest_sha256']==composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
release=read((R/'build/service.release.json').resolve());capacity=read(W/'capacity-02/result.json')
assert capacity['status']=='PASS_DELIVERY_CAPACITY_RESERVED' and capacity['original_failure_preserved']
assert not capacity['deleted_files'] and capacity['default_unchanged'] and capacity['recovery_budget_unchanged']
files={}
for d in [D,W/'capacity-01',W/'capacity-02']:
 for p in d.iterdir():
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(W))]=p
for pattern in ['delivery-prepare-*.*','delivery-run-*.*']:
 for p in W.glob(pattern):
  if p.is_file():files[p.name]=p
for name in ['archive_delivery.py','deliver.py','run_delivery.py','reserve_delivery_capacity.py','finish_delivery_capacity.py','maintenance-before.json','publication-composition.json','service-package-03/prepare-review.json']:
 files[name]=W/name
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,item in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(item,str) and len(item)>=24:secrets.append(item.encode())
   else:collect(item)
 elif isinstance(v,list):
  for item in v:collect(item)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for name,p in files.items():
 raw=p.read_bytes();assert not any(secret in raw for secret in secrets),name
 assert b'-----BEGIN '+b'PRIVATE KEY-----\n' not in raw,name
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
a=dict(status='ACCEPT_NATIVE_AUDIO_AUXILIARY_DELIVERY',revision=286,current=c,
 commands=len(v['commands']),seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,
 manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],
 candidate_whole_package_gpu_run=True,older_engine_fallback=False,previous_rev276_preserved=True,
 retired_intents_archived=4,retired_generations_archived=2,retired_versions_archived=2,
 maintenance_original_timeout_preserved=True,maintenance_cumulative_seconds=capacity['cumulative_seconds'],deleted_files=0,
 files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,
 full_model_quality=False,performance_claim=False,long_stability_run=False,full_openai_compatibility=False,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生时间戳、字幕和VAD默认交付 rev286

默认包`{c['manifest_sha256']}`，引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、实际整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU；outer保持启用且累计启动0次。服务默认保持STOPPED。

实际词时间戳、完整segment统计、SRT/VTT和VAD切片已接入默认。
[主轻](../serve-audio-auxiliary-profiles-20261117/README.md)和
[原生TLS/整包恢复](../serve-audio-auxiliary-service-20261118/README.md)
有真实双段语音业务；后者6计费尝试/5实际加载/19创建/1探针，
315.834秒、305次NVML正常。原exec失败及旧控制argv核对失败保留，
路径等价审查的依据/限制明确，未将其追认成原自动finalizer通过。

核心/client/outer预算字节保持，profile仅显式增加已验辅助身份与预算；
原history/pending/selected/deadline保持。实际整根回退恢复各根原周期。
人工根`{a['manual_root']}`和自动payload`{a['automatic_payload']}`
均为当前引擎与保留控制，不声称独立旧引擎回退。前驱rev276及day入口保留。

4意图/2副本/2登记可恢复归档，0删除；版本归档首轮30秒超时保留，
按同一sealed计划续办，累计{capacity['cumulative_seconds']:.3f}秒，未改变默认和恢复预算。
说话人、Chat音频、合成、Realtime和全部master任务继续；不是完整模型
质量、性能或长稳通过。下一步完成PR45实际合入，并推进剩余实现。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev286；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','Guardian':'`'+release['guardian_sha256']+'`','原生入口':'`'+release['ingress_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；对齐/VAD/原周期/原生入口已验，前驱rev276另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退','外部依赖':'原生入口/自监护不要求nginx/systemd；ASR/对齐/VAD资产按部署显式启用，codec按请求隔离，辅助失能不拖停健康Chat'}
for name,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(name)+r' \| .* \|$',lambda _:f'| {name} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev286对齐/VAD可回退交付](evidence/serve-audio-auxiliary-delivery-20261118/README.md)
已完成，19项STOPPED命令/{v['seconds']:.3f}秒，0新增GPU。实际整根
回退与再前进、预算/历史保持通过；前驱rev276与day保留。版本归档
原30秒超时保留，同一计划续办成功且0删除。继续PR45合main、说话人/
Chat音频/合成/Realtime及全部master任务；本阶段不结束总目标。

'''
s=s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1);p.write_text(s)
p=R/'docs/log/2026-11-18.md';s=p.read_text();header,rest=s.split('\n',1);p.write_text(header+f'''\n\n## rev286原生对齐/VAD可回退交付（2026-11-18）

19项STOPPED命令/{v['seconds']:.3f}秒、0新增GPU；实际整根回退与
前进通过，保持原预算/历史，显式新增已验辅助资产与恢复资格。
旧记录可恢复归档的30秒超时保留，同一计划续办通过且0删除。
原因：新增音频能力须进入可用发行，同时恢复仍保持已声明能力。
前驱rev276及day保留；下一步PR45实际合main及全部master继续。
[证据](../evidence/serve-audio-auxiliary-delivery-20261118/README.md)。\n'''+rest)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for t in j['tasks']:
 if t['id'] in ['A10','A12','Q01','Q02']:t['audio_auxiliary_delivery_20261118']=a|dict(evidence='evidence/serve-audio-auxiliary-delivery-20261118/README.md')
 if t['id']=='Q02':
  t['latest_release']=t['audio_auxiliary_delivery_20261118'];t['remaining_required']=['PR45 final-head checks and actual main merge','Delivery of every remaining implementation']
 if t['id']=='R07':t['current_execution_prerequisite']='Refresh exact cold qualification against rev286 or then-current default; pending host/camera maintenance handoff remains required.'
j['next_task']='PR45 main integration and A10 diarization plus all remaining master tasks';j['next']='Complete final-head PR45 integration and exact user handoff, then actual diarization, Chat audio/synthesis/Realtime and every remaining A/N/R/Q task.';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev286对齐/VAD交付](evidence/serve-audio-auxiliary-delivery-20261118/README.md)：实际时间戳、字幕、分段统计与可回退原生服务。\n')
print(json.dumps({k:a[k] for k in ['status','revision','commands','seconds']}))

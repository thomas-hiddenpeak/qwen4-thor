"""Resume the exact interrupted retirement, without changing selected identities."""
import json,os,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_recovery import publication
from tools.serve_service import package as p
os.umask(0o077)
S=R/'build/service-native-state'; OLD=W/'capacity-01';O=W/'capacity-02'
p.require(not O.exists(),'preserve failed execution');O.mkdir(mode=0o700)
failure=p.read(OLD/'result.json');selection=p.read(OLD/'selection.json')
p.require(failure['status']=='FAILED' and 'TimeoutExpired' in failure['error'] and len(failure['commands'])==5,'unexpected failure')
p.require(all(v['returncode']==0 for v in failure['commands']),'prior completed command failed')
for kind in ('intents','generations'):
 v=p.read(OLD/(kind+'-apply.stdout'));p.require(v['status']=='RETIRED' and not v['model_actions'] and v['deleted_files']==0,'prior archive incomplete')
expected=dict(selection['initial'],request_ids=sorted(set(selection['initial']['request_ids'])-set(selection['selected']['intents'])))
p.require(publication.status(S)==expected,'unexpected publication change')
prior=p.read(R/'.q4t-work/serve-audio-native-20261117/delivery-01/result.json')
p.require(all(p.sha(S/n)==h for n,h in prior['preserved'].items()),'core/client/outer differs from accepted predecessor')
p.require(p.read(S/'profile-selection/policy.json')['state']['policy']==prior['expected_profiles'],'profile changed')
p.require(p.read(S/'version-selection/policy.json')['state']['policy']==prior['final_cycle'],'version changed')
def protected():
 return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection','version-selection')))}
before=protected();p.save(O/'protected-before.json',before)
plan=p.read(OLD/'versions-plan.stdout');p.require(p.sha(Path(plan['plan']))==plan['sha256'],'plan changed')
p.save(O/'review.json',dict(original=failure,selection=selection,expected_publication=expected,protected=before,original_spawn_calls=6,additional_call_limit=2,cumulative_seconds_limit=270,per_call_seconds=90,new_gpu_actions=0))
rows=[];started=time.monotonic()
def call(label,args):
 p.require(len(rows)<2 and failure['seconds']+time.monotonic()-started<270,'resumption budget')
 argv=list(map(str,[R/'build/q4t','service',*args]));r=subprocess.run(argv,capture_output=True,text=True,timeout=90)
 (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr);rows.append(dict(label=label,argv=argv,returncode=r.returncode))
 p.require(r.returncode==0,'resume failed: '+label);v=json.loads(r.stdout)
 p.require(not v['model_actions'] and protected()==before and publication.status(S)==expected,'protected identity changed')
 return v
try:
 v=call('versions-resume',['maintenance-apply','--state',S,'--kind','versions','--plan',plan['plan'],'--plan-sha256',plan['sha256']])
 p.require(v['status']=='RETIRED' and v['deleted_files']==0,'archive incomplete')
 after=call('final-status',['maintenance-status','--state',S])
 p.require(all(after['pools'][k]['used']==selection['pools'][k]['used']-len(ids) for k,ids in selection['selected'].items()),'capacity differs')
 seconds=time.monotonic()-started;p.require(seconds+failure['seconds']<270,'cumulative time exceeded')
 result=dict(status='PASS_DELIVERY_CAPACITY_RESERVED',seconds=seconds,cumulative_seconds=seconds+failure['seconds'],original_failure_preserved=True,original_call_count=6,commands=rows,protected=before,pools=after['pools'],default_unchanged=True,recovery_budget_unchanged=True,deleted_files=0,model_actions=0)
 p.save(O/'result.json',result);print(json.dumps({k:result[k] for k in ['status','cumulative_seconds','deleted_files']}))
except BaseException as error:
 p.save(O/'result.json',dict(status='FAILED',error=repr(error),commands=rows,seconds=time.monotonic()-started));raise

"""Explicit phase snapshots, actual CPU records and reviewed source anchors."""
import hashlib, importlib.util, io, json, subprocess, tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1]
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
O=R/'docs/evidence/serve-live-lifecycle-transport-cpu-20261121'
assert not O.exists()
a=read(W/'lifecycle-cpu-01/result.json');b=read(W/'transport-cpu-01/result.json')
assert all(x['status']=='PASS' and x['sources_unchanged'] and x['protected_unchanged'] for x in (a,b))
expected={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','include/q4t/server/live_session.h','src/server/live_session.cpp','include/q4t/server/live_session_pump.h','src/server/live_session_pump.cpp','include/q4t/server/websocket_session.h','src/server/websocket_session.cpp'}
spec=importlib.util.spec_from_file_location('inventory',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=R/'tools/serve_audit/inventory.json';inventory=read(p);actual=m.current_surface(R)
changed={n for n,h in actual['sources_sha256'].items() if inventory['sources_sha256'].get(n)!=h}
save(W/'lifecycle-transport-inventory-before.json',dict(changed_sources=sorted(changed),errors=m.check(inventory,actual)))
assert changed==expected,(changed,expected)
files={}
for phase in ('lifecycle','transport'):
 plan=read(W/(phase+'-cpu-01/plan.json'))
 for name,digest in plan['sources'].items():
  raw=(R/name).read_bytes()
  if sha(raw)!=digest and phase=='lifecycle':
   s=raw.decode()
   if name=='src/server/live_session.cpp':
    s=s.replace('      !AdvanceClock() || !Flush())\n    return false;\n  // The socket may already have queued input when the worker finalized. Drop\n  // that transport tail without accepting work or writing after session.closed.\n  if (state_ == State::kClosed) return true;','      state_ == State::kClosed || !AdvanceClock() || !Flush())\n    return false;')
   elif name=='CMakeLists.txt':s=s.replace('  src/server/live_session_pump.cpp\n','')
   elif name=='cmake/ChatProtocolIdentity.cmake':s=s.replace('  include/q4t/server/live_session_pump.h\n  src/server/live_session_pump.cpp\n','')
   elif name=='cmake/HostTestSources.cmake':
    s=s.replace('  ${CMAKE_CURRENT_LIST_DIR}/../src/server/live_session_pump.cpp\n','').replace('  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_live_session_pump_test.cpp\n','')
   raw=s.encode()
  assert sha(raw)==digest,(phase,name,sha(raw),digest)
  files['accepted-'+phase+'/'+name]=raw
# Manual semantic review: lifecycle owns real drain, partial-failure cleanup and
# monotonic usage; pump uses existing bounded inbox; completion drains every
# frame and preserves authentication/fault/deadline priority. No route claim.
for name in sorted(expected):inventory['sources_sha256'][name]=actual['sources_sha256'][name]
inventory['live_lifecycle_transport_review_20261121']=dict(sources=sorted(expected),evidence='docs/evidence/serve-live-lifecycle-transport-cpu-20261121/README.md',status='CPU verified owner and socket composition; real model and route pending',no_route_accepted=True)
save(p,inventory)
r=subprocess.run(['python3','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(W/'lifecycle-transport-inventory-reviewed.json').write_text(r.stdout);assert r.returncode==0,r.stdout
for phase in ('lifecycle','transport'):
 for folder in (phase+'-plan-01',phase+'-cpu-01'):
  for path in sorted((W/folder).iterdir()):
   if path.suffix in {'.json','.log','.txt'}:files[folder+'/'+path.name]=path.read_bytes()
for name in ('lifecycle_cpu_01.py','transport_cpu_01.py','archive_lifecycle_transport_01.py','lifecycle-transport-inventory-before.json','lifecycle-transport-inventory-reviewed.json'):
 files['driver/'+name]=(W/name).read_bytes()
O.mkdir()
index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as archive:
 for name,raw in sorted(files.items()):
  index[name]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(raw),0o600,0;archive.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
result=dict(status='PASS_NATIVE_LIVE_LIFECYCLE_TRANSPORT_CPU',lifecycle_tests=10,transport_tests=24,distinct_tests=31,total_live_phase_distinct_tests=58,lifecycle_seconds=a['cpu_seconds'],transport_seconds=b['cpu_seconds'],host_binary_sha256=b['binary_sha256'],source_snapshots_match_each_original_plan=True,inventory_mutation_checks=22,controlled_model_callbacks=True,actual_native_socket_pair=True,model_business_accepted=False,default_changed=False,default_revision=426,new_gpu_starts=0,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',result);print(json.dumps(result))

"""Resume the immutable interrupted publication, then finish the remaining STOPPED checks."""
from pathlib import Path
import json,os,runpy,subprocess,time
W=Path(__file__).resolve().parent;R=W.parents[1];D=W/'delivery-02';O=W/'delivery-03'
base=runpy.run_path(str(W/'deliver_semantic_vad_02.py'))
p=base['p'];preserved=base['preserved'];profiles=base['profiles'];version=base['version'];exact=base['exact']
STATE=R/'build/service-native-state';DEFAULT=R/'build';review=p.read(D/'review.json');roots=review['roots'];ids=p.read(D/'requests.json')
failed=p.read(D/'result.json');assert failed['status']=='FAILED' and len(failed['commands'])==7 and 'TimeoutExpired' in failed['error']
assert all(r['returncode']==0 for r in failed['commands']) and not O.exists()
assert preserved()==review['preserved'] and profiles()==review['expected_profiles']
head=p.read(STATE/'service-publication/policy.json')['state']['policy']
deployment=p.read(STATE/'service-deployment/policy.json')['state']['policy']
intent=p.read(STATE/'service-publication-intents'/(ids['candidate']+'.json'))
assert head['phase']=='prepared' and head['revision']==341 and deployment['phase']=='prepared'
assert deployment['request']==intent['request_id']==ids['candidate'] and intent['base']['revision']==340
assert intent['target']['manifest_sha256']==roots['candidate']['manifest_sha256']
O.mkdir(mode=0o700);p.save(O/'plan.json',dict(scope=__doc__,original_result=dict(path=str(D/'result.json'),sha256=p.sha(D/'result.json')),original_request_id=ids['candidate'],publication_before=head,deployment_before=deployment,maximum_remaining_commands=12,maximum_remaining_seconds=420,maximum_command_seconds=180,original_seconds=failed['seconds'],new_gpu_starts=0,driver_sha256=p.sha(Path(__file__))))
rows=list(failed['commands']);new_rows=[];started=time.monotonic();cli=Path(roots['candidate']['package'])/'bin/q4t'
candidate_state=p.read(D/'candidate-cycle.json');anchor_state=p.read(D/'anchor-cycle.json')
generation=p.read(D/'anchor-publish.stdout')['current']['generation_sha256']
def call(label,args):
 p.require(len(new_rows)<12 and time.monotonic()-started<420,'continuation command/time bound')
 raw=list(map(str,args));begin=time.monotonic()
 try:
  r=subprocess.run(raw,capture_output=True,text=True,timeout=min(180,420-(time.monotonic()-started)))
 except subprocess.TimeoutExpired as error:
  for name,data in [('stdout',error.stdout),('stderr',error.stderr)]:
   (O/(label+'.'+name)).write_bytes(data.encode() if isinstance(data,str) else data or b'')
  p.save(O/'timeout.json',dict(label=label,argv=raw,seconds=time.monotonic()-begin));raise
 (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
 row=dict(label=label,argv=raw,returncode=r.returncode,seconds=time.monotonic()-begin)
 rows.append(row);new_rows.append(row);p.save(O/'progress.json',dict(commands=new_rows))
 p.require(r.returncode==0,'continuation command failed: '+label)
 p.require(preserved()==review['preserved'] and profiles()==review['expected_profiles'],'protected state/budgets changed')
 return json.loads(r.stdout)
try:
 value=call('candidate-resume',[cli,'service','publish-resume','--state',STATE,'--request-id',ids['candidate']])
 p.require(value['durable'] and value['revision']==342,'original candidate publication not completed');exact(candidate_state,version())
 value=call('rollback',[cli,'service','publish-rollback','--state',STATE,'--default-root',DEFAULT,'--package',roots['candidate']['package'],'--manifest-sha256',roots['candidate']['manifest_sha256'],'--generation-sha256',generation,'--expected-manifest-sha256',roots['candidate']['manifest_sha256'],'--expected-revision',342,'--request-id',ids['rollback']])
 p.require(value['durable'] and value['revision']==344,'root rollback');exact(anchor_state,version())
 p.require(call('rollback-check',[DEFAULT/'q4t','service','check','--state',STATE])['desired']=='STOPPED','retained root active')
 p.require(call('rollback-outer',[DEFAULT/'q4t','service','outer-status','--state',STATE])['enabled'],'retained outer absent')
 value=call('forward',[cli,'service','publish','--state',STATE,'--default-root',DEFAULT,'--package',roots['candidate']['package'],'--manifest-sha256',roots['candidate']['manifest_sha256'],'--service-release',D/'candidate-service.release.json','--expected-manifest-sha256',roots['retained']['manifest_sha256'],'--expected-revision',344,'--request-id',ids['forward']])
 p.require(value['durable'] and value['revision']==346,'forward failed');exact(candidate_state,version())
 for action in ('check','status','observe'):
  value=call('default-'+action,[DEFAULT/'q4t','service',action,'--state',STATE]);p.require(value['status']=='PASS' if action=='check' else value['state']=='STOPPED','default health')
 pro=call('profiles',[DEFAULT/'q4t','service','profiles-status','--state',STATE]);p.require(pro['selected']=='primary','selected profile changed')
 ver=call('version',[DEFAULT/'q4t','service','version-status','--state',STATE]);p.require(ver['cycle_id']==candidate_state['registry']['cycle_id'] and not ver['fallback_consumed'],'version budget changed')
 outer=call('outer',[DEFAULT/'q4t','service','outer-status','--state',STATE]);p.require(outer['enabled'] and outer['charged_total']==0,'outer budget changed')
 final=call('publication',[DEFAULT/'q4t','service','publish-status','--state',STATE]);p.require(final['ready'] and final['revision']==346 and final['current']['manifest_sha256']==roots['candidate']['manifest_sha256'],'final default differs')
 p.save(O/'result.json',dict(status='PASS_NATIVE_SEMANTIC_VAD_DELIVERED',seconds=failed['seconds']+time.monotonic()-started,continuation_seconds=time.monotonic()-started,commands=rows,successful_commands=19,command_attempts=20,original_timeout_preserved=True,original_result=dict(path=str(D/'result.json'),sha256=p.sha(D/'result.json')),original_request_resumed=ids['candidate'],publication=final,retained_anchor_generation=generation,profiles=pro,versions=ver,outer=outer,anchor_cycle=anchor_state,candidate_cycle=candidate_state,final_cycle=version(),preserved=review['preserved'],expected_profiles=review['expected_profiles'],state='STOPPED',new_gpu_starts=0,all_master_tasks_active=True))
 print(json.dumps(dict(status='PASS_NATIVE_SEMANTIC_VAD_DELIVERED',revision=346,successful_commands=len(rows),command_attempts=20,continuation_seconds=time.monotonic()-started)))
except BaseException as error:
 p.save(O/'result.json',dict(status='FAILED',commands=new_rows,original_result=str(D/'result.json'),error=repr(error),seconds=time.monotonic()-started));raise

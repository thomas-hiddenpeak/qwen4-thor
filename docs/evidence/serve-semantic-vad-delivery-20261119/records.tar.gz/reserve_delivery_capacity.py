"""Archive only unreferenced records, preserving live state and all budgets."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from tools.serve_recovery import maintenance, publication, version_registration
from tools.serve_service import package as p

os.umask(0o077)
S = R/'build/service-native-state'
O = W/'capacity-01'
p.require(not O.exists(), 'preserve previous archive')
O.mkdir(mode=0o700)
initial = publication.status(S)
p.require(initial['ready'] and initial['revision'] == 336 and
    initial['current']['manifest_sha256'] == '37d329881968020f00bfedbbe48c0e856c5a288f767b84a2fbe1d16e21a7bd32',
    'default predecessor changed')
status = p.read(W/'maintenance-before-01.json')
p.require(status['publication_revision'] == initial['revision'] and
    status['manifest_sha256'] == initial['current']['manifest_sha256'], 'selection observation changed')
selected = {}; skipped = []
with maintenance.generations.locked(S) as (state, desc, manifest, current):
    for kind, count in [('intents', 5), ('generations', 2), ('versions', 2)]:
        rows = []
        for identity in status['pools'][kind]['candidate_ids']:
            if kind == 'intents':
                path = publication.intent_path(S, identity)
                order = p.read(path)['base']['revision']
            elif kind == 'versions':
                path = S/version_registration.DIRECTORY/(identity+'.json')
                order = p.read(path)['candidate']['revision']
            else:
                path = Path(current['root'])/maintenance.generations.files.DIRECTORY/'generations'/identity
                order = path.stat().st_mtime_ns
            rows.append((order, identity, path))
        selected[kind] = []
        for _, identity, path in sorted(rows):
            if len(selected[kind]) == count:
                break
            try:
                (maintenance.versions if kind == 'versions' else maintenance.generations).unreferenced(S, current, path)
            except ValueError as error:
                skipped.append(dict(kind=kind, id=identity, reason=str(error)))
                continue
            selected[kind].append(identity)
        p.require(len(selected[kind]) == count, 'insufficient safely unreferenced records')
p.save(O/'selection.json', dict(selected=selected, skipped=skipped, initial=initial, pools=status['pools']))
def protected():
    return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and
        (f.name == 'ledger.json' or f.relative_to(S).parts[0].startswith(
            ('client-', 'outer-', 'profile-selection', 'version-selection')))}
before = protected(); rows = []; archives = {}; started = time.monotonic()
retired_intents = set()
def call(label, args):
    p.require(len(rows) < 10 and time.monotonic()-started < 540, 'maintenance budget exhausted')
    argv = list(map(str, [R/'build/q4t', 'service', *args]))
    result = subprocess.run(argv, capture_output=True, text=True, timeout=min(90, 540-(time.monotonic()-started)))
    (O/(label+'.stdout')).write_text(result.stdout)
    (O/(label+'.stderr')).write_text(result.stderr)
    rows.append(dict(label=label, argv=argv, returncode=result.returncode))
    p.require(result.returncode == 0, 'maintenance failed: '+label)
    value = json.loads(result.stdout)
    if label.startswith('intents-') and label.endswith('-apply'):
        p.require(value['status'] == 'RETIRED' and value['deleted_files'] == 0, 'intent archival failed')
        retired_intents.update(applying_ids)
    current = publication.status(S)
    expected = dict(initial, request_ids=sorted(set(initial['request_ids'])-retired_intents))
    p.require(value['model_actions'] is False and protected() == before and current == expected,
              'default, state, intent selection or budget changed')
    return value
try:
    for kind, ids in selected.items():
        for index, offset in enumerate(range(0, len(ids), 4)):
            applying_ids = ids[offset:offset+4]
            label = kind+'-'+str(index+1)
            flags = [value for identity in applying_ids for value in ('--select', identity)]
            plan = call(label+'-plan', ['maintenance-plan', '--state', S, '--kind', kind,
                        *flags, '--output', O/(label+'-archive')])
            result = call(label+'-apply', ['maintenance-apply', '--state', S, '--kind', kind,
                        '--plan', plan['plan'], '--plan-sha256', plan['sha256']])
            p.require(result['status'] == 'RETIRED' and result['deleted_files'] == 0,
                      'archive incomplete or destructive')
            archives[label] = plan
    after = call('final-status', ['maintenance-status', '--state', S])
    p.require(all(after['pools'][k]['used'] == status['pools'][k]['used']-len(ids)
                  for k, ids in selected.items()), 'pool capacity differs')
    p.save(O/'result.json', dict(status='PASS_DELIVERY_CAPACITY_RESERVED', seconds=time.monotonic()-started,
        commands=rows, archives=archives, protected=before, pools=after['pools'], default_unchanged=True,
        recovery_budget_unchanged=True, deleted_files=0, model_actions=0))
    print(json.dumps(dict(status='PASS_DELIVERY_CAPACITY_RESERVED', commands=len(rows),
                         seconds=time.monotonic()-started)))
except BaseException as error:
    p.save(O/'result.json', dict(status='FAILED', error=repr(error), commands=rows, archives=archives,
                               seconds=time.monotonic()-started))
    raise

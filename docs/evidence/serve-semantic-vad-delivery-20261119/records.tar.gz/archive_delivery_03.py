"""Publish actual STOPPED delivery and remaining master work, without rerunning business."""
from pathlib import Path
import hashlib,json,re,tarfile,os
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-03'
O=R/'docs/evidence/serve-semantic-vad-delivery-20261119'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  raw=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(raw);p.chmod(mode)
result=read(D/'result.json');composition=read(W/'publication-composition-02.json');capacity=read(W/'capacity-01/result.json');current=result['publication']['current'];release=read(R/'build/service.release.json')
assert result['status']=='PASS_NATIVE_SEMANTIC_VAD_DELIVERED' and result['publication']['revision']==346
assert result['state']=='STOPPED' and result['new_gpu_starts']==0 and len(result['commands'])==19
assert all(r['returncode']==0 for r in result['commands']) and result['outer']['enabled'] and result['outer']['charged_total']==0
assert current['manifest_sha256']==composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t')==current['engine_binary_sha256'] and sha(R/'build/service.release.json')==current['service_release_sha256']
for n,h in result['preserved'].items():assert sha(R/'build/service-native-state'/n)==h,n
assert capacity['status']=='PASS_DELIVERY_CAPACITY_RESERVED' and capacity['deleted_files']==0 and capacity['default_unchanged'] and capacity['recovery_budget_unchanged']
assert release['native_semantic_vad_targeted_accepted'] and release['native_reference_icl_targeted_accepted'] and release['native_realtime_transcription_targeted_accepted']
assert not release['voice_listening_and_similarity_accepted'] and release['voice_listening_deferred']
files={}
for d in (D,W/'delivery-02',W/'capacity-01'):
 for p in d.iterdir():
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(W))]=p
for p in (W/'capacity-01').glob('*-archive/*.json'):files[str(p.relative_to(W))]=p
for n in ('archive_delivery_03.py','deliver_semantic_vad_02.py','resume_delivery_03.py','reserve_delivery_capacity.py','maintenance-before-01.json','publication-composition-02.json'):
 files[n]=W/n
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(p))
for n,p in files.items():
 raw=p.read_bytes();assert not any(s in raw for s in secrets),n;assert b'-----BEGIN '+b'PRIVATE KEY-----' not in raw,n
assert not O.exists();O.mkdir();save(O/'index.json',{n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()})
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
acceptance=dict(status='ACCEPT_NATIVE_SEMANTIC_VAD_DELIVERY',revision=346,current=current,state='STOPPED',commands=19,seconds=result['seconds'],new_gpu_starts=0,outer_enabled=True,outer_charged_total=0,persistent_rpm=30,persistent_tpm=6000,alpha_output_limit=3457,usage_reset=False,fixture_tpm_not_installed_to_existing_state=True,manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_to_retained_automatic_fault_actually_tested=True,reciprocal_automatic_fault_additionally_injected=False,reciprocal_registration_and_stopped_rollback_verified=True,older_engine_fallback=False,previous_rev336_preserved=True,strict_actual_finalizers_all_passed=True,original_failures_preserved=True,profile_history_and_cooldown_preserved=True,retired_intents_archived=5,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,maintenance_seconds=capacity['seconds'],files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,full_model_quality=False,performance_claim=False,long_stability_run=False,full_openai_compatibility=False,listening_and_similarity_accepted=False,listening_deferred_by_owner=True,all_master_tasks_active=True)
clients=read(R/'build/service-native-state/client-limits/policy.json')['state']['policy']['clients']
client_limits={c['id']:{k:c[k] for k in ('requests_per_minute','tokens_per_minute','max_output_tokens')} for c in clients}
assert client_limits=={'alpha':dict(requests_per_minute=30,tokens_per_minute=6000,max_output_tokens=3457),'beta':dict(requests_per_minute=1,tokens_per_minute=6000,max_output_tokens=256)}
acceptance['persistent_client_limits']=client_limits
assert result['command_attempts']==20 and result['original_timeout_preserved']
acceptance.update(command_attempts=20,original_publication_timeout_preserved=True,original_intent_resumed=result['original_request_resumed'],continuation_seconds=result['continuation_seconds'])
save(O/'acceptance.json',acceptance)
(O/'README.md').write_text(f'''# 原生语义 VAD 可回退交付 rev346

默认引擎 `{current['engine_binary_sha256']}`，服务包
`{current['manifest_sha256']}`。19 项 STOPPED 发布、实际整根回退与再次
前进通过，{result['seconds']:.3f} 秒，0 新增 GPU；服务保持 STOPPED，outer 启用
且累计启动0。首次发布驱动在60秒超时后保留FAIL与prepared双日志；
以原请求ID调用publish-resume完成，未重复迁移/重置预算。19项成功检查
共20次命令尝试，原超时和续办原件均保留。前驱rev336及恢复入口完整保留。

本次交付真实语义断句：ASR 完整前缀交给本机主模型评分，使用音频时钟
控制最长静默等待；续说取消并隔离旧评分，分类用量计入所属客户端。
[主轻实际资格](../serve-semantic-vad-primary-light-20261119/README.md)和
[Guardian 三组](../serve-semantic-vad-managed-recovery-20261119/README.md)
验证精确转录、私有评分结算、后端健康、入口和整包恢复后的能力保持。
恢复三组 4 模型、63 HTTP+10 Realtime、{composition['service_seconds']:.3f} 秒，
{composition['nvml_queries']} 次正常 NVML；原导入失败0模型/0业务保持；发布迁移修复后只补候选版本组，
累计6模型/87HTTP+14Realtime，保留/TLS与主轻未重跑。

alpha RPM30/beta RPM1、两端 TPM6000、alpha 输出3457及已用额度保持；验收夹具 TPM60000
未覆盖持久策略。profile 历史/冷却、版本周期与 outer 预算保持。
5 旧 intent、2 旧 generation、2 旧 registration 经维护 API 可恢复归档，
0 删除。回退使用同一已验语义引擎与保留控制器；候选→保留实际自动
恢复通过，反向完成登记及 STOPPED 根回退，未额外注入反向自动故障。

PR #51 的最终提交 CI 与主线合入另记。原 exact-code、声纹一致性失败及
用户延期听感保持，浮点边界接受不能替代音色质量。Realtime 对话/Live、
提示词音色以及其余 master 缺口继续实施；本阶段不表示完整 OpenAI
兼容、全模型质量、性能或长稳通过。
''')
intro=f'[rev346语义VAD可回退交付](evidence/serve-semantic-vad-delivery-20261119/README.md)\n完成：19项STOPPED检查/{result["seconds"]:.3f}秒，实际整根回退再前进，\n0新增GPU，原配额/用量/恢复历史/预算保持。发布超时原FAIL保留，原ID\n续办完成；19项成功检查共20次尝试。当前三组组合证据4模型、\n63HTTP+10Realtime/{composition["service_seconds"]:.3f}秒、{composition["nvml_queries"]}次NVML正常，\n5个真实语义回合通过；含原候选组合累计6模型/87HTTP+14Realtime。\n默认仍STOPPED；继续PR #51检查合入及全部\nmaster，原exact-code/声纹失败与用户延期听感保持。\n\n'
p=R/'docs/STATUS.md';detach(p);s=p.read_text()
rows={'发布':'rev346；服务包 `'+current['manifest_sha256']+'`','Generation':'`'+current['generation_sha256']+'`','引擎':'`'+current['engine_binary_sha256']+'`','引擎发布记录':'`'+current['engine_release_sha256']+'`','Guardian':'`'+release['guardian_sha256']+'`','原生入口':'`'+release['ingress_sha256']+'`','默认容量':'单流、ctx8192、prefill2048、主文本输出256、MTP k=3；inflight8/queue3；TTS 200帧、alpha输出3457/RPM30/TPM6000；参考ICL、Realtime转录与实际语义VAD','人工整包回退':'保留控制根 `'+acceptance['manual_root']+'`；同已验语义引擎、参考和周期保持；前驱rev336另保留','自动payload回退':'候选→保留控制包 `'+acceptance['automatic_payload']+'` 实际恢复已验；反向登记与STOPPED回退已验，未另注入反向故障；不是旧引擎回退'}
for name,value in rows.items():
 s,count=re.subn(r'^\| '+re.escape(name)+r' \| .* \|$',lambda _:f'| {name} | {value} |',s,count=1,flags=re.M);assert count==1,name
p.write_text(s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-19.md';detach(p);head,body=p.read_text().split('\n',1)
p.write_text(head+'\n\n## 语义VAD真实恢复与rev346可回退发行\n\n- 日期：2026-11-19。\n- 做了什么：'+intro.replace('(evidence/','(../evidence/')+'- 为什么：实际断句和计量须随恢复及发行保持，避免只在裸引擎通过。\n- 下一步：PR #51最终检查合入，继续Realtime对话/Live及全部master。\n  原失败和听感待验保持。\n'+body)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p)
entry=acceptance|dict(evidence='evidence/serve-semantic-vad-delivery-20261119/README.md')
g['semantic_vad_delivery_20261119']=entry
for task in g['tasks']:
 if task['id'] in ('A01','A10','A12','N06','R05','R06','Q01','Q02'):task['semantic_vad_delivery_20261119']=dict(revision=346,evidence=entry['evidence'])
 if task['id']=='Q02':task['latest_release']=entry;task['remaining_required']=['Semantic VAD final-head CI and actual main merge','Delivery of every remaining implementation']
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev346 or then-current default; pending host/camera maintenance handoff remains required.'
g['native_tts_progress']['managed']['latest_service_revision']=346
g['realtime_progress'].update(state='native_transcription_semantic_vad_delivered_rev346_conversation_live_pending',semantic_vad_delivered=True,semantic_vad_delivery=entry,full_realtime_api_qualified=False)
g['realtime_progress']['next']='Implement actual conversational Realtime, tool/TTS output and Live; continue remaining master work and preserve owner-deferred listening.'
g['realtime_progress']['semantic_vad'].update(state='DELIVERED_REV346_MAIN_PENDING',actual_primary_light_qualified=True,actual_managed_recovery_qualified=True,delivered=True,delivery_evidence=entry['evidence'])
g['next_task']='Semantic VAD final-head CI/main integration; implement conversation/Live and every remaining A/N/R/Q task. Preserve original failures and owner-deferred listening.'
g['next']='Continue all remaining Serve master implementation, targeted verification and delivery; this reversible publication is not total goal completion.'
save(p,g)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [语义VAD实际恢复](evidence/serve-semantic-vad-managed-recovery-20261119/README.md)：真实分类、计量、入口与整包恢复。\n- [rev346语义VAD可回退交付](evidence/serve-semantic-vad-delivery-20261119/README.md)：保留配额、参考音色和恢复预算。\n')
p=R/'docs/SERVE_REALTIME_2026-11-19.md';detach(p);s=p.read_text()
s=s.replace('注册音色ICL的encoder数值口径仍待决定；此处先推进不依赖该决定的\n传输与会话实现。两者最后都须完成真实业务、恢复和可回退交付。','用户已接受严格浮点边界判定并保留原exact-code失败，声纹机器质量\n失败与正常听感待验保持。当前参考ICL、Realtime转录和语义VAD已完成\n真实业务、恢复及可回退交付；对话/工具/音频输出与Live继续实现。')
s=s.replace('自动分段/可选处理器、对话与Live仍继续实现，实际Guardian组合和\n可回退交付尚待完成；默认rev326保持。不能把手动转录当作完整','自动分段、降噪、连续转录、历史及语义VAD现已完成实际Guardian组合和\n[rev346可回退交付](evidence/serve-semantic-vad-delivery-20261119/README.md)，\n默认STOPPED；主线检查另记，对话和Live继续实现。不能把转录当作完整')
s=s.replace('## 已有阶段证据\n','## 已有阶段证据\n\n以下保留各阶段当时的验证边界；当前发行与剩余工作以上节及STATUS为准。\n',1)
p.write_text(s)
print(json.dumps({k:acceptance[k] for k in ('status','revision','commands','seconds','files')}))

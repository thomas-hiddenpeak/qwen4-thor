import hashlib
import json
import os
import subprocess
import tarfile
import time
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
S = W/'validation-src'
O = W/'frozen-handoff-01'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def protected():
    return {str(R/n): sha(R/n) for n in (
        'build/q4t', 'build/q4t.release.json', 'build/service/manifest.json',
        'build/service.release.json', 'build/service-native-state/ledger.json')}
os.umask(0o077)
assert not S.exists() and not O.exists()
before = protected()
v = read(W/'delivery-01/result.json')
assert v['status'] == 'PASS_NATIVE_MAINTENANCE_DELIVERED'
current = v['publication']['current']
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
O.mkdir()
with (O/'worktree.stdout').open('x') as out, (O/'worktree.stderr').open('x') as err:
    subprocess.run(['git','worktree','add','--detach',str(S),commit], cwd=R,
                   stdout=out, stderr=err, check=True, timeout=120)
package = Path(current['package'])
links = {'q4t': package/'engine/q4t',
         'q4t.release.json': package/'engine/q4t.release.json',
         'service': package,
         'service.release.json': W/'delivery-01/service.release.json'}
(S/'build').mkdir()
for name, path in links.items():
    (S/'build'/name).symlink_to(path)
assert subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=S,text=True).strip() == str(R/'.git')
steps = []
for name, argv in (
    ('prepare', ['/usr/bin/python3','-I','-B','tools/serve_soak/native_stage.py',
                 'prepare','--profile','day','--package','build/service',
                 '--output','.q4t-work/day-01']),
    ('check', ['/usr/bin/python3','-I','-B','tools/serve_soak/native_stage.py',
               'check','--plan','.q4t-work/day-01/plan.json'])):
    start = time.monotonic()
    with (O/(name+'.stdout')).open('x') as out, (O/(name+'.stderr')).open('x') as err:
        result = subprocess.run(argv,cwd=S,stdout=out,stderr=err,timeout=90)
    step = dict(name=name,argv=argv,cwd=str(S),exit_code=result.returncode,
                seconds=time.monotonic()-start)
    (O/(name+'.json')).write_text(json.dumps(step,indent=2)+'\n')
    steps.append(step)
    assert result.returncode == 0, name
assert protected() == before
plan = read(S/'.q4t-work/day-01/plan.json')
assert plan['package']['manifest_sha256'] == current['manifest_sha256']
assert not (S/'.q4t-work/day-01/execution').exists()
a = dict(status='PASS_FROZEN_DAY_HANDOFF',source_commit=commit,workspace=str(S),
         revision=266,package=plan['package'],service_id=plan['service_id'],
         plan=str(S/'.q4t-work/day-01/plan.json'),
         plan_sha256=sha(S/'.q4t-work/day-01/plan.json'),sources=len(plan['sources']),
         links={n:str(p) for n,p in links.items()}, protected_default=before,
         production_unchanged=True,same_git_common_dir=True,steps=steps,
         model_actions=0,executed=False,owner='user')
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')

P = R/'docs/evidence/serve-native-maintenance-day-handoff-20261117'
P.mkdir()
with tarfile.open(P/'handoff.tar.gz','w:gz') as tar:
    for p in sorted(O.iterdir()):
        tar.add(p,arcname='review/'+p.name,recursive=False)
    for n in ('plan.json','handoff.json'):
        tar.add(S/'.q4t-work/day-01'/n,arcname=n,recursive=False)
    tar.add(W/'freeze_day.py',arcname='freeze_day.py',recursive=False)
a['archive_sha256'] = sha(P/'handoff.tar.gz')
(P/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(P/'README.md').write_text("""# rev266独立快照长稳交接

当前精确v20包和源码的day prepare/check通过，0模型动作；24小时
仍由用户显式运行，未安装后台任务。与生产共享原严格GPU锁，后续
开发不漂移此计划；rev260及更早包、工作区和计划保持。
详见[交接入口](../../SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)。
""")
p=R/'docs/SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md';s=p.read_text()
start=s.index('当前rev260');end=s.index('## 当前已准备的入口')
s=s[:start]+f"""当前rev266包`{current['manifest_sha256']}`
已交付三类原生保留管理和已审查旧计划的原样恢复。28个独立CPU用例/
32次执行、34条实际维护命令及15条STOPPED发布/旧根回退/再前进
通过，0新增GPU。引擎/协议/runtime控制器、native helper、客户端和
profile保持原身份，复用原5启动20请求的
[真实业务证据](evidence/serve-video-projective-composition-20261117/README.md)。
[rev266交付](evidence/serve-native-maintenance-delivery-20261117/README.md)
记录旧入口正常及原周期/预算保持，没有把CPU夹具称为新模型验收。
连续60秒长稳驱动短验仍属于rev188，[原证据](evidence/serve-native-soak-business-20261116/README.md)保留。

[当前独立day prepare/check](evidence/serve-native-maintenance-day-handoff-20261117/README.md)
已完成，24小时未运行。快照固定`{commit[:8]}`及rev266包，不依赖活动
工作区和未来默认指针；原rev260及更早快照保持。

"""+s[end:]
s=s.replace('1aaf062e-ad9e-461e-931c-72ea7094498b',plan['service_id'])
s=s.replace('serve-client-receipts-20261117/validation-src','serve-native-maintenance-20261117/validation-src')
s=s.replace('此计划继续验证rev260','此计划继续验证rev266').replace('把rev260证据移称新版本证据','把rev266证据移称新版本证据')
s=s.replace('原rev254/rev244/rev234/rev224/rev214/rev204独立快照','原rev260/rev254/rev244/rev234/rev224/rev214/rev204独立快照');p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
    if task['id']=='Q03':task['current_native_day_handoff']=a|dict(evidence='evidence/serve-native-maintenance-day-handoff-20261117/README.md')
j['next']='rev266 native day handoff frozen and unexecuted. Complete PR43 final-head checks and actual main merge; continue all remaining protocol/backend/SDK and cold/resource/host tasks.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/STATUS.md';s=p.read_text();s=s.replace('下一步固定用户day、修复PR43两项CPU夹具时限并完成','rev266用户day已prepare/check且未运行；PR43两项CPU夹具已修正，继续')
p.write_text(s)
p=R/'docs/log/2026-11-17.md';h,t=p.read_text().split('\n',1);p.write_text(h+"""

## rev266独立长稳交接已固定

精确包与detached源码的day prepare/check通过，0模型动作；生产
默认及账本保持，原rev260及更早入口保留，后续开发不漂移本计划。
下一步PR43最终head检查及实际合main，继续全部剩余master任务；
24小时未启动，长稳实跑仍由用户负责。
"""+t)
print(json.dumps({k:a[k] for k in ('status','source_commit','revision','service_id','sources','model_actions')}))

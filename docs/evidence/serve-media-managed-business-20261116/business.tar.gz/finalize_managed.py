import fcntl,json,socket,sys,tarfile,shutil
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tools/evalscope'))
import gpu_exclusive as guard
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import bundle
W=Path(__file__).resolve().parent;out=W/'managed-02';e=out/'execution';plan=read(out/'plan.json');result=read(e/'result.json');g=read(out/'lease/exit.json')
require(result['status']=='PASS_MANAGED_ADAPTIVE_PROFILES' and result['failure'] is None and result['cleanup_failure'] is None and result['seconds']<900,'managed business failure')
require(result['budget']['counts']['starts']==3 and result['budget']['counts']['chats']==12 and result['budget']['counts']['probes']==0,'budget differs')
actual,expected=g['command'],plan['command']
require(len(actual)==len(expected)==6 and all(actual[i]==expected[i] for i in [1,3,4]) and Path(shutil.which(actual[0])).resolve()==Path(expected[0]).resolve() and all((ROOT/actual[i]).resolve()==(ROOT/expected[i]).resolve() for i in [2,5]),'strict executed command differs')
require(g['status']=='COMPLETED' and g['child_returncode']==0 and g['compute_backend']=='nvml' and g['lease_inherited_by_child'] and not g['external_lease'],'strict lease differs')
q=[json.loads(line) for line in (out/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(q and all(x['status']=='OK' and x['returncode']==0 for x in q),'NVML failure')
for n,h in plan['sources'].items():require(sha(ROOT/n)==h,'source drift: '+n)
for item in plan['protected']:require(sha(item['path'])==item['sha256'],'default drift')
bundle.verify(plan['package']['package'],plan['package']['manifest_sha256'])
stop=read(e/'stop.json');state=read(e/'stopped-ledger.json');launch=read(e/'launcher-result.json')
require(stop['cleanup_confirmed'] and stop['stop_durable'] and launch['guardian_exit_code']==0 and state['desired']=='STOPPED' and all(v is None for v in state['active'].values()),'durable cleanup incomplete')
processes=guard.processes()
for row in result['models'].values():require(processes.get(row['pid'],{}).get('start_ticks')!=row['start_ticks'],'model survives')
for i in [1,2,3]:
 row=read(e/f'ready-{i}.json')
 for role in ['guardian','controller','gateway']:require(processes.get(row[role+'_pid'],{}).get('start_ticks')!=row[role+'_start_ticks'],role+' survives')
for port in [18190,18191,18192]:
 with socket.socket() as sock:sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);sock.bind(('127.0.0.1',port))
with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
pressure=read(e/'pressure.json');require(pressure['state']=='released' and pressure['reason']=='released_by_owner' and pressure['all_owned_pages_released'] and pressure['allocated_bytes']<=24*1024**3,'pressure ownership/bound failure')
require(min(r['available_bytes'] for r in pressure['observations'])>=20*1024**3,'independent RAM floor crossed')
business=read(e/'business-final.json');require(business['status']=='PASS' and business['actual_visual_stages']==3 and business['actual_tool_executions']==1 and all(business[k] for k in ['frozen_media_preserved','media_sse_after_promotion','no_tool_or_request_replay','stored_call_preserved','quota_preserved','control_tree_unchanged']),'incomplete closure')
receipt=dict(status='ACCEPT_MANAGED_VISUAL_PROFILE_RECOVERY',manifest_sha256=plan['package']['manifest_sha256'],engine_binary_sha256=plan['package']['engine_binary_sha256'],counts=result['budget']['counts'],seconds=result['seconds'],nvml_queries=len(q),env_abort=False,postflight=dict(sources_unchanged=True,owned_processes_gone=True,ports_free=True,lock_released=True,default_unchanged=True),actual_business=business,pressure=dict(allocated_bytes=pressure['allocated_bytes'],min_observed_available_bytes=min(r['available_bytes'] for r in pressure['observations']),all_owned_pages_released=True),scope='Actual controlled pressure thresholds, isolated keys/ports; production control/engine/profile identities. Exact delivery package and version fallback still require their own acceptance.',default_changed=False,performance_claim=False,remaining_master_tasks_open=True)
save(out/'acceptance.json',receipt)
archive=ROOT/'docs/evidence/serve-media-managed-business-20261116';archive.mkdir();save(archive/'acceptance.json',receipt)
with tarfile.open(archive/'business.tar.gz','w:gz') as tar:
 for f in sorted(out.rglob('*')):
  if f.is_file() and not any(part in ['state','bundle'] for part in f.relative_to(out).parts) and not f.name.endswith('policy.json'):
   require(b'PRIVATE KEY-----' not in f.read_bytes(),'unexpected private key');tar.add(f,arcname='managed-02/'+str(f.relative_to(out)))
 for n in ['managed_media.py','test_managed_media.py','finalize_managed.py','freeze-04.json','gpu-managed-02.json','gpu-managed-02.stderr','gpu-managed-02.stdout']:tar.add(W/n,arcname=n)
(archive/'README.md').write_text(f'''# 实际视觉服务自动主轻主恢复通过

2026-11-16，3启动/12请求/205.133秒，{len(q)}项NVML正常。12条包括
3次自检、2次预期配额拒绝、7次实际用户生成；0设备probe。原驱动
失败仍保留，没有将首次失败追改为通过。

原生服务实际RAM压力触发降级，临时分配8724152320字节并全部释放，
独立20GiB可用内存下限保持。三阶段真实视频/冻结历史、实际工具仅
执行一次及结果续答、持久调用、配额窗口、晋升后的视觉SSE与普通
Chat均过。Guardian/controller/gateway保持，仅模型按主轻主切换。

实际接受包8fe97f50使用受控阈值与私有Key/端口，原生控制与cd640ccc
引擎及媒体资格一致；不能冒称发行包7a8e9cd2或版本回退也已验。
服务持久STOPPED，原始状态私有保留，自有PID/端口/锁确认清理，
rev134不变；继续同能力保留版本、实际版本恢复、发行和全部master。
''')
print(json.dumps({k:v for k,v in receipt.items() if k!='actual_business'}))

"""One fixed prototype, two original utterances, one accepted ASR under a strict lease."""
import os,sys,json,hashlib,fcntl,stat,time,subprocess
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(R/'tools/native_tts'))
from acceptance import CASES,defaults,digest
from tempo_diagnosis import diagnostic_check
from phase_tempo_prototype import scale
PLAN=Path(sys.argv[1]);O=Path(sys.argv[2])

def main():
 lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);assert stat.S_ISREG(os.fstat(lease).st_mode);fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 p=json.loads(PLAN.read_text());assert p['limits']==dict(seconds=600,asr_seconds=180,asr_loads=1,cases=2,max_tokens=64,tts_loads=0,main_llm_loads=0,http_requests=0,artifact_mib=8,minimum_free_mib=256)
 assert os.environ.get('PYTHONPATH')==p['reference_pythonpath'];assert all(digest(Path(n))==h for n,h in p['reference_dependency_files'].items());assert defaults()==p['defaults'];assert digest(Path(p['asr_binary']))==p['asr_sha256']
 assert all(digest(R/n)==h for n,h in p['sources'].items())
 assert os.statvfs(W).f_bavail*os.statvfs(W).f_frsize>=256*1024**2
 assert not O.exists();O.mkdir(parents=True);start=time.monotonic();result=dict(status='RUNNING',comparisons=[],waveforms=[],model_loads=0,production_acceptance=False,defaults_before=defaults(),plan_sha256=digest(PLAN))
 child_env=dict(os.environ);os.environ['CUDA_VISIBLE_DEVICES']='';os.environ['USE_TORCH']='0'
 try:
  import numpy as np
  import soxr,transformers
  from transformers import Qwen2TokenizerFast,WhisperFeatureExtractor
  assert transformers.__version__=='4.57.6' and soxr.__version__=='0.5.0.post1'
  assets=Path(p['asr_assets']);tokenizer=Qwen2TokenizerFast.from_pretrained(assets,local_files_only=True);extractor=WhisperFeatureExtractor.from_dict(json.loads((assets/'preprocessor_config.json').read_text()))
  template=tokenizer.encode('<|im_start|>system\n<|im_end|>\n<|im_start|>user\n<|audio_start|><|audio_pad|><|audio_end|><|im_end|>\n<|im_start|>assistant\n',add_special_tokens=False);assert template.index(151676)==9 and template.count(151676)==1
  cases=[]
  for index,item in enumerate(p['utterances']):
   path=Path(item['pcm']);assert digest(path)==item['sha256'];original=np.fromfile(path,'<f4');assert original.size==item['samples']
   pcm,meta=scale(original,4);assert pcm.size==(original.size+3)//4 and meta['clipped_samples']==0 and meta['analysis_coverage_min']>.5
   out=O/f'case-{index}';out.mkdir();pcm.tofile(out/'pcm24.f32');meta.update(sha256=digest(out/'pcm24.f32'),original_sha256=item['sha256'],utterance=index);result['waveforms'].append(meta)
   signal=soxr.resample(pcm,24000,16000,quality='HQ').astype('<f4');mel=extractor._np_extract_fbank_features(signal[None,:],'cpu')[0];frames=signal.size//160;assert mel.shape==(128,frames) and 0<frames<=3000 and np.isfinite(mel).all()
   count=frames//100*13+((frames%100)+7)//8;row=dict(frames=frames,samples=int(signal.size),audio_tokens=count,audio_start=9,max_new_tokens=64,tokens=template[:9]+[151676]*count+template[10:])
   for name,value in [('pcm',signal),('mel',mel)]:
    q=out/(name+'.f32');value.astype('<f4').tofile(q);row[name]=str(q);row[name+'_sha256']=digest(q)
   cases.append(row)
  asr=O/'asr-plan.json';asr.write_text(json.dumps(dict(cases=cases),indent=2)+'\n');command=[p['asr_binary'],p['asr_assets'],str(asr),str(O/'asr')];result.update(command=command,model_loads=1)
  with (O/'asr.log').open('wb') as log:r=subprocess.run(command,env=child_env,cwd=R,pass_fds=(lease,),stdout=log,stderr=subprocess.STDOUT,timeout=min(180,600-(time.monotonic()-start)))
  result['asr_returncode']=r.returncode;assert r.returncode==0
  for index in range(2):
   d=O/'asr'/f'case-{index}';receipt=json.loads((d/'result.json').read_text());result['comparisons'].append(dict(utterance=index,**diagnostic_check((d/'text.txt').read_text(),receipt,CASES[index])))
  result['status']='PROTOTYPE_CONTENT_PASS_PENDING_LEASE' if all(x['passed'] for x in result['comparisons']) else 'FAILED_PROTOTYPE_CONTENT'
 except BaseException as e:result.update(status='FAILED_PROTOTYPE_EXECUTION',error=repr(e))
 finally:
  result.update(seconds=time.monotonic()-start,defaults_unchanged=defaults()==result['defaults_before'],artifacts={str(q.relative_to(O)):digest(q) for q in O.rglob('*') if q.is_file()})
  if not result['defaults_unchanged']:result.update(status='FAILED_PROTECTED_DEFAULT_CHANGED')
  result['artifact_bytes']=sum(q.stat().st_size for q in O.rglob('*') if q.is_file());assert result['artifact_bytes']<8*1024**2
  (O/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','seconds','model_loads','defaults_unchanged']},ensure_ascii=False))
 return 0 if result['status']=='PROTOTYPE_CONTENT_PASS_PENDING_LEASE' else 1
if __name__=='__main__':raise SystemExit(main())

"""Test-only independent phase-locked time scaling; not a production backend.

Equations follow Barry/Dorran/Coyle, DAFx-2008, sections 2-3. No upstream
source is copied. NumPy is used only in this bounded development prototype.
"""
import math
import numpy as np

WINDOW = 1024
HOP = 64
MAX_INPUT = 240000


def scale(pcm, speed):
    pcm = np.asarray(pcm, dtype=np.float64)
    if (pcm.ndim != 1 or not 0 < pcm.size <= MAX_INPUT or
            not math.isfinite(speed) or not .25 <= speed <= 4 or
            not np.isfinite(pcm).all() or np.max(np.abs(pcm)) > 1):
        raise ValueError('bounded finite normalized mono PCM and speed required')
    length = math.ceil(pcm.size / speed)
    output = np.zeros(length, np.float64)
    weights = np.zeros(length, np.float64)
    covered = np.zeros(pcm.size, np.float64)
    window = .5 - .5 * np.cos(2 * np.pi * np.arange(WINDOW) / WINDOW)
    omega = 2 * np.pi * np.arange(WINDOW // 2 + 1) / WINDOW
    previous_phase = previous_output = previous_center = None
    frames = 0
    for center in range(-WINDOW // 2, length + WINDOW // 2, HOP):
        source_center = math.floor(center * speed)
        start = source_center - WINDOW // 2
        lo, hi = max(0, start), min(pcm.size, start + WINDOW)
        frame = np.zeros(WINDOW, np.float64)
        if hi > lo:
            frame[lo-start:hi-start] = pcm[lo:hi]
            covered[lo:hi] += window[lo-start:hi-start] ** 2
        spectrum = np.fft.rfft(frame * window)
        magnitude, phase = np.abs(spectrum), np.angle(spectrum)
        if previous_phase is None:
            accumulated = phase.copy()
        else:
            delta = source_center - previous_center
            residual = (phase - previous_phase - omega * delta + np.pi) % (2 * np.pi) - np.pi
            accumulated = previous_output + (omega + residual / delta) * HOP
        peaks = np.flatnonzero((magnitude[1:-1] >= magnitude[:-2]) &
                              (magnitude[1:-1] > magnitude[2:])) + 1
        if peaks.size:
            peaks = peaks[magnitude[peaks] >= np.max(magnitude) * 1e-5]
        if not peaks.size:
            peaks = np.array([int(np.argmax(magnitude))])
        boundaries = (peaks[:-1] + peaks[1:]) / 2
        nearest = peaks[np.searchsorted(boundaries, np.arange(magnitude.size))]
        locked = accumulated[nearest] + phase - phase[nearest]
        previous_phase = phase
        previous_output = (locked + np.pi) % (2 * np.pi) - np.pi
        previous_center = source_center
        synthesized = np.fft.irfft(magnitude * np.exp(1j * locked), WINDOW) * window
        destination = center - WINDOW // 2
        lo, hi = max(0, destination), min(length, destination + WINDOW)
        if hi > lo:
            output[lo:hi] += synthesized[lo-destination:hi-destination]
            weights[lo:hi] += window[lo-destination:hi-destination] ** 2
        frames += 1
    if np.any(weights <= 0) or np.any(covered <= 0):
        raise ArithmeticError('uncovered input/output samples')
    output /= weights
    if not np.isfinite(output).all():
        raise ArithmeticError('nonfinite synthesis')
    raw_peak = float(np.max(np.abs(output)))
    clipped = int(np.count_nonzero(np.abs(output) > 1))
    return np.clip(output, -1, 1).astype('<f4'), dict(
        frames=frames, input_samples=pcm.size, output_samples=length,
        analysis_coverage_min=float(covered.min()), window=WINDOW, synthesis_hop=HOP,
        maximum_analysis_hop=math.ceil(HOP * speed), raw_peak=raw_peak,
        clipped_samples=clipped, streaming_implemented=False,
        production_acceptance=False)

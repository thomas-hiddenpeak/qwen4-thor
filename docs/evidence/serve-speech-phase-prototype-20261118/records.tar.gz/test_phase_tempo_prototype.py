"""Six numerical prototype checks; none is speech-content acceptance."""
import math
import unittest
import numpy as np
from phase_tempo_prototype import scale, MAX_INPUT

class PhaseTempo(unittest.TestCase):
    def test_rejects_invalid_signal_or_speed(self):
        for pcm, speed in [([], 4), ([float('nan')],4), ([1.1],4), ([[0]],4),
                           ([0],float('inf')), ([0],0), ([0],4.01),
                           (np.zeros(MAX_INPUT+1),4)]:
            with self.assertRaises(ValueError): scale(pcm,speed)
    def test_identity_preserves_full_random_waveform(self):
        pcm=np.random.default_rng(17).uniform(-.2,.2,16391).astype('<f4')
        output,meta=scale(pcm,1)
        self.assertLess(float(np.max(np.abs(output-pcm))),1e-7)
        self.assertEqual(meta['clipped_samples'],0)
    def test_silence_and_short_odd_tails_remain_exact(self):
        for size in (1,11,24001):
            output,meta=scale(np.zeros(size),4)
            self.assertEqual(output.size,math.ceil(size/4));self.assertTrue(np.all(output==0))
            self.assertGreater(meta['analysis_coverage_min'],0)
    def test_fractional_speed_covers_each_source_sample(self):
        pcm=np.full(4097,.03)
        for speed in (2.5,3.3,4):
            output,meta=scale(pcm,speed)
            self.assertEqual(output.size,math.ceil(pcm.size/speed))
            self.assertGreater(meta['analysis_coverage_min'],.5)
            self.assertTrue(np.isfinite(output).all());self.assertEqual(meta['clipped_samples'],0)
    def test_four_times_speed_preserves_three_distinct_pitches(self):
        time=np.arange(96000)/24000
        for frequency in (93,275,761):
            output,meta=scale(.2*np.sin(2*np.pi*frequency*time),4)
            middle=output[2400:-2400]
            power=np.abs(np.fft.rfft(middle*np.hanning(middle.size)))
            peak=int(np.argmax(power))*24000/middle.size
            self.assertLess(abs(peak-frequency),4)
            self.assertTrue(.10 < float(np.sqrt(np.mean(middle.astype(float)**2))) < .18)
            self.assertEqual(meta['clipped_samples'],0)
    def test_distinct_ordered_speech_like_bursts_survive(self):
        time=np.arange(48000)/24000;pcm=np.zeros(time.size)
        for start,frequency in ((.3,500),(1.3,1200)):
            selection=(time>=start)&(time<start+.2)
            pcm[selection]=.2*np.sin(2*np.pi*frequency*time[selection])
        output,meta=scale(pcm,4)
        for start,frequency,other in ((.3,500,1200),(1.3,1200,500)):
            center=int((start+.1)/4*24000);window=output[center-480:center+480]
            spectrum=np.abs(np.fft.rfft(window*np.hanning(window.size)))
            index=lambda f:round(f*window.size/24000)
            wanted=float(np.sum(spectrum[index(frequency)-1:index(frequency)+2]**2))
            unwanted=float(np.sum(spectrum[index(other)-1:index(other)+2]**2))
            self.assertGreater(wanted,5*unwanted+1e-8)
        self.assertEqual(meta['clipped_samples'],0)

if __name__=='__main__': unittest.main()

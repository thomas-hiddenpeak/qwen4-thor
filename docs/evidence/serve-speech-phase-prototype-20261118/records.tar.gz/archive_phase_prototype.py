"""Preserve the unsuccessful phase prototype; never promote failed audio."""
import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-speech-phase-prototype-20261118'
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
assert not O.exists();cpu=read(W/'phase-tempo-cpu-01/result.json');first=read(W/'phase-tempo-content-01/run/result.json');current=read(W/'phase-tempo-content-02/run/result.json');assert cpu['status']=='PASS' and first['model_loads']==0 and current['model_loads']==1 and current['status']=='FAILED_PROTOTYPE_CONTENT';assert not any(x['passed'] for x in current['comparisons']) and current['defaults_unchanged']
queries=0
for name in ['phase-tempo-content-01','phase-tempo-content-02']:
 root=W/name;guard=read(root/'lease/exit.json');assert guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1 and guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease']
 rows=[json.loads(l) for l in (root/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(x['status']=='OK' and x['returncode']==0 for x in rows);queries+=len(rows)
files={}
for name in ['phase-tempo-cpu-01','phase-tempo-content-01','phase-tempo-content-02','rebuildable-cache-retirement-07','rebuildable-cache-retirement-08','transport-cache-retirement-01']:
 for p in (W/name).rglob('*'):
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(W))]=p
for name in ['phase_tempo_prototype.py','test_phase_tempo_prototype.py','phase_tempo_content.py','phase-tempo-plan-01.json','phase-tempo-content-plan-01.json','phase-tempo-content-plan-02.json','phase-reference-preflight-01.json','phase-tempo-cpu-precheck-01.json','archive_phase_prototype.py']:
 files[name]=W/name
assert sum(p.stat().st_size for p in files.values())<8*1024**2
for p in files.values():assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in p.read_bytes()
O.mkdir();index={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz',compresslevel=9) as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 for row in archive.getmembers():assert hashlib.sha256(archive.extractfile(row).read()).hexdigest()==index[row.name]['sha256']
value=dict(status='NO_GO_PHASE_TEMPO_PROTOTYPE_CONTENT',cpu_tests=6,cpu_seconds=cpu['seconds'],asr_loads=1,tts_loads=0,main_llm_loads=0,http_requests=0,original_utterances=2,content_seconds=current['seconds'],preload_failure_seconds=first['seconds'],preload_failure_preserved=True,comparisons=current['comparisons'],waveforms=current['waveforms'],nvml_queries=queries,nvml_all_ok=True,default_revision=316,defaults_unchanged=True,production_acceptance=False,streaming_implemented=False,full_model_quality=False,performance_claim=False,master_goal_complete=False,archive_sha256=sha(O/'records.tar.gz'),next='Analyze existing acoustic evidence and ASR time resolution before choosing a concrete repair; no parameter sweep or scope removal',oracle_resolution=dict(original_frames=[320,312],original_audio_tokens=[42,41],fast_frames=[80,78],fast_audio_tokens=[10,10],causal_conclusion_proven=False),prototype_environments=dict(cpu_numpy='1.26.4',reference_numpy='2.5.2',production_numerical_equivalence_accepted=False))
put(O/'result.json',json.dumps(value,ensure_ascii=False,indent=2)+'\n');put(O/'index.json',json.dumps(index,indent=2)+'\n')
put(O/'README.md','''# 4倍语速相位锁定原型未通过内容检查

固定1024窗/64合成步、4倍分析步256的独立原型，6项CPU/0.301秒
通过；这只能说明长度、音高、覆盖与合成事件边界，不能替代语音。
实际1次ASR加载/原两句/4.828秒，0TTS/主LLM/HTTP，关键词仍错：
英文native speech被识别为A S V，中文会议下午被识别为欢迎从。
原句和完整输出都保留，正常EOS不能代替内容正确，原型不进入生产。

两句全部输入分析权重覆盖最小为1.5，输出无削波，不能再把失败
仅归于整段跳采样；但这些也不证明声学信息完整。ASR输入由
320/312帧与42/41音频token降至80/78帧和各10 token。该事实提示
需要区分声学损失和识别器时间分辨率，目前未证明根因，不能据此
将内容失败改判。下一步先分析已有声学数据，不追加参数试跑。

首次驱动遗漏既有reference-deps路径，在模型加载前失败；原记录
保留，补齐已存在且逐SHA绑定的依赖后才执行唯一ASR加载。
CPU原型使用NumPy1.26.4，参考环境2.5.2，不声称两环境或未来原生
实现已逐值等价。NumPy/Transformers/soxr仅为开发参考，未新增
生产依赖。默认rev316不变，全部master任务继续。

算法依据Barry、Dorran、Coyle的[DAFx-2008论文](https://www.dafx.de/paper-archive/2008/papers/dafx08_19.pdf)
中短时相位传播和峰值相位锁定公式独立实现，未复制外部源码。
[结果](result.json)、[逐文件摘要](index.json)、[原件](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();put(p,s.replace('## 正在推进\n\n','## 正在推进\n\n[4倍相位原型内容未过](evidence/serve-speech-phase-prototype-20261118/README.md)：\n6 CPU通过后，1 ASR/两原句/4.828秒仍错关键词，默认rev316保持。\n无采样空洞/削波；ASR有效输入42/41→10 token，尚不能证明根因，\n先分析现有证据，不追加参数试跑；原型不纳入生产，目标不删项。\n\n',1))
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);put(p,h+'\n\n## 4倍相位原型内容失败保留（2026-11-18）\n\n6 CPU通过，但唯一ASR加载/原两句/4.828秒均错关键词，正常EOS、\n分析覆盖1.5与无削波不代替内容。原缺依赖路径失败为0模型，保留。\nASR音频token从42/41降为10，仅作为待区分假设，不改判、不放宽\n内容要求，不引入生产。下一步分析现有声学与时间分辨率证据，再\n决定具体修复；主线PR #48继续检查，总目标active。\n[证据](../evidence/serve-speech-phase-prototype-20261118/README.md)。\n'+b)
print(json.dumps(dict(status=value['status'],files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size,nvml_queries=queries)))

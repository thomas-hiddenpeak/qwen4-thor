"""Reversible storage dedup of 12 byte-identical historical archive copies."""
import gzip,hashlib,json,os,shutil,stat,time
from pathlib import Path
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'retained-head-dedup-01';O.mkdir(exist_ok=False);rows=json.loads((V/'head-duplicate-review-01.json').read_bytes())['records'];expected='21522eabb4ab4f816d9f76eefe317a17e7ba668ebe838809eb4be87d84ef75c1';assert len(rows)==12 and all(r['sha256']==expected and 'archive' in r['path'] for r in rows)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while x:=f.read(4*1024**2):h.update(x)
 return h.hexdigest()
def stable(r):
 p=R/r['path'];s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_dev==r['device'] and s.st_ino==r['inode'] and s.st_size==r['bytes'] and s.st_mtime_ns==r['mtime_ns'] and s.st_ctime_ns==r['ctime_ns'];return s
for row in rows:stable(row)
inodes={(r['device'],r['inode']) for r in rows};open_files=[];inaccessible=[]
for process in Path('/proc').iterdir():
 if not process.name.isdigit():continue
 try:
  for fd in (process/'fd').iterdir():
   try:s=fd.stat()
   except FileNotFoundError:continue
   if (s.st_dev,s.st_ino) in inodes:open_files.append(str(fd))
 except (PermissionError,ProcessLookupError,FileNotFoundError):inaccessible.append(process.name)
assert not open_files
source=R/rows[0]['path'];free=shutil.disk_usage(V).free;assert free>=650*1024**2
start=time.monotonic();backup=O/'head.bf16.gz'
with source.open('rb') as f,gzip.open(backup,'wb',compresslevel=1) as out:shutil.copyfileobj(f,out,4*1024**2)
h=hashlib.sha256();size=0
with gzip.open(backup,'rb') as f:
 while x:=f.read(4*1024**2):h.update(x);size+=len(x)
assert h.hexdigest()==expected and size==335544320
plan=dict(kind='archived identical artifact hardlink dedup; byte content and paths preserved',rows=rows,sha256=expected,backup=str(backup.relative_to(R)),backup_sha256=sha(backup),open_fds_observed=open_files,inaccessible_proc_pids=inaccessible,original_free_bytes=free,default_assets_not_modified=True)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
# Restore independent inodes from the independent compressed backup, atomically.
(O/'restore.py').write_text('''from pathlib import Path
import gzip,hashlib,json,os,shutil
O=Path(__file__).resolve().parent;R=O.parents[2];p=json.loads((O/'plan.json').read_bytes());archive=R/p['backup'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==p['backup_sha256']
assert shutil.disk_usage(O).free>=len(p['rows'])*335544320+256*1024**2
for r in p['rows']:
 target=R/r['path'];tmp=target.with_name(target.name+'.restore-'+str(os.getpid()));assert not tmp.exists();h=hashlib.sha256()
 with gzip.open(archive,'rb') as src,tmp.open('xb') as out:
  while data:=src.read(4*1024**2):h.update(data);out.write(data)
 assert h.hexdigest()==p['sha256']
 os.chmod(tmp,int(r['mode'],8));os.utime(tmp,ns=(r['mtime_ns'],r['mtime_ns']));os.replace(tmp,target)
print('restored independent original artifact files')
''')
completed=[]
for row in rows[1:]:
 stable(row);target=R/row['path'];assert sha(target)==expected and sha(source)==expected
 assert target.stat().st_mode==source.stat().st_mode and target.stat().st_mtime_ns==source.stat().st_mtime_ns
 temp=target.with_name(target.name+'.dedup-'+str(os.getpid()));assert not temp.exists();os.link(source,temp);os.replace(temp,target)
 assert sha(target)==expected;completed.append(row['path']);(O/'progress.json').write_text(json.dumps(dict(completed=completed),indent=2)+'\n')
assert len({(R/r['path']).stat().st_ino for r in rows})==1
result=dict(status='DEDUPLICATED_PATHS_AND_BYTES_PRESERVED',paths=len(rows),independent_backup_sha256=sha(backup),backup_bytes=backup.stat().st_size,free_before=free,free_after=shutil.disk_usage(V).free,seconds=time.monotonic()-start,original_content_sha256=expected,shared_archive_inode=True,restore_script=str((O/'restore.py').relative_to(R)),model_or_default_path_changed=False)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

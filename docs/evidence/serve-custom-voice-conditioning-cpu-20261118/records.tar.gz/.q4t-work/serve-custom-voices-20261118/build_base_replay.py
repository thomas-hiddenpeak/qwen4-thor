from pathlib import Path
import subprocess,time,json,hashlib,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'base-compute-build-01';O.mkdir(exist_ok=False);assert shutil.disk_usage(V).free>256*1024**2
p=R/'tools/native_tts/base_replay.cpp';data=subprocess.run(['clang-format',str(p)],check=True,capture_output=True).stdout;t=p.with_suffix('.edit');t.write_bytes(data);t.replace(p)
sources=['tools/native_tts/base_replay.cpp','src/audio/tts_config.cpp','src/audio/tts_layout.cpp','src/audio/tts_generation.cpp','src/audio/tts_dense.cu','src/audio/tts_model.cu','src/quant/lt_cache.cpp','src/text/tokenizer.cpp','src/io/json.cpp','src/trace/sha256.cpp','src/runtime/system_memory.cpp'];headers=['include/q4t/audio/tts_config.h','include/q4t/audio/tts_layout.h','include/q4t/audio/tts_generation.h','include/q4t/audio/tts_model.h','src/audio/tts_math_internal.h','src/audio/tts_config_data.h','include/q4t/audio/tts_speaker_layout.h','include/q4t/text/tokenizer.h','include/q4t/runtime/system_memory.h','include/q4t/quant/lt_cache.h','include/q4t/status.h'];nv='/usr/local/cuda-13.3/bin/nvcc';commands=[];objects=[]
for i,n in enumerate(sources):
 o=O/f'{i}.o';objects.append(str(o));commands.append([nv,'-std=c++23','-O3','-arch=sm_110a','-ccbin','g++-14','-Iinclude','-Ithird_party','-DQ4T_TTS_TRACE=1','-Xcompiler=-Wall,-Wextra,-Werror','-c',n,'-o',str(o)])
commands.append([nv,'-arch=sm_110a','-ccbin','g++-14',*objects,'-lcublasLt','-lpthread','-licui18n','-licuuc','-licudata','-o',str(O/'q4t_tts_base_replay')]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=dict(commands=commands,sources={n:sha(R/n) for n in sources+headers},gpu_actions=0,model_loads=0);(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic();records=[]
with (O/'build.log').open('wb') as log:
 for cmd in commands:
  r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180);records.append(dict(command=cmd,returncode=r.returncode))
  if r.returncode:break
result=dict(status='PASS_BUILD_ONLY' if r.returncode==0 else 'FAIL_BUILD',seconds=time.monotonic()-start,returncode=r.returncode,warnings=(O/'build.log').read_text().count('warning:'),records=records)
if r.returncode==0:result['binary_sha256']=sha(O/'q4t_tts_base_replay')
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='records'}));raise SystemExit(r.returncode)

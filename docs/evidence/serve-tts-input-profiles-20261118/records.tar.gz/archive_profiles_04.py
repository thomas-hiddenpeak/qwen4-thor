from pathlib import Path
import hashlib,json,tarfile
R=Path.cwd();W=R/'.q4t-work/serve-native-tts-20261118';P=W/'managed-profiles-04';O=R/'docs/evidence/serve-tts-input-profiles-20261118';O.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
accepted=read(P/'acceptance.json');result=read(P/'result.json');plan=read(P/'plan.json')
assert accepted['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
secret=read(P/'client-policy.json')['gateway_token'].encode()
files={};omitted={}
for p in P.rglob('*'):
 if not p.is_file():continue
 name=str(p.relative_to(P))
 if any(x in p.parts for x in ('objects','prefix-cache','session-cache')):continue
 if p.suffix not in ('.json','.jsonl','.wire','.log'):continue
 if p.name=='client-policy.json' or p.name.endswith('-chat-audio.request.json') or secret in p.read_bytes():
  omitted[name]=dict(sha256=sha(p),bytes=p.stat().st_size);continue
 files['managed-profiles-04/'+name]=p
for dirname in ['rebuildable-cache-retirement-03','rebuildable-cache-retirement-04','github-object-sync-01']:
 for p in (W/dirname).glob('*.json'):
  if dirname=='github-object-sync-01' and not p.name.startswith('first-commit-push-01'):continue
  files[dirname+'/'+p.name]=p
files['archive_profiles_04.py']=Path(__file__)
with tarfile.open(O/'records.tar.gz','w:gz',compresslevel=9) as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
index={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in files.items()}
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 for item in archive.getmembers():assert hashlib.sha256(archive.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
aggregate=dict(accepted,binary_sha256=plan['binary_sha256'],source_commit=plan['source_commit'],records=index,omitted_private_or_audio_requests=omitted,archive_sha256=sha(O/'records.tar.gz'),prior_failures_preserved=True,cumulative_core_process_attempts=4,cumulative_actual_weight_loads=3,cumulative_post_requests=37,model_quality_limitation=read(P/'primary-separator.quality.json'),actual_auxiliary_release_and_reload=True,managed_tls_recovery_pending=True,master_complete=False)
put(O/'aggregate.json',json.dumps(aggregate,indent=2,ensure_ascii=False)+'\n')
put(O/'README.md','''# 输入与语音合成组合：主轻配置业务通过

2026-11-18。候选 `5130cae65358f151cbf9c055af9d2c521e6acc46183c32aa70b6581ab39f6fee` 在同一严格GPU租约内完成 **2次核心启动、26 POST、204.599秒**；190次NVML查询全部正常，两个模型退出0，自有进程、端口和租约完整释放。默认rev306保持停止且身份不变。

主、轻配置各13条：轮流A/B/A说话人、真实双人重叠、JSON schema、实际项目文档工具及回填、embedding、视觉、Speech MP3、Chat WAV、ASR、Chat语音输入、alignment/VAD组合，以及输入工作后的Speech重载。全部按真实响应、完整音频摘要、用量和健康状态验证。两次重载均确认TTS先释放为零device bytes，再增加一次真实load；输入模型权重真实释放且元数据保留，CPU VAD保持ready。

原额外C／“Um.”缺陷已由同一原录音实际验证修复；A/B/A三段、三句话和时间保留。真实重叠仍保留两个人及1.68秒重叠。按用户明确决定，“hurt→hurts”记模型质量限制：原WER 1/7（0.142857）和原阈值0.125仍保留，未伪装成原质量门槛通过；其余文本、身份和时间检查不放宽。

[聚合与索引](aggregate.json)、[原始记录](records.tar.gz)保存冻结计划、实际请求/响应、主轻资格、释放/重载健康、监控与清理。私有身份和原录音请求仅保留摘要；无新增完整性能或模型质量矩阵。原容量启动与说话人FAILED记录保持；含失败累计4核心进程尝试、3次实际核心加载、37 POST，另外两次定位仅加载分离/ASR组件。

为准备后续包，只清理可重建编译缓存；旧程序逐SHA无损归档，第三方libarchive依赖被选择器保护，0误删。GitHub首次未同步提交的推送再次HTTP408，远端仍487bf45f，不能称已推送。

后续继续原生TLS、实际受管恢复与可回退发行；本记录不批准默认替换，不等于语音全部能力或总计划完成。
''')
p=R/'docs/STATUS.md';s=p.read_text();marker='## 正在推进\n';entry='\n[输入与TTS组合主轻26条真实业务通过](evidence/serve-tts-input-profiles-20261118/README.md)：\n2核心/26POST/204.599秒，190次NVML全正常，退出0及资源完整清理。\nA/B/A不再多出说话人；双人重叠保留，hurt→hurts按用户决定保留\n原WER并记质量限制。Speech/Chat完整音频、真实usage及输入/TTS\n双向释放/重载通过。默认rev306保持；继续原生TLS/恢复/发行，\n其余语音及全部master任务未结束。远端推送HTTP408仍待处理。\n';put(p,s.replace(marker,marker+entry,1))
p=R/'docs/log/2026-11-18.md';title,body=p.read_text().split('\n',1);put(p,title+'\n\n## 输入与语音合成主轻实际组合通过\n\n- 日期：2026-11-18。候选5130cae6，同严格租约2核心/26POST/204.599秒；190次NVML正常，退出0、进程/端口/锁清理通过。额外说话人实际修复，原双人重叠及用户允许词形质量限制均保留。\n- 真实闭环：主轻各13条，含文档工具、视觉、ASR/说话人/分离、Speech/Chat及完整音频/usage和双向权重释放、再次加载。证据 `evidence/serve-tts-input-profiles-20261118/`；原失败保留，默认不变。\n- 资源：旧程序无损保留后退役重建缓存；第三方静态库被前置选择器拒绝，未删除。后续限定CMake生成对象，清理74文件/145910776逻辑字节；源码、模型、程序、历史记录不变。GitHub推送HTTP408、远端487bf45f仍未更新。\n- 下一步：把TTS加入实际TLS和受管恢复后的业务验证，再收尾发行；不以本阶段停止总目标。\n'+body)
p=R/'docs/serve-master-goals-v2.json';v=read(p);m=v['native_tts_progress']['managed'];m['state']='primary_light_actual_pass_tls_recovery_delivery_pending';m['capacity_fix']['actual_business_pending']=False;m['composition_failure']['actual_fix_pending']=False;m['qualified_profiles']=dict(evidence='evidence/serve-tts-input-profiles-20261118/README.md',binary_sha256=plan['binary_sha256'],starts=2,posts=26,seconds=result['seconds'],nvml_queries=190,default_changed=False,managed_composition_pending=True);put(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
print('archived',len(files),'files', (O/'records.tar.gz').stat().st_size)

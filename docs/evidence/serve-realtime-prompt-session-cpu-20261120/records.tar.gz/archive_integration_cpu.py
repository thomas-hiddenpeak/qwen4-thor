from pathlib import Path
import json,hashlib,tarfile,re,os
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-prompt-session-cpu-20261120'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
plan=read(W/'integration-plan-03.json');result=read(W/'integration-cpu-01/result.json');source=read(W/'integration-cpu-01/source-check.stdout');build=read(W/'integration-build-03/result.json');sharing=read(W/'evidence-sharing-03/result.json')
assert result['status']=='PASS' and result['passed']==57 and source['inventory_current'] and source['mutation_checks']==20 and build['exit_code']==0 and sharing['status']=='PASS_FROZEN_EVIDENCE_SHARED'
assert not re.search(r'\bwarning:',(W/'integration-build-02/build.log').read_text()+(W/'integration-build-03/build.log').read_text())
files={}
for prefix in ('integration-cpu-01','integration-build-01','integration-build-02','integration-build-03','evidence-sharing-03'):
 for p in (W/prefix).rglob('*'):
  if p.is_file() and 'fixtures' not in p.relative_to(W/prefix).parts:files[str(p.relative_to(W))]=p
for name in ('integration-plan-01.json','integration-plan-02.json','integration-plan-03.json','integration-required-tests.txt','integration-detach-01.json','prepare_integration_cpu.py','archive_integration_cpu.py','deduplicate_frozen_evidence_03.py'):files[name]=W/name
for f,h in plan['sources'].items():
 assert sha(R/f)==h,f
 files['source/'+f]=R/f
assert not O.exists();O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
a=dict(status='PASS_REALTIME_PROMPT_SESSION_CPU',tests=57,new_tests=11,seconds=result['seconds'],source_mutations=20,final_build_seconds=build['seconds'],build_warnings=0,original_build_failure_preserved=True,lookup_deadline_milliseconds=250,worker_timeout_and_disconnect_tested=True,prefix_history_indices_projected=True,new_gpu_starts=0,actual_realtime_business_accepted=False,file_media_preparation_pending=True,default_revision=356,default_unchanged=True,pr52_merged_excludes_prompt=True,evidence_paths_preserved=True,duplicate_bytes_reclaimed=sharing['logical_duplicate_bytes_reclaimed'],files=len(files),archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a)
(O/'README.md').write_text(f'''# Realtime Prompt 会话／计划接线 CPU

57 项针对性 CPU 用例通过，{a['seconds']:.3f} 秒、0GPU；其中新增11项，
其余为直接受影响的会话、pump、计划和设置合同。20来源反例通过。
最终构建 {a['final_build_seconds']:.3f} 秒、零警告；原缺少输出序列化声明
的编译失败保留。另在源码审查修正运行时身份string_view拼接，尚未
构建或验收新模型程序，不能将host编译当作完整运行时构建。

实际会话拥有默认/模板/显式覆盖事务，响应持独立快照。新选择走原生
对象工作线程，截止时间不晚于250ms及请求剩余时间；断连信号传递至
读取，超时/取消不确认设置。查库失败后后续普通请求继续；CPU真实
对象进程卡住与断连均已覆盖。原租户隔离、版本删除后保持快照、并发
响应独立、单轮null与密钥撤销检查接线均覆盖。

模板前缀进入实际Responses/Chat计划与token计量路径，不能伪造公开
历史项；上下文截断只回写减去前缀偏移后的真实历史索引。单轮生成
显式设置仍优先，模板不能绕过客户预算或工具结果来源检查。

仍需完成文件/媒体前缀准备、必要运行时构建和真实SDK业务短验，之后
主轻/恢复资格及可回退发行。CPU通过不等于Prompt已具备业务资格。
PR #52已验文本/工具实现已合入main，未含本阶段；默认rev356不变。
全部master继续，原质量/环境失败与延期听感保持。

因本机磁盘不足，将一个已完成干净工作区的30,595份相同公开证据与
当前同SHA文件共享存储，释放395,872,316逻辑字节；每个原路径、SHA、
Git内容和默认程序保持，保留恢复独立文件脚本，没有删除独有证据。
''')
intro=f'[Prompt会话57项CPU通过](evidence/serve-realtime-prompt-session-cpu-20261120/README.md)：\n{a["seconds"]:.3f}秒/0GPU，11项新合同覆盖真实对象worker超时/断连、\n版本/租户/并发快照与前缀安全截断；20来源反例通过，原编译失败保留。\n继续文件/媒体前缀和实际SDK业务，尚未构建新运行时或取得Prompt\n业务资格；默认rev356不变，PR #52已合入，全部master保持active。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Prompt实际会话57项CPU通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：对象存储故障不能无界阻塞连接；模板下标与公开历史下标\n必须分别计量。原构建缺声明失败保留，只补声明后继续统一验证。\n磁盘压力下对一个干净冻结工作区做可逆相同证据共享，原路径/SHA\n全部保持，释放395,872,316逻辑字节；未动模型或当前服务。\n\n下一步：文件/媒体准备与真实SDK验收、能力保持与发行；全部master继续。\n'+b)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['realtime_progress']['prompt_session_20261120']=a|dict(evidence='evidence/serve-realtime-prompt-session-cpu-20261120/README.md',next='Complete file/media prefix preparation and runtime build; actual SDK business and profile/recovery delivery.');save(p,g)
p=R/'docs/SERVE_REALTIME_PROMPT_2026-11-20.md';detach(p);p.write_text(p.read_text().replace('## 已核实的依据','会话与计划接线另通过[57项CPU](evidence/serve-realtime-prompt-session-cpu-20261120/README.md)：\n对象读取有界取消、版本与并发快照、前缀计量及历史下标投影已接线；\n文件/媒体准备、运行时构建和真实SDK业务仍须完成。\n\n## 已核实的依据',1))
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [Realtime Prompt会话CPU](evidence/serve-realtime-prompt-session-cpu-20261120/README.md)：实际owner/对象worker/计划接线；文件与真实业务继续。\n')
b=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';assert sha(b)==result['binary_sha256'];os.link(b,W/'integration-cpu-01/qualified-contracts')
print(json.dumps(a))

from pathlib import Path
import json,hashlib,re,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from tools.serve_audit.check_inventory import current_surface,check
files=['include/q4t/server/realtime_chat_plan.h','include/q4t/server/realtime_conversation_session.h','include/q4t/server/realtime_prompt_settings.h','src/server/chat_realtime_conversation.cpp','src/server/realtime_chat_plan.cpp','src/server/realtime_conversation_session.cpp','src/server/realtime_prompt_settings.cpp','tests/server_realtime_chat_plan_test.cpp','tests/server_realtime_conversation_pump_test.cpp','tests/server_realtime_conversation_session_test.cpp','tests/server_realtime_prompt_settings_test.cpp']
a=current_surface(R);p=R/'tools/serve_audit/inventory.json';v=json.loads(p.read_text());changed={n:h for n,h in a['sources_sha256'].items() if v['sources_sha256'].get(n)!=h};assert set(changed)<=set(files),set(changed)-set(files);v['sources_sha256'].update(changed);assert not check(v,a),check(v,a);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
tests=[n for f in files if f.startswith('tests/') for n in re.findall(r'Q4T_TEST\(\s*(\w+)\s*\)',(R/f).read_text())];assert len(tests)==len(set(tests))
plan=dict(scope='Actual Realtime session owner and request planner prompt integration: bounded native object worker lookup/cancel, pinned snapshots, tenant failure/revocation, public history index projection. File/media prefix preparation and actual GPU business remain pending.',tests=tests,maximum_tests=len(tests),maximum_test_seconds=120,new_gpu_starts=0,maximum_lookup_milliseconds=250,sources={f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files},default_revision=356,default_unchanged=True,pr52_head='74759c6540d4440066820b5bf1e4c685aac7d9f3')
p=W/'integration-plan-01.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2)+'\n');(W/'integration-required-tests.txt').write_text('\n'.join(tests)+'\n')
intro=f'Prompt已接入会话更新、单轮选择与执行计划；250ms上限的对象读取\n沿用断连取消，旧快照不重新查库，模板前缀进入实际输入并将截断索引\n投影回公开历史。冻结{len(tests)}项针对性CPU/120秒/0GPU，覆盖实际对象\n工作线程、会话事务、并发和断连。文件/媒体前缀准备与真实业务继续\n完成；默认rev356不变，尚无Prompt业务资格，全部master保持active。\n\n'
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);head,body=p.read_text().split('\n',1);p.write_text(head+'\n\n## Prompt实际会话与计划接线、对象读取取消\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：模板回显不能替代实际执行，隐藏前缀下标不能删除错会话\n历史；辅助库卡住也不能永久堵住消息处理或阻止连接关闭。\n\n下一步：针对性CPU后完成文件/媒体准备及实际SDK业务，按原范围\n继续主轻/恢复与可回退交付；PR #52终检合入，全部master继续。\n'+body)
print(json.dumps(dict(tests=len(tests),updated_anchors=sorted(changed))))

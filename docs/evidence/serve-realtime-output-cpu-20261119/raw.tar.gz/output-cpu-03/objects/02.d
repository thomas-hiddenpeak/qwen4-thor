/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-03/objects/02.o: \
 src/server/native_chat_generation.cpp \
 include/q4t/server/native_chat_generation.h \
 include/q4t/server/chat_response_parser.h include/q4t/io/json.h \
 include/q4t/status.h include/q4t/server/custom_tools.h \
 include/q4t/server/output_constraints.h \
 include/q4t/server/reasoning_options.h \
 include/q4t/server/schema_receipt.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h include/q4t/server/object_store.h \
 include/q4t/server/request_limits.h src/server/object_protocol.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/output_schema.h src/server/responses_json.h
include/q4t/server/native_chat_generation.h:
include/q4t/server/chat_response_parser.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/custom_tools.h:
include/q4t/server/output_constraints.h:
include/q4t/server/reasoning_options.h:
include/q4t/server/schema_receipt.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/server/object_store.h:
include/q4t/server/request_limits.h:
src/server/object_protocol.h:
include/q4t/server/application_routes.h:
include/q4t/server/output_schema.h:
src/server/responses_json.h:

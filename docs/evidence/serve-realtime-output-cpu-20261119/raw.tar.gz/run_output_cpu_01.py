from pathlib import Path
import hashlib, json, re, shutil, subprocess, time

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = W / 'output-cpu-01'
O.mkdir(mode=0o700)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, v): p.write_text(json.dumps(v, indent=2) + '\n')
def run(name, cmd, timeout=120):
    start = time.monotonic()
    with (O / (name + '.log')).open('w') as log:
        try:
            code = subprocess.run(cmd, cwd=R, stdout=log,
                stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired: code = 124
    row = dict(command=cmd, exit_code=code, seconds=time.monotonic()-start)
    save(O / (name + '-result.json'), row)
    print(name, code, round(row['seconds'], 3), flush=True)
    if code:
        print((O / (name + '.log')).read_text()[-6000:], flush=True)
        raise SystemExit(code)
    return row

sources = ['tests/server_realtime_response_output_test.cpp',
    'src/server/realtime_response_output.cpp',
    'src/server/native_chat_generation.cpp',
    'src/server/chat_response_parser.cpp', 'src/server/output_constraints.cpp',
    'src/server/custom_tools.cpp', 'src/server/custom_regex.cpp',
    'src/server/schema_graph.cpp', 'src/server/schema_prefix.cpp',
    'src/server/schema_receipt.cpp', 'src/server/schema_decimal.cpp',
    'src/server/reasoning_options.cpp', 'src/server/legacy_tools.cpp']
names = re.findall(r'Q4T_TEST\((\w+)\)', (R / sources[0]).read_text())
assert len(names) == 14 and len(set(names)) == len(names)
reuse = [(W/'cpu-03/0.o', 'src/server/realtime_conversation.cpp',
          W/'cpu-03/source/src/server/realtime_conversation.cpp')]
for i, name in enumerate(['responses_item_shape', 'input_contract',
                         'output_schema', 'http_response']):
    rel = f'src/server/{name}.cpp'
    reuse.append((W/'cpu-02/objects'/f'{i+4:02d}.o', rel,
                  W/'cpu-02/source'/rel))
for i, rel in [(8, 'src/trace/sha256.cpp'), (9, 'src/io/json.cpp')]:
    reuse.append((W/'cpu-02/objects'/f'{i:02d}.o', rel, W/'cpu-02/source'/rel))
for obj, rel, old in reuse:
    assert obj.is_file() and sha(R/rel) == sha(old), rel
freeze = dict(tests=names, maximum_test_seconds=120, gpu_actions=0,
    purpose='Actual shared parser -> SDK-valid Realtime events and bounded history; primary output sink contracts. No socket/model acceptance.',
    regex_engine_cases=False,
    sources={n:sha(R/n) for n in sources},
    reused=[dict(object=str(p), sha256=sha(p), source=n,
                 source_sha256=sha(R/n)) for p,n,_ in reuse])
save(O/'freeze.json', freeze)
for n in sources:
    p = O/'source'/n; p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(R/n, p)
main = O/'main.cpp'
main.write_text('#include "q4t/test.h"\nint main() { return q4t::test::RunAllTests(); }\n')
objects = [str(p) for p,_,_ in reuse]; rows=[]
(O/'objects').mkdir()
for i, n in enumerate([*sources, str(main)]):
    obj = O/'objects'/f'{i:02d}.o'; objects.append(str(obj))
    rows.append(run(f'build-{i:02d}', ['g++-14','-std=c++23','-O1',
        '-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections',
        '-MMD','-MP','-Iinclude','-I'+str(W/'cpu-02/generated'),
        '-c',n,'-o',str(obj)]))
binary = O/'contracts'
rows.append(run('link', ['g++-14',*objects,'-Wl,--gc-sections','-pthread',
                        '-ldl','-o',str(binary)],60))
assert not any('warning:' in p.read_text() for p in O.glob('build-*.log'))
save(O/'build-result.json', dict(seconds=sum(r['seconds'] for r in rows),
    warnings=0,binary_sha256=sha(binary)))
result = run('contracts', [str(binary)],120)
log = (O/'contracts.log').read_text()
assert log.count('[PASS] ') == len(names) and '[FAIL]' not in log and '[SKIP]' not in log
assert all(sha(R/n) == h for n,h in freeze['sources'].items())
save(O/'result.json', dict(status='PASS_REALTIME_OUTPUT_CPU',tests=len(names),
    seconds=result['seconds'],gpu_actions=0,default_unchanged=True,
    actual_model_execution_accepted=False))

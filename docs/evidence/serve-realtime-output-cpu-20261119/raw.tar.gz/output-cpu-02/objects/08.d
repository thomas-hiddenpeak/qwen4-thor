/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/objects/08.o: \
 src/server/schema_prefix.cpp include/q4t/server/schema_prefix.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/custom_tools.h
include/q4t/server/schema_prefix.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/custom_tools.h:

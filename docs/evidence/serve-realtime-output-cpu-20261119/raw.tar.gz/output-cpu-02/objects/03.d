/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/objects/03.o: \
 src/server/chat_response_parser.cpp \
 include/q4t/server/chat_response_parser.h include/q4t/io/json.h \
 include/q4t/status.h include/q4t/server/custom_tools.h \
 include/q4t/server/output_constraints.h \
 include/q4t/server/reasoning_options.h \
 include/q4t/server/schema_receipt.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h include/q4t/server/request_json.h \
 include/q4t/server/request_limits.h include/q4t/server/schema_prefix.h \
 include/q4t/server/http_response.h include/q4t/server/request_control.h \
 include/q4t/server/client_identity.h \
 include/q4t/server/request_progress.h include/q4t/server/actual_usage.h \
 include/q4t/server/client_policy.h include/q4t/server/http_observation.h \
 include/q4t/server/finite_response.h include/q4t/server/legacy_tools.h \
 include/q4t/server/output_schema.h include/q4t/server/refusal_frame.h
include/q4t/server/chat_response_parser.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/custom_tools.h:
include/q4t/server/output_constraints.h:
include/q4t/server/reasoning_options.h:
include/q4t/server/schema_receipt.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/server/request_json.h:
include/q4t/server/request_limits.h:
include/q4t/server/schema_prefix.h:
include/q4t/server/http_response.h:
include/q4t/server/request_control.h:
include/q4t/server/client_identity.h:
include/q4t/server/request_progress.h:
include/q4t/server/actual_usage.h:
include/q4t/server/client_policy.h:
include/q4t/server/http_observation.h:
include/q4t/server/finite_response.h:
include/q4t/server/legacy_tools.h:
include/q4t/server/output_schema.h:
include/q4t/server/refusal_frame.h:

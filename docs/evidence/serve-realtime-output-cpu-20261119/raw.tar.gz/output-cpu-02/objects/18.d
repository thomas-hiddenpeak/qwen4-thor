/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/objects/18.o: \
 src/trace/sha256.cpp include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h include/q4t/status.h
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/status.h:

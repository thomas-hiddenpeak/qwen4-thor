/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/objects/20.o: \
 /home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/main.cpp \
 include/q4t/test.h
include/q4t/test.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/objects/10.o: \
 src/server/schema_decimal.cpp include/q4t/server/schema_decimal.h \
 include/q4t/status.h
include/q4t/server/schema_decimal.h:
include/q4t/status.h:

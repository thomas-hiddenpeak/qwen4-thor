/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/output-cpu-02/objects/12.o: \
 src/server/legacy_tools.cpp include/q4t/server/legacy_tools.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/input_contract.h
include/q4t/server/legacy_tools.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/input_contract.h:

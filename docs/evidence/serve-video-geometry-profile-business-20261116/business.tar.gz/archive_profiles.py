import json,re,shutil,tarfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;P=W/'profiles-01'
accepted=read(P/'acceptance.json');require(accepted['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION','qualification absent')
require(read(W/'version-driver-cpu-01.json')['exit_code']==0,'driver failed')
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [ROOT/'build/service/engine/client-policy.json',ROOT/'build/service/gateway-policy.json',P/'client-policy.json']:
 if p.is_file():collect(read(p))
out=ROOT/'docs/evidence/serve-video-geometry-profile-business-20261116';out.mkdir();files=[]
for p in P.rglob('*'):
 if not p.is_file():continue
 parts=p.relative_to(P).parts
 if parts[0] in ('client-policy.json','application-objects','application-objects-prompt-cache'):continue
 files.append((p,'profiles-01/'+str(p.relative_to(P))))
for n in ['prepare_package.py','prepare_package_before_capacity_fix.py','prepare_retained.py','media_version.py','test_media_version.py','freeze-version-01.json','archive_profiles.py']:
 files.append((W/n,n))
for stem in ['prepare-profiles-01','gpu-profiles-01','finalize-profiles-01','finalize-profiles-02','prepare-package-01','prepare-package-02','prepare-retained-01','version-driver-cpu-01']:
 for suffix in ['json','stdout','stderr']:files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for n in ['package-02/prepare-review.json','package-02/native-build.json','package-02/receipt.json','retained-01/review.json']:
 files.append((W/n,n))
for p,_ in files:
 raw=p.read_bytes();require(not any(x in raw for x in secrets),'secret in public archive')
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),'private key')
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,name in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=name)
for n in ['acceptance.json','qualified/registry.json','qualified/primary.json','qualified/light.json']:
 target=out/n;target.parent.mkdir(exist_ok=True);shutil.copy2(P/n,target)
review=read(W/'package-02/prepare-review.json');retained=read(W/'retained-01/review.json')
save(out/'archive.json',dict(files=len(files),sha256=sha(out/'business.tar.gz'),secret_scan_matches=0,package=review['package_sha256'],fallback=retained['fallback']['manifest_sha256'],control_delta=review['control_source_delta'],native_delta=review['native_source_delta'],native_executables_identical=review['native_executables_identical'],driver_cpu_cases=2,version_business_pending=True))
(out/'README.md').write_text('''# 显示修复精确主轻资格与封包准备

2026-11-16，a7bd6785在同一严格租约下2启动/10请求/87.791秒，83项
NVML正常。每侧schema42、一次真实项目文档工具及实际SHA续答、原生
embedding和视频均通过，能力相同，仅MTP开关不同；自有资源清理。
注册表a4c27749绑定这个实际引擎，未改写rev142旧资格。

正式包8d9c07f1、保留控制包a9bd9c73已封装，两项实际sealed namespace
CPU检查首过。控制源码与四个原生程序均与rev142完全相同，复用既有
压力/监护状态机证据；新包版本组合仍待1启动/2生成及2启动/4生成/
1探测两段短验，后者要求冻结镜像画面回退后仍正确并支持SSE。

首次归档finalize参数误用和封包容量输入形状错误均在动作前拒绝，
原记录及未完成package-01保留；只修正交付驱动，无新增模型请求或
生产改动。实际默认rev142保持，私有对象库、策略Key未入公开归档。
不扩大到完整性能/正确性或长稳，全部master继续。
''')
print(json.dumps(dict(status='PROFILE_AND_PACKAGE_PREPARED',files=len(files),package=review['package_sha256'],fallback=retained['fallback']['manifest_sha256'])))

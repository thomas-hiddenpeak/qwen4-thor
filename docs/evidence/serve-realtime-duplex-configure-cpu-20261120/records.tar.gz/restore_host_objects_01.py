from pathlib import Path
import hashlib,json,os,shutil,tarfile,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'host-objects-01';O.mkdir(mode=0o700)
A=R/'.q4t-work/serve-realtime-audio-20261120/build-intermediates-01';P=R/'.q4t-work/serve-file-search-20261112/host'
plan=json.loads((A/'plan.json').read_text());rows=[x for x in plan['files'] if Path(x['path']).is_relative_to(P) and x['path'].endswith('.o')];assert len(rows)==591
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json','.q4t-work/serve-custom-tools-20261108/engine-build/libq4t_server.a','.q4t-work/serve-custom-tools-20261108/engine-build/libq4t_model.a']}
missing=sum(x['bytes'] for x in rows if not Path(x['path']).exists());assert shutil.disk_usage(R).free>missing+(64<<20)
save('plan.json',{'scope':'Restore only the 591 original host objects needed for the next incremental host build; do not restore obsolete runtime libraries. No test/GPU execution.','original_plan':str(A/'plan.json'),'original_plan_sha256':sha(A/'plan.json'),'archive':plan['archive'],'archive_sha256':plan['archive_sha256'],'bytes_to_restore':missing,'protected':protected})
assert sha(plan['archive'])==plan['archive_sha256'];start=time.monotonic();count=0
with tarfile.open(plan['archive'],'r:gz') as src:
 for row in rows:
  p=Path(row['path'])
  if p.exists():assert sha(p)==row['sha256'];continue
  m=src.getmember(row['name']);assert m.isfile();tmp=p.with_name(p.name+'.restore');assert not tmp.exists()
  with src.extractfile(m) as i,tmp.open('xb') as o:shutil.copyfileobj(i,o)
  assert sha(tmp)==row['sha256'];tmp.chmod(row['mode']);os.utime(tmp,ns=(row['atime_ns'],row['mtime_ns']));tmp.replace(p);count+=1
assert all(sha(n)==h for n,h in protected.items())
result={'status':'EXACT_HOST_OBJECTS_RESTORED','objects':count,'bytes':missing,'seconds':time.monotonic()-start,'free_after':shutil.disk_usage(R).free,'runtime_libraries_unchanged':True,'default_unchanged':True,'gpu_actions':0}
save('result.json',result);print(json.dumps(result))

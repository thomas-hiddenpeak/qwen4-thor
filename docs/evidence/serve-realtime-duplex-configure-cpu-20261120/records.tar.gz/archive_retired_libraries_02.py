"""Reversible retired serve build intermediate static libraries; no live/default/package assets."""
from pathlib import Path
import gzip,hashlib,json,os,shutil,stat
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'retired-static-libraries-02';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
files=[R/n for n in json.loads((W/'cold-static-libraries-02.json').read_text())]
assert len(files)==6
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json','.q4t-work/serve-custom-tools-20261108/engine-build/q4t','.q4t-work/serve-file-search-20261112/host/q4t_host_tests']}
for p in W.glob('*package-01/bundle/manifest.json'):protected[str(p)]=sha(p)
inodes=set();rows=[];free=shutil.disk_usage(R).free
for p in files:
 s=p.lstat();assert p.is_file() and not p.is_symlink() and s.st_nlink==1
 rows.append(dict(paths=[str(p)],sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),atime_ns=s.st_atime_ns,mtime_ns=s.st_mtime_ns,original_links=1))
 inodes.add((s.st_dev,s.st_ino))
for proc in Path('/proc').glob('[0-9]*'):
 for fd in [proc/'exe',*(proc/'fd').glob('*')]:
  try:s=fd.stat();assert (s.st_dev,s.st_ino) not in inodes,str(fd)
  except (PermissionError,FileNotFoundError,ProcessLookupError):pass
save(O/'plan.json',dict(scope=__doc__,files=rows,protected=protected,free_before=free))
for i,row in enumerate(rows):
 p=Path(row['paths'][0]);target=O/f'binary-{i}.gz'
 with p.open('rb') as src,target.open('xb') as dst:
  with gzip.GzipFile(filename='',mode='wb',compresslevel=6,fileobj=dst,mtime=0) as z:shutil.copyfileobj(src,z)
 with gzip.open(target,'rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
 row.update(archive=str(target),archive_sha256=sha(target),archive_bytes=target.stat().st_size)
 assert sha(p)==row['sha256'] and p.stat().st_nlink==1
 save(O/'plan.json',dict(scope=__doc__,files=rows,protected=protected,free_before=free))
 p.unlink()
shutil.copyfile(R/'.q4t-work/serve-realtime-audio-20261120/retired-binaries-06/restore.py',O/'restore.py')
assert all(sha(n)==h for n,h in protected.items())
result=dict(status='ARCHIVED_HISTORICAL_VALIDATION_BINARIES_REVERSIBLY',identities=len(rows),paths=len(rows),bytes_released=sum(r['bytes']-r['archive_bytes'] for r in rows),free_after=shutil.disk_usage(R).free,protected_unchanged=True,gpu_starts=0,restore=str(O/'restore.py'))
save(O/'result.json',result);print(json.dumps(result))

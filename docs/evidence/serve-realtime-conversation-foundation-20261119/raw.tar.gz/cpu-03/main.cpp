#include "q4t/test.h"
int main() { return q4t::test::RunTests({"realtime_conversation_tickets_cannot_cross_session","realtime_conversation_output_updates_preserve_identity_and_budget","realtime_conversation_mcp_nullable_identity_survives_output_updates"}); }

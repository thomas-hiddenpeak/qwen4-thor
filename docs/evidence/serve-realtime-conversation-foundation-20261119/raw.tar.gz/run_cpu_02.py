from pathlib import Path
import hashlib,json,subprocess,time,shutil,re,sys

R=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent
O=W/'cpu-02'
O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def run(name,cmd,timeout):
    started=time.monotonic()
    with (O/(name+'.log')).open('w') as log:
        try:
            result=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,
                                  timeout=timeout)
            code=result.returncode
        except subprocess.TimeoutExpired:
            code=124
    row=dict(command=cmd,exit_code=code,seconds=time.monotonic()-started)
    save(O/(name+'-result.json'),row)
    print(name,json.dumps(row),flush=True)
    if code:
        print((O/(name+'.log')).read_text()[-3500:],flush=True)
        raise SystemExit(code)
    return row

freeze=json.loads((W/'cpu-freeze-01.json').read_text())
freeze['repair']='Require explicit Realtime item_reference type; keep bare-ID oracle failure.'
freeze['sources_sha256']={n:sha(R/n) for n in freeze['sources_sha256']}
save(O/'freeze.json',freeze)
for n in freeze['sources_sha256']:
    p=O/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
sdk='.q4t-work/serve-realtime-20261119/profile-sdk-01'
compiler='.q4t-work/serve-responses-20261108/schema-tool'
oracle=run('oracle',['node','tools/serve_responses/item_shape_vectors.mjs',
    sdk,compiler,'src/server/contracts/openai_realtime_types_v1.json',
    str(O/'oracle')],90)
fixture=R/'tests/fixtures/realtime/sdk_vectors.json'
assert not fixture.exists()
fixture.parent.mkdir(exist_ok=True)
shutil.copy2(O/'oracle/vectors.json',fixture)
old=O/'original-item-graph.json'
regeneration=run('old-graph',['node','tools/serve_responses/generate_item_types.mjs',
    sdk,compiler,str(old)],15)
assert old.read_bytes()==(R/'src/server/contracts/openai_item_types_v1.json').read_bytes()

generated=O/'generated/q4t/server';generated.mkdir(parents=True)
for kind in ['responses_item','realtime']:
    contract='openai_item_types_v1.json' if kind=='responses_item' else 'openai_realtime_types_v1.json'
    variable='Q4T_ITEM_TYPES' if kind=='responses_item' else 'Q4T_REALTIME_TYPES'
    data=(R/'src/server/contracts'/contract).read_text()
    template=(R/'cmake'/f'{kind}_types.h.in').read_text()
    assert ')q4t_types"' not in data
    (generated/f'{kind}_types_data.h').write_text(template.replace('@'+variable+'@',data))
main=O/'main.cpp'
main.write_text('#include "q4t/test.h"\nint main() { return q4t::test::RunAllTests(); }\n')
sources=['tests/server_realtime_conversation_test.cpp',
 'tests/server_realtime_shape_test.cpp','tests/server_responses_item_shape_test.cpp',
 'src/server/realtime_conversation.cpp','src/server/responses_item_shape.cpp',
 'src/server/input_contract.cpp','src/server/output_schema.cpp',
 'src/server/http_response.cpp','src/trace/sha256.cpp','src/io/json.cpp',str(main)]
names=[]
for n in sources[:3]:names+=re.findall(r'Q4T_TEST\((\w+)\)',(R/n).read_text())
assert len(names)<=60
save(O/'test-selection.json',dict(tests=names,maximum_test_seconds=120,
  sdk_oracle_seconds=oracle['seconds'],prior_failure_seconds=3.718099716119468))
objects=[];build=[];objdir=O/'objects';objdir.mkdir()
for i,n in enumerate(sources):
    obj=objdir/f'{i:02d}.o';objects.append(str(obj))
    cmd=['g++-14','-std=c++23','-O1','-Wall','-Wextra','-Werror',
         '-ffunction-sections','-fdata-sections','-MMD','-MP',
         '-Iinclude','-I'+str(O/'generated'),'-c',n,'-o',str(obj)]
    build.append(run(f'build-{i:02d}',cmd,120))
binary=O/'contracts'
build.append(run('link',['g++-14',*objects,'-Wl,--gc-sections','-pthread','-ldl',
                        '-o',str(binary)],60))
assert all('warning:' not in p.read_text() for p in O.glob('build-*.log'))
save(O/'build-result.json',dict(exit_code=0,warnings=0,
  seconds=sum(x['seconds'] for x in build),binary_sha256=sha(binary)))
tests=run('contracts',[str(binary)],30)
text=(O/'contracts.log').read_text()
assert text.count('[PASS] ')==len(names) and '[FAIL]' not in text and '[SKIP]' not in text
test_seconds=oracle['seconds']+regeneration['seconds']+tests['seconds']+3.718099716119468
assert test_seconds<=120
result=dict(status='PASS_REALTIME_SCHEMA_HISTORY_CPU',tests=len(names),
  sdk_vectors=len(json.loads(fixture.read_text())['vectors']),seconds=test_seconds,
  build_seconds=sum(x['seconds'] for x in build),gpu_actions=0,
  original_failure_preserved=True,old_graph_byte_identical=True,
  default_unchanged=True,actual_conversation_execution_accepted=False)
save(O/'result.json',result);print(json.dumps(result),flush=True)

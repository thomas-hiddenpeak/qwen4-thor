from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-mcp-session-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
plans=['session-plan','session-repair-plan','session-forced-plan','session-receipt-plan','session-schema-plan']
snapshots=['session-original-source','session-repair-source','session-forced-source','session-receipt-source',None]
required=['session-required','session-repair-required','session-forced-required','session-receipt-required','session-schema-required']
files={'archive_session_01.py':Path(__file__)};results=[];accepted=set()
for i,(pn,snapshot,rn) in enumerate(zip(plans,snapshots,required),1):
 p=read(W/(pn+'.json'));r=read(W/f'session-cpu-0{i}/result.json');b=read(W/f'session-build-0{i}/result.json');results.append(r)
 assert b['status']=='BUILD_PASS' and b['warnings']==0 and r['sources']==p['sources']
 for n in [pn+'.json',rn+'.txt',f'build_session_0{i}.py',f'run_session_cpu_0{i}.py',*[f'session-build-0{i}/'+k for k in ['plan.json','result.json','build.log']],*[f'session-cpu-0{i}/'+k for k in ['result.json','stdout.txt','stderr.txt']]]:files[n]=W/n
 for n,h in p['sources'].items():
  path=W/snapshot/n if snapshot else R/n
  assert sha(path)==h;files[f'source-0{i}/'+n]=path
 for line in (W/f'session-cpu-0{i}/stdout.txt').read_text().splitlines():
  if line.startswith('[PASS] '):accepted.add(line.split(' ',1)[1])
assert results[4]['status']=='PASS' and len(accepted)==38
assert set(accepted)==set(read(W/'session-plan.json')['tests'])|set(read(W/'session-schema-plan.json')['tests'])
# Production bytes did not change across the five CPU runs; only fixtures did.
for n,h in results[4]['sources'].items():
 if not n.startswith('tests/'):assert all(r['sources'][n]==h for r in results)
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_REALTIME_MCP_PUBLIC_SESSION_CPU',distinct_cases=38,case_executions=sum(r['tests'] for r in results),cpu_seconds=sum(r['seconds'] for r in results),passed_initial=35,passed_approval_repair=1,passed_forced_followup=2,original_failed_executions=7,accepted_cases=sorted(accepted),native_http_cases=5,builds_zero_warnings=5,binary_sha256=results[-1]['binary_sha256'],production_sources_identical_across_cpu_runs=True,runtime_connected=True,runtime_build_pending=True,real_llm_acceptance=False,gpu_actions=0,llm_requests=0,default_revision=396,default_unchanged=True,master_goal_active=True)
save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP公开会话：CPU验收

2026-11-20。38个不同用例完成，累计45次执行，约3.793秒；五次必要
host构建均零警告。包含5项实际本机原生MCP HTTP合同/会话组合，
模型输出由CPU夹具提供；不能代替真实GPU模型、官方SDK和恢复交付。

公开会话接通异步目录/审批/单次调用；私有凭据与已导入目录冻结到
实际模型输入，SDK事件不泄露凭据。单次response工具覆盖等待确切
目录；普通auto文本不被未就绪或失败目录阻塞。已生成response和
工具执行有各自终态，后续显式回答读取真实结果，不隐式续轮或重放。
客户端历史副本须对照同scope密封结果，取消/断开和删除保留所有权。

首轮37项中35通过、2失败；补审批响应必填ID后该项通过。另一项
CPU模型依次暴露约束XML参数格式、隔离解码器收据缺失，以及夹具
误用封闭生成schema校验器。修正为实际open/advisory工具schema合同
和精确收据后，原失败项及新增实际HTTP单次覆盖闭环均通过。四轮
失败结果、各轮源码/构建/计划均保留，生产源在五轮间逐字节相同；
35项首轮和1项审批通过明确复用，没有放宽生产解析器或成功断言。

当前默认rev396 STOPPED保持，0模型/GPU。实际运行时构建正在推进，
之后开展有界真实资料查询、SDK及恢复交付；总目标仍active。

[结果](acceptance.json) · [索引](index.json) · [计划、源码与记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();start=s.index('公开会话首轮37项CPU');end=s.index('客户端/GPU业务',start);s=s[:start]+'''[公开会话38项CPU](evidence/serve-realtime-mcp-session-cpu-20261120/README.md)
完成，含5项真实本机MCP HTTP；累计45次执行，五次构建零警告。
首轮35通过，审批ID修正后1项通过；强制工具夹具的XML/收据/schema
方言修正后2项通过。运行时源码在各轮间相同，四轮失败完整保留。
实际运行时正在构建，CPU模型夹具不作为GPU/SDK业务通过证据。
'''+s[end:];p.write_text(s)
p=R/'docs/log/2026-11-20.md';p.write_text('''## Realtime MCP公开会话38项CPU完成

日期：2026-11-20。

做了什么：[38项CPU](../evidence/serve-realtime-mcp-session-cpu-20261120/README.md)
完成，45次执行/约3.793秒，含5项真实本机MCP HTTP组合；五次host
构建零警告。35项首轮通过、审批ID修正后的1项复用，强制工具两项
在夹具对齐XML、schema收据及open/advisory方言后通过。四轮原失败
与每轮源码/计划保留，生产源在各轮间逐字节相同。

为什么：公开工具接线、来源校验、审批/取消和辅助失败须有直接证据；
不放宽生产保护，不把模拟模型输出当成真实业务成功。

下一步：实际runtime构建已启动，继续官方SDK/模型工具业务和恢复
交付。默认rev396 STOPPED保持、0GPU，总目标active。

'''+p.read_text())
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';s=p.read_text().replace('该模块当前尚未接入Realtime运行时。','该模块已接入源码，实际模型/SDK/恢复交付继续。');s += '''\n[公开会话38项CPU完成](evidence/serve-realtime-mcp-session-cpu-20261120/README.md)，
累计45次执行，五次host构建零警告。首次35项和审批修正1项复用，
强制工具夹具对齐XML、精确收据与开放schema方言后两项补验通过。
四轮失败、原源码/计划均保留；实际模型业务与恢复交付仍待验。
''';p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m.update(state='public_session_cpu_accepted_native_build_and_sdk_business_next',session_cpu=a,session_evidence='evidence/serve-realtime-mcp-session-cpu-20261120/README.md');save(p,d)
print(json.dumps({k:v for k,v in a.items() if k!='accepted_cases'}))

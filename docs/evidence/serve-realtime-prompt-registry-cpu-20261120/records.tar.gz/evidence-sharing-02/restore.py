"""Recreate independent bytes at original paths; hashes/modes/times restored, not inodes."""
from pathlib import Path
import hashlib,json,os,shutil
O=Path(__file__).resolve().parent
plan=json.loads((O/'plan.json').read_text());restored=0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in plan['files']:
 p=Path(row['path']);q=Path(row['canonical'])
 assert sha(p)==sha(q)==row['sha256']
 if p.stat().st_ino==q.stat().st_ino:
  assert shutil.disk_usage(p.parent).free>row['bytes']+16*1024**2
  temp=p.with_name(p.name+'.q4t-independent-restore')
  with temp.open('xb') as target, q.open('rb') as source:
   shutil.copyfileobj(source,target);target.flush();os.fsync(target.fileno())
  assert sha(temp)==row['sha256'];os.chmod(temp,row['mode']);os.utime(temp,ns=(row['atime_ns'],row['mtime_ns']));os.replace(temp,p);restored+=1
print(json.dumps(dict(independent_files_restored=restored,original_bytes_preserved=True)))

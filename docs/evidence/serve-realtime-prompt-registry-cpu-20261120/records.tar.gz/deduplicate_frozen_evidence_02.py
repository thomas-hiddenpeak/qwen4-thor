"""Share identical frozen evidence in completed clean worktrees; keep every path."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'evidence-sharing-02'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def clean(p):return not subprocess.check_output(['git','-C',str(p),'status','--porcelain'])
def protected():return {str(R/p):sha(R/p) for p in ['build/q4t','build/q4t.release.json','build/service.release.json','build/service-native-state/ledger.json']}
def prepare():
 assert not O.exists();selected=read(W/'evidence-duplicates-review.json')[:7];before=protected();rows=[]
 for root in selected:
  assert root['ancestor'] and not root['dirty'];p=Path(root['path']);assert clean(p)
  assert subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()==root['head']
  # Evidence only, never runtime sources, packages, model assets or ignored results.
  names=subprocess.check_output(['git','-C',str(p),'ls-files','-z','docs/evidence']).decode().split('\0')
  for name in filter(None,names):
   f=p/name;q=R/name
   if not f.is_file() or f.is_symlink() or not q.is_file() or q.is_symlink():continue
   a,b=f.stat(),q.stat()
   if a.st_nlink!=1 or a.st_size!=b.st_size or a.st_ino==b.st_ino or a.st_mode!=b.st_mode or a.st_uid!=os.getuid() or b.st_uid!=os.getuid():continue
   digest=sha(f)
   if digest!=sha(q):continue
   rows.append(dict(path=str(f),canonical=str(q),bytes=a.st_size,sha256=digest,old_inode=a.st_ino,canonical_inode=b.st_ino,mode=stat.S_IMODE(a.st_mode),mtime_ns=a.st_mtime_ns,atime_ns=a.st_atime_ns))
 assert 20000<len(rows)<35000 and sum(r['bytes'] for r in rows)<1024**3
 O.mkdir(mode=0o700);save(O/'plan.json',dict(scope=__doc__,roots=selected,files=rows,protected=before,new_gpu_starts=0,maximum_seconds=240,maximum_files=35000,driver_sha256=sha(Path(__file__)),restoration='restore.py recreates independent identical files at every path; original inode cannot be recreated'))
 save(O/'prepared.json',dict(files=len(rows),logical_bytes=sum(r['bytes'] for r in rows),free_before=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize))
 print(json.dumps(read(O/'prepared.json')),flush=True)
def apply():
 plan=read(O/'plan.json');assert not (O/'result.json').exists() and plan['driver_sha256']==sha(Path(__file__))
 before=plan['protected'];assert protected()==before;started=time.monotonic();count=0;size=0
 for row in plan['files']:
  assert time.monotonic()-started<240
  f,q=Path(row['path']),Path(row['canonical']);a,b=f.stat(),q.stat()
  assert a.st_ino==row['old_inode'] and a.st_nlink==1 and b.st_ino==row['canonical_inode']
  assert sha(f)==sha(q)==row['sha256'] and stat.S_IMODE(a.st_mode)==stat.S_IMODE(b.st_mode)==row['mode']
  temp=f.with_name(f.name+'.q4t-evidence-share');assert not temp.exists();os.link(q,temp);os.replace(temp,f)
  assert f.stat().st_ino==q.stat().st_ino and f.stat().st_size==row['bytes']
  count+=1;size+=row['bytes']
  if count%4000==0:print(json.dumps(dict(shared=count,bytes=size)),flush=True)
 for root in plan['roots']:assert clean(root['path'])
 assert protected()==before
 save(O/'result.json',dict(status='PASS_FROZEN_EVIDENCE_SHARED',files=count,logical_duplicate_bytes_reclaimed=size,seconds=time.monotonic()-started,free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,all_original_paths_present=True,all_worktrees_clean=True,protected_unchanged=True,deleted_unique_evidence=0,new_gpu_starts=0))
 print(json.dumps(read(O/'result.json')),flush=True)
os.umask(0o077)
{'prepare':prepare,'apply':apply}[sys.argv[1]]()

"""Archive actual typed registry CPU checks; session execution remains pending."""
from pathlib import Path
import hashlib,json,subprocess,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-prompt-registry-cpu-20261120'
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
result=read(W/'registry-cpu-01/result.json');plan=read(W/'registry-plan-01.json');source=read(W/'registry-cpu-01/source-check.stdout');maintenance=read(W/'evidence-sharing-02/result.json')
assert result['status']=='PASS' and result['passed']==24 and source['inventory_current'] and source['mutation_checks']==20
assert maintenance['status']=='PASS_FROZEN_EVIDENCE_SHARED' and maintenance['protected_unchanged'] and maintenance['all_worktrees_clean']
for name,digest in plan['sources'].items():assert sha(R/name)==digest
files={}
for prefix in ('registry-cpu-01','registry-build-01','evidence-sharing-01','evidence-sharing-02'):
 for p in (W/prefix).rglob('*'):
  if p.is_file() and 'fixtures' not in p.relative_to(W/prefix).parts:files[str(p.relative_to(W))]=p
for name in ('registry-plan-01.json','registry-required-tests.txt','registry-source-review-01.json','registry-source-review-02.json','evidence-duplicates-review.json','deduplicate_frozen_evidence.py','deduplicate_frozen_evidence_02.py','archive_registry_cpu.py'):files[name]=W/name
patch=W/'registry-source.patch';patch.write_bytes(subprocess.check_output(['git','diff','--',*plan['sources']]));files[patch.name]=patch
assert not O.exists();O.mkdir()
for name,p in files.items():assert b'-----BEGIN '+b'PRIVATE KEY-----' not in p.read_bytes(),name
index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 for member in archive:
  raw=archive.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==index[member.name]['sha256']
acceptance=dict(status='PASS_REALTIME_TYPED_PROMPT_REGISTRY_CPU',tests=24,existing_tests=16,new_tests=8,seconds=result['seconds'],source_mutations=20,build_seconds=read(W/'registry-build-01/result.json')['seconds'],build_warnings=0,new_gpu_starts=0,actual_realtime_session_accepted=False,default_revision=356,default_unchanged=True,main_pr52_head_excludes_this_change=True,original_source_precheck_failure_preserved=True,original_readonly_maintenance_limit_failure_preserved=True,frozen_evidence_shared_files=maintenance['files'],logical_duplicate_bytes_reclaimed=maintenance['logical_duplicate_bytes_reclaimed'],all_evidence_paths_preserved=True,files=len(files),archive_sha256=sha(O/'records.tar.gz'),all_master_tasks_active=True)
save(O/'acceptance.json',acceptance)
(O/'README.md').write_text(f'''# Realtime Prompt 类型化注册表与不可变快照 CPU

24 项针对性 CPU 用例通过，{result['seconds']:.3f} 秒、0GPU；包含原16项
Responses/持久化合同与8项新版本快照、租户隔离、取消/截止时间、
Realtime定义、凭证隔离和输出预算检查。必要构建
{acceptance['build_seconds']:.3f} 秒、零警告，来源20项反例通过。

`PromptRegistry::Resolve` 在实际对象工作线程下选定版本并一次渲染，
输出带权限范围的独立快照；后续追加/切默认版本/删除不改原快照，
错误也不覆盖旧输出。既有模板默认`api=responses`，原生Realtime
专有模板使用`api=realtime`，保存完整会话设置和输入前缀，禁止递归
Prompt和持久化MCP凭证。跨API误用明确报错，不静默过滤配置。

这是解析基础，尚未接Realtime会话和模型执行；不将CPU夹具记为
真实业务通过。继续接默认/显式覆盖、有界解析、取消、前缀计量和
正确的历史截断，再做官方SDK实际业务。默认rev356未改；PR #52
只含已验文本/工具服务，本阶段未推入该PR。

来源白名单首次检查失败保留，确认旧Responses字段不变和Realtime
固定SDK字段后补登记。磁盘只读清单首轮超限也保留；缩到7个已完成
干净工作区后，22,553份相同证据共享存储，释放668,911,071字节。
原路径、SHA、Git内容和默认状态保持，保留恢复独立文件的脚本；
恢复不能复原旧inode。必要CPU缓存按原SHA恢复，模型未动。
''')
intro=f'[Prompt注册表24项CPU通过](evidence/serve-realtime-prompt-registry-cpu-20261120/README.md)：\n{result["seconds"]:.3f}秒/0GPU，原16项与8项新合同通过，来源20反例通过；\n构建246.350秒零警告。类型定义、权限范围和不可变版本快照已具备，\n继续会话覆盖/取消/执行/前缀截断接线与实际SDK业务；目前尚无\nRealtime Prompt业务资格。默认rev356、PR #52冻结head与原失败保持。\n\n'
p=R/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';head,body=p.read_text().split('\n',1);p.write_text(head+'\n\n## Prompt注册表24项CPU及来源检查通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：先固定版本/权限/类型及失败事务边界，才能接入有并发响应的\n实际会话。复用旧Responses测试验证提取Resolve未改变已有行为。\n\n下一步：会话覆盖与有界对象解析、真实执行和上下文索引；继续\nPR #52最终检查合入，全部master保持active。\n'+body)
p=R/'docs/SERVE_REALTIME_PROMPT_2026-11-20.md';s=p.read_text().replace('此类型化基础已编写，24 项 CPU 待验；','此类型化基础已通过[24 项 CPU](evidence/serve-realtime-prompt-registry-cpu-20261120/README.md)；');p.write_text(s)
p=R/'docs/serve-master-goals-v2.json'
if p.stat().st_nlink>1:
 data=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(data);p.chmod(mode)
g=read(p);g['realtime_progress']['prompt_registry_20261120']=acceptance|dict(evidence='evidence/serve-realtime-prompt-registry-cpu-20261120/README.md',next='Wire session overrides, bounded lookup/cancellation, actual execution and prefix-safe truncation; then actual SDK business and delivery.');save(p,g)
p=R/'docs/README.md'
if p.stat().st_nlink>1:
 data=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(data);p.chmod(mode)
p.write_text(p.read_text()+'\n- [Realtime Prompt注册表CPU](evidence/serve-realtime-prompt-registry-cpu-20261120/README.md)：固定版本快照与类型定义；实际会话接线继续。\n')
print(json.dumps(acceptance))

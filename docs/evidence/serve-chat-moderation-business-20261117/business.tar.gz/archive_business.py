import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
profile=read(W/'profiles-01/acceptance.json');assert profile['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
legacy=read(W/'retained-business-01/decision.json');modern=read(W/'modern-business-01/decision.json')
for value in [legacy,modern]:assert value['actual_business']['env_abort'] is False and all(value['actual_business']['postflight'].values())
files=[];queries=[]
for name in ['profiles-01','retained-business-01','modern-business-01']:
 base=W/name
 for p in base.iterdir():
  if p.is_file() and p.name!='client-policy.json':files.append((p,str(p.relative_to(W))))
 for directory in ['lease','qualified','execution']:
  if not (base/directory).exists():continue
  for p in (base/directory).iterdir():
   if p.is_file() and p.name!='budget.lock':files.append((p,str(p.relative_to(W))))
 for p in (base/'execution').rglob('model.log'):files.append((p,str(p.relative_to(W))))
 queries.extend(json.loads(line) for line in (base/'lease/nvml-queries.jsonl').read_text().splitlines())
 assert read(base/'lease/exit.json')['status']=='COMPLETED'
for prefix in ['package-01','retained-01','modern-retained-01']:
 for p in (W/prefix).iterdir():
  if p.is_file() and p.suffix=='.json':files.append((p,str(p.relative_to(W))))
for p in W.iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.stdout','.stderr']:
  files.append((p,p.name))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ['api_key','gateway_token','shared_secret','private_key','token'] and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json',W/'profiles-01/client-policy.json']:collect(read(p))
for p,n in files:
 b=p.read_bytes();assert not any(s in b for s in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',b),n
seconds=sum(read(W/(n+'.json'))['seconds'] for n in ['profiles-gpu-01','retained-gpu-01','modern-gpu-01']);assert seconds<900
prior=read(R/'docs/evidence/serve-chat-moderation-business-failure-20261117/acceptance.json')
assert prior['starts']==4 and prior['external_requests']==15 and seconds+prior['seconds']<1200
assert all(q['status']=='OK' and q['returncode']==0 for q in queries)
work=read(W/'profiles-01/moderation-business.json');classifier_steps=work['blocked_usage']['model_steps']+sum(v['model_steps'] for v in work['classifier_usage'].values())
for name in ['retained-business-01','modern-business-01']:
 classifier_steps+=sum(v['model_steps'] for v in read(W/name/'execution/classifier-usage.json').values())
assert classifier_steps==12
out=R/'docs/evidence/serve-chat-moderation-business-20261117';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n,recursive=False)
summary=dict(status='ACCEPT_CHAT_MODERATION_BUSINESS',engine_binary_sha256=read(W/'profiles-01/plan.json')['binary_sha256'],candidate=read(W/'package-01/receipt.json'),modern_retained=read(W/'modern-retained-01/receipt.json'),automatic_fallback=read(W/'retained-01/review.json')['fallback'],profile_qualification=profile,legacy_service_acceptance=legacy,modern_service_acceptance=modern,starts=4,external_generation_requests=17,chat_requests_including_selfchecks=13,embeddings=2,media=2,classifier_model_steps=classifier_steps,seconds=seconds,nvml_queries=len(queries),nvml_all_ok=True,cleanup_complete=True,original_failures_preserved=True,original_failed_input_unchanged=True,cumulative_starts=8,cumulative_external_requests=32,cumulative_seconds=seconds+prior['seconds'],prior_failure_evidence='docs/evidence/serve-chat-moderation-business-failure-20261117/README.md',candidate_whole_package_gpu_run=False,candidate_control_reuse='Exact delivered rev196 recovery/control and native target source/link contracts and helper executables. The only native CMake source delta adds q4t_server and host-test entries. New engine has exact primary/light qualification, distinct retained legacy SSE/storage and modern block/score/SSE/storage actual business.',default_revision=196,default_unchanged=True,full_model_quality=False,performance_claim=False,master_complete=False,files=len(files),archive_sha256=sha(out/'business.tar.gz'),secret_scan_matches=0)
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text(f'''# Chat审核真实业务接受

2026-11-17，修复组4启动/17外部请求/{seconds:.3f}秒，{len(queries)}项NVML正常，
三个严格租约COMPLETED，模型/原生服务/端口/锁全部清理。包含13条
Chat（含两次自检）、两次embedding、两次既定媒体请求；另有12次
实际内部分类，token分别记录，没有把辅助工作当作免费模型调用。

原失败威胁输入保持不变，在主配置和现代保留包实际给出风险分数，
两choice均content_filter、主回答usage为0；没有用503替代分类成功。
主/轻的schema、真实资料工具、媒体/embedding正常；已审核和过滤
对象可从存储回读并跨模型重启。现代包同时完成批准SSE、多choice
score及存储/客户隔离；旧控制包完成批准SSE和存储/客户隔离。

原始4启动/15请求/204.259秒的失败证据保留，包括预模型租约调用
遗漏、旧控制校验器导入冲突和真实分类拒绝。修复后不改阈值、原
输入或拒绝保护。累计8启动/32请求/{seconds+prior['seconds']:.3f}秒，未超1200秒。
原失败链仍失败；新通过记录绑定当前引擎及各完整保留包。

候选当前控制包没有额外完整GPU启动：控制/helper执行文件及目标
编译/链接合同按rev196精确身份复用（CMake仅增加server/test条目），
新引擎由两种容量和两种实际保留控制组合覆盖。未声称重复全部恢复
故障注入或独立旧引擎回退。现代整根和旧控制payload都保留审核能力。

默认rev196尚未改，继续可回退发布和PR37实际合main；全部master
仍active。无完整质量、性能或长稳结论；公开{len(files)}文件，已知密钥/
私钥扫描0命中，私有状态和凭据未入档。
''')
print(json.dumps({k:summary[k] for k in ['status','starts','external_generation_requests','seconds','cumulative_seconds','files']}))

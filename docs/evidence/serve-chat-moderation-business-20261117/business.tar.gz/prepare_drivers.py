from pathlib import Path
import ast
W=Path(__file__).resolve().parent;old=W.parent/'serve-chat-moderation-20261117'
s=(old/'native_moderation_repaired.py').read_text();(W/'native_moderation.py').write_text(s)
s=s.replace('One start, one selfcheck plus three reviewed business requests, no injected fault.','One start, one selfcheck plus one approved review SSE, no injected fault.').replace('chats=4','chats=2').replace('user_generations=3','user_generations=1')
s=s.replace('return dict(approved=approved, blocked=blocked, scored=scored)','return dict(approved=approved)')
a=s.index('def check_business(execution):');b=s.index('\ndef prepare(args):',a)
s=s[:a]+'''def check_business(execution):
    value=check_sse((execution/'approved-sse.wire').read_bytes())
    stored=json.loads((execution/'stored-approved.wire').read_bytes())
    if stored['id']!=value.id or stored['choices'][0]['message']!=value.message or stored['moderation']!=value.moderation or stored['q4t_moderation_usage']!=value.q4t_moderation_usage:
        raise RuntimeError('stored reviewed response changed')
    if json.loads((execution/'other-client-http.json').read_text())['status']!=404:
        raise RuntimeError('client isolation absent')
    if json.loads((execution/'approved-sse-request.json').read_text())!=requests()['approved']:
        raise RuntimeError('actual request differs')
    return dict(approved=value.q4t_moderation_usage)

''' + s[b:]
a=s.index("        blocked=self.request('blocked-input'");b=s.index('        usage=check_business',a);s=s[:a]+s[b:]
s=s.replace("approved_sse=True,actual_input_block=True,\n        all_choices_score=True", "approved_sse=True,actual_input_block=False,\n        all_choices_score=False")
s=s.replace('Chat moderation: approved SSE, actual flagged input block, all-choice score and reviewed storage isolation.', 'Chat moderation: approved SSE and reviewed storage isolation. Input block and all-choice score are covered separately on the modern control payload.')
ast.parse(s);(W/'legacy_moderation.py').write_text(s)
s=(old/'prepare_package.py').read_text().replace("P=W/'profiles-02'", "P=W/'profiles-01'")
s=s.replace('Twenty-six C++ and eight schema/native/client cases accepted;', 'Twenty-six original C++ and eight schema/native/client cases accepted; the classifier task/quoted-data repair additionally passes ten directly affected CPU cases;')
s=s.replace("cpu_contracts=['docs/evidence/serve-chat-moderation-cpu-20261117/README.md']", "cpu_contracts=['docs/evidence/serve-chat-moderation-cpu-20261117/README.md','docs/evidence/serve-chat-moderation-repair-cpu-20261117/README.md']")
ast.parse(s);(W/'prepare_package.py').write_text(s)
for name in ['prepare_retained.py','prepare_modern_root.py']:(W/name).write_text((old/name).read_text())
print('repair package and narrow legacy/modern drivers prepared')

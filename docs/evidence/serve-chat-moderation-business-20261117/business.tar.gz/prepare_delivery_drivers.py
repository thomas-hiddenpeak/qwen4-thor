from pathlib import Path
import ast,re
W=Path(__file__).resolve().parent;old=W.parent/'serve-chat-annotations-20261116'
old_sha='509c3bcb9a2c2d7428cbcb9117b109ae58a4087ad304abb0edda73ec74532a74';new_sha='602bbee6e959fff8e7b82905789b71f0e3817bf50db88e5745544c310c704740'
for name in ['archive_generations.py','archive_version_cycles.py']:
 s=(old/name).read_text().replace(old_sha,new_sha).replace('188','196');ast.parse(s);(W/name).write_text(s)
s=(old/'deliver.py').read_text().replace(old_sha,new_sha)
numbers={'188':'196','190':'198','192':'200','194':'202','196':'204'}
s=re.sub(r'\b(188|190|192|194|196)\b',lambda x:numbers[x[0]],s)
s=s.replace('rev188','rev196').replace('annotations','moderation').replace('ANNOTATIONS','MODERATION').replace('CITATION','MODERATION').replace('citation delivery','moderation delivery')
a=s.index("scope='Chat citation history");b=s.index("')\n  if name=='retained'",a)
s=s[:a]+"scope='Native Chat input/output moderation with actual classifier work, all-choice block publication gates and reviewed storage. Original failed input is repaired and verified without changing its text or the refusal protection. Exact new primary/light, legacy SSE and modern input-block/score/SSE/storage compositions accepted. Current control/native helper recovery reused by accepted source and executable identity; native CMake delta only adds server/test entries. No new whole-current-package GPU run or repeated fault injection claim. Modern manual root and legacy automatic payload retain the new feature; independent older-engine rollback is not claimed. All remaining master tasks continue."+s[b:]
ast.parse(s);(W/'deliver.py').write_text(s)
(W/'run_delivery.py').write_text((old/'run_delivery.py').read_text())
print('prepared reversible publication and recoverable pool archival; not executed')

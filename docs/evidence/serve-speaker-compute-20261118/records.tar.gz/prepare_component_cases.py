from pathlib import Path
import array,hashlib,json,random,subprocess,os,wave,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'component-cases-01';O.mkdir();started=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assets=W/'assets-01';receipt=json.loads((assets/'receipt.json').read_text())
for row in receipt['files']:
 if row['name'] in ['example1.wav','example2.flac']:assert sha(assets/row['name'])==row['sha256']
cmd=['gst-launch-1.0','--gst-disable-registry-fork','-q','filesrc','location='+str(assets/'example2.flac'),'!','flacparse','!','flacdec','!','audioconvert','!','audioresample','!','audio/x-raw,format=F32LE,channels=1,rate=16000','!','filesink','location='+str(O/'example2-pcm.f32')]
env=dict(os.environ,GST_REGISTRY=str(O/'gst-registry.bin'),GST_REGISTRY_1_0=str(O/'gst-registry.bin'))
with (O/'decode.log').open('w') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
assert p.returncode==0
with wave.open(str(assets/'example1.wav')) as w:
 assert w.getnchannels()==1 and w.getsampwidth()==2 and w.getframerate()==16000
 samples=array.array('h',w.readframes(w.getnframes()));pcm=array.array('f',(x/32768 for x in samples));(O/'example1-pcm.f32').write_bytes(pcm.tobytes())
(O/'minimum-pcm.f32').write_bytes(array.array('f',[0]*640).tobytes())
rng=random.Random(20261118);(O/'maximum-pcm.f32').write_bytes(array.array('f',(rng.uniform(-0.4,0.4) for _ in range(480000))).tobytes())
cases=[]
for name in ['minimum','maximum','example1','example2']:
 p=O/(name+'-pcm.f32');n=p.stat().st_size//4;assert p.stat().st_size%4==0 and 640<=n<=480000
 cases.append(dict(name=name,pcm=str(p),pcm_sha256=sha(p),samples=n,frames=1+n//160))
(O/'cases.json').write_text(json.dumps(dict(cases=cases,source_receipt=str(assets/'receipt.json'),decode_command=cmd,seconds=time.monotonic()-started,gpu_actions=0),indent=2)+'\n')
print(json.dumps(dict(cases=cases,seconds=time.monotonic()-started)))

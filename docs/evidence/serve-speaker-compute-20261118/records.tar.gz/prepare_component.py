import importlib.util,json,subprocess,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'component-01'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
spec=importlib.util.spec_from_file_location('speaker_acceptance',R/'tools/native_speaker/acceptance.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert json.loads((W/'acceptance-cpu-01/result.json').read_text())['status']=='PASS'
assert all(x['returncode']==0 for x in json.loads((W/'replay-build-01/result.json').read_text()))
assert shutil.disk_usage(W).free>=5*(1<<30)
O.mkdir()
paths=[p for p in (R/'tools/native_speaker').iterdir() if p.is_file()]
paths+=list((R/'include/q4t/audio').glob('speaker*.h'))+list((R/'src/audio').glob('speaker*'))
paths += [R/p for p in ['src/quant/lt_cache.cpp','include/q4t/quant/lt_cache.h','src/io/json.cpp','include/q4t/io/json.h','src/trace/sha256.cpp','include/q4t/trace/sha256.h','src/runtime/system_memory.cpp','include/q4t/runtime/system_memory.h','tools/evalscope/gpu_exclusive.py']]
paths+=[W/'replay-build/q4t_speaker_replay',W/'native-assets-01/model.safetensors',W/'native-assets-01/config.json',W/'assets-01/embedding_model.ckpt',W/'metadata-mask-01/dataio.py',W/'component-cases-01/cases.json',R/'.q4t-work/refenv/bin/python',R/'.q4t-work/refenv/pyvenv.cfg']
paths+=list((W/'metadata-01').rglob('*.py'))
cases=json.loads((W/'component-cases-01/cases.json').read_text())['cases'];paths+=[Path(c['pcm']) for c in cases]
for pattern in ['torch-*.dist-info/RECORD','numpy-*.dist-info/RECORD']:paths+=list((R/'.q4t-work/refenv/lib/python3.12/site-packages').glob(pattern))
plan=dict(limits=module.LIMITS,thresholds=module.THRESHOLDS,cases=cases,
 binary=str(W/'replay-build/q4t_speaker_replay'),assets=str(W/'native-assets-01'),
 checkpoint=str(W/'assets-01/embedding_model.ckpt'),source=str(W/'metadata-01'),
 mask_source=str(W/'metadata-mask-01/dataio.py'),reference_python=str(R/'.q4t-work/refenv/bin/python'),
 output=str(O),identities={str(p):module.digest(p) for p in sorted(set(paths))},
 source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 protected=module.defaults(),artifact_budget_bytes=256*(1<<20),disk_reserve_bytes=5*(1<<30),
 command=['/usr/bin/python3','-I','-B',str(R/'tools/native_speaker/acceptance.py'),'--plan',str(O/'plan.json')])
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(dict(output=str(O),limits=plan['limits'],identities=len(plan['identities']),frames=[c['frames'] for c in cases])))

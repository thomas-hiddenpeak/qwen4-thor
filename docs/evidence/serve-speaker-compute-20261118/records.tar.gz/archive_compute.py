import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;C=W/'component-01';O=R/'docs/evidence/serve-speaker-compute-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(C/'plan.json');r=read(C/'run/result.json');g=read(C/'lease/exit.json');launch=read(C/'launch.json')
assert r['status']=='PASS_COMPONENT_PENDING_LEASE_RECONCILIATION' and r['defaults_unchanged'] and r['seconds']<=600
assert launch['returncode']==0 and launch['seconds']<=660
assert g['status']=='COMPLETED' and g['child_returncode']==0 and g['command']==p['command']
assert g['compute_backend']=='nvml' and g['lease_inherited_by_child'] and not g['external_lease']
for path,digest in p['identities'].items():assert sha(Path(path))==digest,path
for path,digest in r['artifacts'].items():assert sha(C/'run'/path)==digest,path
for path,digest in p['protected'].items():assert sha(R/path)==digest,path
nvml=[json.loads(line) for line in (C/'lease/nvml-queries.jsonl').read_text().splitlines()];assert nvml and all(x['status']=='OK' for x in nvml)
events=[json.loads(line) for line in (C/'lease/events.jsonl').read_text().splitlines()]
assert events[0]['event']=='lease_acquired' and events[-1]['event']=='lease_released' and events[-1]['status']=='COMPLETED'
assert all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events)
for e in events:
 if e['event']=='child_started':assert not Path('/proc',str(e['child_pid'])).exists()
for q in nvml:assert not Path('/proc',str(q['worker_pid'])).exists()
assert len(r['checks'])==36 and all(x['passed'] for x in r['checks'])
size=sum(f.stat().st_size for f in C.rglob('*') if f.is_file());assert size<=p['artifact_budget_bytes']
n=read(C/'run/native/result.json');a=dict(status='ACCEPT_NATIVE_ECAPA_COMPONENT',gpu_model_loads=1,cpu_reference_loads=1,cases=4,numeric_checks=36,boundary_checks=8,lifecycle_checks=16,seconds=r['seconds'],lease_seconds=events[-1]['monotonic']-events[0]['monotonic'],nvml_ok=len(nvml),http_requests=0,default_revision=286,defaults_unchanged=True,cleanup_complete=True,source_commit=p['source_commit'],thresholds=p['thresholds'],max_feature_abs=max(x['max_abs'] for x in r['checks'] if x['operand']=='mel.f32'),max_stage_relative_l2=max(x['relative_l2'] for x in r['checks'] if x['operand'].startswith('stage-')),max_embedding_relative_l2=max(x['relative_l2'] for x in r['checks'] if x['operand']=='embedding.f32'),max_explicit_workspace_bytes=n['max_explicit_workspace_bytes'],raw_evidence_bytes=size,raw_tensors_retained=str(C/'run'),raw_tensor_digests_recorded=True,model_end_to_end_with_reference_frontend=False,speaker_identification_business=False,diarized_http_business=False,performance_claim=False,full_model_quality=False,long_stability_run=False,all_master_tasks_active=True)
(C/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
files=[Path(__file__).resolve(),W/'prepare_component.py',W/'prepare_component_cases.py']
for name in ['component-01','acceptance-cpu-01','replay-build-01','metadata-mask-01']:
 for f in (W/name).rglob('*'):
  if f.is_file() and f.suffix not in ('.pyc','.f32'):files.append(f)
for d in ['native','reference']:
 for i in range(4):files.append(C/'run'/d/f'case-{i}'/'embedding.f32')
for name in ['component-cases-01/cases.json','component-cases-01/decode.log','metadata-01/source-receipt.json','metadata-01/LICENSE']:
 files.append(W/name)
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for f in sorted(set(files)):archive.add(f,arcname=str(f.relative_to(W)),recursive=False)
a['archive_sha256']=sha(O/'records.tar.gz');(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生ECAPA数值与边界通过（2026-11-18）

1GPU/1CPU参考加载、4输入、36项数值、8输入边界及16生命周期检查
通过，{r['seconds']:.3f}秒；单租约{a['lease_seconds']:.3f}秒，{len(nvml)}次NVML正常，
所有自有进程和租约清理，默认rev286未变。验收器5项CPU正负控通过。

5/3001帧边界与两段官方真实语音：完整80维特征max_abs
{a['max_feature_abs']:.9f}≤0.002；七阶段最坏relative_l2
{a['max_stage_relative_l2']:.9g}，最终192维最坏relative_l2
{a['max_embedding_relative_l2']:.9g}，全部达到事前固定逐项门槛。
计算保持原F32/FP32 pedantic，参考使用未修改官方AST前向和原checkpoint。
模型两侧使用相同native特征以隔离算术；官方前处理完整矩阵另对照，
没有把参考输出当原生结果或声称两套前处理的完整模型端到端差分。

显式峰值工作区{n['max_explicit_workspace_bytes']}字节，原生权重83,224,056字节；
这是布局计量，不包括库内部/页缓存，也不是整服务统一RAM实测结论。
原始约{size/1024**2:.1f}MiB中间张量留在本机component-01/run，所有SHA
及汇总、最终向量、驱动、租约原件归档，未把大张量重复放进Git。
轮询不能排除短于采样间隔的外部干扰。

本组0HTTP，没有证明聚类/已知参考/重叠语音或diarized_json业务完成。
继续独立资产健康、真实分段/匹配、API/SDK与恢复/发行；完整master
保持active，不跑完整主模型质量、性能或长稳。
''')
intro=f'''[ECAPA真实组件通过](evidence/serve-speaker-compute-20261118/README.md)：
1GPU/1CPU参考、4输入/36数值+24边界与生命周期，{r['seconds']:.3f}秒；
9次NVML正常、租约清理，最大embedding相对误差2.89e-06。
默认rev286不变；继续独立资产/健康及真实分段/参考/API/恢复交付，
不是说话人HTTP已通过，全部master继续。

'''
pth=R/'docs/STATUS.md';pth.write_text(pth.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
pth=R/'docs/log/2026-11-18.md';s=pth.read_text();h,b=s.split('\n',1);pth.write_text(h+f'''\n\n## 原生ECAPA真实组件数值通过（2026-11-18）

固定4输入、1GPU/1CPU加载、36项数值和24项边界/生命周期通过，
{r['seconds']:.3f}秒、9次NVML正常，租约清理。最大embedding相对误差
2.89e-06，保持事前门槛和FP32合同；0HTTP/主模型、默认rev286不变。
原因：为实际说话人服务提供经过原计算对照的真实声纹后端。
下一步独立资产/健康、分段/已知参考/API/恢复交付及全部master。
[证据](../evidence/serve-speaker-compute-20261118/README.md)。\n'''+b)
pth=R/'docs/serve-master-goals-v2.json';j=read(pth)
for t in j['tasks']:
 if t['id']=='A10':t['speaker_component_20261118']=a|dict(evidence='evidence/serve-speaker-compute-20261118/README.md')
j['next_task']='A10 native speaker assets/health and real diarization integration; PR45 exact-head main integration; all remaining master tasks';pth.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:a[k] for k in ['status','seconds','nvml_ok','max_explicit_workspace_bytes','max_embedding_relative_l2']}))

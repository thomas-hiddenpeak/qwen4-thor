"""Continue the two completed native calls; preserve the original harness failure."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_recovery import publication
from tools.serve_service import package as p
os.umask(0o077)
O=W/'actual-maintenance-continue-01';O.mkdir(mode=0o700)
S=R/'build/service-native-state';selection=p.read(W/'maintenance-selections.json')
target=p.read(W/'candidate-01/receipt.json');old=p.read(W/'candidate-01/review.json')['previous']
cli=Path(target['package'])/'bin/q4t';base=['--state',S,'--package',old['package'],'--manifest-sha256',old['manifest_sha256']]
initial=p.read(W/'actual-maintenance-original-publication.json')
prior=p.read(W/'actual-maintenance-01/result.json')
p.require(prior['status']=='FAILED' and len(prior['commands'])==2 and all(r['returncode']==0 for r in prior['commands']), 'original failure differs')
p.require(p.read(W/'actual-maintenance-diagnosis.json')['core_client_outer_profile_and_version_exact'], 'diagnosis missing')
expected_requests=set(initial['request_ids'])-{selection['selected']['intents'][0]}
def publication_unchanged():
    current=publication.status(S)
    return {k:v for k,v in current.items() if k!='request_ids'}=={k:v for k,v in initial.items() if k!='request_ids'} and set(current['request_ids'])==expected_requests
def state_bytes():return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file()}
def protected():return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and
    (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection','version-selection')))}
before=protected();rows=[];started=time.monotonic();archives={}
p.require(publication_unchanged(),'continuation predecessor changed')
p.save(O/'before.json',dict(protected=before,publication=initial,remaining_native_commands=14))
def call(label,args):
    p.require(len(rows)<14 and time.monotonic()-started+prior['seconds']<540,'maintenance command budget')
    argv=list(map(str,[cli,'service',*args]))
    r=subprocess.run(argv,cwd=O,env=dict(os.environ,PYTHONPATH=''),capture_output=True,text=True,timeout=60)
    (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
    rows.append(dict(label=label,argv=argv,returncode=r.returncode))
    p.require(r.returncode==0,'maintenance failed: '+label)
    result=json.loads(r.stdout)
    p.require(result['model_actions'] is False and protected()==before and publication_unchanged(),'authority or budgets changed')
    return result
try:
    for kind,ids in selection['selected'].items():
        all_before=state_bytes()
        if kind=='intents':
            plan=p.read(W/'actual-maintenance-01/intents-plan.stdout')
            saved=p.read(plan['plan'])['requests'][0]
            all_before[str(publication.intent_path(S,saved['request_id']).relative_to(S))]=saved['sha256']
        else:
            output=O/(kind+'-roundtrip')
            plan=call(kind+'-plan',['maintenance-plan',*base,'--kind',kind,'--select',ids[0],'--output',output])
            flags=[*base,'--kind',kind,'--plan',plan['plan'],'--plan-sha256',plan['sha256']]
            a=call(kind+'-apply',['maintenance-apply',*flags]);p.require(a['status']=='RETIRED','archive did not complete')
        flags=[*base,'--kind',kind,'--plan',plan['plan'],'--plan-sha256',plan['sha256']]
        if kind=='intents':expected_requests.add(ids[0])
        a=call(kind+'-restore',['maintenance-restore',*flags]);p.require(a['status']=='RESTORED','restore did not complete')
        p.require(state_bytes()==all_before,'restore changed original bytes')
        output=O/(kind+'-reserved-capacity')
        flags=[v for identity in ids for v in ('--select',identity)]
        plan=call(kind+'-reserve-plan',['maintenance-plan',*base,'--kind',kind,*flags,'--output',output])
        if kind=='intents':expected_requests-=set(ids)
        a=call(kind+'-reserve-apply',['maintenance-apply',*base,'--kind',kind,'--plan',plan['plan'],'--plan-sha256',plan['sha256']])
        p.require(a['status']=='RETIRED' and a['deleted_files']==0,'capacity archive failed')
        archives[kind]=plan
    status=call('final-capacity',['maintenance-status',*base])
    p.require(all(status['pools'][k]['used']==selection['old_pools'][k]['used']-len(v)
        for k,v in selection['selected'].items()),'capacity changed unexpectedly')
    p.save(O/'result.json',dict(status='PASS_NATIVE_MAINTENANCE_ACTUAL_ROUNDTRIPS',seconds=time.monotonic()-started,
        original_seconds=prior['seconds'],commands=rows,original_commands=prior['commands'],successful_native_commands=16,
        original_harness_failure_preserved=True,target=target,current=old,archives=archives,pools=status['pools'],protected=before,
        publication_unchanged_except_explicit_archived_request_ids=True,recovery_cycle_and_budgets_unchanged=True,deleted_files=0,model_actions=False))
    print(json.dumps(dict(status='PASS_NATIVE_MAINTENANCE_ACTUAL_ROUNDTRIPS',successful_native_commands=16,seconds=time.monotonic()-started)))
except BaseException as e:
    p.save(O/'result.json',dict(status='FAILED',seconds=time.monotonic()-started,commands=rows,archives=archives,error=repr(e)));raise

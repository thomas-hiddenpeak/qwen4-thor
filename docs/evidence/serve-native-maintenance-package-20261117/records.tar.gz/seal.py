"""Seal only reviewed maintenance sources; retain the exact accepted engine."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from tools.serve_recovery import bundle, profile_manager
from tools.serve_service import package as p

os.umask(0o077)
p.require(not subprocess.check_output(['git','status','--porcelain'], cwd=R), 'clean source required')
old = (R/'build/service').resolve(strict=True)
old_sha = p.sha(old/'manifest.json')
p.require(old_sha == '168477d190e4b0d2c5f2f92410722b39486801500ad4397ff1c717019f022d64', 'default changed')
m = bundle.verify(old, old_sha)
e = p.read(old/'engine/manifest.json')
metadata = p.read(old/'engine/q4t.release.json')
p.require(all(p.sha(R/n) == h for n,h in p.read(metadata['tested_source_manifest']).items()), 'engine source changed')
p.require(all(p.sha(R/n) == h for n,h in p.read(old/'native-build.json')['source_files'].items()), 'native helper source changed')
accepted = p.read(R/'docs/evidence/serve-native-maintenance-cpu-20261117/acceptance.json')
p.require(accepted['status'] == 'PASS_NATIVE_MAINTENANCE_CPU' and accepted['tests'] == 25, 'targeted CPU missing')
p.require(all(p.sha(R/n) == h for n,h in accepted['production_sources'].items()), 'CPU identity changed')
changed = {n[7:] for n,h in m['files'].items() if n.startswith('source/') and p.sha(R/n[7:]) != h}
added = set(bundle.SOURCES)-set(bundle.V19_SOURCES)
p.require(changed == {'tools/serve_recovery/bundle.py','tools/serve_recovery/service.py'} and
    added == {'tools/serve_recovery/'+n+'.py' for n in
        ('maintenance','publication_archive','publication_intent_archive','version_archive')}, 'source delta differs')
out = W/'candidate-01';p.require(not out.exists(), 'preserve candidate')
out.mkdir(mode=0o700)
target = out/'bundle';shutil.copytree(old,target,symlinks=True)
new = copy.deepcopy(m)
for n in sorted(changed|added):
    f=target/'source'/n
    if f.exists():f.chmod(0o600)
    shutil.copyfile(R/n,f);f.chmod(0o400)
    new['files']['source/'+n]=p.sha(f)
new.update(version=20,profile='q4t-service-recovery-v20')
(target/'manifest.json').chmod(0o600);p.save(target/'manifest.json',new)
(target/'manifest.json').chmod(0o400)
digest=p.sha(target/'manifest.json')
entry=target/'bin/q4t';entry.chmod(0o700)
entry.write_bytes(bundle.launcher(digest,new['python']['path']));entry.chmod(0o500)
p.require(bundle.verify(target,digest)==new,'new package failed')
p.require(profile_manager.compatible(m,new,old,target) is None,'profiles changed')
p.require(p.read(target/'engine/manifest.json')==e,'engine changed')
p.require(all(p.sha(target/'engine'/n)==h for n,h in e['files'].items()),'engine bytes changed')
p.require(all(p.sha(target/n)==h for n,h in m['files'].items() if n not in {'source/'+n for n in changed}), 'unreviewed existing bytes changed')
receipt=dict(package=str(target),manifest_sha256=digest)
p.save(out/'receipt.json',receipt)
p.save(out/'review.json',dict(status='PASS_MAINTENANCE_PACKAGE_SOURCE',previous=dict(package=str(old),manifest_sha256=old_sha),current=receipt,
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),changed=sorted(changed),added=sorted(added),
    cpu_acceptance=accepted,engine_binary_sha256=p.sha(target/'engine/q4t'),engine_protocol_sources_unchanged=True,
    native_helper_sources_unchanged=True,runtime_controllers_unchanged=True,profiles_clients_policies_unchanged=True,
    default_unchanged=(R/'build/service').resolve()==old,model_actions=False,actual_cli_pending=True))
print(json.dumps(receipt))

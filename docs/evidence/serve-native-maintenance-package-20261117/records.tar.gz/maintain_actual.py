import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_recovery import publication
from tools.serve_service import package as p
os.umask(0o077)
O=W/'actual-maintenance-01';O.mkdir(mode=0o700)
S=R/'build/service-native-state';selection=p.read(W/'maintenance-selections.json')
target=p.read(W/'candidate-01/receipt.json');old=p.read(W/'candidate-01/review.json')['previous']
cli=Path(target['package'])/'bin/q4t'
base=['--state',S,'--package',old['package'],'--manifest-sha256',old['manifest_sha256']]
initial=publication.status(S)
p.require(initial['revision']==selection['revision']==260 and initial['current']['manifest_sha256']==old['manifest_sha256'],'predecessor changed')
def state_bytes():return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file()}
def protected():return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and
    (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection','version-selection')))}
before=protected();rows=[];started=time.monotonic();archives={}
def call(label,args):
    p.require(len(rows)<16 and time.monotonic()-started<540,'maintenance command budget')
    argv=list(map(str,[cli,'service',*args]))
    r=subprocess.run(argv,cwd=O,env=dict(os.environ,PYTHONPATH=''),capture_output=True,text=True,timeout=60)
    (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
    rows.append(dict(label=label,argv=argv,returncode=r.returncode))
    p.require(r.returncode==0,'maintenance failed: '+label)
    result=json.loads(r.stdout)
    p.require(result['model_actions'] is False and protected()==before and publication.status(S)==initial,'authority or budgets changed')
    return result
try:
    for kind,ids in selection['selected'].items():
        all_before=state_bytes()
        output=O/(kind+'-roundtrip')
        plan=call(kind+'-plan',['maintenance-plan',*base,'--kind',kind,'--select',ids[0],'--output',output])
        flags=[*base,'--kind',kind,'--plan',plan['plan'],'--plan-sha256',plan['sha256']]
        a=call(kind+'-apply',['maintenance-apply',*flags]);p.require(a['status']=='RETIRED','archive did not complete')
        a=call(kind+'-restore',['maintenance-restore',*flags]);p.require(a['status']=='RESTORED','restore did not complete')
        p.require(state_bytes()==all_before,'restore changed original bytes')
        output=O/(kind+'-reserved-capacity')
        flags=[v for identity in ids for v in ('--select',identity)]
        plan=call(kind+'-reserve-plan',['maintenance-plan',*base,'--kind',kind,*flags,'--output',output])
        a=call(kind+'-reserve-apply',['maintenance-apply',*base,'--kind',kind,'--plan',plan['plan'],'--plan-sha256',plan['sha256']])
        p.require(a['status']=='RETIRED' and a['deleted_files']==0,'capacity archive failed')
        archives[kind]=plan
    status=call('final-capacity',['maintenance-status',*base])
    p.require(all(status['pools'][k]['used']==selection['old_pools'][k]['used']-len(v)
        for k,v in selection['selected'].items()),'capacity changed unexpectedly')
    p.save(O/'result.json',dict(status='PASS_NATIVE_MAINTENANCE_ACTUAL_ROUNDTRIPS',seconds=time.monotonic()-started,
        commands=rows,target=target,current=old,archives=archives,pools=status['pools'],protected=before,
        publication_unchanged=True,recovery_cycle_and_budgets_unchanged=True,deleted_files=0,model_actions=False))
    print(json.dumps(dict(status='PASS_NATIVE_MAINTENANCE_ACTUAL_ROUNDTRIPS',commands=len(rows),seconds=time.monotonic()-started)))
except BaseException as e:
    p.save(O/'result.json',dict(status='FAILED',seconds=time.monotonic()-started,commands=rows,archives=archives,error=repr(e)));raise

"""Restore exact old plans with the new native entry, then rearchive safely."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_recovery import maintenance,publication
from tools.serve_service import package as p
os.umask(0o077)
O=W/'legacy-package-check-01';O.mkdir(mode=0o700)
S=R/'build/service-native-state';target=p.read(W/'candidate-02/receipt.json')
old=p.read(W/'candidate-02/review.json')['previous'];cli=Path(target['package'])/'bin/q4t'
base=['--state',S,'--package',old['package'],'--manifest-sha256',old['manifest_sha256']]
initial=publication.status(S);expected_requests=set(initial['request_ids'])
prior=p.read(W/'actual-maintenance-continue-01/result.json')
p.require(prior['status']=='PASS_NATIVE_MAINTENANCE_ACTUAL_ROUNDTRIPS' and initial['revision']==260,'predecessor differs')
def state_bytes():return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file()}
def protected():return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and
    (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection','version-selection')))}
all_before=state_bytes();before=protected();rows=[];started=time.monotonic();archives={}
p.save(O/'before.json',dict(protected=before,all_state_files=all_before,publication=initial))
def call(label,args):
    p.require(len(rows)<11 and time.monotonic()-started<540,'legacy check budget')
    argv=list(map(str,[cli,'service',*args]));r=subprocess.run(argv,cwd=O,env=dict(os.environ,PYTHONPATH=''),capture_output=True,text=True,timeout=60)
    (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
    rows.append(dict(label=label,argv=argv,returncode=r.returncode))
    p.require(r.returncode==0,'legacy command failed: '+label)
    value=json.loads(r.stdout);current=publication.status(S)
    p.require(value['model_actions'] is False and protected()==before and
        {k:v for k,v in current.items() if k!='request_ids'}=={k:v for k,v in initial.items() if k!='request_ids'} and
        set(current['request_ids'])==expected_requests,'authority or budget changed')
    return value
try:
    p.require(call('candidate-check',['check'])['status']=='PASS','candidate identity')
    for kind,directory,field,key in [('intents','intent-archive-01','requests','request_id'),
            ('generations','publication-archive-01','generations',None),
            ('versions','version-archive-01','cycles','cycle_id')]:
        plan=R/'.q4t-work/serve-client-receipts-20261117'/directory/'plan.json'
        value=p.read(plan);digest=p.sha(plan)
        p.require(value['source_sha256'] in maintenance.KINDS[kind].LEGACY_PLAN_SOURCES,'unreviewed legacy plan source')
        selected=[row[key] if key else row['selected']['generation_sha256'] for row in value[field]]
        original_receipt=p.sha(plan.parent/'retired.json')
        if kind=='intents':expected_requests.update(selected)
        a=call(kind+'-legacy-restore',['maintenance-restore',*base,'--kind',kind,'--plan',plan,'--plan-sha256',digest])
        p.require(a['status']=='RESTORED' and p.sha(plan)==digest and p.sha(plan.parent/'retired.json')==original_receipt,'old plan or archive receipt changed')
        flags=[v for identity in selected for v in ('--select',identity)]
        new=call(kind+'-new-plan',['maintenance-plan',*base,'--kind',kind,*flags,'--output',O/(kind+'-rearchived')])
        if kind=='intents':expected_requests-=set(selected)
        a=call(kind+'-new-apply',['maintenance-apply',*base,'--kind',kind,'--plan',new['plan'],'--plan-sha256',new['sha256']])
        p.require(a['status']=='RETIRED' and a['deleted_files']==0 and state_bytes()==all_before,'rearchive changed active state')
        archives[kind]=dict(original_plan=str(plan),original_sha256=digest,new_plan=new,selected=selected)
    status=call('final-status',['maintenance-status',*base])
    p.require(status['pools']==prior['pools'],'reserved capacities changed')
    p.save(O/'result.json',dict(status='PASS_NATIVE_LEGACY_PLANS_ACTUAL',seconds=time.monotonic()-started,
        commands=rows,target=target,current=old,archives=archives,pools=status['pools'],state_bytes_unchanged=True,
        old_plans_and_receipts_preserved=True,model_actions=False,new_gpu_starts=0))
    print(json.dumps(dict(status='PASS_NATIVE_LEGACY_PLANS_ACTUAL',commands=len(rows),seconds=time.monotonic()-started)))
except BaseException as error:
    p.save(O/'result.json',dict(status='FAILED',seconds=time.monotonic()-started,commands=rows,archives=archives,error=repr(error)));raise

import json
import os
from pathlib import Path
import sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_recovery import maintenance, publication, version_registration
from tools.serve_service import package as p
os.umask(0o077)
S=R/'build/service-native-state'
status=p.read(W/'package-check-01/maintenance-status.stdout')
p.require(publication.status(S)['revision']==status['publication_revision']==260,'publication changed')
out=W/'maintenance-selections.json';p.require(not out.exists(),'preserve selection')
selected={};skipped=[]
with maintenance.generations.locked(S) as (state,desc,manifest,current):
    for kind,count in [('intents',4),('generations',2),('versions',2)]:
        rows=[]
        for identity in status['pools'][kind]['candidate_ids']:
            if kind=='intents':
                path=publication.intent_path(S,identity)
                order=p.read(path)['base']['revision']
            elif kind=='versions':
                path=S/version_registration.DIRECTORY/(identity+'.json')
                order=p.read(path)['candidate']['revision']
            else:
                path=Path(current['root'])/maintenance.generations.files.DIRECTORY/'generations'/identity
                order=path.stat().st_mtime_ns
            rows.append((order,identity,path))
        selected[kind]=[]
        for _,identity,path in sorted(rows):
            if len(selected[kind])==count:break
            try:
                (maintenance.versions if kind=='versions' else maintenance.generations).unreferenced(S,current,path)
            except ValueError as e:
                skipped.append(dict(kind=kind,id=identity,reason=str(e)));continue
            selected[kind].append(identity)
        p.require(len(selected[kind])==count,'insufficient safe candidates')
p.save(out,dict(revision=260,current_manifest_sha256=status['manifest_sha256'],selected=selected,skipped=skipped,
    old_pools=status['pools'],state=str(S),model_actions=False))
print(json.dumps(selected))

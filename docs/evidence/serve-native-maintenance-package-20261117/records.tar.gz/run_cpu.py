import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
out = W/(sys.argv[1] if len(sys.argv) > 1 else 'cpu-01')
out.mkdir(mode=0o700)
names = json.loads((W/'cpu-tests.json').read_text()) if len(sys.argv) < 3 else sys.argv[2:]
changed = ['bundle', 'service', 'maintenance', 'publication_archive',
           'publication_intent_archive', 'version_archive', 'test_maintenance',
           'test_native_bundle']
sources = {'tools/serve_recovery/'+n+'.py': hashlib.sha256(
    (R/'tools/serve_recovery'/(n+'.py')).read_bytes()).hexdigest() for n in changed}
(out/'sources.json').write_text(json.dumps(sources, indent=2)+'\n')
env = dict(os.environ, Q4T_TEST_OUTPUT_DIR=str(W/'fixtures'))
start = time.monotonic()
with (out/'tests.log').open('wb') as log:
    p = subprocess.run([sys.executable, '-B', '-m', 'unittest', '-v', *names],
        cwd=R, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
result = dict(status='PASS' if p.returncode == 0 else 'FAILED',
    seconds=time.monotonic()-start, returncode=p.returncode, selectors=names,
    production_sources=sources, model_actions=False, synthetic_assets=True)
(out/'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','seconds','returncode')}))
raise SystemExit(p.returncode)

import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_service import package as p
from tools.serve_recovery import publication
os.umask(0o077)
O=W/'package-check-01';O.mkdir(mode=0o700)
S=R/'build/service-native-state'
target=p.read(W/'candidate-01/receipt.json');review=p.read(W/'candidate-01/review.json')
old=review['previous'];cli=Path(target['package'])/'bin/q4t'
before={str(f.relative_to(S)):p.sha(f) for f in S.rglob('*.json')}
before_default=publication.status(S)
base=['--state',S,'--package',old['package'],'--manifest-sha256',old['manifest_sha256']]
rows=[];started=time.monotonic()
def call(label,args,code=0):
    p.require(len(rows)<8 and time.monotonic()-started<540,'frozen package check budget')
    argv=list(map(str,[cli,'service',*args]))
    r=subprocess.run(argv,cwd=O,env=dict(os.environ,PYTHONPATH=''),capture_output=True,text=True,timeout=60)
    (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
    rows.append(dict(label=label,argv=argv,returncode=r.returncode,expected=code))
    p.require(r.returncode==code,'packaged command failed: '+label)
    p.require(before=={str(f.relative_to(S)):p.sha(f) for f in S.rglob('*.json')},'state bytes changed')
    return json.loads(r.stdout if code==0 else r.stderr)
try:
    a=call('candidate-check',['check']);p.require(a['status']=='PASS' and a['model_actions'] is False,'candidate check')
    a=call('historical-v19-check',['check',*base]);p.require(a['desired']=='STOPPED','historical check')
    status=call('maintenance-status',['maintenance-status',*base]);p.require(status['desired']=='STOPPED' and not status['model_actions'],'maintenance status')
    for kind,pool in status['pools'].items():
        output=O/('protected-'+kind)
        a=call('protected-'+kind,['maintenance-plan',*base,'--kind',kind,
            '--select',pool['protected_ids'][0],'--output',output],1)
        p.require(a['status']=='FAILED' and not output.exists(),'protected entry was moved')
    call('wrong-selected-root',['maintenance-status','--state',S],1)
    p.require(publication.status(S)==before_default,'publication changed')
    p.save(O/'result.json',dict(status='PASS_PACKAGED_NATIVE_MAINTENANCE',seconds=time.monotonic()-started,
        commands=rows,target=target,current=old,pools=status['pools'],state_bytes_unchanged=True,
        default_unchanged=True,model_actions=False,synthetic_model=False,mutation_roundtrips_pending=True))
    print(json.dumps(dict(status='PASS_PACKAGED_NATIVE_MAINTENANCE',commands=len(rows),seconds=time.monotonic()-started)))
except BaseException as e:
    p.save(O/'result.json',dict(status='FAILED',seconds=time.monotonic()-started,commands=rows,error=repr(e)));raise

import hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
# Complete the immutable copy: first attempt used a wrong generated-manifest path.
c=W/'candidate-01';b=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
assert sha(c/'q4t')==sha(b/'q4t')
shutil.copy2(b/'generated/q4t/server/chat_protocol_sources.json',c/'chat_protocol_sources.json')
manifest=json.loads((c/'chat_protocol_sources.json').read_text())
assert all(sha(ROOT/n)==h for n,h in manifest.items())
protocol=re.search(r'kProtocol\[\] = "([0-9a-f]+)"',(b/'generated/q4t/server/chat_protocol_identity.h').read_text())[1]
save(W/'identity.json',dict(binary=str(c/'q4t'),binary_sha256=sha(c/'q4t'),compiled_manifest_sha256=sha(c/'chat_protocol_sources.json'),protocol_sha256=protocol,compiled_source_identity=manifest,default_protected=True))
save(W/'freeze-03.json',dict(cpu=['tools.serve_responses.test_video_geometry_acceptance'],cases=2,gpu_limits=dict(starts=1,chats=4,controls=2000,seconds=600),source_hashes={n:sha(ROOT/n) for n in ['tools/serve_responses/video_geometry_acceptance.py','tools/serve_responses/test_video_geometry_acceptance.py']},scope='Original rotation, reflection SSE, pixel aspect/rotation and same-PID ordinary text. No expected answers supplied.',record_note='CPU scope and 1/4/600 budget declared in driver and commentary before its two tests. Writing this JSON was interrupted by wrong generated-manifest path; the two CPU tests passed and are not repeated. Candidate preparation corrected without binary/source change.'))
passed={}
for name in ['host-test-01','diagnostic-test-01','host-test-02']:
 for status,test in re.findall(r'\[(PASS|FAIL)\] (\w+)',(W/(name+'.stdout')).read_text()):
  passed[test]=dict(status=status,run=name)
assert len(passed)==14 and all(v['status']=='PASS' for v in passed.values())
for name in ['host-build-02','engine-build-02','source-audit-02','driver-cpu-01','host-test-02']:
 j=json.loads((W/(name+'.json')).read_text());assert j['exit_code']==0 and j['default_unchanged']
 assert 'warning:' not in (W/(name+'.stderr')).read_text()+(W/(name+'.stdout')).read_text()
out=ROOT/'docs/evidence/serve-video-geometry-cpu-20261116';out.mkdir()
with tarfile.open(out/'cpu.tar.gz','w:gz') as tar:
 for p in sorted(W.iterdir()):
  if p.is_file() and p.name not in ['working-01']:
   assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', p.read_bytes())
   tar.add(p,arcname=p.name)
 for folder in ['source-01','source-02']:
  tar.add(W/folder,arcname=folder)
 tar.add(c/'chat_protocol_sources.json',arcname='candidate/chat_protocol_sources.json')
 for name in ['tools/serve_responses/video_geometry_acceptance.py','tools/serve_responses/test_video_geometry_acceptance.py']:
  tar.add(ROOT/name,arcname='driver/'+name)
receipt=dict(status='ACCEPT_NATIVE_VIDEO_GEOMETRY_TARGETED_CPU',distinct_cpp=14,cpp_executions=23,python_cases=2,source_anchors=714,negative_inventory_checks=7,cpp_final=passed,initial_failures=['installed qtdemux omits reflected display matrix tags','capacity error overwritten on failure/EOS'],fixes=['bounded native MP4 movie and selected video track matrix composition','retain explicit failure on pipeline exit'],binary_sha256=sha(c/'q4t'),protocol_sha256=protocol,build_warnings=0,gpu_starts=0,default_revision=142,default_unchanged=True,business_pending=True,archive_sha256=sha(out/'cpu.tar.gz'))
save(out/'acceptance.json',receipt)
(out/'README.md').write_text('''# 视频显示几何针对性 CPU 通过

2026-11-16，14项不同C++最终通过（含失败共23次执行），2项业务驱动
CPU首过，714来源锚点/7项负控通过；主机和完整引擎构建零警告。
实际H.264/VP8/VP9、七种旋转/镜像、MP4/WebM像素比例及组合、预算
和溢出、恶意矩阵、旧v1/v2及新v3冻结读取均有针对性证据。

首轮13项通过11项；失败和两项定点复现完整保留。系统已安装qtdemux
对反射矩阵明确报Unhandled并不发布方向；原生有界MP4矩阵读取补齐
movie/track组合，像素变换仍在隔离worker中。另修复EOS/状态失败时
容量错误被覆盖。8项受影响用例复验通过，6项未变成功记录直接复用。

原生解析不复制第三方实现，不新增外部服务或核心启动依赖；帧预算
在放大前校验，默认rev142/CD640未修改、0GPU。候选及编译来源在
acceptance.json/原件中固定，下一步最多1启动/4创建/600秒实际HTTP。
这不是完整模型质量、性能、格式兼容或总目标完成声明。
''')
# PR29: exact accepted head merged; protect the still-active branch/workspace.
p=ROOT/'.q4t-work/serve-pr29-merged-20261116';out=ROOT/'docs/evidence/serve-pr29-merged-20261116';out.mkdir()
for f in p.iterdir():
 if f.is_file():shutil.copy2(f,out/f.name)
head='a68c8030861ecf7188ea50381a8cf92ed65ceba3';merge='692982e76669d07ee51fba8d5b568edd5e6d10f8'
subprocess.run(['git','merge-base','--is-ancestor',head,'origin/main'],cwd=ROOT,check=True)
save(out/'containment.json',dict(head=head,merge=merge,origin_main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=ROOT,text=True).strip(),accepted_head_contained=True,local_branch_fast_forwarded=True,branch_retained_for_active_geometry_work=True))
(out/'README.md').write_text('''# PR29 已实际合 main

精确head a68c8030861ecf7188ea50381a8cf92ed65ceba3的push/PR两组CI
43821190933和43821195620全部通过，PR29于2026-11-16T07:36:03Z
实际合main，合并提交692982e76669d07ee51fba8d5b568edd5e6d10f8。
已获取远端main并核对完整包含已验head；本地工作分支快进到合并点。

rev142原生视频、文本MTP共同服务、媒体主轻与整树版本恢复和可回退
发行进入main。云适配实现/CPU证据同时合入，但真实账户仍待部署配置。
显示几何后续工作独立，未混入PR29。工作分支因活动修改继续复用，
默认、证据和回退包保持；全部33项计划仍active，不因阶段合并停止。
''')
print(json.dumps(dict(cpu=receipt['status'],candidate=receipt['binary_sha256'],pr29_merged=merge)))

"""Record actual reversible native-ASR publication without altering history."""
import hashlib
import json
from pathlib import Path
import re
import tarfile

R = Path(__file__).resolve().parents[2]; W = Path(__file__).resolve().parent
D = W/'delivery-01'; O = R/'docs/evidence/serve-asr-delivery-20261117'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
v = read(D/'result.json')
assert v['status'] == 'PASS_NATIVE_ASR_DELIVERED' and v['publication']['revision'] == 276
assert len(v['commands']) == 19 and all(x['returncode'] == 0 for x in v['commands'])
assert v['state'] == 'STOPPED' and v['new_gpu_starts'] == 0
c = v['publication']['current']; composition = read(W/'publication-composition.json')
assert c['manifest_sha256'] == composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t') == c['engine_binary_sha256']
assert sha(R/'build/service.release.json') == c['service_release_sha256']
release = read((R/'build/service.release.json').resolve())
files = {'delivery-01/'+p.name:p for p in D.iterdir() if p.is_file() and not p.is_symlink()}
for pattern in ('delivery-prepare-*.*', 'delivery-run-*.*'):
    for p in W.glob(pattern):
        if p.is_file(): files[p.name] = p
for n in ['archive_delivery.py', 'deliver.py', 'run_delivery.py', 'prepare_package.py',
          'publication-composition.json', 'package-01/prepare-review.json']:
    files[n] = W/n
secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'gateway_token', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else: collect(item)
    elif isinstance(value, list):
        for item in value: collect(item)
for p in [R/'build/service/gateway-policy.json', R/'build/service/engine/client-policy.json']:
    collect(read(p))
for name, p in files.items(): assert not any(secret in p.read_bytes() for secret in secrets), name
assert not O.exists(); O.mkdir()
with tarfile.open(O/'records.tar.gz', 'w:gz') as archive:
    for name, p in sorted(files.items()): archive.add(p, arcname=name, recursive=False)
a = dict(status='ACCEPT_NATIVE_ASR_DELIVERY', revision=276, current=c,
    commands=len(v['commands']), seconds=v['seconds'], state='STOPPED', new_gpu_starts=0,
    manual_root=composition['modern_retained_root']['manifest_sha256'],
    automatic_payload=composition['automatic_fallback']['manifest_sha256'],
    candidate_whole_package_gpu_run=True, older_engine_fallback=False,
    previous_rev266_preserved=True, retired_intents_archived=4,
    retired_generations_archived=2, retired_versions_archived=2,
    deleted_files=0, files=len(files), secret_scan_matches=0,
    archive_sha256=sha(O/'records.tar.gz'), main_integration_pending=True,
    full_openai_compatibility=False, all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a, indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生ASR默认交付 rev276

默认包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`；引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、实际整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU，outer保持enabled且累计启动0次。

可选固定Qwen3-ASR-0.6B资产已在本机显式启用；真实multipart
JSON/text/SSE转录、usage/logprobs、预算和取消、双SDK/TLS及
故障隔离已验，主轻和整payload恢复保持ASR及存储Chat。
[接入恢复组合](../serve-asr-service-composition-20261117/README.md)
含原TLS驱动失败累计6启动20创建1探测/316.806秒，307次NVML正常。
两原TLS连续驱动仍FAILED，分项业务与独立同引擎健康来源明确。

核心/client/outer预算字节保持，profile仅显式增加已验ASR；原
history/pending/selected/deadline保持，实际整根回退恢复各根原周期。
人工根`{a['manual_root']}`及自动旧控制payload
`{a['automatic_payload']}`都用当前ASR引擎；不声称独立旧引擎回退。
原rev266及day计划保留，退休4意图/2副本/2登记均可恢复且0删除。

时间戳/字幕/说话人/VAD、Chat音频/合成/Realtime等继续实现，
所有Serve master剩余任务仍须完成。未作完整模型质量、性能或
长稳主张。下一步固定用户长稳入口、完成PR44检查并实际合main。
''')
p = R/'docs/STATUS.md'; s = p.read_text()
rows = {'发布':'rev276；服务包 `'+c['manifest_sha256']+'`',
        'Generation':'`'+c['generation_sha256']+'`',
        '引擎':'`'+c['engine_binary_sha256']+'`',
        '引擎发布记录':'`'+c['engine_release_sha256']+'`',
        'Guardian':'`'+release['guardian_sha256']+'`',
        '原生入口':'`'+release['ingress_sha256']+'`',
        '人工整包回退':'现代保留根 `'+a['manual_root']+'`；ASR/原周期/原生入口已验，前驱rev266另保留',
        '自动payload回退':'已验旧控制/当前ASR引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退',
        '外部依赖':'原生入口/自监护不要求nginx/systemd；ASR模型按部署显式启用，codec按请求隔离加载，失效不拖停健康Chat'}
for name, value in rows.items():
    s, count = re.subn(r'^\| '+re.escape(name)+r' \| .* \|$', lambda _:f'| {name} | {value} |', s, count=1, flags=re.M)
    assert count == 1
start = s.index('下一步STOPPED可回退发布和实际合main。')
end = s.index('\n[直接HTTP分项接受]', start)
s = s[:start]+f'''[rev276可回退交付已完成](evidence/serve-asr-delivery-20261117/README.md)：
19项STOPPED命令/{v['seconds']:.3f}秒，实际整根回退与再前进通过，
0新增GPU。原核心/client/outer预算与各根周期保持，profile显式
增加ASR；退休记录可恢复归档，原rev266和day保持。继续固定
当前用户day入口、PR44最终检查和实际合main，随后所有剩余任务。
''' + s[end:]
intro = f'''[rev276原生ASR交付](evidence/serve-asr-delivery-20261117/README.md)
19项STOPPED发布/整根回退/再前进通过，{v['seconds']:.3f}秒，0新增GPU。
ASR资产/预算已显式绑定默认，原核心/client/outer预算和周期保持。
原rev266及day保留；继续独立长稳交接、PR44合main与全部master。

'''
s = s.replace('[rev266原生维护交付]', intro+'前驱[rev266原生维护交付]', 1)
s = s.replace('## 最近完成的实现和验证\n\n', '## 最近完成的实现和验证\n\n'+intro, 1)
p.write_text(s)
p = R/'docs/log/2026-11-17.md'; header, rest = p.read_text().split('\n', 1)
p.write_text(header+f'''\n\n## rev276原生ASR已可回退交付

19项STOPPED检查/发布/整根回退/再前进通过，{v['seconds']:.3f}秒，
0新增GPU。核心/client/outer预算和原周期保持，显式启用已验ASR
和profile；原rev266/day及两个TLS原失败保留，旧记录可恢复归档。
下一步固定用户day入口、PR44检查合main，然后继续全部master，
转录交付不等于音频或总计划完成。\n'''+rest)
p = R/'docs/serve-master-goals-v2.json'; j = read(p)
for task in j['tasks']:
    if task['id'] in ['A10', 'A12', 'Q01', 'Q02']:
        task['native_asr_delivery_20261117'] = a | dict(evidence='evidence/serve-asr-delivery-20261117/README.md')
    if task['id'] == 'Q02':
        task['latest_release'] = a | dict(evidence='evidence/serve-asr-delivery-20261117/README.md')
        task['remaining_required'] = ['Native ASR PR44 final-head checks and actual main merge', 'Delivery of every remaining implementation']
    if task['id'] == 'R07':
        task['current_execution_prerequisite'] = 'Refresh exact cold qualification against rev276 or then-current default; pending host/camera maintenance handoff remains required.'
j['next'] = 'Freeze current ASR day handoff, finish PR44 checks and actual main merge; implement every remaining Serve master-plan task.'
p.write_text(json.dumps(j, ensure_ascii=False, indent=2)+'\n')
p = R/'docs/README.md'; p.write_text(p.read_text()+'\n- [rev276原生ASR交付](evidence/serve-asr-delivery-20261117/README.md)：真实转录、独立资源和可回退服务恢复。\n')
p = R/'README.md'; s = p.read_text(); start = s.index('原生音频后端正在实现；'); end = s.index('\nMIT (项目代码)', start)
s = s[:start]+'''原生Qwen3-ASR-0.6B转录已在rev276可回退交付，支持multipart
JSON/text/SSE、实际usage/logprobs、language/prompt、取消和显式
资源预算。中英文真实音频、双SDK、原生TLS、主轻与整包恢复均有
[分项业务证据](docs/evidence/serve-asr-service-composition-20261117/README.md)。
原数值差分和TLS驱动失败保留；不作完整模型质量或长稳主张。

ASR资产按部署通过`--asr-model-dir DIR`启用，固定revision/权重
合同在加载时核验，不要求vLLM或Transformers运行服务。默认预算为
30秒音频、4096上下文token、1024输出token、1024MiB workspace；
可用`--asr-max-audio-seconds`、`--asr-max-context-tokens`、
`--asr-max-output-tokens`、`--asr-workspace-mib`显式调整。托管
服务准备命令也接收这些选项；独立客户端上传/输入/输出额度仍生效。
ASR或codec故障隔离于相应请求，真正共享设备故障仍保留保护。

音频codec在隔离worker复用系统GStreamer音频库/固定插件，核心
不链接或加载它们，不启动外部解码程序。按官方API适配，未复制
codec源码；系统插件保留其LGPL等发行许可。模型来源、固定revision
与Apache-2.0许可见[Qwen3-ASR声明](third_party/licenses/qwen3-asr/README.md)。
时间戳/字幕/说话人/VAD、Chat音频、语音合成及Realtime继续按
[总音频计划](docs/SERVE_NATIVE_AUDIO_2026-11-17.md)实现。
''' + s[end:]; p.write_text(s)
print(json.dumps({k:a[k] for k in ('status', 'revision', 'commands', 'seconds')}))

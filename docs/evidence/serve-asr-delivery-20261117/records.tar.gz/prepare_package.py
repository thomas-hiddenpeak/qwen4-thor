"""Seal actually qualified native ASR engine, then prepare a pending service candidate."""
import copy
import hashlib
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2];sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'package-01';B=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD=(ROOT/'build/service').resolve(strict=True);P=W/'profiles-01'
helpers=runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))
EXPECTED_CONTROL={'tools/serve_recovery/bundle.py','tools/serve_recovery/deployment.py','tools/serve_recovery/profile_bundle.py','tools/serve_recovery/profile_contract.py','tools/serve_recovery/profile_controller.py','tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_migration.py','tools/serve_recovery/service.py','tools/serve_service/package.py','tools/serve_service/service.py'}
EXPECTED_NATIVE={'CMakeLists.txt','include/q4t/server/application_routes.h','include/q4t/server/request_limits.h','include/q4t/trace/sha256.h','src/server/http_request.cpp','src/service/ingress_main.cpp','src/trace/sha256.cpp','tests/host/CMakeLists.txt'}
def cp(src,dst):
 dst.parent.mkdir(mode=0o700,parents=True,exist_ok=True);shutil.copyfile(src,dst)
def main():
 os.umask(0o077)
 p.require(not OUT.exists(),'preserve prior candidate')
 p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit sources first')
 protected={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
 original=bundle.verify(OLD,p.sha(OLD/'manifest.json'));old_metadata=p.read(OLD/'engine/q4t.release.json');base=p.read(OLD/'engine/manifest.json')
 plan=p.read(P/'plan.json');qualification=p.read(P/'acceptance.json');direct=p.read(ROOT/'docs/evidence/serve-asr-http-20261117/acceptance.json')
 p.require(qualification['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and qualification['environment']['cleanup_complete'],'actual profile qualification missing')
 runtime=helpers['source_hashes']();compiled=p.read(B/'generated/q4t/server/chat_protocol_sources.json');runtime.update(compiled)
 p.require(all(p.sha(ROOT/n)==h and plan['sources'].get(n,compiled.get(n))==h for n,h in runtime.items()),'qualified runtime drift')
 p.require(p.sha(B/'q4t')==plan['binary_sha256']=='b02d7f25891fb8d43e2d4eefbe6aaef95721ec2332b45ebdab0b46f55a75cec7','accepted engine identity differs')
 previous=p.read(old_metadata['tested_source_manifest']);delta={n for n,h in runtime.items() if previous.get(n)!=h}
 direct_sources=p.read(W/'service-http-05/plan.json')['sources']
 direct_compiled=p.read(ROOT/'docs/evidence/serve-asr-scope-20261117/generated-engine-sources.json')
 for n,h in direct_compiled.items():
  if n not in direct_sources:direct_sources[n]=h
 direct_delta={n for n,h in runtime.items() if direct_sources.get(n)!=h}
 p.require(direct_delta=={'include/q4t/server/asr_assets.h','src/server/chat_capabilities.cpp'},'unreviewed difference from actual SDK engine')
 control={n for n in bundle.SOURCES if p.sha(ROOT/n)!=p.sha(OLD/'source'/n)}
 p.require(control==EXPECTED_CONTROL,'unreviewed management delta')
 native_old=p.read(OLD/'native-build.json');native_delta={n for n,h in native_old['source_files'].items() if p.sha(ROOT/n)!=h}
 p.require(native_delta==EXPECTED_NATIVE,'unreviewed native delta')
 native=dict(version=1,source_repository=str(ROOT),source_files={n:p.sha(ROOT/n) for n in sorted(bundle.NATIVE_SOURCES)})
 native_identity={}
 for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),('ingress','q4t-ingress'),('device_control','q4t-device-control')]:
  native[field+'_sha256']=p.sha(B/name);native_identity[name]=dict(sha256=p.sha(B/name),unchanged_from_default=p.sha(B/name)==p.sha(OLD/'bin'/name))
 p.require(p.read(W/'native-build-01/result.json')['exit_code']==0 and p.read(W/'native-build-01/result.json')['unchanged'],'current helper build missing')
 OUT.mkdir(mode=0o700);engine=OUT/'engine'
 for n in ['q4t','CMakeCache.txt']:cp(B/n,engine/n)
 (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
 protocol=hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
 caps=p.read(P/'primary-capabilities.json');config=p.read(P/'primary-config.json')
 p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,'actual declaration differs')
 decision=dict(status='PASS_NATIVE_ASR_ENGINE_PROFILE_BUSINESS',acceptance='ACCEPT_NATIVE_ASR_ENGINE_PROFILE_BUSINESS',binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,source_commit=plan['source_commit'],actual_primary_light=qualification,direct_asr_business=direct,direct_engine_delta=sorted(direct_delta),direct_reuse_scope='Only fixed ASR identity constants and capability JSON differ; all execution/codec/request code unchanged. Exact current-engine primary/light ASR and existing text/media/embedding are newly qualified. Native TLS SDK and full managed recovery remain pending.',source_delta=sorted(delta),control_delta=sorted(control),full_model_quality=False,performance_acceptance=False,version_composition_pending=True,default_changed=False,remaining_master_tasks_open=True)
 metadata=copy.deepcopy(old_metadata)
 metadata.update(version='serve-native-asr-20261117',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],acceptance=decision['acceptance'],acceptance_decision=str(OUT/'decision.json'),build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),tested_source_manifest=str(engine/'runtime-source.json'),tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),previous_release=str(OLD/'engine/q4t.release.json'),inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),sha256=p.sha(OLD/'engine/q4t.release.json')),source_note=decision['direct_reuse_scope'])
 metadata['native_asr_engine_acceptance']=decision
 declarations=engine/'declarations';declarations.mkdir(mode=0o700)
 p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
 metadata['chat_protocol'].update(caps,protocol_sha256=protocol,declaration_evidence='Actual fixed native ASR and exact primary/light document-tool/media/embedding; managed native TLS and recovery qualification pending.')
 for name,stem in helpers['SCHEMAS'].items():
  source=ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'));target=declarations/'schemas'/(name+'.json');cp(source,target)
  metadata['chat_protocol'][name+'_schema']=str(target);metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
 metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,directory=str(declarations),binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,files={n:p.sha(declarations/n) for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
 for source in (ROOT/'third_party/licenses').rglob('*'):
  if source.is_file():cp(source,engine/'licenses'/source.relative_to(ROOT/'third_party/licenses'))
 metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output');metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
 for name,record in metadata['file_input_system_dependencies'].items():
  source=Path(record['artifact']);p.require(p.sha(source)==record['sha256'],'system notice drift');target=engine/'licenses/system'/name;cp(source,target);record['artifact']=str(target)
 clients=metadata['client_artifacts'];client_delta={n for n,h in clients['files'].items() if p.sha(ROOT/n)!=h}
 p.require(not client_delta,'unreviewed application client delta')
 for n in clients['files']:cp(ROOT/n,OUT/'clients'/n)
 clients['directory']=str(OUT/'clients');p.save(OUT/'decision.json',decision)
 metadata['acceptance_decision_sha256']=p.sha(OUT/'decision.json')
 p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True);p.save(OUT/'native-build.json',native)
 kwargs={key:OLD/'engine'/n for key,n in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json'),('web_policy','web-policy.json')] if (OLD/'engine'/n).is_file()}
 settings=copy.deepcopy(base['settings']);settings['native_asr']=p.read(W/'asr-profile-config-01.json')
 receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',base['model_dir'],B/'q4t-guardian',B/'q4t-cuda-probe',None,OLD/'gateway-policy.json',OLD/'engine/client-policy.json',OUT/'bundle',native_receipt=OUT/'native-build.json',native_ingress=B/'q4t-ingress',device_control=B/'q4t-device-control',capacity_config=dict(version=2,**{k:v for k,v in settings['profile'].items() if k not in ('name','host')}),application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},embedding_model_dir=Path(settings['native_embedding']['directory']),asr_model_dir=Path(settings['native_asr']['directory']),asr_limits=settings['native_asr']['limits'],recovery_profiles=P/'qualified/registry.json',recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
 p.save(OUT/'receipt.json',receipt)
 p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,'unrelated settings drift')
 p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
 p.save(OUT/'prepare-review.json',dict(status='ASR_CANDIDATE_MANAGED_ACCEPTANCE_PENDING',previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),package_sha256=receipt['manifest_sha256'],runtime_source_sha256=runtime,runtime_delta=sorted(delta),control_source_delta=sorted(control),native_source_delta=sorted(native_delta),native_executables=native_identity,client_delta=sorted(client_delta),new_gpu_starts=0,default_changed=False,managed_composition_pending=True))
 print(receipt['manifest_sha256'])
if __name__=='__main__':main()

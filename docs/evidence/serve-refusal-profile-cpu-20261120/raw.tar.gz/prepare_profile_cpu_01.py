from pathlib import Path
import hashlib,json,subprocess,sys,unittest
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;OUT=W/'profile-cpu-01';OUT.mkdir();sys.path.insert(0,str(ROOT))
from tools.serve_audit.check_inventory import current_surface,check
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
selected=['tools.serve_recovery.test_profile_refusal','tools.serve_recovery.test_profile_prompt_reuse','tools.serve_recovery.test_profile_prompt_targeted']
base='tools.serve_recovery.test_native_bundle.BundleTests.'
selected += [base+n for n in ['test_default_package_has_native_binary_and_no_nginx_dependency','test_realtime_native_sources_cannot_be_omitted_or_changed_in_build_receipt','test_v22_includes_refusal_review_without_changing_v21','test_v21_includes_prompt_readers_without_changing_v20','test_historical_source_inventory_versions_remain_verifiable','test_file_transport_and_client_capacity_require_v11_identity','test_http_profile_seals_normalized_policy_and_preserves_managed_binding','test_relocated_current_contains_complete_outer_resume_and_root_transfer_sources']]
suite=unittest.defaultTestLoader.loadTestsFromNames(selected)
def ids(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from ids(x)
  else:yield x.id()
tests=list(ids(suite));assert len(tests)==27 and not any('_FailedTest' in t for t in tests),(len(tests),tests)
p=ROOT/'tools/serve_audit/inventory.json';detach(p);value=json.loads(p.read_text());current=current_surface(ROOT);changed={n:h for n,h in current['sources_sha256'].items() if value['sources_sha256'].get(n)!=h};value['sources_sha256'].update(changed);value['refusal_consumer_qualification_20261120']=dict(scope='Exact reviewed main-model consumers fresh; standalone backends and original voice registration visible; fresh saved-voice Chat/ASR required; v22 keeps old sealed inventories',runtime_binary='648d6d68553a45eb3c5fb703b68dba2e63dd1ed7171f68c1c420b599819723f5',cpu_checks_pending=27);save(p,value);assert not check(value,current),check(value,current)
paths=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()+['tools/serve_recovery/profile_refusal_reuse.py','tools/serve_recovery/profile_refusal_targeted.py','tools/serve_recovery/test_profile_refusal.py']
commands=[['python3','-B','-m','unittest',*selected,'-v'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
save(OUT/'plan.json',dict(scope='Fresh consumer/retained backend proof, immutable source/owner/capacity, v22 packaging with v1-v21 compatibility; no model execution',native_runtime_unchanged=True,tests=tests,maximum_tests=27,source_counterexamples=20,maximum_seconds=120,new_gpu_starts=0,commands=commands,sources={n:sha(ROOT/n) for n in paths if n.startswith(('tools/','.github/'))}))
intro='主模型消费者的有界资格驱动已编写：2模型/34外部请求/8WSS/6入口/\n10注册操作/900秒，另记录2个CSV与既有有界语义评分内部步骤。\n旧独立后端保留原身份；媒体/音频问答/语义停顿重验，内置Chat语音\n与已验声线快照的Chat/ASR取得新证据。v22封包保留v1～v21来源合同。\n先冻结27项CPU和20来源反例/120秒/0GPU；默认rev356及原FAIL保持，\n随后短验和交付，全部master继续。\n\n'
p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 全局提示受影响消费者的资格来源实现\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：只重验文本会漏掉主模型媒体/语音消费者，全部重跑又重复了\n未变后端；显式记录旧来源与新消费者，保留可核验输出/配额/清理合同。\n\n下一步：针对性CPU与有界实际主轻短验，通过后继续恢复与可回退交付。\n'+t)
print(json.dumps(dict(tests=len(tests),source_anchors=len(changed),gpu_actions=0)))

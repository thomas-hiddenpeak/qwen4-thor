from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-refusal-profile-cpu-20261120';O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
p=json.loads((W/'profile-cpu-01/plan.json').read_text());r=json.loads((W/'profile-cpu-01/result.json').read_text());assert r['status']=='PASS' and r['sources_unchanged']
files={str(f.relative_to(W)):f for f in (W/'profile-cpu-01').iterdir() if f.is_file()}
for n,h in p['sources'].items():assert sha(R/n)==h;files['source/'+n]=R/n
for n in ('prepare_profile_cpu_01.py','archive_profile_cpu_01.py'):files[n]=W/n
index={n:dict(bytes=f.stat().st_size,sha256=sha(f)) for n,f in files.items()};save(O/'index.json',index)
with tarfile.open(O/'raw.tar.gz','w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
with tarfile.open(O/'raw.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
a=dict(status='PASS_REFUSAL_CONSUMER_QUALIFICATION_CPU',tests=27,source_counterexamples=20,seconds=r['seconds'],new_gpu_starts=0,runtime_binary='648d6d68553a45eb3c5fb703b68dba2e63dd1ed7171f68c1c420b599819723f5',runtime_unchanged=True,default_unchanged=True,actual_profile_qualification=False,archive_sha256=sha(O/'raw.tar.gz'));save(O/'acceptance.json',a)
(O/'README.md').write_text('''# 主模型消费者资格：来源与驱动 CPU

27项CPU及20项来源反例通过，2.381秒，0GPU。涵盖原Prompt来源合同、
新拒答说明的确切源码/身份/容量复用门、声线快照的所有权/条件/真实Chat
与存储/用量、缺失消费者与扩预算拒绝、独立大证据读取边界及v22封包。
v1～v21历史库存和校验继续通过，一般服务元数据仍保持2MiB上限。

下一组固定2模型/34外部请求/8WSS/6入口/10注册操作/900秒；CSV内部
模型步骤2次、语义评分内部步骤受既有上限控制并记录实际用量。
主/轻各自取得新文本、工具、Prompt、视频、音频问答、Chat语音和
语义停顿证据；声线使用已验且条件相同的私有快照，不重复注册矩阵。
未变后端原记录保持；CPU并不代表实际主轻或恢复已经合格。
默认rev356和原失败保持，全部master继续。
''')
intro='[受影响消费者27项CPU通过](evidence/serve-refusal-profile-cpu-20261120/README.md)：\n2.381秒/0GPU，20来源反例通过，v22与v1～v21历史封包合同保持。\n候选648d6d68不变；继续冻结2模型/34外部请求/8WSS/6入口/900秒\n实际主轻短验，显式保留旧后端与新消费者，默认rev356及原FAIL保持。\n随后恢复和可回退交付，全部master继续。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 主模型消费者来源与封包CPU通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：资格必须能拒绝篡改来源、跳过消费者或混淆历史证据，避免\n因文本短验通过而漏掉其他使用相同提示的业务。\n\n下一步：实际有界主轻短验，满足后继续恢复及交付，不终止总计划。\n'+t)
print(json.dumps(a))

from pathlib import Path
import ast,hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'duplex-driver-cpu-02';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
reuse={}
for file,names in [('tools/serve_realtime/test_duplex_acceptance.py',None),('tools/serve_realtime/duplex_checks.py',None),('tools/serve_realtime/duplex_acceptance.py',{'check_plan','accounting'})]:
 old=subprocess.check_output(['git','show','5003aff43:'+file],cwd=R,text=True);before={x.name:ast.dump(x,include_attributes=False) for x in ast.walk(ast.parse(old)) if isinstance(x,ast.FunctionDef)};now={x.name:ast.dump(x,include_attributes=False) for x in ast.walk(ast.parse((R/file).read_text())) if isinstance(x,ast.FunctionDef)}
 if file.endswith('test_duplex_acceptance.py'):names={n for n in before if n.startswith('test_')}|{'response_fixture','idle_fixture'}
 if names is None:names=set(before)
 assert all(before[n]==now[n] for n in names),(file,[n for n in names if before[n]!=now[n]])
 reuse[file]={n:hashlib.sha256(before[n].encode()).hexdigest() for n in sorted(names)}
files=['tools/serve_realtime/'+n for n in ['duplex_acceptance.py','duplex_checks.py','duplex_sdk.mjs','test_duplex_acceptance.py','bounded_journal.mjs','bounded_journal.test.mjs']]+['.github/workflows/host-checks.yml']
commands=[['python3','-B','-m','unittest','-v',*['tools.serve_realtime.test_duplex_acceptance.Checks.'+n for n in ['test_actor_timeout_retains_written_stdout_and_stderr','test_journal_receipt_must_keep_all_original_events_and_attempts']]],['node','--test','tools/serve_realtime/bounded_journal.test.mjs'],['node','--check','tools/serve_realtime/duplex_sdk.mjs']]
plan=dict(scope=json.loads((W/'journal-repair-plan-01.json').read_text()),sources={n:sha(R/n) for n in files},commands=commands,reused_original_cpu_result=dict(path=str(W/'duplex-driver-cpu-01/result.json'),sha256=sha(W/'duplex-driver-cpu-01/result.json'),unchanged_function_ast=reuse),protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']})
save('plan.json',plan);start=time.monotonic();runs=[]
for i,cmd in enumerate(commands):
 p=subprocess.run(cmd,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O.resolve())),capture_output=True,timeout=max(.1,120-(time.monotonic()-start)));(O/f'command-{i}.stdout').write_bytes(p.stdout);(O/f'command-{i}.stderr').write_bytes(p.stderr);runs.append(dict(command=cmd,returncode=p.returncode))
 if p.returncode:break
unchanged=all(sha(n)==v for n,v in plan['protected'].items());ok=unchanged and len(runs)==3 and all(x['returncode']==0 for x in runs)
r=dict(status='PASS' if ok else 'FAIL',commands=runs,seconds=time.monotonic()-start,new_python_cases=2,new_node_cases=4,original_python_cases_reused=10,default_unchanged=unchanged,gpu_starts=0);save('result.json',r);print(json.dumps(r));raise SystemExit(not ok)

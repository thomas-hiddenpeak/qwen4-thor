"""Bind reviewed MCP sources and exact rebuilt helpers without publishing."""
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p

W = Path(__file__).resolve().parent
B = ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD = (ROOT/'build/service').resolve(strict=True)
previous = p.read(p.read(OLD/'engine/q4t.release.json')['tested_source_manifest'])
names = subprocess.check_output(['git','ls-files','src','include','cmake','CMakeLists.txt'],
                                cwd=ROOT,text=True).splitlines()
runtime = {n:p.sha(ROOT/n) for n in names}
runtime.update(p.read(B/'generated/q4t/server/chat_protocol_sources.json'))
delta = {n for n,h in runtime.items() if previous.get(n) != h}
p.require(all(n.startswith(('src/server/', 'include/q4t/server/')) or n in {
    'CMakeLists.txt', 'cmake/ChatProtocolIdentity.cmake', 'cmake/HostTestSources.cmake',
    'src/main.cpp', 'src/service/ingress_main.cpp'} for n in delta),
    'model math or unreviewed runtime changed')
control = {n for n in bundle.SOURCES if p.sha(ROOT/n) != p.sha(OLD/'source'/n)}
p.require(control == {'tools/serve_gateway/gateway.py', 'tools/serve_recovery/bundle.py',
    'tools/serve_recovery/gateway.py', 'tools/serve_recovery/gateway_config.py',
    'tools/serve_recovery/service.py', 'tools/serve_service/package.py',
    'tools/serve_service/service.py', 'tools/serve_recovery/profile_migration.py',
    'tools/serve_recovery/version_contract.py'}, 'control delta differs')
old_native = p.read(OLD/'native-build.json')
native_delta = {n for n in bundle.NATIVE_SOURCES
                if old_native['source_files'].get(n) != p.sha(ROOT/n)}
p.require(native_delta == {'CMakeLists.txt', 'include/q4t/server/application_routes.h',
    'include/q4t/server/http_connection.h', 'include/q4t/server/http_framing.h',
    'include/q4t/server/http_request.h', 'src/server/http_request.cpp',
    'src/service/ingress_main.cpp'}, 'native delta differs')
for stem in ('release-native-build-01', 'release-tools-build-01'):
    p.require(p.read(W/(stem+'.json'))['exit_code'] == 0 and
        'warning:' not in (W/(stem+'.stderr')).read_text() + (W/(stem+'.stdout')).read_text(),
        'native/tools rebuild failed or warned')
native = dict(version=1, source_repository=str(ROOT),
    source_files={n:p.sha(ROOT/n) for n in sorted(bundle.NATIVE_SOURCES)})
same = {}
for field, name in [('guardian', 'q4t-guardian'), ('cuda_probe', 'q4t-cuda-probe'),
                    ('ingress', 'q4t-ingress'), ('device_control', 'q4t-device-control')]:
    native[field+'_sha256'] = p.sha(B/name)
    same[name] = p.sha(B/name) == p.sha(OLD/'bin'/name)
p.require(same == {'q4t-guardian':True, 'q4t-cuda-probe':True,
                   'q4t-ingress':False, 'q4t-device-control':True}, 'helper changes differ')
p.require(native['ingress_sha256'] ==
    '8c669d808962d74612c1ae2e6cee7758d2c19bfba6bf1c938a582d69aa91585a', 'tested ingress changed')
native['reuse_review'] = dict(previous=str(OLD/'native-build.json'),
    sha256=p.sha(OLD/'native-build.json'), changed_sources=sorted(native_delta),
    executable_hashes_identical=same,
    current_build_result=str(W/'release-native-build-01.json'),
    current_build_result_sha256=p.sha(W/'release-native-build-01.json'),
    rationale='MCP tunnel headers, routes and independent admission have exact CPU/TLS/native acceptance; three other native helpers are byte-identical. No math-kernel changes.')
p.require(not (W/'native-build.json').exists() and not (W/'runtime-review.json').exists(),
          'preserve original review')
p.save(W/'native-build.json', native)
p.save(W/'runtime-review.json', dict(previous_package=str(OLD),
    previous_manifest_sha256=p.sha(OLD/'manifest.json'), runtime_delta=sorted(delta),
    runtime_source_sha256=runtime, control_delta=sorted(control),
    control_source_sha256={n:p.sha(ROOT/n) for n in sorted(control)},
    native_source_delta=sorted(native_delta),
    native_rebuild_receipt_sha256=p.sha(W/'native-build.json'),
    scope='Native MCP approval, stateful HTTP/SSE, isolated transport and private tunnel agent, media/resources, authenticated program and batch integration; CPU evidence and actual SDK business retained. Control changes add optional deployment policy, native/optional ingress lanes and explicit capability/authority preserving recovery. Provider adapters remain a master task.'))
print(json.dumps(dict(runtime_files=len(delta), control_files=len(control),
                     helper_bytes_unchanged=same)))

"""Archive exact package recovery evidence, excluding private runtime state."""
import json
from pathlib import Path
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_service.package import read, save, sha, require

W = Path(__file__).resolve().parent
OUT = ROOT/'docs/evidence/serve-mcp-managed-20261116'
require(not OUT.exists(), 'preserve previous archive')
records = {label:read(W/('managed-'+label+'-01/decision.json'))
           for label in ('retained', 'version')}
for label, value in records.items():
    require(value['acceptance'] == 'ACCEPT_MCP_SERVICE_'+label.upper(),
            'exact managed package not accepted')
files = []
for name in ('managed-retained-01', 'managed-version-01'):
    folder = W/name
    files += [p for p in folder.iterdir() if p.is_file()]
    for child in ('lease', 'execution'):
        files += [p for p in (folder/child).iterdir()
                  if p.is_file() and p.name != 'budget.lock']
for prefix in ('managed-retained-prepare-01', 'managed-retained-run-01',
               'managed-retained-finalize-01', 'managed-version-prepare-01',
               'managed-version-run-01', 'managed-version-finalize-01',
               'managed-driver-cpu-01', 'candidate-prepare-01',
               'retained-prepare-01', 'release-tools-build-01'):
    row = read(W/(prefix+'.json'))
    require(row['exit_code'] == 0 and row['default_unchanged'], prefix+' failed')
    files += [p for p in W.glob(prefix+'.*') if p.is_file()]
files += [W/name for name in ('prepare_candidate.py', 'prepare_retained.py',
    'review_candidate.py', 'runtime-review.json', 'native-build.json',
    'mcp_managed_acceptance.py', 'test_mcp_managed.py',
    'candidate-01/prepare-review.json', 'candidate-01/receipt.json', 'retained-01/review.json')]
tokens = set()
for name in ('candidate-01', 'retained-01'):
    policy = read(W/name/'bundle/gateway-policy.json')
    tokens.update(v['api_key'].encode() for v in policy['clients'])
    tokens.add(read(W/name/'bundle/engine/client-policy.json')['gateway_token'].encode())
files = sorted(set(files))
for path in files:
    raw = path.read_bytes()
    require(not any(s and s in raw for s in tokens) and b'PRIVATE KEY-----' not in raw,
            'credential in '+str(path.relative_to(W)))
OUT.mkdir()
with tarfile.open(OUT/'managed.tar.gz', 'w:gz') as archive:
    for path in files+[Path(__file__)]:
        archive.add(path, arcname=str(path.relative_to(W)), recursive=False)
for label, value in records.items():
    save(OUT/(label+'-acceptance.json'), value)
save(OUT/'raw-sha256.json', {str(p.relative_to(W)):sha(p) for p in files})
a, b = [records[label]['actual_business'] for label in ('retained', 'version')]
save(OUT/'summary.json', dict(status='ACCEPT_MCP_CAPABLE_MANAGED_PACKAGES',
    primary=records['version']['manifest_sha256'], retained=records['retained']['manifest_sha256'],
    engine=records['version']['engine_binary_sha256'],
    this_group=dict(starts=3, requests=6, device_probes=1),
    cumulative=dict(starts=6, requests=22, native_embedding_requests=2, device_probes=1),
    separate_actual_mcp='docs/evidence/serve-mcp-business-20261116/acceptance.json',
    session_recovery_cpu='docs/evidence/serve-mcp-sessions-execution-cpu-20261116/README.md',
    actual_recovery_remote_mcp_dispatch=False, actual_recovery_program_document_closure=True,
    default_changed=False, remaining_master_tasks_open=True))
(OUT/'README.md').write_text(f'''# MCP能力包的受控恢复短验（2026-11-16）

主包{records['version']['manifest_sha256'][:8]}、兼容回退包{records['retained']['manifest_sha256'][:8]}已完成真实服务验收。
独立回退包1启动2业务，严格租约{a['strict_lease_seconds']:.3f}秒；整树切换
2启动4业务1CUDA探测，{b['strict_lease_seconds']:.3f}秒。自有入口SIGABRT
后Guardian保留，控制器/模型/入口换代；原程序、caller、调用schema
和存储保持，错误结果拒绝；实际资料只读1次，续接后SSE输出正确
标题和引用。回退前后MCP全部能力、profile历史与配额预算保持。

本组验证共享执行/存储与整树恢复；实际MCP远端派发及私网agent
JSON/SSE闭环见前组业务，MCP会话/审批/冻结恢复使用既有针对性CPU
证据，不把本组描述为远端MCP调用跨真实故障的端到端场景。
本组3启动6请求1探测，{a['nvml_queries']+b['nvml_queries']}次NVML正常；
累计6启动22请求（其中2个embedding）1探测。各阶段严格租约、真实
进程/端口/锁清理均核验；未开展完整性能/全模型质量或长稳矩阵。

主包/回退包是相同新引擎与不同控制版本；不是独立旧引擎回退。
默认保持rev126；下一步17项STOPPED可回退发布和实际合main。
原始私有state/objects不归档，实际凭据扫描0命中。全部master及
提供方适配继续，阶段通过不代表完整OpenAI兼容完成。
''')
save(OUT/'sha256.json', {p.name:sha(p) for p in OUT.iterdir() if p.is_file()})
print(json.dumps(dict(status='ARCHIVED', files=len(files), credential_matches=0)))

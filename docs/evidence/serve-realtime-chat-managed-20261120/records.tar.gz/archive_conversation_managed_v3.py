"""Compose accepted real stages, preserving all original failed reviews."""
from pathlib import Path
import hashlib
import json
import tarfile

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
OUT = W / 'managed-publication-03'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def save(path, value):
    if path.exists():
        assert read(path) == value, 'Existing observation changed: '+str(path)
        return
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')


assert not OUT.exists()
rows, files, conversations, semantics = [], {}, {}, {}
for name in ('retained-service-01', 'tls-service-02', 'version-service-02'):
    directory = W / name
    plan, result, decision, lease, business = [read(directory / path) for path in
        ('plan.json', 'execution/result.json', 'decision.json', 'lease/exit.json',
         'execution/media-usage.json')]
    assert result['status'] == 'PASS_BOUNDED_FEATURE_SERVICE'
    assert result['failure'] is result['cleanup_failure'] is None
    assert lease['status'] == 'COMPLETED' and lease['child_returncode'] == 0
    assert lease['compute_backend'] == 'nvml' and lease['lease_inherited_by_child']
    assert all(v is True for v in decision['actual_business']['postflight'].values())
    assert all(sha(Path(v['path'])) == v['sha256'] for v in plan['protected'])
    if name == 'retained-service-01':
        review = decision['actual_business']['command_identity_review']
        assert review['original_literal_command_check_passed'] is False
        assert sha(Path(review['path'])) == review['sha256']
        assert read(W / 'retained-command-review-02/result.json')['status'] == \
            'PASS_RETAINED_COMMAND_IDENTITY_AND_FULL_FINALIZATION'
    else:
        assert lease['command'] == plan['command']
    queries = [json.loads(s) for s in
               (directory / 'lease/nvml-queries.jsonl').read_text().splitlines()]
    assert queries and all(v['status'] == 'OK' and v['returncode'] == 0
                           for v in queries) and queries[-1]['pids'] == []
    counts = result['budget']['counts']
    assert len(result['models']) == counts['starts'] == plan['limits']['starts']
    assert all(counts[k] == plan['limits'][k]
               for k in ('chats', 'probes', 'websocket_sessions'))
    conversation = {k:v for k,v in business['results'].items()
                    if k.endswith('-conversation')}
    semantic = {k:v for k,v in business['results'].items()
                if k.endswith('-semantic')}
    assert len(conversation) == len(semantic) == (1 if name.startswith('retained') else 2)
    assert all(v['completed_tokens'] > 0 and v['actual_tokens'] >= v['completed_tokens']
               and not v['automatic_replay'] for v in conversation.values())
    assert all(v['actual_classifier'] and v['actual_tokens'] > 0 and
               v['resources_released'] and not v['automatic_replay']
               for v in semantic.values())
    conversations[name], semantics[name] = conversation, semantic
    rows.append(dict(name=name, counts=counts, seconds=result['seconds'],
        strict_lease_seconds=decision['actual_business']['strict_lease_seconds'],
        nvml_queries=len(queries), business=business,
        postflight=decision['actual_business']['postflight']))
    for path in ('plan.json', 'decision.json', 'service-release.json',
                 'execution/result.json', 'execution/media-usage.json',
                 'execution/business-final.json', 'execution/core-continuity.json',
                 'execution/counts.json', 'execution/stop.json',
                 'lease/exit.json', 'lease/events.jsonl', 'lease/nvml-queries.jsonl'):
        files[name + '/' + path] = directory / path
    # Text-only actual SDK events are public. PCM/authorized recordings stay local.
    for path in (directory / 'execution').glob('*conversation*'):
        if path.is_file():
            files[name + '/execution/' + path.name] = path
    witnesses = {str(p.relative_to(directory)): dict(sha256=sha(p), bytes=p.stat().st_size)
                 for p in (directory / 'execution').glob('*semantic*') if p.is_file()}
    save(directory / 'semantic-witness-index.json', witnesses)
    files[name + '/semantic-witness-index.json'] = directory / 'semantic-witness-index.json'
assert conversations['tls-service-02']['tls-before-conversation']['mode'] == 'hold_stream'
assert conversations['tls-service-02']['tls-before-conversation']['interrupted_usage_from_server']
roots = {name: {k:read(W / path / 'receipt.json')[k]
                for k in ('package', 'manifest_sha256')}
         for name,path in [('candidate','service-package-01'),
                           ('retained','retained-01'),('tls','tls-package-01')]}
assert read(W / 'profiles-01/acceptance.json')['status'] == 'ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
starts = sum(r['counts']['starts'] for r in rows)
work = sum(r['counts']['chats'] for r in rows)
sessions = sum(r['counts']['websocket_sessions'] for r in rows)
assert (starts, work, sessions) == (4, 84, 15)
assert sum(r['seconds'] for r in rows) < 1500
composition = dict(status='ACCEPT_NATIVE_REALTIME_CHAT_SERVICE_COMPOSITION_WITH_MODEL_QUALITY_LIMITATION',
    binary_sha256=read(W / 'service-package-01/receipt.json')['engine_binary_sha256'],
    candidate=roots['candidate'], automatic_fallback=roots['retained'],
    modern_retained_root=roots['retained'], tls_package=roots['tls'], stages=rows,
    conversation_turns=conversations, semantic_turns=semantics,
    actual_model_starts=starts, service_requests=63, realtime_tasks=21,
    websocket_sessions=sessions, semantic_tasks=5, realtime_chat_responses=11,
    service_work_items=work, service_probes=sum(r['counts']['probes'] for r in rows),
    service_seconds=sum(r['seconds'] for r in rows),
    nvml_queries=sum(r['nvml_queries'] for r in rows), nvml_all_ok=True,
    cleanup_complete=True, strict_finalizers_all_passed=False,
    retained_exact_execution_identity_reviewed=True,
    original_literal_command_failure_preserved=True,
    private_review_initialization_failure_preserved=True,
    strict_runtime_environment_checks_passed=True,
    original_version_driver_passed=False, qualified_version_driver_passed=True,
    original_version_environment_abort_preserved=True,
    original_version_environment_evidence='docs/evidence/serve-realtime-chat-recovery-followup-20261120/README.md',
    tls_composition=read(W / 'tls-service-02/decision.json'),
    candidate_service_acceptance=read(W / 'version-service-02/decision.json'),
    modern_service_acceptance=read(W / 'retained-service-01/decision.json'),
    candidate_whole_package_gpu_run=True, default_unchanged=True,
    publication_pending=True, older_engine_fallback=False, full_model_quality=False,
    performance_claim=False, all_master_tasks_complete=False,
    original_failure_relabelled=False, listening='PENDING_BY_OWNER',
    primary_light_evidence='docs/evidence/serve-realtime-chat-primary-light-20261119/README.md',
    normal_speed_voice_similarity_accepted=False, strict_fp_boundary_accepted=True,
    model_quality_policy='record_exact_source_answer_separately',
    original_sampled_answer_quality='FAIL',
    original_tls_stage='tls-service-01', original_tls_stage_passed=False,
    user_quality_classification_accepted='2026-11-20',
    original_quality_evidence='docs/evidence/serve-realtime-chat-recovery-review-20261119/README.md',
    bounded_diagnostic_evidence='docs/evidence/serve-realtime-chat-sampling-20261120/README.md')
save(W / 'publication-composition.json', composition)
for path in ('publication-composition.json', 'managed-quality-freeze-01/plan.json',
             'archive_conversation_managed_v3.py', 'review_retained_command.py',
             'resume_retained_command_review.py'):
    files[path] = W / path
for name in ('retained-command-review-01','retained-command-review-02',
             'native-build-01','native-build-02','failed-binaries-archive-01','cpu-cache-archive-01',
             'rebuildable-cache-cleanup-01','host-cache-archive-01',
             'generated-dependencies-archive-01','managed-archive-review-01'):
    for path in (W / name).iterdir():
        if path.is_file() and path.suffix in ('.json','.py','.log','.stdout','.stderr'):
            files[name + '/' + path.name] = path
secrets = []


def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key','gateway_token','shared_secret','private_key','token') \
                    and isinstance(item,str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value,list):
        for item in value:
            collect(item)


for descriptor in roots.values():
    for name in ('gateway-policy.json','engine/client-policy.json'):
        collect(read(Path(descriptor['package']) / name))
for name, path in files.items():
    content = path.read_bytes()
    assert not any(value in content for value in secrets), name
    assert (b'-----BEGIN ' + b'PRIVATE KEY-----') not in content, name
OUT.mkdir()
save(OUT / 'index.json', {name:dict(sha256=sha(path),bytes=path.stat().st_size)
                        for name,path in files.items()})
with tarfile.open(OUT / 'records.tar.gz','w:gz') as archive:
    for name,path in sorted(files.items()):
        archive.add(path,arcname=name,recursive=False)
summary = {k:v for k,v in composition.items() if k not in
           ('stages','tls_composition','candidate_service_acceptance','modern_service_acceptance')}
summary.update(archive_sha256=sha(OUT / 'records.tar.gz'),archive_files=len(files),
               secret_scan_matches=0)
save(OUT / 'acceptance.json',summary)
(OUT / 'README.md').write_text(f'''# Realtime Chat 实际恢复验收（2026-11-20）

4 次模型启动、63 项 HTTP + 21 项 Realtime 工作、15 条 WebSocket、
1 次 CUDA 探测，{composition['service_seconds']:.3f} 秒；
{composition['nvml_queries']} 次 NVML 全部正常，自有进程/端口/GPU 锁释放。

保留包及 TLS/整包恢复前后共 5 组真实两轮资料查询协议通过，来源绑定
实际 STATUS 与 rev346，文本/工具流事件与实际用量一致。模型答案质量
单列在 conversation_turns 中；原 TLS 首轮错误答案继续 FAIL，不追认
原整组通过。用户已确认该质量分类；严格主轻正确答案资格门保持。
本次 TLS 在第三个
独立请求的真实增量后中断，旧连接关闭，取消用量从服务指标复核；健康
模型/控制器不重启。整包恢复切换控制器、模型与入口；显式新连接继续，
不自动重连或重放。已配置 ASR、语义 VAD、ICL、语音与 HTTP 能力同时检查。

保留组首次 finalize 因相对/绝对路径字符串不同拒绝，原拒绝保持。
冻结 guard 源码证明固定 cwd，两处路径精确解析到相同文件；6 项 CPU
反例通过，其余原始来源、环境、业务与清理合同全部复核通过。复核脚本
首次遗漏初始化的失败也保留。两次复核都没有新增 GPU 工作或改写原件。
本次 TLS/版本组执行冻结绝对命令，严格 finalize 通过。
原 TLS 首轮、两次诊断脚本失败和 greedy 单条观察另有完整归档；
原整包组因 NVML init 超时记 ENV_ABORT，原件与未完成项保持；
环境与自有资源核对后，仅增加了一次固定整包组。
本组合不声称所有历史尝试都通过，也不声称完整模型质量通过。

引擎 f5af36c6、v17 主轻资格及恢复包保持；默认 rev346 STOPPED 尚未替换。
原错误辅助构建和 3 个失败程序均保留，失败程序无损归档并逐项 SHA 核实。
声纹/原 exact-code 失败、用户认可的严格浮点边界及延期听感保持。
音频/MCP/Prompt/追踪/Live 与全部 Serve 总计划继续，未宣称完整兼容或长稳通过。
''')
print(json.dumps({k:composition[k] for k in ('status','actual_model_starts',
    'service_requests','realtime_tasks','service_seconds','nvml_queries')}))

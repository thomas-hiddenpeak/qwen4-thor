"""Initialize the original driver limits, then resume read-only finalization."""
from pathlib import Path
import contextlib
import copy
import io
import json
import os
import runpy
import sys
import time

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
prior = runpy.run_path(str(W / 'review_retained_command.py'))
sha, save, normalized = (prior[k] for k in ('sha', 'save', 'normalized'))
OLD, OUT = W / 'retained-command-review-01', W / 'retained-command-review-02'
RUN = W / 'retained-service-01'
PLAN = RUN / 'plan.json'
os.umask(0o077)
OUT.mkdir(mode=0o700)
proof = json.loads((OLD / 'proof.json').read_bytes())
assert sha(W / 'review_retained_command.py') == proof['driver_sha256']
assert proof['cpu_checks'] == 6 and 'Ran 6 tests' in (OLD / 'cpu.log').read_text()
assert (OLD / 'cpu.log').read_text().rstrip().endswith('OK')
assert all(sha(p) == value for p, value in proof['raw_hashes'].items())
save(OLD / 'result.json', dict(status='FAILED_REVIEW_INITIALIZATION',
    error='RuntimeError: acceptance budget changed',
    reason='The private runpy caller omitted configure_plan_limits from the original main entry.',
    cpu_checks_passed=6, finalization_completed=False, new_gpu_starts=0,
    driver_sha256=proof['driver_sha256']))
save(OUT / 'plan.json', dict(scope=__doc__, maximum_seconds=60,
    reused_cpu_tests=6, original_review=str(OLD / 'result.json'),
    original_review_sha256=sha(OLD / 'result.json'),
    proof_sha256=sha(OLD / 'proof.json'), new_gpu_starts=0,
    driver_sha256=sha(__file__)))
begin = time.monotonic()
plan = json.loads(PLAN.read_bytes())
guard = json.loads((RUN / 'lease/exit.json').read_bytes())
stage = runpy.run_path(str(ROOT / 'tools/native_asr/service_acceptance.py'))
stage['configure_plan_limits'](plan)
assert stage['GLOBALS']['LIMITS'][plan['scenario']] == plan['limits']
original_accept = stage['accepted_run']


def reviewed_accept(p, result, observed, queries, events):
    assert p == plan and observed == guard
    reviewed = copy.deepcopy(observed)
    reviewed['command'] = normalized(observed['command'], p['command'], ROOT)
    environment = original_accept(p, result, reviewed, queries, events)
    environment['command_identity_review'] = dict(
        path=str(OLD / 'proof.json'), sha256=sha(OLD / 'proof.json'),
        original_literal_command_check_passed=False,
        review_continuation=str(OUT / 'plan.json'),
        review_continuation_sha256=sha(OUT / 'plan.json'))
    return environment


stage['GLOBALS']['accepted_run'] = reviewed_accept
output = io.StringIO()
try:
    with contextlib.redirect_stdout(output):
        stage['GLOBALS']['finalize'](PLAN)
    (OUT / 'finalize.stdout').write_text(output.getvalue())
    assert all(sha(p) == value for p, value in proof['raw_hashes'].items())
    elapsed = time.monotonic() - begin
    assert elapsed < 60
    result = dict(status='PASS_RETAINED_COMMAND_IDENTITY_AND_FULL_FINALIZATION',
        seconds=elapsed, reused_cpu_checks=6, new_gpu_starts=0,
        original_literal_command_failure_preserved=True,
        review_initialization_failure_preserved=True,
        original_records_unchanged=True,
        decision_sha256=sha(RUN / 'decision.json'),
        service_release_sha256=sha(RUN / 'service-release.json'),
        proof_sha256=sha(OLD / 'proof.json'))
    save(OUT / 'result.json', result)
    print(json.dumps(result))
except BaseException as error:
    save(OUT / 'result.json', dict(status='FAILED', error=repr(error),
        seconds=time.monotonic() - begin, new_gpu_starts=0))
    raise

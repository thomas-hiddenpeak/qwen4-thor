"""Review one relative-path invocation without changing its raw evidence.

The frozen guard runs its child with cwd=ROOT. Only argv[3] and argv[6]
may use the recorded relative spellings; all other arguments and every
original environment, business, cleanup and source check remain mandatory.
"""
from pathlib import Path
import copy
import hashlib
import io
import contextlib
import json
import os
import runpy
import subprocess
import sys
import time
import unittest

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
ROOT = W.parents[1]
RUN = W / 'retained-service-01'
OUT = W / 'retained-command-review-01'
PLAN = RUN / 'plan.json'
GUARD = RUN / 'lease/exit.json'
GUARD_SOURCE = 'tools/evalscope/gpu_exclusive.py'
GUARD_SHA = '7cfbae4d8f6caf151aa816c1bb1a580301c329f9c31e591879ebb5b5c0e3a351'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def normalized(actual, expected, cwd):
    if cwd != ROOT or len(actual) != 7 or len(expected) != 7:
        raise ValueError('execution root or argument count differs')
    fixed = [0, 1, 2, 4, 5]
    if any(actual[i] != expected[i] for i in fixed):
        raise ValueError('interpreter, mode or flags differ')
    relative = ['tools/native_asr/service_acceptance.py',
                str(PLAN.relative_to(ROOT))]
    value = list(actual)
    for i, permitted in zip((3, 6), relative):
        if actual[i] != permitted:
            raise ValueError('not the exact observed relative spelling')
        resolved = (cwd / actual[i]).resolve(strict=True)
        if str(resolved) != expected[i] or not resolved.samefile(expected[i]):
            raise ValueError('relative path identifies a different file')
        value[i] = str(resolved)
    if value != expected:
        raise ValueError('command differs after reviewed path expansion')
    return value


def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700)
    plan = json.loads(PLAN.read_bytes())
    guard = json.loads(GUARD.read_bytes())
    raw_hashes = {str(p): sha(p) for p in
                  (PLAN, GUARD, RUN / 'execution/result.json',
                   RUN / 'lease/events.jsonl', RUN / 'lease/nvml-queries.jsonl')}
    assert plan['sources'][GUARD_SOURCE] == GUARD_SHA == sha(ROOT / GUARD_SOURCE)
    # This exact reviewed source passes cwd=ROOT to subprocess.Popen(command).
    source = (ROOT / GUARD_SOURCE).read_text()
    assert 'subprocess.Popen(command, cwd=ROOT, start_new_session=True,' in source
    assert plan['source_commit'] == 'f30474741d6f34f8b69332baafda8e6ef261eeb2'
    assert plan['command'] == ['/usr/bin/python3', '-I', '-B',
        str(ROOT / 'tools/native_asr/service_acceptance.py'),
        'run', '--plan', str(PLAN)]
    save(OUT / 'plan.json', dict(scope=__doc__, raw_hashes=raw_hashes,
        maximum_seconds=60, maximum_cpu_tests=6, new_gpu_starts=0,
        source_guard_sha256=GUARD_SHA, driver_sha256=sha(__file__)))
    begin = time.monotonic()
    original = subprocess.run(['/usr/bin/python3', '-I', '-B',
        str(ROOT / 'tools/native_asr/service_acceptance.py'),
        'finalize', '--plan', str(PLAN)], cwd=ROOT,
        capture_output=True, timeout=30)
    (OUT / 'original-finalize.stdout').write_bytes(original.stdout)
    (OUT / 'original-finalize.stderr').write_bytes(original.stderr)
    assert original.returncode == 1
    assert original.stderr.endswith(b'RuntimeError: strict managed environment not accepted\n')

    class PathReview(unittest.TestCase):
        def test_exact_observed_paths(self):
            self.assertEqual(normalized(guard['command'], plan['command'], ROOT),
                             plan['command'])

        def test_wrong_root(self):
            with self.assertRaises(ValueError):
                normalized(guard['command'], plan['command'], ROOT.parent)

        def test_changed_interpreter(self):
            changed = list(guard['command']); changed[0] = '/usr/bin/python'
            with self.assertRaises(ValueError):
                normalized(changed, plan['command'], ROOT)

        def test_changed_flags(self):
            changed = list(guard['command']); changed[1] = '-S'
            with self.assertRaises(ValueError):
                normalized(changed, plan['command'], ROOT)

        def test_changed_plan(self):
            changed = list(guard['command']); changed[6] = 'plan.json'
            with self.assertRaises(ValueError):
                normalized(changed, plan['command'], ROOT)

        def test_extra_argument(self):
            with self.assertRaises(ValueError):
                normalized(guard['command'] + ['--other'], plan['command'], ROOT)

    stream = io.StringIO()
    checks = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(PathReview))
    (OUT / 'cpu.log').write_text(stream.getvalue())
    assert checks.wasSuccessful() and checks.testsRun == 6
    proof = dict(status='EXACT_EXECUTION_PATH_IDENTITY_REVIEWED',
        original_literal_command_check_passed=False,
        original_finalizer_returncode=original.returncode,
        original_failure_sha256=sha(OUT / 'original-finalize.stderr'),
        actual_command=guard['command'], frozen_command=plan['command'],
        child_cwd=str(ROOT), child_cwd_source=GUARD_SOURCE,
        child_cwd_source_sha256=GUARD_SHA,
        normalized_command=normalized(guard['command'], plan['command'], ROOT),
        original_records_unchanged=True, new_gpu_starts=0,
        raw_hashes=raw_hashes, cpu_checks=checks.testsRun,
        driver_sha256=sha(__file__))
    save(OUT / 'proof.json', proof)
    sys.path.insert(0, str(ROOT))
    stage = runpy.run_path(str(ROOT / 'tools/native_asr/service_acceptance.py'))
    original_accept = stage['accepted_run']

    def reviewed_accept(p, result, observed, queries, events):
        assert p == plan and observed == guard
        reviewed = copy.deepcopy(observed)
        reviewed['command'] = normalized(observed['command'], p['command'], ROOT)
        # Run every original strict gate; only the two proven path spellings differ.
        environment = original_accept(p, result, reviewed, queries, events)
        environment['command_identity_review'] = dict(
            path=str(OUT / 'proof.json'), sha256=sha(OUT / 'proof.json'),
            original_literal_command_check_passed=False)
        return environment

    stage['GLOBALS']['accepted_run'] = reviewed_accept
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        stage['GLOBALS']['finalize'](PLAN)
    (OUT / 'review-finalize.stdout').write_text(output.getvalue())
    assert all(sha(p) == digest for p, digest in raw_hashes.items())
    elapsed = time.monotonic() - begin
    assert elapsed < 60
    result = dict(status='PASS_RETAINED_COMMAND_IDENTITY_AND_FULL_FINALIZATION',
        seconds=elapsed, cpu_checks=checks.testsRun, new_gpu_starts=0,
        original_literal_command_failure_preserved=True,
        original_records_unchanged=True,
        decision_sha256=sha(RUN / 'decision.json'),
        service_release_sha256=sha(RUN / 'service-release.json'),
        proof_sha256=sha(OUT / 'proof.json'))
    save(OUT / 'result.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

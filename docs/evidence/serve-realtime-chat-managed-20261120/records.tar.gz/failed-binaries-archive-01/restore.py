from pathlib import Path
import hashlib,json,tarfile,os
root=Path(__file__).resolve().parent;work=root.parent
value=json.loads((root/'manifest.json').read_text());archive=root/'programs.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==value['archive_sha256']
with tarfile.open(archive,'r:gz') as tar:
 for row in value['files']:
  path=work/row['path'];assert path.resolve().is_relative_to(work)
  if path.exists():
   assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'];continue
  member=tar.getmember(row['path']);assert member.isfile()
  data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
  fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,row['mode'])
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  path.chmod(row['mode']);print('restored',path)

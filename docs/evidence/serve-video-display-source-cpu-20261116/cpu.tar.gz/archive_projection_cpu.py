import hashlib,json,re,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
b=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build';c=W/'candidate-02';c.mkdir()
shutil.copy2(b/'q4t',c/'q4t');shutil.copy2(b/'generated/q4t/server/chat_protocol_sources.json',c/'chat_protocol_sources.json')
manifest=json.loads((c/'chat_protocol_sources.json').read_text());assert all(sha(ROOT/n)==h for n,h in manifest.items())
protocol=re.search(r'kProtocol\[\] = "([0-9a-f]+)"',(b/'generated/q4t/server/chat_protocol_identity.h').read_text())[1]
identity=dict(binary=str(c/'q4t'),binary_sha256=sha(c/'q4t'),compiled_manifest_sha256=sha(c/'chat_protocol_sources.json'),protocol_sha256=protocol)
save(W/'identity-02.json',identity)
for name in ['host-build-05','engine-build-04','host-test-04','source-audit-04']:
 r=json.loads((W/(name+'.json')).read_text());assert r['exit_code']==0 and r['default_unchanged']
 assert 'warning:' not in (W/(name+'.stdout')).read_text()+(W/(name+'.stderr')).read_text()
assert '5 tests, 5 passed, 0 failed, 0 skipped' in (W/'host-test-04.stdout').read_text()
out=ROOT/'docs/evidence/serve-video-display-source-cpu-20261116';out.mkdir()
with tarfile.open(out/'cpu.tar.gz','w:gz') as tar:
 for name in ['freeze-04.json','freeze-05.json','required-04.txt','identity-02.json','archive_projection_cpu.py']:
  tar.add(W/name,arcname=name)
 for stem in ['host-build-04','host-build-05','engine-build-04','host-test-04','source-audit-04']:
  for suffix in ['json','stdout','stderr']:tar.add(W/(stem+'.'+suffix),arcname=stem+'.'+suffix)
 for name in ['source-04','source-05']:tar.add(W/name,arcname=name)
 tar.add(c/'chat_protocol_sources.json',arcname='candidate/chat_protocol_sources.json')
save(out/'acceptance.json',dict(status='ACCEPT_DISPLAY_SOURCE_TARGETED_CPU',cases=5,identity=identity,source_anchors=714,negative_source_checks=7,default_unchanged=True,new_gpu_starts=0,original_http_failure_retained=True,archive_sha256=sha(out/'cpu.tar.gz')))
(out/'README.md').write_text('''# 实际视频显示尺寸进入共享输入说明

2026-11-16，5项针对性C++首过，主机/引擎零警告，714来源锚点/7项
负控通过。新用例从真实上传的视频经过同一准备、模板与ProcessVideo，
确认旋转64×128、镜像128×64、像素比例与旋转64×256；最终patch网格
同样保持该尺寸，没有方形化。来源说明仅增加经快照验证的宽、高和
通用含义，不加入颜色、layout分类或预期答案；数值处理不变。

计数/生成投影一致、删除原件后无codec续接、实际工具视频投影均通过。
首次主机构建因测试使用不存在的GetObject失败，改为既有Find加类型
检查；生产引擎未受该测试编译修正影响，原记录保留。0新增GPU，
rev142保持。下一步同一原问题/原预期最多1启动/4创建/600秒补验，
不把先前实际失败或本次CPU通过写成模型业务通过。
''')
print(json.dumps(identity))

#include "q4t/server/object_store.h"
#include "q4t/test.h"
int main(int argc, char** argv) {
  const int worker = q4t::server::MaybeRunObjectWorker(argc, argv);
  if (worker >= 0) return worker;
  return q4t::test::RunAllTests();
}

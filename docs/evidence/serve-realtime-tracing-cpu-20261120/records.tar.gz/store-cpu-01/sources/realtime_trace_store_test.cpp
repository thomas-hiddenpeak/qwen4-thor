#include "realtime_trace_store.h"

#include <condition_variable>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <future>
#include <thread>

#include "object_protocol.h"
#include "q4t/server/grammar_process.h"
#include "q4t/test.h"
#include "realtime_trace.h"

namespace {
using namespace q4t::server;
using namespace q4t::server::object_detail;
using namespace std::chrono_literals;
using Clock = std::chrono::steady_clock;
namespace fs = std::filesystem;
struct Fixture {
  fs::path root;
  ObjectStoreOptions application;
  RealtimeTraceStoreOptions options;
  Fixture() {
    const auto* output = std::getenv("Q4T_TEST_OUTPUT_DIR");
    auto directory =
        fs::absolute(output ? output : ".q4t-work/trace-store-test");
    fs::create_directories(directory);
    auto name = (directory / "trace-XXXXXX").string();
    if (!mkdtemp(name.data()))
      throw std::runtime_error("trace fixture directory");
    root = name;
    application.directory = (root / "objects").string();
    options = ResolveRealtimeTraceStoreOptions(application.directory + "/");
  }
};
RealtimeTraceCollector Collector(std::string session = "sess_test") {
  RealtimeTraceConfiguration config;
  config.enabled = true;
  config.workflow_name = "project query";
  config.metadata = Object({{"private_metadata", String("caller-private")}});
  RealtimeTraceCollector result(std::move(session), "conv_test", config,
                                {1795185600000, 0});
  result.Begin("response", "resp_test", {}, {1795185600001, 1000000});
  return result;
}
ObjectRequest Request(ObjectOperation op, std::string id,
                      std::string scope = "client:a") {
  ObjectRequest request;
  request.operation = op;
  request.id = std::move(id);
  request.scope = std::move(scope);
  request.kind = ObjectKind::kTrace;
  return request;
}
RealtimeTraceStore::Producer Open(RealtimeTraceStore& store, std::string scope,
                                  std::string session) {
  const auto deadline = Clock::now() + 1s;
  while (Clock::now() < deadline) {
    if (auto producer = store.Open(scope, session)) return producer;
    std::this_thread::sleep_for(1ms);
  }
  return {};
}
ObjectReply Read(RealtimeTraceStore& store, std::string id,
                 std::string scope = "client:a") {
  return store.Execute(
      Request(ObjectOperation::kGet, std::move(id), std::move(scope)),
      Clock::now() + 5s);
}
ObjectReply AppWrite(ObjectStore& store) {
  auto request = Request(ObjectOperation::kPut, "resp_business");
  request.kind = ObjectKind::kResponse;
  request.data = Object({{"value", String("healthy application")}});
  return store.Execute(request, Clock::now() + 2s);
}
bool Wait(const std::function<bool()>& predicate, int ms = 2500) {
  const auto deadline = Clock::now() + std::chrono::milliseconds(ms);
  while (Clock::now() < deadline) {
    if (predicate()) return true;
    std::this_thread::sleep_for(2ms);
  }
  return predicate();
}
bool Submit(RealtimeTraceStore& store,
            const RealtimeTraceStore::Producer& producer,
            const RealtimeTraceCollector& collector) {
  // An actual owner retries a rejected snapshot on a later bounded tick.
  // Fixture waits only for transient lock contention, never false durability.
  return Wait([&] { return store.Publish(producer, collector.Snapshot()); });
}
struct Barrier {
  std::mutex mutex;
  std::condition_variable changed;
  bool entered = false, released = false;
  explicit Barrier(std::string point) {
    RealtimeTraceExporterHookForTesting([this, point](std::string_view stage) {
      if (stage != point) return;
      std::unique_lock lock(mutex);
      if (released) return;
      entered = true;
      changed.notify_all();
      changed.wait_for(lock, 5s, [&] { return released; });
    });
  }
  bool Entered() {
    std::unique_lock lock(mutex);
    return changed.wait_for(lock, 2s, [&] { return entered; });
  }
  void Release() {
    const std::lock_guard lock(mutex);
    released = true;
    changed.notify_all();
  }
  ~Barrier() {
    Release();
    RealtimeTraceExporterHookForTesting({});
  }
};
struct HookReset {
  ~HookReset() {
    RealtimeTraceExporterHookForTesting({});
    ObjectWorkerEntryForTesting({});
  }
};
}  // namespace

Q4T_TEST(trace_store_application_and_trace_domains_are_independent) {
  Fixture f;
  ObjectStore app(f.application);
  ObjectStore traces(f.options.objects);
  Q4T_CHECK(AppWrite(app).ok());
  auto put = Request(ObjectOperation::kPut, "trace_domain");
  put.data = Object({{"value", Number(1)}});
  Q4T_CHECK(traces.Execute(put, Clock::now() + 2s).ok());
  Q4T_CHECK(app.Execute(put, Clock::now() + 2s).http_status == 400);
  put.kind = ObjectKind::kResponse;
  Q4T_CHECK(traces.Execute(put, Clock::now() + 2s).http_status == 400);
  ObjectStore duplicate(f.options.objects);
  Q4T_CHECK(duplicate.Health().state == "controller_owned");
  Q4T_CHECK(app.Health().workers_started == 1);
  Q4T_CHECK(traces.Health().workers_started == 1);
  Q4T_CHECK(traces.ScanResponses({}, Clock::now() + 1s).http_status == 400);
  Q4T_CHECK(traces.Retention(1, 1, {}, Clock::now() + 1s).http_status == 400);
  return true;
}

Q4T_TEST(trace_store_scoped_durable_crud_and_bounded_summary) {
  Fixture f;
  Q4T_CHECK(f.options.objects.directory == f.application.directory + "-traces");
  RealtimeTraceStore store(f.options);
  auto producer = Open(store, "client:a", "sess_test");
  auto collector = Collector();
  Q4T_CHECK(producer && Submit(store, producer, collector));
  auto record = Read(store, producer->Id());
  Q4T_CHECK(record.ok() && record.value.GetString("status") == "in_progress");
  Q4T_CHECK(record.value.Find("metadata")->GetString("private_metadata") ==
            "caller-private");
  Q4T_CHECK(record.value.Find("persistence")->GetInt("object_revision") == 1);
  Q4T_CHECK(Read(store, producer->Id(), "client:b").http_status == 404);
  auto foreign = Request(ObjectOperation::kErase, producer->Id(), "client:b");
  Q4T_CHECK(store.Execute(foreign, Clock::now() + 2s).http_status == 404);
  Q4T_CHECK(!producer->Revoked());
  auto page =
      store.Execute(Request(ObjectOperation::kList, {}), Clock::now() + 2s);
  Q4T_CHECK(page.ok() && page.value.GetArray("data")->array.size() == 1);
  const auto& summary = page.value.GetArray("data")->array.front();
  Q4T_CHECK(summary.GetBool("summary") && summary.GetInt("span_count") == 1);
  Q4T_CHECK(!summary.Has("metadata") && !summary.Has("spans"));
  auto erased = store.Execute(Request(ObjectOperation::kErase, producer->Id()),
                              Clock::now() + 2s);
  Q4T_CHECK(erased.ok() && erased.value.GetBool("deleted"));
  Q4T_CHECK(producer->Revoked());
  collector.EventSeen();
  Q4T_CHECK(!store.Publish(producer, collector.Snapshot()));
  Q4T_CHECK(Read(store, producer->Id()).http_status == 404);
  return true;
}

Q4T_TEST(trace_store_coalesces_latest_snapshot_without_growing_queue) {
  Fixture f;
  f.options.max_queue = 2;
  RealtimeTraceStore store(f.options);
  auto a = Open(store, "client:a", "sess_test");
  auto b = Open(store, "client:b", "sess_other");
  auto collector = Collector();
  Barrier barrier("before_dispatch");
  Q4T_CHECK(a && b && Submit(store, a, collector));
  Q4T_CHECK(barrier.Entered());
  collector.EventSeen();
  Q4T_CHECK(Submit(store, a, collector));
  collector.EventSeen();
  Q4T_CHECK(Submit(store, a, collector));
  const auto before = Clock::now();
  Q4T_CHECK(!store.Publish(b, Collector("sess_other").Snapshot()));
  Q4T_CHECK(Clock::now() - before < 100ms);
  Q4T_CHECK(store.Health().pending == 2);
  barrier.Release();
  Q4T_CHECK(Wait([&] { return store.Health().pending == 0; }));
  const auto record = Read(store, a->Id());
  Q4T_CHECK(record.ok() && record.value.GetInt("revision") ==
                               static_cast<int64_t>(collector.Revision()));
  Q4T_CHECK(store.Health().persisted == 2);
  return true;
}

Q4T_TEST(trace_store_deletion_prevents_late_and_queued_resurrection) {
  Fixture f;
  RealtimeTraceStore store(f.options);
  auto producer = Open(store, "client:a", "sess_test");
  auto collector = Collector();
  Q4T_CHECK(producer && Submit(store, producer, collector));
  Q4T_CHECK(Read(store, producer->Id()).ok());
  Barrier barrier("before_save_commit");
  collector.EventSeen();
  Q4T_CHECK(Submit(store, producer, collector));
  Q4T_CHECK(barrier.Entered());
  collector.EventSeen();
  Q4T_CHECK(Submit(store, producer, collector));
  auto erased = std::async(std::launch::async, [&] {
    return store.Execute(Request(ObjectOperation::kErase, producer->Id()),
                         Clock::now() + 3s);
  });
  Q4T_CHECK(Wait([&] { return producer->Revoked(); }));
  barrier.Release();
  Q4T_CHECK(erased.get().ok());
  Q4T_CHECK(Read(store, producer->Id()).http_status == 404);
  Q4T_CHECK(store.Health().persisted == 1);
  return true;
}

Q4T_TEST(trace_store_lost_final_snapshot_reports_capture_interrupted) {
  Fixture f;
  RealtimeTraceStore store(f.options);
  auto producer = Open(store, "client:a", "sess_test");
  Q4T_CHECK(producer && Submit(store, producer, Collector()));
  const auto id = producer->Id();
  Q4T_CHECK(Read(store, id).ok());
  producer.reset();
  auto record = Read(store, id);
  Q4T_CHECK(record.ok() && record.value.GetString("status") == "interrupted");
  Q4T_CHECK(record.value.GetString("close_reason") == "capture_interrupted");
  Q4T_CHECK(record.value.Find("ended_at_ms")->IsNull());
  const auto& span = record.value.GetArray("spans")->array.front();
  Q4T_CHECK(span.GetString("status") == "interrupted");
  Q4T_CHECK(span.Find("duration_ms")->IsNull());
  return true;
}

Q4T_TEST(trace_store_restart_marks_orphan_without_replaying_work) {
  Fixture f;
  std::string id;
  {
    RealtimeTraceStore store(f.options);
    auto producer = Open(store, "client:a", "sess_test");
    Q4T_CHECK(producer && Submit(store, producer, Collector()));
    id = producer->Id();
    Q4T_CHECK(Read(store, id).ok());
  }
  RealtimeTraceStore restarted(f.options);
  const auto record = Read(restarted, id);
  Q4T_CHECK(record.ok() && record.value.GetString("status") == "interrupted");
  Q4T_CHECK(record.value.GetString("close_reason") == "owner_interrupted");
  Q4T_CHECK(record.value.Find("persistence")->GetBool("owner_interrupted"));
  Q4T_CHECK(record.value.Find("persistence")->GetInt("object_revision") == 1);
  Q4T_CHECK(restarted.Health().persisted == 0);
  return true;
}

Q4T_TEST(trace_store_io_failure_does_not_disable_application_store) {
  Fixture f;
  std::ofstream(f.options.objects.directory) << "not a directory";
  ObjectStore application(f.application);
  RealtimeTraceStore traces(f.options);
  auto producer = Open(traces, "client:a", "sess_test");
  Q4T_CHECK(producer && Submit(traces, producer, Collector()));
  Q4T_CHECK(!Read(traces, producer->Id()).ok());
  Q4T_CHECK(traces.Health().failures > 0);
  Q4T_CHECK(AppWrite(application).ok());
  Q4T_CHECK(application.Health().state == "ready");
  return true;
}

Q4T_TEST(trace_store_exporter_exception_recovers_in_same_bounded_owner) {
  Fixture f;
  RealtimeTraceStore store(f.options);
  auto producer = Open(store, "client:a", "sess_test");
  auto collector = Collector();
  HookReset reset;
  std::atomic<bool> fail{true};
  RealtimeTraceExporterHookForTesting([&](std::string_view stage) {
    if (stage == "before_dispatch" && fail.exchange(false))
      throw std::bad_alloc();
  });
  Q4T_CHECK(producer && Submit(store, producer, collector));
  Q4T_CHECK(Read(store, producer->Id()).http_status == 404);
  collector.EventSeen();
  Q4T_CHECK(Submit(store, producer, collector));
  Q4T_CHECK(Read(store, producer->Id()).ok());
  const auto health = store.Health();
  Q4T_CHECK(health.controller_failures == 1 &&
            health.controller_recoveries == 1);
  return true;
}

Q4T_TEST(trace_store_thread_construction_failure_recovers_with_backoff) {
  Fixture f;
  FailRealtimeTraceExporterStartForTesting();
  RealtimeTraceStore store(f.options);
  Q4T_CHECK(!store.Health().running && store.Health().controller_failures == 1);
  auto producer = Open(store, "client:a", "sess_test");
  Q4T_CHECK(producer && !store.Publish(producer, Collector().Snapshot()));
  std::this_thread::sleep_for(110ms);
  Q4T_CHECK(Read(store, producer->Id()).http_status == 404);
  Q4T_CHECK(Submit(store, producer, Collector()));
  Q4T_CHECK(Read(store, producer->Id()).ok());
  Q4T_CHECK(store.Health().controller_recoveries == 1);
  return true;
}

Q4T_TEST(trace_store_uncertain_commit_is_read_back_without_blind_replay) {
  Fixture f;
  HookReset reset;
  ObjectWorkerEntryForTesting("--q4t-object-worker-lost-ack");
  RealtimeTraceStore store(f.options);
  auto producer = Open(store, "client:a", "sess_test");
  auto collector = Collector();
  Q4T_CHECK(producer && Submit(store, producer, collector));
  Q4T_CHECK(Wait([&] { return store.Health().pending == 0; }, 4000));
  Q4T_CHECK(store.Health().failures == 1 && store.Health().persisted == 0);
  std::this_thread::sleep_for(110ms);
  const auto record = Read(store, producer->Id());
  Q4T_CHECK(record.ok());
  Q4T_CHECK(record.value.Find("persistence")->GetInt("object_revision") == 1);
  Q4T_CHECK(record.value.GetInt("revision") ==
            static_cast<int64_t>(collector.Revision()));
  Q4T_CHECK(!store.Publish(producer, collector.Snapshot()));
  Q4T_CHECK(Read(store, producer->Id())
                .value.Find("persistence")
                ->GetInt("object_revision") == 1);
  return true;
}

Q4T_TEST(trace_store_allocation_and_producer_limits_are_enforced) {
  Fixture f;
  f.options.max_client_producers = 1;
  RealtimeTraceStore store(f.options);
  auto producer = Open(store, "client:a", "sess_test");
  Q4T_CHECK(producer && !store.Open("client:a", "sess_another"));
  Q4T_CHECK(!store.Open("client:a", "sess_test"));
  auto huge = Collector().Snapshot();
  Field(huge, "metadata").str.reserve(8ULL << 20);
  const auto start = Clock::now();
  Q4T_CHECK(!store.Publish(producer, std::move(huge)));
  Q4T_CHECK(Clock::now() - start < 100ms);
  Q4T_CHECK(store.Health().pending == 0);
  Q4T_CHECK(Submit(store, producer, Collector()));
  Q4T_CHECK(Read(store, producer->Id()).ok());
  return true;
}

Q4T_TEST(trace_store_blocked_exporter_retains_its_slot_after_bounded_shutdown) {
  Fixture f;
  Barrier barrier("before_dispatch");
  auto store = std::make_unique<RealtimeTraceStore>(f.options);
  auto producer = Open(*store, "client:a", "sess_test");
  Q4T_CHECK(producer && Submit(*store, producer, Collector()));
  Q4T_CHECK(barrier.Entered());
  const auto start = Clock::now();
  store.reset();
  Q4T_CHECK(Clock::now() - start < 500ms);
  {
    RealtimeTraceStore replacement(f.options);
    Q4T_CHECK(!replacement.Health().running);
    Q4T_CHECK(!replacement.Open("client:b", "sess_other"));
    ObjectStore application(f.application);
    Q4T_CHECK(AppWrite(application).ok());
  }
  barrier.Release();
  Q4T_CHECK(Wait([&] {
    RealtimeTraceStore replacement(f.options);
    return replacement.Health().running;
  }));
  return true;
}

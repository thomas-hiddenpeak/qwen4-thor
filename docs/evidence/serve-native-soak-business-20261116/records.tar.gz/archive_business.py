import json,re,shutil,tarfile
from pathlib import Path
root=Path.cwd();work=root/'.q4t-work/serve-ops-v5-20261116';run=work/'short-01';out=root/'docs/evidence/serve-native-soak-business-20261116'
verified=json.loads((run/'verified.json').read_text());assert verified['status']=='PASS_NATIVE_SHORT_SOAK' and verified['business_requests']==15 and verified['tool_executions']==3
result=json.loads((run/'execution/result.json').read_text());assert result['failure'] is None and result['cleanup_failure'] is None
files=[(p,'short-01/'+str(p.relative_to(run))) for directory in ('execution','capture','lease') for p in (run/directory).rglob('*') if p.is_file() and not p.is_symlink()]
files += [(p,'short-01/'+p.name) for p in run.iterdir() if p.is_file()]
for stem in ('business-01','prepare-package-01','prepare-short-01','check-short-01'):
 for ext in ('json','stdout','stderr'):files.append((work/(stem+'.'+ext),stem+'.'+ext))
for n in ('candidate-01/receipt.json','candidate-01/review.json','prepare_package.py','archive_business.py'):files.append((work/n,n))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for n in ('gateway-policy.json','engine/client-policy.json'):collect(json.loads((work/'candidate-01/bundle'/n).read_text()))
for p,n in files:
 data=p.read_bytes();assert not any(s in data for s in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',data),n
out.mkdir()
with tarfile.open(out/'records.tar.gz','w:gz') as archive:
 for p,n in files:archive.add(p,arcname=n,recursive=False)
for n in ('verified.json','run.json','seal.json'):shutil.copy2(run/n,out/n)
prior=root/'.q4t-work/serve-native-soak-20261116';prior_rows=[json.loads((prior/(n+'.json')).read_text()) for n in ('business-01','business-02')];seconds=json.loads((work/'business-01.json').read_text())['seconds'];queries=[]
for directory in (prior/'short-01',prior/'short-02',run):queries += [json.loads(line) for line in (directory/'capture/nvml-queries.jsonl').read_text().splitlines()]
assert all(v['status']=='OK' for v in queries)
summary=dict(status='ACCEPT_NATIVE_SHORT_SOAK_AND_V5_METRICS',manifest_sha256=verified['package']['manifest_sha256'],engine_binary_sha256='0851dab3568ae05f401156270ccaafb4ffa1eb1871c684de71ae626cf4244fcf',actual_business=verified,successful_run_starts=1,successful_run_chats=16,successful_run_seconds=seconds,total_starts=3,total_chats=28,total_probes=0,total_seconds=seconds+sum(v['seconds'] for v in prior_rows),original_failures_preserved=2,nvml_queries=len(queries),nvml_all_ok=True,all_cleanup_confirmed=True,default_changed=False,day_executed=False,long_stability_accepted=False,secret_scan_matches=0,master_active=True)
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text(f'''# 原生60秒短验与当前运营指标通过

精确新包509c3bcb完成连续60秒/3组业务：15次业务生成加1自检，
JSON、SSE、严格schema、3次真实项目文档读取及实际SHA的SSE续答。
原模型身份保持；每组106项已知运营指标成功解析，槽位和约束worker
排空；原始响应/wire/工具来源/计数/连续监控/密封记录独立复核通过。
整个通过阶段{seconds:.3f}秒、1启动/16Chat/0探测，严格guard COMPLETED，
outer/core停止、端口与租约释放。未改生产默认、其他服务或配额。

含两次驱动/解析失败，累计3启动/28Chat/0探测/{summary['total_seconds']:.3f}秒，
{len(queries)}项NVML查询均OK；原失败不覆盖、不称原连续三轮均通过。
生产包只更新root/engine两处同一Python解析源；所有本机程序、容量、
profile资格和模型不变，原430e7985封包保留。继续可回退发布及合main。

24小时未执行，short不证明长期资源稳定或统一DRAM硬限额；day入口
由用户执行。R07维护交接、R08、协议/媒体/后端及全部master继续。
''')
p=root/'docs/STATUS.md';s=p.read_text();m='## 最近完成的实现和验证\n\n';p.write_text(s.replace(m,m+f'''[原生60秒短验通过](evidence/serve-native-soak-business-20261116/README.md)：
新包509c3bcb，3组/15业务生成加自检，3次真实工具闭环及运营指标排空，
{seconds:.3f}秒，清理与完整证据复核通过。含原两失败累计3启动/28Chat/
{summary['total_seconds']:.3f}秒，{len(queries)}项NVML均OK；继续可回退发布、day交接、合main及全部master。

''',1))
p=root/'docs/log/2026-11-16.md';s=p.read_text();head,rest=s.split('\n\n',1);p.write_text(head+f'''\n\n## 原生连续短验及当前指标真实通过

- 日期：2026-11-16。精确509c3bcb连续60秒/3组/15业务加1自检，3次
  真实文档工具与SHA续答；运营指标、槽位/worker排空及原始wire复核通过。
- 为什么：当前包交接必须由真实原生生命周期和原始记录证明。
- 通过阶段{seconds:.3f}秒；含两失败累计3启动/28Chat/{summary['total_seconds']:.3f}秒，
  {len(queries)}项NVML均OK，全部清理，原失败保留，默认暂保持rev182。
- 下一步：可回退STOPPED发布、day交接及合main，继续所有master任务。
- 证据：[真实短验](../evidence/serve-native-soak-business-20261116/README.md)。

'''+rest)
p=root/'docs/serve-master-goals-v2.json';v=json.loads(p.read_text())
for t in v['tasks']:
 if t['id']=='Q03':t['native_soak_20261116'].update(state='real_short_accepted_delivery_and_handoff_pending',business_evidence='evidence/serve-native-soak-business-20261116/README.md',actual_starts=3,actual_chats=28,actual_gpu_seconds=summary['total_seconds'],day_executed=False)
 if t['id']=='R04':t['metric_v5_compatibility_20261116'].update(state='real_business_accepted_delivery_pending',business_evidence='evidence/serve-native-soak-business-20261116/README.md',manifest_sha256=verified['package']['manifest_sha256'])
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'nvml_queries':len(queries),'total_seconds':summary['total_seconds']}))

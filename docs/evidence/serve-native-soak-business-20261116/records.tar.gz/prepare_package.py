"""Seal exactly the CPU-accepted auxiliary parser; reuse native/model artifacts."""
import copy,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as engine
WORK=Path(__file__).resolve().parent

def replace(path,data,mode=0o400):
 path.chmod(0o600);path.write_bytes(data);path.chmod(mode)

def main():
 os.umask(0o077)
 engine.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit reviewed source')
 original=(ROOT/'build/service').resolve(strict=True);digest=engine.sha(original/'manifest.json')
 manifest=bundle.verify(original,digest);base=engine.verify(original/'engine',manifest['engine_manifest_sha256'])
 allowed={'tools/serve_ops/contracts.py'}
 delta={n for n in bundle.SOURCES if engine.sha(ROOT/n)!=engine.sha(original/'source'/n)}
 engine.require(delta==allowed,'unreviewed sealed runtime delta: '+str(delta))
 engine.require(all(engine.sha(ROOT/n)==h for n,h in engine.read(original/'native-build.json')['source_files'].items()),'native artifacts differ')
 out=WORK/'candidate-01';engine.require(not out.exists(),'preserve original candidate');out.mkdir(mode=0o700)
 target=out/'bundle';shutil.copytree(original,target,symlinks=True)
 updated=copy.deepcopy(manifest);new_base=copy.deepcopy(base)
 for name in allowed:
  relative='source/'+name;data=(ROOT/name).read_bytes()
  replace(target/relative,data);updated['files'][relative]=engine.sha(target/relative)
  engine.require(relative in new_base['files'],'expected engine auxiliary source')
  replace(target/'engine'/relative,data);new_base['files'][relative]=engine.sha(target/'engine'/relative)
 replace(target/'engine/manifest.json',json.dumps(new_base,indent=2).encode()+b'\n')
 updated['engine_manifest_sha256']=engine.sha(target/'engine/manifest.json')
 replace(target/'manifest.json',json.dumps(updated,indent=2).encode()+b'\n')
 new_digest=engine.sha(target/'manifest.json')
 replace(target/'bin/q4t',bundle.launcher(new_digest,updated['python']['path']),0o500)
 engine.require(bundle.verify(target,new_digest)==updated,'sealed successor invalid')
 engine.require(all(updated['files'][n]==manifest['files'][n] for n in manifest['files'] if n!='source/tools/serve_ops/contracts.py'),'other root payload changed')
 engine.require(all(new_base[k]==base[k] for k in base if k!='files') and all(new_base['files'][n]==base['files'][n] for n in base['files'] if n!='source/tools/serve_ops/contracts.py'),'other engine settings/artifacts changed')
 previous=dict(package=str(original),manifest_sha256=digest);current=dict(package=str(target),manifest_sha256=new_digest)
 engine.require(version_contract.compatible(version_contract.payload(current),version_contract.payload(previous))['automatic'],'old package is not a compatible rollback')
 engine.save(out/'receipt.json',current)
 engine.save(out/'review.json',dict(status='CPU_ACCEPTED_SEALED_AUXILIARY_FIX_BUSINESS_PENDING',previous=previous,current=current,changed_sources=sorted(delta),engine_manifest_before=manifest['engine_manifest_sha256'],engine_manifest_after=updated['engine_manifest_sha256'],engine_binary_unchanged=True,native_receipt_unchanged=True,core_client_outer_profile_settings_unchanged=True,default_unchanged=True,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()))
 print(json.dumps(current))
if __name__=='__main__':main()

from pathlib import Path
import json
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';p=R/'tools/native_tts/voice_service_acceptance.py';s=p.read_text()
s=s.replace("'--max-tokens', '64', '--max-inflight-requests', '2',\n            '--max-queued-requests', '1'", "'--max-tokens', '64', '--max-inflight-requests', '4',\n            '--max-queued-requests', '3'")
a='\ndef validate_plan(plan):';b='''
def check_admission(command, policy):
    # Reject contradictory fixtures before any process/model startup.
    inflight = int(command[command.index('--max-inflight-requests')+1])
    queued = int(command[command.index('--max-queued-requests')+1])
    require(not policy['fair_queue'] or
            (queued >= len(policy['clients']) and
             inflight >= sum(c['max_inflight'] for c in policy['clients'])),
            'fair policy exceeds global admission capacity')


def validate_plan(plan):''';assert s.count(a)==1;s=s.replace(a,b)
a="        self.budget('starts')\n        save(self.out/'model-command.json', command)";b="        check_admission(command, policy)\n        self.budget('starts')\n        save(self.out/'model-command.json', command)";assert s.count(a)==1;s=s.replace(a,b)
t=p.with_suffix('.py.edit');t.write_text(s);t.replace(p)
p=R/'tools/native_tts/test_voice_service_acceptance.py';s=p.read_text();a='    def test_request_time_and_frozen_plan_bounds_fail_closed(self):';b='''    def test_fair_policy_cannot_exceed_global_queue_or_inflight(self):
        policy = dict(fair_queue=True, clients=[dict(max_inflight=1)]*3)
        def args(inflight, queued):
            return ['serve', '--max-inflight-requests', str(inflight),
                    '--max-queued-requests', str(queued)]
        subject.check_admission(args(4, 3), policy)
        for inflight, queued in ((2, 3), (4, 1), (2, 1)):
            with self.assertRaises(RuntimeError):
                subject.check_admission(args(inflight, queued), policy)
        policy['clients'][0] = dict(max_inflight=3)
        with self.assertRaises(RuntimeError):
            subject.check_admission(args(4, 3), policy)

    def test_request_time_and_frozen_plan_bounds_fail_closed(self):''';assert s.count(a)==1;s=s.replace(a,b);t=p.with_suffix('.py.edit');t.write_text(s);t.replace(p)
plan={'scope':'Fix three-client HTTP fixture global fair admission, reject before model startup','tests':['tools.native_tts.test_voice_service_acceptance.Contract.test_fair_policy_cannot_exceed_global_queue_or_inflight','client_rate_disabled_restart_authentication_and_fair_capacity'],'seconds':60,'gpu':0,'original_attempt':'voice-http-02','original_retained':True,'http_posts':18,'unchanged_engine_sha256':'100a490bc62fcc879da209d52c7f27e3d8af23da14b5f2011b3db7a752c8a85a'}
(V/'voice-driver-admission-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
update='第二轮HTTP在客户准入配置停止：驱动的3客户公平队列超出其全局2槽/1队列，\n0模型权重加载/0业务POST。修正驱动为4槽/3队列并增加启动前检查，\n冻结1验收器负控+1已有准入合同/60秒；生产候选身份保持，原失败保留。\n'
for name,marker,text in [('docs/STATUS.md','## 正在推进\n\n',update+'\n'),('docs/log/2026-11-18.md','# 2026-11-18 开发日志\n\n','## 2026-11-18：修正真实音色驱动的公平队列容量\n\n'+update+'\n为什么：测试配置必须满足真实多客户准入合同，不放宽生产保护。\n下一步针对检查后继续同一18POST清单，默认保持。\n\n')]:
 p=R/name;t=p.with_name(p.name+'.edit');t.write_text(p.read_text().replace(marker,marker+text,1));t.replace(p)

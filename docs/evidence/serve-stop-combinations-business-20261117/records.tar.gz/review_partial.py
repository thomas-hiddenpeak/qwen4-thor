import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent; P=W/'business-01'
read=lambda n:json.loads((P/n).read_text())
plan=read('plan.json'); result=read('result.json'); log=(P/'candidate-model.log').read_text()
assert result['status']=='FAILED' and result['counts']['starts']==1 and result['counts']['chats']==10
assert read('lease/exit.json')['status']=='COMMAND_FAILED'
cleanup=read('cleanup.json');assert cleanup['remaining']==[] and cleanup['model_exit']==0 and cleanup['ports_released'] and cleanup['lease_continuously_held']
queries=[json.loads(x) for x in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];assert queries and all(x['status']=='OK' for x in queries)
for name,digest in plan['sources'].items():
 p=R/name
 raw=p.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=digest:
  raw=subprocess.check_output(['git','show',plan['source_commit']+':'+name],cwd=R)
 assert hashlib.sha256(raw).hexdigest()==digest,name
values={name:read(name+'.result.json') for name in ('none_json','none_sse','schema_complete','tool_complete','private_write','private_follow','private_uncached')}
for name in ('none_json','none_sse','schema_complete','tool_complete','schema_cut','tool_cut','private_write'):
 assert read(name+'.request.json')==plan['requests'][name]
for name in ('none_json','none_sse'):
 v=values[name];assert v['message']['content'].strip()=='ALPHA' and v['finish_reason']=='stop'
 assert re.search(r'\[text-stop\] request=stop-combo-'+name+r' matched_index=0 ',log)
assert json.loads(values['schema_complete']['message']['content'])=={'answer':'ALPHA'}
for name in ('schema_cut','tool_cut'):assert read(name+'.expected-error.json')['code']=='structured_output_invalid'
tool=values['tool_complete'];calls=tool['message']['tool_calls'];assert tool['finish_reason']=='tool_calls' and len(calls)==1 and calls[0]['function']['name']=='project_document'
execution=read('actual-tool-execution.json');assert json.loads(calls[0]['function']['arguments'])=={'path':execution['path']}
assert hashlib.sha256(execution['content'].encode()).hexdigest()==execution['sha256']==plan['sources'][execution['path']]
first=values['private_write'];boundary=first['usage']['prompt_tokens'];assert boundary>=8192 and first['message']['content']=='ALPHA'
for name in ('private_follow','private_uncached'):
 expected=copy.deepcopy(plan['requests'][name]);expected['messages'] += [first['message'],{'role':'user','content':'Write exactly: BETA END OMEGA'}]
 if name=='private_follow':expected.update(stream=True,stream_options={'include_usage':True})
 assert read(name+'.request.json')==expected
 v=values[name];assert v['finish_reason']=='stop' and v['message']['content']=='BETA'
 assert v['usage'].get('prompt_tokens_details',{}).get('cached_tokens',0)==(boundary if name=='private_follow' else 0)
assert values['private_follow']['message']==values['private_uncached']['message']
for name in ('private_write','private_follow'):
 records=re.findall(r'\[session-cache\] request=stop-combo-'+name+r' event=save prefix=(\d+) ms=\S+ disk_bytes=(\d+) error=(\S+) layout=(\w+) source=(\w+)',log)
 assert len(records)==1 and records[0][2:]==('none','mtp','private_prompt') and int(records[0][0])==values[name]['usage']['prompt_tokens'] and int(records[0][1])>0
assert re.search(r'\[session-cache\] request=stop-combo-private_follow event=restore prefix='+str(boundary)+r' ms=\S+ error=none source=session layout=mtp',log)
stop=re.search(r'\[text-stop\] request=stop-combo-private_write matched_index=0 tokens=(\d+) mtp_steps=(\d+) mtp_tokens=(\d+) mtp_discarded=(\d+)',log)
assert stop and int(stop[1])==first['usage']['completion_tokens'] and int(stop[2])>0 and int(stop[4])>0
assert re.search(r'\[text-stop\] request=stop-combo-private_follow matched_index=-1 ',log)
refusal=read('media_write.result.json');assert refusal['message']['content'] is None and refusal['message']['refusal'] and refusal['finish_reason']=='stop'
metrics=read('media_write-drain.metrics.json')[-1];assert metrics['q4t_requests_total']==10 and metrics['q4t_requests_success_total']==8 and metrics['q4t_requests_error_total']==2
proof=dict(status='ACCEPT_NINE_TEXT_STOP_REQUESTS_ONLY',original_stage_status='FAILED',accepted_external_requests=9,additional_visual_refusal_observed=1,media_positive_business_pending=True,private_prompt_boundary=boundary,private_cached_uncached_equal=True,private_initial_stop_discards_hidden_mtp_tokens=int(stop[4]),private_continuation='EOS after BETA, stop enabled but not matched; no matched-stop claim',same_model_and_cleanup=True,nvml_ok=len(queries),no_new_gpu=True,binary_sha256=result['binary_sha256'],source_commit=plan['source_commit'])
(P/'partial-review.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))

"""Preserve original failed stage and each independently accepted composition."""
import copy
import json
import re
from pathlib import Path
import sys
import tarfile
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-stop-combinations-business-20261117'
require(not O.exists(),'preserve original archive')
feature=read(W/'feature-acceptance.json');qualified=read(W/'profiles-02/acceptance.json')
require(feature['status']=='ACCEPT_STOP_COMBINATIONS_BUSINESS' and qualified['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION','feature/profile acceptance missing')
candidate={k:read(W/'package-01/receipt.json')[k] for k in ['package','manifest_sha256']}
legacy=read(W/'retained-01/review.json')['fallback'];modern=read(W/'modern-retained-01/receipt.json')
for name,descriptor in [('legacy-business-01',legacy),('modern-business-01',modern)]:
 a=read(W/name/'decision.json')
 require(a['acceptance']=='ACCEPT_MEDIA_STATE_SERVICE_RETAINED' and a['manifest_sha256']==descriptor['manifest_sha256'] and a['engine_binary_sha256']==feature['binary_sha256'] and all(a['actual_business']['postflight'].values()),'exact retained payload not accepted')
stages=[];files=[]
for name in ['business-01','media-01','profiles-02','legacy-business-01','modern-business-01']:
 d=W/name;managed=name.startswith(('legacy-','modern-'));out=d/'execution' if managed else d
 result=read(out/'result.json');counts=result['budget']['counts'] if managed else result['counts']
 guard=read(d/'lease/exit.json');queries=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()];events=[json.loads(x) for x in (d/'lease/events.jsonl').read_text().splitlines()]
 acquired=[e for e in events if e.get('event')=='lease_acquired'];released=[e for e in events if e.get('event')=='lease_released']
 require(guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and len(acquired)==len(released)==1,'strict lease absent')
 require(guard['status']==('COMMAND_FAILED' if name=='business-01' else 'COMPLETED'),'guard not accepted')
 require(all(q.get('status')=='OK' and q.get('returncode')==0 for q in queries) and queries,'NVML failure')
 if managed:
  require(result['failure'] is None and result['cleanup_failure'] is None and read(out/'stop.json')['cleanup_confirmed'],'managed cleanup missing')
 else:
  for cp in [out/'cleanup.json',*([out/'primary-cleanup.json'] if name=='profiles-02' else [])]:
   c=read(cp);require(c['remaining']==[] and c['model_exit']==0 and c['ports_released'] and c['lease_continuously_held'],'owned cleanup missing')
 stages.append(dict(stage=name,status=result['status'],counts=counts,guard_status=guard['status'],strict_lease_seconds=released[0]['monotonic']-acquired[0]['monotonic'],nvml_queries=len(queries),guard_sha256=sha(d/'lease/exit.json'),result_sha256=sha(out/'result.json'),whole_run_accepted=name!='business-01'))
 # Never publish credential policies, state directories, or cache/model blobs.
 for folder in (d,d/'lease',*([out] if managed else [])):
  files += [f for f in folder.iterdir() if f.is_file() and not f.is_symlink() and f.name not in ('client-policy.json','gateway-policy.json')]
 if name=='profiles-02':files+=list((d/'qualified').glob('*.json'))
starts=sum(x['counts']['starts'] for x in stages);requests=sum(x['counts']['chats'] for x in stages);seconds=sum(x['strict_lease_seconds'] for x in stages)
require(starts==6 and requests==27 and seconds<1200,'frozen total exceeded')
for f in W.iterdir():
 if f.is_file() and (f.suffix=='.py' or f.suffix in ('.json','.stdout','.stderr') and not f.name.startswith(('pr38-','cpp-','migration-','schema-','python-client-','js-client-','build-','source-check-','generated-check-'))):files.append(f)
for name in ['package-01/prepare-review.json','package-01/decision.json','retained-01/review.json','modern-retained-01/review.json']:files.append(W/name)
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for name in ['build/service/gateway-policy.json','build/service/engine/client-policy.json']:collect(read(R/name))
files=sorted(set(files))
for f in files:
 raw=f.read_bytes();require(not any(s in raw for s in secrets),'credential leaked: '+str(f));require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),'private key leaked')
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(W)),recursive=False)
a=dict(status='ACCEPT_STOP_COMBINATIONS_BUSINESS',binary_sha256=feature['binary_sha256'],engine_binary_sha256=feature['binary_sha256'],candidate=candidate,automatic_fallback=legacy,manual_root=modern,cleanup_complete=True,nvml_all_ok=True,nvml_queries=sum(x['nvml_queries'] for x in stages),total_starts=starts,total_external_requests=requests,accepted_feature_requests=12,strict_lease_seconds=seconds,stages=stages,original_failures_preserved=True,original_stage_status='FAILED',original_valid_visual_refusal_not_positive_acceptance=True,private_continuation_stop_matched=False,feature_review=feature,profile_qualification=qualified,modern_service_acceptance=read(W/'modern-business-01/decision.json'),candidate_control_reuse=dict(changed_sources=['tools/serve_recovery/profile_migration.py'],live_controller_and_native_helpers_unchanged=True,client_change='Python request builder admits stop/session, verified directly; response readers unchanged',cpu_migration_cases=4,explicit_capability_upgrade=True,whole_candidate_package_gpu_run=False,stopped_migration_pending=True),default_unchanged=True,publication_pending=True,full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a);save(W/'publication-composition.json',a)
(O/'README.md').write_text(f'''# Stop、约束输出和状态缓存业务接受

可见JSON/必需工具完整时成功，截断时返回明确错误、无成功终态，同一
模型继续服务。MTP首个停止请求只保存13361-token prompt，实际丢弃
1个隐藏推测token；续问恢复精确边界，与无缓存文本一致。续问实际
BETA后EOS、stop未命中，不把它宣称第二次命中。实际图片内容查询
的schema、完整prompt SSD恢复及冷/热文本与logprobs一致通过。

主轻真实工具/结构化/媒体/embedding、旧及现代保留控制包Stop+schema
媒体SSE/存储/客户端隔离通过。累计{starts}启动{requests}请求，含两次保留
包自检，严格租约{seconds:.3f}秒；{a['nvml_queries']}项NVML正常，所有自有
进程、端口、租约清理。没有完整性能或模型质量矩阵。

首轮视觉题要求无关固定字符串，模型返回合法拒绝，驱动解析null失败；
原run仍FAILED，前9条依据原件独立接受，仅补媒体3条，不重复文本。
新的图片任务保留schema/stop/缓存与概率比较，不能追认原视觉题通过。
引擎核心数值代码未改。发行只额外更新显式能力迁移和Python构造器，
CPU证据及实际STOPPED升级/回退将补齐；默认214保持，全部master继续。
''')
# Preserve the exact original driver source, independently of its later repair.
old_source=__import__('subprocess').check_output(['git','show',feature['text_review']['source_commit']+':tools/serve_protocol/stop_combinations_acceptance.py'],cwd=R)
(O/'original-driver.py.txt').write_bytes(old_source)
print(json.dumps({k:a[k] for k in ['status','total_starts','total_external_requests','strict_lease_seconds','nvml_queries','archive_sha256']}))

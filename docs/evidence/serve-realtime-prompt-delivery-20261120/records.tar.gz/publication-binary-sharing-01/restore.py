from pathlib import Path
import json,os
out=Path(__file__).resolve().parent
for row in json.loads((out/'plan.json').read_text())['items']:
 p=Path(row['shared'])
 if p.stat().st_nlink>1:
  raw=p.read_bytes();mode=p.stat().st_mode&0o777;temp=p.with_name('q4t.restore-new')
  with temp.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  temp.chmod(mode);os.utime(temp,ns=(row['atime_ns'],row['mtime_ns']));os.replace(temp,p)

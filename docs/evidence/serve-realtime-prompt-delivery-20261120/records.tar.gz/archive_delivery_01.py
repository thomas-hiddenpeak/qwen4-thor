"""Archive actual STOPPED Prompt delivery; keep every original failed run."""
from pathlib import Path
import hashlib
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = W / 'delivery-01'
O = ROOT / 'docs/evidence/serve-realtime-prompt-delivery-20261120'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def write(path, value):
    if path.exists() and path.stat().st_nlink > 1:
        mode = path.stat().st_mode & 0o777
        path.unlink()
        path.write_text(value)
        path.chmod(mode)
    else:
        path.write_text(value)


result = read(D / 'result.json')
composition = read(W / 'publication-composition.json')
current = result['publication']['current']
release = read(ROOT / 'build/service.release.json')
assert result['status'] == 'PASS_NATIVE_REALTIME_PROMPT_DELIVERED'
assert result['publication']['revision'] == 366
assert result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0
assert len(result['commands']) == 19
assert all(command['returncode'] == 0 for command in result['commands'])
assert result['outer']['enabled'] and result['outer']['charged_total'] == 0
assert current['manifest_sha256'] == composition['candidate']['manifest_sha256']
assert sha(ROOT / 'build/q4t') == current['engine_binary_sha256']
assert sha(ROOT / 'build/service.release.json') == current['service_release_sha256']
for name, digest in result['preserved'].items():
    assert sha(ROOT / 'build/service-native-state' / name) == digest, name
assert release['native_realtime_prompt_targeted_accepted']
assert release['native_realtime_prompt_recovery_accepted']
assert release['native_semantic_vad_targeted_accepted']
assert release['native_reference_icl_targeted_accepted']
assert not release['voice_listening_and_similarity_accepted']
assert release['voice_listening_deferred']
clients = read(ROOT / 'build/service-native-state/client-limits/policy.json')['state']['policy']['clients']
limits = {c['id']: {k: c[k] for k in ('requests_per_minute', 'tokens_per_minute', 'max_output_tokens')} for c in clients}
assert limits == {
    'alpha': dict(requests_per_minute=30, tokens_per_minute=6000, max_output_tokens=3457),
    'beta': dict(requests_per_minute=1, tokens_per_minute=6000, max_output_tokens=256),
}
maintenance = read(W / 'retired-intents-02/result.json')
assert maintenance['status'] == 'PASS' and maintenance['protected_unchanged']
assert maintenance['deleted_files'] == 0
files = {}
for directory in ('delivery-01', 'retired-intents-01', 'retired-intents-02',
                  'publication-binary-sharing-01', 'publication-binary-sharing-02',
                  'publication-binary-sharing-03'):
    for path in (W / directory).iterdir():
        if path.is_file() and not path.is_symlink():
            files[str(path.relative_to(W))] = path
for path in (W / 'retired-intents-02').glob('batch-*/*.json'):
    files[str(path.relative_to(W))] = path
for name in ('deliver_prompt_01.py', 'archive_delivery_01.py', 'publication-composition.json'):
    files[name] = W / name
secrets = []


def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'gateway_token', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)


for path in (ROOT / 'build/service/gateway-policy.json',
             ROOT / 'build/service/engine/client-policy.json'):
    collect(read(path))
for name, path in files.items():
    raw = path.read_bytes()
    assert not any(secret in raw for secret in secrets), name
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----\s+[A-Za-z0-9+/=]{10,}', raw), name
assert not O.exists()
O.mkdir()
index = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
save(O / 'index.json', index)
with tarfile.open(O / 'records.tar.gz', 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(O / 'records.tar.gz', 'r:gz') as archive:
    seen = set()
    for member in archive:
        assert member.isfile() and member.name in index and member.name not in seen
        raw = archive.extractfile(member).read()
        assert len(raw) == index[member.name]['bytes']
        assert hashlib.sha256(raw).hexdigest() == index[member.name]['sha256']
        seen.add(member.name)
    assert seen == index.keys()
acceptance = dict(
    status='ACCEPT_NATIVE_REALTIME_PROMPT_DELIVERY', revision=366,
    current=current, state='STOPPED', successful_commands=19, command_attempts=19,
    seconds=result['seconds'], new_gpu_starts=0, outer_enabled=True,
    outer_charged_total=0, persistent_client_limits=limits, usage_reset=False,
    profile_history_and_cooldown_preserved=True, version_cycles_preserved=True,
    manual_root=composition['modern_retained_root']['manifest_sha256'],
    automatic_payload=composition['automatic_fallback']['manifest_sha256'],
    candidate_to_retained_automatic_fault_actually_tested=True,
    reciprocal_automatic_fault_additionally_injected=False,
    reciprocal_registration_and_stopped_rollback_verified=True,
    older_engine_fallback=False, previous_rev356_preserved=True,
    retired_intents_archived=4, deleted_files=0,
    maintenance_seconds=maintenance['seconds'],
    original_tls_driver_passed=False, original_driver_failure_preserved=True,
    original_model_quality_failures_preserved=True, files=len(files),
    secret_scan_matches=0, archive_sha256=sha(O / 'records.tar.gz'),
    main_integration_pending=True, full_model_quality=False,
    performance_claim=False, long_stability_run=False,
    full_openai_compatibility=False, listening_deferred_by_owner=True,
    all_master_tasks_active=True)
save(O / 'acceptance.json', acceptance)
(O / 'README.md').write_text(f'''# 原生 Realtime Prompt 可回退交付 rev366

默认引擎 `{current['engine_binary_sha256']}`，服务包
`{current['manifest_sha256']}`。19项 STOPPED 命令全部通过，
{result['seconds']:.3f}秒、0新增GPU。实际完成能力迁移、双向回退登记、
候选→保留根→候选的发布与回退；最终rev366 STOPPED，outer启用但
累计启动0，前驱rev356程序、发布元数据和状态快照保留。

Realtime会话现在实际解析已注册Prompt，保留固定版本和不可变快照，
执行模板默认值、显式覆盖、文件前缀、CSV准备及真实工具回填；与
会话历史共同计入上下文和RPM/TPM，跨客户隔离、取消及结算已验。
拒答说明改为中性输出格式要求，保留真实拒答、schema和流式合同。

[主轻来源复核](../serve-refusal-reviewed-profiles-20261120/README.md)
绑定实际成功输出及旧独立后端身份；[原生恢复](../serve-prompt-native-recovery-20261120/README.md)
包括保留包、网关中断、强杀控制器后完整配额窗口、整包自动回退。
四个原始组（含原失败组）共7模型/22生成/7WSS/1探测，402.001秒、
377次NVML正常且清理完成，七组实际工具答案均为当时版本rev356。
反向已完成登记和STOPPED回退，未另注入反向自动故障。

alpha RPM30/beta RPM1、两端TPM6000、alpha输出3457、实际用量账本、
profile历史/冷却和outer预算保持。包内不可变初始策略与原包相同；
不会用验收夹具TPM60000替换实际部署中的TPM6000。新能力是显式
配置迁移，自动回退必须保留Prompt，不能悄悄降回不具备该能力的包。

原TLS驱动误用正常交接快照的TypeError仍为FAIL；其已完成网关段
单独复核，控制器缺项由专组补验。原随机错误答案、格式失败、冷态
语义评分过期和数值/声纹失败均保留，不改默认采样或追认原错误。
用户延期听感仍待验。独立ASR/语音/embedding后端复用原身份证据，
没有冒称本阶段重新执行全矩阵。

为发行空间共享相同字节的只读旧程序（142220224字节），保留所有
原路径、SHA及分离恢复脚本；私有策略不共享。GPU租约持有时第一次
意图维护被正确拒绝，释放后4条退休意图可逆归档，0删除、5.029秒。
这些原记录均存于归档；私有状态/密钥不进入公共证据。

PR #53最终检查和实际合入另记。Realtime音频输出、MCP、追踪、Live
与其余master任务继续；不宣称完整OpenAI兼容、全模型质量、性能或
长稳通过。
''')
intro = f'''[rev366原生Realtime Prompt已交付](evidence/serve-realtime-prompt-delivery-20261120/README.md)：
19项STOPPED命令/{result['seconds']:.3f}秒，真实回退再前进，0新增GPU。
默认648d6d68、服务包7be0a6a5；配额/用量/历史/恢复预算保持，前驱
rev356保留。实际Prompt恢复与主轻资格已验，原质量与驱动FAIL不改写。
PR #53待最终检查合入；继续音频/MCP/追踪/Live及全部master。

以下阶段记录保留各自时点事实；当前默认以本段和默认身份表为准。

'''
path = ROOT / 'docs/STATUS.md'
status = path.read_text()
rows = {
    '发布': 'rev366；服务包 `' + current['manifest_sha256'] + '`',
    'Generation': '`' + current['generation_sha256'] + '`',
    '引擎': '`' + current['engine_binary_sha256'] + '`',
    '引擎发布记录': '`' + current['engine_release_sha256'] + '`',
    'Guardian': '`' + release['guardian_sha256'] + '`',
    '原生入口': '`' + release['ingress_sha256'] + '`',
    '默认容量': '单流、ctx8192、prefill2048、主文本输出256、MTP k=3；inflight8/queue3；TTS 200帧、alpha输出3457/RPM30/TPM6000；参考ICL、Realtime转录/语义VAD/文本/函数工具/持久Prompt',
    '人工整包回退': '保留控制根 `' + acceptance['manual_root'] + '`；同已验Prompt引擎、参考和周期保持；前驱rev356另保留',
    '自动payload回退': '候选→保留控制包 `' + acceptance['automatic_payload'] + '` 实际恢复已验；反向登记与STOPPED回退已验，未另注入反向故障；不是旧引擎回退',
}
for name, value in rows.items():
    status, count = re.subn(r'^\| ' + re.escape(name) + r' \| .* \|$', lambda _: f'| {name} | {value} |', status, count=1, flags=re.M)
    assert count == 1, name
write(path, status.replace('## 正在推进\n\n', '## 正在推进\n\n' + intro, 1))
path = ROOT / 'docs/log/2026-11-20.md'
head, body = path.read_text().split('\n', 1)
write(path, head + '\n\n## Realtime Prompt rev366可回退交付\n\n日期：2026-11-20。\n\n做了什么：' + intro.split('以下阶段记录')[0].replace('(evidence/', '(../evidence/') + '为什么：已验能力须进入默认服务和同能力回退根，同时保持客户实际配额、用量和恢复预算；不能仅关闭PR或记录限制。\n\n下一步：PR #53最终检查合入，继续音频/MCP/追踪/Live及全部总计划，保留原失败和延期听感。\n' + body)
path = ROOT / 'README.md'
old = '语音输出及assistant音频历史已交付；当前rev356包含Realtime手动/\n自动转录、语义VAD和文本/函数工具对话，支持原生WebSocket/TLS、\n工具回填、逐轮配额与取消结算，已完成[实际恢复和可回退交付](docs/evidence/serve-realtime-chat-delivery-20261120/README.md)。\n原TLS随机回答的模型质量失败单独保留，默认采样未改。Realtime\nPrompt、音频输出、MCP、追踪及Live继续按总计划实现。'
new = '语音输出及assistant音频历史已交付；当前rev366包含Realtime手动/\n自动转录、语义VAD、文本/函数工具对话及持久Prompt。支持原生\nWebSocket/TLS、固定模板快照、文件前缀、工具回填、逐轮配额及取消\n结算，已完成[实际恢复和可回退交付](docs/evidence/serve-realtime-prompt-delivery-20261120/README.md)。\n原错误答案和失败记录单独保留，默认采样未改。Realtime音频输出、\nMCP、追踪及Live继续按总计划实现。'
source = path.read_text()
assert old in source
write(path, source.replace(old, new, 1))
path = ROOT / 'docs/SERVE_REALTIME_PROMPT_2026-11-20.md'
source = path.read_text().replace('说明代替。本文是实施方案，尚未表示 Prompt 对话可用。', '说明代替。当前文字、工具及文件Prompt已交付rev366；本文保留\n分阶段记录，现状以本节交付结果为准。', 1)
summary = '''## 当前交付

[rev366可回退交付](evidence/serve-realtime-prompt-delivery-20261120/README.md)
已完成实际模板解析、固定快照、会话/单轮覆盖、文件与CSV准备、共享
配额、取消及真实工具闭环。19项STOPPED检查包含整根回退再前进；
默认和回退均保留Prompt能力，实际客户策略与用量、恢复预算不变。
原生TLS网关、强杀控制器及整包回退后均有实际Prompt业务。

主轻资格以完整来源绑定复用不变后端，并复核新执行的受影响消费者。
真实拒答格式说明的干扰已修复，默认采样保持；原错误答案、精确格式
失败、冷态语义评分过期及首轮TLS驱动失败仍保留，成功补验不追认
旧失败。v22封包包含显式来源复核，v1～v21历史合同保持。

音频输出、MCP、追踪、Live继续实现；本交付不是整个Realtime API、
完整OpenAI兼容、全模型质量或长稳验收。PR #53合入状态另记。

'''
source = source.replace('## 当前实现进度\n', summary + '## 分阶段实现记录\n', 1)
source = source.replace('## 本次主轻资格的针对性范围', '## 最初主轻计划与来源边界（历史）', 1)
write(path, source)
path = ROOT / 'docs/serve-master-goals-v2.json'
goals = read(path)
entry = acceptance | dict(evidence='evidence/serve-realtime-prompt-delivery-20261120/README.md')
goals['native_realtime_prompt_delivery_20261120'] = entry
goals['native_realtime_prompt_recovery_20261120'] = dict(evidence='evidence/serve-prompt-native-recovery-20261120/README.md', status=composition['status'], model_starts=7, counted_generations=22, websocket_sessions=7, seconds=composition['service_seconds'], nvml_queries=377, original_tls_driver_passed=False)
goals['native_realtime_prompt_primary_light_20261120'] = dict(evidence='evidence/serve-refusal-reviewed-profiles-20261120/README.md', registry_sha256='489e6fb65146c24df5cc96e904e67d9777f0d47596716ea91259ec1bf64a78b1', original_failures_preserved=True)
goals['realtime_progress'].update(state='native_transcription_semantic_vad_text_tools_prompts_delivered_rev366_audio_mcp_tracing_live_pending', prompt_delivered=True, prompt_delivery=entry, full_realtime_api_qualified=False, next='Implement native Realtime audio output, MCP, tracing and Live, then every remaining master task; preserve original failures and owner-deferred listening.')
goals['native_tts_progress']['managed']['latest_service_revision'] = 366
for task in goals['tasks']:
    if task['id'] in ('A01', 'A10', 'A12', 'R05', 'R06', 'Q01', 'Q02'):
        task['native_realtime_prompt_delivery_20261120'] = dict(revision=366, evidence=entry['evidence'])
    if task['id'] == 'A10':
        task['next'] = 'Implement native Realtime audio output, MCP/tracing and Live; remaining multimodal format/backends and actual acceptance continue. ICL floating-boundary decision is accepted with original numeric failures preserved; listening remains owner-deferred.'
    if task['id'] == 'Q02':
        task.update(state='rev366_delivered_pr53_final_checks_pending_remaining_master_active', latest_release=entry, remaining_required=['Realtime Prompt final-head CI and actual main merge', 'Delivery of every remaining implementation'])
    if task['id'] == 'R07':
        task['current_execution_prerequisite'] = 'Refresh exact cold qualification against rev366 or then-current default; pending host/camera maintenance handoff remains required.'
goals['next_task'] = 'Realtime Prompt final-head CI/main integration; implement native Realtime audio output, MCP/tracing/Live and every remaining A/N/R/Q task. Preserve original failures and owner-deferred listening.'
write(path, json.dumps(goals, ensure_ascii=False, indent=2) + '\n')
path = ROOT / 'docs/README.md'
write(path, path.read_text() + '''
- [Prompt受影响消费者主轻复核](evidence/serve-refusal-reviewed-profiles-20261120/README.md)：确切新输出、原后端来源与全部失败保留。
- [Prompt原生恢复](evidence/serve-prompt-native-recovery-20261120/README.md)：持久模板/工具、网关中断、冷控制器与整包回退。
- [rev366原生Realtime Prompt交付](evidence/serve-realtime-prompt-delivery-20261120/README.md)：19项STOPPED检查、可回退默认与实际客户预算保持。
''')
print(json.dumps({key: acceptance[key] for key in ('status', 'revision', 'seconds', 'files')}))

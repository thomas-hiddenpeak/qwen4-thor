"""Only extend alpha output capacity, keeping durable rate/usage/recovery budgets."""
import copy,json,os,subprocess,time,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'delivery-quota-01';S=R/'build/service-native-state'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service import package as p
from tools.serve_recovery import quota_policy,publication
os.umask(0o077);p.require(not O.exists(),'preserve quota evidence');O.mkdir(mode=0o700)
before=p.read(S/'client-limits/policy.json')['state']['policy'];current=publication.status(S)
p.require(current['revision']==316 and current['ready'],'publication predecessor changed')
p.require(p.read(S/'ledger.json')['state']['desired']=='STOPPED','default must remain stopped')
p.require(before['revision']==1 and [c['id'] for c in before['clients']]==['alpha','beta'] and before['clients'][0]['max_output_tokens']==2817,'quota predecessor changed')
candidate=copy.deepcopy(before);candidate['revision']=2;candidate['clients'][0]['max_output_tokens']=3457
quota_policy.transition(before,candidate)
p.save(O/'original-policy.json',before);p.save(O/'desired-policy.json',dict(version=1,clients=candidate['clients']))
def protected():
 return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection','version-selection'))) and not f.relative_to(S).parts[0].startswith('client-limits')}
original=protected();rows=[];start=time.monotonic()
try:
 for label,args in [('propose',['limits-propose','--limits',O/'desired-policy.json','--proposal',O/'proposal.json']),('apply',['limits-apply','--proposal',O/'proposal.json','--wait-seconds','0'])]:
  argv=list(map(str,[R/'build/q4t','service',*args,'--state',S]));r=subprocess.run(argv,capture_output=True,text=True,timeout=30)
  (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
  rows.append(dict(label=label,argv=argv,returncode=r.returncode))
  p.require(r.returncode==0,'quota command failed: '+label)
  p.require(protected()==original and publication.status(S)==current,'unrelated usage/recovery/publication changed')
 p.require(p.read(S/'client-limits/policy.json')['state']['policy']==candidate,'quota not durable')
 p.save(O/'result.json',dict(status='PASS_EXPLICIT_OUTPUT_BUDGET_MIGRATION',seconds=time.monotonic()-start,commands=rows,previous=before,candidate=candidate,preserved_except_limits=original,usage_reset=False,rpm_tpm_unchanged=True,new_gpu_starts=0,publication_unchanged=True))
 print(json.dumps(dict(status='PASS_EXPLICIT_OUTPUT_BUDGET_MIGRATION',commands=2,revision=2,rpm_tpm_unchanged=True)))
except BaseException as error:
 p.save(O/'result.json',dict(status='FAILED',error=repr(error),commands=rows));raise

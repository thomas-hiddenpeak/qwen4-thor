from pathlib import Path
import re
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';s=(R/'.q4t-work/serve-native-tts-20261118/deliver.py').read_text()
s=s.replace('STOPPED native audio auxiliary delivery with modern root rollback and preserved budgets.', 'STOPPED registered voice delivery with accepted reciprocal controls and preserved budgets.')
s=s.replace("OLD='3c136a5884f87dde06cdd10b8bbc286717361e6bdf397aff4c5f3a37941c06f4'", "OLD='e992bae3e6a090c595605ff1fbb4c122c96838510bef1f3f6ec6f3c7b4fd111d'")
s=s.replace('modern-retained-01','retained-01').replace('modern-service-01','retained-service-02').replace('retained-service-01','retained-service-02')
s=s.replace('ACCEPT_NATIVE_TTS_INPUT_SERVICE_COMPOSITION','ACCEPT_NATIVE_REGISTERED_VOICE_SERVICE_COMPOSITION')
old="registrations={n:version_contract.prepare(root,root,legacy,str(uuid.uuid4()),fallback_acceptance=legacy_receipt) for n,root in roots.items()}"
new="candidate_acceptance=receipt(W/'version-review-01')\n version_contract.accepted_fallback(candidate_acceptance,version_contract.payload(roots['candidate']))\n fallback_by_root=dict(candidate=roots['retained'],retained=roots['candidate'])\n accepted_by_root=dict(candidate=legacy_receipt,retained=candidate_acceptance)\n registrations={n:version_contract.prepare(root,root,fallback_by_root[n],str(uuid.uuid4()),fallback_acceptance=accepted_by_root[n]) for n,root in roots.items()}"
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('automatic_payload_fallback=legacy,manual_modern_root_fallback','automatic_payload_fallback_by_root=fallback_by_root,manual_modern_root_fallback')
s=s.replace("W/'managed-profiles-04/acceptance.json'","W/'voice-profiles-02/acceptance.json'")
s=s.replace('NATIVE_TTS_INPUT_','NATIVE_REGISTERED_VOICE_')
scope=('Native registered Consent/Voice ownership and revocation; actual Base Speech/Chat and independent unhinted ASR, stored complete audio and same IDs across native gateway and whole-payload recovery. Exact primary/light v11 checkpoint-sampled builtin output, input auxiliaries and lazy family reload remain qualified. Version run executed all24 requests, then failed an overstrict registration-encoder loaded-state assertion; original FAILED/COMMAND_FAILED retained,15CPU and separate complete offline review accepted without further GPU. Candidate-to-retained automatic recovery was actually executed. Both distinct accepted control roots share C05; stopped reverse root rollback preserves cycles and budgets. Retained root registers the accepted candidate as its distinct fallback, without claiming an additional actual reverse automatic fault injection. Persistent TPM/RPM remain unchanged; only alpha output allowance extends to3457. Base-only, reference-audio ICL, prompt voices, Live/Realtime, listening/similarity and all remaining master tasks continue. No full-quality/performance/long-stability claim.')
start=s.index("scope='Native Speech and Chat audio output/history")
end=s.index("long-stability claim.'",start)+len("long-stability claim.'")
s=s[:start]+'scope='+repr(scope)+s[end:]
needle="  if name=='retained':release.pop('rollback_receipt',None);release.pop('rollback_sha256',None)"
assert needle in s
s=s.replace(needle,"  release.update(native_registered_voice_targeted_accepted=True,native_tts_base_model=manifests[name]['recovery_profiles']['identity']['native_tts_base'],native_tts_base_configuration=p.read(package/'engine/manifest.json')['settings']['native_tts_base'],native_registered_voice_service_business_evidence=decision['original_decision']['path'],voice_listening_and_similarity_accepted=False,original_version_driver_passed=False,version_record_review_accepted=True)\n"+needle)
revisions={306:316,308:318,310:320,312:322,314:324,316:326}
s=re.sub(r'\b(306|308|310|312|314|316)\b',lambda m:str(revisions[int(m.group())]),s)
compile(s,'deliver_voices.py','exec')
(V/'deliver_voices.py').write_text(s)
print('Prepared stopped publication driver, runtime execution still gated by actual receipts')

"""Archive the completed stopped voice publication without replaying it."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

R = Path(__file__).resolve().parents[2]
V = Path(__file__).resolve().parent
D = V / 'delivery-01'
O = R / 'docs/evidence/serve-voice-delivery-20261119'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def put(path, text):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(text)
    temporary.replace(path)


result = read(D / 'result.json')
composition = read(V / 'publication-composition.json')
quota = read(V / 'delivery-quota-01/result.json')
capacity = read(V / 'capacity-01/result.json')
ci = read(V / 'ci-wiring-01.json')
current = result['publication']['current']
assert result['status'] == 'PASS_NATIVE_REGISTERED_VOICE_DELIVERED'
assert result['publication']['revision'] == 326
assert result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0
assert len(result['commands']) == 19
assert all(command['returncode'] == 0 for command in result['commands'])
assert result['outer']['enabled'] and result['outer']['charged_total'] == 0
assert current['manifest_sha256'] == composition['candidate']['manifest_sha256']
assert sha(R / 'build/q4t') == current['engine_binary_sha256']
assert sha(R / 'build/service.release.json') == current['service_release_sha256']
release = read((R / 'build/service.release.json').resolve(strict=True))
for name, digest in result['preserved'].items():
    assert sha(R / 'build/service-native-state' / name) == digest, name
assert quota['status'] == 'PASS_EXPLICIT_OUTPUT_BUDGET_MIGRATION'
assert quota['rpm_tpm_unchanged'] and not quota['usage_reset']
assert capacity['status'] == 'PASS_DELIVERY_CAPACITY_RESERVED'
assert capacity['deleted_files'] == 0 and capacity['default_unchanged']
assert capacity['recovery_budget_unchanged']
assert ci['count'] == 47 and ci['executed'] == 0
assert ci['workflow_sha256'] == sha(R / '.github/workflows/host-checks.yml')

files = {}
for directory in (D, V / 'capacity-01', V / 'delivery-quota-01'):
    for path in directory.iterdir():
        if path.is_file() and not path.is_symlink():
            files[str(path.relative_to(V))] = path
for path in (V / 'capacity-01').glob('*-archive/*.json'):
    files[str(path.relative_to(V))] = path
for name in (
    'archive_delivery.py', 'deliver_voices.py', 'prepare_delivery_driver.py',
    'reserve_delivery_capacity.py', 'extend_voice_output_budget.py',
    'maintenance-before.json', 'publication-composition.json',
    'ci-wiring-01.json',
):
    files[name] = V / name

secrets = []


def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'gateway_token', 'shared_secret',
                       'private_key', 'token') and isinstance(item, str):
                if len(item) >= 24:
                    secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)


for path in (R / 'build/service/gateway-policy.json',
             R / 'build/service/engine/client-policy.json'):
    collect(read(path))
for name, path in files.items():
    raw = path.read_bytes()
    assert not any(secret in raw for secret in secrets), name
    assert b'-----BEGIN ' + b'PRIVATE KEY-----\n' not in raw, name
assert not O.exists()
O.mkdir()
index = {name: dict(bytes=path.stat().st_size, sha256=sha(path))
         for name, path in files.items()}
(O / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
with tarfile.open(O / 'records.tar.gz', 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)

acceptance = dict(
    status='ACCEPT_NATIVE_REGISTERED_VOICE_DELIVERY', revision=326,
    current=current, state='STOPPED', commands=19, seconds=result['seconds'],
    new_gpu_starts=0, outer_enabled=True, outer_charged_total=0,
    client_output_extension=dict(client='alpha', previous=2817, current=3457,
                                 previous_policy_revision=1, policy_revision=2),
    persistent_rpm=30, persistent_tpm=6000, usage_reset=False,
    immutable_acceptance_fixture_tpm=60000,
    fixture_tpm_not_installed_to_existing_state=True,
    manual_root=composition['modern_retained_root']['manifest_sha256'],
    automatic_payload=composition['automatic_fallback']['manifest_sha256'],
    candidate_to_retained_automatic_fault_actually_tested=True,
    reciprocal_automatic_fault_additionally_injected=False,
    reciprocal_registration_and_stopped_rollback_verified=True,
    older_engine_fallback=False, previous_rev316_preserved=True,
    original_version_driver_passed=False, separate_full_record_review_accepted=True,
    original_failures_preserved=True, profile_history_and_cooldown_preserved=True,
    retired_intents_archived=5, retired_generations_archived=2,
    retired_versions_archived=2, deleted_files=0,
    maintenance_seconds=capacity['seconds'], quota_seconds=quota['seconds'],
    ci_contracts_discovered=47, ci_local_reexecutions=0,
    files=len(files), secret_scan_matches=0,
    archive_sha256=sha(O / 'records.tar.gz'), main_integration_pending=True,
    full_model_quality=False, performance_claim=False, long_stability_run=False,
    full_openai_compatibility=False, listening_and_similarity_accepted=False,
    all_master_tasks_active=True,
)
(O / 'acceptance.json').write_text(json.dumps(acceptance, indent=2) + '\n')
(O / 'README.md').write_text(f'''# 注册音色可回退交付 rev326

默认引擎 `{current['engine_binary_sha256']}`，服务包
`{current['manifest_sha256']}`。19项STOPPED发布、实际整根回退和再次
前进全部通过，{result['seconds']:.3f}秒，0新增GPU；服务保持STOPPED，
outer启用且累计启动0。前驱rev316及其证据、恢复入口保留。

已注册音色的授权、同客户所有权、Speech/Chat合成、完整音频历史与
撤销进入默认。复用精确C05身份的[主轻资格](../serve-voice-primary-light-20261119/README.md)、
[官方SDK/TLS](../serve-voice-sdk-tls-20261119/README.md)及
[实际恢复](../serve-voice-managed-recovery-20261119/README.md)。后者实际
4启动/63业务POST/1探测，原末组懒加载断言失败原样保留，15项CPU
与单独完整记录复核接受；没有把原FAILED改成通过。

正式limits-propose/apply将alpha输出上限2817→3457，策略revision
1→2。原RPM30、TPM6000及已用额度不变，beta不变；不可变验收包
中的TPM60000是私有短验配置，没有覆盖已有部署的持久限额。恢复
history、pending、selected、冷却和启动预算保持。5旧intent、2旧
generation、2旧registration通过正式维护API可恢复归档，0删除。

人工整根与候选自动payload回退均为 `{acceptance['manual_root']}`，
同C05引擎、保留控制器。候选→保留包自动故障恢复实际验证；反向
已完成资格回执登记和STOPPED根回退，没有另注入反向自动故障。
这不是独立旧引擎回退。47项音色/恢复CPU合同接入CI，本地仅校验
名称加载，复用先前未变的执行证据，CI结果另记。

Base-only已有音色消费资格、参考音频ICL、提示词音色、Live/Realtime、
正常播放听感和音色相似度及全部master剩余项继续。未宣称完整
OpenAI兼容、全模型质量、性能或长稳通过；下一步完成主线检查合入。
''')

intro = f'''[rev326注册音色可回退交付](evidence/serve-voice-delivery-20261119/README.md)
完成：19项STOPPED检查/{result['seconds']:.3f}秒，实际整根回退再前进，
0新增GPU。原用量/恢复历史/预算保持；alpha输出2817→3457，RPM30/
TPM6000不变。47项音色恢复CPU合同接入CI。接着主线合入、Base-only
消费资格、ICL/提示词音色/Live及全部master；听感仍待用户验证。

'''
path = R / 'docs/STATUS.md'
text = path.read_text()
rows = {
    '发布': 'rev326；服务包 `' + current['manifest_sha256'] + '`',
    'Generation': '`' + current['generation_sha256'] + '`',
    '引擎': '`' + current['engine_binary_sha256'] + '`',
    '引擎发布记录': '`' + current['engine_release_sha256'] + '`',
    'Guardian': '`' + release['guardian_sha256'] + '`',
    '原生入口': '`' + release['ingress_sha256'] + '`',
    '默认容量': '单流、ctx8192、prefill2048、主文本输出256、MTP k=3；inflight8/queue3；TTS 200帧、alpha合计输出3457/RPM30/TPM6000；媒体已启用',
    '人工整包回退': '保留控制根 `' + acceptance['manual_root'] + '`；同C05/实际输入和音色/原周期已验，前驱rev316另保留',
    '自动payload回退': '候选→保留控制包 `' + acceptance['automatic_payload'] + '` 实际故障恢复已验；反向登记和STOPPED回退已验，未另注入反向故障；不是旧引擎回退',
    '外部依赖': '原生入口/自监护不要求nginx/systemd；ASR/对齐/VAD/speaker/分离/内置及Base TTS按部署启用，注册校验依赖ASR/VAD/speaker，健康核心业务与辅助故障隔离',
}
for name, value in rows.items():
    text, count = re.subn(r'^\| ' + re.escape(name) + r' \| .* \|$',
                         lambda _: f'| {name} | {value} |', text,
                         count=1, flags=re.M)
    assert count == 1, name
put(path, text.replace('## 正在推进\n\n', '## 正在推进\n\n' + intro, 1))
path = R / 'docs/log/2026-11-19.md'
header, body = path.read_text().split('\n', 1)
put(path, header + '\n\n## 2026-11-19 — 注册音色rev326可回退交付与CI接入\n\n' +
    intro.replace('(evidence/', '(../evidence/') +
    '为什么：已验功能须进入默认且保留真实回退和预算；下一步：主线检查合入及剩余音频能力。\n' + body)
path = R / 'docs/serve-master-goals-v2.json'
goals = read(path)
entry = acceptance | dict(evidence='evidence/serve-voice-delivery-20261119/README.md')
for task in goals['tasks']:
    if task['id'] in ('A01', 'A02', 'A10', 'A12', 'Q01', 'Q02'):
        task['registered_voice_delivery_20261119'] = entry
    if task['id'] == 'Q02':
        task['latest_release'] = entry
        task['remaining_required'] = ['Registered voice final-head CI and actual main merge',
                                      'Delivery of every remaining implementation']
    if task['id'] == 'R07':
        task['current_execution_prerequisite'] = ('Refresh exact cold qualification against rev326 or then-current default; '
                                                  'pending host/camera maintenance handoff remains required.')
tts = goals['native_tts_progress']
tts['managed']['state'] = 'registered_voices_delivered_rev326_main_pending'
tts['managed']['default_changed'] = True
tts['managed']['registered_voice_delivery'] = entry
voice = tts['custom_voice']
voice['state'] = 'REGISTERED_SAMPLE_VOICE_HTTP_AND_MANAGED_DELIVERED_REV326'
voice['runtime_api_accepted'] = True
voice['default_changed'] = True
voice['api_lifecycle_pending'] = False
voice['service']['state'] = 'REGISTERED_VOICE_DELIVERED_REV326_MAIN_PENDING'
voice['service']['delivery'] = entry
goals['next_task'] = 'Registered voice main integration, Base-only consumer qualification, ICL/prompt voices and remaining master tasks'
goals['next'] = 'Complete main integration, remaining audio and Realtime capabilities, and every unfinished A/N/R/Q task; listening and long-soak remain separately assigned.'
put(path, json.dumps(goals, ensure_ascii=False, indent=2) + '\n')
path = R / 'docs/README.md'
put(path, path.read_text() + '\n- [rev326注册音色可回退交付](evidence/serve-voice-delivery-20261119/README.md)：持久音色、原生恢复、配额保持及STOPPED回退。\n')
print(json.dumps({key: acceptance[key] for key in ('status', 'revision', 'commands', 'seconds', 'files')}))

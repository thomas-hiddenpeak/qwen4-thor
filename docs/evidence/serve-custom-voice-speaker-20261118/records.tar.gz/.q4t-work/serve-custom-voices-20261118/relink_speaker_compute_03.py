from pathlib import Path
import json,subprocess,time,hashlib
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';B=V/'speaker-compute-build-02';O=V/'speaker-compute-build-03';O.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();previous=json.loads((B/'plan.json').read_bytes());changed='tools/native_tts/speaker_replay.cpp';assert all(sha(R/n)==v for n,v in previous['sources'].items() if n!=changed)
compile=previous['commands'][0].copy();compile[-1]=str(O/'0.o');link=previous['commands'][-1].copy();link[link.index(str(B/'0.o'))]=str(O/'0.o');link[-1]=str(O/'q4t_tts_speaker_replay')
plan=dict(previous_plan_sha256=sha(B/'plan.json'),sources={n:sha(R/n) for n in previous['sources']},commands=[compile,link],reused_objects={str(B/f'{i}.o'):sha(B/f'{i}.o') for i in range(1,10)},correction='bounded BF16 expansion loop in qualification loader; production ExpandTtsWeightChunk unchanged')
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic();records=[]
with (O/'build.log').open('wb') as log:
 for cmd in [compile,link]:
  r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120);records.append(dict(command=cmd,returncode=r.returncode));
  if r.returncode:break
value=dict(status='PASS_BUILD_ONLY' if r.returncode==0 else 'FAIL_BUILD',returncode=r.returncode,seconds=time.monotonic()-start,warnings=(O/'build.log').read_text().count('warning:'),commands=records)
if r.returncode==0:value['binary_sha256']=sha(O/'q4t_tts_speaker_replay')
(O/'result.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k!='commands'}));assert r.returncode==0
p=json.loads((V/'speaker-qualification-plan-01.json').read_bytes());p['sources'][str(R/changed)]=sha(R/changed);p['binary']=str(O/'q4t_tts_speaker_replay');p['sources'][p['binary']]=sha(Path(p['binary']));p['sources'][str(O/'result.json')]=sha(O/'result.json');p['continuation_of']=dict(original_plan_sha256=sha(V/'speaker-qualification-plan-01.json'),failure=str(V/'speaker-qualification-01/run/result.json'),failure_sha256=sha(V/'speaker-qualification-01/run/result.json'),original_actual_cases=0,original_cpu_model_loads=0,original_gpu_process_attempts=1)
(V/'speaker-qualification-plan-02.json').write_text(json.dumps(p,indent=2)+'\n')

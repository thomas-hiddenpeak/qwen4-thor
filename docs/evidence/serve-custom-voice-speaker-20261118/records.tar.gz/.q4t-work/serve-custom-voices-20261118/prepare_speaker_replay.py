from pathlib import Path
R=Path.cwd();p=R/'tools/native_tts/speaker_replay.cpp';assert not p.exists()
s=(R/'tools/native_speaker/model_replay.cpp').read_text().replace('// Fixed real ECAPA numerical replay with caller-owned stages and strict lease.','// Native Qwen Base 2048 speaker qualification; no synthesis acceptance.')
s=s.replace('q4t/audio/speaker_model.h','q4t/audio/tts_speaker_model.h').replace('q4t/audio/speaker_features.h','q4t/audio/tts_speaker_features.h')
for a,b in [('SpeakerConfig','TtsSpeakerConfig'),('SpeakerComputeResult','TtsComputeResult'),('SpeakerDeviceWeights','TtsSpeakerDeviceWeights'),('BindSpeakerDeviceWeights','BindTtsSpeakerDeviceWeights'),('SpeakerFeatures','TtsSpeakerFeatures'),('ComputeSpeakerFeatures','ComputeTtsSpeakerFeatures'),('SpeakerWorkspaceLayout','TtsSpeakerWorkspace'),('PlanSpeakerWorkspace','PlanTtsSpeakerWorkspace'),('SpeakerRun','TtsSpeakerRun')]:s=s.replace(a,b)
start=s.index('  Check(audio::ValidateTtsSpeakerConfig(');end=s.index('  size_t maximum_workspace',start)
s=s[:start]+'''  const auto receipt = Json(TextFile(assets / "result.json", 16384));
  Require(receipt.GetString("status") ==
              "FULL_SOURCE_SHA_VERIFIED_SPEAKER_PREFIX_RETAINED" &&
              receipt.GetString("full_source_sha256") ==
                  "38fc7fc51c5e776e840414b6fd443962e941"
                  "1b9654888fd7913e4da643cb857c",
          "requires independently complete source verification");
  auto file = ReadFile(assets / "source-prefix.bin", 24061040);
  Require(file.size() == 24061040 &&
              trace::HexDigest(trace::Sha256(file)) ==
                  "6f0c979914635259a77c56b31ab9d3cda4f"
                  "aacc1f466ba5e26f06ce6fc8b1661",
          "verified speaker prefix differs");
  static_assert(std::endian::native == std::endian::little);
  uint64_t header_bytes = 0;
  std::memcpy(&header_bytes, file.data(), sizeof(header_bytes));
  Require(header_bytes == 58856, "Base header differs");
  audio::TtsWeightLayout tensor_layout;
  Check(audio::ParseTtsSpeakerWeightLayout(
      Json(std::string(reinterpret_cast<const char*>(file.data() + 8),
                       header_bytes)), C::kBaseDataBytes, &tensor_layout));
  Device device_weights(C::kDeviceBytes);
  for (const auto& tensor : tensor_layout.tensors) {
    checkpoint();
    std::vector<uint16_t> compact(tensor.bytes / 2);
    std::memcpy(compact.data(), file.data() + 8 + header_bytes +
                                   tensor.file_offset, tensor.bytes);
    std::vector<float> expanded(compact.size());
    Check(audio::ExpandTtsWeightChunk(compact, expanded));
    Cuda(cudaMemcpy(static_cast<uint8_t*>(device_weights.value) +
                        tensor.offset * 2,
                    expanded.data(), expanded.size() * sizeof(float),
                    cudaMemcpyHostToDevice));
  }
  std::vector<uint8_t>().swap(file);
  audio::TtsSpeakerDeviceWeights weights;
  Check(audio::BindTtsSpeakerDeviceWeights(device_weights.value,
                                          C::kDeviceBytes, tensor_layout,
                                          &weights));
''' +s[end:]
s=s.replace('ComputeTtsTtsSpeakerFeatures','ComputeTtsSpeakerFeatures')
s=s.replace('pcm, 16000','pcm, 24000').replace('features.frames, 3001','features.frames, 5625').replace('std::array<float, 192>','std::array<float, 2048>')
a=s.index('    for (int stage = 0; stage < 7; ++stage)');b=s.index('    Check(run.Finish(result));',a)
s=s[:a]+'''    constexpr std::array<int, 7> checkpoints{1, 14, 27, 40, 41, 46, 47};
    size_t macro = 0;
    for (int stage = 0; stage < audio::TtsSpeakerRun::kStages; ++stage) {
      checkpoint();
      Check(run.NextStage());
      Require(run.completed_stages() == stage + 1, "stage progress differs");
      if (stage + 1 != checkpoints[macro]) continue;
      const size_t offset = macro < 4    ? layout.hidden
                            : macro == 4 ? layout.aggregate
                            : macro == 5 ? layout.pool
                                         : layout.output;
      const size_t count = macro < 4    ? 512 * features.frames
                           : macro == 4 ? 1536 * features.frames
                           : macro == 5 ? 3072
                                        : 2048;
      SaveDevice(directory / ("stage-" + std::to_string(macro) + ".f32"),
                 reinterpret_cast<const float*>(
                     static_cast<uint8_t*>(workspace.value) + offset),
                 count);
      ++macro;
    }
    Require(macro == 7 && !run.NextStage().ok() &&
                run.completed_stages() == audio::TtsSpeakerRun::kStages,
            "stage count or completion bound differs");
''' +s[b:]
s=s.replace('C::kWeightBytes','C::kDeviceBytes')
p.write_text(s)
for file,old,new in [('CMakeLists.txt','  src/audio/tts_speaker_layout.cpp','  src/audio/tts_speaker_layout.cpp\n  src/audio/tts_speaker_model.cu'),('cmake/ChatProtocolIdentity.cmake','  src/audio/tts_speaker_layout.cpp','  src/audio/tts_speaker_layout.cpp\n  include/q4t/audio/tts_speaker_model.h\n  src/audio/tts_speaker_model.cu')]:
 q=R/file;v=q.read_text();assert v.count(old)==1;t=q.with_suffix('.edit');t.write_text(v.replace(old,new));t.replace(q)

from pathlib import Path
from array import array
import hashlib,json,sys,os,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';T=R/'.q4t-work/serve-native-tts-20261118';sys.path.insert(0,str(R/'tools/native_tts'))
from speaker_acceptance import LIMITS,THRESHOLDS
from acceptance import defaults,digest
O=V/'speaker-acceptance-cpu-01';O.mkdir(exist_ok=False);tmp=O/'tmp';tmp.mkdir()
names=['tools/native_tts/speaker_acceptance.py','tools/native_tts/test_speaker_acceptance.py','tools/native_tts/speaker_reference.py','tools/native_tts/speaker_feature_reference.py']
plan=dict(cases=5,seconds=60,model_loads=0,gpu_actions=0,sources={str(R/n):digest(R/n) for n in names});(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
cmd=['python3','-B','-m','unittest','tools.native_tts.test_speaker_acceptance','-v'];start=time.monotonic()
with (O/'test.log').open('wb') as log:r=subprocess.run(cmd,env=dict(os.environ,Q4T_TEST_TMP=str(tmp)),stdout=log,stderr=subprocess.STDOUT,timeout=60)
result=dict(status='PASS' if r.returncode==0 else 'FAIL',returncode=r.returncode,cases=5,seconds=time.monotonic()-start,gpu_actions=0,model_loads=0,command=cmd,plan_sha256=digest(O/'plan.json'));(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert r.returncode==0
B=V/'speaker-compute-build-02';build=json.loads((B/'result.json').read_bytes());assert build['status']=='PASS_BUILD_ONLY' and build['warnings']==0
sourceplan=json.loads((B/'plan.json').read_bytes());sources={str(R/n):h for n,h in sourceplan['sources'].items()};sources.update(plan['sources'])
inputs=V/'speaker-inputs-01';inputs.mkdir(exist_ok=False)
# Fixed shortest legal input, existing synthetic chirp, two unmodified real utterances.
array('f',[0.0]*1280).tofile((inputs/'minimum-silence.f32').open('wb'))
cases=[]
for name,path in [('minimum_silence',inputs/'minimum-silence.f32'),('synthetic_chirp',R/'tests/fixtures/tts/speaker_features/tail-pcm.f32'),('english',T/'utterance-01/run/native/case-0/pcm.f32'),('chinese',T/'utterance-01/run/native/case-1/pcm.f32')]:
 count=path.stat().st_size//4;cases.append(dict(name=name,pcm=str(path),pcm_sha256=digest(path),samples=count,frames=count//256));sources[str(path)]=digest(path)
source=T/'source-01/official/qwen_tts/core/models';librosa=V/'frontend-reference-source-01'
for p in [source/'configuration_qwen3_tts.py',source/'modeling_qwen3_tts.py',librosa/'convert.py',librosa/'filters.py',V/'metadata-01/config.json',V/'speaker-source-02/source-prefix.bin',V/'speaker-source-02/result.json',B/'q4t_tts_speaker_replay',B/'result.json',V/'speaker-layout-cpu-01/result.json',O/'result.json']:
 sources[str(p)]=digest(p)
qualified=dict(schema='q4t-base-speaker-fp32-qualification-v1',limits=LIMITS,thresholds=THRESHOLDS,sources=sources,cases=cases,defaults=defaults(),binary=str(B/'q4t_tts_speaker_replay'),assets=str(V/'speaker-source-02'),config=str(V/'metadata-01/config.json'),official_source=str(source),librosa_source=str(librosa),reference_python=str(R/'.q4t-work/refenv/bin/python'),purpose='2048 speaker numeric/lifecycle only; synthesis and registered voices still required',source_frontend_contract='canonical FP64 equations max1e-4; separately measure original FP32 frontend effect at FP32 embedding without BF16 rounding')
(V/'speaker-qualification-plan-01.json').write_text(json.dumps(qualified,indent=2)+'\n')
print('Frozen: 1 GPU speaker / 1 CPU reference / 4 cases / 600 s / 64 MiB; no synthesis, HTTP or main model')

"""Verify all pinned Base bytes; retain only the exact speaker source prefix."""
from pathlib import Path
import hashlib,json,os,shutil,time,urllib.request
W=Path(__file__).resolve().parent;O=W/'speaker-source-01';O.mkdir(exist_ok=False)
expected='38fc7fc51c5e776e840414b6fd443962e9411b9654888fd7913e4da643cb857c'
length=3857413744;prefix_length=8+58856+24002176
revision='fd4b254389122332181a7c3db7f27e918eec64e3'
url='https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-Base/resolve/'+revision+'/model.safetensors?download=true&q4t=verified-speaker-prefix'
plan=dict(source=url,expected_full_sha256=expected,source_bytes=length,
 maximum_download_bytes=length,maximum_retained_bytes=32*1024*1024,
 maximum_seconds=900,minimum_free_mib=256,model_loads=0,gpu_loads=0,
 full_model_asset_retained=False,publication='only after complete pinned SHA verification')
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
started=time.monotonic();count=0;next_notice=256*1024*1024;state='FAILED'
result=dict(status='FAILED',gpu_loads=0,model_loads=0)
try:
 assert shutil.disk_usage(W).free>256*1024*1024+prefix_length
 source=hashlib.sha256();partial=O/'source-prefix.partial'
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'q4t-verified-speaker-component/1'}),timeout=30) as r, partial.open('xb') as f:
  assert r.status==200 and int(r.headers['Content-Length'])==length
  while data:=r.read(1024*1024):
   assert time.monotonic()-started<900
   assert count+len(data)<=length
   source.update(data)
   if count<prefix_length:f.write(data[:prefix_length-count])
   count+=len(data)
   if count>=next_notice:
    print(json.dumps(dict(bytes=count,total=length,seconds=time.monotonic()-started)),flush=True)
    next_notice+=256*1024*1024
  f.flush();os.fsync(f.fileno())
 assert count==length and source.hexdigest()==expected
 assert partial.stat().st_size==prefix_length
 with partial.open('rb') as f:
  assert f.read(8)==(W/'metadata-01/header-size.bin').read_bytes()
  assert f.read(58856)==(W/'metadata-01/header.json').read_bytes()
 sha=hashlib.sha256(partial.read_bytes()).hexdigest()
 destination=O/'source-prefix.bin';partial.rename(destination)
 result.update(status='FULL_SOURCE_SHA_VERIFIED_SPEAKER_PREFIX_RETAINED',
   full_source_sha256=source.hexdigest(),prefix_sha256=sha,
   retained_bytes=prefix_length,full_model_asset_retained=False,
   tensor_data_bytes=24002176,tensors=76)
except BaseException as e:
 result['error']=repr(e)
finally:
 result.update(download_bytes=count,seconds=time.monotonic()-started)
 (O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
assert result['status']=='FULL_SOURCE_SHA_VERIFIED_SPEAKER_PREFIX_RETAINED'

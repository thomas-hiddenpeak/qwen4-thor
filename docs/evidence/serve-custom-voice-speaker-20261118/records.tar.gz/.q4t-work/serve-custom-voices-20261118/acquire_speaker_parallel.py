"""Bounded ordered range reads; verify the full pinned digest before publishing."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,threading,time,urllib.request
W=Path(__file__).resolve().parent;O=W/'speaker-source-02';O.mkdir(exist_ok=False)
length=3857413744;prefix_length=8+58856+24002176;chunk_size=4*1024*1024
expected='38fc7fc51c5e776e840414b6fd443962e9411b9654888fd7913e4da643cb857c'
base='https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-Base/resolve/fd4b254389122332181a7c3db7f27e918eec64e3/model.safetensors'
plan=dict(source=base,source_bytes=length,source_sha256=expected,range_bytes=chunk_size,
 connections=8,maximum_download_bytes=length,maximum_retained_bytes=32*1024*1024,
 maximum_network_buffer_mib=128,maximum_seconds=1200,minimum_free_mib=256,
 retries=0,gpu_loads=0,model_loads=0,full_model_asset_retained=False)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
assert shutil.disk_usage(W).free>256*1024*1024+prefix_length
start=time.monotonic();stop=threading.Event();count=0;rows=[];pending={}
result=dict(status='FAILED',gpu_loads=0,model_loads=0);executor=ThreadPoolExecutor(max_workers=8)
def fetch(offset):
 end=min(length,offset+chunk_size)-1;data=bytearray();started=time.monotonic()
 headers={'User-Agent':'q4t-verified-speaker-ranges/1','Range':f'bytes={offset}-{end}','Accept-Encoding':'identity'}
 request=urllib.request.Request(base+f'?download=true&q4t=speaker-range-{offset}',headers=headers)
 with urllib.request.urlopen(request,timeout=30) as r:
  assert r.status==206 and r.headers.get('Content-Range')==f'bytes {offset}-{end}/{length}'
  while block:=r.read(65536):
   assert not stop.is_set() and time.monotonic()-start<1200
   data.extend(block);assert len(data)<=end-offset+1
 assert len(data)==end-offset+1
 return bytes(data),dict(offset=offset,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),seconds=time.monotonic()-started)
try:
 source=hashlib.sha256();next_submit=0;next_notice=64*1024*1024
 for _ in range(8):
  pending[next_submit]=executor.submit(fetch,next_submit);next_submit+=chunk_size
 partial=O/'source-prefix.partial'
 with partial.open('xb') as f:
  for offset in range(0,length,chunk_size):
   data,row=pending.pop(offset).result(timeout=max(0.1,1200-(time.monotonic()-start)))
   source.update(data);rows.append(row)
   if offset<prefix_length:f.write(data[:prefix_length-offset])
   count+=len(data)
   if next_submit<length:
    pending[next_submit]=executor.submit(fetch,next_submit);next_submit+=chunk_size
   if count>=next_notice:
    progress=dict(bytes=count,total=length,seconds=time.monotonic()-start,source_verified=False)
    print(json.dumps(progress),flush=True)
    (O/'progress.json').write_text(json.dumps(progress)+'\n');next_notice+=64*1024*1024
  f.flush();os.fsync(f.fileno())
 assert count==length and source.hexdigest()==expected
 assert partial.stat().st_size==prefix_length
 with partial.open('rb') as f:
  assert f.read(8)==(W/'metadata-01/header-size.bin').read_bytes()
  assert f.read(58856)==(W/'metadata-01/header.json').read_bytes()
 digest=hashlib.sha256(partial.read_bytes()).hexdigest()
 partial.rename(O/'source-prefix.bin')
 result.update(status='FULL_SOURCE_SHA_VERIFIED_SPEAKER_PREFIX_RETAINED',
  full_source_sha256=source.hexdigest(),prefix_sha256=digest,retained_bytes=prefix_length,
  full_model_asset_retained=False,tensor_data_bytes=24002176,tensors=76)
except BaseException as e:result['error']=repr(e)
finally:
 stop.set()
 for p in pending.values():p.cancel()
 executor.shutdown(wait=True,cancel_futures=True)
 result.update(download_bytes_hashed=count,seconds=time.monotonic()-start,
  completed_ranges=len(rows),all_requested_range_bytes_at_most=min(next_submit,length))
 (O/'ranges.json').write_text(json.dumps(rows,indent=2)+'\n')
 (O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
assert result['status']=='FULL_SOURCE_SHA_VERIFIED_SPEAKER_PREFIX_RETAINED'

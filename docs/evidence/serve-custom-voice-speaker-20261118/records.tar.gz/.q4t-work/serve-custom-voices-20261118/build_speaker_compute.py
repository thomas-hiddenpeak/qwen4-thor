import hashlib,json,subprocess,time,shutil
from pathlib import Path
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'speaker-compute-build-01';O.mkdir(exist_ok=False)
assert shutil.disk_usage(V).free>=256*1024**2
sources=['tools/native_tts/speaker_replay.cpp','src/audio/tts_speaker_model.cu','src/audio/tts_speaker_features.cpp','src/audio/tts_speaker_layout.cpp','src/audio/tts_layout.cpp','src/audio/tts_config.cpp','src/io/json.cpp','src/trace/sha256.cpp','src/quant/lt_cache.cpp'];nv='/usr/local/cuda-13.3/bin/nvcc'
commands=[];objects=[]
for i,s in enumerate(sources):
 o=O/f'{i}.o';objects.append(str(o));commands.append([nv,'-std=c++23','-O2','-arch=sm_110a','-ccbin','g++-14','-Iinclude','-Ithird_party','-Xcompiler=-Wall,-Wextra,-Werror','-c',s,'-o',str(o)])
commands.append([nv,'-std=c++23','-arch=sm_110a','-ccbin','g++-14',*objects,'-lcublasLt','-lpthread','-o',str(O/'q4t_tts_speaker_replay')]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
headers=['include/q4t/audio/tts_speaker_model.h','include/q4t/audio/tts_speaker_layout.h','include/q4t/audio/tts_speaker_features.h','include/q4t/audio/tts_layout.h','include/q4t/audio/tts_config.h','include/q4t/audio/tts_model.h','src/audio/tts_math_internal.h','include/q4t/quant/lt_cache.h','include/q4t/runtime/system_memory.h','include/q4t/status.h']
plan=dict(commands=commands,sources={p:sha(R/p) for p in sources+headers},model_loads=0,gpu_actions=0);(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic();records=[];code=0
with (O/'build.log').open('wb') as log:
 for command in commands:
  tick=time.monotonic();r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=180);records.append(dict(command=command,exit_code=r.returncode,seconds=time.monotonic()-tick))
  if r.returncode:code=r.returncode;break
result=dict(status='PASS_BUILD_ONLY' if code==0 else 'FAIL_BUILD',seconds=time.monotonic()-start,commands=records,warnings=(O/'build.log').read_text().count('warning:'),model_loads=0,gpu_actions=0,plan_sha256=sha(O/'plan.json'))
if code==0:result['binary_sha256']=sha(O/'q4t_tts_speaker_replay')
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='commands'}));raise SystemExit(code)

import json,runpy,sys
from pathlib import Path
w=Path(__file__).resolve().parent;name,label=sys.argv[1:];out=w/name;plan=json.loads((out/'plan.json').read_text());command=plan['command']
assert command[:3]==['/usr/bin/python3','-I','-B'] and command[-1]==str(out/'plan.json')
sys.argv=[str(w/'run.py'),label,'timeout','--signal=TERM','--kill-after=30s','180s','/usr/bin/python3','-B',str(w.parents[1]/'tools/evalscope/gpu_exclusive.py'),'--output',str(out/'lease'),'--inherit-lease','--',*command]
runpy.run_path(str(w/'run.py'),run_name='__main__')

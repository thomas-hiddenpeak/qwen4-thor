"""Archive exact projective feature/profile/retained service qualification."""
import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-video-projective-composition-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not O.exists()
f=read(W/'feature-acceptance.json');q=read(W/'profiles-01/acceptance.json')
assert f['status']=='ACCEPT_NATIVE_VIDEO_PROJECTIVE_BUSINESS' and q['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
candidate={k:read(W/'package-01/receipt.json')[k] for k in ('package','manifest_sha256')}
legacy=read(W/'retained-01/review.json')['fallback'];modern=read(W/'modern-retained-01/receipt.json')
for name,desc in [('legacy-business-01',legacy),('modern-business-01',modern)]:
 a=read(W/name/'decision.json')
 assert a['acceptance']=='ACCEPT_VIDEO_PROJECTIVE_SERVICE_RETAINED' and a['manifest_sha256']==desc['manifest_sha256'] and a['engine_binary_sha256']==f['binary_sha256'] and all(a['actual_business']['postflight'].values())
files=[];stages=[]
for name in ['profiles-01','legacy-business-01','modern-business-01']:
 d=W/name;managed=name!='profiles-01';e=d/'execution' if managed else d
 result=read(e/'result.json');guard=read(d/'lease/exit.json')
 counts=result['budget']['counts'] if managed else result['counts']
 events=[json.loads(x) for x in (d/'lease/events.jsonl').read_text().splitlines()]
 queries=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()]
 a=[x for x in events if x.get('event')=='lease_acquired'];z=[x for x in events if x.get('event')=='lease_released']
 assert len(a)==len(z)==1 and a[0]['pid']==z[0]['pid']
 assert guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease']
 assert all(x['status']=='OK' and x['returncode']==0 for x in queries)
 assert guard['status']==z[0]['status']=='COMPLETED'
 stages.append(dict(name=name,status=result['status'],counts=counts,strict_lease_seconds=z[0]['monotonic']-a[0]['monotonic'],nvml_queries=len(queries)))
 for folder,prefix in [(d,name),(d/'lease',name+'/lease')]+([(e,name+'/execution')] if managed else []):
  for p in folder.iterdir():
   if p.is_file() and not p.is_symlink() and p.name not in ['client-policy.json','gateway-policy.json','object-store-key.json']:
    files.append((prefix+'/'+p.name,p))
 for p in (d/'qualified').glob('*.json'):files.append((name+'/qualified/'+p.name,p))
for n in ['prepare_package.py','prepare_retained.py','prepare_modern_root.py','namespace-preflight.py','run.py','run_managed.py','profile-migration-review.json','archive_composition.py','package-delta-review.json','package-01/prepare-review.json','package-01/native-build.json','package-01/receipt.json','package-01/decision.json','retained-01/review.json','modern-retained-01/review.json','modern-retained-01/receipt.json']:
 files.append((n,W/n))
for pattern in ['*namespace-cpu-*.*','service-driver-cpu-*.*','package-prepare-*.*','retained-prepare-*.*','modern-prepare-*.*','legacy-business-*.*','modern-business-*.*','profiles-*.json']:
 for p in W.glob(pattern):
  if p.is_file():files.append((p.name,p))
secrets=[]
def collect(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(v,str) and len(v)>=24:secrets.append(v.encode())
   else:collect(v)
 elif isinstance(x,list):
  for v in x:collect(v)
for desc in [candidate,legacy,modern]:
 for n in ['gateway-policy.json','engine/client-policy.json']:collect(read(Path(desc['package'])/n))
collect(read(W/'profiles-01/client-policy.json'))
files=sorted(dict(files).items())
for n,p in files:assert not any(secret in p.read_bytes() for secret in secrets),n
starts=sum(x['counts']['starts'] for x in stages);requests=sum(x['counts']['chats'] for x in stages);seconds=sum(x['strict_lease_seconds'] for x in stages)
assert starts==4 and requests==16 and seconds<900
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
accepted=dict(status='ACCEPT_NATIVE_VIDEO_PROJECTIVE_COMPOSITION',binary_sha256=f['binary_sha256'],candidate=candidate,automatic_fallback=legacy,modern_retained_root=modern,stages=stages,composition_starts=starts,composition_requests=requests,composition_lease_seconds=seconds,total_starts=starts+f['cumulative_starts'],total_external_requests=requests+f['cumulative_requests'],strict_lease_seconds=seconds+f['cumulative_lease_seconds'],nvml_queries=sum(x['nvml_queries'] for x in stages)+f['nvml_ok_samples'],nvml_all_ok=True,cleanup_complete=True,feature_evidence='docs/evidence/serve-video-projective-business-20261117/README.md',modern_service_acceptance=read(W/'modern-business-01/decision.json'),candidate_control_delta=[],candidate_whole_package_gpu_run=False,default_unchanged=True,publication_pending=True,older_engine_fallback=False,full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,archive_sha256=sha(O/'records.tar.gz'),secret_scan_matches=0)
(W/'publication-composition.json').write_text(json.dumps(accepted,indent=2)+'\n');(O/'acceptance.json').write_text(json.dumps(accepted,indent=2)+'\n')
(O/'README.md').write_text(f'''# 有限透视视频发行组合接受\n\n同一7f25058d引擎的真实齐次/透视JSON、SSE和冻结历史已验；\n主轻实际工具闭环/结构化/embedding/视频通过。旧及现代保留控制包\n均经原生入口完成high透视SSE、私有存储/客户端隔离，奇异请求400\n后同PID普通文本42继续。发行组合4启动16请求、{seconds:.3f}秒。\n含功能短验累计{accepted['total_starts']}启动{accepted['total_external_requests']}请求（含自检和embedding），\n{accepted['strict_lease_seconds']:.3f}秒严格租约、{accepted['nvml_queries']}项NVML正常，完整清理。\n\n控制器/native helper/client源码和字节保持，复用其原恢复证据；\n候选整包按同引擎/控制组合接受，不冒称独立旧引擎回退。显式新增\nprojective能力保持预算和历史，反向丢能力被拒绝。原默认rev244\n保持；继续STOPPED可回退发布和实际合main，其余master继续。\n此前小尺寸默认视频和含答案Chat题质量失败仍单列，不追认通过，\n不作完整模型质量、性能或长稳结论。\n''')
print(json.dumps({k:accepted[k] for k in ['status','total_starts','total_external_requests','strict_lease_seconds','nvml_queries']}))

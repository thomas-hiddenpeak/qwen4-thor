from pathlib import Path
import json,hashlib,subprocess
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profile-source-02';O.mkdir()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
release=json.loads((R/'build/service/engine/q4t.release.json').read_text());old_path=Path(release['tested_source_manifest']);assert sha(old_path)==release['tested_source_manifest_sha256'];old=json.loads(old_path.read_text())
current=json.loads((W/'idle-fact-runtime-01/plan.json').read_text())['sources'];compiled_path=R/'.q4t-work/serve-custom-tools-20261108/engine-build/generated/q4t/server/chat_protocol_sources.json';compiled=json.loads(compiled_path.read_text());assert all(current[n]==h for n,h in compiled.items())
changed={n:dict(before=old[n],after=h) for n,h in current.items() if n in old and h!=old[n]};added={n:h for n,h in current.items() if n not in old};unchanged={n:h for n,h in current.items() if n in old and h==old[n]};removed={n:h for n,h in old.items() if n not in current}
base_commit=subprocess.check_output(['git','rev-parse','c4ed24574'],cwd=R,text=True).strip()
assert all(hashlib.sha256(subprocess.check_output(['git','show',base_commit+':'+n],cwd=R)).hexdigest()==v['before'] for n,v in changed.items())
diff=subprocess.check_output(['git','diff',base_commit,'HEAD','--',*changed,*added],cwd=R);(O/'runtime.diff').write_bytes(diff)
review=dict(status='SOURCE_REVIEW_PENDING',base_commit=base_commit,previous_binary=release['binary_sha256'],previous_protocol=json.loads((R/'build/service/engine/manifest.json').read_text())['protocol_sha256'],candidate_binary=sha(W/'idle-fact-runtime-01/q4t'),candidate_protocol=hashlib.sha256(json.dumps(compiled,sort_keys=True,separators=(',',':')).encode()).hexdigest(),previous_runtime_sources=dict(path=str(old_path),sha256=sha(old_path)),compiled_sources=dict(path=str(compiled_path),sha256=sha(compiled_path)),changed=changed,added=added,unchanged=unchanged,removed=removed,runtime_diff=sha(O/'runtime.diff'))
save(O/'review.json',review);print(json.dumps({k:review[k] for k in ('candidate_binary','candidate_protocol')}));print(json.dumps(dict(changed=list(changed),added=list(added),removed=list(removed),unchanged=len(unchanged),diff_bytes=len(diff)),indent=2))

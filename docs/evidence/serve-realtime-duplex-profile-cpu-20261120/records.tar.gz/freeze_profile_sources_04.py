from pathlib import Path
import json,hashlib,pprint,shutil,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from tools.serve_recovery import profile_record,profile_evidence,ledger
from tools.serve_recovery.profile_acceptance import candidate_build_base
R=Path.cwd();W=R/'.q4t-work/serve-realtime-duplex-20261120';O=W/'profile-source-04';O.mkdir()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
r=json.loads((W/'profile-source-03/review.json').read_text());base=json.loads((R/'build/service/engine/manifest.json').read_text());B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';candidate,binding=candidate_build_base(base,B/'q4t',B)
r['candidate_protocol']=candidate['protocol_sha256'];r['status']='REVIEWED_CHANGED_REALTIME_INPUT_BOUNDARY';r['binding']=binding
r['scope']=dict(fresh=['same conversation native duplex manual, mixed, temporary, TTS roundtrip, tool, VAD auto, idle, interruption and actual settlement','independent transcription history and semantic VAD sharing the changed callback/job owner'],retained='Exact accepted non-Realtime backend/numeric/Chat/Responses results and unchanged voice/speech generation; new Realtime text/tool/speech owners exercised by duplex work, CPU prompt/file/role contracts retained by source.',no_performance_claim=True,no_full_model_matrix=True,remaining=['actual primary/light new business','Guardian fault recovery with same duplex capabilities','delivery/main/all master'])
r['source_scope_notes']={
 'native_engine_and_backends':'Model, CUDA kernels, ASR/TTS weights and numeric paths unchanged; all changed/added files are Realtime wrappers, owners, strict shape selection, capability metadata or build registration.',
 'independent_transcription':'PrepareRealtimeInput callbacks, health gate, shared queue/configure/native job hooks affect standalone input; require fresh original history and semantic VAD business on both capacities.',
 'default_conversation':'Adds native input owner, manual default, private provenance, exact tickets, serialized workers and idle. Require fresh duplex with actual tools and native speech on both capacities.',
 'other_conversation_branches':'Persisted Prompt/file registry, speech encode/synthesize/voice authorization, underlying Chat/Responses planners unchanged. Existing direct CPU combinations and fresh shared-owner duplex retained; no new cloud-account, long-stability or listening claim.'}
shutil.copy2(W/'profile-source-03/runtime.diff',O/'runtime.diff');assert sha(O/'runtime.diff')==r['runtime_diff']
prior=R/'.q4t-work/serve-realtime-audio-20261120/cancel-profiles-01/qualified/registry.json';registry=json.loads(prior.read_text());r['previous_registry_sha256']=sha(prior);sources={}
for name in ('primary','light'):
 p=prior.parent/(name+'.json');v=profile_record.read(p);profile_evidence.validate(v,registry,name,sha(p))
 sources[name]=dict(record_sha256=sha(p),record_format=v['format'],identity=ledger.digest(v['identity']),capacity=ledger.digest(v['capacity']),capabilities=ledger.digest(v['capabilities']),business={k:ledger.digest(z) for k,z in v['business'].items()},prior_reuse=ledger.digest(v['reused_business']))
 assert v['identity']['binary_sha256']==r['previous_binary'] and v['identity']['protocol_sha256']==r['previous_protocol']
save(O/'review.json',r);save(O/'sources.json',sources)
review={k:r[k] for k in ('candidate_binary','candidate_protocol','previous_binary','previous_protocol','previous_registry_sha256','runtime_diff')};review['source_review']=sha(O/'review.json')
p=R/'tools/serve_recovery/profile_duplex_source.py';p.write_text('"""Frozen reviewed native duplex scope; original v19 records stay intact."""\n\nREVIEW = '+pprint.pformat(review,sort_dicts=False,width=100)+'\n\nSOURCES = '+pprint.pformat(sources,sort_dicts=False,width=110)+'\n')
save(O/'preparation-corrections.json',dict(gpu_actions=0,original_drafts_retained=['profile-source-01/review-draft.json','profile-source-03/review.json'],corrections=['invalid copied commit string rejected before producing a diff; resolved c4ed24574 from Git','build source selection omitted third_party/quickjs/SOURCE.json; combined compiled protocol list and build manifest, checked all bytes','draft JSON hash was not the protocol fingerprint; now uses production candidate_build_base sorted path:digest newline hashing'],accepted_review=str(O/'review.json')))
print(json.dumps(dict(status=r['status'],candidate_protocol=r['candidate_protocol'],changed=len(r['changed']),added=len(r['added']),unchanged=len(r['unchanged']),old_records_validated=2)))

from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profile-duplex-cpu-02';O.mkdir(mode=0o700);C=W/'profile-duplex-cpu-01'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
old=json.loads((C/'plan.json').read_text());prior=json.loads((C/'result.json').read_text());assert prior['commands'][0]['returncode']==0 and prior['commands'][1]['returncode']==1 and 'Ran 16 tests' in (C/'command-0.stderr').read_text()
original=C/'original-profile_duplex_targeted.py';new=R/'tools/serve_recovery/profile_duplex_targeted.py';assert sha(original)==old['sources'][str(new.relative_to(R))];assert original.read_text().replace('profile-duplex-cpu-01','profile-duplex-cpu-02')==new.read_text()
for n,h in old['sources'].items():
 if n not in ('tools/serve_audit/inventory.json','tools/serve_recovery/profile_duplex_targeted.py'):assert sha(R/n)==h,n
command=['python3','-B','tools/serve_audit/check_inventory.py','--self-check']
plan=dict(scope='Renew five reviewed new source anchors; reuse 16 successful original Python cases without rerun. The only driver change selects this corrected proof path, all tested functions are unchanged.',sources={n:sha(R/n) for n in old['sources']},protected=old['protected'],commands=[command],reused_cases=16,original_result_sha256=sha(C/'result.json'),original_test_stderr_sha256=sha(C/'command-0.stderr'),driver_metadata_only=dict(before=sha(original),after=sha(new)),gpu_starts=0)
save(O/'plan.json',plan);start=time.monotonic();run=subprocess.run(command,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,timeout=120);(O/'source.stdout').write_bytes(run.stdout);(O/'source.stderr').write_bytes(run.stderr)
unchanged=all(sha(n)==h for n,h in old['protected'].items());r=dict(status='PASS' if run.returncode==0 and unchanged else 'FAIL',seconds=time.monotonic()-start,source_counterexamples=20,reused_python_cases=16,new_python_executions=0,original_source_failure_preserved=True,default_unchanged=unchanged,gpu_starts=0);save(O/'result.json',r);print(json.dumps(r));raise SystemExit(r['status']!='PASS')

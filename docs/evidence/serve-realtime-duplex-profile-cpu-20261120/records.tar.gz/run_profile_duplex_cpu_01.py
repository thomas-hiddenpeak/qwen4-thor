from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profile-duplex-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
files=['tools/serve_recovery/'+n for n in ('profile_evidence.py','profile_migration.py','profile_record.py','profile_duplex.py','profile_duplex_evidence.py','profile_duplex_reuse.py','profile_duplex_source.py','profile_duplex_targeted.py','test_profile_duplex.py','test_profile_speech.py')]+['tools/serve_audit/inventory.json','.github/workflows/host-checks.yml']
commands=[['python3','-B','-m','unittest','-v','tools.serve_recovery.test_profile_duplex','tools.serve_recovery.test_profile_speech.SpeechCapabilities'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
plan=dict(scope=json.loads((W/'profile-duplex-scope-01.json').read_text()),commands=commands,sources={n:sha(R/n) for n in files},protected={str(R/n):sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')})
save(O/'plan.json',plan);start=time.monotonic();runs=[]
for i,cmd in enumerate(commands):
 run=subprocess.run(cmd,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O)),capture_output=True,timeout=max(.1,120-(time.monotonic()-start)));(O/f'command-{i}.stdout').write_bytes(run.stdout);(O/f'command-{i}.stderr').write_bytes(run.stderr);runs.append(dict(command=cmd,returncode=run.returncode))
 if run.returncode:break
unchanged=all(sha(n)==h for n,h in plan['protected'].items());ok=len(runs)==len(commands) and all(x['returncode']==0 for x in runs) and unchanged
result=dict(status='PASS' if ok else 'FAIL',seconds=time.monotonic()-start,commands=runs,tests=16,gpu_starts=0,default_unchanged=unchanged);save(O/'result.json',result);print(json.dumps(result));raise SystemExit(not ok)

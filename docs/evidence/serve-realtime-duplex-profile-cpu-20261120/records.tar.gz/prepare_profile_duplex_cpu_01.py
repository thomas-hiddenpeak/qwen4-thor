from pathlib import Path
import json,re,hashlib,subprocess
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=dict(scope='Native duplex qualification v20, exact source reuse and recovery preservation; fresh primary/light same-conversation and affected standalone history/semantic input. No GPU until CPU checks and complete source freeze.',cpu_tests=16,source_counterexamples=20,cpu_seconds=120,gpu_limits=dict(starts=2,native_admission_units=42,websocket_sessions=10,ingress_starts=6,seconds=1200),fresh_business=['realtime','semantic_vad','realtime_duplex'],retained_unchanged_fields=True,default_unchanged=True,full_matrix=False,model_automatic_restart=False,master_active=True)
(W/'profile-duplex-scope-01.json').write_text(json.dumps(plan,indent=2)+'\n')
p=R/'.github/workflows/host-checks.yml';s=p.read_text();key='            tools.serve_recovery.test_profile_speech \\\n';assert key in s;p.write_text(s.replace(key,key+'            tools.serve_recovery.test_profile_duplex \\\n'))
p=R/'tools/serve_audit/inventory.json';v=json.loads(p.read_text());v['duplex_profiles_20261120']=dict(plan,state='development_targeted_cpu_pending')
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines());changed.update('tools/serve_recovery/'+p.name for p in (R/'tools/serve_recovery').glob('*duplex*.py'))
def refresh(x):
 if isinstance(x,dict):
  for k,z in list(x.items()):
   if k in changed and isinstance(z,str) and len(z)==64 and (R/k).is_file():x[k]=sha(R/k)
   else:refresh(z)
 elif isinstance(x,list):
  for z in x:refresh(z)
refresh(v);p.write_text(json.dumps(v,indent=2)+'\n')
p=R/'docs/STATUS.md';s=p.read_text();a=s.index('\n## 当前实际默认');s=s[:a]+'''
主轻/恢复资格接入已开发：v20要求实际双向业务和组合3.5GiB会话预算，
旧v19仍独立可验，自动降级不得丢掉输入能力或预算；8MiB证据上限保持。
24改动/4新增/956未变来源已核对，模型数值后端保持；共享转写回调/
job owner需补两容量的独立历史与语义VAD。冻结16 Python/20来源反例/
120秒，之后最多2模型/10WSS/42原生准入工作/6入口/1200秒；不是完整
模型矩阵。当前新增GPU0，原默认与失败保留，继续恢复/交付及全部master。
''' +s[a:];p.write_text(s)
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 双向主轻资格、恢复能力与内存预算保留开发

日期：2026-11-20。

做了什么：补v20能力/原始业务证据校验；旧语音资格不自动获得双向
输入。按已核对声明把2GiB原会话和1.5GiB输入增量都保留在迁移合同，
自动回退不得变成旧输出程序。来源24改动/4新增/956未变；只允许精确
复用未影响字段，要求两容量新双向、独立转写历史及语义VAD。证据仍
限8MiB，新驱动有界持有同一租约，原始事件持续保存。冻结16 Python/
20来源反例/120秒，待验；GPU阶段最多2模型/10WSS/42原生工作/1200秒。

为什么：真实业务短验不能代替恢复系统识别新能力，新增音频内存也
不能在能力等价归一化中消失。原始失败保留，不扩大到完整模型矩阵。

下一步：针对CPU、主轻实跑与严格环境收尾，再Guardian故障恢复和
可回退交付、全部master。尚未运行本阶段GPU，默认rev376未改变。
''' +s[i:])
print(json.dumps(plan))

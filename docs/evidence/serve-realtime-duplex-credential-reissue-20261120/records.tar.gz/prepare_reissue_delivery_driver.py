from pathlib import Path
import copy,json,re
W=Path(__file__).resolve().parent;D=W.parent
read=lambda p:json.loads(p.read_text())
c=read(D/'publication-composition.json');old=copy.deepcopy(c)
c['candidate']=read(W/'candidate/receipt.json');c['automatic_fallback']=read(W/'retained/receipt.json');c['modern_retained_root']=c['automatic_fallback']
c['candidate_service_acceptance']=read(W/'candidate/decision.json');c['modern_service_acceptance']=read(W/'retained/decision.json')
c.update(credential_only_reissue=True,original_candidate=old['candidate'],original_retained=old['automatic_fallback'],candidate_whole_package_gpu_run=False,original_whole_package_gpu_run=True,new_gpu_starts=0,source_review=str(W/'source-review.json'))
p=W/'publication-composition.json';assert not p.exists();p.write_text(json.dumps(c,indent=2)+'\n')
s=(D/'deliver_duplex_01.py').read_text()
s=s.replace('R=Path(__file__).resolve().parents[2]','R=Path(__file__).resolve().parents[3]')
s=s.replace('68345e1781eebda59d530bcad2d235e9fe08365f64929a0caa97f0cecd6a84dd','1fbaf0cb3cf106cc6b165810559697f9085d463499ead41e2af445b5fbfb12b8')
for a,b in [('service-package-01/receipt.json','candidate/receipt.json'),('retained-01/receipt.json','retained/receipt.json'),("W/'recovery-retained-02'","W/'retained'"),("W/'recovery-version-01'","W/'candidate'"),("W/'composed-profiles-01/acceptance.json'","W.parent/'composed-profiles-01/acceptance.json'")]:
 assert a in s,a;s=s.replace(a,b)
revs={376:386,378:388,380:390,382:392,384:394,386:396}
s=re.sub(r'\b(?:376|378|380|382|384|386)\b',lambda m:str(revs[int(m.group())]),s)
s=s.replace("permit is not None and profile_manager.compatible", "permit is None and profile_manager.compatible")
s=s.replace("'reviewed one-time profile extension required'","'credential-only reissue cannot change profile qualification'")
s=s.replace("clock=prior_profiles['clock'];expected_profiles=profile_migration.candidate(prior_profiles,permit,ledger.Stamp(clock['boot_id'],clock['monotonic_ns']))","expected_profiles=copy.deepcopy(prior_profiles)")
s=s.replace("candidate_whole_package_gpu_run=(name=='candidate')","candidate_whole_package_gpu_run=False,original_whole_package_gpu_run=(name=='candidate'),credential_only_reissue=True")
s=s.replace("engine_metadata_unchanged=False,engine_default_replaced=True,","engine_metadata_unchanged=True,engine_default_replaced=False,credential_only_reissue=True,")
s=s.replace("'capability-upgrade'","'credential-reissue'").replace('explicit actual duplex capability upgrade','explicit credential-only reissue')
a=s.index("   scope='Native Realtime same-conversation");b=s.index("Serve master tasks continue.')",a)+len("Serve master tasks continue.')")
s=s[:a]+'''   scope='Reissue only the disclosed immutable bootstrap gateway credential in both accepted '
    'candidate and retained payloads. All engine/helper/control sources, actual model '
    'assets, settings, profile qualifications and external client keys are unchanged. '
    'Native control already generates a distinct per-model credential; six original '
    'actual policies were checked to differ from the disclosed seed. Five targeted CPU '
    'authentication/binding checks pass. Original actual duplex and recovery evidence '
    'is explicitly reused by source identity; these new sealed identities were not '
    'loaded on GPU. Model quality remains FAIL independently of protocol acceptance. '
    'Published Git history still contains the old seed, so both newly selected roots '
    'use the replacement value. STOPPED publication preserves client quotas, usage, '
    'profile/outer budgets and existing history. No model restart or automatic replay. '
    'The previous archive was corrected without rewriting original business failures; '
    'no full-model-quality, performance or long-stability claim. All master tasks continue.')''' +s[b:]
s=s.replace('STOPPED native Realtime duplex delivery','STOPPED credential-only native Realtime duplex reissue')
p=W/'deliver_reissue.py';assert not p.exists();p.write_text(s);compile(s,str(p),'exec')
print('Prepared credential-only delivery driver; five STOPPED publications; zero GPU')

import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[3];W=Path(__file__).resolve().parent;S=R/'build/service-native-state'
O=W/'maintenance';O.mkdir(mode=0o700);start=time.monotonic();rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def preserved():
 return {str(p.relative_to(R)):sha(p) for p in [R/'build/q4t',R/'build/service.release.json',R/'build/service/manifest.json']+[p for p in S.rglob('*') if p.is_file() and (p.name=='ledger.json' or p.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection','version-selection')))]}
before=preserved()
def call(label,args):
 assert len(rows)<6 and time.monotonic()-start<360
 cmd=[str(R/'build/q4t'),'service',*map(str,args)]
 r=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=120)
 (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
 rows.append(dict(label=label,command=cmd,returncode=r.returncode));assert r.returncode==0,label
 assert preserved()==before,'live identity/budgets changed'
 print(label,'PASS',flush=True);return json.loads(r.stdout)
try:
 status=call('before',['maintenance-status','--state',S]);assert status['publication_revision']==386 and status['pools']['intents']['used']==128
 selected=sorted(status['pools']['intents']['candidate_ids'],key=lambda n:read(S/'service-publication-intents'/(n+'.json'))['base']['revision'])[:8];assert len(selected)==8
 save(O/'review.json',dict(before=status,selected=selected,preserved=before,deleted_files=0,gpu_starts=0))
 for i in range(2):
  args=['maintenance-plan','--state',S,'--kind','intents','--output',O/f'batch-{i}']
  for value in selected[i*4:i*4+4]:args+=['--select',value]
  plan=call(f'plan-{i}',args)
  call(f'apply-{i}',['maintenance-apply','--state',S,'--kind','intents','--plan',plan['plan'],'--plan-sha256',plan['sha256']])
 after=call('after',['maintenance-status','--state',S]);assert after['pools']['intents']['used']==120 and after['publication_revision']==386
 save(O/'result.json',dict(status='PASS',seconds=time.monotonic()-start,commands=rows,after=after,retired_intents=8,deleted_files=0,gpu_starts=0,live_state_unchanged=True))
except BaseException as e:
 save(O/'result.json',dict(status='FAILED',error=repr(e),commands=rows));raise

"""Reissue only disclosed bootstrap credentials; retain exact actual origin."""
import copy,hashlib,json,os,secrets,shutil,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[3];W=Path(__file__).resolve().parent;D=W.parent
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service import package as p
from tools.serve_recovery import bundle,version_contract,binding,quota_policy
from tools.serve_gateway import client_policy as cp
os.umask(0o077)
protected={n:p.sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
old_roots={n:p.read(D/f/'receipt.json') for n,f in [('candidate','service-package-01'),('retained','retained-01')]}
old_roots={n:{k:v[k] for k in ('package','manifest_sha256')} for n,v in old_roots.items()}
secret=secrets.token_hex(32);roots={};reviews=[]
for name,old_root in old_roots.items():
 old=Path(old_root['package']);manifest=bundle.verify(old,old_root['manifest_sha256'])
 target=W/name/'bundle';p.require(not target.exists(),'preserve reissue');target.parent.mkdir(mode=0o700)
 def copied(a,b):
  a=Path(a);rel=a.relative_to(old).as_posix()
  if rel not in ('manifest.json','bin/q4t') and a.suffix!='.json' and not a.stat().st_mode&0o222:os.link(a,b)
  else:shutil.copy2(a,b)
  return b
 shutil.copytree(old,target,symlinks=True,copy_function=copied)
 raw,base=cp.read(old/'engine/client-policy.json');p.require(base['gateway_token']!=secret,'fresh seed required')
 rotated=dict(base,gateway_token=secret);newraw=binding.policy_bytes(base,secret)
 p.require(cp.digest(base)==cp.digest(rotated) and quota_policy.from_base(base)==quota_policy.from_base(rotated),'client semantics changed')
 path=target/'engine/client-policy.json';path.chmod(0o600);path.write_bytes(newraw);path.chmod(0o400)
 engine=p.read(old/'engine/manifest.json');newengine=copy.deepcopy(engine)
 newengine['files']['client-policy.json']=p.sha(path);newengine['client_policy']=cp.binding(newraw)
 path=target/'engine/manifest.json';path.chmod(0o600);p.save(path,newengine);path.chmod(0o400)
 current=copy.deepcopy(manifest);current['engine_manifest_sha256']=p.sha(path)
 path=target/'manifest.json';path.chmod(0o600);p.save(path,current);path.chmod(0o400);digest=p.sha(path)
 path=target/'bin/q4t';path.chmod(0o700);path.write_bytes(bundle.launcher(digest,current['python']['path']));path.chmod(0o500)
 p.require(bundle.verify(target,digest)==current,'new payload invalid')
 p.require({k for k in current if current[k]!=manifest[k]}=={'engine_manifest_sha256'},'bundle semantic change')
 p.require({k for k in newengine if newengine[k]!=engine[k]}=={'files','client_policy'},'engine semantic change')
 p.require({k for k in newengine['files'] if newengine['files'][k]!=engine['files'][k]}=={'client-policy.json'},'unrelated payload change')
 roots[name]=dict(package=str(target),manifest_sha256=digest)
 p.save(target.parent/'receipt.json',roots[name])
 reviews.append(dict(role=name,original=old_root,reissued=roots[name],
  changed_sealed_files=['engine/client-policy.json','engine/manifest.json','manifest.json','bin/q4t'],
  original_bootstrap_sha256=hashlib.sha256(base['gateway_token'].encode()).hexdigest(),
  new_bootstrap_sha256=hashlib.sha256(secret.encode()).hexdigest(),
  same_binary_protocol_assets_settings_and_source=True,same_client_semantics=True,
  same_dynamic_generation_policy=True,original_engine_manifest=engine,new_engine_manifest=newengine))
p.require(version_contract.compatible(version_contract.payload(roots['candidate']),version_contract.payload(roots['retained']))['automatic'],'new roots incompatible')
# All real managed model policy files must use the generation-scoped credential.
observed=[]
for phase in ['recovery-retained-01','recovery-retained-02','recovery-tls-01','recovery-version-01']:
 for path in (D/phase/'execution/state').rglob('client-policy.json'):
  if not path.parent.name.startswith('model-'):continue
  value=p.read(path)
  p.require(value['gateway_token']!=base['gateway_token'] and value['gateway_token']!=secret,'bootstrap used as runtime authority')
  observed.append(dict(path=str(path),sha256=p.sha(path),bootstrap_credential_used=False))
p.require(len(observed)==6,'actual model generation policies incomplete')
# Native C++ authentication and exact production rotation/binding checks only.
checks=['client_authentication_legacy_and_forgery_boundary','client_http_auth_and_body_reject_before_reservation']
(W/'auth-required.txt').write_text('\n'.join(checks)+'\n')
commands=[[str(R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests'),'--required-list',str(W/'auth-required.txt')],
 [sys.executable,'-B','-m','unittest','-v','tools.serve_recovery.test_gateway.BindingTests.test_rotating_credentials_preserves_all_quota_and_fairness_fields','tools.serve_recovery.test_gateway.BindingTests.test_changed_release_ports_policy_and_types_are_rejected','tools.serve_recovery.test_gateway.AdmissionTests.test_stale_generation_and_credential_never_forward']]
rows=[];start=time.monotonic()
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=60,env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(W),PYTHONDONTWRITEBYTECODE='1'))
 (W/f'auth-{i}.stdout').write_bytes(r.stdout);(W/f'auth-{i}.stderr').write_bytes(r.stderr);p.require(r.returncode==0,'credential CPU failed');rows.append(dict(command=cmd,returncode=r.returncode))
review=dict(status='ACCEPT_CREDENTIAL_ONLY_REISSUE_BY_EXACT_SOURCE',reviews=reviews,actual_runtime_policies=observed,
 original_value_remains_disclosed_in_git=True,core_service_stopped=True,
 preserved_external_client_keys=True,original_actual_business_reused=True,
 new_gpu_starts=0,tests=5,commands=rows,cpu_seconds=time.monotonic()-start,
 runtime_source_unchanged=True,full_model_quality=False,model_quality_status='FAIL')
p.save(W/'source-review.json',review)
for name,origin in [('candidate','recovery-version-01'),('retained','recovery-retained-02')]:
 olddecision=p.read(D/origin/'decision.json');oldrelease=p.read(D/origin/'service-release.json')
 acceptance='ACCEPT_REALTIME_DUPLEX_CREDENTIAL_REISSUE_'+name.upper()
 business=copy.deepcopy(olddecision['actual_business'])
 business.update(original_observed_package=old_roots[name],reissued_package=roots[name],
     credential_only_source_review=dict(path=str(W/'source-review.json'),sha256=p.sha(W/'source-review.json')),
     actual_new_payload_gpu_run=False,new_gpu_starts=0,
     claim='Original actual ASR/protocol/recovery retained; only non-runtime bootstrap credential and sealed identities reissued. Native controller always generates a fresh model credential.')
 decision=dict(status='PASS_REALTIME_DUPLEX_CREDENTIAL_REISSUE_'+name.upper(),acceptance=acceptance,
     manifest_sha256=roots[name]['manifest_sha256'],engine_binary_sha256=olddecision['engine_binary_sha256'],
     actual_business=business,model_quality_status='FAIL',model_quality_separate=True,
     original_decision=dict(path=str(D/origin/'decision.json'),sha256=p.sha(D/origin/'decision.json')),
     runtime_changes=False,new_gpu_starts=0,default_replaced=False)
 directory=W/name;p.save(directory/'decision.json',decision)
 release=copy.deepcopy(oldrelease);release.update(acceptance=acceptance,package=roots[name]['package'],
     manifest_sha256=roots[name]['manifest_sha256'],acceptance_record=str(directory/'decision.json'),
     acceptance_sha256=p.sha(directory/'decision.json'),credential_only_reissue=True,
     actual_new_payload_gpu_run=False,source_review=str(W/'source-review.json'))
 p.save(directory/'service-release.json',release)
 receipt={k:dict(path=str(directory/f),sha256=p.sha(directory/f)) for k,f in [('release','service-release.json'),('decision','decision.json')]}
 version_contract.accepted_fallback(receipt,version_contract.payload(roots[name]))
p.require(all(p.sha(R/n)==h for n,h in protected.items()),'default changed before explicit publication')
p.save(W/'reissue-preparation.json',dict(status='PREPARED_QUALIFIED_CREDENTIAL_REISSUE',roots=roots,protected=protected,source_review_sha256=p.sha(W/'source-review.json'),gpu_starts=0,default_unchanged=True))
print(json.dumps(dict(status='PREPARED_QUALIFIED_CREDENTIAL_REISSUE',roots=roots,actual_generation_policies=len(observed),cpu_tests=5,gpu_starts=0)))

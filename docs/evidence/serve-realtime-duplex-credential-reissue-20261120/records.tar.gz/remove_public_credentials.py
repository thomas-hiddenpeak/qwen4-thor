import hashlib,json,os,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[3];W=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-realtime-duplex-managed-recovery-20261120'
secret=json.loads((W.parent/'service-package-01/clients.json').read_text())['gateway_token'].encode()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=O/'records.tar.gz';backup=W/'original-private-records.tar.gz'
assert not backup.exists();backup.write_bytes(old.read_bytes());backup.chmod(0o600)
idx=O/'index.json';(W/'original-index.json').write_bytes(idx.read_bytes())
index=json.loads(idx.read_text());deny={'service-package-01/clients.json','service-package-01/prepare-review.json'}
rows=[];kept=set();tmp=W/'sanitized-records.tar.gz'
with tarfile.open(backup,'r:gz') as source,tarfile.open(tmp,'w:gz') as target:
 for item in source:
  assert item.isfile();data=source.extractfile(item)
  if item.name in deny:
   assert secret in data.read();continue
  raw=data.read();assert secret not in raw,item.name
  import io
  target.addfile(item,io.BytesIO(raw));kept.add(item.name)
assert deny=={r['path'] for r in index['records'] if r['path'] not in kept}
redacted=[r for r in index['records'] if r['path'] in deny]
index['records']=[r for r in index['records'] if r['path'] in kept]
index.update(archive_sha256=sha(tmp),withheld_private_configuration_records=redacted,
             original_unredacted_archive_sha256=sha(backup),
             redaction_reason='Remove exposed immutable bootstrap gateway credential; runtime/quality/failure records unchanged')
os.replace(tmp,old);idx.write_text(json.dumps(index,indent=2)+'\n')
(O/'README.md').write_text((O/'README.md').read_text()+'''\n公开归档更正：移除误打包的两份含网关初始凭据的私有配置；原文件\nSHA与完整原归档保存在私有现场。测试、原错误回答和失败记录未删改。\n索引明确列出被移除项，原提交历史可能仍含该值，凭据更换另行记录。\n''')
(W/'public-redaction.json').write_text(json.dumps(dict(status='PUBLIC_HEAD_SANITIZED',withheld=redacted,
    original_archive_sha256=sha(backup),new_archive_sha256=sha(old),historical_git_value_still_disclosed=True,
    credential_reissue_pending=True,core_or_gpu_actions=0),indent=2)+'\n')
print('PUBLIC_HEAD_SANITIZED; private original retained; credential reissue pending')

"""Archive only explicitly reviewed, secret-scanned reissue receipts."""
import hashlib,json,re,sys,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[3];W=Path(__file__).resolve().parent;D=W.parent
sys.path.insert(0,str(R))
from tools.serve_service.package import read,sha,require
v=read(W/'delivery-01/result.json');review=read(W/'source-review.json')
O=R/'docs/evidence/serve-realtime-duplex-credential-reissue-20261120'
require(not O.exists() and v['status']=='PASS_NATIVE_REALTIME_DUPLEX_DELIVERED'
    and v['publication']['revision']==396 and v['state']=='STOPPED','reissue incomplete')
require(len(v['commands'])==19 and all(r['returncode']==0 for r in v['commands'])
    and v['outer']['enabled'] and v['outer']['charged_total']==0,'reissue CLI incomplete')
require(all(sha(R/'build/service-native-state'/n)==h for n,h in v['preserved'].items()),'live state changed')
roots=read(W/'reissue-preparation.json')['roots'];selected=v['publication']['current']
require(selected['manifest_sha256']==roots['candidate']['manifest_sha256']
    and sha(R/'build/service/manifest.json')==selected['manifest_sha256'],'default root differs')
old=read(D/'service-package-01/clients.json')['gateway_token'];new=read(Path(roots['candidate']['package'])/'engine/client-policy.json')['gateway_token']
require(old!=new and read(Path(roots['retained']['package'])/'engine/client-policy.json')['gateway_token']==new,'both roots must replace disclosed seed')
release=read((R/'build/service.release.json').resolve());anchor=read(release['rollback_receipt'])
require(anchor['manifest_sha256']==roots['retained']['manifest_sha256'],'old seed remains manual fallback')
policy=read(R/'build/service-native-state/version-selection/policy.json')['state']['policy']
require(roots['retained']['manifest_sha256'] in json.dumps(policy['registry']), 'new seed fallback not registered')
files={}
for name in ['source-review.json','reissue-preparation.json','public-exposure-paths.json',
 'public-redaction.json','remove_public_credentials.py','prepare_reissued_packages.py',
 'prepare_reissue_delivery_driver.py','retire_intents.py','deliver_reissue.py',
 'publication-composition.json','auth-required.txt','auth-0.stdout','auth-0.stderr',
 'auth-1.stdout','auth-1.stderr','archive_reissue.py']:
 files[name]=W/name
for phase in ['candidate','retained']:
 for name in ['receipt.json','decision.json','service-release.json']:
  files[phase+'/'+name]=W/phase/name
for parent in ['delivery-01','maintenance']:
 for p in (W/parent).iterdir():
  if p.is_file():files[str(p.relative_to(W))]=p
for p in (W/'maintenance').glob('batch-*/*.json'):files[str(p.relative_to(W))]=p
files['archive_managed_recovery_fixed.py']=D/'archive_managed_recovery_01.py'
files['superseded-ci.json']=D/'ci-superseded-cancellations.json'
secrets=[old.encode(),new.encode()]
def collect(x):
 if isinstance(x,dict):
  for k,z in x.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(z,str) and len(z)>=24:secrets.append(z.encode())
   else:collect(z)
 elif isinstance(x,list):
  for z in x:collect(z)
collect(read(R/'build/service/gateway-policy.json'))
for name,p in files.items():
 raw=p.read_bytes();require(not any(s in raw for s in secrets) and not re.search(
  rb'-----BEGIN [A-Z ]*PRIVATE KEY-----\s+[A-Za-z0-9+/=]{10,}',raw),'private authority in public artifact: '+name)
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 seen=set()
 for m in t:
  require(m.isfile() and m.name in rows and m.name not in seen,'archive member differs')
  raw=t.extractfile(m).read();require(hashlib.sha256(raw).hexdigest()==rows[m.name]['sha256']
    and not any(s in raw for s in secrets),'archive bytes or credentials differ');seen.add(m.name)
 require(seen==rows.keys(),'missing archive member')
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
save(O/'index.json',dict(records=rows,archive_sha256=sha(O/'records.tar.gz')))
summary=dict(status='PASS_CREDENTIAL_ONLY_REISSUE_DELIVERED',revision=396,state='STOPPED',
 current=selected,roots=roots,original_revision=386,tests=5,cpu_seconds=review['cpu_seconds'],
 actual_managed_generations_checked=6,original_seed_never_used_by_observed_managed_models=True,
 historical_git_disclosure_not_erased=True,public_private_configurations_removed=2,
 candidate_and_retained_bootstrap_replaced=True,external_client_keys_unchanged=True,
 engine_binary_unchanged=True,protocol_source_unchanged=True,model_assets_and_settings_unchanged=True,
 actual_business_reused_by_explicit_source_identity=True,new_payload_gpu_runs=0,
 new_model_starts=0,successful_management_commands=19,management_seconds=v['seconds'],
 profile_history_unchanged=True,client_usage_unchanged=True,outer_budget_unchanged=True,
 retired_intents=8,deleted_files=0,model_quality_status='FAIL',original_failures_preserved=True,
 public_artifact_credential_matches=0,all_master_tasks_active=True,main_integration_pending=True,
 evidence='evidence/serve-realtime-duplex-credential-reissue-20261120/README.md')
save(O/'acceptance.json',summary)
(O/'README.md').write_text(f'''# 网关初始凭据重新签发与rev396交付

2026-11-20。代理在恢复证据归档时误收两份私有配置，含同一个内部
网关初始凭据，并随提交aafa4a63e推送。提交81ac8c09b已移除当前
公共归档里的配置；原文件SHA和完整原件在本地私有现场保留。Git
历史仍可能取得旧值，明确视为已披露，不以删除最新副本当作撤销。
原测试、错误回答和失败数据未改写。

已查验生产代码和6次实际模型的私有策略：原生控制器每次加载都会
生成独立随机凭据，这些实际策略都未使用已披露的包内初始值。
服务此前及此后均STOPPED。仍为候选与保留包重新签发初始值，并
验证旧值不再出现在当前或自动/手动回退的初始化策略里。用户的
外部API Key、配额和用量没有修改。

更换后候选a53986ce、保留包d98f1fa0；引擎ecd6cc23、协议f0c82ef9、
模型资产、所有运行时代码、容量、主轻资格与客户端限制逐字节/语义
核对保持。只有初始化凭据及其封包身份、启动器摘要变化。5项原生
认证/凭据绑定CPU检查通过，{review['cpu_seconds']:.3f}秒；原实际ASR、
双向业务及恢复证据按明确来源复用，新封包未另跑GPU，不假称旧运行
使用了新包身份。原模型质量仍FAIL，原命令格式/检查器失败仍保留。

19条原生管理命令/{v['seconds']:.3f}秒完成显式发布、两向注册、整根
回退和再前进，最终rev396 STOPPED，新增模型启动0。profile历史、
客户端用量、外层预算保持。发行池内8条退役意图可逆归档，0删除。
旧rev386及更早包保留作历史证据；其已披露初始值不得手动复用，
当前回退锚点只选重新签发的同能力保留包。

归档改为显式回执白名单，并扫描压缩包内实际字节；当前/候选/
回退凭据均未命中公共产物。此事故是证据发布操作错误，修复不改变
核心推理或辅助依赖故障隔离。PR #55继续最终检查，全部master仍active。

[重新签发记录](acceptance.json)、[索引](index.json)、[原件](records.tar.gz)。
''')
print(json.dumps(dict(status=summary['status'],revision=396,management_seconds=v['seconds'],archive_bytes=(O/'records.tar.gz').stat().st_size)))

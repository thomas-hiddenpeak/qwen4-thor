# SRV-10d客户端策略托管闭环与用户长验交接

目标是让已验7619966e在生产托管后端v4、托管网关v2及独立API Key
组合中实际运行，并提供同代码的用户day入口。SRV-10c直连runner/
TLS证据继续有效，但不能代替包内固定入口、systemd监督、后端策略
绑定、网关排空/换代及完整停止的组合证明。本批不改C++或默认pair。

## 发布合同修正

已复现：当前sidecar绑定ACCEPT_BOUNDED_CLIENT_ISOLATION汇总决定，
packager只识别旧PASS_*原始结果，故在创建包前拒绝；0模型/HTTP，
原拒绝及原package.py保留。新增明确允许的汇总状态白名单，要求
状态与sidecar acceptance相同；不泛化接受任意ACCEPT_*。失败、
待验或形状错误继续拒绝，verify也检查包内同一验收合同。旧PASS_*
模式继续支持，不把保留的失败attempt改写成成功，也不重新发布ELF。

CPU范围：5项新发布合同（含实际默认v4打包/包内unit入口）、4项
驱动合同、既有PackageTests、8项client包及11项soak检查。包生成
仅nginx -t/openssl与文件操作，不启动模型/监听；真实运行另冻结。

## 运行合同

同一策略alpha/beta分别max_inflight1/control2、prompt4096、body128KiB，
output512/64。后端127.0.0.1:18128，真实TLS网关127.0.0.1:18448；
临时30天自签证书仅用于本机测试，启动前须覆盖整段预算再加1小时。
没有实际LAN/CA/DNS/防火墙或正式Key分发的部署声明。

一次模型systemd启动，restart0；在真实后端上拒绝不同policy与无policy
的网关包，必须无nginx子进程且后端仍存活。正确网关启动后检查beta
输出超额/preflight默认64；每轮alpha普通JSON与beta SSE并发，随后
alpha strict JSON及真实只读资料工具/引用回填，共5成功、3grammar。
最后活跃SSE通过正式stop排空，明确重新启动同一网关包，再做beta
恢复。停止后端后网关需自行检测依赖丢失、清理，不反向停止/重启后端。

短验固定2轮/至少30秒、12生成、3负场景、1模型和2实际网关启动；
128显式控制、GPU420秒/总600秒上限，无自动请求重试。用户day固定
5760轮/86400秒、28802成功（含最后排空/重连）、5760真实工具，
间隔15秒、第一小时240轮检查点；GPU87720秒/总87900秒，60000控制。
不是性能优化或性能非劣验收，不把两个短周期宣称长期资源包络。

后端生产controller从gpu_exclusive持有共享锁，驱动从READY起复制
同一flock并独立监控到网关/模型清理后释放，无第二把锁或中间空档。
模型独立systemd cgroup；复用完整guard日志复制、连续资源观察和
16轮warmup后的RSS/anon/fd/thread包络，缺失或观察失败不接受。
进程内请求字节额度不是物理RAM硬限额，cgroup计量也不等于CUDA全量。
小时/day阶段只准备，必须显式--operator-run-day由用户启动。

## 出口

完整系统身份、两个client的实际响应、工具结果、排空和依赖失联、
各进程/监听退出及10秒无复起，GPU空/原锁可用、SOAR仍masked，
默认与原两份day计划不变。保留新旧所有失败，短验通过后同一固定
包交接day，运行目录隔离；不创建timer或常驻自动启动服务。

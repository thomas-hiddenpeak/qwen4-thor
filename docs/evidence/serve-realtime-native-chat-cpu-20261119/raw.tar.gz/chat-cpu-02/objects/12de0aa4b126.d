/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-02/objects/12de0aa4b126.o: \
 src/server/mcp_content.cpp include/q4t/server/mcp_content.h \
 include/q4t/io/json.h include/q4t/status.h src/server/object_protocol.h \
 include/q4t/server/object_store.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/output_schema.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h src/server/responses_json.h \
 include/q4t/server/input_contract.h
include/q4t/server/mcp_content.h:
include/q4t/io/json.h:
include/q4t/status.h:
src/server/object_protocol.h:
include/q4t/server/object_store.h:
include/q4t/server/application_routes.h:
include/q4t/server/output_schema.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
src/server/responses_json.h:
include/q4t/server/input_contract.h:

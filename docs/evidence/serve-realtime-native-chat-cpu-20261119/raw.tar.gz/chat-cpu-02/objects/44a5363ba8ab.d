/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-02/objects/44a5363ba8ab.o: \
 src/server/speech_request.cpp include/q4t/server/speech_request.h \
 include/q4t/status.h include/q4t/server/chat_plan_error.h \
 include/q4t/io/json.h
include/q4t/server/speech_request.h:
include/q4t/status.h:
include/q4t/server/chat_plan_error.h:
include/q4t/io/json.h:

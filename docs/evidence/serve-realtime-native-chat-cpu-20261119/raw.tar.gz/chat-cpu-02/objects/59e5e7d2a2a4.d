/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-02/objects/59e5e7d2a2a4.o: \
 src/server/mcp_http.cpp src/server/mcp_transport_internal.h \
 include/q4t/server/mcp_transport.h include/q4t/server/file_fetch.h \
 include/q4t/server/file_input.h include/q4t/server/binary_store.h \
 include/q4t/server/object_store.h include/q4t/io/json.h \
 include/q4t/status.h include/q4t/server/grammar_process.h \
 include/q4t/server/worker_io_budget.h src/server/mcp_provider_internal.h \
 src/server/mcp_sse_internal.h src/server/object_protocol.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/output_schema.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h src/server/responses_json.h \
 src/server/remote_http_internal.h src/server/file_fetch_internal.h \
 include/q4t/service/ingress_address.h \
 src/server/mcp_tunnel_transport_internal.h \
 include/q4t/server/mcp_tunnel.h include/q4t/server/http_framing.h \
 include/q4t/server/http_response.h include/q4t/server/request_control.h \
 include/q4t/server/client_identity.h \
 include/q4t/server/request_progress.h include/q4t/server/actual_usage.h \
 include/q4t/server/client_policy.h include/q4t/server/http_observation.h \
 include/q4t/server/finite_response.h include/q4t/server/request_limits.h \
 include/q4t/server/input_contract.h include/q4t/server/lifetime.h \
 include/q4t/server/mcp_content.h
src/server/mcp_transport_internal.h:
include/q4t/server/mcp_transport.h:
include/q4t/server/file_fetch.h:
include/q4t/server/file_input.h:
include/q4t/server/binary_store.h:
include/q4t/server/object_store.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/grammar_process.h:
include/q4t/server/worker_io_budget.h:
src/server/mcp_provider_internal.h:
src/server/mcp_sse_internal.h:
src/server/object_protocol.h:
include/q4t/server/application_routes.h:
include/q4t/server/output_schema.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
src/server/responses_json.h:
src/server/remote_http_internal.h:
src/server/file_fetch_internal.h:
include/q4t/service/ingress_address.h:
src/server/mcp_tunnel_transport_internal.h:
include/q4t/server/mcp_tunnel.h:
include/q4t/server/http_framing.h:
include/q4t/server/http_response.h:
include/q4t/server/request_control.h:
include/q4t/server/client_identity.h:
include/q4t/server/request_progress.h:
include/q4t/server/actual_usage.h:
include/q4t/server/client_policy.h:
include/q4t/server/http_observation.h:
include/q4t/server/finite_response.h:
include/q4t/server/request_limits.h:
include/q4t/server/input_contract.h:
include/q4t/server/lifetime.h:
include/q4t/server/mcp_content.h:

// Generated from the pinned OpenAI SDK types. See openai-node/LICENSE.
#pragma once
#include <string_view>
namespace q4t::server::item_types {
inline constexpr std::string_view kData = R"q4t_types({
  "profile": "q4t-openai-item-types-v1",
  "sdk_version": "7.47.0",
  "compiler_version": "5.9.3",
  "roots": {
    "input_item": 0,
    "output_item": 555,
    "conversation_item": 622
  },
  "nodes": [
    {
      "kind": "union",
      "variants": [
        1,
        41,
        47,
        72,
        87,
        134,
        142,
        156,
        164,
        182,
        188,
        385,
        414,
        428,
        437,
        439,
        457,
        467,
        473,
        475,
        482,
        494,
        507,
        513,
        517,
        519,
        522,
        533,
        541,
        546,
        548,
        551,
        552
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "content",
          "optional": false,
          "type": 2
        },
        {
          "name": "phase",
          "optional": true,
          "type": 31
        },
        {
          "name": "role",
          "optional": false,
          "type": 34
        },
        {
          "name": "type",
          "optional": true,
          "type": 39
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        3,
        4
      ]
    },
    {
      "kind": "string"
    },
    {
      "kind": "array",
      "element": 5
    },
    {
      "kind": "union",
      "variants": [
        6,
        14,
        25
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 7
        },
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 13
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        8
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "explicit"
    },
    {
      "kind": "union",
      "variants": [
        11,
        12
      ]
    },
    {
      "kind": "literal",
      "value": "30m"
    },
    {
      "kind": "literal",
      "value": "12h"
    },
    {
      "kind": "literal",
      "value": "input_text"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "detail",
          "optional": false,
          "type": 15
        },
        {
          "name": "file_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "image_url",
          "optional": true,
          "type": 20
        },
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 22
        },
        {
          "name": "type",
          "optional": false,
          "type": 24
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        16,
        17,
        18,
        19
      ]
    },
    {
      "kind": "literal",
      "value": "low"
    },
    {
      "kind": "literal",
      "value": "high"
    },
    {
      "kind": "literal",
      "value": "auto"
    },
    {
      "kind": "literal",
      "value": "original"
    },
    {
      "kind": "union",
      "variants": [
        21,
        3
      ]
    },
    {
      "kind": "null"
    },
    {
      "kind": "union",
      "variants": [
        23
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "input_image"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "detail",
          "optional": true,
          "type": 26
        },
        {
          "name": "file_data",
          "optional": true,
          "type": 27
        },
        {
          "name": "file_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "file_url",
          "optional": true,
          "type": 27
        },
        {
          "name": "filename",
          "optional": true,
          "type": 27
        },
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 28
        },
        {
          "name": "type",
          "optional": false,
          "type": 30
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        16,
        17,
        18
      ]
    },
    {
      "kind": "union",
      "variants": [
        3
      ]
    },
    {
      "kind": "union",
      "variants": [
        29
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "input_file"
    },
    {
      "kind": "union",
      "variants": [
        21,
        32,
        33
      ]
    },
    {
      "kind": "literal",
      "value": "commentary"
    },
    {
      "kind": "literal",
      "value": "final_answer"
    },
    {
      "kind": "union",
      "variants": [
        35,
        36,
        37,
        38
      ]
    },
    {
      "kind": "literal",
      "value": "user"
    },
    {
      "kind": "literal",
      "value": "assistant"
    },
    {
      "kind": "literal",
      "value": "system"
    },
    {
      "kind": "literal",
      "value": "developer"
    },
    {
      "kind": "union",
      "variants": [
        40
      ]
    },
    {
      "kind": "literal",
      "value": "message"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "content",
          "optional": false,
          "type": 4
        },
        {
          "name": "role",
          "optional": false,
          "type": 42
        },
        {
          "name": "status",
          "optional": true,
          "type": 43
        },
        {
          "name": "type",
          "optional": true,
          "type": 39
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        35,
        37,
        38
      ]
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        46
      ]
    },
    {
      "kind": "literal",
      "value": "in_progress"
    },
    {
      "kind": "literal",
      "value": "completed"
    },
    {
      "kind": "literal",
      "value": "incomplete"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "content",
          "optional": false,
          "type": 48
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "phase",
          "optional": true,
          "type": 31
        },
        {
          "name": "role",
          "optional": false,
          "type": 36
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 40
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 49
    },
    {
      "kind": "union",
      "variants": [
        50,
        69
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "annotations",
          "optional": false,
          "type": 51
        },
        {
          "name": "logprobs",
          "optional": true,
          "type": 62
        },
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 68
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 52
    },
    {
      "kind": "union",
      "variants": [
        53,
        56,
        58,
        60
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "filename",
          "optional": false,
          "type": 3
        },
        {
          "name": "index",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 55
        }
      ],
      "additional": null
    },
    {
      "kind": "number"
    },
    {
      "kind": "literal",
      "value": "file_citation"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "end_index",
          "optional": false,
          "type": 54
        },
        {
          "name": "start_index",
          "optional": false,
          "type": 54
        },
        {
          "name": "title",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 57
        },
        {
          "name": "url",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "url_citation"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "container_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "end_index",
          "optional": false,
          "type": 54
        },
        {
          "name": "file_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "filename",
          "optional": false,
          "type": 3
        },
        {
          "name": "start_index",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 59
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "container_file_citation"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "index",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 61
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "file_path"
    },
    {
      "kind": "union",
      "variants": [
        63
      ]
    },
    {
      "kind": "array",
      "element": 64
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "bytes",
          "optional": false,
          "type": 65
        },
        {
          "name": "logprob",
          "optional": false,
          "type": 54
        },
        {
          "name": "token",
          "optional": false,
          "type": 3
        },
        {
          "name": "top_logprobs",
          "optional": false,
          "type": 66
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 54
    },
    {
      "kind": "array",
      "element": 67
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "bytes",
          "optional": false,
          "type": 65
        },
        {
          "name": "logprob",
          "optional": false,
          "type": 54
        },
        {
          "name": "token",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "output_text"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "refusal",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 70
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "refusal"
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        46
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "queries",
          "optional": false,
          "type": 73
        },
        {
          "name": "results",
          "optional": true,
          "type": 74
        },
        {
          "name": "status",
          "optional": false,
          "type": 83
        },
        {
          "name": "type",
          "optional": false,
          "type": 86
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 3
    },
    {
      "kind": "union",
      "variants": [
        21,
        75
      ]
    },
    {
      "kind": "array",
      "element": 76
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "attributes",
          "optional": true,
          "type": 77
        },
        {
          "name": "file_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "filename",
          "optional": true,
          "type": 27
        },
        {
          "name": "score",
          "optional": true,
          "type": 82
        },
        {
          "name": "text",
          "optional": true,
          "type": 27
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        78
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 79
    },
    {
      "kind": "union",
      "variants": [
        3,
        54,
        80,
        81
      ]
    },
    {
      "kind": "literal",
      "value": false
    },
    {
      "kind": "literal",
      "value": true
    },
    {
      "kind": "union",
      "variants": [
        54
      ]
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        46,
        84,
        85
      ]
    },
    {
      "kind": "literal",
      "value": "searching"
    },
    {
      "kind": "literal",
      "value": "failed"
    },
    {
      "kind": "literal",
      "value": "file_search_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": true,
          "type": 88
        },
        {
          "name": "actions",
          "optional": true,
          "type": 117
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "pending_safety_checks",
          "optional": false,
          "type": 131
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 133
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        89,
        98,
        101,
        105,
        107,
        109,
        111,
        113,
        115
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "button",
          "optional": false,
          "type": 90
        },
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "type",
          "optional": false,
          "type": 97
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        91,
        92,
        93,
        94,
        95
      ]
    },
    {
      "kind": "literal",
      "value": "left"
    },
    {
      "kind": "literal",
      "value": "right"
    },
    {
      "kind": "literal",
      "value": "wheel"
    },
    {
      "kind": "literal",
      "value": "back"
    },
    {
      "kind": "literal",
      "value": "forward"
    },
    {
      "kind": "union",
      "variants": [
        21,
        73
      ]
    },
    {
      "kind": "literal",
      "value": "click"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": false,
          "type": 99
        },
        {
          "name": "type",
          "optional": false,
          "type": 100
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        73
      ]
    },
    {
      "kind": "literal",
      "value": "double_click"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "path",
          "optional": false,
          "type": 102
        },
        {
          "name": "type",
          "optional": false,
          "type": 104
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 103
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "drag"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": false,
          "type": 73
        },
        {
          "name": "type",
          "optional": false,
          "type": 106
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "keypress"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "type",
          "optional": false,
          "type": 108
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "move"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 110
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "screenshot"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "scroll_x",
          "optional": false,
          "type": 54
        },
        {
          "name": "scroll_y",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 112
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "scroll"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 114
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "type"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 116
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "wait"
    },
    {
      "kind": "union",
      "variants": [
        118
      ]
    },
    {
      "kind": "array",
      "element": 119
    },
    {
      "kind": "union",
      "variants": [
        120,
        121,
        122,
        125,
        126,
        127,
        128,
        129,
        130
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "button",
          "optional": false,
          "type": 90
        },
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "type",
          "optional": false,
          "type": 97
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": false,
          "type": 99
        },
        {
          "name": "type",
          "optional": false,
          "type": 100
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "path",
          "optional": false,
          "type": 123
        },
        {
          "name": "type",
          "optional": false,
          "type": 104
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 124
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": false,
          "type": 73
        },
        {
          "name": "type",
          "optional": false,
          "type": 106
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "type",
          "optional": false,
          "type": 108
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 110
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "keys",
          "optional": true,
          "type": 96
        },
        {
          "name": "scroll_x",
          "optional": false,
          "type": 54
        },
        {
          "name": "scroll_y",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 112
        },
        {
          "name": "x",
          "optional": false,
          "type": 54
        },
        {
          "name": "y",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 114
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 116
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 132
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "message",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "computer_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "acknowledged_safety_checks",
          "optional": true,
          "type": 135
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "output",
          "optional": false,
          "type": 138
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 141
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        136
      ]
    },
    {
      "kind": "array",
      "element": 137
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "message",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "image_url",
          "optional": true,
          "type": 27
        },
        {
          "name": "type",
          "optional": false,
          "type": 139
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "computer_screenshot"
    },
    {
      "kind": "union",
      "variants": [
        21,
        44,
        45,
        46
      ]
    },
    {
      "kind": "literal",
      "value": "computer_call_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": false,
          "type": 143
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 83
        },
        {
          "name": "type",
          "optional": false,
          "type": 155
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        144,
        151,
        153
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "queries",
          "optional": true,
          "type": 145
        },
        {
          "name": "query",
          "optional": true,
          "type": 27
        },
        {
          "name": "sources",
          "optional": true,
          "type": 146
        },
        {
          "name": "type",
          "optional": false,
          "type": 150
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        73
      ]
    },
    {
      "kind": "union",
      "variants": [
        147
      ]
    },
    {
      "kind": "array",
      "element": 148
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 149
        },
        {
          "name": "url",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "url"
    },
    {
      "kind": "literal",
      "value": "search"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 152
        },
        {
          "name": "url",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "open_page"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "pattern",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 154
        },
        {
          "name": "url",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "find_in_page"
    },
    {
      "kind": "literal",
      "value": "web_search_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 158
        },
        {
          "name": "id",
          "optional": true,
          "type": 27
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "namespace",
          "optional": true,
          "type": 27
        },
        {
          "name": "status",
          "optional": true,
          "type": 43
        },
        {
          "name": "type",
          "optional": false,
          "type": 163
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        80,
        81
      ]
    },
    {
      "kind": "union",
      "variants": [
        21,
        159,
        161
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "direct"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "program"
    },
    {
      "kind": "literal",
      "value": "function_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "caller",
          "optional": true,
          "type": 165
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "name",
          "optional": true,
          "type": 20
        },
        {
          "name": "namespace",
          "optional": true,
          "type": 20
        },
        {
          "name": "output",
          "optional": false,
          "type": 168
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 181
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        166,
        167
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        3,
        169
      ]
    },
    {
      "kind": "array",
      "element": 170
    },
    {
      "kind": "union",
      "variants": [
        171,
        174,
        178
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 172
        },
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 13
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        173
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "detail",
          "optional": true,
          "type": 175
        },
        {
          "name": "file_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "image_url",
          "optional": true,
          "type": 20
        },
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 176
        },
        {
          "name": "type",
          "optional": false,
          "type": 24
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        16,
        17,
        18,
        19
      ]
    },
    {
      "kind": "union",
      "variants": [
        21,
        177
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "detail",
          "optional": true,
          "type": 26
        },
        {
          "name": "file_data",
          "optional": true,
          "type": 20
        },
        {
          "name": "file_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "file_url",
          "optional": true,
          "type": 20
        },
        {
          "name": "filename",
          "optional": true,
          "type": 20
        },
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 179
        },
        {
          "name": "type",
          "optional": false,
          "type": 30
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        180
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "function_call_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 183
        },
        {
          "name": "call_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "execution",
          "optional": true,
          "type": 184
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 187
        }
      ],
      "additional": null
    },
    {
      "kind": "any"
    },
    {
      "kind": "union",
      "variants": [
        185,
        186
      ]
    },
    {
      "kind": "literal",
      "value": "server"
    },
    {
      "kind": "literal",
      "value": "client"
    },
    {
      "kind": "literal",
      "value": "tool_search_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "execution",
          "optional": true,
          "type": 184
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "tools",
          "optional": false,
          "type": 189
        },
        {
          "name": "type",
          "optional": false,
          "type": 384
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 190
    },
    {
      "kind": "union",
      "variants": [
        191,
        202,
        229,
        231,
        239,
        251,
        274,
        291,
        293,
        328,
        330,
        352,
        362,
        370,
        372,
        382
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "defer_loading",
          "optional": true,
          "type": 157
        },
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "output_schema",
          "optional": true,
          "type": 196
        },
        {
          "name": "parameters",
          "optional": false,
          "type": 198
        },
        {
          "name": "strict",
          "optional": false,
          "type": 200
        },
        {
          "name": "type",
          "optional": false,
          "type": 201
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        193
      ]
    },
    {
      "kind": "array",
      "element": 194
    },
    {
      "kind": "union",
      "variants": [
        160,
        195
      ]
    },
    {
      "kind": "literal",
      "value": "programmatic"
    },
    {
      "kind": "union",
      "variants": [
        21,
        197
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 183
    },
    {
      "kind": "union",
      "variants": [
        21,
        199
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 183
    },
    {
      "kind": "union",
      "variants": [
        21,
        80,
        81
      ]
    },
    {
      "kind": "literal",
      "value": "function"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "filters",
          "optional": true,
          "type": 203
        },
        {
          "name": "max_num_results",
          "optional": true,
          "type": 82
        },
        {
          "name": "ranking_options",
          "optional": true,
          "type": 222
        },
        {
          "name": "type",
          "optional": false,
          "type": 228
        },
        {
          "name": "vector_store_ids",
          "optional": false,
          "type": 73
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        204,
        217
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "key",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 205
        },
        {
          "name": "value",
          "optional": false,
          "type": 214
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        206,
        207,
        208,
        209,
        210,
        211,
        212,
        213
      ]
    },
    {
      "kind": "literal",
      "value": "eq"
    },
    {
      "kind": "literal",
      "value": "ne"
    },
    {
      "kind": "literal",
      "value": "gt"
    },
    {
      "kind": "literal",
      "value": "gte"
    },
    {
      "kind": "literal",
      "value": "lt"
    },
    {
      "kind": "literal",
      "value": "lte"
    },
    {
      "kind": "literal",
      "value": "in"
    },
    {
      "kind": "literal",
      "value": "nin"
    },
    {
      "kind": "union",
      "variants": [
        3,
        54,
        80,
        81,
        215
      ]
    },
    {
      "kind": "array",
      "element": 216
    },
    {
      "kind": "union",
      "variants": [
        3,
        54
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "filters",
          "optional": false,
          "type": 218
        },
        {
          "name": "type",
          "optional": false,
          "type": 219
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 183
    },
    {
      "kind": "union",
      "variants": [
        220,
        221
      ]
    },
    {
      "kind": "literal",
      "value": "and"
    },
    {
      "kind": "literal",
      "value": "or"
    },
    {
      "kind": "union",
      "variants": [
        223
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "hybrid_search",
          "optional": true,
          "type": 224
        },
        {
          "name": "ranker",
          "optional": true,
          "type": 226
        },
        {
          "name": "score_threshold",
          "optional": true,
          "type": 82
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        225
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "embedding_weight",
          "optional": false,
          "type": 54
        },
        {
          "name": "text_weight",
          "optional": false,
          "type": 54
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        18,
        227
      ]
    },
    {
      "kind": "literal",
      "value": "default-2024-11-15"
    },
    {
      "kind": "literal",
      "value": "file_search"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 230
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "computer"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "display_height",
          "optional": false,
          "type": 54
        },
        {
          "name": "display_width",
          "optional": false,
          "type": 54
        },
        {
          "name": "environment",
          "optional": false,
          "type": 232
        },
        {
          "name": "type",
          "optional": false,
          "type": 238
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        233,
        234,
        235,
        236,
        237
      ]
    },
    {
      "kind": "literal",
      "value": "windows"
    },
    {
      "kind": "literal",
      "value": "mac"
    },
    {
      "kind": "literal",
      "value": "linux"
    },
    {
      "kind": "literal",
      "value": "ubuntu"
    },
    {
      "kind": "literal",
      "value": "browser"
    },
    {
      "kind": "literal",
      "value": "computer_use_preview"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "external_web_access",
          "optional": true,
          "type": 157
        },
        {
          "name": "filters",
          "optional": true,
          "type": 240
        },
        {
          "name": "search_context_size",
          "optional": true,
          "type": 242
        },
        {
          "name": "type",
          "optional": false,
          "type": 244
        },
        {
          "name": "user_location",
          "optional": true,
          "type": 247
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        241
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_domains",
          "optional": true,
          "type": 96
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        16,
        17,
        243
      ]
    },
    {
      "kind": "literal",
      "value": "medium"
    },
    {
      "kind": "union",
      "variants": [
        245,
        246
      ]
    },
    {
      "kind": "literal",
      "value": "web_search"
    },
    {
      "kind": "literal",
      "value": "web_search_2025_08_26"
    },
    {
      "kind": "union",
      "variants": [
        21,
        248
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "city",
          "optional": true,
          "type": 20
        },
        {
          "name": "country",
          "optional": true,
          "type": 20
        },
        {
          "name": "region",
          "optional": true,
          "type": 20
        },
        {
          "name": "timezone",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": true,
          "type": 249
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        250
      ]
    },
    {
      "kind": "literal",
      "value": "approximate"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "allowed_tools",
          "optional": true,
          "type": 252
        },
        {
          "name": "authorization",
          "optional": true,
          "type": 27
        },
        {
          "name": "connector_id",
          "optional": true,
          "type": 254
        },
        {
          "name": "defer_loading",
          "optional": true,
          "type": 157
        },
        {
          "name": "headers",
          "optional": true,
          "type": 263
        },
        {
          "name": "require_approval",
          "optional": true,
          "type": 265
        },
        {
          "name": "server_description",
          "optional": true,
          "type": 27
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_url",
          "optional": true,
          "type": 27
        },
        {
          "name": "tunnel_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "type",
          "optional": false,
          "type": 273
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        73,
        253
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "read_only",
          "optional": true,
          "type": 157
        },
        {
          "name": "tool_names",
          "optional": true,
          "type": 145
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        255,
        256,
        257,
        258,
        259,
        260,
        261,
        262
      ]
    },
    {
      "kind": "literal",
      "value": "connector_dropbox"
    },
    {
      "kind": "literal",
      "value": "connector_gmail"
    },
    {
      "kind": "literal",
      "value": "connector_googlecalendar"
    },
    {
      "kind": "literal",
      "value": "connector_googledrive"
    },
    {
      "kind": "literal",
      "value": "connector_microsoftteams"
    },
    {
      "kind": "literal",
      "value": "connector_outlookcalendar"
    },
    {
      "kind": "literal",
      "value": "connector_outlookemail"
    },
    {
      "kind": "literal",
      "value": "connector_sharepoint"
    },
    {
      "kind": "union",
      "variants": [
        21,
        264
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 3
    },
    {
      "kind": "union",
      "variants": [
        21,
        266,
        271,
        272
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "always",
          "optional": true,
          "type": 267
        },
        {
          "name": "never",
          "optional": true,
          "type": 269
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        268
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "read_only",
          "optional": true,
          "type": 157
        },
        {
          "name": "tool_names",
          "optional": true,
          "type": 145
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        270
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "read_only",
          "optional": true,
          "type": 157
        },
        {
          "name": "tool_names",
          "optional": true,
          "type": 145
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "always"
    },
    {
      "kind": "literal",
      "value": "never"
    },
    {
      "kind": "literal",
      "value": "mcp"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "container",
          "optional": false,
          "type": 275
        },
        {
          "name": "type",
          "optional": false,
          "type": 290
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        3,
        276
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_ids",
          "optional": true,
          "type": 145
        },
        {
          "name": "memory_limit",
          "optional": true,
          "type": 277
        },
        {
          "name": "network_policy",
          "optional": true,
          "type": 282
        },
        {
          "name": "type",
          "optional": false,
          "type": 18
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        278,
        279,
        280,
        281
      ]
    },
    {
      "kind": "literal",
      "value": "1g"
    },
    {
      "kind": "literal",
      "value": "4g"
    },
    {
      "kind": "literal",
      "value": "16g"
    },
    {
      "kind": "literal",
      "value": "64g"
    },
    {
      "kind": "union",
      "variants": [
        283,
        285
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 284
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "disabled"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_domains",
          "optional": false,
          "type": 73
        },
        {
          "name": "domain_secrets",
          "optional": true,
          "type": 286
        },
        {
          "name": "type",
          "optional": false,
          "type": 289
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        287
      ]
    },
    {
      "kind": "array",
      "element": 288
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "domain",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "value",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "allowlist"
    },
    {
      "kind": "literal",
      "value": "code_interpreter"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 292
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "programmatic_tool_calling"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": true,
          "type": 294
        },
        {
          "name": "background",
          "optional": true,
          "type": 297
        },
        {
          "name": "input_fidelity",
          "optional": true,
          "type": 300
        },
        {
          "name": "input_image_mask",
          "optional": true,
          "type": 301
        },
        {
          "name": "model",
          "optional": true,
          "type": 303
        },
        {
          "name": "moderation",
          "optional": true,
          "type": 315
        },
        {
          "name": "output_compression",
          "optional": true,
          "type": 82
        },
        {
          "name": "output_format",
          "optional": true,
          "type": 316
        },
        {
          "name": "partial_images",
          "optional": true,
          "type": 82
        },
        {
          "name": "quality",
          "optional": true,
          "type": 320
        },
        {
          "name": "size",
          "optional": true,
          "type": 323
        },
        {
          "name": "type",
          "optional": false,
          "type": 327
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        18,
        295,
        296
      ]
    },
    {
      "kind": "literal",
      "value": "generate"
    },
    {
      "kind": "literal",
      "value": "edit"
    },
    {
      "kind": "union",
      "variants": [
        18,
        298,
        299
      ]
    },
    {
      "kind": "literal",
      "value": "transparent"
    },
    {
      "kind": "literal",
      "value": "opaque"
    },
    {
      "kind": "union",
      "variants": [
        21,
        16,
        17
      ]
    },
    {
      "kind": "union",
      "variants": [
        302
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "image_url",
          "optional": true,
          "type": 27
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        304,
        305,
        306,
        307,
        308,
        309,
        310,
        311,
        312,
        313,
        314
      ]
    },
    {
      "kind": "string"
    },
    {
      "kind": "literal",
      "value": "gpt-image-1"
    },
    {
      "kind": "literal",
      "value": "gpt-image-1-mini"
    },
    {
      "kind": "literal",
      "value": "gpt-image-2"
    },
    {
      "kind": "literal",
      "value": "gpt-image-2-2026-04-21"
    },
    {
      "kind": "literal",
      "value": "gpt-image-2.5-sunburst"
    },
    {
      "kind": "literal",
      "value": "gpt-image-2.5-sunburst-2026-09-08"
    },
    {
      "kind": "literal",
      "value": "gpt-image-2.5-flare"
    },
    {
      "kind": "literal",
      "value": "gpt-image-2.5-flare-2026-09-08"
    },
    {
      "kind": "literal",
      "value": "gpt-image-1.5"
    },
    {
      "kind": "literal",
      "value": "chatgpt-image-latest"
    },
    {
      "kind": "union",
      "variants": [
        16,
        18
      ]
    },
    {
      "kind": "union",
      "variants": [
        317,
        318,
        319
      ]
    },
    {
      "kind": "literal",
      "value": "png"
    },
    {
      "kind": "literal",
      "value": "webp"
    },
    {
      "kind": "literal",
      "value": "jpeg"
    },
    {
      "kind": "union",
      "variants": [
        16,
        17,
        18,
        243,
        321,
        322
      ]
    },
    {
      "kind": "literal",
      "value": "xhigh"
    },
    {
      "kind": "literal",
      "value": "max"
    },
    {
      "kind": "union",
      "variants": [
        18,
        304,
        324,
        325,
        326
      ]
    },
    {
      "kind": "literal",
      "value": "1024x1024"
    },
    {
      "kind": "literal",
      "value": "1024x1536"
    },
    {
      "kind": "literal",
      "value": "1536x1024"
    },
    {
      "kind": "literal",
      "value": "image_generation"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 329
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "local_shell"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "environment",
          "optional": true,
          "type": 331
        },
        {
          "name": "type",
          "optional": false,
          "type": 351
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        332,
        344,
        349
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_ids",
          "optional": true,
          "type": 145
        },
        {
          "name": "memory_limit",
          "optional": true,
          "type": 277
        },
        {
          "name": "network_policy",
          "optional": true,
          "type": 282
        },
        {
          "name": "skills",
          "optional": true,
          "type": 333
        },
        {
          "name": "type",
          "optional": false,
          "type": 343
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        334
      ]
    },
    {
      "kind": "array",
      "element": 335
    },
    {
      "kind": "union",
      "variants": [
        336,
        338
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "skill_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 337
        },
        {
          "name": "version",
          "optional": true,
          "type": 27
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "skill_reference"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "description",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "source",
          "optional": false,
          "type": 339
        },
        {
          "name": "type",
          "optional": false,
          "type": 342
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "data",
          "optional": false,
          "type": 3
        },
        {
          "name": "media_type",
          "optional": false,
          "type": 340
        },
        {
          "name": "type",
          "optional": false,
          "type": 341
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "application/zip"
    },
    {
      "kind": "literal",
      "value": "base64"
    },
    {
      "kind": "literal",
      "value": "inline"
    },
    {
      "kind": "literal",
      "value": "container_auto"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "skills",
          "optional": true,
          "type": 345
        },
        {
          "name": "type",
          "optional": false,
          "type": 348
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        346
      ]
    },
    {
      "kind": "array",
      "element": 347
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "description",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "path",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "local"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "container_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 350
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "container_reference"
    },
    {
      "kind": "literal",
      "value": "shell"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "defer_loading",
          "optional": true,
          "type": 157
        },
        {
          "name": "description",
          "optional": true,
          "type": 27
        },
        {
          "name": "format",
          "optional": true,
          "type": 353
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 361
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        354,
        356
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 355
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "text"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "definition",
          "optional": false,
          "type": 3
        },
        {
          "name": "syntax",
          "optional": false,
          "type": 357
        },
        {
          "name": "type",
          "optional": false,
          "type": 360
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        358,
        359
      ]
    },
    {
      "kind": "literal",
      "value": "lark"
    },
    {
      "kind": "literal",
      "value": "regex"
    },
    {
      "kind": "literal",
      "value": "grammar"
    },
    {
      "kind": "literal",
      "value": "custom"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "description",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "tools",
          "optional": false,
          "type": 363
        },
        {
          "name": "type",
          "optional": false,
          "type": 369
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 364
    },
    {
      "kind": "union",
      "variants": [
        352,
        365
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "defer_loading",
          "optional": true,
          "type": 157
        },
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "output_schema",
          "optional": true,
          "type": 366
        },
        {
          "name": "parameters",
          "optional": true,
          "type": 183
        },
        {
          "name": "strict",
          "optional": true,
          "type": 368
        },
        {
          "name": "type",
          "optional": false,
          "type": 201
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        367
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 183
    },
    {
      "kind": "union",
      "variants": [
        21,
        80,
        81
      ]
    },
    {
      "kind": "literal",
      "value": "namespace"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "execution",
          "optional": true,
          "type": 184
        },
        {
          "name": "parameters",
          "optional": true,
          "type": 183
        },
        {
          "name": "type",
          "optional": false,
          "type": 371
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "tool_search"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "search_content_types",
          "optional": true,
          "type": 373
        },
        {
          "name": "search_context_size",
          "optional": true,
          "type": 242
        },
        {
          "name": "type",
          "optional": false,
          "type": 377
        },
        {
          "name": "user_location",
          "optional": true,
          "type": 380
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        374
      ]
    },
    {
      "kind": "array",
      "element": 375
    },
    {
      "kind": "union",
      "variants": [
        355,
        376
      ]
    },
    {
      "kind": "literal",
      "value": "image"
    },
    {
      "kind": "union",
      "variants": [
        378,
        379
      ]
    },
    {
      "kind": "literal",
      "value": "web_search_preview"
    },
    {
      "kind": "literal",
      "value": "web_search_preview_2025_03_11"
    },
    {
      "kind": "union",
      "variants": [
        21,
        381
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "city",
          "optional": true,
          "type": 20
        },
        {
          "name": "country",
          "optional": true,
          "type": 20
        },
        {
          "name": "region",
          "optional": true,
          "type": 20
        },
        {
          "name": "timezone",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": false,
          "type": 250
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "type",
          "optional": false,
          "type": 383
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "apply_patch"
    },
    {
      "kind": "literal",
      "value": "tool_search_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "role",
          "optional": false,
          "type": 38
        },
        {
          "name": "tools",
          "optional": false,
          "type": 386
        },
        {
          "name": "type",
          "optional": false,
          "type": 413
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 387
    },
    {
      "kind": "union",
      "variants": [
        191,
        202,
        229,
        231,
        239,
        330,
        352,
        370,
        372,
        382,
        388,
        399,
        402,
        403,
        406,
        407
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "allowed_tools",
          "optional": true,
          "type": 389
        },
        {
          "name": "authorization",
          "optional": true,
          "type": 27
        },
        {
          "name": "connector_id",
          "optional": true,
          "type": 254
        },
        {
          "name": "defer_loading",
          "optional": true,
          "type": 157
        },
        {
          "name": "headers",
          "optional": true,
          "type": 391
        },
        {
          "name": "require_approval",
          "optional": true,
          "type": 393
        },
        {
          "name": "server_description",
          "optional": true,
          "type": 27
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_url",
          "optional": true,
          "type": 27
        },
        {
          "name": "tunnel_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "type",
          "optional": false,
          "type": 273
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        73,
        390
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "read_only",
          "optional": true,
          "type": 157
        },
        {
          "name": "tool_names",
          "optional": true,
          "type": 145
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        392
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 3
    },
    {
      "kind": "union",
      "variants": [
        21,
        271,
        272,
        394
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "always",
          "optional": true,
          "type": 395
        },
        {
          "name": "never",
          "optional": true,
          "type": 397
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        396
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "read_only",
          "optional": true,
          "type": 157
        },
        {
          "name": "tool_names",
          "optional": true,
          "type": 145
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        398
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "read_only",
          "optional": true,
          "type": 157
        },
        {
          "name": "tool_names",
          "optional": true,
          "type": 145
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "container",
          "optional": false,
          "type": 400
        },
        {
          "name": "type",
          "optional": false,
          "type": 290
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        3,
        401
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_ids",
          "optional": true,
          "type": 145
        },
        {
          "name": "memory_limit",
          "optional": true,
          "type": 277
        },
        {
          "name": "network_policy",
          "optional": true,
          "type": 282
        },
        {
          "name": "type",
          "optional": false,
          "type": 18
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 292
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": true,
          "type": 294
        },
        {
          "name": "background",
          "optional": true,
          "type": 297
        },
        {
          "name": "input_fidelity",
          "optional": true,
          "type": 300
        },
        {
          "name": "input_image_mask",
          "optional": true,
          "type": 404
        },
        {
          "name": "model",
          "optional": true,
          "type": 303
        },
        {
          "name": "moderation",
          "optional": true,
          "type": 315
        },
        {
          "name": "output_compression",
          "optional": true,
          "type": 82
        },
        {
          "name": "output_format",
          "optional": true,
          "type": 316
        },
        {
          "name": "partial_images",
          "optional": true,
          "type": 82
        },
        {
          "name": "quality",
          "optional": true,
          "type": 320
        },
        {
          "name": "size",
          "optional": true,
          "type": 323
        },
        {
          "name": "type",
          "optional": false,
          "type": 327
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        405
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "file_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "image_url",
          "optional": true,
          "type": 27
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 329
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "description",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "tools",
          "optional": false,
          "type": 408
        },
        {
          "name": "type",
          "optional": false,
          "type": 369
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 409
    },
    {
      "kind": "union",
      "variants": [
        352,
        410
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "allowed_callers",
          "optional": true,
          "type": 192
        },
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "defer_loading",
          "optional": true,
          "type": 157
        },
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "output_schema",
          "optional": true,
          "type": 411
        },
        {
          "name": "parameters",
          "optional": true,
          "type": 183
        },
        {
          "name": "strict",
          "optional": true,
          "type": 368
        },
        {
          "name": "type",
          "optional": false,
          "type": 201
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        412
      ]
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 183
    },
    {
      "kind": "literal",
      "value": "additional_tools"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "reasoning",
          "optional": true,
          "type": 415
        },
        {
          "name": "text",
          "optional": true,
          "type": 420
        },
        {
          "name": "type",
          "optional": false,
          "type": 427
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        416
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "effort",
          "optional": true,
          "type": 417
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        16,
        17,
        243,
        321,
        322,
        418,
        419
      ]
    },
    {
      "kind": "literal",
      "value": "none"
    },
    {
      "kind": "literal",
      "value": "minimal"
    },
    {
      "kind": "union",
      "variants": [
        421
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "format",
          "optional": false,
          "type": 422
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        423,
        424
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 355
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "description",
          "optional": true,
          "type": 27
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "schema",
          "optional": false,
          "type": 425
        },
        {
          "name": "strict",
          "optional": true,
          "type": 368
        },
        {
          "name": "type",
          "optional": false,
          "type": 426
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 183
    },
    {
      "kind": "literal",
      "value": "json_schema"
    },
    {
      "kind": "literal",
      "value": "configuration_update"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "content",
          "optional": true,
          "type": 429
        },
        {
          "name": "encrypted_content",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 43
        },
        {
          "name": "summary",
          "optional": false,
          "type": 433
        },
        {
          "name": "type",
          "optional": false,
          "type": 436
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        430
      ]
    },
    {
      "kind": "array",
      "element": 431
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 432
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "reasoning_text"
    },
    {
      "kind": "array",
      "element": 434
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 435
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "summary_text"
    },
    {
      "kind": "literal",
      "value": "reasoning"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "encrypted_content",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": false,
          "type": 438
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "compaction"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": true,
          "type": 440
        },
        {
          "name": "background",
          "optional": true,
          "type": 441
        },
        {
          "name": "error",
          "optional": true,
          "type": 442
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output_format",
          "optional": true,
          "type": 451
        },
        {
          "name": "quality",
          "optional": true,
          "type": 452
        },
        {
          "name": "result",
          "optional": false,
          "type": 444
        },
        {
          "name": "revised_prompt",
          "optional": true,
          "type": 20
        },
        {
          "name": "size",
          "optional": true,
          "type": 453
        },
        {
          "name": "status",
          "optional": false,
          "type": 454
        },
        {
          "name": "type",
          "optional": false,
          "type": 456
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        18,
        295,
        296
      ]
    },
    {
      "kind": "union",
      "variants": [
        21,
        18,
        298,
        299
      ]
    },
    {
      "kind": "union",
      "variants": [
        443
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": false,
          "type": 444
        },
        {
          "name": "message",
          "optional": false,
          "type": 3
        },
        {
          "name": "moderation_details",
          "optional": true,
          "type": 445
        },
        {
          "name": "param",
          "optional": false,
          "type": 444
        },
        {
          "name": "type",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        3
      ]
    },
    {
      "kind": "union",
      "variants": [
        446
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "categories",
          "optional": false,
          "type": 73
        },
        {
          "name": "moderation_stage",
          "optional": false,
          "type": 447
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        448,
        449,
        450
      ]
    },
    {
      "kind": "literal",
      "value": "input"
    },
    {
      "kind": "literal",
      "value": "output"
    },
    {
      "kind": "literal",
      "value": "unknown"
    },
    {
      "kind": "union",
      "variants": [
        21,
        317,
        318,
        319
      ]
    },
    {
      "kind": "union",
      "variants": [
        21,
        16,
        17,
        18,
        243,
        321,
        322
      ]
    },
    {
      "kind": "union",
      "variants": [
        21,
        304,
        324,
        325,
        326
      ]
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        85,
        455
      ]
    },
    {
      "kind": "literal",
      "value": "generating"
    },
    {
      "kind": "literal",
      "value": "image_generation_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": false,
          "type": 444
        },
        {
          "name": "container_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "outputs",
          "optional": false,
          "type": 458
        },
        {
          "name": "status",
          "optional": false,
          "type": 464
        },
        {
          "name": "type",
          "optional": false,
          "type": 466
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        459
      ]
    },
    {
      "kind": "array",
      "element": 460
    },
    {
      "kind": "union",
      "variants": [
        461,
        463
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "logs",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 462
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "logs"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 376
        },
        {
          "name": "url",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        46,
        85,
        465
      ]
    },
    {
      "kind": "literal",
      "value": "interpreting"
    },
    {
      "kind": "literal",
      "value": "code_interpreter_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": false,
          "type": 468
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 472
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "command",
          "optional": false,
          "type": 73
        },
        {
          "name": "env",
          "optional": false,
          "type": 469
        },
        {
          "name": "timeout_ms",
          "optional": true,
          "type": 470
        },
        {
          "name": "type",
          "optional": false,
          "type": 471
        },
        {
          "name": "user",
          "optional": true,
          "type": 20
        },
        {
          "name": "working_directory",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 3
    },
    {
      "kind": "union",
      "variants": [
        21,
        54
      ]
    },
    {
      "kind": "literal",
      "value": "exec"
    },
    {
      "kind": "literal",
      "value": "local_shell_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 474
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "local_shell_call_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": false,
          "type": 476
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 477
        },
        {
          "name": "environment",
          "optional": true,
          "type": 480
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 481
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "commands",
          "optional": false,
          "type": 73
        },
        {
          "name": "max_output_length",
          "optional": true,
          "type": 470
        },
        {
          "name": "timeout_ms",
          "optional": true,
          "type": 470
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        478,
        479
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        344,
        349
      ]
    },
    {
      "kind": "literal",
      "value": "shell_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 483
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "max_output_length",
          "optional": true,
          "type": 470
        },
        {
          "name": "output",
          "optional": false,
          "type": 486
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 493
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        484,
        485
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 487
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "outcome",
          "optional": false,
          "type": 488
        },
        {
          "name": "stderr",
          "optional": false,
          "type": 3
        },
        {
          "name": "stdout",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        489,
        491
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 490
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "timeout"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "exit_code",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 492
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "exit"
    },
    {
      "kind": "literal",
      "value": "shell_call_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 495
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "operation",
          "optional": false,
          "type": 498
        },
        {
          "name": "status",
          "optional": false,
          "type": 505
        },
        {
          "name": "type",
          "optional": false,
          "type": 506
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        496,
        497
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        499,
        501,
        503
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "diff",
          "optional": false,
          "type": 3
        },
        {
          "name": "path",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 500
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "create_file"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "path",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 502
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "delete_file"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "diff",
          "optional": false,
          "type": 3
        },
        {
          "name": "path",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 504
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "update_file"
    },
    {
      "kind": "union",
      "variants": [
        44,
        45
      ]
    },
    {
      "kind": "literal",
      "value": "apply_patch_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 508
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "output",
          "optional": true,
          "type": 20
        },
        {
          "name": "status",
          "optional": false,
          "type": 511
        },
        {
          "name": "type",
          "optional": false,
          "type": 512
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        509,
        510
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        45,
        85
      ]
    },
    {
      "kind": "literal",
      "value": "apply_patch_call_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "error",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "tools",
          "optional": false,
          "type": 514
        },
        {
          "name": "type",
          "optional": false,
          "type": 516
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 515
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "annotations",
          "optional": true,
          "type": 183
        },
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "input_schema",
          "optional": false,
          "type": 183
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "mcp_list_tools"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 518
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "mcp_approval_request"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "approval_request_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "approve",
          "optional": false,
          "type": 520
        },
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "reason",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": false,
          "type": 521
        }
      ],
      "additional": null
    },
    {
      "kind": "boolean"
    },
    {
      "kind": "literal",
      "value": "mcp_approval_response"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "approval_request_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "error",
          "optional": true,
          "type": 523
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": true,
          "type": 20
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 530
        },
        {
          "name": "type",
          "optional": false,
          "type": 532
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        524,
        526,
        528
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": false,
          "type": 54
        },
        {
          "name": "message",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 525
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "mcp_protocol_error"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "content",
          "optional": false,
          "type": 183
        },
        {
          "name": "type",
          "optional": false,
          "type": 527
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "mcp_tool_execution_error"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": false,
          "type": 54
        },
        {
          "name": "message",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 529
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "http_error"
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        46,
        85,
        531
      ]
    },
    {
      "kind": "literal",
      "value": "calling"
    },
    {
      "kind": "literal",
      "value": "mcp_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 534
        },
        {
          "name": "id",
          "optional": true,
          "type": 27
        },
        {
          "name": "output",
          "optional": false,
          "type": 537
        },
        {
          "name": "type",
          "optional": false,
          "type": 540
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        535,
        536
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        3,
        538
      ]
    },
    {
      "kind": "array",
      "element": 539
    },
    {
      "kind": "union",
      "variants": [
        6,
        14,
        25
      ]
    },
    {
      "kind": "literal",
      "value": "custom_tool_call_output"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 542
        },
        {
          "name": "id",
          "optional": true,
          "type": 27
        },
        {
          "name": "input",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "namespace",
          "optional": true,
          "type": 27
        },
        {
          "name": "type",
          "optional": false,
          "type": 545
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        543,
        544
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "custom_tool_call"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": false,
          "type": 547
        }
      ],
      "additional": null
    },
    {
      "kind": "literal",
      "value": "compaction_trigger"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": true,
          "type": 549
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        550
      ]
    },
    {
      "kind": "literal",
      "value": "item_reference"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "code",
          "optional": false,
          "type": 3
        },
        {
          "name": "fingerprint",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "result",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 553
        },
        {
          "name": "type",
          "optional": false,
          "type": 554
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        45,
        46
      ]
    },
    {
      "kind": "literal",
      "value": "program_output"
    },
    {
      "kind": "union",
      "variants": [
        47,
        72,
        87,
        142,
        156,
        428,
        457,
        541,
        556,
        560,
        565,
        566,
        567,
        569,
        570,
        575,
        576,
        581,
        584,
        585,
        594,
        603,
        611,
        615,
        616,
        619,
        620,
        621
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": true,
          "type": 27
        },
        {
          "name": "caller",
          "optional": true,
          "type": 557
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": true,
          "type": 27
        },
        {
          "name": "namespace",
          "optional": true,
          "type": 27
        },
        {
          "name": "output",
          "optional": false,
          "type": 537
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 181
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        558,
        559
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "acknowledged_safety_checks",
          "optional": true,
          "type": 561
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": false,
          "type": 138
        },
        {
          "name": "status",
          "optional": false,
          "type": 564
        },
        {
          "name": "type",
          "optional": false,
          "type": 141
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        562
      ]
    },
    {
      "kind": "array",
      "element": 563
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "message",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        44,
        45,
        46,
        85
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "code",
          "optional": false,
          "type": 3
        },
        {
          "name": "fingerprint",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "result",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 553
        },
        {
          "name": "type",
          "optional": false,
          "type": 554
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 183
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 444
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "execution",
          "optional": false,
          "type": 568
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 187
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        185,
        186
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 444
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "execution",
          "optional": false,
          "type": 568
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "tools",
          "optional": false,
          "type": 386
        },
        {
          "name": "type",
          "optional": false,
          "type": 384
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "role",
          "optional": false,
          "type": 571
        },
        {
          "name": "tools",
          "optional": false,
          "type": 386
        },
        {
          "name": "type",
          "optional": false,
          "type": 413
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        35,
        36,
        37,
        38,
        450,
        572,
        573,
        574
      ]
    },
    {
      "kind": "literal",
      "value": "critic"
    },
    {
      "kind": "literal",
      "value": "discriminator"
    },
    {
      "kind": "literal",
      "value": "tool"
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "encrypted_content",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 438
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": true,
          "type": 440
        },
        {
          "name": "background",
          "optional": true,
          "type": 441
        },
        {
          "name": "error",
          "optional": true,
          "type": 577
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output_format",
          "optional": true,
          "type": 451
        },
        {
          "name": "quality",
          "optional": true,
          "type": 452
        },
        {
          "name": "result",
          "optional": false,
          "type": 444
        },
        {
          "name": "revised_prompt",
          "optional": true,
          "type": 20
        },
        {
          "name": "size",
          "optional": true,
          "type": 453
        },
        {
          "name": "status",
          "optional": false,
          "type": 454
        },
        {
          "name": "type",
          "optional": false,
          "type": 456
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        578
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": false,
          "type": 444
        },
        {
          "name": "message",
          "optional": false,
          "type": 3
        },
        {
          "name": "moderation_details",
          "optional": true,
          "type": 579
        },
        {
          "name": "param",
          "optional": false,
          "type": 444
        },
        {
          "name": "type",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        580
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "categories",
          "optional": false,
          "type": 73
        },
        {
          "name": "moderation_stage",
          "optional": false,
          "type": 447
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": false,
          "type": 582
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 472
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "command",
          "optional": false,
          "type": 73
        },
        {
          "name": "env",
          "optional": false,
          "type": 583
        },
        {
          "name": "timeout_ms",
          "optional": true,
          "type": 470
        },
        {
          "name": "type",
          "optional": false,
          "type": 471
        },
        {
          "name": "user",
          "optional": true,
          "type": 20
        },
        {
          "name": "working_directory",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 3
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 474
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": false,
          "type": 586
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 588
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "environment",
          "optional": false,
          "type": 591
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 481
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "commands",
          "optional": false,
          "type": 73
        },
        {
          "name": "max_output_length",
          "optional": false,
          "type": 587
        },
        {
          "name": "timeout_ms",
          "optional": false,
          "type": 587
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        54
      ]
    },
    {
      "kind": "union",
      "variants": [
        21,
        589,
        590
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        592,
        593
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 348
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "container_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 350
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 595
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "max_output_length",
          "optional": false,
          "type": 587
        },
        {
          "name": "output",
          "optional": false,
          "type": 598
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 493
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        596,
        597
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 599
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "outcome",
          "optional": false,
          "type": 600
        },
        {
          "name": "stderr",
          "optional": false,
          "type": 3
        },
        {
          "name": "stdout",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        601,
        602
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 490
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "exit_code",
          "optional": false,
          "type": 54
        },
        {
          "name": "type",
          "optional": false,
          "type": 492
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 604
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "operation",
          "optional": false,
          "type": 607
        },
        {
          "name": "status",
          "optional": false,
          "type": 505
        },
        {
          "name": "type",
          "optional": false,
          "type": 506
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        605,
        606
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        608,
        609,
        610
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "diff",
          "optional": false,
          "type": 3
        },
        {
          "name": "path",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 500
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "path",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 502
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "diff",
          "optional": false,
          "type": 3
        },
        {
          "name": "path",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 504
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 612
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": true,
          "type": 20
        },
        {
          "name": "status",
          "optional": false,
          "type": 511
        },
        {
          "name": "type",
          "optional": false,
          "type": 512
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        21,
        613,
        614
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "type",
          "optional": false,
          "type": 160
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "caller_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "approval_request_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "error",
          "optional": true,
          "type": 523
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": true,
          "type": 20
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 530
        },
        {
          "name": "type",
          "optional": false,
          "type": 532
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "error",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "tools",
          "optional": false,
          "type": 617
        },
        {
          "name": "type",
          "optional": false,
          "type": 516
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 618
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "annotations",
          "optional": true,
          "type": 183
        },
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "input_schema",
          "optional": false,
          "type": 183
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 518
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "approval_request_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "approve",
          "optional": false,
          "type": 520
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "reason",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": false,
          "type": 521
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 534
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": false,
          "type": 537
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 540
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        72,
        87,
        142,
        428,
        457,
        533,
        541,
        556,
        560,
        567,
        569,
        575,
        585,
        594,
        603,
        611,
        623,
        632,
        633,
        638,
        639,
        644,
        645,
        646,
        649,
        650,
        653,
        654,
        655
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "content",
          "optional": false,
          "type": 624
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "phase",
          "optional": true,
          "type": 31
        },
        {
          "name": "role",
          "optional": false,
          "type": 571
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 40
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 625
    },
    {
      "kind": "union",
      "variants": [
        6,
        14,
        25,
        50,
        69,
        626,
        627,
        628,
        629
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 355
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 435
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "text",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 432
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "detail",
          "optional": false,
          "type": 15
        },
        {
          "name": "file_id",
          "optional": false,
          "type": 444
        },
        {
          "name": "image_url",
          "optional": false,
          "type": 444
        },
        {
          "name": "prompt_cache_breakpoint",
          "optional": true,
          "type": 630
        },
        {
          "name": "type",
          "optional": false,
          "type": 139
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        631
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "mode",
          "optional": false,
          "type": 9
        },
        {
          "name": "ttl",
          "optional": true,
          "type": 10
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "async",
          "optional": true,
          "type": 157
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "caller",
          "optional": true,
          "type": 158
        },
        {
          "name": "created_by",
          "optional": true,
          "type": 27
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "namespace",
          "optional": true,
          "type": 27
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 163
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": true,
          "type": 440
        },
        {
          "name": "background",
          "optional": true,
          "type": 441
        },
        {
          "name": "error",
          "optional": true,
          "type": 634
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output_format",
          "optional": true,
          "type": 451
        },
        {
          "name": "quality",
          "optional": true,
          "type": 452
        },
        {
          "name": "result",
          "optional": false,
          "type": 444
        },
        {
          "name": "revised_prompt",
          "optional": true,
          "type": 20
        },
        {
          "name": "size",
          "optional": true,
          "type": 453
        },
        {
          "name": "status",
          "optional": false,
          "type": 454
        },
        {
          "name": "type",
          "optional": false,
          "type": 456
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        635
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "code",
          "optional": false,
          "type": 444
        },
        {
          "name": "message",
          "optional": false,
          "type": 3
        },
        {
          "name": "moderation_details",
          "optional": true,
          "type": 636
        },
        {
          "name": "param",
          "optional": false,
          "type": 444
        },
        {
          "name": "type",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        637
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "categories",
          "optional": false,
          "type": 73
        },
        {
          "name": "moderation_stage",
          "optional": false,
          "type": 447
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "role",
          "optional": false,
          "type": 571
        },
        {
          "name": "tools",
          "optional": false,
          "type": 386
        },
        {
          "name": "type",
          "optional": false,
          "type": 413
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "reasoning",
          "optional": true,
          "type": 640
        },
        {
          "name": "text",
          "optional": true,
          "type": 642
        },
        {
          "name": "type",
          "optional": false,
          "type": 427
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        641
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "effort",
          "optional": true,
          "type": 417
        }
      ],
      "additional": null
    },
    {
      "kind": "union",
      "variants": [
        643
      ]
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "format",
          "optional": false,
          "type": 422
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "code",
          "optional": false,
          "type": 3
        },
        {
          "name": "fingerprint",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 162
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "result",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 553
        },
        {
          "name": "type",
          "optional": false,
          "type": 554
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "action",
          "optional": false,
          "type": 647
        },
        {
          "name": "call_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": false,
          "type": 71
        },
        {
          "name": "type",
          "optional": false,
          "type": 472
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "command",
          "optional": false,
          "type": 73
        },
        {
          "name": "env",
          "optional": false,
          "type": 648
        },
        {
          "name": "timeout_ms",
          "optional": true,
          "type": 470
        },
        {
          "name": "type",
          "optional": false,
          "type": 471
        },
        {
          "name": "user",
          "optional": true,
          "type": 20
        },
        {
          "name": "working_directory",
          "optional": true,
          "type": 20
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [],
      "additional": 3
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 140
        },
        {
          "name": "type",
          "optional": false,
          "type": 474
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "error",
          "optional": true,
          "type": 20
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "tools",
          "optional": false,
          "type": 651
        },
        {
          "name": "type",
          "optional": false,
          "type": 516
        }
      ],
      "additional": null
    },
    {
      "kind": "array",
      "element": 652
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "annotations",
          "optional": true,
          "type": 183
        },
        {
          "name": "description",
          "optional": true,
          "type": 20
        },
        {
          "name": "input_schema",
          "optional": false,
          "type": 183
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "type",
          "optional": false,
          "type": 518
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "approval_request_id",
          "optional": false,
          "type": 3
        },
        {
          "name": "approve",
          "optional": false,
          "type": 520
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "reason",
          "optional": true,
          "type": 20
        },
        {
          "name": "type",
          "optional": false,
          "type": 521
        }
      ],
      "additional": null
    },
    {
      "kind": "object",
      "fields": [
        {
          "name": "approval_request_id",
          "optional": true,
          "type": 20
        },
        {
          "name": "arguments",
          "optional": false,
          "type": 3
        },
        {
          "name": "error",
          "optional": true,
          "type": 523
        },
        {
          "name": "id",
          "optional": false,
          "type": 3
        },
        {
          "name": "name",
          "optional": false,
          "type": 3
        },
        {
          "name": "output",
          "optional": true,
          "type": 20
        },
        {
          "name": "server_label",
          "optional": false,
          "type": 3
        },
        {
          "name": "status",
          "optional": true,
          "type": 530
        },
        {
          "name": "type",
          "optional": false,
          "type": 532
        }
      ],
      "additional": null
    }
  ],
  "sources_sha256": {
    "src/resources/conversations/conversations.ts": "f65731936f0822881a3f7becd29d78ec043cb8138a22131c5115e6d8dfa70a58",
    "src/resources/conversations/items.ts": "d15db5536c58775a13bce0ff4c8c0df9df6836210b0ab01dd510b6be9fda4514",
    "src/resources/responses/responses.ts": "f84e394bf08d71403c054ccb4d41d278861f2d19db3ea426e7aec789f3eb5dbb",
    "src/resources/shared.ts": "15cf6803634242502525c52098acddea16b9c2bb2439f85aa388dd43fa837455"
  },
  "license_sha256": "636eb7d79da9bb6d515a4b3fd417aa26679eb3cf16396ddab4bc55fa74e616e4",
  "compiler_sha256": "3ae902c92cc44dace175c0e69e13a4b0899f6983c6121d76b9ab8dd5795e7675"
}
)q4t_types";
}

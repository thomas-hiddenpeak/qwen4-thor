#pragma once

// Generated at configure time; no runtime release/quality attestation.
namespace q4t::server::identity {
inline constexpr char kProtocol[] = "4c221982fc27c578ad0bf3390c8e67c3c6752fbb8eb0a516e4edbefc1b9dc493";
inline constexpr char kRenderer[] = "891adaf390e59776189f8cf68006a3b8020ece14fbd3882c46f04aec3dcd2b68";
inline constexpr char kToolHistory[] = "243097e1cfefb35971a947b273dacbabf5f0c5c7de1fffab9e24048fd57a47b9";
inline constexpr char kTemplateReference[] = "c3cf9e34abf4f9e36c2d72165aa9c132d3e2a725b6c2586aaa3a8af9d7a81041";
inline constexpr char kTemplateFixture[] = "670afc63b321539c2f86aff7c15a1b351bd7bb35ca9e01373466c7ad2353f27c";
}  // namespace q4t::server::identity

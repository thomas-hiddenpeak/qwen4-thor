#include "q4t/test.h"
int main(){return q4t::test::RunTests({"realtime_chat_inf_uses_model_and_client_limits_without_loosening_number","realtime_session_bad_metadata_is_error_before_publication_or_owner"});}

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-03/0.o: \
 tests/server_realtime_chat_plan_test.cpp \
 include/q4t/server/realtime_chat_plan.h \
 include/q4t/server/responses_plan.h include/q4t/io/json.h \
 include/q4t/status.h include/q4t/server/chat_plan.h \
 include/q4t/server/access_program.h include/q4t/server/asr_service.h \
 include/q4t/server/chat_audio_output.h \
 include/q4t/server/speech_request.h include/q4t/server/chat_plan_error.h \
 include/q4t/server/actual_usage.h \
 include/q4t/server/output_constraints.h include/q4t/server/sampling.h \
 include/q4t/server/prediction.h include/q4t/server/prompt_cache_policy.h \
 include/q4t/server/moderation_options.h \
 include/q4t/server/client_policy.h include/q4t/server/client_identity.h \
 include/q4t/server/chat_template.h include/q4t/server/server_options.h \
 include/q4t/server/tts_service.h include/q4t/audio/tts_config.h \
 include/q4t/server/aligner_service.h \
 include/q4t/audio/aligner_postprocess.h \
 include/q4t/server/speaker_service.h \
 include/q4t/server/separator_service.h \
 include/q4t/runtime/sequence_capacity.h include/q4t/server/moderation.h \
 include/q4t/server/responses_input.h \
 tests/../src/server/responses_json.h include/q4t/server/output_schema.h \
 include/q4t/test.h
include/q4t/server/realtime_chat_plan.h:
include/q4t/server/responses_plan.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/chat_plan.h:
include/q4t/server/access_program.h:
include/q4t/server/asr_service.h:
include/q4t/server/chat_audio_output.h:
include/q4t/server/speech_request.h:
include/q4t/server/chat_plan_error.h:
include/q4t/server/actual_usage.h:
include/q4t/server/output_constraints.h:
include/q4t/server/sampling.h:
include/q4t/server/prediction.h:
include/q4t/server/prompt_cache_policy.h:
include/q4t/server/moderation_options.h:
include/q4t/server/client_policy.h:
include/q4t/server/client_identity.h:
include/q4t/server/chat_template.h:
include/q4t/server/server_options.h:
include/q4t/server/tts_service.h:
include/q4t/audio/tts_config.h:
include/q4t/server/aligner_service.h:
include/q4t/audio/aligner_postprocess.h:
include/q4t/server/speaker_service.h:
include/q4t/server/separator_service.h:
include/q4t/runtime/sequence_capacity.h:
include/q4t/server/moderation.h:
include/q4t/server/responses_input.h:
tests/../src/server/responses_json.h:
include/q4t/server/output_schema.h:
include/q4t/test.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/022.o: \
 tests/server_realtime_conversation_test.cpp \
 include/q4t/server/realtime_conversation.h include/q4t/io/json.h \
 include/q4t/status.h include/q4t/server/output_schema.h \
 include/q4t/test.h tests/../src/server/responses_json.h
include/q4t/server/realtime_conversation.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/output_schema.h:
include/q4t/test.h:
tests/../src/server/responses_json.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/037.o: \
 src/server/chat_template.cpp include/q4t/server/chat_template.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/generation_style.h include/q4t/server/refusal_frame.h \
 include/q4t/server/chat_tool_history.h include/q4t/server/custom_tools.h \
 include/q4t/server/http_response.h include/q4t/server/request_control.h \
 include/q4t/server/client_identity.h \
 include/q4t/server/request_progress.h include/q4t/server/actual_usage.h \
 include/q4t/server/client_policy.h include/q4t/server/http_observation.h \
 include/q4t/server/finite_response.h include/q4t/server/request_limits.h \
 include/q4t/server/input_contract.h include/q4t/server/legacy_tools.h \
 include/q4t/server/mcp_content.h include/q4t/server/chat_audio_output.h \
 include/q4t/server/speech_request.h include/q4t/server/chat_plan_error.h \
 include/q4t/server/output_schema.h \
 include/q4t/server/prompt_cache_policy.h \
 include/q4t/server/request_json.h include/q4t/server/reasoning_options.h
include/q4t/server/chat_template.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/generation_style.h:
include/q4t/server/refusal_frame.h:
include/q4t/server/chat_tool_history.h:
include/q4t/server/custom_tools.h:
include/q4t/server/http_response.h:
include/q4t/server/request_control.h:
include/q4t/server/client_identity.h:
include/q4t/server/request_progress.h:
include/q4t/server/actual_usage.h:
include/q4t/server/client_policy.h:
include/q4t/server/http_observation.h:
include/q4t/server/finite_response.h:
include/q4t/server/request_limits.h:
include/q4t/server/input_contract.h:
include/q4t/server/legacy_tools.h:
include/q4t/server/mcp_content.h:
include/q4t/server/chat_audio_output.h:
include/q4t/server/speech_request.h:
include/q4t/server/chat_plan_error.h:
include/q4t/server/output_schema.h:
include/q4t/server/prompt_cache_policy.h:
include/q4t/server/request_json.h:
include/q4t/server/reasoning_options.h:

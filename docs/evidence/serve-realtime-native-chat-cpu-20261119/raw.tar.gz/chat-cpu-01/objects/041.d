/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/041.o: \
 src/server/prediction.cpp include/q4t/server/prediction.h \
 include/q4t/io/json.h include/q4t/status.h include/q4t/server/sampling.h \
 include/q4t/server/input_contract.h
include/q4t/server/prediction.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/sampling.h:
include/q4t/server/input_contract.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/011.o: \
 src/server/reasoning_options.cpp include/q4t/server/reasoning_options.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/input_contract.h
include/q4t/server/reasoning_options.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/input_contract.h:

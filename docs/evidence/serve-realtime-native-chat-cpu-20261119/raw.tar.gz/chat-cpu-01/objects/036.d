/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/036.o: \
 src/server/chat_tool_history.cpp include/q4t/server/chat_tool_history.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/input_contract.h include/q4t/server/custom_tools.h \
 include/q4t/server/request_json.h include/q4t/server/request_limits.h
include/q4t/server/chat_tool_history.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/input_contract.h:
include/q4t/server/custom_tools.h:
include/q4t/server/request_json.h:
include/q4t/server/request_limits.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/047.o: \
 src/server/responses_mcp_binding.cpp \
 include/q4t/server/responses_mcp_binding.h \
 include/q4t/server/responses_mcp.h include/q4t/server/chat_plan.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/access_program.h include/q4t/server/asr_service.h \
 include/q4t/server/chat_audio_output.h \
 include/q4t/server/speech_request.h include/q4t/server/chat_plan_error.h \
 include/q4t/server/actual_usage.h \
 include/q4t/server/output_constraints.h include/q4t/server/sampling.h \
 include/q4t/server/prediction.h include/q4t/server/prompt_cache_policy.h \
 include/q4t/server/moderation_options.h \
 include/q4t/server/client_policy.h include/q4t/server/client_identity.h \
 include/q4t/server/chat_template.h include/q4t/server/server_options.h \
 include/q4t/server/tts_service.h include/q4t/audio/tts_config.h \
 include/q4t/server/aligner_service.h \
 include/q4t/audio/aligner_postprocess.h \
 include/q4t/server/speaker_service.h \
 include/q4t/server/separator_service.h \
 include/q4t/runtime/sequence_capacity.h \
 include/q4t/server/mcp_transport.h include/q4t/server/file_fetch.h \
 include/q4t/server/file_input.h include/q4t/server/binary_store.h \
 include/q4t/server/object_store.h include/q4t/server/grammar_process.h \
 include/q4t/server/worker_io_budget.h src/server/object_protocol.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/output_schema.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h src/server/responses_json.h \
 include/q4t/server/input_contract.h include/q4t/server/responses_input.h \
 include/q4t/server/responses_item_shape.h \
 include/q4t/server/responses_program.h include/q4t/server/state_cipher.h \
 include/q4t/server/native_crypto.h include/q4t/server/responses_state.h \
 include/q4t/server/batch_response_link.h \
 include/q4t/server/responses_plan.h include/q4t/server/moderation.h \
 include/q4t/server/schema_graph.h
include/q4t/server/responses_mcp_binding.h:
include/q4t/server/responses_mcp.h:
include/q4t/server/chat_plan.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/access_program.h:
include/q4t/server/asr_service.h:
include/q4t/server/chat_audio_output.h:
include/q4t/server/speech_request.h:
include/q4t/server/chat_plan_error.h:
include/q4t/server/actual_usage.h:
include/q4t/server/output_constraints.h:
include/q4t/server/sampling.h:
include/q4t/server/prediction.h:
include/q4t/server/prompt_cache_policy.h:
include/q4t/server/moderation_options.h:
include/q4t/server/client_policy.h:
include/q4t/server/client_identity.h:
include/q4t/server/chat_template.h:
include/q4t/server/server_options.h:
include/q4t/server/tts_service.h:
include/q4t/audio/tts_config.h:
include/q4t/server/aligner_service.h:
include/q4t/audio/aligner_postprocess.h:
include/q4t/server/speaker_service.h:
include/q4t/server/separator_service.h:
include/q4t/runtime/sequence_capacity.h:
include/q4t/server/mcp_transport.h:
include/q4t/server/file_fetch.h:
include/q4t/server/file_input.h:
include/q4t/server/binary_store.h:
include/q4t/server/object_store.h:
include/q4t/server/grammar_process.h:
include/q4t/server/worker_io_budget.h:
src/server/object_protocol.h:
include/q4t/server/application_routes.h:
include/q4t/server/output_schema.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
src/server/responses_json.h:
include/q4t/server/input_contract.h:
include/q4t/server/responses_input.h:
include/q4t/server/responses_item_shape.h:
include/q4t/server/responses_program.h:
include/q4t/server/state_cipher.h:
include/q4t/server/native_crypto.h:
include/q4t/server/responses_state.h:
include/q4t/server/batch_response_link.h:
include/q4t/server/responses_plan.h:
include/q4t/server/moderation.h:
include/q4t/server/schema_graph.h:

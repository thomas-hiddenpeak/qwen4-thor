/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/007.o: \
 src/server/schema_graph.cpp include/q4t/server/schema_graph.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/input_contract.h include/q4t/server/output_schema.h \
 include/q4t/server/schema_decimal.h include/q4t/server/schema_prefix.h
include/q4t/server/schema_graph.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/input_contract.h:
include/q4t/server/output_schema.h:
include/q4t/server/schema_decimal.h:
include/q4t/server/schema_prefix.h:

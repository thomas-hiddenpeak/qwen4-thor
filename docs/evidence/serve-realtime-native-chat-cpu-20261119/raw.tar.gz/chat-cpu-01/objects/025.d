/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/025.o: \
 src/server/realtime_chat_execution.cpp \
 include/q4t/server/realtime_chat_execution.h \
 include/q4t/server/client_policy.h include/q4t/server/client_identity.h \
 include/q4t/status.h include/q4t/server/native_chat_generation.h \
 include/q4t/server/chat_response_parser.h include/q4t/io/json.h \
 include/q4t/server/custom_tools.h \
 include/q4t/server/output_constraints.h \
 include/q4t/server/reasoning_options.h \
 include/q4t/server/schema_receipt.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h include/q4t/server/object_store.h \
 include/q4t/server/request_limits.h \
 include/q4t/server/realtime_conversation_session.h \
 include/q4t/server/realtime_conversation.h \
 include/q4t/server/realtime_response_output.h \
 include/q4t/server/actual_usage.h include/q4t/server/websocket_session.h \
 include/q4t/server/request_control.h \
 include/q4t/server/request_progress.h include/q4t/server/websocket.h \
 include/q4t/server/http_request.h include/q4t/server/http_connection.h \
 include/q4t/server/model_catalog.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/http_observation.h src/server/object_protocol.h \
 include/q4t/server/output_schema.h src/server/responses_json.h \
 include/q4t/server/finite_response.h include/q4t/server/http_response.h \
 include/q4t/server/lifetime.h include/q4t/server/request_json.h
include/q4t/server/realtime_chat_execution.h:
include/q4t/server/client_policy.h:
include/q4t/server/client_identity.h:
include/q4t/status.h:
include/q4t/server/native_chat_generation.h:
include/q4t/server/chat_response_parser.h:
include/q4t/io/json.h:
include/q4t/server/custom_tools.h:
include/q4t/server/output_constraints.h:
include/q4t/server/reasoning_options.h:
include/q4t/server/schema_receipt.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/server/object_store.h:
include/q4t/server/request_limits.h:
include/q4t/server/realtime_conversation_session.h:
include/q4t/server/realtime_conversation.h:
include/q4t/server/realtime_response_output.h:
include/q4t/server/actual_usage.h:
include/q4t/server/websocket_session.h:
include/q4t/server/request_control.h:
include/q4t/server/request_progress.h:
include/q4t/server/websocket.h:
include/q4t/server/http_request.h:
include/q4t/server/http_connection.h:
include/q4t/server/model_catalog.h:
include/q4t/server/application_routes.h:
include/q4t/server/http_observation.h:
src/server/object_protocol.h:
include/q4t/server/output_schema.h:
src/server/responses_json.h:
include/q4t/server/finite_response.h:
include/q4t/server/http_response.h:
include/q4t/server/lifetime.h:
include/q4t/server/request_json.h:

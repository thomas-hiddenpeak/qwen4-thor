/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/039.o: \
 src/server/chat_audio_output.cpp include/q4t/server/chat_audio_output.h \
 include/q4t/io/json.h include/q4t/status.h \
 include/q4t/server/speech_request.h include/q4t/server/chat_plan_error.h \
 include/q4t/server/actual_usage.h include/q4t/io/base64.h \
 include/q4t/server/output_schema.h src/server/responses_json.h
include/q4t/server/chat_audio_output.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/speech_request.h:
include/q4t/server/chat_plan_error.h:
include/q4t/server/actual_usage.h:
include/q4t/io/base64.h:
include/q4t/server/output_schema.h:
src/server/responses_json.h:

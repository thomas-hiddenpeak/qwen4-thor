/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/009.o: \
 src/server/schema_receipt.cpp include/q4t/server/schema_receipt.h \
 include/q4t/io/json.h include/q4t/status.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h include/q4t/server/schema_graph.h
include/q4t/server/schema_receipt.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/server/schema_graph.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/018.o: \
 src/trace/sha256.cpp include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h include/q4t/status.h
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/status.h:

/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/chat-cpu-01/objects/042.o: \
 src/server/prompt_cache_policy.cpp \
 include/q4t/server/prompt_cache_policy.h include/q4t/io/json.h \
 include/q4t/status.h include/q4t/server/application_routes.h \
 include/q4t/server/chat_prompt.h include/q4t/server/output_constraints.h \
 include/q4t/server/chat_template.h include/q4t/vision/processor.h \
 include/q4t/server/input_contract.h include/q4t/server/session_cache.h \
 include/q4t/server/cache_io.h include/q4t/server/grammar_process.h \
 include/q4t/server/worker_io_budget.h include/q4t/server/session_media.h \
 include/q4t/trace/sha256.h include/q4t/trace/router_trace.h \
 include/q4t/server/session_save_timing.h src/server/responses_json.h
include/q4t/server/prompt_cache_policy.h:
include/q4t/io/json.h:
include/q4t/status.h:
include/q4t/server/application_routes.h:
include/q4t/server/chat_prompt.h:
include/q4t/server/output_constraints.h:
include/q4t/server/chat_template.h:
include/q4t/vision/processor.h:
include/q4t/server/input_contract.h:
include/q4t/server/session_cache.h:
include/q4t/server/cache_io.h:
include/q4t/server/grammar_process.h:
include/q4t/server/worker_io_budget.h:
include/q4t/server/session_media.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
include/q4t/server/session_save_timing.h:
src/server/responses_json.h:

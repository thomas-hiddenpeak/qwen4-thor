// CPU diagnosis only: exact production restoration, VAD and ASR features.
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

#include "q4t/audio/asr_config.h"
#include "q4t/audio/features.h"
#include "q4t/audio/separator_resample.h"
#include "q4t/audio/vad_chunks.h"
#include "q4t/text/tokenizer.h"
#include "q4t/trace/sha256.h"

namespace {
namespace fs = std::filesystem;
using namespace q4t;
void Require(bool ok) {
  if (!ok) throw std::runtime_error("diagnostic contract failed");
}
void Check(const Status& status) {
  if (!status) throw std::runtime_error(status.message());
}
std::string Read(const fs::path& path) {
  const auto count = fs::file_size(path);
  Require(count > 0 && count < (16ULL << 20));
  std::string value(count, '\0');
  std::ifstream file(path, std::ios::binary);
  file.read(value.data(), value.size());
  Require(file.good());
  return value;
}
template <typename T>
void Save(const fs::path& path, std::span<const T> value) {
  Require(!fs::exists(path));
  std::ofstream file(path, std::ios::binary);
  file.write(reinterpret_cast<const char*>(value.data()), value.size_bytes());
  file.close();
  Require(file.good());
}
}  // namespace

int main(int argc, char** argv) {
  try {
    Require(argc == 5);
    const auto bytes = Read(argv[1]);
    Require(bytes.size() == 85040 * 2 * sizeof(float));
    std::vector<float> sources(bytes.size() / sizeof(float));
    std::memcpy(sources.data(), bytes.data(), bytes.size());
    const auto vad_file = Read(argv[2]);
    const std::span vad_bytes(
        reinterpret_cast<const uint8_t*>(vad_file.data()), vad_file.size());
    Require(trace::HexDigest(trace::Sha256(vad_bytes)) ==
            audio::kVadWeightSha256);
    audio::SileroVad vad;
    Check(vad.Load(vad_bytes));
    const fs::path assets = argv[3], out = argv[4];
    Require(!fs::exists(out) && fs::create_directory(out));
    std::unique_ptr<text::Tokenizer> tokenizer;
    Check(text::Tokenizer::LoadQwen3Asr(
        Read(assets / "vocab.json"), Read(assets / "merges.txt"),
        Read(assets / "tokenizer_config.json"), {}, &tokenizer));
    size_t emitted = 0;
    for (size_t track = 0; track < 2; ++track) {
      std::vector<float> pcm;
      Check(audio::RestoreSeparation(
          std::span(sources).subspan(track * 85040, 85040), 170080, 480000,
          &pcm));
      Check(audio::NormalizeSeparation(pcm, 480000, &pcm));
      Save<float>(out / ("track-" + std::to_string(track) + ".f32"), pcm);
      std::vector<audio::VadFrame> frames;
      Check(vad.Score(pcm, 480000, &frames));
      audio::VadChunkOptions options;
      options.silence_duration_ms = 500;
      options.max_samples = 480000;
      std::vector<audio::VadChunk> chunks;
      Check(audio::SplitVadChunks(frames, pcm.size(), options, &chunks));
      Require(chunks.size() == (track == 0 ? 3 : 1));
      for (size_t index = 0; index < chunks.size(); ++index) {
        const auto& chunk = chunks[index];
        std::cout << "chunk " << track << ' ' << index << ' '
                  << chunk.begin_sample << ' ' << chunk.end_sample << '\n';
        if (track == 0 && index == 2) continue;
        const auto part = std::span(pcm).subspan(
            chunk.begin_sample, chunk.end_sample - chunk.begin_sample);
        audio::AsrFeatures features;
        Check(audio::ComputeAsrFeatures(part, 16000, {}, &features));
        std::vector<uint32_t> prefix, suffix;
        Check(tokenizer->Encode(
            "<|im_start|>system\n<|im_end|>\n<|im_start|>user\n"
            "<|audio_start|>", &prefix, {.recognize_special_tokens = true}));
        const auto audio_start = prefix.size();
        const auto audio_tokens = audio::AsrEncodedFrames(features.frames);
        prefix.insert(prefix.end(), audio_tokens, audio::AsrConfig::kAudioPad);
        Check(tokenizer->Encode(
            "<|audio_end|><|im_end|>\n<|im_start|>assistant\nlanguage",
            &suffix, {.recognize_special_tokens = true}));
        prefix.insert(prefix.end(), suffix.begin(), suffix.end());
        Require(prefix.back() == 11528);
        const auto base = out / ("case-" + std::to_string(emitted++));
        Save<float>(base.string() + "-pcm.f32", part);
        Save<float>(base.string() + "-mel.f32", features.mel);
        Save<uint32_t>(base.string() + "-tokens.u32", prefix);
        std::cout << "case " << emitted - 1 << ' ' << track << ' ' << index
                  << ' ' << features.frames << ' ' << audio_start << '\n';
      }
    }
    Require(emitted == 3);
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}

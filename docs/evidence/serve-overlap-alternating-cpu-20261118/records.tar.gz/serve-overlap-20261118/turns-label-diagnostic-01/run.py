import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import numpy as np

from tools.native_tts.acceptance import defaults

out = Path(__file__).resolve().parent
plan = json.loads((out / 'plan.json').read_text())
assert defaults() == plan['defaults']
for path, digest in plan['sources'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
lease = int(os.environ['Q4T_MANAGED_LEASE_FD'])
os.fstat(lease)
start = time.monotonic()
result = dict(status='FAILED')
try:
    command = [plan['binary'], plan['assets'], str(out / 'plan.json'),
               str(out / 'native')]
    with (out / 'native.log').open('xb') as log:
        proc = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                              pass_fds=(lease,), timeout=150)
    result['returncode'] = proc.returncode
    assert proc.returncode == 0
    result['observations'] = []
    for index, case in enumerate(plan['cases']):
        directory = out / 'native' / ('case-' + str(index))
        bits = np.fromfile(directory / 'logits-0.bf16', '<u2')
        logits = (bits.astype('<u4') << 16).view('<f4').astype(np.float64)
        assert np.isfinite(logits).all()
        probability = np.exp(logits - logits.max())
        probability /= probability.sum()
        result['observations'].append(dict(label=case['label'],
            no_speech_probability=float(probability[2240]),
            top_token=int(np.argmax(logits)),
            top_text=(directory / 'text.txt').read_text(),
            top_probability=float(probability.max())))
    result['status'] = 'COMPLETED_DIAGNOSIS_PENDING_LEASE_RECONCILIATION'
except Exception as error:
    result['error'] = repr(error)
finally:
    result.update(seconds=time.monotonic()-start,
                  defaults_unchanged=defaults() == plan['defaults'])
    if not result['defaults_unchanged'] or result['seconds'] > 180:
        result['status'] = 'FAILED'
    (out / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(0 if result['status'].startswith('COMPLETED_') else 1)

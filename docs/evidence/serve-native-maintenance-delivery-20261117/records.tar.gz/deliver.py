"""STOPPED release of native maintenance, preserving every runtime artifact."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle,publication,profile_manager,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;O=W/'delivery-01';D=R/'build';S=D/'service-native-state'
OLD='168477d190e4b0d2c5f2f92410722b39486801500ad4397ff1c717019f022d64'
def preserved():
    return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and
        (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-','profile-selection')))}
def version():return p.read(S/'version-selection/policy.json')['state']['policy']
def exact(before,after):
    p.require({k:v for k,v in before.items() if k!='revision'}=={k:v for k,v in after.items() if k!='revision'} and
        after['revision']>before['revision'],'prior version state or budget changed')
def prepare():
    p.require(not O.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=R),'clean committed preparation required')
    current=publication.status(S);target=p.read(W/'candidate-02/receipt.json')
    acceptance=R/'docs/evidence/serve-native-maintenance-package-20261117/acceptance.json';accepted=p.read(acceptance)
    p.require(current['ready'] and current['revision']==260 and current['current']['manifest_sha256']==OLD,'predecessor differs')
    p.require(accepted['status']=='PASS_NATIVE_MAINTENANCE_PACKAGE_AND_ACTUAL' and accepted['manifest_sha256']==target['manifest_sha256'] and accepted['model_actions']==0,'package acceptance missing')
    p.require(len(list((D/'.q4t-publication/generations').iterdir()))<=31 and
        len(list((S/'version-registrations').glob('*.json')))<=15 and
        len(list((S/publication.INTENTS).glob('*.json')))<=125,'reserve capacity for all three publication steps')
    old=bundle.verify(current['current']['package'],OLD);new=bundle.verify(target['package'],target['manifest_sha256'])
    p.require(profile_manager.compatible(old,new,current['current']['package'],target['package']) is None,'profile migration changed')
    for name,digest in new['files'].items():
        if name.startswith('source/'):p.require(p.sha(R/name[7:])==digest,'control source changed')
    p.require(old['engine_manifest_sha256']==new['engine_manifest_sha256'],'engine changed')
    prior=version();p.require(prior['registry']['root_manifest_sha256']==OLD and prior['switch'] is None and prior['terminal_fault'] is None,'prior cycle not quiescent')
    oldreg=p.read(S/'version-registrations'/(prior['registry']['cycle_id']+'.json'))['registration']
    registration=version_contract.prepare(target,target,oldreg['payloads']['fallback']['descriptor'],str(uuid.uuid4()),fallback_acceptance=oldreg['fallback_acceptance'])
    O.mkdir(mode=0o700);shutil.copytree(S,O/'previous-state',symlinks=True)
    generation=(D/'q4t').resolve().parent;(O/'previous').mkdir(mode=0o700)
    for name in ('q4t','q4t.release.json','service.release.json','service.acceptance.json'):
        shutil.copyfile(generation/name,O/'previous'/name)
    original=p.read(O/'previous/service.release.json')
    review=dict(previous=current,target=target,previous_version=prior,preserved=preserved(),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),package_acceptance=accepted,engine_runtime_native_profiles_unchanged=True,new_gpu_starts=0,limits=dict(commands=15,seconds=900,model_starts=0))
    p.save(O/'review.json',review);p.save(O/'registration.json',registration)
    decision=dict(status='PASS_NATIVE_MAINTENANCE_DELIVERY',acceptance='ACCEPT_NATIVE_MAINTENANCE_DELIVERY',manifest_sha256=target['manifest_sha256'],engine_binary_sha256=accepted['engine_binary_sha256'],maintenance_acceptance=dict(path=str(acceptance),sha256=p.sha(acceptance)),runtime_business_reused='docs/evidence/serve-video-projective-composition-20261117/README.md',control_review=str(O/'review.json'),new_gpu_starts=0,performance_acceptance=False,long_stability_accepted=False,remaining_master_tasks_open=True)
    p.save(O/'decision.json',decision)
    anchor=dict(package=current['current']['package'],manifest_sha256=OLD,generation_sha256=current['current']['generation_sha256'],service_release=str(O/'previous/service.release.json'),service_release_sha256=p.sha(O/'previous/service.release.json'),manual_root_rollback_requires_stopped=True,retains_native_outer_and_cycle_migration=True,prior_package_lacks_native_maintenance=True)
    p.save(O/'recovery-anchor.json',anchor)
    release=copy.deepcopy(original);package=Path(target['package'])
    release.update(acceptance=decision['acceptance'],acceptance_record=str(O/'decision.json'),acceptance_sha256=p.sha(O/'decision.json'),package=target['package'],manifest_sha256=target['manifest_sha256'],recovery_accepted=True,engine_binary_sha256=p.sha(package/'engine/q4t'),engine_release_sha256=p.sha(package/'engine/q4t.release.json'),control_review=str(O/'review.json'),control_source_commit=review['source_commit'],previous_acceptance_record=original['acceptance_record'],version_recovery_registration=str(O/'registration.json'),version_recovery_registration_sha256=p.sha(O/'registration.json'),version_recovery_cycle_id=registration['registry']['cycle_id'],unaffected_control_recovery_reused_by_exact_source_identity=True,gpu_starts_for_install=0,rollback_receipt=str(O/'recovery-anchor.json'),rollback_sha256=p.sha(O/'recovery-anchor.json'),maintenance_acceptance=decision['maintenance_acceptance'],scope='Native service maintenance status/plan/archive/restore in sealed v20. Targeted CPU, exact package CLI and actual three-pool round trips accepted. Engine, protocol, runtime controller, native helpers, clients, profiles and policies are unchanged; existing business evidence reused. No GPU or long stability run. All remaining Serve master tasks remain required.')
    p.save(O/'service.release.json',release);p.save(O/'requests.json',{n:str(uuid.uuid4()) for n in ('publish','rollback','forward')})
    print(json.dumps(dict(status='PREPARED_NATIVE_MAINTENANCE_DELIVERY',target=target,new_gpu_starts=0)))
def run():
    review=p.read(O/'review.json');target=review['target'];ids=p.read(O/'requests.json')
    cli=Path(target['package'])/'bin/q4t';rows=[];started=time.monotonic()
    def call(label,args):
        p.require(len(rows)<15 and time.monotonic()-started<840,'delivery budget exhausted')
        argv=list(map(str,args));r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
        (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
        rows.append(dict(label=label,argv=argv,returncode=r.returncode))
        p.require(r.returncode==0,'delivery failed: '+label)
        p.require(preserved()==review['preserved'],'core/client/outer/profile state changed')
        return json.loads(r.stdout)
    def publish(label,prior,revision):
        return call(label,[cli,'service','publish','--state',S,'--default-root',D,'--package',target['package'],'--manifest-sha256',target['manifest_sha256'],'--service-release',O/'service.release.json','--expected-manifest-sha256',prior,'--expected-revision',revision,'--request-id',ids[label]])
    try:
        p.require(call('previous-check',[cli,'service','check','--state',S,'--package',review['previous']['current']['package'],'--manifest-sha256',OLD])['desired']=='STOPPED','previous not stopped')
        p.require(call('candidate-check',[cli,'service','check'])['status']=='PASS','candidate check failed')
        result=publish('publish',OLD,260);p.require(result['durable'] and result['revision']==262,'initial publication')
        registered=call('register',[D/'q4t','service','version-register','--state',S,'--registration',O/'registration.json','--expected-cycle',review['previous_version']['registry']['cycle_id']])
        p.require(registered['registered'] and not registered['fallback_consumed'],'registration failed')
        candidate_cycle=version();p.save(O/'candidate-cycle.json',candidate_cycle)
        result=call('rollback',[cli,'service','publish-rollback','--state',S,'--default-root',D,'--package',target['package'],'--manifest-sha256',target['manifest_sha256'],'--generation-sha256',review['previous']['current']['generation_sha256'],'--expected-manifest-sha256',target['manifest_sha256'],'--expected-revision',262,'--request-id',ids['rollback']])
        p.require(result['durable'] and result['revision']==264,'rollback publication');exact(review['previous_version'],version())
        p.require(call('rollback-check',[D/'q4t','service','check','--state',S])['desired']=='STOPPED','rollback entry failed')
        rollback_version=call('rollback-version',[D/'q4t','service','version-status','--state',S])
        p.require(rollback_version['root_manifest_sha256']==OLD and rollback_version['cycle_id']==review['previous_version']['registry']['cycle_id'],'historical entry cannot read its own cycle')
        result=publish('forward',OLD,264);p.require(result['durable'] and result['revision']==266,'forward publication');exact(candidate_cycle,version())
        for action in ('check','status','observe'):
            value=call('default-'+action,[D/'q4t','service',action,'--state',S]);p.require(value['status']=='PASS' if action=='check' else value['state']=='STOPPED','default health')
        profiles=call('profiles',[D/'q4t','service','profiles-status','--state',S]);p.require(profiles['selected']=='primary','profile changed')
        outer=call('outer',[D/'q4t','service','outer-status','--state',S]);p.require(outer['enabled'] and outer['charged_total']==0,'outer budget changed')
        final=call('publication',[D/'q4t','service','publish-status','--state',S]);p.require(final['ready'] and final['revision']==266 and final['current']['manifest_sha256']==target['manifest_sha256'],'final publication differs')
        maintenance=call('maintenance',[D/'q4t','service','maintenance-status','--state',S]);p.require(maintenance['manifest_sha256']==target['manifest_sha256'] and maintenance['publication_revision']==266,'new default lacks maintenance')
        p.save(O/'result.json',dict(status='PASS_NATIVE_MAINTENANCE_DELIVERED',seconds=time.monotonic()-started,commands=rows,publication=final,profiles=profiles,outer=outer,maintenance=maintenance,original_cycle=review['previous_version'],candidate_cycle=candidate_cycle,final_cycle=version(),preserved=review['preserved'],state='STOPPED',new_gpu_starts=0,all_master_tasks_active=True))
        print(json.dumps(dict(status='PASS_NATIVE_MAINTENANCE_DELIVERED',revision=266,commands=len(rows))))
    except BaseException as error:
        p.save(O/'result.json',dict(status='FAILED',commands=rows,error=repr(error),seconds=time.monotonic()-started));raise
if __name__=='__main__':
    os.umask(0o077);{'prepare':prepare,'run':run}[sys.argv[1]]()

"""Frozen allocation-guard followup: two profiles, four real generations."""
import copy, fcntl, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_realtime import mcp_acceptance as m, mcp_recovery_checks as c, managed
from tools.serve_realtime.duplex_acceptance import capture_actor
from tools.serve_service.package import read,save,sha,require
full=m.full;encrypted=m.encrypted;O=W/'binding-business-02'
LIMITS=dict(starts=2,chats=4,controls=1200,seconds=600,websocket_sessions=2,ingress_starts=2)
SUCCESS='PASS_MCP_BINDING_GUARD_PRIMARY_LIGHT'

def check(plan):
 require(plan['format']=='q4t-mcp-binding-guard-business-v1' and plan['limits']==LIMITS and plan['requests']=={} and plan['automatic_retries'] is False,'frozen scope')
 built=read(W/'ci-capacity-runtime-01/result.json')
 require(built['status']=='BUILD_PASS' and built['warnings']==0 and plan['binary_sha256']==built['binary_sha256'],'runtime build')
 for n,h in plan['reviewed_sources'].items():require(sha(R/n)==h,'runtime source drift: '+n)
 previous=read(W/'sdk-business-04/plan.json')
 for n in ('profiles','native_assets','model_assets'):require(plan[n]==previous[n],'unchanged capacity/assets')
 require(plan['base']['settings']==previous['base']['settings'],'settings unchanged')

def prepare():
 require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'commit source first')
 require(read(R/'docs/evidence/serve-realtime-mcp-ci-capacity-20261120/acceptance.json')['status']=='PASS_TARGETED_MCP_BINDING_CAPACITY_CPU','CPU required')
 O.mkdir(mode=0o700);plan=read(W/'sdk-business-04/plan.json');b=R/'.q4t-work/serve-custom-tools-20261108/engine-build'
 base,identity=full.candidate_build_base(plan['base'],b/'q4t',b)
 sources=read(W/'ci-capacity-runtime-01/plan.json')['sources'];sources.update(read(b/'generated/q4t/server/chat_protocol_sources.json'))
 plan.update(format='q4t-mcp-binding-guard-business-v1',output=str(O),binary=str(b/'q4t'),binary_sha256=sha(b/'q4t'),base=base,candidate_identity=identity,reviewed_sources=sources,limits=LIMITS,planned={k:v for k,v in LIMITS.items() if k not in ('seconds','controls')},scope=__doc__,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),identity=dict(plan['identity'],binary_sha256=sha(b/'q4t'),protocol_sha256=base['protocol_sha256']),tls=m.certificate(O/'credentials'))
 names=subprocess.check_output(['git','ls-files','src','include','cmake','CMakeLists.txt','tools/serve_realtime','tools/serve_recovery','tools/serve_service','tools/serve_responses','tools/serve_grammar_reap','tools/serve_schema_v2','tools/serve_protocol','tools/examples','tools/evalscope','tools/release','docs/MODEL.md'],text=True).splitlines()
 plan['sources']={n:sha(R/n) for n in names}
 for p in (Path(__file__).resolve(),W/'ci-capacity-runtime-01/plan.json',W/'ci-capacity-runtime-01/result.json',Path(plan['ingress']),Path(plan['tls']['certificate']),Path(plan['tls']['key'])):plan['sources'][str(p)]=sha(p)
 plan['protected']={str(R/n):sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')}
 check(plan);save(O/'plan.json',plan);print(json.dumps(dict(plan=str(O/'plan.json'),limits=LIMITS,binary=plan['binary_sha256'])))

class Stage(m.Stage):
 limits=LIMITS;success_status=SUCCESS
 def __init__(self,plan):
  check(plan);encrypted.Stage.__init__(self,plan)
  self.counts.update(websocket_sessions=0,ingress_starts=0);self.peer=self.edge=None;self.observed={}
 def profile_business(self):
  name=self.profile_name;label=name+'-binding';plan=self.plan
  policy=read(self.out/'client-policy.json');key=hashlib.sha256(os.urandom(32)).hexdigest()
  self.budget('ingress_starts')
  self.edge=m.NativeIngress(self.out/label,plan['ingress'],plan['public_port'],plan['port'],plan['operations_port'],policy['gateway_token'],{encrypted.CLIENT:key},plan['tls'],lambda:self.model.poll() is None)
  guard=encrypted.foreground.base.lifecycle.guard;self.history[self.edge.process.pid]=guard.processes()[self.edge.process.pid]
  def observe(suffix):
   status,raw=self.http('/metrics',label=label+'-'+suffix);require(status==200,'metrics')
   values=encrypted.foreground.base.lifecycle.parse_metrics(raw)
   state=full.profile_realtime.state(values,encrypted.CLIENT)
   state.update({n:int(values[k]) for n,k in managed.METRICS.items() if n not in state})
   managed.state_shape(state);return state
  before=observe('before');require(managed.clean(before),'initial resources');remote_before=self.peer.snapshot()
  self.budget('websocket_sessions')
  for _ in range(2):self.budget('chats')
  args=dict(mode='complete',history=[],arguments=m.peer.ARGUMENTS,base_url=f"https://127.0.0.1:{plan['public_port']}/v1",api_key=key,ca_file=plan['tls']['certificate'],mcp_url=self.peer.url,mcp_token=self.peer.secret,journal_file=str(self.out/(label+'.events.jsonl')))
  require(set(args)=={'mode','history','arguments','base_url','api_key','ca_file','mcp_url','mcp_token','journal_file'} and args['arguments']==c.c.ARGUMENTS,'SDK argument contract')
  env={k:v for k,v in os.environ.items() if k not in ('NODE_OPTIONS','NODE_PATH','LD_PRELOAD')};env['Q4T_NODE_SDK_DIR']=plan['sdk']['sdk_directory']
  receipt=self.out/(label+'.sdk.json')
  process=capture_actor([plan['sdk']['node']['path'],str(R/'tools/serve_realtime/mcp_recovery_sdk.mjs')],args,receipt,self.out/(label+'.stderr'),env,200)
  require(receipt.stat().st_size<=8<<20,'receipt bound');value=read(receipt)
  self.same_model();self.drained(label+'-drain');after=observe('after-0');end=time.monotonic()+5;index=0
  while not managed.clean(after) and time.monotonic()<end:
   time.sleep(.02);index+=1;after=observe('after-'+str(index))
  journal=Path(args['journal_file']);require(journal.stat().st_size<=8<<20,'journal bound');events=[json.loads(l) for l in journal.read_text().splitlines()]
  remote=self.peer.snapshot();witness=dict(session=value,journal=events,remote_before=remote_before,remote=remote,before=before,after=after,source=plan['document_source'])
  save(self.out/(label+'-witness.json'),witness)
  require(process.returncode==0,'actual SDK protocol failure')
  observed=c.check_session(value,'complete','official-openai-wss',events,plan['document_source'],[])
  c.accounting(before,after,observed);c.peer(remote_before,remote,observed,plan['document_source']);require(managed.clean(after),'resource leak')
  self.observed[name]=observed;save(self.out/'observations.json',self.observed)
  for p in [receipt,journal,self.out/(name+'-model.log'),*(p for p in (self.out/'application-objects').rglob('*') if p.is_file())]:require(self.peer.secret.encode() not in p.read_bytes(),'MCP credential leaked')
  self.edge.close();save(self.out/(name+'-entry-cleanup.json'),dict(exit_code=self.edge.process.returncode,pid=self.edge.process.pid,port_released=True));self.edge=None
 def business(self):full.Stage.business(self)

def finalize():
 plan=read(O/'plan.json');check(plan);result=read(O/'result.json')
 require(result['status']==SUCCESS and 0<result['seconds']<=600 and all(result['counts'][k]==v for k,v in LIMITS.items() if k not in ('seconds','controls')),'bounded work incomplete')
 for n,h in {**plan['sources'],**plan['protected'],**plan['native_assets']}.items():require(sha(R/n)==h,'postflight drift: '+n)
 clean=[read(O/n) for n in ('primary-cleanup.json','cleanup.json')]
 environment=full.environment(read(O/'lease/exit.json'),[json.loads(l) for l in (O/'lease/nvml-queries.jsonl').read_text().splitlines()],clean)
 events=[json.loads(l) for l in (O/'lease/events.jsonl').read_text().splitlines()];require(not any(e.get('conflicts') for e in events) and events[-1]['event']=='lease_released','lease incomplete')
 observations={}
 for name in ('primary','light'):
  witness=read(O/(name+'-binding-witness.json'));observed=c.check_session(witness['session'],'complete','official-openai-wss',witness['journal'],witness['source'],[])
  c.accounting(witness['before'],witness['after'],observed);c.peer(witness['remote_before'],witness['remote'],observed,witness['source']);require(managed.clean(witness['after']),'resource leak')
  require(read(O/(name+'-entry-cleanup.json'))['exit_code']==0,'entry cleanup');observations[name]=observed
 guard=encrypted.foreground.base.lifecycle.guard;processes=guard.processes()
 require(not any(processes.get(int(pid),{}).get('start_ticks')==v['start_ticks'] for row in clean for pid,v in row['owned'].items()),'owned process remains')
 full.background.probe_ports(tuple(plan[k] for k in ('port','operations_port','public_port','private_peer_port')))
 with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 environment['lease_result_sha256']=sha(O/'lease/exit.json')
 save(O/'acceptance.json',dict(status=SUCCESS,environment=environment,counts=result['counts'],seconds=result['seconds'],observations=observations,default_unchanged=True,model_quality_status='PASS' if all(o['model_quality_status']=='PASS' for o in observations.values()) else 'FAIL',original_failures_preserved=True,new_managed_faults=False))
 print(json.dumps(read(O/'acceptance.json')))

if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='prepare':prepare()
 elif mode=='finalize':finalize()
 else:
  require(mode=='run','mode')
  def interrupted(_signum,_frame):raise TimeoutError('bounded binding followup interrupted')
  signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGALRM,interrupted);signal.alarm(600)
  try:
   with encrypted.foreground.base.lifecycle.child_subreaper():Stage(read(O/'plan.json')).run()
  finally:signal.alarm(0)

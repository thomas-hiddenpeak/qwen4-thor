import json,re,hashlib
from pathlib import Path
import numpy as np
W=Path(__file__).resolve().parent;P=W/'capture-01'
HS=2560;HC=10240;LAYERS=48
full=sorted([f for f in P.glob('tensor_m*.moe_in.bin') if f.stat().st_size==1069*HS*2],key=lambda f:int(re.search(r'_m(\d+)',f.name)[1]))
prefix=sorted([f for f in P.glob('tensor_m*.moe_in.bin') if f.stat().st_size==1062*HS*2],key=lambda f:int(re.search(r'_m(\d+)',f.name)[1]))
suffix=sorted([f for f in P.glob('tensor_m*.moe_in.bin') if f.stat().st_size==7*HS*2],key=lambda f:int(re.search(r'_m(\d+)',f.name)[1]))
assert len(full)==len(prefix)==len(suffix)==LAYERS,(len(full),len(prefix),len(suffix))
starts={k:int(re.search(r'_m(\d+)',v[0].name)[1]) for k,v in [('full',full),('prefix',prefix),('suffix',suffix)]}
records=[]
for layer in range(LAYERS):
 for stem,width in [('trunk_in',HC),('attn_out',HS),('moe_in',HS),('moe_out',HS),('out',HC)]:
  path=P/f"tensor_m{starts['full']+layer}.{stem}.bin"
  a=np.memmap(path,dtype='<u2',mode='r').reshape(1069,width)
  for kind,sl in [('prefix',slice(0,1062)),('suffix',slice(1062,None))]:
   other=P/f"tensor_m{starts[kind]+layer}.{stem}.bin"
   b=np.memmap(other,dtype='<u2',mode='r').reshape(-1,width);x=a[sl]
   different=x!=b;count=int(different.sum())
   if count:
    xf=(x.astype(np.uint32)<<16).view(np.float32);bf=(b.astype(np.uint32)<<16).view(np.float32)
    diff=xf.astype(np.float64)-bf.astype(np.float64)
    rec=dict(layer=layer,stage=stem,part=kind,elements=x.size,different=count,max_abs=float(np.abs(diff).max()),relative_l2=float(np.linalg.norm(diff)/max(np.linalg.norm(xf.astype(np.float64)),1e-30)),first=np.argwhere(different)[0].tolist())
   else:rec=dict(layer=layer,stage=stem,part=kind,elements=x.size,different=0)
   records.append(rec)
result=dict(starts=starts,records=records)
(W/'capture-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for part in ['prefix','suffix']:
 rows=[r for r in records if r['part']==part and r['different']]
 print(part,'first differences',rows[:8])
print('all captures bytes',sum(f.stat().st_size for f in P.glob('*.bin')))

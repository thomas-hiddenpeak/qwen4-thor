import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['prepare-day-01','check-day-01']:
 v=read(W/(n+'.json'));assert v['exit_code']==0 and v['default_unchanged']
plan=read(W/'day-01/plan.json');handoff=read(W/'day-01/handoff.json')
current=read(W/'delivery-01/result.json')['publication']['current']
assert plan['package']['manifest_sha256']==current['manifest_sha256'] and handoff['user_runs_day'] and not handoff['automatically_started']
assert not (W/'day-01/execution').exists()
O=R/'docs/evidence/serve-chat-moderation-day-handoff-20261117';O.mkdir()
files=[(W/'day-01/plan.json','plan.json'),(W/'day-01/handoff.json','handoff.json'),(W/'archive_day.py','archive_day.py')]
for n in ['prepare-day-01','check-day-01']:
 for ext in ['json','stdout','stderr']:files.append((W/(n+'.'+ext),n+'.'+ext))
with tarfile.open(O/'handoff.tar.gz','w:gz') as tar:
 for p,n in files:tar.add(p,arcname=n,recursive=False)
a=dict(status='PASS_CURRENT_DAY_HANDOFF',revision=204,manifest_sha256=current['manifest_sha256'],service_id=plan['service_id'],plan=str(W/'day-01/plan.json'),plan_sha256=sha(W/'day-01/plan.json'),archive_sha256=sha(O/'handoff.tar.gz'),executed=False,owner='user',new_gpu_starts=0,default_unchanged=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text('''# rev204用户长稳交接

当前精确包的day prepare/check通过，私有状态与原生outer已初始化，
未启动服务或占用GPU，默认保持STOPPED。24小时由用户执行；原rev196
及rev188计划按原身份保留，没有修改旧计划散列或把短验称作长稳。

当前审核引擎通过针对性功能业务；原连续60秒短验属于rev188。两者
分别绑定各自身份，不能把旧连续short称作新引擎重跑。实际入口、
清理命令、后续身份变化时重新准备办法见[交接文档](../../SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)。
''')
p=R/'docs/SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md';s=p.read_text();start=s.index('当前rev196');end=s.index('## 当前已准备的入口')
s=s[:start]+'''当前rev204包`'''+current['manifest_sha256']+'''`
已完成真实审核主轻、批准SSE/输入block/多choice评分、存储/隔离的
4启动/17请求功能短验及可回退发布；[业务证据](evidence/serve-chat-moderation-business-20261117/README.md)、
[交付证据](evidence/serve-chat-moderation-delivery-20261117/README.md)。原失败另保留，
累计8启动/32请求；不能把原失败链改称通过。连续60秒/3组长稳驱动
短验属于前驱rev188的509c3bcb包，其原始
[证据](evidence/serve-native-soak-business-20261116/README.md)保留，不能
冒称当前审核引擎重跑该连续short。当前原生控制/helper按精确身份复用。

[当前精确day prepare/check](evidence/serve-chat-moderation-day-handoff-20261117/README.md)
已完成，24小时未运行，由用户选择维护窗口显式开展。

'''+s[end:]
s=s.replace('556e2ba7-98a3-4ef8-879b-0c712d609707',plan['service_id']).replace('serve-chat-annotations-20261116','serve-chat-moderation-repair-20261117');p.write_text(s)
p=R/'docs/STATUS.md';s=p.read_text();s=s.replace('PR37检查与实际合main继续，按新\n默认刷新用户day交接，全部33项master保持active。','PR37检查与实际合main继续，当前\n用户day交接已prepare/check、未启动，全部33项master保持active。');p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 if task['id']=='Q03':task['current_native_day_handoff']=a|dict(evidence='evidence/serve-chat-moderation-day-handoff-20261117/README.md')
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/log/2026-11-17.md';s=p.read_text();head,rest=s.split('\n',1);p.write_text(head+'''\n
## rev204用户day交接已刷新

2026-11-17：当前包的原生24小时入口prepare/check通过，0模型启动，
私有服务STOPPED，默认状态不变。原计划保留，未执行长稳；原rev188
连续short与当前功能验收分别记录。下一步PR37实际检查/合main，以及
全部剩余兼容、媒体缓存/后端、冷启动与资源任务。
'''+rest)
print(json.dumps(a))

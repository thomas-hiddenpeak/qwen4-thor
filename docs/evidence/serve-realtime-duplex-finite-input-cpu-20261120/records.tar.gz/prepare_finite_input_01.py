from pathlib import Path
import re,json,subprocess,hashlib
W=Path(__file__).parent
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
for n in files:
 if not n.endswith(('.cpp','.h')):continue
 diff=subprocess.check_output(['git','diff','--unified=0','--',n],text=True);lines=[]
 for b,c in re.findall(r'^@@.*\+(\d+)(?:,(\d+))? @@',diff,re.M):
  if c!='0':lines+=['--lines='+b+':'+str(int(b)+int(c or '1')-1)]
 if lines:subprocess.run(['clang-format','-i',*lines,n],check=True)
new=[]
for n in files:
 if not n.startswith('tests/') or not n.endswith('.cpp'):continue
 prior=set(re.findall(r'Q4T_TEST\(\s*(\w+)',subprocess.check_output(['git','show','HEAD:'+n],text=True)))
 new += [x for x in re.findall(r'Q4T_TEST\(\s*(\w+)',Path(n).read_text()) if x not in prior]
assert len(new)==10,new
affected=['realtime_audio_history_budget_includes_erased_borrowers','realtime_audio_history_exact_decoder_reused_across_ring_splits','realtime_audio_history_failed_decode_releases_reservation_atomically','realtime_input_owner_manual_commit_joins_actual_conversation','realtime_input_owner_unknown_commit_cannot_publish_or_consume','realtime_input_owner_waiting_admission_keeps_original_deadline','realtime_input_owner_semantic_reserves_before_public_commit','realtime_transcription_cancel_unblocks_producer_and_preserves_borrow','realtime_continuous_aggregate_storage_includes_cancelled_pending_jobs','realtime_composed_input_recovery_preserves_audio_context_and_clock','realtime_session_recovers_new_audio_after_borrowed_fault_without_replay','realtime_input_idle_retains_actual_silent_audio_for_native_asr']
p=W/'finite-input-plan-01.json';plan=json.loads(p.read_text());plan.update(new_tests=new,affected_tests=affected,tests=new+affected);p.write_text(json.dumps(plan,indent=2)+'\n')
p=Path('tools/release/required_host_tests.txt');s=p.read_text();p.write_text(s+''.join(n+'\n' for n in new if n not in s))
p=Path('tools/serve_audit/inventory.json');v=json.loads(p.read_text());v['duplex_finite_input_20261120']=dict(state='development_targeted_cpu_pending',scope=plan['scope'],tests=new,limits=plan['limits'],default_revision=376)
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
def refresh(x):
 if isinstance(x,dict):
  for k,z in list(x.items()):
   if k in changed and isinstance(z,str) and len(z)==64 and Path(k).is_file():x[k]=hashlib.sha256(Path(k).read_bytes()).hexdigest()
   else:refresh(z)
 elif isinstance(x,list):
  for z in x:refresh(z)
refresh(v);p.write_text(json.dumps(v,indent=2)+'\n')
s=(W/'build_mixed_history_01.py').read_text().replace('mixed-history-build-01','finite-input-build-01').replace('d0498c558130b1a0a8cde729dac127e3f514b25985ada896a361eab27ce09442','b1207ef300e6d99b1a3d123678eb7976ff8d5bf0ea2db0dc4bee5df317aa0c03').replace('ordered mixed audio history and per-content native ownership','independent finite audio preparation and shared native queue ownership');(W/'build_finite_input_01.py').write_text(s)
s=(W/'run_mixed_history_cpu_01.py').read_text().replace('mixed-history-cpu-01','finite-input-cpu-01').replace('mixed-history-build-01','finite-input-build-01').replace('mixed-history-plan-01','finite-input-plan-01').replace('len(new)==18','len(new)==22').replace('tests=18','tests=22');(W/'run_finite_input_cpu_01.py').write_text(s)
p=Path('docs/STATUS.md');s=p.read_text();at=s.index('\n## 当前实际默认');s=s[:at]+'''
有限音频处理与队列已成组开发：复用PCM/G.711和配置降噪，保持独立
波形与内容索引，不占用append ring的样本位置。全类输入共用音频
预算、32项队列和一小时累计时长，恢复不退还；保留实际借用/期限。
冻结10新+12相关CPU及20来源反例/120秒待验，实际item/response接线继续。
''' +s[at:];p.write_text(s)
p=Path('docs/log/2026-11-20.md');s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 直接有限音频处理与共用原生队列开发

日期：2026-11-20。

做了什么：有限音频复用PCM/G.711、流式同算法降噪与同一128MiB音频
预算，独立保存波形和来源内容索引，避免混入append ring。实际ASR
沿用同一准入/期限/删除借用；有限与连续输入共用32项待执行和一小时
累计样本寿命，局部恢复不退还。提供只能收紧的组件寿命上限用于
有界边界验证；默认仍一小时。冻结10新+12相关CPU/20来源反例/120秒，
尚待构建/验证；0GPU、默认rev376不变。

为什么：同一会话的新输入形式不能另开不受控预算、提前释放异步
借用或污染旧输入缓存。纯组件尚未等于实际mixed item入口可用。

下一步：针对验证、实际item/response入口组合、统一业务短验、恢复
交付及全部master。
''' +s[i:])

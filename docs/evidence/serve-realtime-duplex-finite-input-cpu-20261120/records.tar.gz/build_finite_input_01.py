from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'finite-input-build-01';B=R/'.q4t-work/serve-file-search-20261112/host';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
assert shutil.disk_usage(R).free > (96 << 20)
old=B/'q4t_host_tests';assert sha(old)=='b1207ef300e6d99b1a3d123678eb7976ff8d5bf0ea2db0dc4bee5df317aa0c03'
os.link(old,O/'previous_host_tests');old.unlink()
for name in ['generated/q4t/server/chat_protocol_sources.json','CMakeCache.txt']:
 p=B/name;shutil.copy2(p,O/('previous-'+p.name))
detached=[]
for p in [*B.rglob('*.a'),*B.rglob('*.o'),*(B/'generated').rglob('*')]:
 if p.is_symlink() or not p.is_file() or p.stat().st_nlink<2:continue
 s=p.stat();h=sha(p);tmp=p.with_name(p.name+'.prompt-detach');assert not tmp.exists();shutil.copy2(p,tmp);assert sha(tmp)==h;tmp.replace(p);detached.append(dict(path=str(p),sha256=h,old_links=s.st_nlink))
paths=sorted(set(subprocess.check_output(['git','ls-files','src','include','tests','cmake','CMakeLists.txt'],cwd=R,text=True).splitlines()+[]));cmd=['cmake','--build',str(B),'--target','q4t_host_tests','--parallel','4']
save(O/'plan.json',dict(scope='Necessary incremental host build for independent finite audio preparation and shared native queue ownership; no test execution/GPU action',command=cmd,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources={n:sha(R/n) for n in paths},protected=protected,previous_binary_sha256=sha(O/'previous_host_tests'),detached=detached,gpu_actions=0,free_bytes_before=shutil.disk_usage(R).free))
start=time.monotonic()
with (O/'build.log').open('w') as f:
 try:code=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=1800).returncode
 except subprocess.TimeoutExpired:code=124
raw=(O/'build.log').read_text();warnings=raw.count('warning:');unchanged=all(sha(Path(n))==h for n,h in protected.items())
result=dict(status='BUILD_PASS' if code==0 and not warnings and unchanged else 'BUILD_FAIL',exit_code=code,seconds=time.monotonic()-start,warnings=warnings,gpu_actions=0,default_unchanged=unchanged,prior_unchanged=sha(O/'previous_host_tests')=='b1207ef300e6d99b1a3d123678eb7976ff8d5bf0ea2db0dc4bee5df317aa0c03',binary_sha256=sha(B/'q4t_host_tests') if (B/'q4t_host_tests').exists() else None,free_bytes_after=shutil.disk_usage(R).free)
save(O/'result.json',result);print(json.dumps(result),flush=True)
if code:print(raw[-6000:],flush=True)
raise SystemExit(0 if result['status']=='BUILD_PASS' else 1)

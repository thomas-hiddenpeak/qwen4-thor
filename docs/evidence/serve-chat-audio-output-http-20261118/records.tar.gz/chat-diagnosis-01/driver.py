import copy, json, signal, time, traceback
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from tools.native_tts import chat_acceptance as chat
from tools.serve_service.package import read, save, require, sha

class Diagnose(chat.Stage):
    def budget(self, kind):
        limits = self.plan['diagnosis']
        require(time.monotonic()-self.started < limits['seconds']-40, 'diagnostic deadline')
        require(self.counts[kind] < limits[kind], 'diagnostic attempts: '+kind)
        self.counts[kind] += 1; save(self.out/'counts.json', self.counts)
    def business(self):
        original = self.plan['requests']['json']
        self.budget('chats')
        body = dict(request=original, include_prompt=True)
        save(self.out/'preflight.request.json',body)
        status, raw = self.http('/v1/chat/preflight', body, label='preflight')
        require(status == 200, 'preflight failed')
        request = copy.deepcopy(original);request['stream']=True
        request['stream_options']=dict(include_usage=True,include_obfuscation=False)
        status, raw = self.post('chat',request)
        transcript='';errors=[]
        for line in raw.splitlines():
            if not line.startswith(b'data: ') or line[6:]==b'[DONE]': continue
            event=json.loads(line[6:])
            if 'error' in event: errors.append(event['error'])
            for choice in event.get('choices',[]):
                transcript += choice.get('delta',{}).get('audio',{}).get('transcript','')
        save(self.out/'chat-observation.json',dict(status=status,transcript=transcript,errors=errors,done=b'data: [DONE]' in raw))
        require(transcript, 'no actual main transcript observed')
        self.drained('chat-drain')
        body=dict(model=chat.speech.MODEL,input=transcript,voice=original['audio']['voice'],response_format='wav')
        save(self.out/'speech.request.json',body);self.budget('chats')
        status, raw = self.http('/v1/audio/speech',body,label='speech')
        save(self.out/'speech-observation.json',dict(status=status,bytes=len(raw),error=json.loads(raw) if status!=200 else None))
        self.drained('speech-drain')
    def run(self):
        result=dict(status='FAILED')
        def expire(*_args): raise TimeoutError('diagnosis deadline')
        signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,260)
        try:
            self.start();self.business()
            result['status']='DIAGNOSIS_OBSERVED_NOT_BUSINESS_ACCEPTANCE'
        except BaseException:
            result['error']=traceback.format_exc();raise
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            try: self.cleanup()
            finally:
                result.update(counts=self.counts,seconds=time.monotonic()-self.started,defaults_unchanged=chat.defaults()==self.plan['defaults'])
                save(self.out/'result.json',result)

if __name__=='__main__':
    plan=read(Path(__file__).with_name('plan.json'))
    require(sha(__file__)==plan['diagnostic_driver_sha256'],'diagnostic source drift')
    with chat.lifecycle.child_subreaper():Diagnose(plan).run()

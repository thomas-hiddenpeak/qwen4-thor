import json,re,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;P=W/'profiles-01'
import sys
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
accepted=read(P/'acceptance.json');require(accepted['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION','qualification absent')
require(read(W/'version-driver-cpu-01.json')['exit_code']==0,'driver failed')
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [ROOT/'build/service/engine/client-policy.json',ROOT/'build/service/gateway-policy.json',P/'client-policy.json']:
 if p.is_file():collect(read(p))
e=ROOT/'docs/evidence/serve-chat-cache-profile-business-20261116';e.mkdir();files=[]
for p in P.rglob('*'):
 if not p.is_file():continue
 if p.relative_to(P).parts[0] in ('client-policy.json','application-objects','application-objects-prompt-cache'):continue
 files.append((p,'profiles-01/'+str(p.relative_to(P))))
for n in ['prepare_package.py','prepare_retained.py','media_version.py','test_media_version.py','freeze-delivery-01.json','archive_profiles.py']:
 files.append((W/n,n))
for stem in ['prepare-profiles-01','gpu-profiles-01','finalize-profiles-01','prepare-package-01','prepare-retained-01','version-driver-cpu-01','sealed-package-cpu-01']:
 for suffix in ['json','stdout','stderr']:files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for n in ['package-01/prepare-review.json','package-01/native-build.json','package-01/receipt.json','retained-01/review.json']:
 files.append((W/n,n))
for p,_ in files:
 raw=p.read_bytes();require(not any(x in raw for x in secrets),'secret in public archive')
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),'private key')
with tarfile.open(e/'business.tar.gz','w:gz') as tar:
 for p,name in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=name)
for n in ['acceptance.json','qualified/registry.json','qualified/primary.json','qualified/light.json']:
 target=e/n;target.parent.mkdir(exist_ok=True);shutil.copy2(P/n,target)
review=read(W/'package-01/prepare-review.json');retained=read(W/'retained-01/review.json')
save(e/'archive.json',dict(files=len(files),sha256=sha(e/'business.tar.gz'),secret_scan_matches=0,package=review['package_sha256'],fallback=retained['fallback']['manifest_sha256'],control_delta=review['control_source_delta'],native_delta=review['native_source_delta'],native_executables_identical=review['native_executables_identical'],driver_cpu_cases=3,version_business_pending=True))
(e/'README.md').write_text('''# Chat标准缓存候选主轻资格与封包通过

0851dab3同一严格租约2启动/10请求/86.044秒，82项NVML正常，两侧均
完成schema、真实文档工具/实际SHA续答、embedding、视频；主轻能力
相同，仅MTP开关不同。注册表绑定当前引擎，不改写旧引擎资格。

正式78d6bd7b和保留控制c789291b封包及两项sealed namespace及一项新能力正负控CPU通过。
控制源码、原生helper源码和四程序字节与rev166相同；客户端源码与文件身份保持不变。
旧压力/监护按身份复用，新包版本组合仍待1启动/2生成/300秒和
2启动/4生成/1设备探测/600秒两段短验，要求冻结镜像视频/历史/SSE及
缓存执行/隔离合同完整保留。此处回退是旧控制/当前引擎，不是独立旧引擎。

当前默认rev166保持，自有资源清理，实际策略Key/对象库未入公开归档。
不作完整质量/性能或全部兼容声明，全部master继续。
''')
p=ROOT/'docs/STATUS.md';s=p.read_text();h='## 最近完成的实现和验证\n\n';p.write_text(s.replace(h,h+'''[Chat标准缓存候选主轻资格/封包通过](evidence/serve-chat-cache-profile-business-20261116/README.md)：
2启动/10请求/86.044秒，82项NVML正常；两侧实际schema/工具/SHA续答/
embedding/视频通过。正式78d6bd7b、保留控制c789291b及两项sealed CPU
通过；控制和四个原生程序字节保持。继续1启动/2生成及2启动/4生成/
1探测的精确包版本验收，rev166未改，全部master继续。

''',1))
p=ROOT/'docs/log/2026-11-16.md';s=p.read_text();h='# 开发日志（2026-11-16）\n\n';p.write_text(h+'''## Chat标准缓存候选主轻资格与精确封包

- 日期：2026-11-16。0851dab3两侧实际schema、文档工具/SHA续答、
  embedding、视频通过，2启动/10请求/86.044秒，82项NVML正常。
- 正式78d6bd7b与保留控制c789291b封包、两项真实sealed与一项能力正负控CPU通过。
  控制与四程序字节同rev166；客户端字节也保持。
- 为什么：新引擎须绑定自己的配置资格，不能挪用旧引擎接受记录；
  未改控制压力/监护仍按身份复用，避免无意义重跑。
- 下一步：分别最多1启动/2生成/300秒、2启动/4生成/1探测/600秒完成
  精确包与实际版本回退，冻结视频历史/SSE和缓存执行/隔离合同保持。
  默认未改，全部master继续。
- 证据：[配置与封包](../evidence/serve-chat-cache-profile-business-20261116/README.md)。

'''+s[len(h):])
print(json.dumps(dict(package=review['package_sha256'],fallback=retained['fallback']['manifest_sha256'],files=len(files))))

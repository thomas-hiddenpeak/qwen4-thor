"""Archive original failed input checks and exact targeted repair receipts."""
import hashlib,importlib.util,io,json,subprocess,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-live-input-cpu-20261121'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
a=read(W/'input-cpu-01/result.json');b=read(W/'input-cpu-02/result.json')
assert a['status']=='FAIL' and b['status']=='PASS'
assert all(x['sources_unchanged'] and x['protected_unchanged'] for x in (a,b))
first=read(W/'input-cpu-01/plan.json');last=read(W/'input-cpu-02/plan.json')
with tarfile.open(W/'input-cpu-01/failed-source.tar.gz','r:gz') as t:
 for n,h in first['sources'].items():assert sha(t.extractfile(n).read())==h
changed=[n for n,h in first['sources'].items() if last['sources'][n]!=h]
assert set(changed)=={'src/server/live_audio_input.cpp','tests/server_live_audio_input_test.cpp'}
spec=importlib.util.spec_from_file_location('inventory',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=R/'tools/serve_audit/inventory.json';inventory=read(p);actual=m.current_surface(R)
expected={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','include/q4t/server/live_audio_input.h','src/server/live_audio_input.cpp','include/q4t/server/realtime_conversation_input.h','include/q4t/server/realtime_transcription_session.h','src/server/realtime_conversation_input.cpp'}
diff={n for n,h in actual['sources_sha256'].items() if inventory['sources_sha256'].get(n)!=h}
save(W/'input-inventory-before.json',dict(changed_sources=sorted(diff),errors=m.check(inventory,actual)));assert diff==expected,(diff,expected)
# Typed ranges originate from actual job ownership, existing wire contract
# unchanged. Input muting/partial-sample and close/drain proof reviewed above.
for name in sorted(expected):inventory['sources_sha256'][name]=actual['sources_sha256'][name]
inventory['live_audio_input_review_20261121']=dict(sources=sorted(expected),evidence='docs/evidence/serve-live-input-cpu-20261121/README.md',status='CPU verified native processor/history adapter; real VAD/ASR model and route binding pending',no_route_accepted=True)
save(p,inventory)
r=subprocess.run(['python3','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(W/'input-inventory-reviewed.json').write_text(r.stdout);assert r.returncode==0,r.stdout
files={}
for folder in ('input-plan-01','input-cpu-01','input-cpu-02'):
 for p in sorted((W/folder).iterdir()):
  assert p.is_file();files[folder+'/'+p.name]=p.read_bytes()
for name in ('input_cpu_01.py','input_cpu_02.py','archive_input_01.py','input-inventory-before.json','input-inventory-reviewed.json'):files['driver/'+name]=(W/name).read_bytes()
for name,digest in last['sources'].items():
 raw=(R/name).read_bytes();assert sha(raw)==digest,name;files['accepted/'+name]=raw
assert not O.exists();O.mkdir();index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,bits in sorted(files.items()):
  index[n]=dict(sha256=sha(bits),bytes=len(bits));info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(bits),0o600,0;t.addfile(info,io.BytesIO(bits))
save(O/'index.json',index)
result=dict(status='PASS_NATIVE_LIVE_INPUT_TARGETED_REPAIR',original_tests=14,original_pass=10,original_fail=4,repaired_targeted_tests=8,distinct_tests=15,original_failure_and_source_preserved=True,changed_since_original=changed,original_cpu_seconds=a['cpu_seconds'],repair_cpu_seconds=b['cpu_seconds'],host_binary_sha256=b['binary_sha256'],typed_native_audio_history_and_worker=True,controlled_asr_vad_callbacks=True,real_model_business_accepted=False,inventory_mutation_checks=22,new_gpu_starts=0,default_revision=426,default_changed=False,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',result);print(json.dumps(result))

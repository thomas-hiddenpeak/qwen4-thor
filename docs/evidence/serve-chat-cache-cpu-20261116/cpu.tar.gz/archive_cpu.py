import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stems=['generated-01','generated-check-01','source-gate-01','host-build-01','engine-build-01','host-test-01','schema-cpu-01','differential-01','driver-cpu-02']
assert '20 tests, 20 passed, 0 failed, 0 skipped' in (W/'host-test-01.stdout').read_text()
assert 'Ran 4 tests' in (W/'schema-cpu-01.stderr').read_text()
assert 'Ran 3 tests' in (W/'driver-cpu-02.stderr').read_text()
assert json.loads((W/'differential-01/result.json').read_text())['passed']
for stem in stems:
 v=json.loads((W/(stem+'.json')).read_text());assert v['exit_code']==0 and v['default_unchanged']
 if 'build' in stem:assert not re.search(r'\bwarning:|\berror:',(W/(stem+'.stdout')).read_text()+(W/(stem+'.stderr')).read_text())
files=[]
for stem in stems+['driver-cpu-01']:
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
for p in (W/'differential-01').iterdir():
 if p.is_file():files.append((p,'differential/'+p.name))
for n in ['freeze-01.json','freeze-driver-01.json','required-01.txt','cases-01.txt','run.py','archive_cpu.py','test_chat_cache_acceptance_before_import_fix.py']:files.append((W/n,n))
for p,n in files:assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),n
out=R/'docs/evidence/serve-chat-cache-cpu-20261116';out.mkdir()
with tarfile.open(out/'cpu.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n)
result=dict(status='PASS_TARGETED_CPU',cpp_tests=20,schema_tests=4,acceptance_oracle_tests=3,native_schema_cases=20,source_anchors=715,source_negative_controls=7,zero_warning_builds=True,engine_binary_sha256=sha(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t'),default_revision=166,default_unchanged=True,gpu_runs=0,actual_business_pending=True,archive_sha256=sha(out/'cpu.tar.gz'),master_complete=False)
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'README.md').write_text('''# Chat 标准缓存执行合同：针对性 CPU 通过

2026-11-16，20项C++、4项schema、3项业务判定器正负控和20项native/
schema对照通过；715来源/7负控及生成物检查通过，host/engine/probe
零警告。候选引擎 `'''+result['engine_binary_sha256']+'''`。

覆盖Chat专有mode/ttl、默认隐式、内容断点的全部文本角色、原请求及
模板字节不变、精确子块/NFC边界、最近80唯一查找边界和4个写槽、
显式无断点禁读写、旧Responses控制保持、原生scope冲突、TTL独立、
PDF实际展开后断点移动到最后一个内容块，以及存储重启/客户隔离。
判定器要求实际SSD写入、MTP/target恢复日志和usage一致，不以HTTP200
或字段接受代替命中。第一次判定器测试因独立导入chat_client失败，
0业务用例执行；改用显式模块路径后三项通过，原失败和源快照保留。

rev166未改，0GPU；不宣称真实缓存业务/媒体状态恢复/性能或长稳通过。
下一步最多1启动/8条Chat/900秒：真实JSON/SSE状态复用、suffix变化、
独立client/key、显式禁缓存、默认隐式写入和目标解码。全部33项master
继续，不以本阶段验收代替总目标。
''')
print(json.dumps(result))

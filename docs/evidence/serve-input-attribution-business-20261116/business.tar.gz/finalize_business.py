import json,re,tarfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R));W=Path(__file__).resolve().parent
from tools.serve_protocol import input_attribution_acceptance as a
from tools.serve_service.package import read,save,sha,require
partial=read(W/'partial-review.json');P=W/'business-02';plan=read(P/'plan.json');result=read(P/'result.json');guard=read(P/'lease/exit.json');cleanup=read(P/'cleanup.json');native=read(W/'native-cleanup.json')
require(plan['binary_sha256']==partial['binary_sha256']==sha(plan['binary']),'engine changed')
require(result['status']=='FAILED' and result['counts']['chats']==2 and result['counts']['starts']==1 and 'full stored Responses snapshot changed' in result['error'],'unexpected original stage')
require(guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1,'environment rejection')
queries=[json.loads(l) for l in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];events=[json.loads(l) for l in (P/'lease/events.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and not q['observed_errors'] for q in queries),'NVML invalid')
require(all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events),'environment competition')
require(cleanup['model_exit']==0 and not cleanup['remaining'] and cleanup['ports_released'] and cleanup['lease_continuously_held'],'cleanup incomplete')
changed={p for p,h in plan['sources'].items() if sha(R/p)!=h};require(changed=={'tools/serve_protocol/input_attribution_acceptance.py','tools/serve_protocol/test_input_attribution.py'},'unreviewed source drift')
for n,h in plan['protected'].items():require(sha(n)==h,'default changed')
values={}
for label in ('response_default','response_null'):
 sdk=read(P/(label+'.sdk.json'));get=read(P/(label+'-get.sdk.json'));require(sdk['ok'] and get['ok'] and len(sdk['exchanges'])==len(get['exchanges'])==1,'SDK replay/failure')
 if label=='response_default':raw=json.loads((P/(label+'.wire')).read_bytes())
 else:
  stream=a.wire_events((P/(label+'.wire')).read_text());require(all(not a.errors(e,'response_event') for e in stream),'invalid event wire')
  require(all(e['response']['reasoning']['effort']=='medium' and e['response']['service_tier']=='default' for e in stream if 'response' in e),'stream options differ');raw=stream[-1]['response']
 saved=json.loads((P/(label+'-get.wire')).read_bytes());a.check_response(raw);a.check_stored_snapshots(raw,saved,sdk['result'],get['result']);values[label]=dict(id=raw['id'],actual_tier=raw['service_tier'],effort=raw['reasoning']['effort'],answer=a.responses.text(raw),raw_snapshot_equal=True)
metrics=read(P/'response_null-get-drain.metrics.json')[-1];require(metrics['q4t_requests_total']==metrics['q4t_requests_success_total']==2 and metrics['q4t_requests_error_total']==0,'core counter failure')
log=(P/'model.log').read_text();require(a.IDENTIFIER not in log,'raw identifier leaked')
for body in plan['requests'].values():
 lines=[l for l in log.splitlines() if '[q4t][request]' in l and 'event=end' in l and 'id='+body['request_id']+' ' in l];require(len(lines)==1 and 'outcome=success' in lines[0] and 'safety_identifier_sha256='+a.expected_digest(a.IDENTIFIER) in lines[0],'attribution failure')
require(read(P/'response_default-delete.sdk.json')['result']['deleted'] and native['status']=='PASS_NATIVE_STORED_API_CPU_CLEANUP' and native['statuses']==[200,200,404],'owned state cleanup')
require(read(W/'projection-cpu-01.json')['exit_code']==0,'oracle CPU failed')
summary=dict(status='ACCEPT_INPUT_ATTRIBUTION_BUSINESS',binary_sha256=plan['binary_sha256'],cleanup_complete=True,total_starts=2,total_generations=7,unique_business_cases=6,actual_document=partial['actual_document'],first_stage=partial,second_stage=dict(result_original=result,strict_lease_seconds=events[-1]['monotonic']-events[0]['monotonic'],nvml_queries=len(queries),values=values,raw_snapshot_equality=True,sdk_derived_text_checked=True),native_cleanup=native,driver_failures_preserved=True,acceptance_basis='Original four Chat passes, two actual Responses JSON/SSE/GET captures, targeted raw-versus-SDK oracle CPU and native CPU cleanup. Failed harness receipts not relabelled.',supplemental_validation_gpu_starts=0,default_unchanged=True,performance_acceptance=False,full_model_quality=False,master_complete=False)
e=R/'docs/evidence/serve-input-attribution-business-20261116';e.mkdir()
files=[]
for p in P.rglob('*'):
 if p.is_file() and 'objects' not in p.relative_to(P).parts:files.append((p,'business-02/'+str(p.relative_to(P))))
for name in ('finalize_business.py','responses_followup.py','freeze-followup-01.json','freeze-delivery-01.json','cleanup_stored_response.cpp','build_cleanup.py','cleanup_actual_state.py','native-cleanup.json','cleanup-native.stdout','cleanup-native.stderr','partial-review.json'):
 files.append((W/name,name))
for stem in ('gpu-business-02','prepare-business-02','projection-cpu-01','cleanup-build-01','cleanup-native-01'):
 for suffix in ('json','stdout','stderr'):files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for p,n in files:require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),'private key in '+n)
with tarfile.open(e/'business.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda v:v[1]):t.add(p,arcname=n)
summary['archive_sha256']=sha(e/'business.tar.gz');save(e/'acceptance.json',summary)
(e/'README.md').write_text(f'''# 输入归属、实际档位和Responses默认：实际业务接受

2026-11-16，候选7a23cb30累计2启动/7生成，覆盖六项不同业务；两个
严格租约分别{partial['strict_lease_seconds']:.3f}/{summary['second_stage']['strict_lease_seconds']:.3f}秒，NVML
{partial['nvml_queries']}/{len(queries)}项正常。运行时及二进制未改，第一轮四条Chat
JSON/SSE/实际档位/归属/一次文档工具/SHA续答按精确身份复用。
第二轮Responses省略与null实际medium、回答42、JSON/SSE事件/usage、
存储GET原始快照完全一致，核心请求计数2/2成功。

两次驱动失败均保留，不修改原始result/guard：第一次GET遗漏include
导致logprobs投影；补验第二次GET的SDK附加output_text，流式原始结果
没有该客户端便利字段。现在显式include，并分别严格校验实际wire
相等、SDK派生text正确；一项CPU正/负控和实际捕获重验证通过，0新增
GPU。原始wire没有变化，未通过删除字段来放松原始响应判定。

第一项对象HTTP DELETE已过。第二项因脚本提前结束，使用相同编译
来源的生产PlanResponsesRead/ReadResponsesState在CPU上读取真实自有
对象并删除，GET/DELETE/再次GET为200/200/404；原状态私有备份保留。
这不是宣称又跑过HTTP DELETE。自有模型/端口/锁清理通过，失败现场
私有fixture数据按证据保留，默认rev158未改。

已冻结后续主轻2启动/10请求，以及精确保留/正式包版本恢复短验。
未改native/control/client证据复用；无全模型质量、性能或长稳结论。
继续可回退发行和全部master，阶段通过不等于完整兼容。
''')
print(json.dumps({k:summary[k] for k in ['status','binary_sha256','total_starts','total_generations','cleanup_complete']}))

import shlex,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[2];w=Path(__file__).resolve().parent;b=r/'.q4t-work/serve-file-search-20261112/host'
subprocess.run(['/usr/bin/g++-14','-std=c++23','-Wall','-Wextra','-I'+str(r/'include'),'-c',str(w/'cleanup_stored_response.cpp'),'-o',str(w/'cleanup.o')],check=True)
argv=shlex.split((b/'CMakeFiles/q4t_host_tests.dir/link.txt').read_text());argv=[x for x in argv if not x.startswith('-Wl,--dependency-file=')]
for i,x in enumerate(argv):
 if x.endswith('/tests/test_main.cpp.o'):argv[i]=str(w/'cleanup.o')
 if i and argv[i-1]=='-o':argv[i]=str(w/'cleanup-stored-response')
subprocess.run(argv,cwd=b,check=True)

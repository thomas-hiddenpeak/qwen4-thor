#include <chrono>
#include <iostream>
#include <string>

#include "q4t/server/object_store.h"
#include "q4t/server/output_schema.h"
#include "q4t/server/responses_api.h"

int main(int argc, char** argv) {
  const int worker = q4t::server::MaybeRunObjectWorker(argc, argv);
  if (worker >= 0) return worker;
  if (argc != 3) return 2;
  using namespace q4t::server;
  ObjectStoreOptions options;
  options.directory = argv[1];
  ObjectStore objects(options);
  const std::string target = "/v1/responses/" + std::string(argv[2]);
  StateAccess access{"local:anonymous",
                     std::chrono::steady_clock::now() + std::chrono::seconds(15),
                     {}};
  for (const auto* method : {"GET", "DELETE", "GET"}) {
    ResponsesReadPlan plan;
    auto result = PlanResponsesRead(method,
        std::string(method) == "GET"
            ? target + "?include[]=message.output_text.logprobs" : target,
        "", &plan);
    if (!result.ok()) return 3;
    ResponsesReplay replay;
    result = ReadResponsesState(objects, plan, access, &replay);
    std::cout << method << " " << result.http_status << " "
              << OutputJson(result.value) << '\n';
    if (std::string(method) == "DELETE" &&
        (!result.ok() || !result.value.GetBool("deleted"))) return 4;
  }
  return 0;
}

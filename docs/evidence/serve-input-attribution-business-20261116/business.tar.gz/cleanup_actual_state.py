import json,shutil,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;p=w/'business-02';raw=json.loads((p/'response_null-get.wire').read_bytes());identifier=raw['id']
assert identifier.startswith('resp-') or identifier.startswith('resp_'),identifier
shutil.copytree(p/'objects',w/'business-02-objects-before-cleanup')
r=subprocess.run([str(w/'cleanup-stored-response'),str(p/'objects'),identifier],capture_output=True,text=True,timeout=25)
(w/'cleanup-native.stdout').write_text(r.stdout);(w/'cleanup-native.stderr').write_text(r.stderr);r.check_returncode()
rows=[s.split(' ',2) for s in r.stdout.splitlines()];assert [(a,int(b)) for a,b,c in rows]==[('GET',200),('DELETE',200),('GET',404)],rows
assert json.loads(rows[0][2])==raw
assert json.loads(rows[1][2])['deleted'] is True
(w/'native-cleanup.json').write_text(json.dumps(dict(status='PASS_NATIVE_STORED_API_CPU_CLEANUP',actual_response_id=identifier,raw_snapshot_unchanged=True,before_snapshot_backup=str(w/'business-02-objects-before-cleanup'),native_public_read_delete_api=True,http_endpoint_retested=False,statuses=[200,200,404],model_starts=0,gpu_runs=0),indent=2)+'\n')
print('actual native state GET/DELETE/404 passed; no model or GPU')

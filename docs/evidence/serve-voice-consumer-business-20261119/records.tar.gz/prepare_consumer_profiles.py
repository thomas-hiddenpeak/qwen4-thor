"""Freeze one explicit Base-only saved-voice qualification attempt."""
import argparse,json,shutil,subprocess
from pathlib import Path
from tools.serve_recovery import profile_acceptance as driver
from tools.serve_recovery import profile_evidence as evidence
from tools.serve_service import package
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'consumer-profiles-01'
assert not subprocess.check_output(['git','status','--porcelain'])
assert package.read(V/'consumer-cpu-01/result.json')['status']=='PASS'
assert package.read(V/'consumer-input-check-01/result.json')['status']=='PASS_REAL_SAVED_VOICE_INPUTS_BOUND'
assert shutil.disk_usage(R).free>(256+64)<<20
args=argparse.Namespace(package=V/'service-package-01/bundle',binary=V/'voice-service-candidate-05/q4t',output=O,candidate_build=None,candidate_release=None,capacity_config=None,tts_config=None,tts_base_config=None,voice_fixtures=None,voice_consumer=V/'voice-sdk-tls-02/run/registered-state.json',tts_checkpoint_sampling=False,asr_config=None,asr_audio=None,chat_audio=False,speaker_audio=None,separator_audio=None,port=19202)
driver.prepare(args);p=package.read(O/'plan.json')
assert p['limits']==dict(starts=2,chats=26,controls=2000,seconds=900)
assert not {'native_asr','native_tts'}&p['identity'].keys()
assert p['planned']['native_voice_registrations']==0 and p['planned']['registered_voice_transcriptions']==0
files=[Path(__file__).resolve(),V/'consumer-cpu-01/result.json',V/'consumer-input-check-01/result.json',R/'docs/evidence/serve-voice-sdk-tls-20261119/result.json']
assert package.sha(files[-1])==evidence.VOICE_CONSUMER_WITNESS['evidence_sha256']
rows={}
for key,stage,target in [('speech','voice-sdk-tls-01',evidence.VOICE_TARGETS[0]),('chat','voice-sdk-tls-02',evidence.VOICE_TARGETS[1])]:
 audio=V/stage/'run'/(key+'.wav');proof=V/stage/'run'/(key+'-asr.quality.json')
 assert (audio.stat().st_size,package.sha(audio))==evidence.VOICE_CONSUMER_AUDIO[key]
 quality=package.read(proof);assert quality['expected']==target and quality['response']['text']==target
 rows[key]=dict(audio=str(audio),audio_sha256=package.sha(audio),transcription=str(proof),transcription_sha256=package.sha(proof),new_inference=False)
 files += [audio,proof]
for f in files:p['sources'][str(f)]=package.sha(f)
p['reused_complete_audio_content']=rows
p['scope']='Base-only explicit deployment, actual saved voice consumption in both profiles; no ASR, alignment, VAD, speaker, separator or builtin TTS configured. Original state copied separately, per-synthesis consent and client ownership, both revoked routes, full audio witness equality, core tool/schema/embedding/media retained. No performance or new ASR claim; no change to full default deployment.'
p['stop_policy']='First failure or ENV_ABORT stops this attempt; preserve all original records and own cleanup; no replay.'
package.save(O/'plan.json',p)
print(json.dumps(dict(plan=str(O/'plan.json'),limits=p['limits'],sources=len(p['sources']),planned=p['planned'])))

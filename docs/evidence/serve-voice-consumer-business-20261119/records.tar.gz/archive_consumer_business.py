"""Archive real Base-only consumer profiles and explicit optional package."""
import base64,hashlib,json,tarfile
from pathlib import Path
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'consumer-profiles-01';B=V/'consumer-package-01';C=V/'consumer-package-check-review-01';O=R/'docs/evidence/serve-voice-consumer-business-20261119'
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qualified=read(P/'acceptance.json');result=read(P/'result.json');checked=read(C/'result.json');manifest=read(B/'bundle/manifest.json')
assert qualified['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and result['counts']['starts']==2 and result['counts']['chats']==26
assert qualified['environment']['all_queries_ok'] and qualified['environment']['cleanup_complete']
assert read(P/'lease/exit.json')['status']=='COMPLETED'
assert checked['status']=='PASS_OPTIONAL_BASE_ONLY_PACKAGE_AND_PRIVATE_STATE'
assert sha(B/'bundle/manifest.json')==checked['package_sha256']
files={};omitted={}
for directory in [P,V/'consumer-package-check-01',C]:
 for path in directory.rglob('*'):
  if not path.is_file() or path.is_symlink():continue
  name=str(path.relative_to(V));parts=path.relative_to(directory).parts
  private=(any('application-objects' in n or n=='state' for n in parts) or
      path.name in ('client-policy.json','clients.json','gateway-policy.json') or
      path.name.endswith('.request.body'))
  if private:omitted[name]=dict(bytes=path.stat().st_size,sha256=sha(path));continue
  files[name]=path
for name in ['prepare_consumer_profiles.py','prepare_consumer_package.py','derive_consumer_package.py','check_consumer_package.py','resume_consumer_package_check.py','archive_consumer_business.py']:
 files[name]=V/name
for name in ['decision.json','receipt.json','native-build.json']:
 files['consumer-package-01/'+name]=B/name
for name in ['engine/q4t.release.json','bundle/manifest.json']:
 files['consumer-package-01/'+name]=B/name
secrets=[]
def collect(value):
 if isinstance(value,dict):
  for k,x in value.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(value,list):
  for x in value:collect(x)
for p in [B/'gateway-policy.json',B/'clients.json',R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for name,path in files.items():
 raw=path.read_bytes();assert not any(secret in raw for secret in secrets),name
 assert b'-----BEGIN '+b'PRIVATE KEY-----\n' not in raw,name
assert not O.exists();O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n');(O/'omitted-private.json').write_text(json.dumps(omitted,indent=2)+'\n')
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
a=dict(status='ACCEPT_BASE_ONLY_SAVED_VOICE_PROFILES_AND_OPTIONAL_PACKAGE',actual_model_starts=2,business_posts=26,seconds=result['seconds'],nvml_queries=qualified['environment']['nvml_queries'],nvml_all_ok=True,cleanup_complete=True,source_commit=read(P/'plan.json')['source_commit'],engine_sha256=result['binary_sha256'],qualification_format='q4t-profile-business-v12',registry_sha256=qualified['registry_sha256'],same_saved_owner_and_condition=True,reference_state_changed=False,registration_backends_disabled_with_zero_loads=True,registered_voice_condition_encoder_loads=0,complete_audio_witness_comparisons=4,new_asr_inferences=0,prior_independent_asr_content_reused=True,revoked_speech_and_chat_rejected=True,optional_package_sha256=checked['package_sha256'],optional_package=str(B/'bundle'),private_state=str(V/'consumer-package-check-01/state'),private_state_check_commands=5,reused_completed_check_commands=2,new_continuation_check_commands=3,initial_certificate_flag_assertion_failed=True,original_failure_preserved=True,certificate_check_applicable=False,client_state_checked=True,default_changed=False,default_revision=326,automatic_managed_switching_accepted=False,full_model_quality=False,performance_claim=False,listening_and_similarity_accepted=False,files=len(files),private_files_omitted=len(omitted),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Base-only已有音色消费：真实资格与可选封装

两档配置同一严格GPU租约，2启动/26业务POST/{result['seconds']:.3f}秒，
{a['nvml_queries']}次NVML正常；最终资格、来源、进程/端口/锁清理通过。
引擎仍是C05 `{a['engine_sha256']}`，编译714来源未变。

从原真实SDK注册快照分别复制两个独立状态目录，不修改原始授权、
音色ID、客户所有权和2048维条件。仅启用Base、原核心/embedding/媒体；
ASR、alignment、VAD、speaker、separator和内置TTS均disabled且零加载，
注册条件encoder保持configured且零加载。实际Base Speech/Chat均完成，
四份完整WAV与原独立无提示ASR及两档注册测试见证逐字节一致；本轮
没有新ASR。完整音频历史、跨客户404、缺注册资产503、授权撤销后
Speech/Chat双路404，以及原schema/真实文档工具/embedding/视频通过。

可选原生封装 `{a['optional_package_sha256']}` 已按v12资格准备；私有
状态init/check/status/profiles/observe共5步骤完成，没有启动服务。
首次断言误将HTTP包的credentials_checked当成客户鉴权检查；该字段
实际表示TLS证书检查，原check已PASS且client_state_valid=true。原失败
保留，仅离线确认适用性并完成剩余3命令，未重做init/check或GPU。
封装为隔离夹具，私有API Key没有写入证据；其完整源码/资格可校验。

已有音色部署可只配置`--tts-base-model-dir`，并沿用原`--object-store-dir`
和客户ID对应的`--client-policy-file`。变更API Key不应变更音色所有者ID；
重命名客户不会转移授权。创建新consent/voice仍需配置原生ASR/VAD/
speaker；Base-only不会伪造登记成功。此模式是显式部署选择，不能用作
自动删减现有完整服务能力的许可。默认rev326和其恢复预算保持。

此次未重新注入Base-only自动监护故障，不扩张原受监护默认资格；
原型正常播放听感/相似度、参考音频ICL、提示词音色、Live及总计划
剩余项继续。下一步补齐已批准的4倍速度内容反例，再推进ICL/实时。
''')
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
intro=f'''[Base-only真实消费与可选封装通过](evidence/serve-voice-consumer-business-20261119/README.md)：
2启动/26POST/{result['seconds']:.3f}秒，118次NVML正常、完整清理。
同原客户/授权/音色条件，四完整音频见证及撤销双路通过，注册后端
零加载；5项私有STOPPED封装步骤完成，TLS标记误断言原失败保留。
默认rev326不变；继续主线检查、已批准4倍内容反例、ICL/提示词/Live。

'''
p=R/'docs/STATUS.md';put(p,p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-19.md';h,b=p.read_text().split('\n',1);put(p,h+'\n\n## 2026-11-19 — Base-only已有音色实际资格与可选封装\n\n'+intro.replace('(evidence/','(../evidence/')+'为什么：缺少注册后端不能妨碍合法既有音色消费；下一步：4倍内容反例和剩余音频实现，维持总目标active。\n'+b)
p=R/'docs/serve-master-goals-v2.json';j=read(p);entry=a|dict(evidence='evidence/serve-voice-consumer-business-20261119/README.md');s=j['native_tts_progress']['custom_voice']['service'];s['base_only_consumer']=entry;s['package_recovery']['base_only_saved_voice_qualification_pending']=False;s['package_recovery']['state']='REGISTERED_DEFAULT_DELIVERED_AND_BASE_ONLY_CONSUMER_QUALIFIED';j['next_task']='Finish registered voice main merge; approved 4x content counterexamples, ICL/prompt voice and remaining master tasks';j['next']='Preserve full rev326 default and optional Base-only qualification; complete every remaining API/backend/recovery task.';put(p,json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';put(p,p.read_text()+'\n- [Base-only真实消费与可选封装](evidence/serve-voice-consumer-business-20261119/README.md)：完整音频、无注册后端、原客户授权与两档资格。\n')
p=R/'docs/SERVE_CUSTOM_VOICES_2026-11-18.md';s=p.read_text();a0=s.index('承接Serve总计划');b=s.index('\n1. ',a0);s=s[:a0]+'''承接Serve总计划A01/A10/A12。样本音色的真实授权、持久登记、
Speech/Chat、客户隔离、撤销、SDK/TLS及主轻/实际恢复已验并进入
[默认rev326](evidence/serve-voice-delivery-20261119/README.md)。
[Base-only已有音色消费](evidence/serve-voice-consumer-business-20261119/README.md)
两档真实资格和可选封装也已完成，不依赖注册用ASR/VAD/speaker。
参考音频ICL、提示词音色/Live、完整风格及听感/相似度继续；不推定
与OpenAI专有音色音质或身份相同。以下实施分项及历史证据保留。
'''+s[b:];put(p,s)
p=R/'README.md';s=p.read_text();marker='## 能力概览\n\n';text='''[注册音色](docs/evidence/serve-voice-delivery-20261119/README.md)已进入默认：
真实授权与样本核验、Speech/Chat输出、历史、客户隔离与撤销，并验证
原生入口及整包恢复。已有音色可[仅启用Base合成](docs/evidence/serve-voice-consumer-business-20261119/README.md)，
沿用原对象存储和客户ID，不要求注册用ASR/VAD/speaker；新登记需启用
这些后端。参考音频ICL、提示词音色、实时语音和听感验收继续推进。

''';put(p,s.replace(marker,marker+text,1))
print(json.dumps({k:a[k] for k in ['status','actual_model_starts','business_posts','seconds','files','private_files_omitted']}))

"""Resume remaining stopped checks; TLS-certificate flag is false for HTTP."""
import json,subprocess,time
from pathlib import Path
from tools.serve_service import package
from tools.serve_recovery import profile_consumer
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'consumer-package-check-01';O=V/'consumer-package-check-review-01';B=V/'consumer-package-01/bundle';S=P/'state';O.mkdir()
original=package.read(P/'result.json');checked=package.read(P/'check.stdout');manifest=package.read(B/'manifest.json')
assert original['status']=='FAILED' and len(original['commands'])==2 and all(c['returncode']==0 for c in original['commands'])
assert checked['status']=='PASS' and checked['state_checked'] and checked['client_state_valid'] and checked['client_count']==2
assert not checked['credentials_checked'] and 'tls' not in package.read(B/'gateway-policy.json')
assert not checked['model_actions'] and not checked['gpu_queries']
package.save(O/'plan.json',dict(original_failure_preserved=True,scope='credentials_checked reports configured TLS certificate readiness; this explicit HTTP package has no TLS. client_state_valid and both scoped clients already passed. Reuse init/check and execute only status/profiles/observe.',seconds=60,new_commands=3,reused_commands=2,new_gpu_starts=0))
start=time.monotonic();commands=[]
for label,operation in [('status','status'),('profiles','profiles-status'),('observe','observe')]:
 args=[str(B/'bin/q4t'),'service',operation,'--state',str(S)]
 with (O/(label+'.stdout')).open('x') as out,(O/(label+'.stderr')).open('x') as err:
  run=subprocess.run(args,stdout=out,stderr=err,timeout=min(20,60-(time.monotonic()-start)))
 commands.append(dict(label=label,argv=args,returncode=run.returncode));assert run.returncode==0
 response=package.read(O/(label+'.stdout'))
 if label=='status':assert response['state']=='STOPPED'
 if label=='profiles':assert response['selected']=='primary' and not response['model_actions']
assert all(package.sha(Path(n))==h for n,h in original['protected'].items())
assert profile_consumer.inputs(V/'voice-sdk-tls-02/run/registered-state.json')['sha256']==original['original_saved_state_unchanged']
result=dict(status='PASS_OPTIONAL_BASE_ONLY_PACKAGE_AND_PRIVATE_STATE',commands=commands,reused_commands=original['commands'],seconds=time.monotonic()-start,original_seconds=original['seconds'],original_failure_preserved=True,certificate_check_applicable=False,client_state_checked=True,consumer_owner_retained=True,service_stopped=True,model_starts=0,gpu_queries=0,default_unchanged=True,original_result_sha256=package.sha(P/'result.json'),package_sha256=package.sha(B/'manifest.json'))
package.save(O/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('commands','reused_commands')}))

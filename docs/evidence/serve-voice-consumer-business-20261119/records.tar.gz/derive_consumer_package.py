from pathlib import Path
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';s=(V/'prepare_voice_package.py').read_text()
s=s.replace('Seal C05 qualified voices and prepare a native payload for actual recovery.','Seal an explicitly selected Base-only consumer variant; keep the full default.')
s=s.replace("OUT = WORK/'service-package-01'", "OUT = WORK/'consumer-package-01'").replace("PROFILE = WORK/'voice-profiles-02'", "PROFILE = WORK/'consumer-profiles-01'")
a=s.index("CONTROL = {");b=s.index('\n\ndef cp',a)
s=s[:a]+"CONTROL = {'tools/serve_recovery/profile_evidence.py'}\nNATIVE = set()\n"+s[b:]
s=s.replace("    shutil.copyfile(source, target)","    if Path(source).name == 'q4t':\n        p.require(Path(source).stat().st_mode & 0o777 == 0o500, 'immutable source required')\n        os.link(source, target)\n    else:\n        shutil.copyfile(source, target)",1)
a=s.index("    evidence = ['serve-voice-chat-fix-");b=s.index("    evidence = {",a)
s=s[:a]+"    evidence = ['serve-voice-consumer-cpu-20261119','serve-voice-sdk-tls-20261119']\n"+s[b:]
a=s.index("    scope = (");b=s.index("    decision = ",a)
scope=('Explicit Base-only saved-voice deployment. Both primary/light profiles performed26businessPOSTs in126.176seconds under a continuous strict NVML lease. The same previously registered state is copied separately; existing owner and live consent checks, full Speech/Chat audio byte-for-byte recognized witnesses, stored complete Chat, cross-client404, missing-registration-assets503 and both revoked routes404 passed. ASR/aligner/VAD/speaker/separator/builtinTTS remain disabled with zero loads; the registration condition encoder remains configured with zero loads while the saved2048condition drives real Base synthesis. Original SDK no-hint ASR content is reused only after complete audio identity. The full rev326 default is unchanged. This optional package uses a private gateway/client fixture consistent with the saved owner, not production credentials. Package verification is CPU-only; Base-only automatic managed fault switching is not newly injected. Registration, ICL, prompt VoiceDesign, Live, listening/similarity, full model quality and performance are not certified by this consumer result.')
s=s[:a]+'    scope = '+repr(scope)+'\n'+s[b:]
s=s.replace('NATIVE_REGISTERED_VOICE_ENGINE_PROFILE_BUSINESS','NATIVE_SAVED_VOICE_CONSUMER_PROFILE_BUSINESS')
s=s.replace("        evidence=evidence,scope=scope,managed_composition_pending=True,", "        evidence=evidence,scope=scope,managed_composition_pending=True,\n        explicit_optional_configuration=True,registration_accepted=False,\n        core_inference_and_native_helpers_unchanged=True,")
s=s.replace("version='serve-native-registered-voices-20261119'", "version='serve-native-saved-voice-consumer-20261119'")
s=s.replace("    metadata['native_registered_voice_engine_acceptance']=decision", "    metadata.pop('native_registered_voice_engine_acceptance',None)\n    metadata['saved_voice_consumer_acceptance']=decision")
a=s.index("    policy=p.read(OLD/'engine/client-policy.json')");b=s.index("    kwargs=",a)
s=s[:a]+'''    from tools.serve_recovery import profile_consumer,profile_acceptance
    import secrets
    policy=profile_consumer.client_policy(profile_acceptance.Stage.client_policy_base(),
        settings['profile'],settings['native_tts_base'])
    prior=None
    policy['gateway_token']=secrets.token_hex(32)
    gateway=p.read(OLD/'gateway-policy.json')
    gateway['clients']=[dict(id=row['id'],api_key=secrets.token_hex(32)) for row in policy['clients']]
    gateway['listen_port']=19210
    p.save(OUT/'clients.json',policy)
    p.save(OUT/'gateway-policy.json',gateway)
'''+s[b:]
s=s.replace("None,OLD/'gateway-policy.json'", "None,OUT/'gateway-policy.json'")
a=s.index("        asr_model_dir=Path(");b=s.index("        tts_base_model_dir=",a)
s=s[:a]+"        tts_limits=settings['native_tts_base']['limits'],\n"+s[b:]
s=s.replace("status='MANAGED_VOICE_ACCEPTANCE_PENDING'", "status='PASS_OPTIONAL_BASE_ONLY_PACKAGE_CPU_CHECK_PENDING'")
s=s.replace("private_quota_changes='alpha output budget 3457; TPM 60000 for composed business short test'", "private_quota_changes='Owned isolated consumer fixture, preserving audio client identity; no production policy or state migration'")
s=s.replace("        default_unchanged=True,model_actions=0,driver_sha256=p.sha(Path(__file__))))", "        default_unchanged=True,model_actions=0,registration_enabled=False,\n        consumer_identity_from=plan['voice_consumer']['witness'],\n        optional_variant_not_default=True,driver_sha256=p.sha(Path(__file__))))")
compile(s,'prepare_consumer_package.py','exec');(V/'prepare_consumer_package.py').write_text(s)

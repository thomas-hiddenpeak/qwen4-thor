"""Initialize/check only a private consumer state, with no service startup."""
import json,subprocess,time
from pathlib import Path
from tools.serve_recovery import profile_consumer
from tools.serve_service import package
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'consumer-package-check-01';B=V/'consumer-package-01/bundle';S=O/'state'
O.mkdir();before={str(p):package.sha(p) for p in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service/manifest.json',R/'build/service.release.json',R/'build/service-native-state/ledger.json']}
rows=[('init',['init']),('check',['check']),('status',['status']),('profiles',['profiles-status']),('observe',['observe'])]
package.save(O/'plan.json',dict(commands=rows,seconds=90,model_starts=0,gpu_queries=0,original_package_check_without_state=dict(returncode=0,status='PASS',state_checked=False,credentials_checked=False,model_actions=False,source='prior direct tool invocation chunk 2e6946')))
start=time.monotonic();commands=[];result=dict(status='FAILED')
try:
 for label,words in rows:
  args=[str(B/'bin/q4t'),'service',*words,'--state',str(S)]
  with (O/(label+'.stdout')).open('x') as out,(O/(label+'.stderr')).open('x') as err:
   run=subprocess.run(args,stdout=out,stderr=err,timeout=min(30,90-(time.monotonic()-start)))
  commands.append(dict(label=label,argv=args,returncode=run.returncode))
  assert run.returncode==0,label
  response=package.read(O/(label+'.stdout'))
  if label=='init':
   assert response['desired']=='STOPPED' and not response['automatic_start']
   inputs=profile_consumer.inputs(V/'voice-sdk-tls-02/run/registered-state.json')
   profile_consumer.clone(inputs,S/'application-objects')
   package.save(O/'state-inputs.json',dict(witness=inputs['witness'],files=inputs['files'],original_unchanged=True))
  if label=='check':
   assert response['status']=='PASS' and response['state_checked'] and response['credentials_checked']
   assert not response['model_actions'] and not response['gpu_queries']
  if label=='status':assert response['state']=='STOPPED'
  if label=='profiles':assert response['selected']=='primary' and not response['model_actions']
 result['status']='PASS_BASE_ONLY_PRIVATE_PACKAGE_STATE_AND_CREDENTIALS'
except BaseException as error:
 result['error']=repr(error)
finally:
 result.update(commands=commands,seconds=time.monotonic()-start,model_starts=0,gpu_queries=0,
   original_saved_state_unchanged=profile_consumer.inputs(V/'voice-sdk-tls-02/run/registered-state.json')['sha256'],
   default_unchanged=all(package.sha(Path(n))==d for n,d in before.items()),protected=before)
 package.save(O/'result.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in ('commands','protected')}))
assert result['status'].startswith('PASS_') and result['default_unchanged']

"""Compose passed cases without changing any original failed run or receipt."""
import fcntl,json,socket,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle,journal,version_contract
from tools.serve_service import package as p

def environment(directory,status):
 lease=directory/'lease';v=p.read(lease/'exit.json')
 p.require(v['status']==status and v['child_returncode']==(0 if status=='COMPLETED' else 1) and
   v['compute_backend']=='nvml' and v['lease_inherited_by_child'] is True and v['external_lease'] is False,
   'unexpected environment outcome')
 queries=[json.loads(n) for n in (lease/'nvml-queries.jsonl').read_text().splitlines()]
 p.require(queries and all(q['status']=='OK' and q['returncode']==0 for q in queries),'failed observation')
 events=[json.loads(n) for n in (lease/'events.jsonl').read_text().splitlines()]
 a=[e for e in events if e.get('event')=='lease_acquired'];b=[e for e in events if e.get('event')=='lease_released']
 p.require(len(a)==len(b)==1 and a[0]['pid']==b[0]['pid'] and b[0]['status']==status,'lease continuity differs')
 return dict(status=status,seconds=b[0]['monotonic']-a[0]['monotonic'],nvml_queries=len(queries),env_abort=False,lock=v['lock_path'])

def main():
 out=W/'accepted-cases';p.require(not out.exists(),'preserve acceptance');out.mkdir(mode=0o700)
 groups=[W/('business-0'+str(n)) for n in range(1,5)]
 envs=[environment(d,'COMPLETED' if i==3 else 'COMMAND_FAILED') for i,d in enumerate(groups)]
 elapsed=sum(p.read(W/('gpu-business-0'+str(i)+'.json'))['seconds'] for i in range(1,5))
 p.require(elapsed<1040,'frozen cumulative GPU bound exceeded')
 old=p.read(groups[0]/'execution/result.json');second=p.read(groups[1]/'execution/result.json')
 p.require(old['status']==second['status']=='FAILED' and old['cleanup_failure'] is None and second['cleanup_failure'] is None,'original failures changed')
 p.require(old['budget']['counts']['starts']==4 and old['budget']['counts']['chats']==8 and second['budget']['counts']['starts']==5 and second['budget']['counts']['chats']==10,'original consumption changed')
 group=p.read(groups[2]/'result.json');unused=p.read(groups[2]/'root_wait_candidate/execution/result.json')
 p.require(group['status']=='FAILED' and 'bounded remaining group deadline' in group['failure'] and
  unused['status']=='FAILED' and unused['cleanup_failure'] is None and
  all(unused['budget']['counts'][n]==0 for n in ('starts','chats','probes')),'last original case was not unexecuted')
 p.require(p.read(groups[3]/'plan.json')['resume_state']==p.read(groups[2]/'root_wait_candidate/plan.json')['resume_state'],'candidate qualification reset its original state')
 cases=[('root_forward',groups[2]/'root_forward',1,2),('root_wait_outer',groups[2]/'root_wait_outer',2,4),('root_candidate_completion',groups[3],1,2)]
 accepted={};owners=set();ports=set()
 for kind,directory,starts,chats in cases:
  plan=p.read(directory/'plan.json');result=p.read(directory/'execution/result.json');scope=Path(plan['resume_state']);desc=plan['package'];manifest=bundle.verify(desc['package'],desc['manifest_sha256'])
  p.require(plan['scenario']==result['scenario']==kind and result['status']=='PASS_BOUNDED_ROOT_ROLLBACK_BUSINESS' and result['failure'] is None and result['cleanup_failure'] is None,'missing complete business case')
  p.require(result['budget']==p.read(directory/'execution/counts.json') and result['budget']['counts']['starts']==starts and result['budget']['counts']['chats']==chats and result['budget']['counts']['probes']==0,'case work incomplete')
  for k,v in result['budget']['counts'].items():p.require(type(v) is int and 0<=v<=plan['limits'][k],'case budget exceeded')
  for n,h in plan['sources'].items():p.require(p.sha(R/n)==h,'reviewed source drift: '+n)
  for v in plan['protected']+plan['prior_evidence']:p.require(p.sha(v['path'])==v['sha256'],'protected artifact changed')
  core=p.read(scope/'ledger.json')['state'];outer=p.read(scope/'outer-recovery/policy.json')['state']['policy']
  p.require(core['desired']=='STOPPED' and not any(core['active'].values()) and outer['pending'] is None and not outer['protected'],'cleanup incomplete')
  records=list((directory/'execution').glob('launcher-*-result.json'));p.require(records,'missing outer cleanup proof')
  for file in records:
   v=p.read(file);p.require(v['stop_durable'] and v['cleanup_confirmed'] and v['tree_cleanup_verified'],'native cleanup unconfirmed')
  for line in (directory/'execution/status.jsonl').read_text().splitlines():
   v=json.loads(line)
   for role in ('guardian','controller','model','gateway'):
    if v.get(role+'_pid') is not None:owners.add((v[role+'_pid'],v[role+'_start_ticks']))
  policy=p.read(Path(desc['package'])/'gateway-policy.json');ports.update(policy[n] for n in ('listen_port','upstream_port','upstream_operations_port'))
  final=p.read(directory/'execution/business-final.json');p.require(final['status']=='PASS' and final['scenario']==kind,'business proof missing')
  accepted[kind]=dict(plan=plan,result=result,directory=str(directory),core=core,outer=outer,final=final)
 for pid,ticks in owners:
  try:p.require(journal.process_start(pid)!=ticks,'owned process survives')
  except (FileNotFoundError,ProcessLookupError):pass
 for port in ports:
  with socket.socket() as s:s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',port))
 with Path(envs[-1]['lock']).open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 postflight=dict(sources_unchanged=True,owned_processes_gone=True,ports_free=True,lock_released=True)
 summary=dict(status='ACCEPT_TARGETED_ROOT_ROLLBACK_AND_RECOVERY',original_continuous_script_passed=False,original_failures_preserved=True,environment=envs,cumulative_counts=dict(starts=9,chats=18,probes=1),cumulative_gpu_seconds=elapsed,postflight=postflight,default_replaced=False,remaining_master_tasks_open=True,actual_case_files={k:v['directory'] for k,v in accepted.items()})
 for kind,label,index in [('root_wait_outer','retained',2),('root_candidate_completion','candidate',3)]:
  item=accepted[kind];directory=Path(item['directory']);plan=item['plan'];desc=plan['package'];package=Path(desc['package']);acceptance='ACCEPT_NATIVE_ROOT_'+label.upper()
  decision=dict(status='PASS_NATIVE_ROOT_'+label.upper(),acceptance=acceptance,manifest_sha256=desc['manifest_sha256'],engine_binary_sha256=p.sha(package/'engine/q4t'),
   actual_business=dict(status=acceptance,strict_lease_seconds=envs[index]['seconds'],nvml_queries=envs[index]['nvml_queries'],env_abort=False,counts=item['result']['budget']['counts'],source_commit=plan['source_commit'],plan_sha256=p.sha(directory/'plan.json'),result_sha256=p.sha(directory/'execution/result.json'),lease_result_sha256=p.sha(groups[index]/'lease/exit.json'),postflight=postflight,whole_driver_status=envs[index]['status'],separate_case_accepted=True,scope=item['final']),
   default_replaced=False,performance_acceptance=False,long_stability_accepted=False)
  p.save(directory/'decision.json',decision)
  release=dict(version=1,profile='q4t-service-recovery-v19',acceptance=acceptance,recovery_accepted=True,acceptance_record=str(directory/'decision.json'),acceptance_sha256=p.sha(directory/'decision.json'),package=desc['package'],manifest_sha256=desc['manifest_sha256'],engine_binary_sha256=decision['engine_binary_sha256'],engine_release_sha256=p.sha(package/'engine/q4t.release.json'),ingress_mode='native',state=plan['resume_state'],service_id=item['core']['service_id'],initial_desired='STOPPED',automatically_started=False,scope='Exact root targeted business; original cycles and tool continuation separately accepted; all original failed runs preserved; cold/resource/host work remains.',default_replaced=False)
  p.save(directory/'service-release.json',release)
  receipts={k:dict(path=str(directory/n),sha256=p.sha(directory/n)) for k,n in [('release','service-release.json'),('decision','decision.json')]}
  version_contract.accepted_fallback(receipts,version_contract.payload(desc));summary[label]=dict(package=desc,acceptance=receipts)
 p.save(out/'acceptance.json',summary);print(json.dumps(summary))
if __name__=='__main__':main()

"""Resume the exact preserved prefix after a transport EOF, without a model load."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,threading,time,urllib.request
W=Path(__file__).resolve().parent;P=W/'base-assets-01';O=W/'base-assets-02';O.mkdir(exist_ok=False)
length=3857413744;chunk_size=4*1024*1024;expected='38fc7fc51c5e776e840414b6fd443962e9411b9654888fd7913e4da643cb857c'
old=json.loads((P/'result.json').read_bytes());assert old['status']=='FAILED' and 'SSLEOFError' in old['error'];count=old['download_bytes_hashed'];assert 0<count<length and count%chunk_size==0
prior=P/'model.safetensors.partial';assert prior.stat().st_size==count
source=hashlib.sha256();prior_rows=json.loads((P/'ranges.json').read_bytes());assert len(prior_rows)*chunk_size==count
with prior.open('rb') as f:
 for row in prior_rows:
  data=f.read(chunk_size);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];source.update(data)
 assert not f.read(1)
assert shutil.disk_usage(W).free>=length-count+256*1024**2
base=json.loads((P/'plan.json').read_bytes())['source'];plan=dict(source=base,source_bytes=length,source_sha256=expected,resume_offset=count,preserved_prefix_sha256=source.hexdigest(),original_failed_result_sha256=hashlib.sha256((P/'result.json').read_bytes()).hexdigest(),prior_prefix_range_checks=len(prior_rows),range_bytes=chunk_size,connections=8,retries=0,maximum_download_bytes=length-count,maximum_seconds=1200,minimum_free_mib=256,gpu_loads=0,model_loads=0,prior_partial_relocated_to=str(O/'model.safetensors.partial'),note='Original failure/plan/ranges unchanged. Exact old prefix relocated and retained byte-for-byte at new file prefix; full file usable only after final SHA.')
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');partial=O/'model.safetensors.partial';prior.rename(partial);(P/'partial-continuation.json').write_text(json.dumps(dict(path=str(partial),prefix_bytes=count,prefix_sha256=source.hexdigest(),frozen_result_unchanged=True),indent=2)+'\n')
start=time.monotonic();stop=threading.Event();rows=[];pending={};offset_start=count;result=dict(status='FAILED',gpu_loads=0,model_loads=0);executor=ThreadPoolExecutor(max_workers=8)
def fetch(offset):
 end=min(length,offset+chunk_size)-1;data=bytearray();tick=time.monotonic();request=urllib.request.Request(base+f'?download=true&q4t=speaker-range-{offset}',headers={'User-Agent':'q4t-verified-base-ranges/1','Range':f'bytes={offset}-{end}','Accept-Encoding':'identity'})
 with urllib.request.urlopen(request,timeout=30) as r:
  assert r.status==206 and r.headers.get('Content-Range')==f'bytes {offset}-{end}/{length}'
  while block:=r.read(65536):
   assert not stop.is_set() and time.monotonic()-start<1200;data.extend(block);assert len(data)<=end-offset+1
 assert len(data)==end-offset+1
 return bytes(data),dict(offset=offset,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),seconds=time.monotonic()-tick)
try:
 next_submit=count;next_notice=count+64*1024*1024
 for _ in range(8):
  if next_submit<length:pending[next_submit]=executor.submit(fetch,next_submit);next_submit+=chunk_size
 with partial.open('ab') as f:
  for offset in range(count,length,chunk_size):
   data,row=pending.pop(offset).result(timeout=max(.1,1200-(time.monotonic()-start)));source.update(data);rows.append(row);f.write(data);count+=len(data);assert shutil.disk_usage(W).free>=256*1024**2
   if next_submit<length:pending[next_submit]=executor.submit(fetch,next_submit);next_submit+=chunk_size
   if count>=next_notice:
    progress=dict(bytes=count,total=length,seconds=time.monotonic()-start,source_verified=False);print(json.dumps(progress),flush=True);(O/'progress.json').write_text(json.dumps(progress)+'\n');next_notice+=64*1024*1024
  f.flush();os.fsync(f.fileno())
 assert count==length and source.hexdigest()==expected and partial.stat().st_size==length
 partial.chmod(0o444);partial.rename(O/'model.safetensors')
 result.update(status='FULL_BASE_SOURCE_SHA_VERIFIED_ASSET_RETAINED',full_source_sha256=expected,retained_bytes=length,full_model_asset_retained=True,tensors=480,prior_prefix_bytes_reused=offset_start)
except BaseException as e:result['error']=repr(e)
finally:
 stop.set()
 for p in pending.values():p.cancel()
 executor.shutdown(wait=True,cancel_futures=True);result.update(bytes_hashed_including_prefix=count,new_download_bytes_hashed=count-offset_start,seconds=time.monotonic()-start,completed_ranges=len(rows));(O/'ranges.json').write_text(json.dumps(rows,indent=2)+'\n');(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
assert result['status']=='FULL_BASE_SOURCE_SHA_VERIFIED_ASSET_RETAINED'

from pathlib import Path
import json,hashlib,sys
R=Path.cwd();sys.path.insert(0,str(R));from tools.native_tts import base_acceptance as a
V=R/'.q4t-work/serve-custom-voices-20261118';T=R/'.q4t-work/serve-native-tts-20261118';W=R/'.q4t-work/serve-audio-native-20261117';p=V/'base-qualification-plan-01.json';assert not p.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((V/'base-compute-build-01/plan.json').read_text());sources={}
for n,h in build['sources'].items():assert sha(R/n)==h;sources[str(R/n)]=h
cases=[]
for i,item in enumerate(a.CASES):
 q=V/f'speaker-qualification-02/run/native/case-{i+2}/embedding.f32';cases.append(dict(item,speaker_embedding=str(q),speaker_embedding_sha256=sha(q)));sources[str(q)]=sha(q)
for n in ['speaker-qualification-02/run/result.json','speaker-qualification-02/lease/exit.json','base-conditioning-cpu-01/result.json','base-acceptance-cpu-01/result.json','base-compute-build-01/result.json']:q=V/n;sources[str(q)]=sha(q)
for n in ['configuration_qwen3_tts.py','modeling_qwen3_tts.py']:q=T/'source-01/official/qwen_tts/core/models'/n;sources[str(q)]=sha(q)
for n in ['config.json','generation_config.json','vocab.json','merges.txt','tokenizer_config.json']:q=V/'base-service-assets-01'/n;sources[str(q)]=sha(q)
names=['base_replay.cpp','base_reference.py','base_acceptance.py','acceptance.py'];drivers={n:sha(R/'tools/native_tts'/n) for n in names}
for n,h in drivers.items():sources[str(R/'tools/native_tts'/n)]=h
binary=V/'base-compute-build-01/q4t_tts_base_replay';plan=dict(schema='q4t-native-base-tts-component-fp32-v1',limits=a.LIMITS,thresholds=a.THRESHOLDS,cases=cases,eos_qualified=False,audio_qualified=False,defaults=a.defaults(),binary_sha256=sha(binary),sources=sources,driver_sources=drivers,binary=str(binary),assets=str(V/'base-service-assets-01'),official_source=str(T/'source-01/official/qwen_tts/core/models'),reference_python=str(R/'.q4t-work/refenv/bin/python'),reference_deps=str(W/'reference-deps'),source_checkpoint_sha256='38fc7fc51c5e776e840414b6fd443962e9411b9654888fd7913e4da643cb857c',registered_voice_api_qualified=False)
a.validate_plan(plan);p.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(plan=str(p),limits=a.LIMITS,comparisons=134)))

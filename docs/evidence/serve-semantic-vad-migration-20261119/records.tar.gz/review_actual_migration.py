"""Read-only migration review of actual sealed qualifications; no model actions."""
from pathlib import Path
import copy,json,runpy,time
from tools.serve_recovery import profile_manager as manager,profile_migration as migration,ledger
from tools.serve_service import package as p
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'migration-review-01'
assert not O.exists();O.mkdir(mode=0o700);start=time.monotonic()
paths=dict(previous=R/'build/service',candidate=W/'service-package-01/bundle',retained=W/'retained-01/bundle')
manifests={k:p.read(v/'manifest.json') for k,v in paths.items()}
records={k:manager.evidence(paths[k],m) for k,m in manifests.items()}
source=paths['candidate']/'source/tools/serve_recovery/profile_migration.py'
legacy=runpy.run_path(str(source))['permit']
def call(f,a,b,**kwargs):
 x,y=manifests[a],manifests[b]
 return f(x['recovery_profiles'],y['recovery_profiles'],records[a],records[b],
     x['recovery_profile_policy'],y['recovery_profile_policy'],**kwargs)
protected={str(path):p.sha(path) for path in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service.release.json',R/'build/service/manifest.json',R/'build/service-native-state/ledger.json',R/'build/service-native-state/profile-selection/policy.json',source]}
p.save(O/'plan.json',dict(scope=__doc__,sources=dict(old=p.sha(source),new=p.sha(Path(migration.__file__))),manifests={k:p.sha(v/'manifest.json') for k,v in paths.items()},protected=protected,maximum_seconds=60,gpu_actions=0))
try:
 call(legacy,'previous','candidate',allow_capacity_change=True,allow_capability_extension=True)
 raise RuntimeError('original failure did not reproduce')
except ledger.LedgerError as error:
 assert 'capabilities' in str(error);original=str(error)
grant=call(migration.permit,'previous','candidate',allow_capacity_change=True,allow_capability_extension=True)
current=p.read(R/'build/service-native-state/profile-selection/policy.json')['state']['policy']
clock=current['clock'];future=migration.candidate(current,grant,ledger.Stamp(clock['boot_id'],clock['monotonic_ns']))
for k in ('history','pending','selected','not_before_ns','light_since_ns','clock','configuration'):assert future[k]==current[k],k
identical={}
for a,b in [('candidate','retained'),('retained','candidate'),('candidate','candidate')]:
 first=call(legacy,a,b,automatic=True);second=call(migration.permit,a,b,automatic=True)
 assert first==second;identical[a+'-'+b]=ledger.digest(first)
assert all(p.sha(Path(name))==h for name,h in protected.items())
p.save(O/'result.json',dict(status='PASS_ACTUAL_QUALIFIED_MIGRATION_READ_ONLY',seconds=time.monotonic()-start,original_failure=original,original_failure_preserved=True,upgrade_permit=grant,automatic_permits_byte_identical=identical,protected_unchanged=True,history_and_budgets_preserved=True,model_actions=0))
print(json.dumps(dict(status='PASS_ACTUAL_QUALIFIED_MIGRATION_READ_ONLY',seconds=time.monotonic()-start,automatic_permits_byte_identical=len(identical),model_actions=0)))

"""Finalize the exact-byte clone after enforcing private single-link policies."""
from pathlib import Path
import copy,json
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as p
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=W/'service-package-02';old=W/'service-package-01/bundle';target=O/'bundle'
source='source/tools/serve_recovery/profile_migration.py'
receipt=p.read(W/'service-package-01/receipt.json');original=bundle.verify(old,receipt['manifest_sha256'])
manifest=p.read(target/'manifest.json');digest=p.sha(target/'manifest.json')
assert p.sha(target/source)==p.sha(R/source[7:])
assert not (O/'receipt.json').exists()
assert bundle.verify(target,digest)==manifest
expected=copy.deepcopy(original);expected['files'][source]=manifest['files'][source];assert manifest==expected
for name in original['files']:
 if name!=source:assert p.sha(old/name)==p.sha(target/name)
assert bundle.verify(old,receipt['manifest_sha256'])==original
retained=p.read(W/'retained-01/receipt.json')
permit=version_contract.compatible(version_contract.payload(dict(package=str(target),manifest_sha256=digest)),version_contract.payload({k:retained[k] for k in ('package','manifest_sha256')}))
p.save(O/'receipt.json',dict(package=str(target),manifest_sha256=digest,engine_binary_sha256=receipt['engine_binary_sha256'],recovery_accepted=False))
p.save(O/'delta-review.json',dict(scope=__doc__,original=dict(package=str(old),manifest_sha256=receipt['manifest_sha256']),candidate=dict(package=str(target),manifest_sha256=digest),changed_payload_sources=[source],engine_unchanged=True,primary_light_unchanged=True,native_helpers_unchanged=True,retained_and_tls_packages_unchanged=True,automatic_compatibility=permit,new_gpu_starts=0,actual_candidate_version_recovery_pending=True))
print(json.dumps(dict(candidate_manifest_sha256=digest,changed_payload_sources=[source],new_gpu_starts=0)))

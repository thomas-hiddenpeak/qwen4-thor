"""Seal one reviewed Python migration delta; retain exact engine and native helpers."""
from pathlib import Path
import copy,json,os,shutil
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as p
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=W/'service-package-02';old=W/'service-package-01/bundle'
receipt=p.read(W/'service-package-01/receipt.json');original=bundle.verify(old,receipt['manifest_sha256'])
assert not O.exists();O.mkdir(mode=0o700);target=O/'bundle'
source='source/tools/serve_recovery/profile_migration.py'
delta={n for n,h in original['files'].items() if n.startswith('source/') and p.sha(R/n[7:])!=h}
assert delta=={source}
assert p.read(W/'migration-cpu-01/result.json')['status']=='PASS'
assert p.read(W/'migration-review-01/result.json')['status']=='PASS_ACTUAL_QUALIFIED_MIGRATION_READ_ONLY'
shutil.copytree(old,target,symlinks=True,copy_function=os.link)
def replace(path,data):
 parent_mode=path.parent.stat().st_mode&0o777;mode=path.stat().st_mode&0o777
 path.parent.chmod(parent_mode|0o200)
 path.unlink();path.write_bytes(data);path.chmod(mode)
 path.parent.chmod(parent_mode)
replace(target/source,(R/source[7:]).read_bytes())
manifest=copy.deepcopy(original);manifest['files'][source]=p.sha(target/source)
replace(target/'manifest.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
digest=p.sha(target/'manifest.json')
replace(target/'bin/q4t',bundle.launcher(digest,manifest['python']['path']))
assert bundle.verify(target,digest)==manifest
expected=copy.deepcopy(original);expected['files'][source]=manifest['files'][source];assert manifest==expected
for name in original['files']:
 if name!=source:assert p.sha(old/name)==p.sha(target/name)
assert bundle.verify(old,receipt['manifest_sha256'])==original
retained=p.read(W/'retained-01/receipt.json')
permit=version_contract.compatible(version_contract.payload(dict(package=str(target),manifest_sha256=digest)),version_contract.payload({k:retained[k] for k in ('package','manifest_sha256')}))
p.save(O/'receipt.json',dict(package=str(target),manifest_sha256=digest,engine_binary_sha256=receipt['engine_binary_sha256'],recovery_accepted=False))
p.save(O/'delta-review.json',dict(scope=__doc__,original=dict(package=str(old),manifest_sha256=receipt['manifest_sha256']),candidate=dict(package=str(target),manifest_sha256=digest),changed_payload_sources=[source],engine_unchanged=True,primary_light_unchanged=True,native_helpers_unchanged=True,retained_and_tls_packages_unchanged=True,automatic_compatibility=permit,new_gpu_starts=0,actual_candidate_version_recovery_pending=True))
print(json.dumps(dict(candidate_manifest_sha256=digest,changed_payload_sources=[source],new_gpu_starts=0)))

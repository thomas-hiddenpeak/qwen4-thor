"""Seal native programmatic tools acceptance with exact profiles; preserve default."""
import copy
import hashlib
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import capacity, package as p

WORK = Path(__file__).resolve().parent
OUT = WORK/'candidate-02'
BUSINESS = WORK/'business-02'
PROFILES = WORK/'profiles-02'
BUILD = ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD = (ROOT/'build/service').resolve(strict=True)
helpers = runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))


def copy_file(source, target):
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def main():
    p.require(not OUT.exists(), 'preserve previous candidate')
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),
              'commit reviewed sources first')
    accepted = p.read(BUSINESS/'acceptance.json')
    p.require(accepted['status'] == 'ACCEPT_PROGRAMMATIC_TOOLS_BUSINESS' and
              not accepted['env_abort'] and all(accepted['postflight'].values()),
              'actual namespace/result business absent')
    for name, digest in accepted['records'].items():
        p.require(p.sha(WORK/name) == digest, 'actual business changed')
    plan = p.read(PROFILES/'plan.json')
    current_plan = p.read(BUSINESS/'plan.json')
    runtime = helpers['source_hashes']()
    compiled = p.read(BUILD/'generated/q4t/server/chat_protocol_sources.json')
    runtime.update(compiled)
    original = bundle.verify(OLD, p.sha(OLD/'manifest.json'))
    old_release = p.read(OLD/'engine/q4t.release.json')
    previous_runtime = p.read(old_release['tested_source_manifest'])
    runtime_delta = {n for n,h in runtime.items() if previous_runtime.get(n) != h}
    review = p.read(WORK/'runtime-review-02.json')
    expected_delta = set(review['runtime_delta'])
    p.require(review['runtime_source_sha256'] == runtime, 'reviewed runtime changed')
    p.require(runtime_delta == expected_delta, 'runtime drift')
    repair = p.read(ROOT/'docs/evidence/serve-programmatic-resume-rate-cpu-20261115/decision.json')
    p.require(repair['status'] == 'PASS_TARGETED_PENDING_PROMPT_REPLAN',
              'targeted rate repair not accepted')
    prior_runtime = p.read(WORK/'runtime-review.json')['runtime_source_sha256']
    repaired_sources = {'include/q4t/server/client_policy.h',
                        'src/server/client_policy.cpp', 'src/server/chat_generation.cpp'}
    p.require({n for n,h in runtime.items() if prior_runtime.get(n) != h} == repaired_sources,
              'unreviewed runtime repair delta')
    p.require(all(repair['runtime_sources'][n] == runtime[n] for n in repaired_sources),
              'reviewed rate repair changed')
    p.require(all(current_plan['sources'].get(n, accepted['compiled_source_identity'].get(n)) == h
                  for n,h in runtime.items() if n not in repaired_sources),
              'unaffected business runtime changed')
    compiled_identity = plan['candidate_identity']['compiled_sources']
    p.require(p.sha(compiled_identity['path']) == compiled_identity['sha256'],
              'frozen qualification compilation identity differs')
    qualified_compiled = p.read(compiled_identity['path'])
    p.require(all(plan['sources'].get(n, qualified_compiled.get(n)) == h for n,h in runtime.items()),
              'current qualified runtime changed')
    p.require(p.sha(BUILD/'q4t') == repair['binary_sha256'] == plan['binary_sha256'],
              'repaired build/qualification engine differs')
    p.require(accepted['binary_sha256'] == p.sha(WORK/'candidate-01/bundle/engine/q4t'),
              'original uncontrolled business evidence identity differs')
    for name, digest in current_plan['protected'].items():
        p.require(p.sha(name) == digest, 'default changed')
    native_old = p.read(OLD/'native-build.json')
    native_delta = {n for n,h in native_old['source_files'].items() if p.sha(ROOT/n) != h}
    p.require(native_old['source_files'].keys() == bundle.NATIVE_SOURCES and
              native_delta == {'CMakeLists.txt', 'tests/host/CMakeLists.txt'}, 'native source drift')
    native = p.read(WORK/'native-build-02.json')
    p.require(p.sha(WORK/'native-build-02.json') == review['native_rebuild_receipt_sha256'] and
              all(p.sha(ROOT/n) == h for n,h in native['source_files'].items()) and
              all(native['reuse_review']['executable_hashes_identical'].values()),
              'rebuilt native identity differs')
    for field, filename in [('guardian_sha256','q4t-guardian'),
        ('cuda_probe_sha256','q4t-cuda-probe'), ('ingress_sha256','q4t-ingress'),
        ('device_control_sha256','q4t-device-control')]:
        p.require(native[field] == p.sha(OLD/'bin'/filename), 'retained helper changed')
    control_delta = {n for n in bundle.SOURCES if p.sha(ROOT/n) != p.sha(OLD/'source'/n)}
    p.require(control_delta == {'tools/serve_recovery/profile_migration.py', 'tools/serve_service/package.py'}, 'control drift')
    OUT.mkdir(mode=0o700)
    engine = OUT/'engine'
    for name in ('q4t','CMakeCache.txt'):
        copy_file(BUILD/name, engine/name)
    (engine/'q4t').chmod(0o500)
    p.save(engine/'runtime-source.json', runtime)
    compiled = p.read(BUILD/'generated/q4t/server/chat_protocol_sources.json')
    p.require(all(runtime.get(n) == h for n,h in compiled.items()), 'compiled source changed')
    protocol = hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
    qualification = p.read(PROFILES/'acceptance.json')
    p.require(qualification['status'] == 'ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and
        qualification['environment']['cleanup_complete'], 'profiles absent')
    caps, config = [p.read(PROFILES/('primary-'+n+'.json')) for n in ('capabilities','config')]
    p.require(caps['protocol_source_sha256'] == config['protocol_source_sha256'] == protocol,
              'protocol observation differs')
    decision = dict(status='PASS_PROGRAMMATIC_TOOLS',
        acceptance='ACCEPT_PROGRAMMATIC_TOOLS', binary_sha256=plan['binary_sha256'],
        protocol_sha256=protocol, actual_business=accepted, runtime_delta=sorted(runtime_delta),
        source_commit=plan['source_commit'], full_model_quality=False,
        performance_acceptance=False, profile_qualification=qualification,
        retained_service_evidence=str(ROOT/'docs/evidence/serve-retrieval-managed-business-20261112/README.md'),
        optional_frontend_evidence=str(ROOT/'docs/evidence/serve-optional-route-parity-20261112/README.md'),
        default_changed=False, remaining_master_tasks_open=True)
    decision.update(rate_repair=repair, managed_resume_acceptance_pending=True,
        original_business_reuse='Only unchanged direct requests without client limits; exactly three runtime files reviewed. This candidate is not a managed delivery acceptance.')
    p.save(OUT/'decision.json', decision)
    metadata = copy.deepcopy(old_release)
    metadata.update(version='serve-programmatic-tools-resume-rate-20261115',
        source_commit=plan['source_commit'], binary_sha256=plan['binary_sha256'],
        acceptance=decision['acceptance'], acceptance_decision=str(OUT/'decision.json'),
        acceptance_decision_sha256=p.sha(OUT/'decision.json'),
        build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),
        tested_source_manifest=str(engine/'runtime-source.json'),
        tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),
        observed_configuration=config, previous_binary=str(OLD/'engine/q4t'),
        previous_release=str(OLD/'engine/q4t.release.json'),
        inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),sha256=p.sha(OLD/'engine/q4t.release.json')),
        source_note='Native programmatic JavaScript with authenticated original tool authority and causal continuation; loaded function/custom and namespaces, serial/async, media and shared budgets. Two actual project JSON/SSE closures and local computation accepted. Compact large-length grammar preserves exact bounds. Fixed MIT QuickJS runs only in isolated workers and cannot restart the model. Primary/light qualified; helpers byte-identical, model arithmetic unchanged. No full quality/performance claim.')
    metadata['source_note'] += ' First-step pending prompt replacement has targeted CPU acceptance; current binary profiles are qualified, while actual controlled program continuation and whole-tree recovery must still pass before publication. Original unrestricted business evidence is reused only for unchanged paths.'
    declarations = engine/'declarations'
    declarations.mkdir(mode=0o700)
    p.save(declarations/'capabilities.json',caps)
    p.save(declarations/'configuration.json',config)
    metadata['chat_protocol'].update(caps,protocol_sha256=protocol,
        declaration_evidence='Exact current primary/light observations and native programmatic JSON/SSE project closure; targeted CPU/SDK evidence, unchanged native recovery evidence reused.')
    for name,stem in helpers['SCHEMAS'].items():
        source = ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'))
        target = declarations/'schemas'/(name+'.json')
        copy_file(source,target)
        metadata['chat_protocol'][name+'_schema'] = str(target)
        metadata['chat_protocol'][name+'_schema_sha256'] = p.sha(target)
    metadata['release_declarations'] = dict(profile=p.APPLICATION_DECLARATION_PROFILE,
        directory=str(declarations),binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,
        files={n:p.sha(declarations/n) for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
    for source in (ROOT/'third_party/licenses').rglob('*'):
        if source.is_file():copy_file(source,engine/'licenses'/source.relative_to(ROOT/'third_party/licenses'))
    metadata['third_party_notices']['source_directory'] = str(engine/'licenses/structured_output')
    metadata['application_notices']['source_directory'] = str(engine/'licenses/openai-node')
    for name,record in metadata['file_input_system_dependencies'].items():
        source = Path(record['artifact'])
        p.require(p.sha(source)==record['sha256'],'notice changed')
        target=engine/'licenses/system'/name;copy_file(source,target);record['artifact']=str(target)
    clients=metadata['client_artifacts']
    for name in clients['files']:
        copy_file(ROOT/name,OUT/'clients'/name);clients['files'][name]=p.sha(ROOT/name)
    clients['directory']=str(OUT/'clients')
    metadata['programmatic_acceptance']=decision
    p.save(engine/'q4t.release.json',metadata)
    p.verify_declarations(metadata,required=True)
    p.save(OUT/'native-build.json',native)
    settings=p.read(OLD/'engine/manifest.json')['settings']
    profile=dict(version=1,**{k:v for k,v in settings['profile'].items()
                             if k in capacity.BOUNDS or k=='mtp_enabled'})
    kwargs={key:OLD/'engine'/name for key,name in
        [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json')]
        if (OLD/'engine'/name).is_file()}
    receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',
        p.read(OLD/'engine/manifest.json')['model_dir'],OLD/'bin/q4t-guardian',
        OLD/'bin/q4t-cuda-probe',None,OLD/'gateway-policy.json',OLD/'engine/client-policy.json',
        OUT/'bundle',native_receipt=OUT/'native-build.json',native_ingress=OLD/'bin/q4t-ingress',
        device_control=OLD/'bin/q4t-device-control',capacity_config=profile,
        application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},
        embedding_model_dir=Path(settings['native_embedding']['directory']),
        recovery_profiles=PROFILES/'qualified/registry.json',
        recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
    p.save(OUT/'receipt.json',receipt)
    p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,
              'managed settings drift')
    p.save(OUT/'prepare-review.json',dict(previous=str(OLD),
        previous_manifest_sha256=p.sha(OLD/'manifest.json'),engine_sha256=plan['binary_sha256'],
        protocol_sha256=protocol,control_delta=sorted(control_delta),
        native_source_delta=sorted(native_delta),runtime_delta=sorted(runtime_delta),
        new_gpu_starts=0,default_changed=False,package_sha256=receipt['manifest_sha256']))
    print(receipt['manifest_sha256'])


if __name__=='__main__':
    os.umask(0o077)
    main()

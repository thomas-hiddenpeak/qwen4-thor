from pathlib import Path
import fcntl,hashlib,json,socket,tarfile
from tools.serve_recovery import journal
ROOT=Path.cwd();W=ROOT/'.q4t-work/serve-programmatic-tools-20261113';RUN=W/'managed-version-01'
OUT=ROOT/'docs/evidence/serve-programmatic-resume-failure-20261115'
assert not OUT.exists()
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(RUN/'plan.json');result=read(RUN/'execution/result.json');guard=read(RUN/'lease/exit.json')
assert result['status']=='FAILED' and result['cleanup_failure'] is None
assert guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1 and guard['lease_inherited_by_child']
rows=[json.loads(x[6:]) for x in (RUN/'execution/fallback-follow.wire').read_text().splitlines() if x.startswith('data: {')]
response=rows[-1]['response']
assert rows[-1]['type']=='response.failed' and response['error']['code']=='step_admission_unavailable'
assert response['output'][0]['type']=='program_output' and response['output'][0]['status']=='completed'
queries=[json.loads(s) for s in (RUN/'lease/nvml-queries.jsonl').read_text().splitlines()]
assert queries and all(x['status']=='OK' and x['returncode']==0 for x in queries)
stop=read(RUN/'execution/stop.json');assert stop['cleanup_confirmed'] and stop['stop_durable'] and stop['state']=='STOPPED'
identities=set()
for s in (RUN/'execution/status.jsonl').read_text().splitlines():
 v=json.loads(s)
 for role in ('guardian','controller','model','gateway'):
  if v.get(role+'_pid'):identities.add((v[role+'_pid'],v[role+'_start_ticks']))
for pid,tick in identities:
 try:assert journal.process_start(pid)!=tick
 except (FileNotFoundError,ProcessLookupError):pass
package=Path(plan['package']['package']);policy=read(package/'gateway-policy.json')
for field in ('listen_port','upstream_port','upstream_operations_port'):
 with socket.socket() as s:
  s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',policy[field]))
with Path(guard['lock_path']).open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert all(sha(Path(v['path']))==v['sha256'] for v in plan['protected'])
files=[p for d in (RUN,RUN/'lease',RUN/'execution') for p in d.iterdir() if p.is_file() and p.name!='budget.lock']
files += [p for prefix in ('managed-version-prepare-01','managed-version-run-01') for p in W.glob(prefix+'.*')]
files += [W/'program_managed_acceptance.py',W/'qualification-freeze-01.json']
secrets=[c['api_key'].encode() for c in policy['clients']]
for p in files:assert not any(s and s in p.read_bytes() for s in secrets)
OUT.mkdir()
with tarfile.open(OUT/'original.tar.gz','w:gz') as ar:
 for p in files:ar.add(p,arcname=str(p.relative_to(W)))
record=dict(status='FAILED_REQUIRES_REPAIR',error=response['error'],counts=result['budget']['counts'],seconds=result['seconds'],nvml_queries=len(queries),env_abort=False,program_resumed=True,final_model_step_admitted=False,default_unchanged=True,owned_processes_gone=True,ports_free=True,lock_released=True,package=plan['package'],source_commit=plan['source_commit'])
(OUT/'decision.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'raw-sha256.json').write_text(json.dumps({str(p.relative_to(W)):sha(p) for p in files},indent=2)+'\n')
(OUT/'README.md').write_text('''# 程序续接在受控配额下失败（2026-11-15）

实际整树切换已完成：Guardian保持，控制器/模型/入口换代，程序与caller
持久身份恢复，错误结果schema拒绝。真实资料只读执行一次后，VM输出
正确program_output，但模型首次续答前返回step_admission_unavailable。
因此整体验收失败，不能以恢复成功掩盖最后业务未闭环；默认rev118未改。

根因：生成循环在程序resume后先continue，下次准备实际提示时无条件
调用ExtendPrompt；该接口要求started，而当前请求尚未入场任何模型步。
直接无客户端限额的原短验跳过该路径，未覆盖受控多客户端组合。
修复必须重新预留尚未入场提示，并保留RPM/输出预算/已发生用量，
不能关闭配额或把程序结果当最终答案。修后只按受影响合同补验。

本轮2启动4业务1探测；实际耗时与NVML次数见decision.json。无ENV_ABORT，
自有进程、端口、GPU锁均已确认清理，失败原件保留。源码修复进行中，
此记录不构成通过或发行证明，全部master任务持续。
''')
(OUT/'sha256.json').write_text(json.dumps({p.name:sha(p) for p in OUT.iterdir() if p.is_file()},indent=2)+'\n')
print(json.dumps(record))

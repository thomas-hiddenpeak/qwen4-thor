from pathlib import Path
import hashlib,json,runpy,tarfile
ROOT=Path.cwd();W=ROOT/'.q4t-work/serve-programmatic-tools-20261113';B=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
E=ROOT/'docs/evidence/serve-programmatic-resume-rate-cpu-20261115'
assert not E.exists()
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=read(W/'resume-rate-freeze-02.json')
assert all(sha(ROOT/n)==h for n,h in freeze['sources'].items())
for name in ('resume-rate-build-02','resume-rate-cpu-01','resume-rate-audit-02','resume-rate-engine-build-01'):
 r=read(W/(name+'.json'));assert r['exit_code']==0 and r['default_unchanged']
 if 'build' in name:assert not any(s in (W/(name+ext)).read_text() for s in ('warning:','error:') for ext in ('.stdout','.stderr'))
assert '26 tests, 26 passed, 0 failed, 0 skipped' in (W/'resume-rate-cpu-01.stdout').read_text()
compiled=read(B/'generated/q4t/server/chat_protocol_sources.json')
assert all(sha(ROOT/n)==h for n,h in compiled.items())
repair_names={'include/q4t/server/client_policy.h','src/server/client_policy.cpp','src/server/chat_generation.cpp'}
record=dict(status='PASS_TARGETED_PENDING_PROMPT_REPLAN',cpu_passed=26,new_cases=7,related_cases=19,
 binary_sha256=sha(B/'q4t'),runtime_sources={n:sha(ROOT/n) for n in sorted(repair_names)},
 zero_build_warnings=True,new_gpu_starts=0,default_unchanged=True,actual_managed_business_pending=True,
 audit_negative_checks=7,build_failure_retained='CPU fixture ternary bool/Status; fixed before executing the frozen list',
 source_audit_initial_failure='Three reviewed runtime hashes stale; renewed only those anchors',
 test_sources=freeze['sources'])
files=sorted({p for pattern in ('resume-rate-*','resume-rate-required-01.txt') for p in W.glob(pattern) if p.is_file()})
E.mkdir()
with tarfile.open(E/'original.tar.gz','w:gz') as ar:
 for p in files:ar.add(p,arcname=p.name)
(E/'decision.json').write_text(json.dumps(record,indent=2)+'\n')
(E/'raw-sha256.json').write_text(json.dumps({p.name:sha(p) for p in files},indent=2)+'\n')
(E/'README.md').write_text('''# 首次模型入场前程序续接的配额修复（2026-11-15）

为尚未入场的提示重新计算预留，保留已入场用量、原RPM和输出预算；
不假装模型已开始，不将旧提示与新提示重复相加。Batch保留既有
预留容量，超出时原子检查TPM；认领失败不能借此恢复成有效请求。
生成循环按实际模型入场选择重新预留或追加后续步输入。

26项针对性CPU全部通过（7新增、19直接受影响）：增长/退款、取消、
已发生准备工作、身份/限额拒绝、窗口与冻结、Batch额度与错误认领、
并发TPM竞争及程序持久/异步/串行组合。主机与实际引擎构建零警告。
最初夹具bool/Status编译错误及来源清单陈旧失败原件保留，修后仅
更新三项已审阅哈希，7项来源负控通过。0新增GPU，默认rev118不变。

此处仅接受CPU合同，实际整树恢复中的最终业务失败尚须补验。
新引擎须重新绑定主轻资格及精确包，旧无客户端限额业务只用于
未改路径的明确复用，不冒充受控配额已通过。全部master继续。
''')
(E/'sha256.json').write_text(json.dumps({p.name:sha(p) for p in E.iterdir() if p.is_file()},indent=2)+'\n')
native=read(W/'native-build.json')
for key,name in [('guardian_sha256','q4t-guardian'),('ingress_sha256','q4t-ingress'),('cuda_probe_sha256','q4t-cuda-probe'),('device_control_sha256','q4t-device-control')]:
 assert sha(B/name)==native[key]
assert all(sha(ROOT/n)==h for n,h in native['source_files'].items())
native['reuse_review'].update(current_build_result=str(W/'resume-rate-engine-build-01.json'),current_build_result_sha256=sha(W/'resume-rate-engine-build-01.json'),rationale='Programmatic first-step rate repair affects only engine code. Four helpers rebuilt, source and bytes unchanged; accepted helper behavior reused.')
(W/'native-build-02.json').write_text(json.dumps(native,indent=2)+'\n')
old=read(W/'runtime-review.json')
helpers=runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))
runtime=helpers['source_hashes']();runtime.update(compiled)
assert {n for n,h in runtime.items() if old['runtime_source_sha256'].get(n)!=h}==repair_names
previous=read(Path(read(ROOT/'build/q4t.release.json')['tested_source_manifest']))
old.update(runtime_source_sha256=runtime,runtime_delta=sorted(n for n,h in runtime.items() if previous.get(n)!=h),native_rebuild_receipt_sha256=sha(W/'native-build-02.json'),rate_repair_evidence=str(E/'decision.json'),rate_repair_evidence_sha256=sha(E/'decision.json'))
(W/'runtime-review-02.json').write_text(json.dumps(old,indent=2)+'\n')
limits=read(W/'qualification-freeze-01.json')
limits.update(binary_sha256=record['binary_sha256'],reason='Actual managed program resume failed before first model admission; repair reviewed in exactly three runtime files, 26 CPU cases passed. Qualify exact repaired binary before managed retest; no unrelated full quality/performance.',prior_qualification_attempt=dict(starts=5,requests=14,probes=1,version_passed=False),cumulative_maximum=dict(starts=10,requests=28,probes=2,seconds=3600))
(W/'resume-rate-revalidation-freeze-01.json').write_text(json.dumps(limits,indent=2)+'\n')
print(json.dumps(record))

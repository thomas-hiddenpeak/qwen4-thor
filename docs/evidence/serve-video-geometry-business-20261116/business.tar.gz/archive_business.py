import fcntl,json,re,tarfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_responses import background_acceptance as b
from tools.serve_recovery import bundle
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;work=W/'business-02'
plan,result,cleanup,exit_record=[read(work/name) for name in ['plan.json','result.json','cleanup.json','lease/exit.json']]
require(result['status']=='PASS_NATIVE_VIDEO_GEOMETRY_BUSINESS' and result['counts']['starts']==1 and result['counts']['chats']==4 and result['seconds']<600,'business incomplete')
require(exit_record['status']=='COMPLETED' and exit_record['child_returncode']==0 and exit_record['compute_backend']=='nvml' and exit_record['lease_inherited_by_child'],'strict environment failed')
queries=[json.loads(x) for x in (work/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and q['returncode']==0 for q in queries),'NVML failure')
require(cleanup['remaining']==[] and cleanup['model_exit']==0 and cleanup['ports_released'] and cleanup['lease_continuously_held'],'cleanup incomplete')
for n,h in {**plan['sources'],**plan['protected']}.items():require(sha(ROOT/n)==h,'source/default drift: '+n)
require(sha(plan['binary'])==plan['binary_sha256'],'binary changed');bundle.check_assets(plan['model'],plan['model_assets'])
guard=b.base.lifecycle.guard;processes=guard.processes()
require(not any(processes.get(int(p),{}).get('start_ticks')==v['start_ticks'] for p,v in cleanup['owned'].items()),'owned process still live')
b.probe_ports((plan['port'],plan['operations_port']))
with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
compiled=read(W/'candidate-02/chat_protocol_sources.json');require(all(sha(ROOT/n)==h for n,h in compiled.items()),'compiled source differs')
require(plan['requests']==read(W/'business-01/plan.json')['requests'],'original question/oracle request changed')
out=ROOT/'docs/evidence/serve-video-geometry-business-20261116';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p in sorted(work.rglob('*')):
  if p.is_file() and 'objects' not in p.relative_to(work).parts:
   require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),'private key')
   tar.add(p,arcname='business-02/'+str(p.relative_to(work)))
 for name in ['archive_business.py','gpu-business-02.json','gpu-business-02.stdout','gpu-business-02.stderr','identity-02.json']:
  tar.add(W/name,arcname=name)
receipt=dict(status='ACCEPT_NATIVE_VIDEO_GEOMETRY_BUSINESS',binary_sha256=plan['binary_sha256'],protocol_sha256=read(W/'identity-02.json')['protocol_sha256'],counts=result['counts'],seconds=result['seconds'],nvml_queries=len(queries),environment='strict_completed_all_nvml_ok',cleanup_complete=True,default_unchanged=True,actual_business=read(work/'business-summary.json'),compiled_source_identity=compiled,raw_archive_sha256=sha(out/'business.tar.gz'),previous_failure='docs/evidence/serve-video-geometry-business-failure-20261116/README.md',original_request_unchanged=True,managed_delivery_pending=True,performance_claim=False)
save(out/'acceptance.json',receipt)
(out/'README.md').write_text(f'''# 显示几何实际业务通过

2026-11-16，1启动/4创建/{result['seconds']:.3f}秒，{len(queries)}次NVML正常。
真实上传90度MP4、inline镜像SSE、像素比例与旋转组合的四角颜色和
portrait/landscape全部正确，计数与实际usage一致；删除自有上传后
同PID普通文本返回42。视频输入为原文件，未向模型提供预期角点或
layout分类；新增的原生来源宽、高取自实际验证帧。

首轮镜像layout错误原件保留，问题/请求/预期不变；不声称修正了模型
内部的视觉比例判断，也不把来源元数据推理等同纯像素识别的提升。
实际像素方向与比例另有CPU角点、最终处理网格和快照独立证据。
源/编译身份/模型资产/默认核对、自有PID/端口/锁清理通过。rev142
保持；继续新引擎主轻资格与可回退发行，未改恢复控制证据复用。
无性能、完整质量、全格式或长期稳定结论，全部master继续。
''')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['compiled_source_identity','actual_business']}))

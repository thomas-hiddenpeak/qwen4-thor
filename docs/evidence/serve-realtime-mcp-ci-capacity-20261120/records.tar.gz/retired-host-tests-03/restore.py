from pathlib import Path
import gzip,hashlib,json,os,sys
O=Path(__file__).resolve().parent
plan=json.loads((O/'plan.json').read_text())
for row in plan['files']:
 if len(sys.argv)>1 and Path(row['path']).parent.name!=sys.argv[1]:continue
 p=Path(row['path']);assert not p.exists(),'will not overwrite a new file'
 raw=Path(row['archive']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['archive_sha256']
 raw=gzip.decompress(raw);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 with p.open('xb') as f:f.write(raw)
 p.chmod(row['mode']);os.utime(p,ns=(row['atime_ns'],row['mtime_ns']))
 print(p)

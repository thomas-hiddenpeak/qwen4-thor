from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'settings-build-02';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
sources=['tests/test_main.cpp','tests/server_realtime_duplex_input_test.cpp','src/server/realtime_duplex_input.cpp','src/server/realtime_transcription_protocol.cpp','src/server/realtime_asr_policy.cpp','src/io/json.cpp','src/server/input_contract.cpp','src/server/output_schema.cpp','src/server/http_response.cpp']
headers=['include/q4t/server/realtime_duplex_input.h','include/q4t/server/realtime_transcription_protocol.h','include/q4t/server/realtime_asr_policy.h','include/q4t/io/json.h']
cmd=['g++-14','-std=c++23','-O2','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-pthread','-Iinclude',*sources,'-o',str(O/'duplex-settings-tests')]
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
save('plan.json',dict(command=cmd,sources={n:sha(R/n) for n in sources+headers},protected=protected,scope='Necessary directly linked CPU component build only; no test execution',seconds=180))
t=time.monotonic();p=subprocess.run(cmd,cwd=R,capture_output=True,timeout=180);(O/'build.stdout').write_bytes(p.stdout);(O/'build.stderr').write_bytes(p.stderr)
unchanged=all(sha(n)==h for n,h in protected.items())
v=dict(status='BUILD_PASS' if p.returncode==0 and b'warning:' not in p.stderr and unchanged else 'BUILD_FAIL',returncode=p.returncode,seconds=time.monotonic()-t,warnings=p.stderr.count(b'warning:'),binary_sha256=sha(O/'duplex-settings-tests') if (O/'duplex-settings-tests').exists() else None,default_unchanged=unchanged,gpu_actions=0)
save('result.json',v);print(json.dumps(v));print(p.stderr.decode()[-4500:]);raise SystemExit(v['status']!='BUILD_PASS')

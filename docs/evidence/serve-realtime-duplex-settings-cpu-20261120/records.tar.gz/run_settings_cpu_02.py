from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parents[2];A=Path(__file__).parent;O=A/'settings-cpu-02';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
new=['realtime_duplex_failed_settings_preserve_all_accepted_fields','realtime_duplex_uses_real_processing_contract_and_transcript_includes']
old=['realtime_transcription_ga_and_legacy_settings_are_equivalent','realtime_transcription_patch_preserves_and_explicit_null_clears','realtime_transcription_invalid_settings_are_atomic','realtime_transcription_commit_delta_final_and_actual_usage','realtime_history_queued_delete_skips_execution_and_future_context']
for name,names in [('new',new),('old',old)]:(O/(name+'.txt')).write_text('\n'.join(names)+'\n')
commands=[[str(A/'settings-build-02/duplex-settings-tests'),'--required-list',str(O/'new.txt')],[str(R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests'),'--required-list',str(O/'old.txt')],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
files=['src/server/realtime_duplex_input.cpp','include/q4t/server/realtime_duplex_input.h','tests/server_realtime_duplex_input_test.cpp','src/server/realtime_transcription_protocol.cpp','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake','CMakeLists.txt','tools/release/required_host_tests.txt','tools/serve_audit/inventory.json'];plan=dict(scope='Original 9 passes retained; only duplicate-field failed case plus one valid-field protection, then the unexecuted five legacy protections and source check. No runtime entry enabled',limits=dict(tests=7,source_counterexamples=20,seconds=120,gpu_starts=0),tests=new+old,commands=commands,sources={n:sha(R/n) for n in files},binaries={cmd[0]:sha(Path(cmd[0])) for cmd in commands[:2]},protected={n:sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']})
save('plan.json',plan);start=time.monotonic();runs=[];status='PASS'
env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O),PYTHONDONTWRITEBYTECODE='1')
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,timeout=max(.1,120-(time.monotonic()-start)));(O/f'command-{i}.stdout').write_bytes(r.stdout);(O/f'command-{i}.stderr').write_bytes(r.stderr);runs.append(dict(command=cmd,returncode=r.returncode))
 if r.returncode:status='FAIL';break
assert all(sha(R/n)==h for n,h in plan['protected'].items());result=dict(status=status,seconds=time.monotonic()-start,commands=runs,tests=7 if status=='PASS' else None,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

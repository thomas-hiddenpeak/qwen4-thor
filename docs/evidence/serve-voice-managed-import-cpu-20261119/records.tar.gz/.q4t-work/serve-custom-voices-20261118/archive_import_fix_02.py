from pathlib import Path
import json,tarfile,subprocess
from tools.native_tts.voice_service_acceptance import read,save,sha,defaults
from tools.serve_audit import check_inventory as audit
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=R/'docs/evidence/serve-voice-managed-import-cpu-20261119'
def put(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
failed=V/'retained-service-01';result=read(failed/'execution/result.json');assert result['status']=='FAILED' and result['budget']['counts']==dict(starts=0,chats=0,probes=0,controls=0)
assert read(failed/'lease/exit.json')['status']=='COMMAND_FAILED'
assert read(failed/'postflight-import-failure.json')['default_unchanged']
assert (failed/'plan.json').stat().st_size < 16<<20
plan=json.loads((failed/'plan.json').read_text());changed=[]
for name,h in plan['sources'].items():
 if sha(R/name)!=h:
  raw=subprocess.check_output(['git','show',plan['source_commit']+':'+name]);import hashlib
  assert hashlib.sha256(raw).hexdigest()==h
  p=failed/'original-sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);changed.append(name)
assert set(changed)=={'tools/native_tts/managed_voice.py','tools/native_tts/test_managed_voice.py'}
actual=audit.current_surface(R);inv=read(audit.INVENTORY);errors=audit.check(inv,actual);assert not errors
cpu=[read(V/n/'result.json') for n in ['managed-voice-import-cpu-01','managed-voice-import-cpu-02']];assert all(x['status']=='PASS' for x in cpu)
O.mkdir();save(O/'result.json',dict(status='PASS_SEALED_VOICE_DRIVER_IMPORT_CPU',distinct_cases=2,executions=3,runs=cpu,original_failed_starts=0,original_failed_posts=0,original_cleanup_error_retained=True,real_recovery_pending=True,default_replaced=False))
save(O/'audit.json',dict(anchors=len(actual['sources_sha256']),errors=errors,production_changed=False))
files=[]
for name in ['managed-voice-import-cpu-01','managed-voice-import-cpu-02','managed-voice-import-fix-01','candidate-storage-01','native-build-01']:
 files += [p for p in (V/name).rglob('*') if p.is_file() and p.suffix!='.gz']
files += [failed/n for n in ['plan.json','execution/result.json','postflight-import-failure.json','lease/exit.json','lease/events.jsonl','lease/nvml-queries.jsonl']]
files += [p for p in (failed/'original-sources').rglob('*') if p.is_file()]
for n in ['service-package-01','retained-01','tls-package-01']:files.append(V/n/'receipt.json')
files += [V/n for n in ['retained-01/review.json','prepare_voice_package.py','prepare_voice_retained.py','prepare_voice_tls.py','build_voice_native.py','run_voice_service_sequence.py','service-sequence-plan-01.json','service-sequence-result-01.json','deduplicate_voice_candidates.py','archive_import_fix.py','archive_import_fix_02.py','import-archive-failure-01.json']]
files += [R/n for n in changed]
# Private package policies/review bodies contain generated fixture credentials.
# Keep them locally; this public archive stores only non-secret package identities.
with tarfile.open(O/'records.tar.gz','x:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}))
put(O/'README.md','''# 受监护音色验收驱动：封装导入缺陷修复

首组恢复短验在启动模型前失败：生产命名空间按封装包隔离，测试专用
profile_voice不随生产包发行，验收actor直接import因而失败。原FAILED、
清理时尚未创建控制socket的ConnectionRefused及原源码/租约保持；
0模型、0业务POST，后续只读核实自有进程/端口/锁均已清理。

测试助手改为从冻结的固定源码文件显式加载，生产依赖仍严格来自
封装目录。新鲜隔离子进程重现不包含测试助手的发行环境，检查全部
生产模块路径；同ID跨恢复actor检查复用原完整合同。两项不同CPU、
三次执行均通过，0GPU。仅修改两份验收文件；引擎、控制包和已验
主轻资格身份保持。940来源锚点检查通过。

准备了C05候选、旧现代控制器组合和私有TLS包。旧控制器仅比候选
少已有的模型异常退出指纹通知分支，原文件逐字保留；将对同一保留
包分别做独立业务和实际自动回退，之后验证STOPPED根回退。不能
把准备/CPU当成真实恢复通过。冻结剩余三组总上限4启动/63业务POST/
1设备探测/1500秒，严格阶段租约、无失败自动重试。默认rev316保持。
''')
p=R/'docs/serve-master-goals-v2.json';g=read(p);g['native_tts_progress']['custom_voice']['service']['managed_import_fix']=dict(evidence='evidence/serve-voice-managed-import-cpu-20261119/README.md',cpu_distinct_cases=2,real_recovery_pending=True,original_failed_starts=0);put(p,json.dumps(g,ensure_ascii=False,indent=2)+'\n')
text='''[恢复驱动隔离导入修复](evidence/serve-voice-managed-import-cpu-20261119/README.md)：
首组在模型前import失败，0启动/0POST，原失败/清理socket错误保留，
进程/端口/锁后核实释放。2项不同CPU/3次执行通过，生产来源隔离保持；
同C05候选/回退/TLS包不变，继续3组4启动/63POST/1探测/1500秒。
'''
for n,m,v in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 封装音色验收导入修复与三组恢复冻结\n\n'+text+'\n为什么：验收助手不能突破生产封装来源边界；下一步：同包实际恢复短验和可回退发行。\n\n')]:
 p=R/n;s=p.read_text();assert m in s;put(p,s.replace(m,m+v,1))
print('Archived import failure, 2 distinct CPU checks and exact pending payloads')

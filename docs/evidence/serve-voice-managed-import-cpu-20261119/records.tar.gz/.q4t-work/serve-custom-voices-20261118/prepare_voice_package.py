"""Seal C05 qualified voices and prepare a native payload for actual recovery."""
import copy
import hashlib
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
WORK = Path(__file__).resolve().parent
OUT = WORK/'service-package-01'
PROFILE = WORK/'voice-profiles-02'
CANDIDATE = WORK/'voice-service-candidate-05'
BUILD = ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD = (ROOT/'build/service').resolve(strict=True)
CONTROL = {'tools/serve_recovery/'+n+'.py' for n in ('bundle','deployment',
    'profile_bundle','profile_contract','profile_controller','profile_evidence',
    'profile_migration','service')} | {'tools/serve_service/package.py',
    'tools/serve_service/service.py'}
NATIVE = {'CMakeLists.txt','include/q4t/server/application_routes.h',
    'include/q4t/server/http_connection.h','src/server/http_request.cpp',
    'src/service/ingress_main.cpp'}

def cp(source, target):
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    shutil.copyfile(source, target)

def main():
    os.umask(0o077)
    p.require(not OUT.exists(), 'preserve previous preparation')
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),
              'commit reviewed source first')
    before = {n:p.sha(ROOT/n) for n in ('build/q4t','build/q4t.release.json',
        'build/service/manifest.json','build/service.release.json',
        'build/service-native-state/ledger.json')}
    original = bundle.verify(OLD,p.sha(OLD/'manifest.json'))
    oldmeta = p.read(OLD/'engine/q4t.release.json')
    plan = p.read(PROFILE/'plan.json')
    qualification = p.read(PROFILE/'acceptance.json')
    p.require(qualification['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and
        qualification['environment']['status']=='PASS' and
        qualification['environment']['cleanup_complete'], 'actual qualification missing')
    helpers = runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))
    compiled = p.read(CANDIDATE/'chat_protocol_sources.json')
    runtime = helpers['source_hashes']();runtime.update(compiled)
    p.require(all(p.sha(ROOT/n)==h and plan['sources'].get(n,compiled.get(n))==h
                  for n,h in runtime.items()), 'qualified runtime drift')
    p.require(p.sha(CANDIDATE/'q4t')==p.sha(BUILD/'q4t')==plan['binary_sha256'],
              'qualified engine drift')
    previous = p.read(oldmeta['tested_source_manifest'])
    delta = sorted(n for n,h in runtime.items() if previous.get(n)!=h)
    control = {n for n in bundle.SOURCES if p.sha(ROOT/n)!=p.sha(OLD/'source'/n)}
    p.require(control==CONTROL,'unreviewed control changes')
    oldnative = p.read(OLD/'native-build.json')
    nativedelta = {n for n,h in oldnative['source_files'].items() if p.sha(ROOT/n)!=h}
    p.require(nativedelta==NATIVE, 'unreviewed native helper changes')
    built = p.read(WORK/'native-build-01/result.json')
    buildplan = p.read(WORK/'native-build-01/plan.json')
    p.require(built['status']=='PASS' and not built['warnings'], 'helper build failed')
    native = dict(version=1,source_repository=str(ROOT),
        source_files={n:p.sha(ROOT/n) for n in sorted(bundle.NATIVE_SOURCES)})
    p.require(native['source_files']==buildplan['sources'], 'helper build source drift')
    for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),
                       ('ingress','q4t-ingress'),('device_control','q4t-device-control')]:
        p.require(p.sha(BUILD/name)==built['binaries'][name], 'helper binary drift')
        native[field+'_sha256']=built['binaries'][name]
    evidence = ['serve-voice-chat-fix-20261119','serve-voice-sdk-tls-20261119',
        'serve-tts-checkpoint-witness-20261119','serve-voice-primary-light-20261119',
        'serve-voice-managed-driver-cpu-20261119','serve-tts-checkpoint-profile-cpu-20261119']
    evidence = {n:p.sha(ROOT/'docs/evidence'/n/'README.md') for n in evidence}
    OUT.mkdir(mode=0o700);engine=OUT/'engine'
    for n in ('q4t','CMakeCache.txt'):cp(CANDIDATE/n,engine/n)
    (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
    caps = p.read(PROFILE/'primary-capabilities.json')
    config = p.read(PROFILE/'primary-config.json')
    protocol = hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
    p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,
              'actual declaration mismatch')
    scope = ('C05 registered voice engine: actual consent/voice registration, ownership, '
        'full Speech/Chat with independent unhinted ASR, history and revocation; '
        'official Python voice SDK over native TLS. Exact current primary/light v11 '
        'profiles retain all configured input auxiliaries, document tools/schema/media/embedding '
        'and verify complete checkpoint-sampled builtin output plus family reload. '
        'Existing client artifacts unchanged. Managed payload/Guardian recovery is pending. '
        'Not acceptance of listening, general voice similarity, Base-only consumption, '
        'reference-audio ICL, prompt VoiceDesign, Live, full model quality or performance.')
    decision = dict(status='PASS_NATIVE_REGISTERED_VOICE_ENGINE_PROFILE_BUSINESS',
        acceptance='ACCEPT_NATIVE_REGISTERED_VOICE_ENGINE_PROFILE_BUSINESS',
        binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,
        source_commit=plan['source_commit'],actual_primary_light=qualification,
        source_delta=delta,control_delta=sorted(control),native_delta=sorted(nativedelta),
        evidence=evidence,scope=scope,managed_composition_pending=True,
        full_model_quality=False,performance_acceptance=False,default_changed=False,
        remaining_master_tasks_open=True)
    metadata = copy.deepcopy(oldmeta)
    metadata.update(version='serve-native-registered-voices-20261119',
        source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],
        acceptance=decision['acceptance'],acceptance_decision=str(OUT/'decision.json'),
        build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),
        tested_source_manifest=str(engine/'runtime-source.json'),
        tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),
        observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),
        previous_release=str(OLD/'engine/q4t.release.json'),
        inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),
                               sha256=p.sha(OLD/'engine/q4t.release.json')),source_note=scope)
    metadata['native_registered_voice_engine_acceptance']=decision
    declarations=engine/'declarations';declarations.mkdir(mode=0o700)
    p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
    metadata['chat_protocol'].update(caps,protocol_sha256=protocol,
        declaration_evidence=scope)
    for name,stem in helpers['SCHEMAS'].items():
        source=ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'))
        target=declarations/'schemas'/(name+'.json');cp(source,target)
        metadata['chat_protocol'][name+'_schema']=str(target)
        metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
    metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,
        directory=str(declarations),binary_sha256=plan['binary_sha256'],
        protocol_sha256=protocol,files={n:p.sha(declarations/n)
            for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
    for source in (ROOT/'third_party/licenses').rglob('*'):
        if source.is_file():cp(source,engine/'licenses'/source.relative_to(ROOT/'third_party/licenses'))
    metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output')
    metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
    for name,row in metadata['file_input_system_dependencies'].items():
        source=Path(row['artifact']);p.require(p.sha(source)==row['sha256'],'notice drift')
        target=engine/'licenses/system'/name;cp(source,target);row['artifact']=str(target)
    clients=metadata['client_artifacts']
    p.require(all(p.sha(ROOT/n)==h for n,h in clients['files'].items()),'client source changed')
    for n in clients['files']:cp(ROOT/n,OUT/'clients'/n)
    clients['directory']=str(OUT/'clients')
    p.save(OUT/'decision.json',decision)
    metadata['acceptance_decision_sha256']=p.sha(OUT/'decision.json')
    p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True)
    p.save(OUT/'native-build.json',native)
    settings=copy.deepcopy(plan['base']['settings'])
    policy=p.read(OLD/'engine/client-policy.json');prior=copy.deepcopy(policy)
    for client in policy['clients']:
        if client['id']=='alpha':
            client['max_output_tokens']=max(client['max_output_tokens'],
                settings['profile']['max_tokens']+settings['native_tts']['limits']['max_frames']*16+1)
            client['tokens_per_minute']=60000
    p.save(OUT/'clients.json',policy)
    kwargs={key:OLD/'engine'/n for key,n in [
        ('access_program_policy','access-program-policy.json'),
        ('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json'),
        ('web_policy','web-policy.json')] if (OLD/'engine'/n).is_file()}
    receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',plan['model'],
        BUILD/'q4t-guardian',BUILD/'q4t-cuda-probe',None,OLD/'gateway-policy.json',
        OUT/'clients.json',OUT/'bundle',native_receipt=OUT/'native-build.json',
        native_ingress=BUILD/'q4t-ingress',device_control=BUILD/'q4t-device-control',
        capacity_config=dict(version=2,**{k:v for k,v in settings['profile'].items()
                                          if k not in ('name','host')}),
        application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},
        embedding_model_dir=Path(settings['native_embedding']['directory']),
        asr_model_dir=Path(settings['native_asr']['directory']),
        asr_limits=settings['native_asr']['limits'],
        asr_auxiliary={k:v for k,v in settings['native_asr'].items() if k in p.ASR_AUXILIARY},
        tts_model_dir=Path(settings['native_tts']['directory']),
        tts_limits=settings['native_tts']['limits'],
        tts_base_model_dir=Path(settings['native_tts_base']['directory']),
        recovery_profiles=PROFILE/'qualified/registry.json',
        recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
    p.save(OUT/'receipt.json',receipt)
    p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,
              'unrelated settings changed')
    p.require(all(p.sha(ROOT/n)==h for n,h in before.items()),'default changed')
    p.save(OUT/'prepare-review.json',dict(status='MANAGED_VOICE_ACCEPTANCE_PENDING',
        previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),
        package_sha256=receipt['manifest_sha256'],source_delta=delta,
        control_delta=sorted(control),native_delta=sorted(nativedelta),
        client_policy_before=prior,client_policy_after=policy,
        private_quota_changes='alpha output budget 3457; TPM 60000 for composed business short test',
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        default_unchanged=True,model_actions=0,driver_sha256=p.sha(Path(__file__))))
    print(receipt['manifest_sha256'],flush=True)

if __name__=='__main__':main()

"""Build only current recovery helpers; never touch the published engine."""
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p

def main():
    os.umask(0o077)
    out = Path(__file__).resolve().parent / 'native-build-01'
    out.mkdir(mode=0o700, exist_ok=False)
    build = ROOT / '.q4t-work/serve-custom-tools-20261108/engine-build'
    names = ('q4t-guardian', 'q4t-cuda-probe', 'q4t-ingress', 'q4t-device-control')
    protected = {n:p.sha(ROOT/n) for n in ('build/q4t', 'build/q4t.release.json',
        'build/service/manifest.json', 'build/service.release.json',
        'build/service-native-state/ledger.json')}
    command = ['cmake', '--build', str(build), '--target', 'q4t_guardian',
        'q4t_cuda_probe', 'q4t_ingress', 'q4t_device_control', '--parallel', '4']
    sources = {n:p.sha(ROOT/n) for n in sorted(bundle.NATIVE_SOURCES)}
    plan = dict(command=command, sources=sources, protected=protected,
        previous={n:p.sha(build/n) for n in names}, model_actions=0,
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
    p.save(out/'plan.json', plan)
    with tarfile.open(out/'previous-programs.tar.gz', 'x:gz') as archive:
        for n in names: archive.add(build/n, arcname=n)
    started = time.monotonic()
    with (out/'build.log').open('x') as log:
        process = subprocess.run(command, cwd=ROOT, stdout=log,
            stderr=subprocess.STDOUT, timeout=600)
    warnings = [s for s in (out/'build.log').read_text().splitlines()
                if 'warning:' in s.lower()]
    passed = process.returncode == 0 and not warnings and all(
        p.sha(ROOT/n) == h for n,h in {**sources, **protected}.items())
    result = dict(status='PASS' if passed else 'FAIL', returncode=process.returncode,
        seconds=time.monotonic()-started, warnings=warnings,
        binaries={n:p.sha(build/n) for n in names}, default_unchanged=True,
        model_actions=0)
    p.save(out/'result.json', result)
    print(result, flush=True)
    p.require(passed, 'native helper build/source/protected check failed')

if __name__ == '__main__': main()

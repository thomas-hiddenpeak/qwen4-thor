import hashlib,io,json,re,subprocess,sys,tarfile
from dataclasses import asdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
from tools.serve_protocol.media_cache_acceptance import check_tool_reply
from tools.examples.chat_client import read_json,read_sse
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent;P=W/'business-01';OUT=W/'postflight-01'
OUT.mkdir(mode=0o700)
plan=read(P/'plan.json');result=read(P/'result.json');guard=read(P/'lease/exit.json')
require(result['status']=='FAILED' and result['counts']['starts']==2 and result['counts']['chats']==20 and result['error'].endswith('RuntimeError: actual tool answer\n'),'original failure changed')
require(guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1 and guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'],'environment differs')
queries=[json.loads(x) for x in (P/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(queries and all(x.get('status')=='OK' and x.get('returncode')==0 for x in queries),'environment gap')
for f in ['baseline-cleanup.json','cleanup.json']:
 c=read(P/f);require(c['remaining']==[] and c['model_exit']==0 and c['ports_released'] and c['lease_continuously_held'],'unclean original')
for n,h in {**plan['sources'],**plan['protected']}.items():
 if n=='tools/serve_protocol/media_cache_acceptance.py':
  prior=subprocess.check_output(['git','show',plan['source_commit']+':'+n],cwd=ROOT)
  require(hashlib.sha256(prior).hexdigest()==h,'original driver identity differs')
 else:require(sha(ROOT/n)==h,'identity drift '+n)
require(sha(plan['binary'])==plan['binary_sha256'] and sha(plan['baseline']['binary'])==plan['baseline']['sha256'],'engine drift')
values={}
for file in P.glob('*.result.json'):
 label=file.name[:-len('.result.json')];request=read(P/(label+'.request.json'))
 if label!='tool_follow':require(request==plan['requests'][label],'request drift '+label)
 value=(read_sse if request.get('stream') else read_json)(io.BytesIO((P/(label+'.wire')).read_bytes()))
 require(asdict(value)==read(file),'wire and parsed result differ '+label)
 require(value.finish_reason==('tool_calls' if label=='tool_call' else 'stop'),'missing terminal '+label)
 if label not in ('tool_call','tool_follow'):
  require(json.loads(value.message['content'])=={'visible_colors':True} if label.startswith('schema_') else value.message['content'].strip()=='YES','visual answer '+label)
 values[label]=value
for kind in ['image','video']:
 a,b=values['base_'+kind],values[kind+'_uncached'];require(a.message==b.message and a.logprobs==b.logprobs,'full/chunk differs')
 prepared=[read(P/(n+'-preflight.json')) for n in ['base_'+kind,kind+'_uncached',kind+'_write',kind+'_hit',kind+'_changed']]
 require(all(x['prompt']==prepared[0]['prompt'] and x['token_ids']==prepared[0]['token_ids'] for x in prepared),'comparison token differs')
 require(1024<len(prepared[0]['token_ids'])<2048,'comparison size')
for kind in ['image','video','schema']:
 a,b=values[kind+'_write'],values[kind+'_hit'];require(a.message==b.message and a.logprobs==b.logprobs,'same-boundary restore differs')
source=read(P/'actual-tool-execution.json');require(source['sha256']==sha(ROOT/source['path'])==plan['sources'][source['path']],'actual document drift')
call=values['tool_call'].message['tool_calls'][0];require(json.loads(call['function']['arguments'])=={'path':source['path']},'tool path')
follow=read(P/'tool_follow.request.json');require(follow['messages'][-2]==values['tool_call'].message and follow['messages'][-1]['tool_call_id']==call['id'] and json.loads(follow['messages'][-1]['content'])=={'path':source['path'],'sha256':source['sha256']},'tool closure')
check_tool_reply(values['tool_follow'].message['content'],source['sha256'])
for invalid in ['0123456789ab','2265eb26d4cb or 0123456789ab','2265eb26d4ca']:
 try:check_tool_reply(invalid,source['sha256'])
 except RuntimeError:pass
 else:raise RuntimeError('false digest accepted')
log=(P/'candidate-model.log').read_text();proof={}
hits={'image_hit','image_append','video_hit','schema_hit'}
for label,v in values.items():
 if label.startswith('base_') or label.startswith('tool_'):continue
 cached=v.usage.get('prompt_tokens_details',{}).get('cached_tokens',0)
 require(cached>=1024 if label in hits else cached==0,'hit/miss '+label)
 writes=re.findall(r'\[prefix-cache\] request='+re.escape(plan['requests'][label]['request_id'])+r' event=write prefix=(\d+) ttl=(\d+) saved=(\d+) bytes=(\d+)',log)
 restores=re.findall(r'\[session-cache\] request='+re.escape(plan['requests'][label]['request_id'])+r' event=restore prefix=(\d+) ms=\S+ error=(\S+) source=(\w+) layout=(\w+)',log)
 should_write=label not in hits|{'image_uncached','video_uncached'}
 require(bool(writes)==should_write and all(int(p)>=1024 and ttl=='1800' and ok=='1' and int(size)>0 for p,ttl,ok,size in writes),'actual SSD write '+label)
 if label in hits:require(restores==[(str(cached),'none','shared','target')],'actual restore differs')
 else:require(not any(int(x[0])>0 for x in restores),'negative restored state')
 proof[label]={'writes':writes,'restores':restores,'cached_tokens':cached}
for label in ['responses_write','responses_hit']:
 v=read(P/(label+'.sdk.json'));require(v['ok'] and len(v['exchanges'])==1 and v['result']['status']=='completed','Responses failed')
 from tools.serve_responses.acceptance import text,check_usage
 require(text(v['result']).strip()=='YES','Responses visual answer');check_usage(v['result'])
 cached=v['result']['usage']['input_tokens_details']['cached_tokens'];require(cached>=1024 if label.endswith('hit') else cached==0,'Responses hit/miss')
require(len(values)==18,'actual Chat count')
record=dict(status='ACCEPT_COMPLETED_20_REQUESTS_AFTER_DRIVER_CONTRACT_REVIEW',original_result_preserved=True,original_result_sha256=sha(P/'result.json'),original_guard_status=guard['status'],runtime_changed=False,driver_mismatch='Request asks to report SHA prefix; it does not require suppressing prose. Exact unique 12-hex value is checked.',negative_digest_checks=3,actual_starts=2,actual_external_requests=20,seconds=result['seconds'],nvml_queries=len(queries),cleanup_complete=True,binary_sha256=plan['binary_sha256'],old_full_new_chunk_exact=True,cold_warm_exact=True,state_evidence=proof,actual_tool_answer=values['tool_follow'].message['content'],unfinished=['private_write','private_follow'],new_gpu_starts=0,default_unchanged=True)
save(OUT/'acceptance.json',record)
print(json.dumps({k:v for k,v in record.items() if k!='state_evidence'}))

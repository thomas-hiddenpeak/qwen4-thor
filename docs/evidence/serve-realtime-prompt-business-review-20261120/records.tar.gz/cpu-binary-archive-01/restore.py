from pathlib import Path
import json,tarfile,hashlib,os
root=Path(__file__).resolve().parents[3];here=Path(__file__).resolve().parent
files=json.loads((here/'plan.json').read_text())['files']
with tarfile.open(here/'binaries.tar.gz','r:gz') as tar:
 for name,meta in files.items():
  path=root/name; assert path.is_relative_to(root/'.q4t-work')
  data=tar.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==meta['sha256']
  if path.exists():assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256'];continue
  with path.open('xb') as f:f.write(data)
  path.chmod(meta['mode'])

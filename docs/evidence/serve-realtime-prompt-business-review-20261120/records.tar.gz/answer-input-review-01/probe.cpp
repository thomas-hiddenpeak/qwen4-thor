#include <iostream>
#include <iterator>
#include <stdexcept>

#include "q4t/server/chat_prompt.h"
#include "q4t/text/tokenizer.h"
#include "q4t/server/realtime_chat_plan.h"
#include "src/server/object_protocol.h"

using namespace q4t::server;
using namespace q4t::server::object_detail;

std::string Render(const Json& request, const ChatRequestPlan& plan) {
  std::string result, parameter, code;
  std::vector<VisionItem> media;
  auto status = PrepareChatPrompt(
      plan.Request(request), plan.constraints, &result, &media, &parameter,
      &code, nullptr, false, plan.async_tool_call_ids, plan.responses_tool_media,
      plan.HeaderTools(), plan.tool_call_formats, plan.prepared_source_data);
  if (!status) throw std::runtime_error(status.message());
  return result;
}

int main(int argc, char** argv) {
  try {
    if (argc != 2) throw std::runtime_error("tokenizer path");
    std::unique_ptr<q4t::text::Tokenizer> tokenizer;
    auto loaded = q4t::text::Tokenizer::Load(argv[1], {}, &tokenizer);
    if (!loaded) throw std::runtime_error(loaded.message());
    const std::string text(std::istreambuf_iterator<char>{std::cin}, {});
    Json inputs;
    if (!q4t::io::ParseJson(text, &inputs, true) || !inputs.IsArray())
      throw std::runtime_error("input shape");
    ChatPlanConfig config;
    config.model = "qwen3.8-flash-next";
    config.structured = true;
    config.max_len = 8192;
    auto result = Array();
    for (const auto& row : inputs.array) {
      auto settings = DefaultRealtimeChatSettings(config, "");
      for (const auto& [name, value] : row.Find("settings")->object)
        Set(&settings, name, value);
      RealtimeChatPlan planned;
      ChatPlanError error;
      PromptSnapshot snapshot;
      const auto* reference = settings.Find("prompt");
      if (reference) {
        snapshot.api = PromptApi::kRealtime;
        snapshot.scope = "client:alpha";
        snapshot.reference = *reference;
        snapshot.request = *row.Find("prompt_request");
      }
      auto status = PlanRealtimeChat(settings, *row.Find("response"),
                                      *row.Find("items"), config, &planned,
                                      &error, reference ? &snapshot : nullptr);
      if (!status) throw std::runtime_error(status.message());
      ChatRequestPlan executed;
      config.preparing_file_inputs = true;
      status = PlanChatRequest(planned.generation.generation_request, config,
                               &executed, &error);
      if (!status) throw std::runtime_error(status.message());
      std::vector<uint32_t> tokens;
      auto encoded = tokenizer->Encode(Render(planned.generation.generation_request, planned.generation.chat), &tokens);
      if (!encoded) throw std::runtime_error(encoded.message());
      result.array.push_back(Object({
          {"tokens", Number(tokens.size())},
          {"label", *row.Find("label")},
          {"generation_request", planned.generation.generation_request},
          {"measured_prompt", String(Render(planned.generation.generation_request,
                                             planned.generation.chat))},
          {"executed_prompt", String(Render(planned.generation.generation_request,
                                             executed))},
          {"temperature", Number(executed.sampling.temperature)},
          {"top_p", Number(executed.sampling.top_p)},
          {"seed_set", Boolean(executed.sampling.seed.has_value())}}));
    }
    std::cout << OutputJson(result) << '\n';
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}

from pathlib import Path
import json,subprocess,re,hashlib,time,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def edit(n,old,new):
 p=R/n;s=p.read_text();assert s.count(old)==1,(n,s.count(old));t=p.with_suffix(p.suffix+'.edit');t.write_text(s.replace(old,new));t.replace(p)
edit('src/server/voice_registry.cpp','    Unknown(&reply, id);\n    return reply;','    Unknown(&reply, id);\n    if (reply.commit_unknown && !stage.id.empty())\n      Set(&reply.value, "stage_id", String(stage.id));\n    return reply;')
edit('src/server/voice_registry.cpp','  auto saved = Read(kind, id, access);\n  if (!saved.ok()) return saved;\n  auto erase = Request(kind, id, access, ObjectOperation::kErase);','  if (!ValidId(id)) return Error(400, "invalid_request", "Invalid voice ID");\n  // Ownership and durable integrity still apply. Semantic payload corruption\n  // must not prevent its owner from deleting an unusable optional resource.\n  auto saved = objects_.Execute(Request(kind, id, access), access.deadline,\n                                 access.cancelled);\n  if (!saved.ok()) return saved;\n  auto erase = Request(kind, id, access, ObjectOperation::kErase);')
edit('src/server/object_retention.cpp','    inspector.Reference(data.Find("consent"));','    inspector.Reference(data.Find("consent"));\n    if (!data.Find("consent") || data.Find("consent")->IsNull())\n      inspector.value.uncertain = true;')
edit('tests/server_voice_registry_test.cpp','  for (auto& [key, field] : data.object)\n    if (key == "condition_revision") field.str = "wrong checkpoint";','  auto missing = data;\n  std::erase_if(missing.object, [](const auto& field) {\n    return field.first == "consent";\n  });\n  Q4T_CHECK(InspectObjectRetention("voice", missing).uncertain);\n  for (auto& [key, field] : data.object)\n    if (key == "condition_revision") field.str = "wrong checkpoint";')
edit('tests/server_voice_registry_test.cpp','  Q4T_CHECK(registry.Resolve(id, Access(), &out).code == "voice_state_invalid");','  Q4T_CHECK(registry.Resolve(id, Access(), &out).code == "voice_state_invalid");\n  Q4T_CHECK(Ok(registry.DeleteVoice(id, Access())));')
p=R/'tests/server_voice_registry_test.cpp';s=p.read_text();s+='''

Q4T_TEST(voice_registry_uncertain_staging_keeps_ids_without_replaying) {
  Fixture f;
  f.options.io_timeout_ms = 250;
  struct Injection {
    Injection() { ObjectWorkerEntryForTesting("--q4t-object-worker-lost-ack"); }
    ~Injection() { ObjectWorkerEntryForTesting({}); }
  } inject;
  ObjectStore store(f.options);
  VoiceRegistry registry(store);
  const auto failed = Create(registry);
  Q4T_CHECK(!failed.ok() && failed.commit_unknown &&
            failed.ClientCode() == "object_commit_unknown");
  const auto id = failed.value.GetString("id");
  Q4T_CHECK(id.starts_with("cons_") &&
            failed.value.GetString("stage_id").starts_with("tool_run_"));
  const auto end = Clock::now() + 1s;
  while (store.Health().pending && Clock::now() < end)
    std::this_thread::sleep_for(1ms);
  Q4T_CHECK(!store.Health().pending);
  Q4T_CHECK(registry.RetrieveConsent(id, Access()).http_status == 404);
  Q4T_CHECK(registry.ListConsents(20, {}, Access())
                .value.GetArray("data")->array.empty());
  Q4T_CHECK(store.Health().workers_started == 2);
  return true;
}
''';t=p.with_suffix('.edit');t.write_text(s);t.replace(p)
for n in ['src/server/voice_registry.cpp','tests/server_voice_registry_test.cpp']:
 p=R/n;r=subprocess.run(['clang-format',str(p)],check=True,capture_output=True);t=p.with_suffix('.edit');t.write_bytes(r.stdout);t.replace(p)
plan=json.loads((V/'voice-registry-plan-01.json').read_text());plan['prior_unexecuted_plan']='voice-registry-plan-01.json';plan['required']+=['voice_registry_uncertain_staging_keeps_ids_without_replaying'];plan['cases']=26;plan['review']='voice-registry-review-01.json'
for n in list(plan['source_sha256'])+['src/server/object_retention.cpp','include/q4t/server/object_store.h','src/server/object_protocol.h','src/server/object_store.cpp','src/server/binary_store.cpp']:
 plan['source_sha256'][n]=hashlib.sha256((R/n).read_bytes()).hexdigest()
(V/'voice-registry-plan-02.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
O=V/'voice-registry-build-02';O.mkdir(exist_ok=False);assert shutil.disk_usage(R).free >= 256<<20
cmd=['cmake','--build','.q4t-work/serve-file-search-20261112/host','--target','q4t_host_tests','--parallel','4'];start=time.monotonic()
with (O/'build.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=180)
result={'status':'PASS_BUILD_ONLY' if r.returncode==0 else 'FAIL_BUILD','seconds':time.monotonic()-start,'returncode':r.returncode,'warnings':(O/'build.log').read_text().count('warning:'),'command':cmd}
if r.returncode==0:result['binary_sha256']=hashlib.sha256((R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests').read_bytes()).hexdigest()
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)

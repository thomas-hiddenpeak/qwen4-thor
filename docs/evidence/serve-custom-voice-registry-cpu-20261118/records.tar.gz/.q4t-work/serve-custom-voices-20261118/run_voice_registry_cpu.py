from pathlib import Path
import json,hashlib,time,subprocess,os,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-registry-cpu-01';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((V/'voice-registry-plan-02.json').read_text())
assert shutil.disk_usage(R).free >= plan['disk_reserve_bytes']
for n,h in plan['source_sha256'].items():assert sha(R/n)==h,n
binary=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';assert sha(binary)==json.loads((V/'voice-registry-build-02/result.json').read_text())['binary_sha256']
(O/'required.txt').write_text('\n'.join(plan['required'])+'\n')
defaults=['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json'];before={n:sha(R/n) for n in defaults}
cmd=[str(binary),'--required-list',str(O/'required.txt')];env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O/'fixtures'));start=time.monotonic()
with (O/'test.log').open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=plan['seconds'])
result={'status':'PASS' if r.returncode==0 else 'FAIL','returncode':r.returncode,'seconds':time.monotonic()-start,'requested_cases':plan['cases'],'command':cmd,'binary_sha256':sha(binary),'plan_sha256':sha(V/'voice-registry-plan-02.json'),'model_loads':0,'gpu_actions':0,'default_before':before,'default_after':{n:sha(R/n) for n in defaults}}
result['default_unchanged']=result['default_before']==result['default_after'];(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['default_before','default_after','command']}));raise SystemExit(r.returncode)

from pathlib import Path
import json,hashlib,tarfile,sys
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';E=R/'docs/evidence/serve-custom-voice-registry-cpu-20261118'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
sys.path.insert(0,str(R));from tools.serve_audit.check_inventory import current_surface,check,mutation_checks
surface=current_surface(R);p=R/'tools/serve_audit/inventory.json';inv=read(p)
changes={n:{'old':inv['sources_sha256'].get(n),'new':h} for n,h in surface['sources_sha256'].items() if inv['sources_sha256'].get(n)!=h}
expected={'include/q4t/server/voice_request.h','include/q4t/server/voice_registry.h','src/server/voice_request.cpp','src/server/voice_language.cpp','src/server/voice_registry.cpp','include/q4t/server/object_store.h','src/server/object_protocol.h','src/server/object_store.cpp','src/server/object_retention.cpp','src/server/binary_store.cpp','CMakeLists.txt','cmake/ChatProtocolIdentity.cmake'}
assert set(changes)==expected,changes
review={'scope':'Native Voice/Consent input and private durable records, no public runtime exposure yet','sources':changes,'contracts':['bounded exact multipart/JSON contracts including distinct sample/prompt branches','RFC5646 syntax without an extra ICU/runtime dependency','raw audio on existing owned binary chunks, exact 2048 F32 conditions, private metadata','CAS consent version with atomic voice creation; revoke on every new resolve; owned active snapshot','deletion recovers corrupt optional payload, incomplete retention graph protects owner','real phrase/audio/192-speaker verification and HTTP remain pending','historical reader new-kind compatibility requires a bridge before public state is produced'],'new_cpu':21,'direct_existing_cpu':5}
(V/'voice-registry-source-review-01.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
for n,d in changes.items():inv['sources_sha256'][n]=d['new']
inv['native_voice_registry_2026_11_18']={'state':'INPUT_AND_DURABLE_REGISTRY_CPU_QUALIFIED_RUNTIME_PENDING','evidence':['docs/evidence/serve-custom-voice-registry-cpu-20261118/README.md'],'reviewed_sources':sorted(expected),'runtime_api_accepted':False,'legacy_state_reader_bridge_pending':True}
write(p,json.dumps(inv,ensure_ascii=False,indent=2)+'\n');errors=check(inv,surface);assert not errors,errors
mutations=mutation_checks(inv,surface);(V/'voice-registry-inventory-01.json').write_text(json.dumps({'inventory_current':True,'reviewed_source_anchors':len(surface['sources_sha256']),'mutation_checks':mutations,'semantics_certified':False},indent=2)+'\n')
E.mkdir(exist_ok=False)
files={R/n for n in expected|{'tests/server_voice_request_test.cpp','tests/server_voice_registry_test.cpp','CMakeLists.txt','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake'}}
for name in ['voice-registry-build-01','voice-registry-build-02','voice-registry-cpu-01']:
 files|={p for p in (V/name).iterdir() if p.is_file() and p.suffix in ('.json','.txt','.log')}
for name in ['voice-registry-plan-01.json','voice-registry-plan-02.json','voice-registry-review-01.json','voice-registry-source-review-01.json','voice-registry-inventory-01.json','integrate_voice_registry.py','review_voice_registry.py','run_voice_registry_cpu.py','archive_voice_registry.py','archive_voice_registry_02.py','voice-registry-archive-check-01.json','voice-legacy-reader-01/identity.json','push-base-03.log']:files.add(V/name)
index={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}
with tarfile.open(E/'records.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
(E/'index.json').write_text(json.dumps(index,indent=2)+'\n')
result=read(V/'voice-registry-cpu-01/result.json');result.update(state='INPUT_AND_DURABLE_REGISTRY_CPU_QUALIFIED_RUNTIME_PENDING',new_cases=21,reused_direct_cases=5,builds=[read(V/n/'result.json') for n in ['voice-registry-build-01','voice-registry-build-02']],archive_sha256=sha(E/'records.tar.gz'),archive_files=len(index),runtime_api_accepted=False,full_task_complete=False,legacy_state_reader_bridge_pending=True)
(E/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(E/'README.md').write_text('''# Voice/Consent输入与持久登记CPU验收

21项新增与5项直接受影响旧合同全部通过，0.765秒；0模型/GPU。
必要host构建401.262秒，审查后增量构建25.615秒，均零警告。首份
25项计划未执行，审查补充未知提交负控后冻结26项；没有测试失败。
[结果](result.json)、[逐件身份](index.json)、[原始记录与源码](records.tar.gz)。

输入支持sample默认/显式类型、prompt JSON与multipart、consent创建/
改名，保留全部已知字段并拒绝重复、跨类型混用、伪声纹、非法UTF8。
音频上限10MiB；语言按[RFC 5646](https://www.rfc-editor.org/rfc/rfc5646.html)
检查完整结构与重复变体/扩展，语法通过不表示特定模型已能识别。
实际音频仍必须由有界codec及模型验证，MIME/文件名不代表真实内容。

持久层保留真实样本块、摘要、时长、独立192维身份与2048维Base条件，
公开metadata不泄漏这些私有信息。测试夹具只验证存储合同，不充当
真实音频/模型证据。条件逐值跨重启保持；注册与consent版本CAS原子
提交，竞争只成功一个，配额/取消/截止失败不发布伪对象。consent
撤销后每个新请求都失败，已取得条件的有界请求保留自己的快照。
未知提交保留公开ID及私有stage排查ID，不重放；损坏音色可由所属
客户删除，缺依赖保守保护，音频及consent依赖纳入原生保留图。

来源为已固定当前官方[音色创建](https://developers.openai.com/api/reference/resources/audio/subresources/voices/methods/create)、
[授权录音](https://developers.openai.com/api/reference/resources/audio/subresources/voice_consents/methods/create)
及本地SDK；prompt后端、真实授权短语/说话人验证、HTTP新文本合成、
参考音频ICL、听感/相似度仍继续，不能由CPU注册夹具替代。

源码审查发现历史存储读取器拒绝新voice/voice_consent种类，会影响
旧包读取含新对象的目录。当前默认未产生新对象；发布前须建立兼容
回退包，并以保留实际数据的回退验证闭合，不能只检验空目录。旧CPU
读取器独立保留用于后续对照。默认rev316及五份身份未变，全部master
仍active。Base真实合成提交047fc13b在前两次408后第三次推送成功。
''')
note='''[Voice/Consent登记26项CPU通过](evidence/serve-custom-voice-registry-cpu-20261118/README.md)：
0.765秒，21新增+5旧合同，必要构建零警告；0GPU、默认保持。
精确条件/私有录音、客户隔离、CAS、撤销、配额、未知提交及重启
通过。下一步真实授权/说话人验证、24kHz原始音频接入和HTTP新文本；
新增对象类型的旧包读取兼容须在发布前闭合，总目标继续。

'''
p=R/'docs/STATUS.md';s=p.read_text();write(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：原生音色持久登记与输入26项CPU通过\n\n'+note+'首次25项计划0执行，审查补充未知提交负控后统一26项通过；实际\n运行后端和旧包有状态回退继续，不以阶段通过结束总任务。\n\n'+s.split('\n',1)[1].lstrip('\n'))
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['native_tts_progress']['custom_voice']['registry']={'state':result['state'],'evidence':str((E/'README.md').relative_to(R/'docs')),'cpu_cases':26,'gpu_loads':0,'runtime_api_accepted':False,'legacy_state_reader_bridge_pending':True};write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/SERVE_CUSTOM_VOICES_2026-11-18.md';s=p.read_text();s+='\n[输入与持久登记26项CPU已通过](evidence/serve-custom-voice-registry-cpu-20261118/README.md)。\n尚未接入实际HTTP。保留原始24kHz条件输入，真实授权与同人验证后\n才登记；新增对象类型需要兼容读取回退包，有状态回退是发行必要项。\n';write(p,s)
print(json.dumps({'state':result['state'],'archive_files':len(index),'source_anchors':len(surface['sources_sha256']),'mutation_checks':mutations},ensure_ascii=False))

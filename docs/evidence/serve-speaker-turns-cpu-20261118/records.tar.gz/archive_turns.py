import hashlib, importlib.util, json, subprocess, tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2]; D=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-speaker-turns-cpu-20261118'; C=D/'turns-cpu-01'
read=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(C/'plan.json'); r=read(C/'result.json')
assert r['returncode']==0 and r['tests']==14 and r['seconds']<=180
assert '14 tests, 14 passed, 0 failed, 0 skipped' in (C/'tests.log').read_text()
for k,v in p['sources'].items():assert sha(R/k)==v,k
for k,v in p['protected'].items():assert sha(R/k)==v,k
assert sha(Path(p['command'][0]))==p['binary_sha256']
for name in ['turns-build-01','turns-build-02','turns-build-03','turns-runtime-build-01']:
 assert read(D/name/'result.json')['returncode']==0
 assert 'warning:' not in (D/name/'build.log').read_text()
s=importlib.util.spec_from_file_location('audit',R/'tools/serve_audit/check_inventory.py'); m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
actual=m.current_surface(R); inv=read(m.INVENTORY)
changed=[k for k in sorted(inv['sources_sha256'].keys()|actual['sources_sha256'].keys()) if inv['sources_sha256'].get(k)!=actual['sources_sha256'].get(k)]
assert len(changed)==20
for k in ['fields','completion_fields','routes','native_routes']:assert set(inv[k])==set(actual[k])
assert inv['whitelists']==actual['whitelists']
inv['sources_sha256']=actual['sources_sha256']
inv['speaker_component_review_20261118']={'reviewed_anchors':changed,'scope':'Fixed ECAPA numerical/assets/resources and request-local window/cluster/output components. HTTP remains pending and is not claimed by this source gate.','evidence':['docs/evidence/serve-speaker-compute-20261118/README.md','docs/evidence/serve-speaker-service-assets-20261118/README.md','docs/evidence/serve-speaker-turns-cpu-20261118/README.md']}
m.INVENTORY.write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n')
with (C/'inventory.log').open('w') as f:
 checked=subprocess.run(['/usr/bin/python3','-B',str(R/'tools/serve_audit/check_inventory.py'),'--self-check'],cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=60)
assert checked.returncode==0
O.mkdir()
files=[Path(__file__).resolve()]
for name in ['turns-build-01','turns-build-02','turns-build-03','turns-runtime-build-01','turns-cpu-01']:
 files += [f for f in (D/name).rglob('*') if f.is_file()]
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for f in sorted(files):t.add(f,arcname=str(f.relative_to(D)),recursive=False)
a={'status':'ACCEPT_SPEAKER_TURNS_OUTPUT_CPU','tests':14,'seconds':r['seconds'],'gpu_loads':0,'http_requests':0,'constructed_embeddings_only':True,'real_speech_accuracy_accepted':False,'runtime_build':'PASS_ZERO_WARNINGS','candidate_engine_sha256':sha(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t'),'inventory_anchors_reviewed':20,'inventory_negative_controls':7,'default_revision':286,'defaults_unchanged':True,'speaker_http_delivered':False,'all_master_tasks_active':True,'archive_sha256':sha(O/'records.tar.gz')}
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Speaker分段、聚类与原生输出CPU验收（2026-11-18）

14项/{r['seconds']:.3f}秒通过，0GPU/HTTP。覆盖真实区间窗口/强制片段
拼接/静音空隙，构造声纹的同人回访/异人/平均连接防链式误合并，
已知参考与标签冲突、歧义、容量/取消/失败原子性。输出按实际给定
词时间分配声音标签，中文/标点/零时长词、跨片段ID、同一对象的
JSON/SSE、实际usage、序列化前的累计字节边界均通过。

这是算法和协议组件验证，构造向量不等于真实语音准确率，更不是
diarized HTTP已可用。继续独立后端、真实音频/参考与API/恢复/交付；
重叠检测分离及全部master继续。默认rev286未变，必要运行时及host
构建零警告；20源码锚点已逐项对应既有ECAPA/资产证据和本组，
防遗漏门禁与7负控通过。未复跑完整性能/模型质量或长稳。
''')
p=R/'docs/serve-master-goals-v2.json';data=read(p);task=next(t for t in data['tasks'] if t['id']=='A10')
task['speaker_turns_output_20261118']=dict(a,evidence='evidence/serve-speaker-turns-cpu-20261118/README.md')
task['audio_auxiliary_delivery_20261118'].update(main_integration_pending=False,pull_request=45,main_commit='0ab3ce6a877e534a41bfaa7e6fb836939aa72fe4',main_evidence='evidence/serve-audio-capability-ci-20261118/merge-receipt.json')
p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n',f'''## 正在推进

[Speaker分段/原生输出14CPU通过](evidence/serve-speaker-turns-cpu-20261118/README.md)，
{r['seconds']:.3f}秒、0GPU/HTTP；构造声纹的聚类/参考/容量/取消与真实给定
时间到JSON/SSE/usage通过，不能代替真实语音或API。运行时零警告，
20源码锚点及7负控已核对；继续后端/真实业务/恢复交付与全部master。
默认rev286不变，PR45已合main0ab3ce6a。

''',1))
p=R/'docs/log/2026-11-18.md';head,tail=p.read_text().split('\n',1);p.write_text(head+f'''

## Speaker分段/聚类与输出14CPU通过（2026-11-18）

14项/{r['seconds']:.3f}秒、0GPU/HTTP，声音窗口/平均连接/参考歧义、实际
词时间的JSON/SSE及资源/取消通过；新增累计转义字节检查，防止
只到最后才发现超限。host与运行时零警告，20锚点/7门禁负控通过。
原因：实际业务需要完整声音到输出链；构造向量不代表真实语音
准确率。下一步独立后端、真实音频/API与全部master；默认rev286不变。
[证据](../evidence/serve-speaker-turns-cpu-20261118/README.md)。
'''+tail)
print(json.dumps(a));print((C/'inventory.log').read_text())

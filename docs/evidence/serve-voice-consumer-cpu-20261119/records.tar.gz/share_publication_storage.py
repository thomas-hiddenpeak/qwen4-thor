"""Deduplicate identical immutable published engines without deleting paths."""
import hashlib,json,os,stat,subprocess,time
from pathlib import Path
R=Path.cwd(); V=R/'.q4t-work/serve-custom-voices-20261118'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((V/'publication-storage-plan-01.json').read_text())
out=V/'publication-storage-01';out.mkdir()
protected={str(p):sha(p) for p in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service/manifest.json',R/'build/service.release.json',R/'build/service-native-state/ledger.json']}
run=subprocess.run([str(R/'build/q4t'),'service','status','--state',str(R/'build/service-native-state')],capture_output=True,text=True,timeout=15)
(out/'status.stdout').write_text(run.stdout);(out/'status.stderr').write_text(run.stderr)
assert run.returncode==0 and json.loads(run.stdout)['state']=='STOPPED'
allowed=[R/'build/.q4t-publication/generations',V/'capacity-01/generations-1-archive']
for row in rows:
 for item in row['files']:
  p=Path(item['path']);s=p.lstat()
  assert any(p.is_relative_to(parent) for parent in allowed)
  assert p.name=='q4t' and stat.S_ISREG(s.st_mode) and not s.st_mode&0o222
  assert (s.st_ino,s.st_size,s.st_mode&0o777,s.st_uid,s.st_gid)==(item['inode'],item['bytes'],row['mode'],row['uid'],row['gid'])
  assert sha(p)==row['sha256']
results=[];before=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
for row in rows:
 canonical=Path(row['files'][0]['path'])
 for item in row['files'][1:]:
  p=Path(item['path'])
  if p.stat().st_ino==canonical.stat().st_ino:continue
  assert sha(p)==sha(canonical)==row['sha256']
  temporary=p.with_name('.q4t-share-20261119');assert not temporary.exists()
  os.link(canonical,temporary);os.replace(temporary,p)
  fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
  try:os.fsync(fd)
  finally:os.close(fd)
  assert sha(p)==row['sha256'] and p.stat().st_ino==canonical.stat().st_ino
  results.append(dict(path=str(p),canonical=str(canonical),sha256=row['sha256'],bytes=item['bytes'],old_inode=item['inode'],new_inode=p.stat().st_ino))
for p,digest in protected.items():assert sha(Path(p))==digest
result=dict(status='PASS_IDENTICAL_IMMUTABLE_PUBLICATION_STORAGE_SHARED',files=results,protected=protected,original_paths_retained=True,unique_content_deleted=False,default_publication_unchanged=True,new_gpu_starts=0,free_before=before,free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('files','protected')}))

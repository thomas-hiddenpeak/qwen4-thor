import hashlib,json,unittest
from pathlib import Path
from tools.serve_audit import check_inventory as audit
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,value):
 t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');t.replace(p)
p=R/'tools/serve_audit/inventory.json';j=json.loads(p.read_text());actual=audit.current_surface(R)
old=j['sources_sha256'];new=actual['sources_sha256'];changed=sorted(k for k in old.keys()|new.keys() if old.get(k)!=new.get(k))
assert set(changed)=={'tools/serve_recovery/profile_acceptance.py','tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_consumer.py'},changed
j.update(actual);j['base_only_voice_consumer_20261119']=dict(state='SOURCE_READY_CPU_PENDING',sources={k:new[k] for k in changed},scope='Explicit Base-only qualification from accepted persistent voice state; full independent-ASR-proven audio witnesses, no registration dependency, same ownership and live revocation. No default capability removal or automatic profile downgrade.')
put(p,j)
names=['tools.serve_recovery.test_profile_consumer','tools.serve_recovery.test_voice_profiles.VoiceProfiles','tools.serve_recovery.test_profile_voice.VoiceDriver.test_registration_budget_and_both_commands_keep_actual_base_dependencies','tools.serve_recovery.test_profile_voice.VoiceDriver.test_policy_preflight_requires_three_clients_without_changing_profile']
loader=unittest.TestLoader();suite=loader.loadTestsFromNames(names);assert not loader.errors,loader.errors
out=V/'consumer-cpu-01';out.mkdir()
plan=dict(scope='Base-only saved-voice qualification; CPU contracts only',tests=names,cases=suite.countTestCases(),seconds=180,gpu_starts=0,source_sha256={k:sha(R/k) for k in changed+['tools/serve_recovery/test_profile_consumer.py','tools/serve_audit/inventory.json']},default_sha256={str(p):sha(p) for p in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service/manifest.json',R/'build/service.release.json',R/'build/service-native-state/ledger.json']},original_failures_preserved=True)
put(out/'plan.json',plan);print(json.dumps(dict(cases=plan['cases'],seconds=180,gpu=0,changed=changed)))
p=R/'docs/STATUS.md';s=p.read_text();intro=f"Base-only已有音色消费资格源码完成：显式移除私有验证配置的ASR/内置TTS，\n使用原真实登记状态；完整音频逐字节复用独立识别证据，验证跨客户、\n注册缺配置拒绝、撤销双路与无后端加载。冻结{plan['cases']}项CPU/180秒/0GPU。\n只读发布副本共享回收490.42MB，原路径/哈希/默认保持；PR49仍待CI。\n\n";t=p.with_name(p.name+'.tmp');t.write_text(s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1));t.replace(p)
p=R/'docs/log/2026-11-19.md';h,b=p.read_text().split('\n',1);t=p.with_name(p.name+'.tmp');t.write_text(h+'\n\n## 2026-11-19 — Base-only消费资格开发与存储保持\n\n'+intro+'为什么：已有音色消费不应被注册专用依赖绑定；下一步：针对CPU后，完成显式配置的真实资格与封装。\n'+b);t.replace(p)

import hashlib,json,tarfile
from pathlib import Path
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=R/'docs/evidence/serve-voice-consumer-cpu-20261119'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
result=read(V/'consumer-cpu-01/result.json');source=read(V/'consumer-cpu-01/inventory-fixed.json');inputs=read(V/'consumer-input-check-01/result.json');storage=read(V/'publication-storage-01/result.json')
assert result['status']=='PASS' and result['cases']==24 and source['inventory_current'] and source['mutation_checks']==17
assert inputs['status']=='PASS_REAL_SAVED_VOICE_INPUTS_BOUND' and inputs['compiled_source_changes']==[]
assert storage['status']=='PASS_IDENTICAL_IMMUTABLE_PUBLICATION_STORAGE_SHARED'
files={}
for d in ['consumer-cpu-01','consumer-input-check-01','publication-storage-01']:
 for p in (V/d).iterdir():
  if p.is_file():files[str(p.relative_to(V))]=p
for name in ['freeze_consumer_cpu.py','share_publication_storage.py','publication-storage-plan-01.json','archive_consumer_cpu.py']:
 files[name]=V/name
for name in ['tools/serve_recovery/profile_acceptance.py','tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_consumer.py','tools/serve_recovery/test_profile_consumer.py']:
 files['source/'+name]=R/name
assert not O.exists();O.mkdir()
index={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in files.items()};(O/'index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
a=dict(status='PASS_BASE_ONLY_CONSUMER_CPU_RUNTIME_PENDING',cpu_cases=24,cpu_seconds=result['seconds'],inventory_anchors=source['reviewed_source_anchors'],inventory_negatives=17,original_inventory_metadata_error_preserved=True,inventory_only_retested=True,real_saved_state_files=inputs['files'],compiled_engine_sources_unchanged=714,new_gpu_starts=0,default_revision=326,default_unchanged=True,storage_duplicate_inode_bytes=490422128,storage_paths_retained=True,unique_content_deleted=False,actual_base_only_business_accepted=False,registration_qualification_replaced=False,new_asr_inference=False,archive_sha256=sha(O/'records.tar.gz'),all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text('''# Base-only已有音色消费资格：CPU完成、真实业务待验

修复资格驱动把已有音色消费绑到注册专用ASR/VAD/speaker的问题。
新增显式`--voice-consumer`，只在私有候选配置选择Base-only；原默认
完整配置保持，不能将它作为自动降级丢能力的许可。生产引擎及714
编译来源保持，核心接口无本轮改动。

24项CPU通过，包含14项新正反例、8项原音色合同和2项原驱动合同；
完整输出、原条件与客户身份、独立状态副本、跨客户/撤销双路拒绝、
禁用后端零加载、原注册必需依赖以及8 POST/每profile路线均检查。
真实SDK保存的8份状态已核对，未经改写或新注册。完整Speech/Chat
音频见证复用原独立ASR与两profile逐字节一致的记录；消费验证将
要求全音频哈希一致，不用返回文本或前缀冒充内容通过，也不声称
本轮重新运行ASR。原始音频和speaker condition只留私有现场。

来源清单准备曾把描述字段映射误写成列表，原失败和原清单归档；
恢复映射后仅重验来源检查，941锚点/17负控通过，0重复CPU用例。

为后续短验，将14组、33路径的相同只读历史发布引擎共享存储；
释放490422128字节重复inode，原路径、内容、权限及默认完整保持，
未删除独有二进制/模型/证据。完整旧inode与新链接清单可核查。

下一步冻结同一租约下两profile真实消费短验和对应封装；CPU夹具
没有授予运行时资格。ICL/提示词音色/Live、听感与master剩余项继续。
''')
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
intro='''[Base-only消费资格24项CPU通过](evidence/serve-voice-consumer-cpu-20261119/README.md)：
原保存8文件和714编译来源核对；941来源锚点/17负控通过，清单结构
错误原件保留且仅重验清单。已有完整音频独立识别证据复用，真实
消费待验。只读发布副本共享释放490.42MB，路径/哈希/默认rev326保持。

'''
p=R/'docs/STATUS.md';put(p,p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-19.md';h,b=p.read_text().split('\n',1);put(p,h+'\n\n## 2026-11-19 — Base-only消费CPU通过及来源清单纠正\n\n'+intro.replace('(evidence/','(../evidence/')+'为什么：消费与注册依赖须分别验证；下一步：真实主轻消费和可选配置封装，不重复未受影响的恢复矩阵。\n'+b)
p=R/'docs/serve-master-goals-v2.json';j=read(p);j['native_tts_progress']['custom_voice']['service']['base_only_consumer_cpu']=a|dict(evidence='evidence/serve-voice-consumer-cpu-20261119/README.md');put(p,json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';put(p,p.read_text()+'\n- [Base-only已有音色消费CPU](evidence/serve-voice-consumer-cpu-20261119/README.md)：注册/消费依赖分离、真实保存状态与完整音频见证。\n')
print(json.dumps({k:a[k] for k in ['status','cpu_cases','cpu_seconds','inventory_anchors','new_gpu_starts']}))

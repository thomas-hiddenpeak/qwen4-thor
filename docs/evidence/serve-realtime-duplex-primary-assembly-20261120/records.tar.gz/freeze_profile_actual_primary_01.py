from pathlib import Path
import json,hashlib,pprint,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_recovery import ledger
O=W/'profiles-02'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
files=['plan.json','result.json','cleanup.json','lease/exit.json','lease/events.jsonl','lease/nvml-queries.jsonl','primary-capabilities.json','primary-config.json','primary-diagnostics.json','primary-duplex-sessions-observed.json','primary-duplex-entry-cleanup.json','primary-duplex-mixed.events.jsonl','primary-duplex-vad_once.events.jsonl','primary-duplex-mixed.sdk.json','primary-duplex-vad_once.sdk.json']
review={n:sha(O/n) for n in files}
rows=json.load(open(O/'primary-diagnostics.json'))
assert [r['quality']['status'] for r in rows]==['PASS','PASS','PASS','FAIL','PASS','PASS','PASS','PASS']
p=R/'tools/serve_recovery/profile_duplex_followup_source.py';s=p.read_text();assert 'FOLLOWUP_REVIEW' not in s
p.write_text(s+'\nFOLLOWUP_REVIEW = '+pprint.pformat(review,width=88)+'\n\nDIAGNOSTICS = '+repr(ledger.digest(rows))+'\n')
print('actual primary followup pinned',len(review))

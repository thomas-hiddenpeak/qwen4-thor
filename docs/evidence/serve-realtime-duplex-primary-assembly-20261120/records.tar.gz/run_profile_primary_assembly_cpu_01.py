from pathlib import Path
import json,hashlib,subprocess,time,os,sys,re
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profile-primary-assembly-cpu-01';O.mkdir(mode=0o700);sys.path.insert(0,str(R))
from tools.serve_recovery.profile_duplex_light_resume import primary
from tools.serve_recovery import profile_record
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
files=[p for p in (R/'tools/serve_recovery').glob('*duplex*.py')]+[R/n for n in ('tools/serve_recovery/profile_acceptance.py','tools/serve_realtime/duplex_sdk.mjs','tools/serve_realtime/duplex_quality_checks.py','tools/serve_audit/inventory.json','.github/workflows/host-checks.yml')]
commands=[['python3','-B','-m','unittest','-v','tools.serve_recovery.test_profile_duplex_resume','tools.serve_recovery.test_profile_duplex_followup.SourceAndDiagnostics.test_diagnostic_failure_is_preserved_and_cannot_be_relabelled','tools.serve_recovery.test_profile_duplex_followup.SourceAndDiagnostics.test_source_and_original_failure_cannot_be_replaced','tools.serve_recovery.test_profile_duplex_followup.SourceAndDiagnostics.test_repaired_driver_uses_same_client_policy_with_exact_work_bounds'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
plan=dict(scope='Fix metadata reader misuse, preserve exact original/diagnostic failures, assemble actual primary without a new model; permit only unrun light',limits=dict(tests=5,source_counterexamples=20,seconds=120,gpu_starts=0),commands=commands,sources={str(p.relative_to(R)):sha(p) for p in files},protected={n:sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')})
save('plan.json',plan);start=time.monotonic();runs=[];status='PASS'
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=120,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O)))
 (O/f'{i}.stdout').write_bytes(r.stdout);(O/f'{i}.stderr').write_bytes(r.stderr);runs.append(dict(command=cmd,exit_code=r.returncode))
 if r.returncode:status='FAIL';break
count=re.search(r'Ran (\d+) tests',(O/'0.stderr').read_text());tests=int(count[1]) if count else 0
if tests!=5:status='FAIL'
if status=='PASS':
 value=primary();profile_record.save(O/'primary-unqualified.json',value)
 assert profile_record.read(O/'primary-unqualified.json')==value
 save('assembly.json',dict(status='PASS_PRIMARY_PROTOCOL_AND_ACTUAL_CLARIFIED_TASKS',record_sha256=sha(O/'primary-unqualified.json'),record_bytes=(O/'primary-unqualified.json').stat().st_size,environment_pending_light=True,original_quality_status='FAIL',diagnostic_quality_status='FAIL',new_gpu_starts=0))
assert all(sha(R/n)==h for n,h in plan['protected'].items())
result=dict(status=status,tests=tests,seconds=time.monotonic()-start,commands=runs,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

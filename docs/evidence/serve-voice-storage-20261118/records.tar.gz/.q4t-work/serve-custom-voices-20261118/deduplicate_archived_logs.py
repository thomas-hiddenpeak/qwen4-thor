from pathlib import Path
import json,hashlib,gzip,os,stat,shutil,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'retained-logs-dedup-01';O.mkdir(exist_ok=False);reserve=256*1024**2;start=time.monotonic();rows=json.loads((V/'retained-log-pairs-review-01.json').read_text());free_before=shutil.disk_usage(V).free

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(1<<20):h.update(data)
 return h.hexdigest()

def unchanged(row):
 p=R/row['path'];s=p.stat();assert not p.is_symlink() and stat.S_ISREG(s.st_mode)
 assert (s.st_size,s.st_mode,s.st_uid,s.st_gid,s.st_mtime_ns,s.st_ino)==tuple(row[k] for k in ('bytes','mode','uid','gid','mtime_ns','inode'))
 assert s.st_uid==os.getuid()

inodes=set()
for pair in rows:
 assert len(pair)==2 and pair[0]['inode']!=pair[1]['inode']
 assert all(pair[0][k]==pair[1][k] for k in ('bytes','mode','uid','gid','mtime_ns'))
 for row in pair:unchanged(row);inodes.add((os.stat(R/row['path']).st_dev,row['inode']))
opened=[];unreadable=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  for fd in (proc/'fd').iterdir():
   try:
    s=fd.stat()
    if (s.st_dev,s.st_ino) in inodes:opened.append(str(fd))
   except (FileNotFoundError,PermissionError):pass
 except PermissionError:unreadable.append(proc.name)
 except FileNotFoundError:pass
assert not opened,opened
plan=dict(scope='Only three identical historical record/archive pairs; paths and bytes retained',pairs=rows,maximum_seconds=600,minimum_free_mib=256,open_matching_fds=opened,inaccessible_proc_pids=unreadable,backup='Independent gzip verified by full decompressed SHA before linking each pair',models_and_defaults_untouched=True)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
restore='''from pathlib import Path
import gzip,json,os,hashlib,shutil,stat
O=Path(__file__).resolve().parent
R=O.parents[2]
rows=json.loads((O/'completed.json').read_text())
for group in rows:
 backup=O/group['backup']
 if hashlib.sha256(backup.read_bytes()).hexdigest()!=group['backup_sha256']:
  raise RuntimeError('backup digest differs')
 for row in group['paths']:
  target=R/row['path']
  h=hashlib.sha256()
  if target.is_file():
   with target.open('rb') as f:
    while data:=f.read(1<<20):h.update(data)
   if h.hexdigest()==group['source_sha256'] and target.stat().st_nlink==1:
    continue
  if shutil.disk_usage(O).free < row['bytes']+256*1024**2:
   raise RuntimeError('restore needs extra space, originals preserved')
  temporary=target.with_name(target.name+'.q4t-restore-new')
  h=hashlib.sha256();count=0
  with gzip.open(backup,'rb') as src,temporary.open('xb') as dst:
   while data:=src.read(1<<20):
    dst.write(data);h.update(data);count+=len(data)
   dst.flush();os.fsync(dst.fileno())
  if count!=row['bytes'] or h.hexdigest()!=group['source_sha256']:
   raise RuntimeError('restored bytes differ, old path unchanged')
  temporary.chmod(stat.S_IMODE(row['mode']))
  os.utime(temporary,ns=(row['mtime_ns'],row['mtime_ns']))
  temporary.replace(target)
print('Independent original content restored at all six paths')
'''
(O/'restore.py').write_text(restore)
completed=[]
for i,pair in enumerate(rows):
 assert time.monotonic()-start<600
 for row in pair:unchanged(row)
 sources=[R/row['path'] for row in pair];expected=digest(sources[0]);assert digest(sources[1])==expected
 backup=O/f'group-{i}.gz'
 with sources[0].open('rb') as source,backup.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=1,mtime=0) as sink:
   while data:=source.read(1<<20):
    assert time.monotonic()-start<600 and shutil.disk_usage(V).free>=reserve+2*1024**2
    sink.write(data)
  raw.flush();os.fsync(raw.fileno())
 h=hashlib.sha256();count=0
 with gzip.open(backup,'rb') as f:
  while data:=f.read(1<<20):h.update(data);count+=len(data)
 assert count==pair[0]['bytes'] and h.hexdigest()==expected
 for row in pair:unchanged(row)
 target=sources[1];temporary=target.with_name(target.name+'.q4t-dedup-new');assert not temporary.exists();os.link(sources[0],temporary);temporary.replace(target)
 assert digest(target)==expected and target.stat().st_ino==sources[0].stat().st_ino
 record=dict(paths=pair,source_sha256=expected,backup=backup.name,backup_bytes=backup.stat().st_size,backup_sha256=digest(backup),shared_inode=target.stat().st_ino,original_paths_mode_and_mtime_preserved=True)
 completed.append(record);(O/'completed.json').write_text(json.dumps(completed,indent=2)+'\n');print(json.dumps(dict(group=i,status='PATHS_BYTES_AND_BACKUP_VERIFIED',free=shutil.disk_usage(V).free)),flush=True)
result=dict(status='DUPLICATE_HISTORICAL_RECORDS_DEDUPLICATED_PATHS_RETAINED',groups=3,paths=6,seconds=time.monotonic()-start,free_before=free_before,free_after=shutil.disk_usage(V).free,net_recovered=shutil.disk_usage(V).free-free_before,independent_backups=True,restore=str(O/'restore.py'),gpu_actions=0,model_loads=0);(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

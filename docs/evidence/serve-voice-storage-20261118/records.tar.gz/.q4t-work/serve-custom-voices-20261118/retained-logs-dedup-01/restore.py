from pathlib import Path
import gzip,json,os,hashlib,shutil,stat
O=Path(__file__).resolve().parent
R=O.parents[2]
rows=json.loads((O/'completed.json').read_text())
for group in rows:
 backup=O/group['backup']
 if hashlib.sha256(backup.read_bytes()).hexdigest()!=group['backup_sha256']:
  raise RuntimeError('backup digest differs')
 for row in group['paths']:
  target=R/row['path']
  h=hashlib.sha256()
  if target.is_file():
   with target.open('rb') as f:
    while data:=f.read(1<<20):h.update(data)
   if h.hexdigest()==group['source_sha256'] and target.stat().st_nlink==1:
    continue
  if shutil.disk_usage(O).free < row['bytes']+256*1024**2:
   raise RuntimeError('restore needs extra space, originals preserved')
  temporary=target.with_name(target.name+'.q4t-restore-new')
  h=hashlib.sha256();count=0
  with gzip.open(backup,'rb') as src,temporary.open('xb') as dst:
   while data:=src.read(1<<20):
    dst.write(data);h.update(data);count+=len(data)
   dst.flush();os.fsync(dst.fileno())
  if count!=row['bytes'] or h.hexdigest()!=group['source_sha256']:
   raise RuntimeError('restored bytes differ, old path unchanged')
  temporary.chmod(stat.S_IMODE(row['mode']))
  os.utime(temporary,ns=(row['mtime_ns'],row['mtime_ns']))
  temporary.replace(target)
print('Independent original content restored at all six paths')

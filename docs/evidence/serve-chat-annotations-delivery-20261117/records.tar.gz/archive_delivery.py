import hashlib,json,re,shutil,tarfile
from pathlib import Path
R=Path.cwd();W=R/'.q4t-work/serve-chat-annotations-20261116';D=W/'delivery-01'
read=lambda p:json.loads(p.read_text())
v=read(D/'result.json');assert v['status']=='PASS_CITATION_DELIVERED' and v['publication']['revision']==196
assert len(v['commands'])==18 and all(c['returncode']==0 for c in v['commands'])
c=v['publication']['current'];assert v['state']=='STOPPED' and not v['new_gpu_starts']
files=[(p,'delivery-01/'+p.name) for p in D.iterdir() if p.is_file() and not p.is_symlink()]
for stem in ['delivery-prepare-01','delivery-run-01','archive-generations-01','archive-versions-01','ci-schema-install-02','ci-schema-cpu-01']:
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
for n in ['archive_delivery.py','deliver.py','run_delivery.py','archive_generations.py','archive_version_cycles.py','publication-archive-applied.json','publication-archive-prepared.json','version-archive-applied.json','version-archive-prepared.json','version-archive-review.json','pr36-ci-original.log','pr36-ci-original.json']:
 files.append((W/n,n))
secrets=[]
def collect(x):
 if isinstance(x,dict):
  for k,a in x.items():
   if k in ['api_key','gateway_token','shared_secret','private_key','token'] and isinstance(a,str) and len(a)>=24:secrets.append(a.encode())
   else:collect(a)
 elif isinstance(x,list):
  for a in x:collect(a)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for p,n in files:
 data=p.read_bytes();assert not any(s in data for s in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',data),n
O=R/'docs/evidence/serve-chat-annotations-delivery-20261117';O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda p:p[1]):tar.add(p,arcname=n,recursive=False)
for n in ['result.json','recovery-anchor.json']:shutil.copy2(D/n,O/n)
a=dict(status='ACCEPT_CHAT_ANNOTATIONS_DELIVERY',revision=196,current=c,commands=18,seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,core_client_outer_bytes_preserved=True,profile_migration='qualified additive capability and identity; state, history, configuration and clock preserved',root_cycles_preserved=True,manual_root='42c34068b6a588746d74fc646f27d8994d131bef79f159d154b88e1bfbbcbc2e',automatic_payload='27db274590c76a68615631b0f8d98d2179c799e8a4d24813bd3ac1d531d2b223',older_engine_fallback=False,prior_rev188_preserved=True,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,files=len(files),secret_scan_matches=0,archive_sha256=hashlib.sha256((O/'records.tar.gz').read_bytes()).hexdigest(),main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Chat引用历史默认交付 rev196

已实际发布包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`。18项STOPPED操作完成：发布具有相同
新引擎能力的现代保留根、候选、实际整根回退、再前进及检查，
{v['seconds']:.3f}秒，0新增GPU，最终STOPPED。

核心/client/outer策略和恢复预算原字节保持。profile只按已通过主轻
资格扩展引用能力/绑定身份；历史、pending、原配置及clock完整保持。
两根原周期回填仅递增revision，未返还额度；outer启用、累计0启动。
人工整包回退42c34068保留outer与周期迁移，自动payload回退27db2745
使用已验旧控制/当前新引擎。两者均已实际SSE/存储/隔离短验；不是
独立旧引擎回退。原rev188包与状态备份另行保留，没有弱化能力合同。

退休发布generation和版本登记各2份经可恢复归档腾位，0删除。
[本轮业务](../serve-chat-annotations-business-20261117/README.md)累计
4启动/14请求/185.929秒、176项NVML正常、全部清理；当前控制源和
原生helper按rev188精确身份复用，未冒称候选整体GPU重跑。

PR36首轮CI缺referencing，在导入新schema测试时失败；保留原log，
开发专用依赖现固定到独立venv。全新本机venv8项前端病例通过，不
加载模型。CI补ensurepip环境，未给运行时新增Python依赖。随后确认
新提交检查并实际合main；全部master任务继续，未运行24小时长稳。
''')
p=R/'docs/STATUS.md';s=p.read_text();s=s.replace('rev188；服务包 `509c3bcb9a2c2d7428cbcb9117b109ae58a4087ad304abb0edda73ec74532a74`','rev196；服务包 `'+c['manifest_sha256']+'`',1)
s=s.replace('`daf57aaf26151a6c89905be22c8ec243a249bca4259bb5d0c28ba361887abafa`','`'+c['generation_sha256']+'`',1).replace('`0851dab3568ae05f401156270ccaafb4ffa1eb1871c684de71ae626cf4244fcf`','`'+c['engine_binary_sha256']+'`',1).replace('`2331cc4c8a750a4d89ad223e47fc0721daba61ec9780240ae418831ec327c245`','`'+c['engine_release_sha256']+'`',1)
s=s.replace('前驱rev182根 `430e7985f278ce84a25c99475a315e236fe0eb62201dd4b503a8cc2069805784`；原outer/周期完整，更早7230ac61也保留','现代保留根 `'+a['manual_root']+'`；outer/周期及新引用能力完整，前驱188/182另保留',1)
s=s.replace('`c789291b1c06ec429d58b86dab2586cea83b84422d5daf560bec04ea15c4a374`','`'+a['automatic_payload']+'`',1)
marker='[rev188运营指标交付]';intro=f'''[rev196引用交付](evidence/serve-chat-annotations-delivery-20261117/README.md)已完成18项
STOPPED发布、实际整根回退及再前进，{v['seconds']:.3f}秒，0新增GPU。
引用历史/原字符偏移进入模板，存储和双客户端往返可用；核心/client/
outer预算保持，profile仅做已验能力扩展。原记录和旧包保留。
PR36首轮CI缺schema测试依赖，已修环境并在独立venv通过8项；继续
新提交检查及实际合main，按rev196刷新用户day交接，全部master继续。

前驱'''
s=s.replace(marker,intro+marker,1)
s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro.removesuffix('前驱')+'\n',1)
p.write_text(s)
p=R/'docs/log/2026-11-17.md';s=p.read_text();h,rest=s.split('\n\n',1);p.write_text(h+f'''\n\n## rev196引用默认发行与CI环境缺口修复

- 做了什么：18项STOPPED发布/实际现代整根回退/再前进通过，
  {v['seconds']:.3f}秒、0新增GPU；原核心/client/outer预算保持，profile
  依资格只增引用能力与身份。退休发布/登记各2份可恢复归档，0删除。
- 为什么：业务通过后必须实际交付且保持回退能力；旧188不具新引用，
  不能通过删能力绕过合同。CI另发现缺referencing，固定开发venv
  依赖并在全新隔离环境通过8项，不向运行时增加依赖。
- 下一步：按新默认准备用户day交接、确认PR36新提交检查并实际合main；
  继续Chat moderation及全部master，未执行长稳。
- 证据：[交付](../evidence/serve-chat-annotations-delivery-20261117/README.md)。

'''+rest)
p=R/'docs/serve-master-goals-v2.json';d=read(p)
for t in d['tasks']:
 if 'chat_annotations_20261116' in t:
  t['chat_annotations_20261116'].update(state='delivered_main_pending',revision=196,manifest_sha256=c['manifest_sha256'],delivery_evidence='evidence/serve-chat-annotations-delivery-20261117/README.md',default_unchanged=False,actual_starts=4,actual_requests=14,actual_seconds=185.92932795360684)
 if t['id']=='A02':t['remaining_required']=['Non-null audio history and matching model/output/template round trips; citation input history delivered in rev196, actual search output remains A01/A11']
 if t['id']=='Q02':
  t['chat_annotations_delivery_20261117']=a|dict(evidence='evidence/serve-chat-annotations-delivery-20261117/README.md')
  t['remaining_required']=['PR36 exact-head checks and actual main merge','Delivery of every remaining implementation']
 if t['id']=='R07':t['current_execution_prerequisite']='Refresh exact cold qualification against rev196 or the then-current default; do not stop camera/jtop or enter device-fence without pending maintenance handoff.'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev196引用默认交付](evidence/serve-chat-annotations-delivery-20261117/README.md)：真实整根回退/再前进、预算保持和CI依赖修复。\n')
print(json.dumps(dict(revision=196,files=len(files),secret_scan_matches=0)))

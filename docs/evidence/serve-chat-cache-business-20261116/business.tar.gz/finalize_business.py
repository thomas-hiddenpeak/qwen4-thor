import json,re,sys,tarfile
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R));W=Path(__file__).resolve().parent;B=W/'business-02'
from tools.serve_service.package import read,save,sha,require
prior=read(W/'partial-review.json');plan=read(B/'plan.json');result=read(B/'result.json');guard=read(B/'lease/exit.json');cleanup=read(B/'cleanup.json');checks=read(B/'business-checks.json')
require(prior['status']=='ACCEPT_FIRST_FIVE_CAPTURED_CASES','prior five absent')
require(result['status']=='PASS_CHAT_CACHE_REMAINING_BUSINESS' and result['counts']['starts']==1 and result['counts']['chats']==3,'remaining stage failed')
require(guard['status']=='COMPLETED' and guard['child_returncode']==0,'strict lease rejected')
queries=[json.loads(l) for l in (B/'lease/nvml-queries.jsonl').read_text().splitlines()];events=[json.loads(l) for l in (B/'lease/events.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and not q['observed_errors'] for q in queries),'NVML invalid')
require(all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events),'environment conflict')
require(cleanup['model_exit']==0 and not cleanup['remaining'] and cleanup['ports_released'] and cleanup['lease_continuously_held'],'owned cleanup failed')
require(plan['binary_sha256']==prior['engine_binary_sha256']==sha(plan['binary']),'candidate differs')
for p,h in plan['sources'].items():require(sha(R/p)==h,'frozen source drift: '+p)
for p,h in plan['protected'].items():require(sha(p)==h,'default changed')
require(checks['actual_requests']==3 and checks['default_implicit_write'] and checks['exact_restore_usage'],'missing remaining checks')
summary=dict(status='ACCEPT_CHAT_CACHE_BUSINESS',binary_sha256=plan['binary_sha256'],cleanup_complete=True,total_starts=2,total_generations=8,unique_business_cases=8,first_stage=prior,second_stage=dict(result=result,checks=checks,strict_lease_seconds=events[-1]['monotonic']-events[0]['monotonic'],nvml_queries=len(queries)),default_unchanged=True,original_failure_preserved=True,aggregate_metrics_case_count=7,unobserved_final_metric_case='disabled',performance_acceptance=False,full_model_quality=False,master_complete=False)
files=[]
for p in B.rglob('*'):
 rel=p.relative_to(B)
 if not p.is_file() or rel.parts[0].startswith('objects') or p.name=='client-policy.json':continue
 files.append((p,'business-02/'+str(rel)))
for n in ['finalize_business.py','remaining_business.py','freeze-followup-01.json','partial-review.json','finalizer-initial-observation.json','finalize_business_before_status_fix.py']:files.append((W/n,n))
for stem in ['prepare-business-02','gpu-business-02']:
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token','gateway_token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in ['build/service/engine/client-policy.json','build/service/gateway-policy.json']:collect(read(R/p))
collect(read(B/'client-policy.json'))
for p,n in files:
 require(not any(x in p.read_bytes() for x in secrets),'private value in '+n)
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),'private key')
out=R/'docs/evidence/serve-chat-cache-business-20261116';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n)
summary.update(files=len(files),archive_sha256=sha(out/'business.tar.gz'),secret_scan_matches=0);save(out/'acceptance.json',summary)
(out/'README.md').write_text(f'''# Chat 标准缓存实际业务接受

2026-11-16，候选0851dab3累计2启动/8个不同生成任务。首轮5项原捕获
经修正判定复核，原始FAILED不改写；第二轮只执行剩余3项并PASS。
两次严格租约{prior['strict_lease_seconds']:.3f}/{summary['second_stage']['strict_lease_seconds']:.3f}秒，NVML
{prior['nvml_queries']}/{len(queries)}项正常；没有重复前五条或追加性能采样。

实际双断点SSD写入、12h/30m寿命、改变suffix后的SSE/MTP恢复2320
token及答案43、不同client/key不命中、显式无断点不读写、没有标准
缓存字段的默认隐式写入、目标解码严格JSON写入和SSE恢复均通过。
每个hit有实际共享状态restore及usage对应证据；未靠HTTP200宣称命中。
聚合/分客户指标独立捕获覆盖首轮4项及第二轮3项；首轮禁缓存项只有
成功HTTP/terminal/无读写日志，没有其结束后的最终指标，不称8项
完整指标矩阵。配额结算路径未改，原同身份证据继续有效。

首次工具错误是把可选零缓存details当必填，两个CPU正负控和原捕获
核对已修正；缺失实际hit证据仍拒绝。引擎及冻结运行来源未改变。
两轮正常停止并释放自有进程/端口/锁，rev166未改；私有对象、缓存与
客户端策略不进公开归档，密钥扫描0命中。没有媒体状态恢复、完整
质量、性能或长稳主张，后续资格/可回退发行和全部master继续。
''')
print(json.dumps({k:summary[k] for k in ['status','binary_sha256','total_starts','total_generations','cleanup_complete']}))

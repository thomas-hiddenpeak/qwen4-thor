import argparse,sys,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_protocol import chat_cache_acceptance as a
from tools.serve_service.package import read,save,sha,require
LIMITS=dict(starts=1,chats=3,controls=1200,seconds=600)
LABELS=('default_implicit','target_write','target_hit')
def requests():
 rows=a.requests();return {k:rows[k] for k in LABELS}
class Stage(a.Stage):
 limits=LIMITS
 request_templates=staticmethod(requests)
 success_status='PASS_CHAT_CACHE_REMAINING_BUSINESS'
def main():
 parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare','run']);parser.add_argument('--binary',type=Path);parser.add_argument('--output',type=Path);parser.add_argument('--port',type=int,default=18772);parser.add_argument('--plan',type=Path);args=parser.parse_args()
 if args.mode=='prepare':
  prior=read(Path(__file__).parent/'partial-review.json');require(prior['status']=='ACCEPT_FIRST_FIVE_CAPTURED_CASES' and prior['engine_binary_sha256']==sha(args.binary),'partial proof/engine differs')
  a.foreground.base.prepare(args,rows=requests(),limits=LIMITS,scope='Only three previously unexecuted Chat cache cases. No repeated first five; unchanged exact engine. Original harness failure retained.')
  p=args.output.resolve()/'plan.json';plan=read(p)
  for name in subprocess.check_output(['git','ls-files','tools/serve_responses'],cwd=ROOT,text=True).splitlines():plan['sources'][name]=sha(ROOT/name)
  plan['sources'][str(Path(__file__).resolve().relative_to(ROOT))]=sha(Path(__file__))
  plan.update(planned=dict(starts=1,chats=3),prior_five=prior)
  save(p,plan)
 else:
  with a.foreground.base.lifecycle.child_subreaper():Stage(read(args.plan)).run()
if __name__=='__main__':main()

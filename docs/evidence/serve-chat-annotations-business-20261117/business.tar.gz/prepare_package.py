"""Seal accepted Chat citation history engine; reuse unchanged native/control source evidence."""
import copy,hashlib,os,runpy,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'package-01'
B=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD=(ROOT/'build/service').resolve(strict=True);P=W/'profiles-01'
helpers=runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))
def copy_file(src,dst):
    dst.parent.mkdir(mode=0o700,parents=True,exist_ok=True);shutil.copyfile(src,dst)
def main():
    os.umask(0o077)
    p.require(not OUT.exists(),'preserve previous package')
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'reviewed sources need commit')
    protected={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json']}
    original=bundle.verify(OLD,p.sha(OLD/'manifest.json'));old_metadata=p.read(OLD/'engine/q4t.release.json')
    base=p.read(OLD/'engine/manifest.json');plan=p.read(P/'plan.json');qualification=p.read(P/'acceptance.json')
    actual=dict(status='ACCEPT_CHAT_ANNOTATIONS_PROFILE_BUSINESS',cleanup_complete=qualification['environment']['cleanup_complete'],binary_sha256=plan['binary_sha256'],annotations=p.read(P/'annotations-business.json'))
    p.require(qualification['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and qualification['environment']['cleanup_complete'],'qualification absent')
    p.require(actual['status']=='ACCEPT_CHAT_ANNOTATIONS_PROFILE_BUSINESS' and actual['cleanup_complete'],'display business absent')
    runtime=helpers['source_hashes']();compiled=p.read(B/'generated/q4t/server/chat_protocol_sources.json');runtime.update(compiled)
    p.require(all(p.sha(ROOT/n)==h for n,h in runtime.items()),'runtime changed')
    p.require(all(plan['sources'].get(n,compiled.get(n))==h for n,h in runtime.items()),'qualified runtime differs')
    p.require(p.sha(B/'q4t')==actual['binary_sha256']==plan['binary_sha256'],'accepted engine differs')
    previous=p.read(old_metadata['tested_source_manifest']);delta={n for n,h in runtime.items() if previous.get(n)!=h}
    expected={'include/q4t/server/chat_template.h','src/server/chat_contract.cpp','src/server/chat_template.cpp','src/server/chat_capabilities.cpp','src/service/guardian_main.cpp'}
    p.require(delta==expected,'unreviewed engine delta: '+str(delta))
    control={n for n in bundle.SOURCES if p.sha(ROOT/n)!=p.sha(OLD/'source'/n)}
    p.require(not control,'unexpected control delta')
    old_native=p.read(OLD/'native-build.json');native_delta={n for n,h in old_native['source_files'].items() if p.sha(ROOT/n)!=h}
    p.require(not native_delta,'unexpected native source delta')
    p.require(old_native['source_files']['src/service/guardian_main.cpp']==runtime['src/service/guardian_main.cpp'],'inherited Guardian source must match actually delivered native helper')
    native=copy.deepcopy(old_native);same={}
    for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),('ingress','q4t-ingress'),('device_control','q4t-device-control')]:
        p.require(p.sha(OLD/'bin'/name)==native[field+'_sha256'],'native helper bytes changed')
        same[name]=True
        # Reuse the accepted helper, not a stale unrelated build-directory copy.
    native['reuse_review']=dict(previous=str(OLD/'native-build.json'),sha256=p.sha(OLD/'native-build.json'),changed_sources=[],executable_hashes_identical=same,rationale='All native and bundled recovery/control sources and helper executables are byte-identical to rev188. Reuse their accepted native ingress, primary/light pressure recovery, device boundaries and root supervision evidence; new engine exact qualification and Chat citation history, actual project tool continuation and stored/restart original-message HTTP accepted. Exact payload version composition follows separately.')
    OUT.mkdir(mode=0o700);engine=OUT/'engine'
    for n in ['q4t','CMakeCache.txt']:copy_file(B/n,engine/n)
    (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
    protocol=hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
    caps=p.read(P/'primary-capabilities.json');config=p.read(P/'primary-config.json')
    p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,'actual declaration differs')
    decision=dict(status='PASS_CHAT_ANNOTATIONS',acceptance='ACCEPT_CHAT_ANNOTATIONS_BUSINESS',binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,source_commit=plan['source_commit'],actual_chat_annotations_business=actual,profile_qualification=qualification,source_delta=sorted(delta),control_delta=[],full_model_quality=False,performance_acceptance=False,version_composition_pending=True,default_changed=False,remaining_master_tasks_open=True,reused_control_recovery='docs/evidence/serve-media-managed-business-20261116/acceptance.json',cpu_contracts=['docs/evidence/serve-chat-annotations-cpu-20261117/README.md'])
    p.save(OUT/'decision.json',decision)
    metadata=copy.deepcopy(old_metadata)
    metadata.update(version='serve-chat-annotations-20261117',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],acceptance=decision['acceptance'],acceptance_decision=str(OUT/'decision.json'),acceptance_decision_sha256=p.sha(OUT/'decision.json'),build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),tested_source_manifest=str(engine/'runtime-source.json'),tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),previous_release=str(OLD/'engine/q4t.release.json'),inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),sha256=p.sha(OLD/'engine/q4t.release.json')),source_note='Assistant citation history is validated using original Unicode character offsets, escaped into the original turn and preserved in stored Chat. Sixteen targeted C++ and eight schema/native/client cases accepted; exact primary/light real tool and stored/restart business accepted. Native/control/helper/client bytes unchanged from rev188; Guardian source manifest catches up to the already delivered e829 helper without rebuilding it. Sealed retained-controller SSE and reversible publication still pending. Audio history and search production remain required; no full correctness/performance or complete compatibility claim')
    metadata['chat_annotations_acceptance']=decision
    declarations=engine/'declarations';declarations.mkdir(mode=0o700)
    p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
    metadata['chat_protocol'].update(caps,protocol_sha256=protocol,declaration_evidence='Actual exact Chat citation history and primary/light observations; prior independent behavior evidence retained by original identity.')
    for name,stem in helpers['SCHEMAS'].items():
        source=ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'));target=declarations/'schemas'/(name+'.json');copy_file(source,target)
        metadata['chat_protocol'][name+'_schema']=str(target);metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
    metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,directory=str(declarations),binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,files={n:p.sha(declarations/n) for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
    for src in (ROOT/'third_party/licenses').rglob('*'):
        if src.is_file():copy_file(src,engine/'licenses'/src.relative_to(ROOT/'third_party/licenses'))
    metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output');metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
    for name,record in metadata['file_input_system_dependencies'].items():
        source=Path(record['artifact']);p.require(p.sha(source)==record['sha256'],'notice changed');target=engine/'licenses/system'/name;copy_file(source,target);record['artifact']=str(target)
    clients=metadata['client_artifacts']
    client_delta={n for n,h in clients['files'].items() if p.sha(ROOT/n)!=h}
    p.require(not client_delta,'unreviewed client delta')
    for n in clients['files']:
        clients['files'][n]=p.sha(ROOT/n);copy_file(ROOT/n,OUT/'clients'/n)
    decision['client_delta']=sorted(client_delta)
    p.save(OUT/'decision.json',decision)
    metadata['acceptance_decision_sha256']=p.sha(OUT/'decision.json')
    clients['directory']=str(OUT/'clients')
    p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True);p.save(OUT/'native-build.json',native)
    kwargs={key:OLD/'engine'/n for key,n in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json')] if (OLD/'engine'/n).is_file()}
    settings=base['settings']
    receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',base['model_dir'],OLD/'bin/q4t-guardian',OLD/'bin/q4t-cuda-probe',None,OLD/'gateway-policy.json',OLD/'engine/client-policy.json',OUT/'bundle',native_receipt=OUT/'native-build.json',native_ingress=OLD/'bin/q4t-ingress',device_control=OLD/'bin/q4t-device-control',capacity_config=dict(version=2, **{k:v for k,v in settings['profile'].items() if k not in ('name','host')}),application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},embedding_model_dir=Path(settings['native_embedding']['directory']),recovery_profiles=P/'qualified/registry.json',recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
    p.save(OUT/'receipt.json',receipt)
    p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,'unrelated settings changed')
    p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
    p.save(OUT/'prepare-review.json',dict(previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),package_sha256=receipt['manifest_sha256'],runtime_source_sha256=runtime,runtime_delta=sorted(delta),control_source_delta=[],native_source_delta=[],native_executables_identical=same,new_gpu_starts=0,default_changed=False,version_composition_pending=True))
    print(receipt['manifest_sha256'])
if __name__=='__main__':main()

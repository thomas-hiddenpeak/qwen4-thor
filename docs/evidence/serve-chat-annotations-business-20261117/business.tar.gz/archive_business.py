import json,re,tarfile,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
profile=read(W/'profiles-01/acceptance.json');assert profile['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
legacy=read(W/'retained-business-01/decision.json');modern=read(W/'modern-business-01/decision.json')
for value in [legacy,modern]:assert value['actual_business']['env_abort'] is False and all(value['actual_business']['postflight'].values())
files=[]
for n in ['profiles-01','retained-business-01','modern-business-01']:
 base=W/n
 for p in base.iterdir():
  if p.is_file() and p.name!='client-policy.json':files.append((p,n+'/'+p.name))
 for dirname in ['lease','qualified']+(['execution'] if n!='profiles-01' else []):
  if not (base/dirname).exists():continue
  for p in (base/dirname).iterdir():
   if p.is_file() and p.name!='budget.lock':files.append((p,n+'/'+dirname+'/'+p.name))
for prefix in ['package-01','retained-01','modern-retained-01']:
 for name in ['receipt.json','review.json','decision.json','prepare-review.json','native-build.json']:
  p=W/prefix/name
  if p.exists():files.append((p,prefix+'/'+name))
for stem in ['prepare-profiles-01','gpu-profiles-01','finalize-profiles-01','prepare-package-01','prepare-package-02','prepare-retained-01','prepare-native-01','gpu-native-01','finalize-native-01','finalize-native-02','finalize-native-03','postflight-command-cpu-01','prepare-modern-root-01','prepare-modern-business-01','gpu-modern-01','finalize-modern-01']:
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
for name in ['archive_business.py','prepare_package.py','prepare_package_before_helper_fix.py','prepare_retained.py','prepare_modern_root.py','native-helper-reuse-review.json','native_citations.py','modern_citations.py','review_native.py','review_native_before_import_fix.py']:
 files.append((W/name,name))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for key,val in v.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(val,str) and len(val)>=24:secrets.append(val.encode())
   else:collect(val)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json',W/'profiles-01/client-policy.json']:collect(read(p))
for p,n in files:
 data=p.read_bytes();assert not any(s in data for s in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',data),n
runs=['gpu-profiles-01','gpu-native-01','gpu-modern-01'];seconds=sum(read(W/(n+'.json'))['seconds'] for n in runs);assert seconds<600
queries=[]
for n in ['profiles-01','retained-business-01','modern-business-01']:
 queries += [json.loads(l) for l in (W/n/'lease/nvml-queries.jsonl').read_text().splitlines()]
assert all(q['status']=='OK' and q['returncode']==0 for q in queries)
summary=dict(status='ACCEPT_CHAT_ANNOTATIONS_BUSINESS',engine_binary_sha256=read(W/'profiles-01/plan.json')['binary_sha256'],candidate=read(W/'package-01/receipt.json'),modern_retained=read(W/'modern-retained-01/receipt.json'),automatic_fallback=read(W/'retained-01/review.json')['fallback'],profile_qualification=profile,legacy_service_acceptance=legacy,modern_service_acceptance=modern,starts=4,generation_requests=14,chat_requests_including_selfcheck=10,native_embeddings=2,native_media=2,seconds=seconds,nvml_queries=len(queries),nvml_all_ok=True,cleanup_complete=True,original_postflight_failures_preserved=2,first_package_build_directory_helper_rejection_preserved=True,original_plan_and_guard_unchanged=True,additional_command_review_cpu=2,candidate_whole_package_gpu_run=False,candidate_control_reuse='Exact currently delivered rev188 recovery/native/helper sources and executables; new engine is qualified on primary/light. Distinct legacy and modern retained complete payloads were each started with citation SSE, storage and isolation.',default_revision=188,default_unchanged=True,full_model_quality=False,performance_claim=False,master_complete=False,secret_scan_matches=0)
out=R/'docs/evidence/serve-chat-annotations-business-20261117';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda v:v[1]):tar.add(p,arcname=n,recursive=False)
summary.update(files=len(files),archive_sha256=sha(out/'business.tar.gz'))
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text(f'''# Chat引用历史真实业务接受

2026-11-17，累计4启动/14生成请求，{seconds:.3f}秒，{len(queries)}项NVML均OK。
三个严格租约均COMPLETED，所有模型/原生服务、自有端口和锁已释放。
包括10Chat（含2自检）、2独立embedding和2既定视频资格请求。

主/轻配置各自完成带真实项目来源的schema和工具闭环；六个原始
历史均从公共存储API回读，主配置三个对象又跨模型重启回读。旧v12
控制/新引擎包和保留outer/周期迁移的现代控制/新引擎包各自真实启动，
经SSE准确返回引用标题，原引用回读保持，不同client读取返回404。

候选current控制/新引擎包没有额外整体GPU启动。其当前rev188控制、
原生入口、Guardian和设备helpers按精确source/binary身份复用；
新引擎由主轻资格和两个不同保留控制包实际业务覆盖。不冒称单一
整链复跑或新的故障恢复/压力测试。现代保留根与候选仅controller.py
不同，自动payload使用已验旧v12控制；不是独立旧引擎回退。

原3/12已完成后，发行能力保持要求发现还缺现代整根回退，明确补
1/2而未删除capability绕过合同；累计仍小于600秒。第一次封包因
隔离构建目录含旧Guardian而拒绝，改用当前已交付同source的e829副本。
后置命令比plan多-I及审计器提前导入sealed模块的两次失败保留；
2项命令正负控后对原始wire/lease复核，没有重跑业务或改原plan。

默认rev188尚未改，继续实际可回退发行/合main，音频/搜索生产者和
全部master仍必做。没有完整质量、性能或长稳主张。公开档案{len(files)}文件，
私有状态及凭据不入包，已知密钥/私钥扫描0命中。
''')
print(json.dumps({k:summary[k] for k in ['status','starts','generation_requests','seconds','nvml_queries','files']}))

"""Review the exact added -I flag without rewriting original plan/guard/evidence."""
import copy,json,runpy,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent

def command_review(planned,actual):
    isolated=[planned[0],'-I',*planned[1:]]
    require(actual==planned or actual==isolated,'unreviewed command change')
    require(planned[1]=='-B' and planned[3]=='run' and planned[4]=='--plan',
            'unexpected validation command contract')
    return dict(planned=planned,actual=actual,
        python_isolation_added=actual!=planned,program_and_arguments_identical=True)

class ReviewTests(unittest.TestCase):
    def test_only_exact_added_isolation_is_permitted(self):
        p=['/usr/bin/python3','-B','/driver.py','run','--plan','/plan.json']
        self.assertFalse(command_review(p,p)['python_isolation_added'])
        self.assertTrue(command_review(p,[p[0],'-I',*p[1:]])['python_isolation_added'])
    def test_changed_program_or_task_is_not_normalized(self):
        p=['/usr/bin/python3','-B','/driver.py','run','--plan','/plan.json']
        for q in [['/other/python',*p[1:]], [p[0],'-I',*p[2:]],
                  [*p[:-1],'/other-plan.json'], [*p,'--retry'],
                  [p[0],'-I','-I',*p[1:]], [p[0],'-E',*p[1:]]]:
            with self.assertRaises(RuntimeError):command_review(p,q)

def main():
    if sys.argv[1]=='test':
        unittest.main(argv=[sys.argv[0]])
        return
    path=W/'retained-business-01/plan.json';original=read(path)
    driver=W/'native_citations.py'
    require(original['sources'][str(driver.relative_to(ROOT))]==sha(driver),
            'original executed driver changed')
    module=runpy.run_path(str(driver));fn=module['finalize'];old=module['accepted_run']
    def reviewed(plan,result,guard,queries,events):
        correction=command_review(plan['command'],guard['command'])
        explicit=copy.deepcopy(plan);explicit['command']=guard['command']
        value=old(explicit,result,guard,queries,events)
        value['validation_command_review']=correction
        value['original_plan_sha256']=sha(path)
        value['reviewer_sha256']=sha(Path(__file__))
        save(W/'retained-business-01/command-review.json',value)
        return value
    fn.__globals__['accepted_run']=reviewed
    fn(path)

if __name__=='__main__':main()

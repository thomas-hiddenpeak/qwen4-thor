/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/pump-cpu-01/objects/15.o: \
 src/server/realtime_semantic_score.cpp \
 include/q4t/server/realtime_semantic_score.h include/q4t/io/json.h \
 include/q4t/status.h src/server/object_protocol.h \
 include/q4t/server/object_store.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/output_schema.h include/q4t/trace/sha256.h \
 include/q4t/trace/router_trace.h src/server/responses_json.h \
 include/q4t/server/realtime_semantic_turn.h \
 include/q4t/server/realtime_semantic_vad.h \
 include/q4t/server/request_control.h \
 include/q4t/server/client_identity.h \
 include/q4t/server/request_progress.h
include/q4t/server/realtime_semantic_score.h:
include/q4t/io/json.h:
include/q4t/status.h:
src/server/object_protocol.h:
include/q4t/server/object_store.h:
include/q4t/server/application_routes.h:
include/q4t/server/output_schema.h:
include/q4t/trace/sha256.h:
include/q4t/trace/router_trace.h:
src/server/responses_json.h:
include/q4t/server/realtime_semantic_turn.h:
include/q4t/server/realtime_semantic_vad.h:
include/q4t/server/request_control.h:
include/q4t/server/client_identity.h:
include/q4t/server/request_progress.h:

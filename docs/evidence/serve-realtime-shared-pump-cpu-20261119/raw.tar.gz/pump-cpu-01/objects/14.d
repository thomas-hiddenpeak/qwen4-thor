/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/pump-cpu-01/objects/14.o: \
 src/server/realtime_semantic_turn.cpp \
 include/q4t/server/realtime_semantic_turn.h \
 include/q4t/server/realtime_semantic_vad.h \
 include/q4t/server/request_control.h \
 include/q4t/server/client_identity.h \
 include/q4t/server/request_progress.h
include/q4t/server/realtime_semantic_turn.h:
include/q4t/server/realtime_semantic_vad.h:
include/q4t/server/request_control.h:
include/q4t/server/client_identity.h:
include/q4t/server/request_progress.h:

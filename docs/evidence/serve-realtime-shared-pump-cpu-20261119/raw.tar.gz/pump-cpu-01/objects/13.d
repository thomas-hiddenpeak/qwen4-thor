/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/pump-cpu-01/objects/13.o: \
 src/server/realtime_semantic_vad.cpp \
 include/q4t/server/realtime_semantic_vad.h \
 include/q4t/server/realtime_audio_queue.h include/q4t/status.h
include/q4t/server/realtime_semantic_vad.h:
include/q4t/server/realtime_audio_queue.h:
include/q4t/status.h:

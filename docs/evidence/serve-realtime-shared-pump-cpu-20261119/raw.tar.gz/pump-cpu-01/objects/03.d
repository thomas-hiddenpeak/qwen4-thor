/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-realtime-conversation-20261119/pump-cpu-01/objects/03.o: \
 src/server/realtime_transcription_pump.cpp \
 include/q4t/server/realtime_transcription_pump.h \
 include/q4t/server/realtime_session_pump.h \
 include/q4t/server/websocket.h include/q4t/status.h \
 include/q4t/server/realtime_transcription_session.h \
 include/q4t/server/asr_stream_input.h \
 include/q4t/server/asr_stream_state.h \
 include/q4t/server/realtime_audio_history.h \
 include/q4t/server/http_request.h include/q4t/server/http_connection.h \
 include/q4t/server/model_catalog.h \
 include/q4t/server/application_routes.h \
 include/q4t/server/http_observation.h \
 include/q4t/server/request_limits.h include/q4t/server/realtime_pcm.h \
 include/q4t/server/realtime_audio_queue.h \
 include/q4t/server/realtime_transcript_history.h \
 include/q4t/server/realtime_transcription_protocol.h \
 include/q4t/audio/asr_config.h include/q4t/io/json.h \
 include/q4t/server/asr_request.h include/q4t/server/asr_service.h \
 include/q4t/server/chat_plan.h include/q4t/server/access_program.h \
 include/q4t/server/chat_audio_output.h \
 include/q4t/server/speech_request.h include/q4t/server/chat_plan_error.h \
 include/q4t/server/actual_usage.h \
 include/q4t/server/output_constraints.h include/q4t/server/sampling.h \
 include/q4t/server/prediction.h include/q4t/server/prompt_cache_policy.h \
 include/q4t/server/moderation_options.h \
 include/q4t/server/client_policy.h include/q4t/server/client_identity.h \
 include/q4t/server/chat_template.h include/q4t/server/server_options.h \
 include/q4t/server/tts_service.h include/q4t/audio/tts_config.h \
 include/q4t/server/aligner_service.h \
 include/q4t/audio/aligner_postprocess.h \
 include/q4t/server/speaker_service.h \
 include/q4t/server/separator_service.h \
 include/q4t/runtime/sequence_capacity.h \
 include/q4t/server/object_store.h \
 include/q4t/server/realtime_noise_input.h \
 include/q4t/audio/noise_reduction.h include/q4t/audio/stream_resample.h \
 include/q4t/server/realtime_semantic_turn.h \
 include/q4t/server/realtime_semantic_vad.h \
 include/q4t/server/request_control.h \
 include/q4t/server/request_progress.h include/q4t/server/realtime_vad.h \
 include/q4t/audio/vad.h include/q4t/server/websocket_session.h
include/q4t/server/realtime_transcription_pump.h:
include/q4t/server/realtime_session_pump.h:
include/q4t/server/websocket.h:
include/q4t/status.h:
include/q4t/server/realtime_transcription_session.h:
include/q4t/server/asr_stream_input.h:
include/q4t/server/asr_stream_state.h:
include/q4t/server/realtime_audio_history.h:
include/q4t/server/http_request.h:
include/q4t/server/http_connection.h:
include/q4t/server/model_catalog.h:
include/q4t/server/application_routes.h:
include/q4t/server/http_observation.h:
include/q4t/server/request_limits.h:
include/q4t/server/realtime_pcm.h:
include/q4t/server/realtime_audio_queue.h:
include/q4t/server/realtime_transcript_history.h:
include/q4t/server/realtime_transcription_protocol.h:
include/q4t/audio/asr_config.h:
include/q4t/io/json.h:
include/q4t/server/asr_request.h:
include/q4t/server/asr_service.h:
include/q4t/server/chat_plan.h:
include/q4t/server/access_program.h:
include/q4t/server/chat_audio_output.h:
include/q4t/server/speech_request.h:
include/q4t/server/chat_plan_error.h:
include/q4t/server/actual_usage.h:
include/q4t/server/output_constraints.h:
include/q4t/server/sampling.h:
include/q4t/server/prediction.h:
include/q4t/server/prompt_cache_policy.h:
include/q4t/server/moderation_options.h:
include/q4t/server/client_policy.h:
include/q4t/server/client_identity.h:
include/q4t/server/chat_template.h:
include/q4t/server/server_options.h:
include/q4t/server/tts_service.h:
include/q4t/audio/tts_config.h:
include/q4t/server/aligner_service.h:
include/q4t/audio/aligner_postprocess.h:
include/q4t/server/speaker_service.h:
include/q4t/server/separator_service.h:
include/q4t/runtime/sequence_capacity.h:
include/q4t/server/object_store.h:
include/q4t/server/realtime_noise_input.h:
include/q4t/audio/noise_reduction.h:
include/q4t/audio/stream_resample.h:
include/q4t/server/realtime_semantic_turn.h:
include/q4t/server/realtime_semantic_vad.h:
include/q4t/server/request_control.h:
include/q4t/server/request_progress.h:
include/q4t/server/realtime_vad.h:
include/q4t/audio/vad.h:
include/q4t/server/websocket_session.h:

from pathlib import Path
import hashlib,json,re,shutil,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=W/'pump-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(name,cmd,timeout=120):
 start=time.monotonic()
 with (O/(name+'.log')).open('w') as f:
  try:code=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 row=dict(command=cmd,exit_code=code,seconds=time.monotonic()-start)
 save(O/(name+'-result.json'),row);print(name,code,round(row['seconds'],3),flush=True)
 if code:
  print((O/(name+'.log')).read_text()[-6000:],flush=True);raise SystemExit(code)
 return row
sources=['tests/server_realtime_pump_test.cpp','tests/server_realtime_conversation_pump_test.cpp',
 'src/server/realtime_session_pump.cpp','src/server/realtime_transcription_pump.cpp','src/server/realtime_conversation_pump.cpp']
sources += ['src/server/'+n+'.cpp' for n in ['realtime_transcription_session','realtime_transcription_protocol',
 'realtime_semantic_session','realtime_audio_queue','realtime_pcm','realtime_audio_history','realtime_transcript_history',
 'realtime_vad','realtime_semantic_vad','realtime_semantic_turn','realtime_semantic_score','realtime_asr_policy',
 'realtime_audio_export','realtime_noise_input','asr_stream_input','asr_request','asr_response']]
sources += ['src/audio/'+n+'.cpp' for n in ['stream_resample','noise_reduction','noise_fft','asr_config']]
names=[]
for n in sources[:2]:names+=re.findall(r'Q4T_TEST\(\s*(\w+)\s*\)',(R/n).read_text())
assert len(names)==8 and len(set(names))==8
prior=json.loads((W/'session-cpu-02/freeze.json').read_text());reused=prior['reused'][:]
for i,n in enumerate(['src/server/realtime_conversation_session.cpp','src/server/realtime_conversation.cpp',
 'src/server/realtime_response_output.cpp','src/server/websocket.cpp','src/server/websocket_session.cpp','src/server/realtime_wire_shape.cpp'],3):
 p=W/'session-cpu-02/objects'/f'{i:02d}.o'
 assert sha(R/n)==prior['sources'][n]
 reused.append(dict(source=n,source_sha256=sha(R/n),object=str(p),sha256=sha(p)))
for row in reused:
 assert sha(R/row['source'])==row['source_sha256'] and sha(Path(row['object']))==row['sha256']
freeze=dict(tests=names,maximum_test_seconds=60,gpu_actions=0,
 scope='Shared queue extraction: four unchanged actual transcription pump contracts plus four conversation pump contracts. Fixture model callbacks only, no model/HTTP acceptance.',
 sources={n:sha(R/n) for n in sources},reused=reused)
save(O/'freeze.json',freeze)
for n in [*sources,'include/q4t/server/realtime_session_pump.h','include/q4t/server/realtime_transcription_pump.h','include/q4t/server/realtime_conversation_pump.h']:
 p=O/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
main=O/'main.cpp';main.write_text('#include "q4t/test.h"\nint main() { return q4t::test::RunAllTests(); }\n')
objects=[r['object'] for r in reused];rows=[];(O/'objects').mkdir()
for i,n in enumerate([*sources,str(main)]):
 obj=O/'objects'/f'{i:02d}.o';objects.append(str(obj))
 rows.append(run(f'build-{i:02d}',['g++-14','-std=c++23','-O1','-Wall','-Wextra','-Werror',
  '-ffunction-sections','-fdata-sections','-MMD','-MP','-Iinclude','-I'+str(W/'cpu-02/generated'),'-c',n,'-o',str(obj)]))
binary=O/'contracts';rows.append(run('link',['g++-14',*objects,'-Wl,--gc-sections','-pthread','-ldl','-o',str(binary)],60))
assert not any('warning:' in p.read_text() for p in O.glob('build-*.log'))
save(O/'build-result.json',dict(seconds=sum(r['seconds'] for r in rows),warnings=0,binary_sha256=sha(binary)))
row=run('contracts',[str(binary)],60)
log=(O/'contracts.log').read_text();assert log.count('[PASS] ')==8 and '[FAIL]' not in log and '[SKIP]' not in log
assert all(sha(R/n)==h for n,h in freeze['sources'].items())
save(O/'result.json',dict(status='PASS_SHARED_REALTIME_PUMP_CPU',tests=8,gpu_actions=0,
 seconds=row['seconds'],actual_business_accepted=False,default_unchanged=True))

cmake_minimum_required(VERSION 3.25)
project(q4t_recovery_wait LANGUAGES CXX)
set(Q4T_BUILD_TESTS OFF)
include("/home/rm01/models/dev/qwen4-thor/cmake/GuardianProcess.cmake")

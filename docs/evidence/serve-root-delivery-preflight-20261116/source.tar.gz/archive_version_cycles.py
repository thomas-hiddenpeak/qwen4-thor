"""Two explicit retired registrations; preserve default and every policy byte."""
import json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import version_archive as archive
from tools.serve_recovery import version_registration as registration
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;STATE=ROOT/'build/service-native-state'
def policies():
 return {str(f.relative_to(STATE)):p.sha(f) for f in STATE.rglob('*.json')
  if registration.DIRECTORY not in f.relative_to(STATE).parts and 'runs' not in f.relative_to(STATE).parts}
before=policies()
with archive.locked(STATE) as (state,desc,manifest,current,selected,binding):
 p.require(current['revision']==174 and current['current']['manifest_sha256']=='78d6bd7b89be7e1325c6c5f76d12bc2458291e79a386b5343f4274e55164fa0d','unexpected default')
 records=archive.entries(state,binding,selected)
 p.require(len(records)==15,'unexpected registration count')
 keep=archive.protected(state,desc,current,selected,records)
 candidates=sorted(records,key=lambda cycle:records[cycle][1]['candidate']['revision'])
 chosen=[]
 for cycle in candidates:
  if cycle in keep:continue
  try:archive.unreferenced(state,current,records[cycle][0])
  except ValueError:continue
  chosen.append(cycle)
  if len(chosen)==2:break
 p.require(len(chosen)==2,'two retired registration slots unavailable')
plan=archive.prepare(STATE,W/'version-archive-01',chosen)
p.save(W/'version-archive-prepared.json',plan)
result=archive.apply(plan['plan'],plan['sha256'])
p.save(W/'version-archive-applied.json',result)
p.require(policies()==before,'protected policy bytes changed')
p.require(len(registration.intents(STATE))==13,'active registration count differs')
p.save(W/'version-archive-review.json',dict(status='ACCEPT_RETIRED_VERSION_ARCHIVE',cycles=chosen,protected_policies=before,all_policies_unchanged=True,default_revision=174,active_before=15,active_after=13,deleted_files=0,new_gpu_starts=0,restore_plan=plan))
print(json.dumps(dict(status='ACCEPT_RETIRED_VERSION_ARCHIVE',cycles=chosen,active_before=15,active_after=13,deleted_files=0,new_gpu_starts=0)))

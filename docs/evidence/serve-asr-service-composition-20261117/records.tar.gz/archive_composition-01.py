"""Archive real ASR TLS, retained-control and whole-payload qualification."""
import hashlib
import json
from pathlib import Path
import tarfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R/'docs/evidence/serve-asr-service-composition-20261117'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not O.exists() and not (W/'publication-composition.json').exists()
tls = read(W/'tls-composition.json')
assert tls['status'] == 'ACCEPT_NATIVE_ASR_TLS_COMPOSED'
profile = read(W/'profiles-01/acceptance.json')
assert profile['status'] == 'ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
candidate = {k: read(W/'package-01/receipt.json')[k] for k in ('package', 'manifest_sha256')}
legacy = read(W/'retained-01/review.json')['fallback']
modern = read(W/'modern-retained-01/receipt.json')
binary = sha(Path(candidate['package'])/'engine/q4t')
assert binary == 'b02d7f25891fb8d43e2d4eefbe6aaef95721ec2332b45ebdab0b46f55a75cec7'
stages = []; files = {}
for name, descriptor, kind in [('legacy-business-01', legacy, 'RETAINED'),
                               ('modern-business-01', modern, 'RETAINED'),
                               ('version-business-01', candidate, 'VERSION')]:
    directory = W/name; execution = directory/'execution'
    decision = read(directory/'decision.json')
    assert decision['acceptance'] == 'ACCEPT_NATIVE_ASR_SERVICE_'+kind
    assert decision['manifest_sha256'] == descriptor['manifest_sha256']
    assert decision['engine_binary_sha256'] == binary
    assert all(decision['actual_business']['postflight'].values())
    result = read(execution/'result.json')
    guard = read(directory/'lease/exit.json')
    assert result['status'] == 'PASS_BOUNDED_FEATURE_SERVICE'
    assert result['failure'] is None and result['cleanup_failure'] is None
    assert guard['status'] == 'COMPLETED' and guard['child_returncode'] == 0
    assert guard['compute_backend'] == 'nvml' and guard['lease_inherited_by_child']
    assert not guard['external_lease']
    assert decision['actual_business']['plan_sha256'] == sha(directory/'plan.json')
    assert decision['actual_business']['result_sha256'] == sha(execution/'result.json')
    assert decision['actual_business']['lease_result_sha256'] == sha(directory/'lease/exit.json')
    queries = [json.loads(x) for x in (directory/'lease/nvml-queries.jsonl').read_text().splitlines()]
    assert queries and all(x['status'] == 'OK' and x['returncode'] == 0 for x in queries)
    stages.append(dict(name=name, counts=result['budget']['counts'], seconds=result['seconds'],
        strict_lease_seconds=decision['actual_business']['strict_lease_seconds'], nvml_queries=len(queries)))
    for folder, prefix in [(directory, name), (directory/'lease', name+'/lease'),
                           (execution, name+'/execution')]:
        for path in folder.iterdir():
            if path.is_file() and not path.is_symlink() and path.suffix in ('.json', '.jsonl', '.wire', '.log'):
                files[prefix+'/'+path.name] = path
    files[name+'/execution/state/ledger.json'] = execution/'state/ledger.json'
for n in ['tls-composition.json', 'prepare_package.py', 'prepare_tls.py', 'prepare_retained.py',
          'prepare_modern_root.py', 'run_service_stage.py', 'archive_composition.py',
          'package-01/prepare-review.json', 'package-01/native-build.json', 'package-01/receipt.json',
          'package-01/decision.json', 'retained-01/review.json', 'modern-retained-01/review.json',
          'modern-retained-01/receipt.json']:
    files[n] = W/n
secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'gateway_token', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
for descriptor in [candidate, legacy, modern, tls['package']]:
    for n in ['gateway-policy.json', 'engine/client-policy.json']:
        collect(read(Path(descriptor['package'])/n))
for name, path in files.items():
    raw = path.read_bytes()
    assert not any(secret in raw for secret in secrets), name
    assert b'BEGIN PRIVATE KEY' not in raw, name
starts = sum(stage['counts']['starts'] for stage in stages)+tls['counts']['starts']
requests = sum(stage['counts']['chats'] for stage in stages)+tls['counts']['chats']
probes = sum(stage['counts']['probes'] for stage in stages)
seconds = sum(stage['seconds'] for stage in stages)+tls['seconds']
queries = sum(stage['nvml_queries'] for stage in stages)+sum(x['nvml_queries'] for x in tls['environments'].values())
assert starts == 6 and requests == 20 and probes == 1 and seconds < 2400
O.mkdir()
with tarfile.open(O/'records.tar.gz', 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
accepted = dict(status='ACCEPT_NATIVE_ASR_SERVICE_COMPOSITION', binary_sha256=binary,
    candidate=candidate, automatic_fallback=legacy, modern_retained_root=modern,
    stages=stages, service_starts=starts, service_requests=requests, service_probes=probes,
    service_seconds=seconds, nvml_queries=queries, nvml_all_ok=True, cleanup_complete=True,
    primary_light_evidence='docs/evidence/serve-asr-profiles-20261117/README.md',
    direct_http_evidence='docs/evidence/serve-asr-http-20261117/README.md',
    tls_composition=tls, candidate_service_acceptance=read(W/'version-business-01/decision.json'),
    modern_service_acceptance=read(W/'modern-business-01/decision.json'),
    candidate_control_delta=read(W/'package-01/prepare-review.json')['control_source_delta'],
    candidate_whole_package_gpu_run=True, default_unchanged=True, publication_pending=True,
    original_failed_tls_drivers_preserved=True, older_engine_fallback=False,
    full_model_quality=False, performance_claim=False, all_master_tasks_complete=False,
    archive_sha256=sha(O/'records.tar.gz'), secret_scan_matches=0)
(W/'publication-composition.json').write_text(json.dumps(accepted, indent=2)+'\n')
(O/'acceptance.json').write_text(json.dumps(accepted, indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生ASR接入与恢复组合接受

固定engine-04的两种保留控制及整payload回退均实际通过。故障后
控制器/模型/原生入口全部替换，ASR、Chat、原存储记录与profile
预算保持。两种保留控制最终私有健康为ready，compute_failures=0，
ASR不成为核心readiness依赖。各自严格租约、进程/端口清理通过。

TLS双SDK中英文、独立文件配额、chunked、断流取消和后续Chat
按两个原FAILED记录分项接受；原驱动失败不改写，未观察到的
TLS最终私有健康不冒称通过，采用同引擎现代保留控制的独立证据。
首轮入口SIGKILL恢复保持核心PID。此前的传输、scope及指标/运维
读取驱动失败单独保留。

本组含失败TLS累计{starts}启动/{requests}创建（含自检）/{probes}真实CUDA探测，
{seconds:.3f}秒、{queries}次NVML正常。主轻2启动12创建及直接HTTP证据独立
保留；不作完整模型正确性、性能或长稳结论。默认rev266保持，
下一步有界可回退发布、实际合main。对齐/字幕/说话人/VAD、Chat
音频及语音/图像/视频生成和全部master仍是必须完成的任务。
''')
print(json.dumps({k: accepted[k] for k in ['status', 'service_starts', 'service_requests', 'service_probes', 'service_seconds', 'nvml_queries']}))

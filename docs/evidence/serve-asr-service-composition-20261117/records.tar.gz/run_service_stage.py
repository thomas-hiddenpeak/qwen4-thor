import json
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
out = (work/sys.argv[1]).resolve(strict=True)
assert out.parent == work
plan = json.loads((out/'plan.json').read_text())
command = [sys.executable, '-B', 'tools/evalscope/gpu_exclusive.py',
           '--compute-backend', 'nvml', '--inherit-lease',
           '--output', str(out/'lease'), '--', *plan['command']]
with (out/'console.log').open('x') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
print(json.dumps(dict(returncode=result.returncode, output=str(out))))
raise SystemExit(result.returncode)

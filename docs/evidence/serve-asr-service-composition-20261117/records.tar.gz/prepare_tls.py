"""Private native TLS acceptance package with explicit independent file quotas."""
import copy,os,secrets,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;SOURCE=W/'package-01/bundle';OUT=W/'tls-package-01'
def main():
 os.umask(0o077);p.require(not OUT.exists(),'preserve previous TLS fixture');OUT.mkdir(mode=0o700)
 original=bundle.verify(SOURCE,p.sha(SOURCE/'manifest.json'));base=p.read(SOURCE/'engine/manifest.json');settings=base['settings']
 before={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
 policy=p.read(SOURCE/'gateway-policy.json');policy.update(listen_port=19141,upstream_port=19142,upstream_operations_port=19143)
 for c in policy['clients']:c['api_key']=secrets.token_urlsafe(32)
 backend=p.read(SOURCE/'engine/client-policy.json');backend.update(version=4,revision=0,gateway_token=secrets.token_hex(32))
 for c in backend['clients']:c['max_file_body_bytes']=32*1024**2 if c['id']=='alpha' else 65536
 p.save(OUT/'policy.json',policy);p.save(OUT/'clients.json',backend)
 credential=OUT/'credentials';credential.mkdir(mode=0o700);cert=credential/'certificate.pem';key=credential/'key.pem'
 cmd=['/usr/bin/openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','2','-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-keyout',str(key),'-out',str(cert)]
 completed=subprocess.run(cmd,capture_output=True,timeout=15);p.require(completed.returncode==0,'test certificate preparation failed');key.chmod(0o600)
 kwargs={k:SOURCE/'engine'/n for k,n in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json'),('web_policy','web-policy.json')] if (SOURCE/'engine'/n).is_file()}
 receipt=bundle.prepare(SOURCE/'engine/q4t',SOURCE/'engine/q4t.release.json',base['model_dir'],SOURCE/'bin/q4t-guardian',SOURCE/'bin/q4t-cuda-probe',None,OUT/'policy.json',OUT/'clients.json',OUT/'bundle',native_receipt=SOURCE/'native-build.json',native_ingress=SOURCE/'bin/q4t-ingress',device_control=SOURCE/'bin/q4t-device-control',certificate=cert,key=key,capacity_config=dict(version=2,**{k:v for k,v in settings['profile'].items() if k not in ('name','host')}),application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},embedding_model_dir=Path(settings['native_embedding']['directory']),asr_model_dir=Path(settings['native_asr']['directory']),asr_limits=settings['native_asr']['limits'],recovery_profiles=W/'profiles-01/qualified/registry.json',recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
 p.save(OUT/'receipt.json',receipt);p.require(all(p.sha(ROOT/n)==h for n,h in before.items()),'default changed')
 p.save(OUT/'review.json',dict(status='TLS_PRIVATE_FIXTURE_PENDING',candidate=str(SOURCE),candidate_manifest=p.sha(SOURCE/'manifest.json'),source_engine_identical=True,explicit_differences=['private TLS certificate/key','three private listen ports','independent random fixture API keys','v4 file upload quota alpha32MiB beta64KiB; other quotas unchanged'],default_unchanged=True,gpu_actions=0))
 print(receipt['manifest_sha256'])
if __name__=='__main__':main()

"""Retain old control semantics with explicit ASR evidence/binding adapters."""
import copy,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle,cold_compat,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'retained-01'
OLD=ROOT/'.q4t-work/serve-refusal-20261112/selfcheck-repair-01/fallback'
OLD_SHA='c93e9714786643a76a933039bff0843df1d40030f2669085f6041af8db0e1ae7'
PRIMARY=W/'package-01/bundle';PRIMARY_SHA=p.read(W/'package-01/receipt.json')['manifest_sha256']
ADAPTERS=['tools/serve_ops/contracts.py','tools/serve_service/package.py','tools/serve_service/supervisor.py','tools/serve_service/capacity.py','tools/serve_recovery/profile_contract.py','tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_bundle.py']
def main():
 os.umask(0o077);before={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
 old=bundle.verify(OLD,OLD_SHA);current=bundle.verify(PRIMARY,PRIMARY_SHA)
 p.require(not OUT.exists(),'preserve old preparation');p.require(old['recovery_profile_policy']==current['recovery_profile_policy'],'policy changed')
 OUT.mkdir(mode=0o700);target=OUT/'bundle'
 shutil.copytree(OLD,target,symlinks=True,ignore=lambda directory,_:{'engine'} if Path(directory)==OLD else set())
 shutil.copytree(PRIMARY/'engine',target/'engine',symlinks=True)
 changed=copy.deepcopy(old);changed['engine_manifest_sha256']=current['engine_manifest_sha256'];changed['recovery_profiles']=current['recovery_profiles']
 names=['profile-primary.json','profile-light.json','native-build.json','bin/q4t-guardian','bin/q4t-cuda-probe','bin/q4t-ingress',*('source/'+n for n in ADAPTERS)]
 for name in names:
  path=target/name;p.require(name in changed['files'],'unexpected legacy module')
  path.chmod(0o600);shutil.copyfile(PRIMARY/name,path);path.chmod(0o500 if name.startswith('bin/') else 0o400);changed['files'][name]=p.sha(path)
 # This old coordinator intentionally uses its original memory/cold policy.
 # Only extend its identity binding; do not import current resource modules.
 name='source/tools/serve_recovery/profile_controller.py';path=target/name
 text=path.read_text();original="controller.manifest['model_assets'], base['settings'].get('native_embedding'))"
 p.require(text.count(original)==1,'legacy ASR adapter context changed')
 path.chmod(0o600);path.write_text(text.replace(original,"controller.manifest['model_assets'], base['settings'].get('native_embedding'),\n            base['settings'].get('native_asr'))",1));path.chmod(0o400)
 changed['files'][name]=p.sha(path);names.append(name)
 p.save(target/'manifest.json',changed);digest=p.sha(target/'manifest.json')
 launch=target/'bin/q4t';launch.chmod(0o700);launch.write_bytes(bundle.launcher(digest,changed['python']['path']));launch.chmod(0o500)
 p.require(bundle.verify(target,digest)==changed,'payload verification failed')
 difference={n for n,h in old['files'].items() if changed['files'][n]!=h}
 p.require(difference<=set(names),'unreviewed legacy changes');p.require(cold_compat.aware(target),'cold custody awareness missing')
 control='source/tools/serve_recovery/controller.py';p.require(changed['files'][control]==old['files'][control]!=current['files'][control],'distinct old controller required')
 root=dict(package=str(PRIMARY),manifest_sha256=PRIMARY_SHA);fallback=dict(package=str(target),manifest_sha256=digest)
 permit=version_contract.compatible(version_contract.payload(root),version_contract.payload(fallback));p.require(permit['automatic'],'compatibility absent')
 p.require(all(p.sha(ROOT/n)==h for n,h in before.items()),'default changed');bundle.verify(OLD,OLD_SHA)
 p.save(OUT/'review.json',dict(status='NEW_PAYLOAD_ACTUAL_ACCEPTANCE_PENDING',original=dict(package=str(OLD),manifest_sha256=OLD_SHA),primary=root,fallback=fallback,changed_files=sorted(difference),asr_adapters=ADAPTERS,coordinator_change='Only pass optional ASR binding to expected identity; original memory policy unchanged',compatibility=permit,original_acceptance_not_relabelled=True,default_unchanged=True,driver_sha256=p.sha(Path(__file__))))
 p.save(OUT/'receipt.json',fallback);print(digest)
if __name__=='__main__':main()

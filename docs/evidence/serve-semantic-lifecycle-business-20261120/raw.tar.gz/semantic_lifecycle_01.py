"""One main model; cold and warm semantic lifecycle plus missing conversation closure.
Four external requests, three WSS, two entries, 600 seconds; no retries.
Observation only. Original strict qualification and model-quality failures remain.
"""
import copy,hashlib,importlib.util,json,os,signal,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_realtime import semantic_observation
from tools.serve_realtime.ingress_fixture import NativeIngress
from tools.serve_recovery import profile_semantic,profile_realtime
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent;OUT=W/'semantic-lifecycle-01';PRIOR=W/'consumers-01'
spec=importlib.util.spec_from_file_location('missing_consumers',W/'observe_remaining_01.py');missing=importlib.util.module_from_spec(spec);spec.loader.exec_module(missing)
audited=missing.audited;encrypted=missing.encrypted
LIMITS=dict(starts=1,chats=4,controls=2000,seconds=600,websocket_sessions=3,ingress_starts=2,prompt_registry_requests=0)

def check(plan):
 require(plan['limits']==LIMITS and plan['observation_only'] is True and plan['qualification'] is False and plan['automatic_retries'] is False and plan['observation_policy']==semantic_observation.POLICY,'fixed lifecycle observation scope')
 require(read(PRIOR/'result.json')['status']=='OBSERVATIONS_COMPLETE_NOT_QUALIFICATION' and sha(PRIOR/'review.json')==plan['previous_review_sha256'],'original cold fallback review missing')
 require(read(W/'semantic-cpu-01/result.json')['status']=='PASS','CPU prerequisite missing')
 probe=copy.deepcopy(plan);probe['limits']=audited.LIMITS;probe['planned']={k:v for k,v in audited.LIMITS.items() if k not in ('seconds','controls')};audited.check_plan(probe)

class Stage(missing.Stage):
 limits=LIMITS
 success_status='OBSERVATIONS_COMPLETE_NOT_QUALIFICATION'
 def __init__(self,plan):
  check(plan);encrypted.Stage.__init__(self,plan);self.counts.update(websocket_sessions=0,ingress_starts=0,prompt_registry_requests=0)
 def semantic(self):
  fixed=self.plan['realtime'];client=encrypted.CLIENT;policy=read(self.out/'client-policy.json');key=hashlib.sha256(os.urandom(32)).hexdigest()
  def state(label):
   status,raw=self.http('/metrics',label=label);require(status==200,'semantic metrics absent');return profile_realtime.state(encrypted.foreground.base.lifecycle.parse_metrics(raw),client)
  self.budget('ingress_starts');edge=NativeIngress(self.out/'semantic-entry',fixed['ingress'],fixed['public_port'],self.plan['port'],self.plan['operations_port'],policy['gateway_token'],{client:key},fixed['tls'],lambda:self.model.poll() is None)
  self.history[edge.process.pid]=encrypted.foreground.base.lifecycle.guard.processes()[edge.process.pid]
  result=[]
  try:
   for label,split in [('cold-complete',0),('warm-continuation',36000)]:
    before=state(label+'-before');health_before=profile_semantic.health(self,label+'-health-before')
    self.budget('websocket_sessions');self.budget('chats')
    args=dict(base_url=f"https://127.0.0.1:{fixed['public_port']}/v1",api_key=key,ca_file=fixed['tls']['certificate'],file=fixed['clip']['path'],split_samples=split,settings=missing.evidence.semantic_settings(),observation_policy=semantic_observation.POLICY)
    env={k:v for k,v in os.environ.items() if k not in ('NODE_OPTIONS','NODE_PATH','LD_PRELOAD')};env['Q4T_NODE_SDK_DIR']=self.plan['sdk']['sdk_directory']
    run=subprocess.run([self.plan['sdk']['node']['path'],str(ROOT/'tools/serve_realtime/semantic_sdk.mjs')],input=json.dumps(args),text=True,capture_output=True,env=env,timeout=135)
    (self.out/(label+'.sdk.json')).write_text(run.stdout);(self.out/(label+'.stderr')).write_text(run.stderr)
    require(run.returncode==0 and len(run.stdout.encode())<=4<<20,'observed semantic SDK failed: '+label)
    raw=json.loads(run.stdout);observed=semantic_observation.observe(raw,bool(split));self.same_model();self.drained(label+'-drain')
    deadline=time.monotonic()+5;after=state(label+'-after-0');i=0
    while (after['sessions'] or after['host_bytes']) and time.monotonic()<deadline:
     time.sleep(.02);i+=1;after=state(label+'-after-'+str(i))
    require(all(after[k]==0 and before[k]==0 for k in ('reserved','active','sessions','host_bytes')) and after['free_slots']==before['free_slots']==1 and after['admitted']-before['admitted']==1 and after['settled']-before['settled']==observed['total_tokens'],'semantic actual settlement differs')
    status,_=self.http('/readyz');require(status==200,'semantic changed healthy core readiness')
    row=dict(label=label,before=before,after=after,observed=observed,sdk_sha256=sha(self.out/(label+'.sdk.json')),health_before=profile_semantic.configuration(health_before),health_after=profile_semantic.configuration(profile_semantic.health(self,label+'-health-after')))
    save(self.out/(label+'-receipt.json'),row);result.append(row)
    require(label!='warm-continuation' or observed['kind']=='scored_early_end','warm classifier did not complete; do not retry')
   save(self.out/'semantic-observations.json',result)
  finally:
   edge.close();save(self.out/'semantic-entry-cleanup.json',dict(exit_code=edge.process.returncode,pid=edge.process.pid,port_released=True))
 def business(self):
  require(self.profile_name=='primary','only missing main lifecycle requested')
  self.semantic()
  conversation=self.conversation();save(self.out/'conversation-observation.json',conversation)
  save(self.out/'business-observation.json',dict(semantic=read(self.out/'semantic-observations.json'),conversation=dict(quality=conversation['quality'],before=conversation['before'],after=conversation['after']),strict_profile_qualified=False))

def prepare():
 OUT.mkdir(mode=0o700);plan=copy.deepcopy(read(PRIOR/'plan.json'))
 plan.update(output=str(OUT),limits=LIMITS,planned={k:v for k,v in LIMITS.items() if k not in ('seconds','controls')},scope=__doc__,observation_policy=semantic_observation.POLICY,previous_review_sha256=sha(PRIOR/'review.json'),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
 for section in ('conversation','prompt','realtime'):
  plan[section]['files']={n:sha(Path(n)) for n in plan[section]['files']}
 record=ROOT/'docs/STATUS.md';plan['conversation']['source']['sha256']=sha(record)
 plan['sources']={n:sha(ROOT/n) for n in plan['sources']}
 for path in (Path(__file__),ROOT/'tools/serve_realtime/semantic_observation.py',ROOT/'tools/serve_realtime/semantic_sdk.mjs',W/'semantic-cpu-01/plan.json',W/'semantic-cpu-01/result.json',PRIOR/'review.json'):
  plan['sources'][str(path)]=sha(path)
 check(plan);save(OUT/'plan.json',plan);print(json.dumps(dict(status='PREPARED_OBSERVATIONS_ONLY',limits=LIMITS)))

if __name__=='__main__':
 if sys.argv[1:]==['prepare']:prepare()
 else:
  require(sys.argv[1:]==['run'],'explicit frozen run required')
  def stopped(_s,_f):raise TimeoutError('semantic lifecycle deadline/interruption')
  signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGALRM,stopped);signal.alarm(600)
  try:
   with encrypted.foreground.base.lifecycle.child_subreaper():Stage(read(OUT/'plan.json')).run()
  finally:signal.alarm(0)

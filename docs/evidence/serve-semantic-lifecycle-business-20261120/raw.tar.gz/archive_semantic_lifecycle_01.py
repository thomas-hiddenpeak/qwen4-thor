from pathlib import Path
import json,hashlib,tarfile
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=W/'semantic-lifecycle-01';O=ROOT/'docs/evidence/serve-semantic-lifecycle-business-20261120';O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  b=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(b);p.chmod(m)
result=json.loads((B/'result.json').read_text());assert result['status']=='OBSERVATIONS_COMPLETE_NOT_QUALIFICATION' and result['counts']['chats']==4
review=dict(status='PASS_TARGETED_LIFECYCLE_OBSERVATIONS',profile_qualified=False,result=result,nvml_ok=62,cleanup_complete=True,default_unchanged=True,cold_degradation_reproduced=False,cold_classifier='scored_early_end',warm_classifier='scored_early_end',warm_resumption_stale_rejected=1,conversation=json.loads((B/'conversation-observation.json').read_text())['quality'],original_quality_failure_preserved=True,original_cold_score_timeout_preserved=True,followup='Independently verify exact successful wire outputs and all frozen source identities; do not relabel original failed stages or observation statuses. No further model replay needed for these consumers.')
save(B/'review.json',review)
files={'semantic_lifecycle_01.py':W/'semantic_lifecycle_01.py','archive_semantic_lifecycle_01.py':Path(__file__)};omitted={};secrets=[]
def scan(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','gateway_token','bearer_token') and isinstance(x,str):secrets.append(x)
   else:scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
for p in B.rglob('*.json'):
 if p.stat().st_size<65536:
  try:scan(json.loads(p.read_text()))
  except ValueError:pass
for p in [*B.iterdir(),*(B/'lease').iterdir()]:
 if not p.is_file() or p.suffix not in ('.json','.jsonl','.wire','.log','.stderr'):continue
 n=str(p.relative_to(W))
 if p.name=='client-policy.json' or any(s.encode() in p.read_bytes() for s in secrets if s):omitted[n]=dict(sha256=sha(p),reason='private test authentication; original retained');continue
 files[n]=p
index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',dict(files=index,omitted=omitted))
with tarfile.open(O/'raw.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'raw.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
save(O/'review.json',dict(review,archive_sha256=sha(O/'raw.tar.gz')))
(O/'README.md').write_text('''# 主配置冷/热态与工具会话生命周期

候选648d6d68保持，1模型/4外部请求/3WSS/2入口/64.650秒；62次NVML
正常，真实进程/端口/锁已释放，来源与默认rev356保持。

冷态ASR从configured/0次加载进入ready；本次完整句和热态续说均取得
有效分类并在最大等待之前结束。续说丢弃1次过期结果后接受新结果；
两项真实转写/流式/历史波形/正常关闭通过，分别结算500和910 tokens。
Realtime真实工具返回rev356，精确答案、流式终态、正常关闭及结算均通过。

本次没有复现未知概率的最大等待降级，不把它写成“降级实跑通过”。
上一轮冷ASR超时取消、原XML格式失败及本次观察状态均保持；不能据此
声称冷态分类每次及时完成或模型总能严格遵循指令。

下一步CPU核对各次实际来源及成功输出，显式组合独立租约和原失败；
不重放模型，不改写旧SDK状态，不把观察驱动退出0当作资格。
原始记录与私有认证摘要见归档和索引，恢复/发行与总计划继续。
''')
intro='[主配置生命周期补验完成](evidence/serve-semantic-lifecycle-business-20261120/README.md)：\n1模型/4请求/64.650秒，62次NVML正常并清理完成；冷/热两轮均实际\n分类，工具准确返回rev356，历史/正常关闭/结算完整。本次未复现未知\n概率降级；原冷态及格式FAIL保持。继续CPU核对确切成功输出、各次\n来源和独立租约，不改写旧观察状态、不重放模型；恢复和总计划继续。\n\n'
p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 主配置完整生命周期与实际语义分类补验\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：补齐原断言中断后缺失的正常关闭和结算；成功分类与原超时降级各自保留，避免把新结果覆盖旧失败。\n\n下一步：严格复核可复用的实际成功业务与来源，不改采样或默认；继续恢复、交付及全部任务。\n'+t)
print(json.dumps(dict(files=len(files),omitted=len(omitted),archive_bytes=(O/'raw.tar.gz').stat().st_size)))

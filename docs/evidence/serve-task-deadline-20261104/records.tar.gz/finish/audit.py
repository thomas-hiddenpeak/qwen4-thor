def audit(data):
    read = lambda name: json.loads(data[name])
    plan = read('plan.json')
    first, fixed = (read(name + '/result.json') for name in ('cpu', 'cpu-repair'))
    require(first['tests_run'] == len(set(first['names'])) == 16 and first['failures'] == 2 and (not first['errors']) and (not first['skipped']) and fixed['passed'] and (fixed['tests_run'] == 2) and (not fixed['failures']) and (not fixed['errors']) and (not fixed['skipped']), 'CPU outcomes')
    for name, digest in plan['receipts'].items():
        require(sha(data[name + '/result.json']) == digest, 'original receipt changed')
    for name in ('cpu', 'cpu-repair'):
        for path, digest in read(name + '/result.json')['sources'].items():
            require(sha(data[name + '/source/' + path]) == digest, 'CPU source identity')
    driver = read('cpu-driver-final/result.json')
    require(driver['passed'] and driver['tests_run'] == 2 and (not driver['errors']) and (not driver['failures']) and (not driver['skipped']), 'driver gate')
    for name, digest in driver['sources'].items():
        require(sha(data['cpu-driver-final/source/' + name]) == digest == plan['source_files'][name], 'driver identity')
    require(fixed['sources'] == {n: plan['source_files'][n] for n in fixed['sources']}, 'final CPU source drift')
    for name in READERS:
        require(sha(data['current-source/' + name]) == plan['source_files'][name], 'reader drift')
    for name, digest in plan['historical']['sources'].items():
        require(sha(data['historical-source/' + name]) == digest, 'historical drift')
    repro = read('reproduction/result.json')
    require(repro['tests_run'] == repro['failures'] == 1 and repro['simulated_elapsed'] > repro['deadline_seconds'] and (not repro['errors']), 'original defect absent')
    network = read('execution/network/result.json')
    require(network['status'] == 'PASS_TLS_DEADLINES' and network['probes'] == 12 and (len(network['records']) == 12) and (network['candidate_transport_sha256'] == plan['source_files']['tools/project_tasks/transport.py']) and (network['baseline_transport_sha256'] == plan['historical']['sources']['tools/project_tasks/transport.py']), 'network sources/probes')
    for row in network['records']:
        require(row['accepts'] == 1 and row['thread_stopped'] and row['listener_released'] and (row == read('execution/network/' + row['name'] + '.json')), 'network peer cleanup/receipt')
        name = row['name']
        if name == 'baseline-headers':
            require(row['error'] == 'TimeoutError' and 0.75 < row['elapsed_seconds'] < 2.5, 'real baseline defect')
        elif name in s.deadline_probes.CASES:
            if name.endswith('-ok'):
                require(row['body'] == 'ok' and row['error'] is None, 'normal response')
            else:
                require(row['error'] == 'TimeoutError' and 0.15 < row['elapsed_seconds'] < 0.8, 'bounded deadline: ' + name)
        else:
            expected = 'REQUEST_UNKNOWN' if name == 'generation-deadline' else 'PREFLIGHT_REJECTED'
            require(row['state']['state'] == expected and row['real_tools'] == 0, 'network task safety')
    result = read('execution/result.json')
    require(result['status'] == 'PASS_TASK_DEADLINE_SHORT' and result['cleanup_confirmed'] and (result['counts']['starts'] == 1) and (result['counts']['generation_attempts'] == 4) and (result['counts']['controls'] <= 48) and (result['seconds'] <= 210), 'real execution bounds')
    log = data['execution/new/scoped-model/stderr.log'].decode()
    ends = [dict(re.findall('([a-z_]+)=([^ ]+)', line)) for line in log.splitlines() if line.startswith('[q4t][request]') and ' event=end ' in line]
    require(len(ends) == 4 and all((row['outcome'] == 'success' and row['reason'] == 'completed' and (row['released'] == '1') for row in ends)) and (log.count('grammar worker reaped=1 ') == 4) and ('shutdown complete (0 in-flight remaining)' in log), 'backend completion/cleanup')
    metrics = read('execution/final-metrics.json')
    require(metrics['q4t_requests_success_total'] == metrics['q4t_structured_workers_started_total'] == metrics['q4t_structured_workers_reaped_total'] == 4 and all((metrics[n] == 0 for n in s.prior.s.a.EMPTY)), 'request resource counters')
    ids, usage = (set(), {})
    parent = s.BASE / 'offline'
    parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as temporary:
        for client, tokens in (('alpha', 512), ('beta', 64)):
            known, final = (read('execution/' + client + suffix) for suffix in ('-known-ledger.json', '-ledger.json'))
            require(known['meta'] == final['meta'] and known['events'] == final['events'][:len(known['events'])] and (known['events'][-1]['kind'] == 'tool_result'), 'saved tool history changed')
            prefix = 'execution/' + client + '-completed-task/'
            folder = Path(temporary) / final['meta']['task_id']
            folder.mkdir(mode=448)
            for name, raw in data.items():
                if name.startswith(prefix):
                    store.write_new(folder / name[len(prefix):], raw)
            require(sha(data[prefix + 'ledger.db']) == final['database_sha256'], 'ledger bytes')
            db = store.connection(folder)
            try:
                ledger = store.Ledger(folder, db, final['meta']['store_id'])
                state = engine.replay(ledger)
                public = engine.public(ledger, state)
                expected = json.loads(read('execution/' + client + '-completed.json')['stdout'])
                require(ledger.meta == final['meta'] and ledger.events() == final['events'] and (public == expected) and (public['state'] == 'COMPLETED') and (public['requests'] == 2) and (public['max_tokens'] == tokens) and (public['tool_attempts'] == public['saved_tool_results'] == 1) and (public.get('migrations', 0) == int(client == 'alpha')) and ('Qwen4ExpForConditionalGeneration' in public['answer']) and ('[docs/MODEL.md:L1-L24]' in public['answer']), 'actual task result/budget')
                require(state['execution_spec']['runtime_sources'] == {n: plan['source_files'][n] for n in engine.RUNTIME_FILES} and state['execution_spec']['binding'] == ledger.spec['binding'] == plan['bindings'][client + '-new'], 'task binding')
                by = lambda kind: [row['payload'] for row in ledger.events() if row['kind'] == kind]
                if client == 'alpha':
                    change = by('migration')[0]['plan']
                    require(change['source_release'] == plan['historical']['release'] == 'srv11i-3967b862' and change['format'] == migration.FORMAT and (change['source_spec']['runtime_sources'] == plan['historical']['sources']), 'registered source migration')
                require(by('tool_started')[0]['arguments'] == dict(path='docs/MODEL.md', start_line=1, line_count=24) and by('tool_started')[0]['name'] == 'read_project_record', 'real tool arguments')
                source = json.loads(by('tool_result')[0]['content'])
                require(source['ok'] and source['source']['sha256'] == plan['source_files']['docs/MODEL.md'], 'real project source')
                observations = data['execution/' + client + '-old/read-observations.jsonl'].splitlines()
                require(len(observations) == 1 and dict(json.loads(observations[0])['result'], application_budget=dict(remaining_model_requests=1, remaining_tool_calls=0, final_response_required=True)) == source, 'exactly one real project read')
                usage[client] = [row['completion']['usage'] for row in by('response')]
                require(len(usage[client]) == 2 and all((0 < row['completion_tokens'] <= tokens for row in usage[client])), 'usage limits')
                ids.update((row['completion']['id'] for row in by('response')))
                require(json.loads(read('execution/' + client + '-duplicate-submit.json')['stdout']) == dict(public, created=False), 'duplicate submitted execution')
            finally:
                db.close()
            require(read('execution/' + client + '-old/reaped.json')['returncode'] == -9, 'application death boundary')
    require(ids == {row['id'] for row in ends}, 'wire/backend correlation')
    for name in ('scoped-model', 'nginx'):
        require(read('execution/new/' + name + '/reaped.json')['returncode'] == 0, 'service child exit')
    events = [json.loads(raw) for raw in data['execution/lease/events.jsonl'].splitlines()]
    starts = [r for r in events if r['event'] == 'lease_acquired']
    stops = [r for r in events if r['event'] == 'lease_released']
    observations = [r for r in events if r['event'] in ('preflight', 'monitor')]
    require(len(starts) == len(stops) == 1 and stops[0]['status'] == read('execution/lease/exit.json')['status'] == 'COMPLETED' and observations and all((not row['conflicts'] for row in observations)), 'lease ownership/observations')
    seconds = stops[0]['monotonic'] - starts[0]['monotonic']
    require(0 < seconds <= 210, 'lease duration')
    post = read('postflight/result.json')
    require(post['passed'] and len(post['owners']) == 4 and all((r['gone'] for r in post['owners'])) and (post['lock'] == dict(dev=66305, inode=3294067, released=True)) and post['default_unchanged'] and (post['day_plans'] == plan['day_plans']) and (read('postflight/gpu.json')['pids'] == []), 'postflight resource release')
    require(not data['postflight/containers.txt'].strip() and len(data['postflight/listeners.txt'].splitlines()) == 1 and (dict((line.split('=', 1) for line in data['postflight/soar-unit.txt'].decode().splitlines())) == dict(LoadState='masked', ActiveState='inactive', SubState='dead', MainPID='0')), 'service state')
    return dict(status='ACCEPT_TASK_NETWORK_DEADLINE', cpu_effective_tests=16, driver_tests=2, original_fixture_failures=2, repaired_fixture_tests=2, original_defect_reproduced=True, real_tls_probes=12, models=1, complete_responses=4, real_tools=2, usage=usage, application_kills=2, source_migrations=1, duplicate_submits=2, gpu_seconds=seconds, guard_observations=len(observations), owned_exited=4, default_unchanged=True, long_run=False, performance_acceptance=False)

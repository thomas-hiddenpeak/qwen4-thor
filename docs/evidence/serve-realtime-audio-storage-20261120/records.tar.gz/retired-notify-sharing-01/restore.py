from pathlib import Path
import json,hashlib,os,shutil
root=Path(__file__).parent
for row in json.loads((root/'plan.json').read_text())['rows']:
 p=Path(row['path'])
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256']
 if p.stat().st_nlink>1:
  tmp=p.with_name(p.name+'.detach')
  assert not tmp.exists()
  shutil.copyfile(p,tmp);tmp.chmod(row['mode'])
  os.utime(tmp,ns=(row['atime_ns'],row['mtime_ns']))
  os.replace(tmp,p)
 else:os.utime(p,ns=(row['atime_ns'],row['mtime_ns']))
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256']
print('Restored independent binaries and original timestamps')

"""Preserve paths/bytes/modes of inactive identical read-only test binaries."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent / 'retired-notify-sharing-01'
BASE = ROOT / 'build/serve-notify-tests'
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
assert not OUT.exists()
OUT.mkdir(mode=0o700)
before = {str(p): sha(p) for p in (ROOT / 'build/q4t', ROOT / 'build/service.release.json')}
rows = []
for name in ('amtool', 'alertmanager', 'promtool', 'prometheus'):
    paths = sorted(BASE.glob('tmp*/package/' + name))
    assert len(paths) == 3
    source = paths[0]
    digest = sha(source)
    for path in paths:
        stat = path.stat()
        assert not path.is_symlink() and stat.st_nlink == 1
        assert stat.st_mode & 0o777 == 0o500 and sha(path) == digest
        rows.append(dict(path=str(path), source=str(source), sha256=digest,
                         bytes=stat.st_size, blocks=stat.st_blocks,
                         mode=stat.st_mode & 0o777, atime_ns=stat.st_atime_ns,
                         mtime_ns=stat.st_mtime_ns))
# Check actual file ownership in live processes, not a substring of this script.
selected = {row['path'] for row in rows}
active = []
unreadable = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        targets = [proc / 'exe', proc / 'cwd'] + list((proc / 'fd').iterdir())
        for target in targets:
            try:
                value = os.readlink(target)
            except FileNotFoundError:
                continue
            if value in selected or value.startswith(str(BASE) + '/'):
                active.append([int(proc.name), str(target), value])
    except ProcessLookupError:
        continue
    except PermissionError:
        unreadable.append(int(proc.name))
    except FileNotFoundError:
        continue
assert not active, active
save(OUT / 'plan.json', dict(rows=rows, before=before,
                           active_selected_files=active,
                           inaccessible_processes=unreadable,
                           mtime_note='Original nanosecond times retained for detachment; linked copies inherit anchor mtime.'))
(OUT / 'restore.py').write_text('''from pathlib import Path
import json,hashlib,os,shutil
root=Path(__file__).parent
for row in json.loads((root/'plan.json').read_text())['rows']:
 p=Path(row['path'])
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256']
 if p.stat().st_nlink>1:
  tmp=p.with_name(p.name+'.detach')
  assert not tmp.exists()
  shutil.copyfile(p,tmp);tmp.chmod(row['mode'])
  os.utime(tmp,ns=(row['atime_ns'],row['mtime_ns']))
  os.replace(tmp,p)
 else:os.utime(p,ns=(row['atime_ns'],row['mtime_ns']))
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256']
print('Restored independent binaries and original timestamps')
''')
started = time.monotonic()
freed = 0
for row in rows:
    path, source = Path(row['path']), Path(row['source'])
    if path == source:
        continue
    assert sha(path) == row['sha256'] and sha(source) == row['sha256']
    temporary = path.with_name(path.name + '.shared')
    assert not temporary.exists()
    os.link(source, temporary)
    os.replace(temporary, path)
    freed += row['blocks'] * 512
for row in rows:
    path = Path(row['path'])
    assert sha(path) == row['sha256'] and path.stat().st_mode & 0o777 == row['mode']
for path, digest in before.items():
    assert sha(Path(path)) == digest
result = dict(status='PASS_PATH_PRESERVING_READONLY_BINARY_SHARING',
              seconds=time.monotonic() - started, allocated_bytes_released=freed,
              source_files=4, additional_paths_shared=8, deleted_paths=0,
              protected_default_unchanged=True, private_policies_shared=False,
              original_timestamps_recorded=True, gpu_starts=0,
              free_bytes=shutil.disk_usage(ROOT).free)
save(OUT / 'result.json', result)
print(json.dumps(result))

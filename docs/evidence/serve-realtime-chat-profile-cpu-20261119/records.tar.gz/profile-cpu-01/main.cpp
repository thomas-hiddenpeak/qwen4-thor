#include "q4t/test.h"
int main(){return q4t::test::RunTests({"realtime_chat_capabilities_do_not_require_transcription_backend","realtime_chat_capabilities_bind_real_storage_and_pending_processors"});}

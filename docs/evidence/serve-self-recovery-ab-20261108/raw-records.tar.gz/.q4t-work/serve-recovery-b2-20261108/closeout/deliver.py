"""Install the exact accepted local service entry; never launch a model."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/home/rm01/models/dev/qwen4-thor')
WORK = ROOT/'.q4t-work/serve-recovery-b2-20261108'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

os.umask(0o077)
accepted = read(WORK/'closeout/result.json')
assert accepted['status'] == 'ACCEPT_BOUNDED_SELF_RECOVERY_AB'
receipt = accepted['package']
package = Path(receipt['package'])
bundle.verify(package, receipt['manifest_sha256'])
target = WORK/'delivery-attempt-01'
target.mkdir(mode=0o700)
rollback = target/'rollback'
rollback.mkdir(mode=0o700)
entry = ROOT/'build/service'
metadata = ROOT/'build/service.release.json'
state = ROOT/'build/service-state'
assert not any(p.exists() or p.is_symlink() for p in (entry, metadata, state))
preserved = []
for name in ('q4t', 'q4t.release.json'):
    source, destination = ROOT/'build'/name, rollback/name
    shutil.copy2(source, destination)
    destination.chmod(0o500 if name == 'q4t' else 0o400)
    assert sha(source) == sha(destination)
    preserved.append(dict(path=str(source), rollback=str(destination), sha256=sha(source)))
save(rollback/'receipt.json', dict(previous_service_entry=None,
    previous_service_metadata=None, preserved=preserved,
    instructions='Stop the exact service state before unlinking this known entry; keep state/ledger and sealed bundle. Direct build/q4t serve retains its original contract.'))

checks = []
def invoke(arguments, expected):
    result = subprocess.run([str(package/'bin/q4t'), 'service', *arguments],
        capture_output=True, text=True, timeout=10)
    checks.append(dict(argv=arguments, exit_code=result.returncode,
        stdout=result.stdout, stderr=result.stderr))
    save(target/('entry-check-'+str(len(checks))+'.json'), checks[-1])
    assert result.returncode == expected
    return result.stdout

invoke(['--help'], 0)
initialized = json.loads(invoke(['init', '--state', str(state)], 0))
assert initialized['desired'] == 'STOPPED' and initialized['automatic_start'] is False
status = json.loads(invoke(['status', '--state', str(state)], 1))
assert status['state'] == 'UNKNOWN' and not status['business_ready'] and not status['live_control']
assert read(state/'ledger.json')['state']['desired'] == 'STOPPED'
temporary = entry.with_name('service.installing')
temporary.symlink_to(package, target_is_directory=True)
assert not entry.exists() and not entry.is_symlink()
os.replace(temporary, entry)
assert entry.resolve() == package.resolve()
bundle.verify(entry, receipt['manifest_sha256'])
value = dict(version=1, profile='q4t-service-recovery-v1',
    acceptance='ACCEPT_BOUNDED_SELF_RECOVERY_AB', recovery_accepted=True,
    acceptance_record=str(WORK/'closeout/result.json'),
    acceptance_sha256=sha(WORK/'closeout/result.json'),
    package=str(package), manifest_sha256=receipt['manifest_sha256'],
    engine_binary_sha256=receipt['engine_binary_sha256'],
    engine_release_sha256=sha(ROOT/'build/q4t.release.json'),
    entry=str(entry/'bin/q4t'), state=str(state), service_id=initialized['service_id'],
    initial_desired='STOPPED', automatically_started=False,
    listen='127.0.0.1:18161', upstream='127.0.0.1:18162', operations='127.0.0.1:18163',
    clients=[dict(id='alpha',rpm=30,tpm=6000),dict(id='beta',rpm=1,tpm=6000)],
    scope='single-slot text/MTP, loopback, process resource mode; local short acceptance only',
    rollback_receipt=str(rollback/'receipt.json'), rollback_sha256=sha(rollback/'receipt.json'),
    engine_default_replaced=False, gpu_starts_for_install=0,
    long_stability_accepted=False, tls_lan_accepted=False,
    limitations=['No Guardian resurrection without an outer manager',
        'Blocking log isolation, bounded grammar reap and execution progress watchdog remain C/D',
        'No delegated cgroup/physical RAM hard limit or NVML-free cold start'])
save(metadata, value)
fd = os.open(metadata, os.O_RDONLY)
try:
    os.fsync(fd)
finally:
    os.close(fd)
fd = os.open(entry.parent, os.O_RDONLY | os.O_DIRECTORY)
try:
    os.fsync(fd)
finally:
    os.close(fd)
for row in preserved:
    assert sha(Path(row['path'])) == row['sha256'] == sha(Path(row['rollback']))
result = dict(status='DELIVERED_STOPPED', release=value,
    release_sha256=sha(metadata), initialized=initialized, checks=checks,
    engine_default_unchanged=True, model_starts=0, chats=0)
save(target/'result.json', result)
print(json.dumps(dict(status=result['status'], entry=value['entry'],
    metadata=str(metadata), manifest_sha256=value['manifest_sha256'],
    state=str(state), live_service=False), ensure_ascii=False))

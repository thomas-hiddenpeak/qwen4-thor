"""Offline closure of frozen A/B records. Does not start models or query NVML."""
from dataclasses import asdict
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

ROOT = Path('/home/rm01/models/dev/qwen4-thor')
WORK = ROOT/'.q4t-work/serve-recovery-b2-20261108'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools.examples import chat_client
from tools.serve_recovery import bundle, journal

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def lines(path):
    return [json.loads(row) for row in Path(path).read_text().splitlines()]

receipt = read(WORK/'package-attempt-02/receipt.json')
package = Path(receipt['package'])
manifest = bundle.verify(package, receipt['manifest_sha256'])
for name in bundle.SOURCES:
    assert sha(ROOT/name) == sha(package/'source'/name), name
native = read(package/'native-build.json')
for name, digest in native['source_files'].items():
    assert sha(ROOT/name) == digest, name
assert sha(ROOT/'build/q4t') == receipt['engine_binary_sha256']
assert sha(ROOT/'build/q4t.release.json') == sha(package/'engine/q4t.release.json')

attempts, known, reparse = [], set(), []
prior = dict(starts=0, chats=0, probes=0, controls=0)
source_references = {}
for index in range(1, 4):
    directory = WORK/f'business-attempt-{index:02d}'
    plan = read(directory/'plan.json')
    result = read(directory/'execution/result.json')
    outer = read(directory/'lease/exit.json')
    queries = lines(directory/'lease/nvml-queries.jsonl')
    events = lines(directory/'lease/events.jsonl')
    samples = lines(directory/'execution/status.jsonl')
    expected = 'FAILED' if index < 3 else 'PASS_BOUNDED_RECOVERY_BUSINESS'
    assert result['status'] == expected and result['cleanup_failure'] is None
    assert outer['status'] == ('COMMAND_FAILED' if index < 3 else 'COMPLETED')
    assert outer['child_returncode'] == (1 if index < 3 else 0)
    assert outer['lease_inherited_by_child'] and outer['compute_backend'] == 'nvml'
    assert queries and all(q['status'] == 'OK' for q in queries)
    assert queries[-1]['pids'] == []
    assert not any(e.get('conflicts') or e.get('event') == 'environment_abort' for e in events)
    assert plan['package'] == result['package'] == receipt
    assert (plan.get('prior_counts') or dict.fromkeys(prior, 0)) == prior
    assert read(directory/'execution/counts.json') == result['budget']
    counts = result['budget']['counts']
    actual = {k: counts[k]-prior[k] for k in counts}
    assert (actual['starts'], actual['chats']) == [(1, 5), (2, 10), (2, 6)][index-1]
    assert len(result['models']) == actual['starts']
    for kind in ('starts', 'chats', 'probes'):
        rows = [e for e in result['budget']['events'] if e['kind'] == kind]
        assert [e['ordinal'] for e in rows] == list(range(prior[kind]+1, counts[kind]+1))
    prior = counts
    stop = read(directory/'execution/stop.json')
    ledger = read(directory/'execution/stopped-ledger.json')
    assert stop['state'] == 'STOPPED' and stop['stop_durable'] and stop['cleanup_confirmed']
    assert ledger['desired'] == 'STOPPED' and all(v is None for v in ledger['active'].values())
    for sample in samples:
        assert not sample['business_ready'] or sample['quota_wait_ms'] == 0
        for role in ('guardian', 'controller', 'gateway', 'journal', 'model'):
            if sample[role+'_pid']:
                known.add((sample[role+'_pid'], sample[role+'_start_ticks']))
    for name, digest in plan['sources'].items():
        source_references[plan['source_commit']+':'+name] = digest
    for row in plan['protected'] + plan.get('prior_evidence', []):
        assert sha(row['path']) == row['sha256'], row['path']
    for response_path in sorted((directory/'execution').glob('*-response.json')):
        response = read(response_path)
        if 'self-check' in response_path.name:
            assert response['http_status'] == 200
            parsed = chat_client.read_json(io.BytesIO(response['body'].encode()))
            assert parsed.finish_reason == 'stop' and json.loads(parsed.message['content']) == {'ok': True}
            reparse.append(dict(attempt=index, label=response_path.stem, quality='self-check'))
            continue
        label = response_path.name.removesuffix('-response.json')
        raw = (directory/'execution'/(label+'-wire.bin')).read_bytes()
        if response['status'] != 200:
            assert json.loads(raw) == response['value']
            reparse.append(dict(attempt=index, label=label, status=response['status']))
            continue
        request = read(directory/'execution'/(label+'-request.json'))
        parse = chat_client.read_sse if request['stream'] else chat_client.read_json
        parsed = parse(io.BytesIO(raw))
        assert asdict(parsed) == response['value']
        assert parsed.id == request['request_id'] and parsed.model == request['model']
        if label.endswith(('-json', '-sse')):
            assert parsed.finish_reason == 'stop' and parsed.message['content'].strip() == '42'
        elif label.endswith('-tool-call'):
            calls = parsed.message['tool_calls']
            assert parsed.finish_reason == 'tool_calls' and len(calls) == 1
            assert calls[0]['function']['name'] == 'read_project_record'
            assert json.loads(calls[0]['function']['arguments']) == dict(path='docs/MODEL.md', start_line=1, line_count=16)
            tool = read(directory/'execution'/(label.removesuffix('-call')+'-result.json'))
            assert tool['executions'] == 1 and tool['call_id'] == calls[0]['id'] and tool['result']['ok']
            assert tool['result']['source']['sha256'] == sha(ROOT/'docs/MODEL.md')
        elif label.endswith('-tool-final'):
            assert parsed.finish_reason == 'stop' and not parsed.message.get('tool_calls')
            assert '[docs/MODEL.md:L1-L16]' in parsed.message['content']
        else:
            raise AssertionError(label)
        reparse.append(dict(attempt=index, label=label, status=200, seconds=response['seconds']))
    rows = [e for e in events if e['event'] == 'lease_acquired']
    assert len(rows) == 1
    attempts.append(dict(attempt=index, status=expected, outer=outer['status'], actual=actual,
        seconds=result['seconds'], lease_seconds=outer['finished']['monotonic']-rows[0]['monotonic'],
        nvml_queries=len(queries), final_compute_pids=[], source_commit=plan['source_commit']))

# Bind every frozen source entry to the committed blob, including failed drivers.
refs = list(source_references)
raw = subprocess.check_output(['git', 'cat-file', '--batch'],
    input=('\n'.join(refs)+'\n').encode(), cwd=ROOT)
stream = io.BytesIO(raw)
for ref in refs:
    header = stream.readline().split()
    assert header[1] == b'blob', ref
    data = stream.read(int(header[2])); assert stream.read(1) == b'\n'
    assert hashlib.sha256(data).hexdigest() == source_references[ref], ref
assert not stream.read()

first = WORK/'business-attempt-01/execution'
second = WORK/'business-attempt-02/execution'
third = WORK/'business-attempt-03/execution'
for directory in (first, second):
    fault = read(directory/'fault-counts-1.json')
    assert fault['nvml_injected'] > 0 and fault['log_errors'] > 0 and fault['metrics_attempts'] == 0
    gap, ready = read(directory/'auxiliary-gap.json'), read(directory/'ready-1.json')
    assert gap['business_ready'] and gap['model_pid'] == ready['model_pid']
    assert gap['controller_health']['observation'] == 'UNKNOWN'
    assert gap['controller_health']['reason'] == 'nvml_timeout'
old, new = read(second/'ready-1.json'), read(second/'ready-2.json')
assert old['guardian_pid'] == new['guardian_pid'] and old['controller_pid'] == new['controller_pid']
assert old['gateway_pid'] == new['gateway_pid'] and old['model_pid'] != new['model_pid']
assert new['probe_used_for_generation'] == 1 and new['business_ready']
assert read(second/'interrupted-sse-result.json')['killed']
assert b'[DONE]' not in (second/'interrupted-sse-wire.bin').read_bytes()
assert read(second/'model-recovery-503-response.json')['status'] == 503
assert read(second/'model-recovery-503-unauthorized-response.json')['status'] == 401
old, new, rebound = (read(third/name) for name in ('ready-1.json', 'ready-2.json', 'gateway-recovered.json'))
assert old['guardian_pid'] == new['guardian_pid'] == rebound['guardian_pid']
assert old['controller_pid'] != new['controller_pid'] == rebound['controller_pid']
assert old['model_pid'] != new['model_pid'] == rebound['model_pid']
assert old['gateway_pid'] == new['gateway_pid'] != rebound['gateway_pid']
assert new['controller_generation'] == rebound['gateway_generation'] == new['model_generation'] == 2
assert read(third/'controller-recovery-503-response.json')['status'] == 503
assert read(third/'controller-recovery-503-unauthorized-response.json')['status'] == 401
drain = read(third/'generation-2-metrics.json')['observations']
final = drain[-1]['values']
assert final['q4t_requests_total'] == final['q4t_requests_success_total'] == 5
assert final['q4t_seq_slots_free'] == final['q4t_seq_slots_total'] == 1
assert final['q4t_structured_workers_started_total'] == final['q4t_structured_workers_reaped_total'] == 3
assert drain[-1]['monotonic'] - drain[0]['monotonic'] < 5
recovery_seconds = {}
for directory, role, target in ((second, 'model', 'model'), (third, 'controller', 'controller'), (third, 'gateway', 'gateway')):
    start = read(directory/(role+'-exit-fault.json'))['monotonic']
    ready = next(s for s in lines(directory/'status.jsonl') if s['monotonic'] > start and s['business_ready'] and s[target+'_generation'] == 2)
    recovery_seconds[role] = ready['monotonic']-start

for pid, ticks in known:
    try:
        assert journal.process_start(pid) != ticks, (pid, ticks)
    except (FileNotFoundError, ProcessLookupError):
        pass
for port in (18161, 18162, 18163):
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', port))
with open(manifest['lock_path'], 'rb') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    # This is a new open-file-description; close releases only this audit lock.
assert prior['starts'] == 5 and prior['chats'] == 21 and prior['probes'] == 1
assert sum(a['lease_seconds'] for a in attempts) < 1800
result = dict(status='ACCEPT_BOUNDED_SELF_RECOVERY_AB', package=receipt,
    cpu_distinct=177, cpu_groups=dict(native=25, lifecycle=35, policy_ledger_journal=58,
        child=9, gateway=14, real_nginx=6, production=22, acceptance_driver=8),
    attempts=attempts, cumulative_counts=prior, total_seconds=sum(a['seconds'] for a in attempts),
    total_lease_seconds=sum(a['lease_seconds'] for a in attempts),
    nvml_queries=sum(a['nvml_queries'] for a in attempts), all_nvml_ok=True,
    source_entries_verified=len(source_references), packaged_python_sources=len(bundle.SOURCES),
    native_build_sources=len(native['source_files']), responses=reparse,
    known_role_identities_retired=len(known), lock_free=True, ports_free=[18161,18162,18163],
    recovery_seconds=recovery_seconds, grammar_drain_seconds=drain[-1]['monotonic']-drain[0]['monotonic'],
    original_failures_preserved=True, one_successful_supplemental_lease=True,
    all_attempts_were_one_lease=False, engine_default_unchanged=True,
    performance_acceptance=False, long_stability_acceptance=False)
with (WORK/'closeout/result.json').open('x') as output:
    json.dump(result, output, indent=2, ensure_ascii=False); output.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('responses', 'package')}, ensure_ascii=False))

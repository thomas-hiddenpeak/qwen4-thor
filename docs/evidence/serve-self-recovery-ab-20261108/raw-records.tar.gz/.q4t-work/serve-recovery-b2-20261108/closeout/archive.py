"""Preserve selected raw evidence; exclude deployment credentials and state."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/rm01/models/dev/qwen4-thor')
WORK = ROOT/'.q4t-work/serve-recovery-b2-20261108'
DEST = ROOT/'docs/evidence/serve-self-recovery-ab-20261108'
DEST.mkdir(parents=True, exist_ok=True)
assert not list(DEST.iterdir()), 'refuse to overwrite an existing evidence archive'
records = {}

def include(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    records[str(path.relative_to(ROOT))] = path.read_bytes()

for suffix in ('a1-20261107', 'a2-20261107', 'b1-20261108', 'b2-20261108'):
    root = ROOT/('.q4t-work/serve-recovery-'+suffix)
    for path in root.iterdir():
        if path.is_file() and path.suffix in ('.json', '.log'):
            include(path)
        if path.is_dir() and any(path.name.startswith(prefix) for prefix in (
                'attempt-', 'journal-attempt-', 'runtime-attempt-', 'runtime-build-',
                'model-channel-attempt-', 'launch-attempt-', 'receipt-attempt-',
                'gateway-attempt-', 'probe-build-', 'driver-cpu-')):
            for child in path.iterdir():
                if child.is_file() and child.suffix in ('.json', '.log'):
                    include(child)
for index in range(1, 4):
    root = WORK/f'business-attempt-{index:02d}'
    for directory in (root, root/'execution', root/'lease'):
        for path in directory.iterdir():
            if path.is_file() and path.suffix in ('.json', '.jsonl', '.log', '.bin'):
                include(path)
    plan = json.loads((root/'plan.json').read_text())
    for name in ('tools/serve_recovery/acceptance.py', 'tools/serve_recovery/test_acceptance.py'):
        key = 'source-snapshots/'+plan['source_commit']+'/'+name
        records[key] = subprocess.check_output(['git', 'show', plan['source_commit']+':'+name], cwd=ROOT)
for index in (1, 2):
    root = WORK/f'package-attempt-{index:02d}'
    for name in ('receipt.json', 'native-build.json', 'entry-check.json',
                 'bundle/manifest.json', 'bundle/native-build.json', 'bundle/engine/manifest.json'):
        path = root/name
        if path.exists():
            include(path)
for name in ('audit.py', 'audit.log', 'result.json', 'deliver.py', 'delivery.log',
             'archive.py', 'archive-attempt-01.log', 'archive-attempt-01.py'):
    include(WORK/'closeout'/name)
for path in (WORK/'delivery-attempt-01').glob('*.json'):
    include(path)
include(WORK/'delivery-attempt-01/rollback/receipt.json')
include(ROOT/'build/service.release.json')

# Inspect private originals only to prevent copying credentials into public evidence.
secrets = set()
def visit(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'gateway_token') and isinstance(item, str) and len(item) >= 16:
                secrets.add(item.encode())
            visit(item)
    elif isinstance(value, list):
        for item in value:
            visit(item)
for name in ('client-policy.json', 'gateway-policy.json', 'gateway.json'):
    for path in WORK.rglob(name):
        visit(json.loads(path.read_text()))
assert secrets
for name, data in records.items():
    assert not any(secret in data for secret in secrets), 'private credential in '+name
    assert not re.search(br'(?m)^-----BEGIN (?:.* )?PRIVATE KEY-----$', data), name

archive = DEST/'raw-records.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as output:
    for name, data in sorted(records.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o444
        output.addfile(info, io.BytesIO(data))
manifest = dict(version=1, archive='raw-records.tar.gz',
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), count=len(records),
    records=[dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest())
             for name, data in sorted(records.items())],
    excluded=['deployment API keys/backend tokens', 'live/private service configs and state trees',
              'model assets', 'native ELF/build trees'],
    known_credentials_scanned=len(secrets), original_failures_preserved=True)
(DEST/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
(DEST/'result.json').write_bytes((WORK/'closeout/result.json').read_bytes())
(DEST/'delivery.json').write_bytes((WORK/'delivery-attempt-01/result.json').read_bytes())
with tarfile.open(archive) as preserved:
    for row in manifest['records']:
        data = preserved.extractfile(row['path']).read()
        assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps(dict(records=len(records), bytes=archive.stat().st_size,
    sha256=manifest['sha256'], known_credentials_excluded=len(secrets))))

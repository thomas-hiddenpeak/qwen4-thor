from pathlib import Path
import collections,hashlib,json,sys,tarfile
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R));W=Path(__file__).parent;B=W/'task-scoped-business-01';O=R/'docs/evidence/serve-realtime-duplex-task-scoped-http-20261120';O.mkdir()
from tools.serve_realtime import duplex_task_checks as c
from tools.serve_recovery import profile_realtime as p,profile_duplex_evidence as e
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
plan=read(B/'plan.json');result=read(B/'result.json');assert result['status']=='FAILED'
assert all(sha(R/n)==h for n,h in {**plan['sources'],**plan['protected']}.items())
raw=read(B/'light-duplex-speech_tool.sdk.json');journal=[json.loads(l) for l in (B/'light-duplex-speech_tool.events.jsonl').read_text().splitlines()]
observed=c.observe(raw,e.PHRASE,plan['duplex']['source'],journal);assert all(q['status']=='PASS' for q in observed['quality'])
states={}
for label in ('before','after-0'):
 meta=read(B/f'light-duplex-speech_tool-{label}.http.json');assert meta['status']==200
 states[label]=p.state(p.encrypted.foreground.base.lifecycle.parse_metrics((B/f'light-duplex-speech_tool-{label}.wire').read_bytes()),p.encrypted.CLIENT)
 e.state(states[label])
assert states['after-0']['admitted']-states['before']['admitted']==observed['admitted']==6
assert states['after-0']['settled']-states['before']['settled']==observed['visible_tokens']
save(B/'speech-tool-reviewed.json',dict(observed=observed,before=states['before'],after=states['after-0'],original_stage_status='FAILED'))
clean=read(B/'cleanup.json');assert clean['remaining']==[] and clean['model_exit']==0 and clean['ports_released'] and clean['lease_continuously_held']
qs=[json.loads(l) for l in (B/'lease/nvml-queries.jsonl').read_text().splitlines()];nvml=dict(collections.Counter(q['status'] for q in qs));assert set(nvml)=={'OK'}
failed=read(B/'light-duplex-barge_in.sdk.json');assert failed['status']=='FAIL'
fr=[json.loads(l) for l in (B/'light-duplex-barge_in.events.jsonl').read_text().splitlines()]
request=next(r['event']['response'] for r in fr if r['direction']=='client' and r['event']['type']=='response.create');assert request['conversation']=='none'
rows=[];omitted=[];token=read(B/'client-policy.json')['gateway_token'].encode()
paths=[f for f in B.iterdir() if f.is_file() and f.name!='client-policy.json']+[f for f in (B/'lease').iterdir() if f.is_file()]+[W/'task_scoped_business_01.py',Path(__file__)]
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for f in paths:
  if token in f.read_bytes():omitted.append(dict(path=str(f.relative_to(W)),sha256=sha(f),reason='private authentication'));continue
  name=str(f.relative_to(W));tar.add(f,arcname=name,recursive=False);rows.append(dict(path=name,bytes=f.stat().st_size,sha256=sha(f)))
save(O/'index.json',dict(records=rows,omitted=omitted,archive_sha256=sha(O/'records.tar.gz')))
review=dict(original_status=result['status'],counts=result['counts'],seconds=result['seconds'],nvml=nvml,speech_tool=read(B/'speech-tool-reviewed.json'),barge_in_driver_failure='conversation:none deliberately immune to VAD cancellation; TTS later reached frame bound',barge_in_actual_error=failed['error'],cleanup_complete=True,default_unchanged=True,qualification_issued=False,master_active=True)
save(O/'review.json',review)
(O/'README.md').write_text('''# 轻量真实语音/工具通过，打断客户端归属错误保留

2026-11-20。候选485a38a3，1模型/2WSS/8预占工作预算/103.428秒。
严格NVML全部正常，模型退出0、所属进程/端口/锁释放，默认rev376不变。

明确当前任务后，实际ASR→完整中文回答→TTS→新ASR→完整复述通过；
实际lookup_project_record调用、结果回填和显式引用回答rev376通过。
六项真实准入与全部可见usage精确结算，会话/预留归零。原错答保持，
本次不证明统计质量改善，也不将原默认历史失败改记成功。

打断客户端错误沿用了conversation:none，属于VAD不能误伤的旁路
回答；真实speech_started没有取消它，之后长语音耗尽帧预算，返回
tts_output_limit。原阶段FAILED/SDK FAIL保持，未颁资格或替换默认。
这次没有证明默认对话语音打断成功，也不是取消语义回归的证据。

下一步修复客户端默认对话归属并增加反例，只补1模型/1WSS/2原生
工作/420秒的实际语音打断。上述通过的轻量语音/工具及主档不重跑。
之后继续受影响恢复、可回退交付及全部master。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认');p.write_text(s[:i]+'''
[轻量语音/工具实测](evidence/serve-realtime-duplex-task-scoped-http-20261120/README.md)：
1模型/2WSS/103.428秒，NVML正常、清理通过。实际语音往返、工具
回填rev376和6次准入结算通过。打断客户端误用conversation:none，
未被VAD取消并最终耗尽TTS帧，整组原FAIL保留。只修默认对话归属并
补1模型/1WSS/2工作/420秒；不重跑已通过业务，默认rev376保持。
''' +s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 轻量真实语音工具闭环通过，保留打断客户端归属错误

日期：2026-11-20。

做了什么：1模型/2WSS/103.428秒，实际语音往返及工具rev376通过，
6工作和usage精确结算。打断客户端沿用旁路conversation:none，VAD
按保护语义不取消它，后续TTS帧限制报错。原阶段FAIL、全部原件保留，
严格监控和所属资源清理通过，未颁资格或替换默认。

为什么：这是验收客户端归属错误，不能改成服务取消成功，也不应
重复已经通过的语音与工具工作。

下一步：默认对话归属修复和针对CPU，补1模型/1WSS/2工作/420秒
实际语音打断；随后恢复、交付和全部master。
''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['realtime_progress']['duplex_input_20261120'].update(state='light_speech_tool_pass_barge_in_client_scope_repair_pending',task_scoped_business=dict(evidence=str(O.relative_to(R)/'README.md'),result=review));save(p,v)
print(json.dumps(dict(review=review,archive_bytes=(O/'records.tar.gz').stat().st_size),ensure_ascii=False))

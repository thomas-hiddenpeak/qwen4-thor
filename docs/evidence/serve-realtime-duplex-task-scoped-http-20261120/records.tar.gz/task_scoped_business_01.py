"""Only failed light speech/tool tasks and actual audio barge-in.

One model, eight native jobs, two WSS, one TLS entry, 600 seconds. Explicit
caller tasks and actual function-result references; native defaults unchanged.
No sampling retries, no repeated primary or unaffected standalone ASR/VAD.
"""
import argparse
import fcntl
import json
from pathlib import Path
import runpy
import signal
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
sys.dont_write_bytecode=True
WORK=Path(__file__).parent
P=runpy.run_path(str(WORK/'audio_boundary_business_01.py'))
prior,full,encrypted,duplex=(P[k] for k in ('prior','full','encrypted','duplex'))
read,save,sha,require=(P[k] for k in ('read','save','sha','require'))
from tools.serve_realtime import duplex_task_checks as checks
from tools.serve_recovery import profile_duplex_evidence as evidence

LIMITS=dict(starts=1,chats=8,controls=600,seconds=600,
            websocket_sessions=2,ingress_starts=1)
FORMAT='q4t-duplex-task-scoped-followup-v1'
SUCCESS='PASS_LIGHT_TASK_SCOPED_BUSINESS'


def check_plan(plan):
    old=read(WORK/'audio-boundary-business-01/plan.json')
    require(plan['targeted_format']==FORMAT and plan['limits']==LIMITS and
        plan['requests']=={} and plan['automatic_retries'] is False and
        plan['duplex']['instruction_policy']==checks.POLICY and
        plan['planned']=={k:v for k,v in LIMITS.items() if k not in ('seconds','controls')},
        'followup scope changed')
    for k in ('binary_sha256','identity','profiles','native_assets','model_assets',
              'base','candidate_identity','reviewed_sources'):
        require(plan[k]==old[k],'runtime/model/capacity drift: '+k)
    for n,h in plan['reviewed_sources'].items():require(sha(ROOT/n)==h,'compiled source drift')


def prepare(out):
    require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),
            'commit reviewed targeted changes')
    cpu=WORK/'task-scoped-cpu-02'
    require(read(cpu/'result.json')['status']=='PASS','targeted CPU missing')
    for n,h in read(cpu/'plan.json')['sources'].items():require(sha(ROOT/n)==h,'CPU source drift')
    out.mkdir(mode=0o700,parents=True)
    plan=read(WORK/'audio-boundary-business-01/plan.json')
    plan.update(targeted_format=FORMAT,limits=LIMITS,output=str(out),port=18568,
        operations_port=18569,scope=__doc__,source_commit=subprocess.check_output(
            ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        planned={k:v for k,v in LIMITS.items() if k not in ('seconds','controls')})
    plan['sources']={n:sha(ROOT/n) for n in plan['sources']}
    plan['sources'].update(read(cpu/'plan.json')['sources'])
    for p in [Path(__file__),cpu/'plan.json',cpu/'result.json']:
        plan['sources'][str(p)]=sha(p)
    plan['duplex']=duplex.prepare(WORK/'idle-business-01/run/plan.json',out,18570,plan['sdk'])
    plan['duplex']['instruction_policy']=checks.POLICY
    plan['sources'].update(plan['duplex']['files'])
    check_plan(plan);save(out/'plan.json',plan)
    print(json.dumps(dict(plan=str(out/'plan.json'),limits=LIMITS)),flush=True)


class Stage(prior.Stage):
    limits=LIMITS
    success_status=SUCCESS

    def __init__(self,plan):
        check_plan(plan);encrypted.Stage.__init__(self,plan)
        self.counts.update(websocket_sessions=0,ingress_starts=0)

    def start(self):full.Stage.start(self,selected='light')

    def business(self):
        require(self.profile_name=='light','unaffected primary must not run')
        sessions=duplex.run_sessions(self,('speech_tool','barge_in'))
        observations={}
        for mode,row in sessions.items():
            journal=[json.loads(l) for l in
                (self.out/('light-duplex-'+mode+'.events.jsonl')).read_text().splitlines()]
            observed=checks.observe(row['session'],evidence.PHRASE,
                                    self.plan['duplex']['source'],journal)
            before,after=row['before'],row['after']
            evidence.state(before);evidence.state(after)
            require(after['admitted']-before['admitted']==observed['admitted'] and
                after['settled']-before['settled']==observed['visible_tokens'],
                'actual native work was lost or charged incorrectly')
            observations[mode]=observed
        save(self.out/'observations.json',observations)
        require(all(q['status']=='PASS' for o in observations.values() for q in o['quality']),
                'targeted original model quality failed')


def finalize(out):
    plan=read(out/'plan.json');check_plan(plan);result=read(out/'result.json')
    require(result['status']==SUCCESS and 0<result['seconds']<=600 and
        all(result['counts'][k]==LIMITS[k] for k in LIMITS if k not in ('seconds','controls')),
        'targeted actual business incomplete')
    for n,h in {**plan['sources'],**plan['protected'],**plan['native_assets']}.items():
        require(sha(ROOT/n)==h,'postflight drift: '+n)
    lease=out/'lease'
    environment=full.environment(read(lease/'exit.json'),
        [json.loads(l) for l in (lease/'nvml-queries.jsonl').read_text().splitlines()],
        [read(out/'cleanup.json')])
    entry=read(out/'light-duplex-entry-cleanup.json')
    require(entry['exit_code']==0 and entry['port_released'],'entry cleanup')
    full.background.probe_ports((18568,18569,18570))
    guard=encrypted.foreground.base.lifecycle.guard
    with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    save(out/'acceptance.json',dict(status=SUCCESS,environment=environment,
        counts=result['counts'],seconds=result['seconds'],default_unchanged=True,
        original_failures_preserved=True,qualification_issued=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('prepare','run','finalize'))
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output.resolve()
    require(out.is_relative_to(WORK.resolve()),'private output required')
    if a.mode=='prepare':prepare(out)
    elif a.mode=='finalize':finalize(out)
    else:
        def interrupted(_signum,_frame):raise TimeoutError('bounded followup interrupted')
        signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGALRM,interrupted)
        signal.alarm(600)
        try:Stage(read(out/'plan.json')).run()
        finally:signal.alarm(0)

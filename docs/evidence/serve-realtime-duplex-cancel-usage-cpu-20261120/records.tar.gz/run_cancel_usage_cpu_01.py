from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'cancel-usage-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();read=lambda p:json.loads(p.read_text());save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
build=read(W/'cancel-usage-build-01/result.json');assert build['status']=='BUILD_PASS' and build['warnings']==0
scope=read(W/'cancel-usage-scope-01.json');names=scope['tests'];assert len(names)==10
(O/'required.txt').write_text('\n'.join(names)+'\n');binary=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';assert sha(binary)==build['binary_sha256']
commands=[[str(binary),'--required-list',str(O/'required.txt')],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
files=read(W/'cancel-usage-build-01/plan.json')['sources'];files.update({str(p):sha(p) for p in [W/'cancel_usage_business_01.py',W/'cancel-usage-scope-01.json']});files.update({n:sha(R/n) for n in ['tools/release/required_host_tests.txt','tools/serve_audit/inventory.json','tools/serve_realtime/duplex_task_checks.py','tools/serve_realtime/duplex_sdk.mjs','tools/serve_realtime/duplex_task_requests.mjs','tools/serve_recovery/profile_duplex.py']})
assert all(sha(R/n)==h for n,h in files.items())
protected=read(W/'cancel-usage-build-01/plan.json')['protected'];plan=dict(scope=scope,commands=commands,sources=files,protected=protected,binary_sha256=sha(binary));save('plan.json',plan);start=time.monotonic();rows=[];status='PASS'
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=120,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O)))
 (O/f'{i}.stdout').write_bytes(r.stdout);(O/f'{i}.stderr').write_bytes(r.stderr);rows.append(dict(command=cmd,exit_code=r.returncode))
 if r.returncode:status='FAIL';break
assert all(sha(Path(n))==h for n,h in protected.items());result=dict(status=status,tests=names,commands=rows,seconds=time.monotonic()-start,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

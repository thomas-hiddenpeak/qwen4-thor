"""Publish actual bounded speaker service evidence, excluding private credentials."""
import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-chat-audio-service-20261118'
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not O.exists() and not (W/'publication-composition.json').exists()
def desc(name):
 p=read(W/name/'receipt.json');return {k:p[k] for k in ('package','manifest_sha256')}
candidate,legacy,modern,tls=[desc(n) for n in ['service-package-01','retained-01','modern-retained-01','tls-package-01']]
binary=sha(Path(candidate['package'])/'engine/q4t')
assert binary=='bcfa0b56c179426ccbba26fec3463d37bd75265fe22e14a7405dac16051ff3b0'
files={};stages=[];decisions={};omitted={}
for name,package,scenario in [('modern-service-01',modern,'tool_retained'),('retained-service-01',legacy,'tool_retained'),('tls-service-01',tls,'tls'),('version-service-02',candidate,'tool_version')]:
 folder=W/name;execution=folder/'execution'
 plan,decision,result,guard=[read(folder/p) for p in ['plan.json','decision.json','execution/result.json','lease/exit.json']]
 assert plan['scenario']==scenario and plan['package']==package
 assert decision['manifest_sha256']==package['manifest_sha256'] and decision['engine_binary_sha256']==binary
 assert all(decision['actual_business']['postflight'].values())
 assert result['status']=='PASS_BOUNDED_FEATURE_SERVICE' and result['failure'] is None and result['cleanup_failure'] is None
 assert guard['status']=='COMPLETED' and guard['child_returncode']==0 and guard['command']==plan['command']
 assert guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease']
 for field,path in [('plan_sha256','plan.json'),('result_sha256','execution/result.json'),('lease_result_sha256','lease/exit.json')]:assert decision['actual_business'][field]==sha(folder/path)
 queries=[json.loads(l) for l in (folder/'lease/nvml-queries.jsonl').read_text().splitlines()]
 assert queries and all(v['status']=='OK' and v['returncode']==0 for v in queries)
 actual=read(execution/'media-usage.json')
 assert actual['results'] and all(v['labels']==['A','B','A'] and v['auxiliaries']==['alignment','vad','speaker'] for k,v in actual['results'].items() if 'chat' not in k)
 assert plan['chat_audio'] and any('chat' in k for k in actual['results'])
 stages.append(dict(name=name,counts=result['budget']['counts'],actual_model_execs=len(result['models']),seconds=result['seconds'],nvml_queries=len(queries),strict_lease_seconds=decision['actual_business']['strict_lease_seconds'],actual_labels={k:v['labels'] for k,v in actual['results'].items() if 'chat' not in k},actual_chat={k:v for k,v in actual['results'].items() if 'chat' in k}))
 decisions[name]=decision
 for directory,prefix in [(folder,name),(folder/'lease',name+'/lease'),(execution,name+'/execution')]:
  for p in directory.iterdir():
   if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.jsonl','.wire','.log'):
    if p.name in ('primary-chat-audio-request.json','fallback-chat-audio-request.json','chat-python-request.json','chat-js-request.json'):omitted[prefix+'/'+p.name]=dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
    else:files[prefix+'/'+p.name]=p
 files[name+'/execution/state/ledger.json']=execution/'state/ledger.json'
for n in ['prepare_package.py','prepare_retained.py','prepare_modern_root.py','prepare_tls.py','run_service_sequence.py','service-sequence-01.json','service-package-01/prepare-review.json','service-package-01/native-build.json','service-package-01/receipt.json','service-package-01/decision.json','retained-01/review.json','modern-retained-01/review.json','modern-retained-01/receipt.json','archive_service.py']:files[n]=W/n
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for pack in [candidate,legacy,modern,tls]:
 for n in ['gateway-policy.json','engine/client-policy.json']:collect(read(Path(pack['package'])/n))
for name,path in files.items():
 raw=path.read_bytes();assert not any(s in raw for s in secrets),name
 assert b'-----BEGIN '+b'PRIVATE KEY-----\n' not in raw,name
assert sum(x['actual_model_execs'] for x in stages)==sum(x['counts']['starts'] for x in stages)==5
assert sum(x['counts']['chats'] for x in stages)==25 and sum(x['counts']['probes'] for x in stages)==1
seconds=sum(x['seconds'] for x in stages);assert seconds<1800
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for name,path in sorted(files.items()):archive.add(path,arcname=name,recursive=False)
accepted=dict(status='ACCEPT_NATIVE_CHAT_AUDIO_SERVICE_COMPOSITION',binary_sha256=binary,candidate=candidate,automatic_fallback=legacy,modern_retained_root=modern,tls_package=tls,stages=stages,counted_spawn_attempts=5,actual_model_starts=5,service_requests=25,service_probes=1,service_seconds=seconds,nvml_queries=sum(x['nvml_queries'] for x in stages),nvml_all_ok=True,cleanup_complete=True,strict_finalizers_all_passed=True,primary_light_evidence='docs/evidence/serve-chat-audio-profiles-20261118/README.md',direct_http_evidence='docs/evidence/serve-chat-audio-http-20261118/README.md',tls_composition=decisions['tls-service-01'],candidate_service_acceptance=decisions['version-service-02'],modern_service_acceptance=decisions['modern-service-01'],candidate_whole_package_gpu_run=True,default_unchanged=True,publication_pending=True,older_engine_fallback=False,full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,archive_sha256=sha(O/'records.tar.gz'),secret_scan_matches=0,omitted_audio_requests=omitted,original_failed_stage=dict(directory=str(W/'version-service-01'),result_sha256=sha(W/'version-service-01/execution/result.json'),starts=2,requests=5,probes=1,seconds=100.85087789781392),cumulative_model_starts=7,cumulative_service_requests=30,cumulative_service_probes=2,actual_recovery_profile=read(W/'version-service-02/execution/profile-continuity.json')['verification'])
for p in [W/'publication-composition.json',O/'acceptance.json']:p.write_text(json.dumps(accepted,indent=2)+'\n')
(O/'README.md').write_text(f'''# Chat音频服务与整包恢复通过（2026-11-18）

4个严格阶段、5次模型启动/25条创建/1次CUDA探针/{seconds:.3f}秒，
{accepted['nvml_queries']}次NVML正常；全部精确argv、自动finalizer及自有进程/端口/锁清理通过。
两种保留控制和候选整包回退后均实际Chat音频回答及A/B/A，验证全部辅助依赖健康、
原始声源、真实全局时间及usage。原生TLS双SDK/JSON/SSE、分块、
客户端上传配额/取消及入口恢复保持核心PID通过；整包故障恢复后
再次分人，已存Chat与profile历史保留。

默认rev296未变，继续可回退发布与主线。自动与手动回退使用同一
已验speaker引擎与保留控制，不能宣称更旧的引擎已有新增能力。
真实重叠质量、非语言声学信息、音频输出/历史/Realtime及全部master继续。
原整包首轮2启动/5请求/1探针/100.851秒失败保留；累计7启动/30请求/2探针，
前三阶段未重跑。本轮实际回退保持primary并完成真实业务；原历史/冷却/预算不变。
冷降级分支的严格观察/扣减检查仅有CPU证据，不冒充本轮实际light
恢复业务；light的独立Chat/全部辅助资格由已过主轻18请求覆盖。
档案私有凭证扫描0匹配，原始音频与TLS私钥未入公开档案。
''')
p=R/'docs/serve-master-goals-v2.json';v=read(p);next(t for t in v['tasks'] if t['id']=='A10')['chat_audio_service_20261118']={k:val for k,val in accepted.items() if k not in ['candidate_service_acceptance','modern_service_acceptance','tls_composition']};p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n',f'''## 正在推进

[Chat音频服务与恢复通过](evidence/serve-chat-audio-service-20261118/README.md)：
4阶段5启动/25创建/1探针/{seconds:.3f}秒；双SDK/TLS、全部保留包及
整包回退后实际A/B/A、原状态/预算保全通过。{accepted['nvml_queries']}次NVML正常，
清理和自动finalize通过；接着可回退发布/主线、真实重叠及全部master。
默认rev296尚未变，旧引擎能力未冒充已验。

''',1))
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);p.write_text(h+f'''

## Chat音频服务与整包恢复通过（2026-11-18）

4阶段5启动/25创建/1探针/{seconds:.3f}秒，TLS双SDK及整包回退后
实际A/B/A、原状态和预算保留通过；{accepted['nvml_queries']}次NVML正常，精确命令/
自动finalizer及自有资源清理。原因：证明交付和恢复链路保有Chat音频与分人
能力。下一步可回退发布/主线、重叠与全部master，默认rev296未变。
[证据](../evidence/serve-chat-audio-service-20261118/README.md)。
'''+b)
print(json.dumps({k:accepted[k] for k in ['status','service_seconds','nvml_queries','actual_model_starts','service_requests']}))

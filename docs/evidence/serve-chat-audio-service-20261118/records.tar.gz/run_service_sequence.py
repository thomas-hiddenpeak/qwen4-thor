"""Execute only frozen exact argv, finalizing each owned stage before the next."""
import json,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
rows=[]
def call(label,command,timeout):
 t=time.monotonic()
 with (D/(label+'.stdout')).open('x') as out,(D/(label+'.stderr')).open('x') as err:
  result=subprocess.run(command,stdout=out,stderr=err,timeout=timeout)
 record=dict(label=label,command=command,returncode=result.returncode,seconds=time.monotonic()-t)
 rows.append(record);(D/'service-sequence-01.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if result.returncode:
  print((D/(label+'.stderr')).read_text()[-3500:],flush=True)
  raise SystemExit(result.returncode)
 return record

def finalize(name):
 call(name+'-finalize',['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'finalize','--plan',str(D/name/'plan.json')],120)
 print((D/name/'decision.json').name+' '+read(D/name/'decision.json')['acceptance'],flush=True)

def run(name):
 out=D/name;plan=read(out/'plan.json')
 command=['/usr/bin/python3','-B',str(R/'tools/evalscope/gpu_exclusive.py'),'--compute-backend','nvml','--inherit-lease','--output',str(out/'lease'),'--',*plan['command']]
 assert Path(plan['command'][3]).is_absolute() and plan['command'][-1]==str(out/'plan.json')
 (out/'lease-command.json').write_text(json.dumps(command,indent=2)+'\n')
 record=call(name+'-launch',command,plan['limits']['seconds']+60)
 (out/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
 result=read(out/'execution/result.json')
 print(json.dumps(dict(stage=name,status=result['status'],seconds=result['seconds'],counts=result['budget']['counts'])),flush=True)
 finalize(name)

run('modern-service-01')
run('retained-service-01')
run('tls-service-01')
command=['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'prepare','--scenario','tool_version','--package',str(D/'service-package-01/bundle'),'--output',str(D/'version-service-01'),'--retained',str(D/'retained-01/bundle'),'--release',str(D/'retained-service-01/service-release.json'),'--decision',str(D/'retained-service-01/decision.json')]
call('version-service-01-prepare',command,120)
run('version-service-01')
print('ALL_FROZEN_SERVICE_STAGES_FINALIZED',flush=True)

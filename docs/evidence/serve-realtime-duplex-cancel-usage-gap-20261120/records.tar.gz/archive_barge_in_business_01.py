from pathlib import Path
import collections,hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;B=W/'barge-in-business-01';O=R/'docs/evidence/serve-realtime-duplex-cancel-usage-gap-20261120';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
plan=read(B/'plan.json');run=read(B/'result.json');assert run['status']=='FAILED';assert all(sha(R/n)==h for n,h in {**plan['sources'],**plan['protected']}.items())
w=read(B/'light-duplex-sessions-observed.json')['barge_in'];s=w['session'];assert s['status']=='PASS'
r=s['responses'][0]['response'];assert r['status']=='cancelled' and r['usage']['output_token_details']=={}
asr=[e for e in s['events'] if e['type']=='conversation.item.input_audio_transcription.completed'];assert len(asr)==1 and asr[0]['transcript']=='甚至出现交易几乎停滞的情况。'
assert w['after']['admitted']-w['before']['admitted']==2
settled=w['after']['settled']-w['before']['settled'];assert settled==r['usage']['total_tokens']+asr[0]['usage']['total_tokens']
assert all(w['after'][k]==0 for k in ['reserved','active','sessions','host_bytes'])
qs=[json.loads(l) for l in (B/'lease/nvml-queries.jsonl').read_text().splitlines()];nvml=dict(collections.Counter(q['status'] for q in qs));assert set(nvml)=={'OK'}
clean=read(B/'cleanup.json');assert clean['remaining']==[] and clean['model_exit']==0 and clean['ports_released']
rows=[];omitted=[];token=read(B/'client-policy.json')['gateway_token'].encode()
paths=[f for f in B.iterdir() if f.is_file() and f.name!='client-policy.json']+[f for f in (B/'lease').iterdir() if f.is_file()]+[W/'barge_in_business_01.py',Path(__file__)]
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for f in paths:
  if token in f.read_bytes():omitted.append(dict(path=str(f.relative_to(W)),sha256=sha(f)));continue
  name=str(f.relative_to(W));tar.add(f,arcname=name,recursive=False);rows.append(dict(path=name,bytes=f.stat().st_size,sha256=sha(f)))
save(O/'index.json',dict(records=rows,omitted=omitted,archive_sha256=sha(O/'records.tar.gz')))
review=dict(status='ACTUAL_BARGE_IN_CANCELLED_USAGE_CATEGORIES_MISSING',original_status=run['status'],counts=run['counts'],seconds=run['seconds'],nvml=nvml,cancelled_usage=r['usage'],asr_usage=asr[0]['usage'],settled_tokens=settled,cleanup_complete=True,default_unchanged=True,master_active=True);save(O/'review.json',review)
(O/'README.md').write_text('''# 实际语音打断成功暴露取消用量分类遗漏

2026-11-20，候选485a38a3。一次轻量模型、一个WSS、两项原生工作。
实际PCM首块后输入录音，speech_started触发同一默认回答cancelled，
原生ASR完整识别中文；没有自动新回答。取消回答617 tokens、ASR76，
693 tokens全部结算，预留/会话归零，严格监控与所属资源清理通过。

但response.done.usage.output_token_details为空，缺少音频/文字分类；
检查器因此失败，原阶段FAILED保留。代码核对发现音频分类只从完成
EOF后的delivery.Usage读取，取消已经计入总量的TTS工作没有传到
分类。不能用总费用正确掩盖明细缺失，也不能从PCM长度猜token数。

接下来传递实际TTS阶段计数，包括取消/异常；不改变推理、采样或
配额扣费。先做直接CPU与构建，再只补该终态的实际语音短验。先前
成功语音/工具和未改变的后端证据复用，恢复/交付及全部master继续。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认');p.write_text(s[:i]+'''
[实际打断的用量明细缺口](evidence/serve-realtime-duplex-cancel-usage-gap-20261120/README.md)：
轻量1模型/1WSS/2工作，真实音频被VAD取消、ASR正确、693 tokens结算
且清理通过。但取消response.done缺音频/文字分类，原阶段FAIL保留。
已定位分类仅依赖成功EOF回执，接着传递实际TTS阶段计量并针对CPU/
短验，不改变推理或扣费，不从波形长度推测token；默认rev376保持。
''' +s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 真实语音打断暴露取消用量分类遗漏

日期：2026-11-20。

做了什么：1模型/1WSS/2工作，首音频块后真实VAD取消，ASR完整正确，
总693 tokens实际结算且资源释放。response.done分类为空，原FAIL
保留；定位生产路径只从成功EOF读取TTS分类，取消已有总计量却丢明细。

为什么：总量正确不等于协议明细完整，不能降低检查或猜波形token。

下一步：传递实际TTS计数覆盖取消/异常，CPU和构建后只补实际取消
终态，复用既有成功业务；继续恢复/交付及全部master。
''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['realtime_progress']['duplex_input_20261120'].update(state='actual_barge_in_pass_cancelled_usage_categories_gap_implementation',barge_in_usage_gap=dict(evidence=str(O.relative_to(R)/'README.md'),result=review));save(p,v)
print(json.dumps(review))

#include <iostream>
#include <iterator>
#include <stdexcept>

#include "q4t/server/chat_prompt.h"
#include "q4t/server/realtime_chat_plan.h"
#include "src/server/object_protocol.h"

using namespace q4t::server;
using namespace q4t::server::object_detail;

std::string Render(const Json& request, const ChatRequestPlan& plan) {
  std::string result, parameter, code;
  std::vector<VisionItem> media;
  auto status = PrepareChatPrompt(
      plan.Request(request), plan.constraints, &result, &media, &parameter,
      &code, nullptr, false, plan.async_tool_call_ids, plan.responses_tool_media,
      plan.HeaderTools(), plan.tool_call_formats, plan.prepared_source_data);
  if (!status) throw std::runtime_error(status.message());
  return result;
}

int main() {
  try {
    const std::string text(std::istreambuf_iterator<char>{std::cin}, {});
    Json inputs;
    if (!q4t::io::ParseJson(text, &inputs, true) || !inputs.IsArray())
      throw std::runtime_error("input shape");
    ChatPlanConfig config;
    config.model = "qwen3.8-flash-next";
    config.structured = true;
    config.max_len = 8192;
    auto result = Array();
    for (const auto& row : inputs.array) {
      auto settings = DefaultRealtimeChatSettings(config, "");
      for (const auto& [name, value] : row.Find("settings")->object)
        Set(&settings, name, value);
      RealtimeChatPlan planned;
      ChatPlanError error;
      auto status = PlanRealtimeChat(settings, *row.Find("response"),
                                      *row.Find("items"), config, &planned,
                                      &error);
      if (!status) throw std::runtime_error(status.message());
      ChatRequestPlan executed;
      config.preparing_file_inputs = true;
      status = PlanChatRequest(planned.generation.generation_request, config,
                               &executed, &error);
      if (!status) throw std::runtime_error(status.message());
      result.array.push_back(Object({
          {"label", *row.Find("label")},
          {"generation_request", planned.generation.generation_request},
          {"measured_prompt", String(Render(planned.generation.generation_request,
                                             planned.generation.chat))},
          {"executed_prompt", String(Render(planned.generation.generation_request,
                                             executed))},
          {"temperature", Number(executed.sampling.temperature)},
          {"top_p", Number(executed.sampling.top_p)},
          {"seed_set", Boolean(executed.sampling.seed.has_value())}}));
    }
    std::cout << OutputJson(result) << '\n';
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}

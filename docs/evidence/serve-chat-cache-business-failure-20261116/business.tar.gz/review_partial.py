import io,json,re,sys,tarfile
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R));W=Path(__file__).resolve().parent;B=W/'business-01'
from tools.serve_protocol import chat_cache_acceptance as a
from tools.serve_service.package import read,save,sha,require
plan=read(B/'plan.json');result=read(B/'result.json');guard=read(B/'lease/exit.json');cleanup=read(B/'cleanup.json')
require(result['status']=='FAILED' and 'prompt_tokens_details' in result['error'] and result['counts']['chats']==5,'unexpected initial failure')
require(guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1,'unexpected environmental verdict')
queries=[json.loads(l) for l in (B/'lease/nvml-queries.jsonl').read_text().splitlines()]
events=[json.loads(l) for l in (B/'lease/events.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and not q['observed_errors'] for q in queries),'NVML rejected')
require(all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events),'GPU competitor')
require(cleanup['model_exit']==0 and not cleanup['remaining'] and cleanup['ports_released'] and cleanup['lease_continuously_held'],'cleanup failed')
require(sha(plan['binary'])==plan['binary_sha256'],'engine changed')
changed=[p for p,h in plan['sources'].items() if sha(R/p)!=h]
require(set(changed)=={'tools/serve_protocol/chat_cache_acceptance.py','tools/serve_protocol/test_chat_cache_acceptance.py'},'unreviewed source change')
for p,h in plan['protected'].items():require(sha(p)==h,'default changed')
values={}
for label in ('write','hit','client_isolated','key_isolated','disabled'):
 row=plan['requests'][label];raw=(B/(label+'.wire')).read_bytes()
 require(read(B/(label+'.http.json'))['status']==200,'HTTP failed')
 value=(a.read_sse if row.get('stream') else a.read_json)(io.BytesIO(raw));a.check_answer(value,label);values[label]=value
log=(B/'model-1.log').read_text();proof=a.check_cache_logs(log,values)
for label,value in values.items():
 terminal=[l for l in log.splitlines() if 'id='+value.id+' ' in l and '[q4t][request]' in l and 'event=end ' in l]
 require(len(terminal)==1 and 'outcome=success' in terminal[0],'missing terminal success')
metrics=read(B/'key_isolated-drain.metrics.json')[-1]
require(metrics['q4t_requests_total']==metrics['q4t_requests_success_total']==4 and metrics['q4t_requests_error_total']==0,'first four metrics')
summary=dict(status='ACCEPT_FIRST_FIVE_CAPTURED_CASES',original_result_status='FAILED',engine_binary_sha256=plan['binary_sha256'],counts=result['counts'],strict_lease_seconds=events[-1]['monotonic']-events[0]['monotonic'],nvml_queries=len(queries),cache_proof=proof,terminal_success_count=5,metrics_observed_through=4,default_unchanged=True,all_original_failure_records_preserved=True,remaining_labels=['default_implicit','target_write','target_hit'],new_gpu_starts=0,explanation='Optional zero-cache prompt_tokens_details is absent in explicit no-marker response; parsed actual response, successful terminal and no restore/write logs verify that case. Last aggregate/per-client metrics were captured through first four only; do not claim a five-request final metrics snapshot.')
save(W/'partial-review.json',summary)
out=R/'docs/evidence/serve-chat-cache-business-failure-20261116';out.mkdir();files=[]
for p in B.rglob('*'):
 rel=p.relative_to(B)
 if not p.is_file() or rel.parts[0].startswith('objects') or p.name=='client-policy.json':continue
 files.append((p,'business-01/'+str(rel)))
for name in ['review_partial.py','original-business-driver.py','partial-review.json']:files.append((W/name,name))
for stem in ['prepare-business-01','gpu-business-01','driver-optional-usage-01']:
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token','gateway_token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in ['build/service/engine/client-policy.json','build/service/gateway-policy.json']:collect(read(R/p))
collect(read(B/'client-policy.json'))
for p,n in files:
 require(not any(x in p.read_bytes() for x in secrets),'private value in '+n)
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),'private key in '+n)
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n)
summary.update(archive_sha256=sha(out/'business.tar.gz'),files=len(files),secret_scan_matches=0)
save(out/'review.json',summary)
(out/'README.md').write_text(f'''# Chat 缓存首次业务驱动中断与实际记录核对

2026-11-16，候选0851dab3在同一严格租约1启动/5生成，
{summary['strict_lease_seconds']:.3f}秒、{len(queries)}项NVML正常，无观察到的竞争。
前四条实际双断点写入、改变suffix的SSE恢复、另一客户端同key及同客户
另一key隔离均通过；2320 token由MTP共享状态实际恢复，答案为43。
第五条显式无断点返回42，原始usage省略可选prompt_tokens_details；
驱动对该可选字段直接索引而中断。原result/guard保持FAILED/COMMAND_FAILED。

两项针对性CPU正负控修正可选零值读取，缺失hit证据仍拒绝；实际前五
条捕获重新核对，成功terminal为5、禁缓存项没有写入/恢复日志。最后
聚合与客户端指标只捕获到前四条，不称第五条有独立最终指标快照。
引擎不变，模型正常退出、端口/锁释放、rev166保持，0重复生成。

下一步仅补未执行的default_implicit/target_write/target_hit：额外最多
1启动/3生成/600秒，累计2启动/8个不同生成任务，不重复前五项；完整
质量/性能矩阵不扩展。保留本次失败与原驱动，不将核对结果篡改为原
驱动PASS；全部master继续。
''')
print(json.dumps({k:summary[k] for k in ['status','strict_lease_seconds','nvml_queries','terminal_success_count','metrics_observed_through']}))

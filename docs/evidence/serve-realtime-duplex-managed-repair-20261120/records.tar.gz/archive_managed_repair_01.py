from pathlib import Path
import fcntl,hashlib,json,subprocess,sys,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_realtime import duplex_managed as d
from tools.serve_responses import encryption_acceptance as encrypted
from tools.serve_service.package import sha,read,require
O=R/'docs/evidence/serve-realtime-duplex-managed-repair-20261120';O.mkdir()
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
B=W/'recovery-retained-01';E=B/'execution';plan=read(B/'plan.json');result=read(E/'result.json');guard=read(B/'lease/exit.json');queries=[json.loads(l) for l in (B/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(result['status']=='FAILED' and result['cleanup_failure'] is None and guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1 and guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] is True,'unexpected original failure')
require(queries and all(v['status']=='OK' and v['returncode']==0 and not v['observed_errors'] for v in queries),'NVML evidence invalid')
stop=read(E/'stop.json');require(stop['state']=='STOPPED' and stop['cleanup_confirmed'] and stop['stop_durable'] and read(E/'launcher-result.json')['guardian_exit_code']==0,'cleanup failed')
proc=encrypted.foreground.base.lifecycle.guard;now=proc.processes();require(not any(now.get(v['pid'],{}).get('start_ticks')==v['start_ticks'] for v in result['models'].values()),'owned model remains')
with proc.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for row in plan['protected']:require(sha(row['path'])==row['sha256'],'default changed')
changed=[]
for name,h in plan['sources'].items():
 if sha(R/name)==h:continue
 rel=str((R/name).relative_to(R));raw=subprocess.check_output(['git','show',plan['source_commit']+':'+rel],cwd=R)
 require(hashlib.sha256(raw).hexdigest()==h,'original executable source not retained: '+name);changed.append(rel)
original=d.check_session(read(E/'primary-duplex.sdk.json'),'complete','ws-loopback',d.journal(E,'primary-duplex'));require(original['model_quality_status']=='FAIL','original model answer changed')
cpu=read(W/'managed-duplex-cpu-02/result.json');require(cpu['status']=='PASS','targeted CPU failed')
review=dict(original_status='FAILED',original_result=result,original_observed=original,original_final_metrics_missing=True,environment=dict(status='PASS',all_queries_ok=True,nvml_queries=len(queries),cleanup_complete=True),original_sources_retained_in_commit=plan['source_commit'],changed_tool_sources=changed,repair_cpu=cpu,scope=read(W/'duplex-recovery-scope-02.json'),model_quality_repaired=False,default_unchanged=True,master_active=True);save(O/'review.json',review)
paths=[p for p in E.iterdir() if p.is_file() and p.name not in ('launcher.log','initialized.json','wrapper.json')]+[B/'plan.json']+[p for p in (B/'lease').iterdir() if p.is_file()]+[p for p in (W/'managed-duplex-cpu-02').iterdir() if p.is_file()]+[W/'duplex-recovery-scope-02.json',W/'run_managed_duplex_cpu_02.py',Path(__file__)]
rows=[]
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for p in paths:
  name=str(p.relative_to(W));tar.add(p,arcname=name,recursive=False);rows.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
save(O/'index.json',dict(records=rows,archive_sha256=sha(O/'records.tar.gz')))
(O/'README.md').write_text('''# 恢复短验的字段检查与失败取证修复

2026-11-20。原保留包1模型/3工作/1WSS/54.042秒整体FAILED；严格
NVML正常，Guardian退出0、STOPPED清理确认，默认和GPU锁已释放。
实际ASR完整中文、响应流终态和波形检索正常，模型给出了无关拒答及
混杂文字，原333可见tokens与原错误回答保留，模型质量仍FAIL。

验收器误将独立转写端点的展开设置用于对话端点；对话session正确
回显用户实际指定字段，不承诺补入language/prompt等空值。修正仅
影响检查器，不修改服务默认。此前异常先于最终metrics保存，因此
不能事后声称原精确结算已验证。驱动现先保存实际最终资源与计量，
再报告校验异常；新增反例防止再次丢失这部分证据。

按用户明确允许把指令不遵循单列模型质量，恢复协议验收持续检查
实际ASR内容、模型输入历史、流终态、计量和核心所有权。原模型
错误不改为PASS；每次业务单独计算并保存model_quality_status。
9项受影响CPU/3.107秒与20来源反例通过，原通过且不受影响项复用。

为补齐丢失的结算证据，仅再执行1模型/3工作/1WSS、最多120秒。
剩余TLS/整包恢复保持360/540秒，累计上限由5模型18工作调整为
6模型21工作7WSS，总GPU时长仍1200秒；原冻结记录保留。无采样
重试、不修改seed/temperature，不以找出正确回答为补验目的。
然后继续实际恢复、可回退交付与全部master，默认rev376 STOPPED保持。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认');p.write_text(s[:i]+'''
[恢复检查器修复](evidence/serve-realtime-duplex-managed-repair-20261120/README.md)：
原保留包1模型/54.042秒，ASR/协议正常、模型无关拒答仍FAIL，字段
检查误用了独立转写的展开默认；原结果与缺少最终metrics均保留。
修正检查与失败后取证，9受影响CPU/20反例通过。按用户授权单列
质量，补1模型/3工作/120秒结算证据后继续TLS/整包恢复；累计6模型/
21工作、仍1200秒，不做采样重试。默认rev376 STOPPED保持。
''' +s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 恢复验收字段与失败取证修复，保留真实模型错答

日期：2026-11-20。

做了什么：原1模型54.042秒FAILED并清理，保留实际ASR、无关拒答和
缺少最终metrics的事实。修正对话设置检查、失败后先留存结算证据；
9CPU/20反例通过。模型质量独立记录FAIL，不修改服务数值或采样。

为什么：用户已允许将指令不遵循单列质量；协议/恢复不能伪造正确
答案，工具错误也不能丢弃原始业务与资源证据。

下一步：补1模型/3工作/120秒结算，仅因工具缺陷补缺项；累计6模型/
21工作仍总1200秒，然后TLS/整包恢复与可回退交付，全部master继续。
''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['realtime_progress']['duplex_input_20261120'].update(state='managed_original_failure_retained_checker_fixed_accounting_repair_pending',managed_repair=dict(evidence=str(O.relative_to(R)/'README.md'),result=review));save(p,v)
print(json.dumps(dict(evidence=str(O),nvml_queries=len(queries),archive_bytes=(O/'records.tar.gz').stat().st_size)))

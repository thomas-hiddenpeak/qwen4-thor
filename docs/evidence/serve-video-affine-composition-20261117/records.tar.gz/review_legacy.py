"""Reconcile only observed relative versus frozen absolute driver arguments.
No plan, guard, response or runtime file is rewritten; all other checks remain.
"""
import copy,json,runpy,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[2];w=Path(__file__).resolve().parent
assert Path.cwd()==root
path=w/'legacy-business-02/plan.json'
plan=json.loads(path.read_text());guard=json.loads((path.parent/'lease/exit.json').read_text())
original=list(guard['command']);expected=plan['command']
assert original[:3]==expected[:3]==['/usr/bin/python3','-I','-B']
assert original[4:6]==expected[4:6]==['run','--plan'] and len(original)==len(expected)==7
assert original[3]=='tools/serve_responses/video_affine_service_acceptance.py'
assert original[6]=='.q4t-work/serve-video-affine-20261117/legacy-business-02/plan.json'
for index in (3,6):assert (root/original[index]).resolve(strict=True)==Path(expected[index]).resolve(strict=True)
record=dict(status='PASS_EXACT_COMMAND_PATH_EQUIVALENCE',original=original,frozen=expected,cwd=str(root),plan_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),guard_sha256=hashlib.sha256((path.parent/'lease/exit.json').read_bytes()).hexdigest(),new_gpu_starts=0,raw_evidence_unchanged=True)
driver=runpy.run_path(str(root/original[3]));g=driver['GLOBALS'];accepted=g['accepted_run']
def review(p,result,actual,queries,events):
 assert actual==guard and p==plan
 checked=copy.deepcopy(actual);checked['command']=list(expected)
 return dict(accepted(p,result,checked,queries,events),command_path_review=record)
g['accepted_run']=review
g['finalize'](path)
(w/'legacy-command-review.json').write_text(json.dumps(record,indent=2)+'\n')

"""Archive real web/profile/retained composition without altering original failures."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-video-affine-composition-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not O.exists()
feature=read(W/'feature-acceptance.json');qualified=read(W/'profiles-01/acceptance.json')
assert feature['status']=='ACCEPT_NATIVE_VIDEO_AFFINE_DETAIL_BUSINESS' and qualified['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
candidate={k:read(W/'package-01/receipt.json')[k] for k in ('package','manifest_sha256')}
legacy=read(W/'retained-01/review.json')['fallback'];modern=read(W/'modern-retained-01/receipt.json')
for name,desc in [('legacy-business-02',legacy),('modern-business-02',modern)]:
 a=read(W/name/'decision.json')
 assert a['acceptance']=='ACCEPT_VIDEO_AFFINE_SERVICE_RETAINED' and a['manifest_sha256']==desc['manifest_sha256'] and a['engine_binary_sha256']==feature['binary_sha256'] and all(a['actual_business']['postflight'].values())
files=[];stages=[]
for name in ['profiles-01','legacy-business-01','legacy-business-02','modern-business-02']:
 d=W/name;managed=name!='profiles-01';e=d/'execution' if managed else d
 result=read(e/'result.json');guard=read(d/'lease/exit.json')
 counts=result['budget']['counts'] if managed else result['counts']
 events=[json.loads(x) for x in (d/'lease/events.jsonl').read_text().splitlines()]
 queries=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()]
 a=[x for x in events if x.get('event')=='lease_acquired'];z=[x for x in events if x.get('event')=='lease_released']
 assert len(a)==len(z)==1 and a[0]['pid']==z[0]['pid']
 assert guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease']
 assert all(x['status']=='OK' and x['returncode']==0 for x in queries)
 expected='COMMAND_FAILED' if name=='legacy-business-01' else 'COMPLETED'
 assert guard['status']==z[0]['status']==expected
 stages.append(dict(name=name,original_status=result['status'],guard_status=guard['status'],counts=counts,strict_lease_seconds=z[0]['monotonic']-a[0]['monotonic'],nvml_queries=len(queries),accepted_separately=False))
 for folder,prefix in [(d,name),(d/'lease',name+'/lease')]+([(e,name+'/execution')] if managed else []):
  for p in folder.iterdir():
   if p.is_file() and not p.is_symlink() and p.name not in ['client-policy.json','gateway-policy.json','object-store-key.json']:
    files.append((prefix+'/'+p.name,p))
 for p in (d/'qualified').glob('*.json'):files.append((name+'/qualified/'+p.name,p))
for n in ['prepare_package.py','prepare_retained.py','prepare_modern_root.py','namespace-preflight.py','run.py','run_managed.py','review_legacy.py','legacy-command-review.json','profile-migration-review.json','archive_composition.py','package-delta-review.json','publication-composition.json','package-01/prepare-review.json','package-01/native-build.json','package-01/receipt.json','package-01/decision.json','retained-01/review.json','modern-retained-01/review.json','modern-retained-01/receipt.json','modern-business-02/plan.json']:
 p=W/n
 if p.exists():files.append((n,p))
for pattern in ['*namespace-cpu-*.*','service-input-cpu-*.*','service-driver-cpu-*.*','package-prepare-*.*','retained-prepare-*.*','modern-prepare-*.*','legacy-business-*.*','modern-business-*.*','profiles-*.json']:
 for p in W.glob(pattern):
  if p.is_file():files.append((p.name,p))
secrets=[]
def collect(x):
 if isinstance(x,dict):
  for key,value in x.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(value,str) and len(value)>=24:secrets.append(value.encode())
   else:collect(value)
 elif isinstance(x,list):
  for item in x:collect(item)
for desc in [candidate,legacy,modern]:
 for n in ['gateway-policy.json','engine/client-policy.json']:collect(read(Path(desc['package'])/n))
collect(read(W/'profiles-01/client-policy.json'))
files=sorted(dict(files).items())
for n,p in files:assert not any(secret in p.read_bytes() for secret in secrets),n
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
starts=sum(x['counts']['starts'] for x in stages);requests=sum(x['counts']['chats'] for x in stages);seconds=sum(x['strict_lease_seconds'] for x in stages)
assert starts==5 and requests==19 and seconds<900
accepted=dict(status='ACCEPT_NATIVE_VIDEO_AFFINE_DETAIL_COMPOSITION',binary_sha256=feature['binary_sha256'],candidate=candidate,automatic_fallback=legacy,modern_retained_root=modern,stages=stages,composition_starts=starts,composition_requests=requests,composition_lease_seconds=seconds,total_starts=starts+feature['cumulative_starts'],total_external_requests=requests+feature['cumulative_requests'],strict_lease_seconds=seconds+feature['cumulative_lease_seconds'],nvml_queries=sum(x['nvml_queries'] for x in stages)+feature['nvml_ok_samples'],nvml_all_ok=True,cleanup_complete=True,feature_evidence='docs/evidence/serve-video-affine-business-20261117/README.md',legacy_original_run_accepted=False,legacy_repaired_run_accepted=True,original_chat_refusal_still_recorded=True,modern_service_acceptance=read(W/'modern-business-02/decision.json'),candidate_control_delta=read(W/'package-delta-review.json')['control'],candidate_whole_package_gpu_run=False,default_unchanged=True,publication_pending=True,older_engine_fallback=False,full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,archive_sha256=sha(O/'records.tar.gz'),secret_scan_matches=0)
(W/'publication-composition.json').write_text(json.dumps(accepted,indent=2)+'\n');(O/'acceptance.json').write_text(json.dumps(accepted,indent=2)+'\n')
(O/'README.md').write_text(f'''# 仿射视频与显式细节发行组合接受

同一e16c8108引擎的真实仿射JSON/SSE和冻结历史证据保持；主轻实际
工具闭环/结构化/embedding/视频通过。旧及现代保留控制包均经原生
入口完成high仿射SSE、私有存储/客户端隔离，奇异请求400后同PID
普通文本42继续。发行组合含原失败5启动19请求，{seconds:.3f}秒严格租约。
含原默认小尺寸失败累计{accepted['total_starts']}启动{accepted['total_external_requests']}请求，
{accepted['strict_lease_seconds']:.3f}秒，{accepted['nvml_queries']}项NVML正常，完整清理。

驱动旧包导入及GET投影的失败和修复记录保留；原含答案Chat题拒答
仍单列。旧02收尾相对/绝对命令路径差异已CPU核对同一脚本/计划，
原plan/guard未改写；修复后两保留GPU完整通过，旧01失败不追认。
控制器/native helper/client源码及字节保持，不重复无关恢复故障；
候选整包按精确同引擎/控制组合接受，不冒称独立旧引擎回退。
默认234保持，继续STOPPED可回退交付和实际合main；原auto小尺寸
质量失败仍单列，不作完整模型质量、性能或长稳结论，全部master继续。
''')
print(json.dumps({k:accepted[k] for k in ['status','total_starts','total_external_requests','strict_lease_seconds','nvml_queries','archive_sha256']}))

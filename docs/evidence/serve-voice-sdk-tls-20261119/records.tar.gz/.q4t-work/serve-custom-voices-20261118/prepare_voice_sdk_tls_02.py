from pathlib import Path
import copy,hashlib,inspect,json,shutil
from tools.native_tts import voice_sdk_acceptance as driver
from tools.native_tts.acceptance import defaults
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-sdk-tls-02';prior=V/'voice-sdk-tls-01'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
original=read(prior/'run/result.json');assert original['status']=='FAILED' and original['counts']['posts']==11
sdk=read(prior/'run/chat.sdk.json');assert sdk['exchanges']==[] and sdk['error']['type']=='TypeError' and 'enable_thinking' in sdk['error']['message']
assert read(prior/'lease/exit.json')['status']=='COMMAND_FAILED'
cleanup=read(prior/'run/cleanup.json');assert not cleanup['remaining'] and cleanup['model_exit']==0
for pid in cleanup['owned']:assert not Path('/proc',pid).exists()
for i in (1,2):
 x=read(prior/f'run/entry-{i}/closed.json');assert x['exit']==0 and x['thread_stopped']
assert read(V/'voice-sdk-cpu-03/result.json')['status']=='PASS'
method=inspect.getsource(driver.Stage.business);a=method.index("        body=direct.chat.request(");method=method[a:]
initial='''    def business(self):
        self.edge=Edge(self);self.core('core-before')
        consent=self.phase['state']['consent'];voice=self.phase['state']['voice']
        raw,_=self.sdk('retained-consent','consent_retrieve',dict(consent_id=consent),control=True)
        require(json.loads(raw)['id']==consent,'persisted SDK consent differs')
        speech=dict(model=direct.BASE,input=direct.TARGETS[0],voice=dict(id=voice),
                    response_format='wav',stream_format='sse')
'''
run=inspect.getsource(driver.Stage.run).replace('PASS_OFFICIAL_VOICE_SDK_NATIVE_TLS_ENTRY_RESTART','PASS_OFFICIAL_VOICE_SDK_TLS_CHAT_STATE_REVOKE_CONTINUATION')
script=V/'voice_sdk_tls_continue_02.py'
script.write_text('''from pathlib import Path
import base64,json,os,shutil,signal,sys,time,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts import voice_sdk_acceptance as driver
from tools.native_tts.voice_sdk_acceptance import direct,Edge,read,save,sha,require
LIMITS=dict(driver.LIMITS,posts=6,ingress_starts=1,seconds=600)
driver.LIMITS=LIMITS
class Stage(driver.Stage):
    def __init__(self,phase):
        super().__init__(phase)
        state=Path(phase['state']['path'])
        actual={str(p.relative_to(state)):sha(p) for p in state.rglob('*') if p.is_file()}
        require(actual==phase['state']['files'],'registered source state changed')
        shutil.copytree(state,self.out/'objects')
        require({str(p.relative_to(self.out/'objects')):sha(p) for p in (self.out/'objects').rglob('*') if p.is_file()}==actual,'state copy differs')
        save(self.out/'input-state.json',phase['state'])
'''+initial+method+'\n'+run+'''
if __name__=='__main__':
    phase=read(Path(sys.argv[1]));Path(phase['http']['output']).mkdir(exist_ok=False)
    with direct.lifecycle.child_subreaper():Stage(phase).run()
''')
plan=copy.deepcopy(read(prior/'plan.json'));plan['format']='q4t-voice-sdk-tls-resume-v1';plan['http']['output']=str(O/'run');plan['bounds']=dict(driver.LIMITS,posts=6,ingress_starts=1,seconds=600)
plan['sources']={n:sha(R/n) for n in plan['sources']};plan['http']['sources']={n:sha(R/n) for n in plan['http']['sources']}
plan['sources'].update({str(p.relative_to(R)):sha(p) for p in (Path(__file__),script,prior/'run/result.json',prior/'run/chat.sdk.json',prior/'lease/exit.json',V/'voice-sdk-cpu-03/result.json')})
state=prior/'run/objects';files={str(p.relative_to(state)):sha(p) for p in state.rglob('*') if p.is_file()};assert 0<len(files)<512 and sum((state/p).stat().st_size for p in files)<16<<20
plan['state']=dict(path=str(state),files=files,consent=read(prior/'run/consent.wire')['id'],voice=read(prior/'run/voice.wire')['id'])
plan['reuse']=dict(prior=str(prior),actual_post_requests=10,counted_attempts=11,registration_speech_and_entry_restart_retained=True,no_fixture_regeneration=True)
plan['http']['acceptance'].update(complete_voice_api_qualification=False,continuation=True,entrypoint_restarts=0)
assert defaults()==plan['http']['defaults'] and shutil.disk_usage(R).free>256<<20
O.mkdir(mode=0o700,exist_ok=False);(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(plan=str(O/'plan.json'),bounds=plan['bounds'],state_files=len(files))))

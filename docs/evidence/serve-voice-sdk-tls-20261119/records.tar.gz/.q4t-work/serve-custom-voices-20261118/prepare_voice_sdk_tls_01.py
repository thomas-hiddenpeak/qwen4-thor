from pathlib import Path
import copy,hashlib,json,shutil,subprocess,time
from tools.native_tts import voice_sdk_acceptance as driver
from tools.native_tts.acceptance import defaults
from tools.serve_recovery import tls_control
from tools.serve_gateway import gateway
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-sdk-tls-01';O.mkdir(mode=0o700,exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
assert read(V/'voice-sdk-cpu-01/result.json')['status']=='PASS' and read(V/'voice-sdk-cpu-02/result.json')['status']=='PASS'
base=copy.deepcopy(read(V/'voice-http-06/plan.json')['http']);base['output']=str(O/'run');base['port']=19188;base['operations_port']=19189
base['sources']={n:sha(R/n) for n in base['sources']};assert defaults()==base['defaults']
production=read(V/'voice-service-candidate-05/chat_protocol_sources.json');assert all(sha(R/n)==h for n,h in production.items())
base['production_sources']=production
clips=read(V/'voice-http-05/plan.json')['clips']
tls=read(R/'.q4t-work/serve-native-tts-20261118/tls-service-01/plan.json')['tls_inputs'];assert all(sha(x['path'])==x['sha256'] for x in tls.values())
ingress=R/'.q4t-work/serve-file-search-20261112/host/q4t-ingress';assert sha(ingress)==read(V/'voice-service-build-02/host-result.json')['binary_sha256']['q4t_ingress']
policy=driver.gateway_fixture(O)['policy'];policy.update(version=5,listen_port=19190,upstream_port=19188,upstream_operations_port=19189,body_bytes=16<<20,file_body_bytes=(10<<20)+65536,per_client_rps=100,burst=100,global_inflight=4,per_client_inflight=1,clients=[dict(id=n,api_key=k) for n,k in driver.KEYS.items()],http=dict(path_prefix='/voice-test'))
tls_config=dict(certificate=tls['certificate']['path'],key=tls['key']['path'],ca='',require_client_certificate=False)
start=time.monotonic();checked=tls_control.check(ingress,gateway.policy(policy),tls_config,O)
(O/'tls-cpu-check.json').write_text(json.dumps(dict(status='PASS',seconds=time.monotonic()-start,receipt=checked,gpu=0),indent=2)+'\n')
sdk=V/'python-sdk-03';files={str(p):sha(p) for p in sdk.rglob('*') if p.is_file() and p.suffix!='.pyc' and '__pycache__' not in p.parts};files[str(sdk/'bin/python')]=sha(sdk/'bin/python')
sources=[R/n for n in ('tools/native_tts/voice_sdk.py','tools/native_tts/voice_sdk_acceptance.py','tools/native_tts/test_voice_sdk.py','tools/native_tts/test_voice_sdk_acceptance.py')]+[Path(__file__),V/'sdk-discovery-01.json',V/'voice-sdk-install-01/packages.json',V/'voice-sdk-cpu-01/result.json',V/'voice-sdk-cpu-02/result.json',V/'voice-service-build-02/host-result.json']
base['acceptance'].update(official_sdk=driver.voice_sdk.VERSION,native_tls=True,entrypoint_restarts=1,guardian_recovery_retested=False)
plan=dict(format='q4t-voice-official-sdk-native-tls-v1',http=base,bounds=driver.LIMITS,edge_port=19190,clips=clips,tls_inputs=tls,ingress=dict(path=str(ingress),sha256=sha(ingress)),sdk=dict(version=driver.voice_sdk.VERSION,python=str(sdk/'bin/python'),files=files),sources={str(p.relative_to(R)):sha(p) for p in sources},scope='one actual model; two native TLS entry processes; actual SDK methods; Guardian parent dispatch is a test adapter only')
assert shutil.disk_usage(R).free>256<<20
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(dict(plan=str(O/'plan.json'),bounds=driver.LIMITS,tls_check=checked,sdk_files=len(files))))

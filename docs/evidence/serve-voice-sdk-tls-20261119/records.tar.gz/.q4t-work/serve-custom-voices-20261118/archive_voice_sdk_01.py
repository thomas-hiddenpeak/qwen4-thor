from pathlib import Path
import fcntl,hashlib,json,shutil,tarfile
from tools.native_tts.acceptance import defaults
from tools.serve_audit import check_inventory as audit
from tools.serve_grammar_reap import acceptance as lifecycle
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=R/'docs/evidence/serve-voice-sdk-tls-20261119'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def save(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=read(V/'voice-sdk-tls-02/plan.json');assert defaults()==p['http']['defaults']
for n,h in p['http']['production_sources'].items():assert sha(R/n)==h,n
for n,h in p['sources'].items():assert sha(R/n)==h,n
for n,h in p['sdk']['files'].items():assert sha(Path(n))==h,n
for n,h in p['state']['files'].items():assert sha(Path(p['state']['path'])/n)==h,n
snapshot=read(V/'voice-sdk-tls-02/run/registered-state.json')
for n,h in snapshot['files'].items():assert sha(V/'voice-sdk-tls-02/run/registered-state'/n)==h,n
leases={}
for name,status in [('voice-sdk-tls-01','COMMAND_FAILED'),('voice-sdk-tls-02','COMPLETED')]:
 d=V/name;ex=read(d/'lease/exit.json');assert ex['status']==status
 qs=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()]
 assert all(q['status']=='OK' for q in qs) and qs[-1]['pids']==[]
 clean=read(d/'run/cleanup.json');assert clean['remaining']==[] and clean['ports_released'] and clean['model_exit']==0 and clean['lease_continuously_held']
 for pid,identity in clean['owned'].items():
  current=lifecycle.guard.processes().get(int(pid));assert current is None or current['start_ticks']!=identity['start_ticks']
 entries=[read(f) for f in sorted((d/'run').glob('entry-*/closed.json'))]
 assert len(entries)==(2 if name.endswith('01') else 1)
 assert all(e['exit']==0 and e['thread_stopped'] and e['error'] is None for e in entries)
 leases[name]=dict(status=status,nvml_queries=len(qs),all_nvml_ok=True,owned_cleanup=True,entry_starts=len(entries))
with lifecycle.guard.common_lock().open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
first=read(V/'voice-sdk-tls-01/run/result.json');last=read(V/'voice-sdk-tls-02/run/result.json')
assert first['status']=='FAILED' and first['counts']['posts']==11
failed=read(V/'voice-sdk-tls-01/run/chat.sdk.json');assert failed['exchanges']==[] and failed['wire_bytes']==0 and 'enable_thinking' in failed['error']['message']
assert last['status']=='PASS_OFFICIAL_VOICE_SDK_TLS_CHAT_STATE_REVOKE_CONTINUATION' and last['counts']['posts']==6
cpus=[read(V/('voice-sdk-cpu-0'+str(i))/'result.json') for i in (1,2,3)];assert all(x['status']=='PASS' for x in cpus) and [x['cases'] for x in cpus]==[8,1,2]
actual=audit.current_surface(R);inv=read(audit.INVENTORY);errors=audit.check(inv,actual);mutations=audit.mutation_checks(inv,actual);assert not errors and mutations==17
O.mkdir(exist_ok=False)
save(O/'audit.json',dict(anchors=len(actual['sources_sha256']),mutations=mutations,errors=errors,source_inventory_unchanged=True,additional_test_clients_bound_by_plan=p['sources']))
result=dict(status='PASS_OFFICIAL_PYTHON_SDK_VOICE_NATIVE_TLS_SCOPED_LIFECYCLE',sdk_version=p['sdk']['version'],engine_sha256=sha(V/'voice-service-candidate-05/q4t'),first_result=first,continuation=last,cpu=cpus,distinct_cpu_cases=10,cpu_executions=11,original_client_failure_preserved=True,actual_posts=16,counted_post_attempts=17,leases=leases,source_and_defaults_unchanged=True,default_replaced=False,guardian_recovery_retested=False,listening='PENDING',full_task_complete=False)
save(O/'result.json',result);save(O/'default-unchanged.json',defaults())
files=set()
for n in ('voice-sdk-install-01','voice-sdk-cpu-01','voice-sdk-cpu-02','voice-sdk-cpu-03','voice-sdk-tls-01','voice-sdk-tls-02','voice-sdk-extension-fix-01'):
 for f in (V/n).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix not in ('.wav','.f32','.pyc') and not f.name.endswith('.tmp'):files.add(f)
for n in ('prepare_voice_sdk_env_01.py','sdk-discovery-01.json','run_voice_sdk_cpu_01.py','run_voice_sdk_cpu_02.py','run_voice_sdk_cpu_03.py','prepare_voice_sdk_tls_01.py','prepare_voice_sdk_tls_02.py','voice_sdk_tls_continue_02.py','archive_voice_sdk_01.py'):files.add(V/n)
for n in ('voice_sdk.py','voice_sdk_acceptance.py','test_voice_sdk.py','test_voice_sdk_acceptance.py'):files.add(R/'tools/native_tts'/n)
files.update([V/'voice-service-candidate-05/chat_protocol_sources.json',V/'voice-service-candidate-05/identity.json'])
assert shutil.disk_usage(R).free>(256<<20)+sum(f.stat().st_size for f in files)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
index={str(f.relative_to(R)):dict(bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(files)}
with tarfile.open(O/'records.tar.gz') as t:
 for member in t.getmembers():assert hashlib.sha256(t.extractfile(member).read()).hexdigest()==index[member.name]['sha256']
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files=index,original_audio_retained_at_same_local_paths=True))
write(O/'README.md','''# 官方Python SDK与原生TLS音色闭环

固定官方openai 3.55.1及依赖，直接使用Voice/Consent/Speech/Chat方法，
SDK仅为测试依赖。原生入口验证证书、API Key及路径前缀；保留原始
multipart/JSON/SSE和SDK解码结果，禁止重试。10项不同CPU用例通过
（11次执行），覆盖真实SDK序列化、错误、流式字节、参数扩展和清理。

首轮1主模型/2入口、11次业务尝试、88.038秒：真实授权与Voice注册、
改名/分页、跨客户、否定授权/异声/配额、入口重启后状态、Speech
及无提示ASR通过。Chat客户端错误使用enable_thinking关键字，未发出
HTTP，原失败保留。修正为SDK extra_body，2项受影响CPU通过。

续验精确复制原注册状态，不重新登记或生成录音；1主模型/1入口、
6 POST、66.215秒。SDK流式Chat实际生成并逐事件核对原wire，独立
ASR完整识别“Please close the window.”，存储Chat音频ID一致。
撤销后Speech和Chat均404、Voice删除成功，核心前后均42。
复用首轮Speech独立ASR“The blue train arrives at noon.”和入口重启证据。
两轮合计17次尝试、16个实际业务POST；控制请求不含在该POST计数内。

各轮持续持有严格GPU租约；83/63次NVML均正常，末次无GPU进程，
模型和入口退出0、自有子树/端口/锁释放确认。轮询不排除小于采样
间隔的外界干扰。未宣称性能收益，默认rev316及714生产源码保持。

入口使用验收进程提供的生产AdmissionSocket协议；此证据覆盖原生
TLS及入口重启，不冒充真实Guardian恢复。继续主/轻profile、受监护
恢复、Base-only已有音色消费资格及保留状态回退。参考音频ICL、
提示词音色、Live及听感/真人身份质量仍需闭合，完整语音资格未宣称。
''')
pth=R/'docs/serve-master-goals-v2.json';g=read(pth);row=g['native_tts_progress']['custom_voice']['service'];row['sdk_tls']=dict(evidence='evidence/serve-voice-sdk-tls-20261119/README.md',python_sdk='3.55.1',qualified=True,entry_restart=True,guardian_recovery=False,original_failure_preserved=True)
row['remaining']=['primary/light profiles and managed recovery','preserved-state compatible rollback','Base-only existing registered voice qualification','reference audio ICL, prompt voices and Live','listening and speaker similarity'];save(pth,g)
text='''[官方SDK与原生TLS音色闭环通过](evidence/serve-voice-sdk-tls-20261119/README.md)：
固定Python SDK 3.55.1，10项不同CPU通过；首轮客户端参数错误原样保留，
修正后复用注册状态，6 POST/66.215秒通过Chat/SSE、独立ASR、历史及
撤销。复用首轮注册、Speech和入口重启；83/63次NVML正常，清理通过。
默认rev316不变，继续主/轻profile、Guardian恢复、Base-only消费和
有状态回退；听感与完整音色质量待验，不将入口驱动当作Guardian恢复。
'''
pth=R/'docs/STATUS.md';s=pth.read_text();start='原生TLS音色业务驱动与官方SDK 3.55.1已接入：'
while start in s:
 a=s.index(start);b=s.index('\n\n',a);s=s[:a]+s[b+2:]
marker='## 正在推进\n\n';assert marker in s;write(pth,s.replace(marker,marker+text+'\n',1))
pth=R/'docs/log/2026-11-19.md';s=pth.read_text();marker='# 2026-11-19 开发日志\n\n';assert marker in s;write(pth,s.replace(marker,marker+'## 2026-11-19 — 官方SDK原生TLS音色闭环与失败续验\n\n'+text+'\n为什么：必须验证标准客户端的真实序列化和实际入口，不能以HTTP直连代替。\n下一步：两profile、受监护恢复及兼容回退；保留听感待验与原失败。\n\n',1))
print(json.dumps(dict(status=result['status'],files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size,anchors=len(actual['sources_sha256']),mutations=mutations)))

from pathlib import Path
import ast,hashlib,json,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-sdk-cpu-02';O.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
names=['tools/native_tts/voice_sdk.py','tools/native_tts/voice_sdk_acceptance.py','tools/native_tts/test_voice_sdk.py','tools/native_tts/test_voice_sdk_acceptance.py']
for n in names:ast.parse((R/n).read_text())
plan=dict(format='q4t-voice-sdk-cpu-v1',seconds=90,cases=1,gpu=0,models=0,sdk_version='3.55.1',source_sha256={n:sha(R/n) for n in names},actual_gpu_followup=dict(starts=1,ingress_starts=2,posts=15,seconds=1200))
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
text='''原生TLS音色业务驱动与官方SDK 3.55.1已接入：直接调用Consent/Voice\n方法，保留multipart/JSON/SSE原wire，强制证书核验与零重试。SDK仅为\n独立测试依赖。8项CPU已通过；补入口清理异常须保持FAILED与模型清理，冻结1项CPU/90秒/0GPU；通过后1主模型、2原生入口\n启动、15业务POST/1200秒，覆盖入口重启后注册音色、内容及撤销。\nGuardian自动恢复仍另验，听感待验与默认rev316保持。\n'''
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 官方音色SDK与原生TLS有界驱动\n\n'+text+'\n为什么：旧SDK缺Voice方法，不能用通用POST冒充兼容证明；\n下一步：CPU负控后实际TLS与SDK闭环，再完成profile和受监护恢复。\n\n')]:
 p=R/n;s=p.read_text();assert m in s;write(p,s.replace(m,m+c,1))
cmd=[str(V/'python-sdk-03/bin/python'),'-B','-m','unittest','-v','tools.native_tts.test_voice_sdk_acceptance.VoiceSdkDriver.test_entry_cleanup_failure_keeps_model_cleanup_and_failed_result'];start=time.monotonic()
r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(O/'tests.log').write_text(r.stdout+r.stderr)
result=dict(status='PASS' if r.returncode==0 and 'Ran 1 test' in r.stderr and 'skipped=' not in r.stderr else 'FAILED',returncode=r.returncode,seconds=time.monotonic()-start,cases=1,models=0,gpu=0,command=cmd)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((r.stdout+r.stderr)[-6500:]);raise SystemExit(0 if result['status']=='PASS' else 1)

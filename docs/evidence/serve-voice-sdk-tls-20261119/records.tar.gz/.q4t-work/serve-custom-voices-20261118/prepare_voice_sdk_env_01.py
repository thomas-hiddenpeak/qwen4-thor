from pathlib import Path
import json,os,shutil,signal,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-sdk-install-01';O.mkdir(exist_ok=False);env=V/'python-sdk-03';assert not env.exists()
subprocess.run(['python3','-m','venv','--without-pip',str(env)],check=True,timeout=30)
cmd=['python3','-m','pip','--python',str(env/'bin/python'),'install','--no-cache-dir','--only-binary=:all:','--disable-pip-version-check','--report',str(O/'packages.json'),str(V/'sdk-wheels-01/openai-3.55.1-py3-none-any.whl')]
start=time.monotonic();minimum=shutil.disk_usage(R).free
with (O/'install.log').open('wb') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  minimum=min(minimum,shutil.disk_usage(R).free)
  if minimum<256<<20 or time.monotonic()-start>180:
   os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);break
  time.sleep(.5)
r=dict(command=cmd,returncode=p.returncode,seconds=time.monotonic()-start,minimum_free_bytes=minimum,scope='private test-client only; no production runtime dependency added')
(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((O/'install.log').read_text()[-2500:]);raise SystemExit(p.returncode)

from pathlib import Path
import base64,json,os,shutil,signal,sys,time,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts import voice_sdk_acceptance as driver
from tools.native_tts.voice_sdk_acceptance import direct,Edge,read,save,sha,require
LIMITS=dict(driver.LIMITS,posts=6,ingress_starts=1,seconds=600)
driver.LIMITS=LIMITS
class Stage(driver.Stage):
    def __init__(self,phase):
        super().__init__(phase)
        state=Path(phase['state']['path'])
        actual={str(p.relative_to(state)):sha(p) for p in state.rglob('*') if p.is_file()}
        require(actual==phase['state']['files'],'registered source state changed')
        shutil.copytree(state,self.out/'objects')
        require({str(p.relative_to(self.out/'objects')):sha(p) for p in (self.out/'objects').rglob('*') if p.is_file()}==actual,'state copy differs')
        save(self.out/'input-state.json',phase['state'])
    def business(self):
        self.edge=Edge(self);self.core('core-before')
        consent=self.phase['state']['consent'];voice=self.phase['state']['voice']
        raw,_=self.sdk('retained-consent','consent_retrieve',dict(consent_id=consent),control=True)
        require(json.loads(raw)['id']==consent,'persisted SDK consent differs')
        speech=dict(model=direct.BASE,input=direct.TARGETS[0],voice=dict(id=voice),
                    response_format='wav',stream_format='sse')
        body=direct.chat.request('Repeat exactly without adding any words: '+direct.TARGETS[1],
                                 'wav',stream=True);body['audio']['voice']=dict(id=voice);body['store']=True
        raw,receipt=self.sdk('chat','chat',body)
        states,usage,events=direct.chat.parse_stream(raw,1);direct.chat.check_usage(usage,1)
        require(direct.normalize(states[0]['transcript'])==direct.normalize(direct.TARGETS[1]),'SDK Chat transcript differs')
        require(len(receipt['result']['events'])==len(events),'SDK omitted stream event')
        for a,b in zip(receipt['result']['events'],events,strict=True):
            require(a['choices']==b['choices'],'SDK changed streamed choices')
        audio=base64.b64decode(states[0]['data'],validate=True);direct.check_wave(audio)
        (self.out/'chat.wav').write_bytes(audio)
        self.transcribe('chat-asr',audio,direct.TARGETS[1])
        completion=events[0]['id']
        raw,_=self.sdk('chat-history','chat_retrieve',dict(completion_id=completion),control=True)
        require(json.loads(raw)['choices'][0]['message']['audio']['id']==states[0]['id'],'SDK history audio differs')
        self.snapshot(consent,voice,completion)
        raw,_=self.sdk('revoke','consent_delete',dict(consent_id=consent),control=True)
        require(json.loads(raw).get('deleted') is True,'SDK revoke failed')
        self.sdk('revoked-speech','speech',speech,status=404)
        body['stream']=False;body.pop('stream_options')
        self.sdk('revoked-chat','chat',body,status=404)
        raw,_=self.sdk('delete-voice','voice_delete',dict(voice_id=voice),control=True)
        require(json.loads(raw).get('deleted') is True,'SDK voice delete failed')
        self.core('core-after');require(self.counts['posts']==LIMITS['posts'],'SDK business checklist incomplete')

    def run(self):
        result=dict(status='FAILED');old=signal.signal(signal.SIGALRM,
            lambda *_:(_ for _ in ()).throw(TimeoutError('SDK stage deadline')))
        signal.alarm(LIMITS['seconds']-40)
        try:
            direct.chat.probe_ports((self.phase['edge_port'],));self.start();self.business()
            result['status']='PASS_OFFICIAL_VOICE_SDK_TLS_CHAT_STATE_REVOKE_CONTINUATION'
        except BaseException:
            result['error']=traceback.format_exc();raise
        finally:
            signal.alarm(0);signal.signal(signal.SIGALRM,old)
            try:
                if self.edge:self.edge.close()
            except BaseException:
                result['status']='FAILED'
                result['entry_cleanup_error']=traceback.format_exc()
                raise
            finally:
                try:
                    self.cleanup();direct.chat.probe_ports((self.phase['edge_port'],))
                    require(direct.defaults()==self.plan['defaults'],'default drift')
                except BaseException:
                    result['status']='FAILED';result['cleanup_error']=traceback.format_exc();raise
                finally:
                    result.update(counts=self.counts,seconds=time.monotonic()-self.started,
                        default_replaced=False,guardian_recovery_retested=False,
                        listening='PENDING',performance='NOT_CLAIMED')
                    save(self.out/'result.json',result)

if __name__=='__main__':
    phase=read(Path(sys.argv[1]));Path(phase['http']['output']).mkdir(exist_ok=False)
    with direct.lifecycle.child_subreaper():Stage(phase).run()

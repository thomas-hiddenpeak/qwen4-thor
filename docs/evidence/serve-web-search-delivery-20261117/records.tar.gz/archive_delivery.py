"""Archive actual reversible web publication and reconcile current documentation."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-01'
O=R/'docs/evidence/serve-web-search-delivery-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');assert v['status']=='PASS_NATIVE_WEB_SEARCH_DELIVERED' and v['publication']['revision']==234
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands']) and v['state']=='STOPPED' and v['new_gpu_starts']==0
c=v['publication']['current'];composition=read(W/'publication-composition.json')
assert c['manifest_sha256']==composition['candidate']['manifest_sha256'] and sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
files=[(p,'delivery-01/'+p.name) for p in D.iterdir() if p.is_file() and not p.is_symlink()]
for pattern in ('delivery-prepare-*.*','delivery-run-*.*','publication-archive-*.*','version-archive-*.*'):
 files.extend((p,p.name) for p in W.glob(pattern) if p.is_file())
for n in ['archive_delivery.py','deliver.py','run_delivery.py','archive_generations.py','archive_version_cycles.py','prepare_package.py','publication-composition.json','package-01/prepare-review.json']:
 files.append((W/n,n))
files=sorted({n:p for p,n in files}.items());secrets=[]
def collect(value):
 if isinstance(value,dict):
  for key,x in value.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(value,list):
  for x in value:collect(x)
for p in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(p))
for n,p in files:assert not any(x in p.read_bytes() for x in secrets),n
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
a=dict(status='ACCEPT_NATIVE_WEB_SEARCH_DELIVERY',revision=234,current=c,commands=len(v['commands']),seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_whole_package_gpu_run=False,composed_change='Exact-engine real web business, primary/light and retained controls plus targeted private-policy and migration CPU; live controller/native helpers unchanged; STOPPED publication and actual root rollback verified',older_engine_fallback=False,prior_rev224_preserved=True,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生网页搜索默认交付 rev234

实际包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`；引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU，outer保持enabled且累计启动0次。

Chat回答前搜索、Responses搜索/读取/查找、实际来源/引用、离线索引
和历史续答可用；私有搜索策略显式配置，默认不新增联网依赖。真实
模型和同PID故障隔离见[发行组合](../serve-web-search-composition-20261117/README.md)。
含原失败累计8启动25请求361.781秒，343项NVML正常、完整清理。
旧保留包后处理失败和独立CPU业务接受单列，未追认原整轮PASS。

core/client/outer预算字节保持；profile只增加已验网页合同，原历史、
pending、selected、deadline和周期保持。实际回退恢复各根原周期，
只递增revision。私有网络策略不能被自动回退改变。现代人工保留根
`{a['manual_root']}`与自动旧控制payload
`{a['automatic_payload']}`均使用当前引擎，未声称独立旧引擎回退。

首次退休归档因本阶段目录group-writable被拒绝，收紧本任务目录为
0700后通过；原失败保留，没有放松生产检查。退休generation及登记
各两份可恢复归档，0删除，原224包/长稳入口保留。继续当前交接、
实际合main及全部master；更广搜索数据源和其余协议/模型任务仍需实现。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev234；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；原生outer/周期及网页能力完整，前驱224另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退'}
for label,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(label)+r' \| .* \|$',lambda _:f'| {label} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev234原生网页交付](evidence/serve-web-search-delivery-20261117/README.md)
完成19项STOPPED发布、实际整根回退与再前进，{v['seconds']:.3f}秒、0新增
GPU。原预算和周期保持；搜索策略显式启用，原生helper/live控制保持。
真实网页、主轻及保留组合已验，原失败和独立接受分列；原224包及
长稳计划保留。继续当前day交接、实际合main与全部33项剩余任务，
不把有限网站索引等同全网提供方完备，也不把本阶段当总目标完成。

'''
s=s.replace('[rev224 Stop组合交付]',intro+'前驱[rev224 Stop组合交付]',1);s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro,1);p.write_text(s)
p=R/'docs/log/2026-11-17.md';head,rest=p.read_text().split('\n',1);p.write_text(head+f'''

## rev234原生网页可回退默认交付

- 日期：2026-11-17。19项STOPPED升级/整根回退/再前进通过，
  {v['seconds']:.3f}秒、0新增GPU。搜索实际业务及主轻/保留组合已验；
  core/client/outer字节和各根原周期保持，profile仅增加网页合同。
- 为什么：新能力必须进入实际可用发行并保留回退；缺配置搜索
  请求局部失败不能拖核心，私有网络策略也不能被自动回退放宽。
- 首次退休归档因任务目录775被拒绝，收紧为700后通过，原失败
  保留；2代副本/2份登记可恢复归档，未删除旧包或原长稳入口。
- 下一步：刷新day交接、完成实际合main；更广搜索、音频/媒体后端、
  SDK及冷启动/资源/宿主全部剩余任务继续，总目标保持active。
'''+rest)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 if 'web_search_20261117' in task:task['web_search_20261117'].update(state='native_configured_site_delivered_main_pending',revision=234,manifest_sha256=c['manifest_sha256'],default_unchanged=False,service_delivery_pending=False,delivery_evidence='evidence/serve-web-search-delivery-20261117/README.md',whole_task_complete=False)
 if task['id']=='A01':task['remaining_required']=['Chat frozen-reference audio/modalities and actual backend execution','Actual main integration of native web field delivery','Remaining default/null, nested message and response projection parity']
 if task['id']=='A11':task['remaining_required']=['Native web rev234 actual main integration and required broader web-provider coverage','Actual configured cloud account permission/pagination/content acceptance','Remaining builtin/tool VM file/video and typed-output combinations']
 if task['id']=='Q02':
  task['state']='latest_release_delivered_main_pending_remaining_tasks_active';task['native_web_delivery_20261117']=a|dict(evidence='evidence/serve-web-search-delivery-20261117/README.md');task['remaining_required']=['Native web rev234 final-head checks and actual main merge','Delivery of every remaining implementation']
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev234 or then-current default; do not stop camera/jtop without pending maintenance handoff.'
j['next']=j['next_task']='Freeze rev234 native day handoff and complete actual native-web PR checks/main merge. Continue all remaining protocol/audio/media/backend/SDK and cold/resource/host tasks; no stage is the total goal endpoint.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev234原生网页交付](evidence/serve-web-search-delivery-20261117/README.md)：可选搜索策略、真实业务与故障隔离、预算保持及实际整根回退。\n')
p=R/'README.md';s=p.read_text();s=s.replace('当前工作分支正在验收网页搜索，尚未替换默认发行。Chat通过','默认rev234已交付原生网页搜索，实际主线合并状态见[STATUS](docs/STATUS.md)。Chat通过');s=s.replace('数据源与完整交付仍按[网页搜索计划]','数据源仍按[网页搜索计划]');p.write_text(s)
p=R/'docs/SERVE_WEB_SEARCH_2026-11-17.md';p.write_text(p.read_text()+f'''
## 实际默认交付

rev234完成19项STOPPED升级、整根回退和再前进，{v['seconds']:.3f}秒、
0新增GPU；预算/周期保持，私有搜索配置可选。原失败不追认，
原224及长稳入口保留。见[交付记录](evidence/serve-web-search-delivery-20261117/README.md)。
继续day交接、实际合main及全部master任务。
''')
p=R/'tools/serve_audit/inventory.json';j=read(p)
j['fields']['web_search_options']=dict(semantics='可选原生网页检索；Chat回答前检索，Responses按标准工具搜索/读取/查找并输出来源与实际引用。',boundary='rev234已实际交付配置网站抓取与按客户端隔离的持久索引、离线/历史及JSON/SSE。搜索策略显式启用，无配置503只影响该请求，健康核心同PID继续。更广搜索提供方仍为A11任务，不冒称全网覆盖。',evidence=['src/server/chat_web_search.cpp','src/server/web_execution.cpp','docs/evidence/serve-web-search-business-20261117/README.md','docs/evidence/serve-web-search-composition-20261117/README.md','docs/evidence/serve-web-search-delivery-20261117/README.md'])
j['native_web_search_20261117']=dict(state='delivered_main_pending',revision=234,manifest_sha256=c['manifest_sha256'],whole_task_complete=False,evidence='docs/evidence/serve-web-search-delivery-20261117/README.md')
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(revision=234,files=len(files),seconds=v['seconds'],secret_scan_matches=0)))

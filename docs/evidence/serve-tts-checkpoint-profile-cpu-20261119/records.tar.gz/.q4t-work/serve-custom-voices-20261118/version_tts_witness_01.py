from pathlib import Path
R=Path.cwd()
def edit(name,changes):
 p=R/name;s=p.read_text()
 for old,new in changes:
  assert s.count(old)==1,(name,old[:90],s.count(old));s=s.replace(old,new,1)
 q=p.with_name(p.name+'.edit');q.write_text(s);q.replace(p)
edit('tools/serve_recovery/profile_evidence.py',[
("VOICE_FORMAT = 'q4t-profile-business-v9'","VOICE_FORMAT = 'q4t-profile-business-v9'\nTTS_CHECKPOINT_FORMAT = 'q4t-profile-business-v10'\nVOICE_CHECKPOINT_FORMAT = 'q4t-profile-business-v11'\nTTS_CHECKPOINT_SAMPLING = 'qwen3-tts-checkpoint-seed0-v1'"),
("\n\ndef tts_requests():",'''\n# Independently recognized whole HTTP audio, fixed requests/seed; the original
# greedy v8/v9 witnesses above are immutable. See the 2026-11-19 checkpoint
# witness evidence, including its preserved driver failure and content-only run.
TTS_CHECKPOINT_AUDIO = dict(
    speech=(58368, 'ba9ca74cd842909ce3422d42681bcdfacc3d7d09e1247218981ce683f226d9c4'),
    chat=(111404, '2f2d4f92ccd99c0b55e2aeb18a30fce82b74d1d434c540038c931d1e080246b9'))


def tts_sampling(value):
    """Missing marks historical greedy evidence; explicit unknowns fail closed."""
    ledger.require(type(value) is dict, 'invalid TTS sampling witness')
    if 'sampling_profile' not in value:
        return None
    ledger.require(value['sampling_profile'] == TTS_CHECKPOINT_SAMPLING,
                   'unknown TTS sampling witness')
    return value['sampling_profile']


def tts_requests():'''),
("def tts_audio(value, kind):","def tts_audio(value, kind, *, sampling_profile=None):"),
("    size, digest = TTS_AUDIO[kind]","    ledger.require(sampling_profile in (None, TTS_CHECKPOINT_SAMPLING),\n                   'unknown TTS audio sampling witness')\n    accepted = TTS_AUDIO if sampling_profile is None else TTS_CHECKPOINT_AUDIO\n    size, digest = accepted[kind]"),
("    ledger.keys(value, ('requests', 'speech_base64', 'chat_response', 'health', 'limits'))","    sampling = tts_sampling(value)\n    ledger.keys(value, ('requests', 'speech_base64', 'chat_response', 'health', 'limits') +\n                (('sampling_profile',) if sampling is not None else ()))"),
("    tts_audio(value['speech_base64'], 'speech')","    tts_audio(value['speech_base64'], 'speech', sampling_profile=sampling)"),
("    tts_audio(audio.get('data'), 'chat')","    tts_audio(audio.get('data'), 'chat', sampling_profile=sampling)"),
("def format_for(profile, identity=None, capabilities=None):\n    if (identity or {}).get('native_tts_base') is not None:\n        return VOICE_FORMAT\n    if (identity or {}).get('native_tts') is not None:\n        return TTS_FORMAT",'''def format_for(profile, identity=None, capabilities=None, business_value=None):
    checkpoint = ((identity or {}).get('native_tts') is not None and
        tts_sampling((business_value or {}).get('tts', {})) is not None)
    if (identity or {}).get('native_tts_base') is not None:
        return VOICE_CHECKPOINT_FORMAT if checkpoint else VOICE_FORMAT
    if (identity or {}).get('native_tts') is not None:
        return TTS_CHECKPOINT_FORMAT if checkpoint else TTS_FORMAT'''),
("                                                registry['identity'], value['capabilities']) and","                                                registry['identity'], value['capabilities'],\n                                                value['business']) and")])
edit('tools/serve_recovery/profile_acceptance.py',[
("def check_tts_family_reload(before, after, previous, encoded, identity):","def check_tts_family_reload(before, after, previous, encoded, identity,\n                            *, sampling_profile=None):"),
("    profile_evidence.tts_audio(encoded, 'speech')","    profile_evidence.tts_audio(encoded, 'speech', sampling_profile=sampling_profile)"),
("    selected_path = getattr(args, 'capacity_config', None)","    checkpoint = getattr(args, 'tts_checkpoint_sampling', False)\n    require(type(checkpoint) is bool and (not checkpoint or tts is not None),\n            'checkpoint witness requires configured builtin TTS')\n    selected_path = getattr(args, 'capacity_config', None)"),
("    if chat_audio: plan['chat_audio'] = True","    if chat_audio: plan['chat_audio'] = True\n    if checkpoint: plan['tts_sampling_profile'] = profile_evidence.TTS_CHECKPOINT_SAMPLING"),
("        selected = plan['profiles']['primary']","        if 'tts_sampling_profile' in plan:\n            profile_evidence.tts_sampling(dict(sampling_profile=plan['tts_sampling_profile']))\n            require(plan['base']['settings'].get('native_tts') is not None,\n                    'sampling witness without builtin TTS')\n        selected = plan['profiles']['primary']"),
("        return dict(requests=rows, speech_base64=base64.b64encode(raw).decode(),\n            chat_response=chat, health=config['native_tts_health'],\n            limits=config['native_tts_limits'])","        result = dict(requests=rows, speech_base64=base64.b64encode(raw).decode(),\n            chat_response=chat, health=config['native_tts_health'],\n            limits=config['native_tts_limits'])\n        if 'tts_sampling_profile' in self.plan:\n            result['sampling_profile'] = self.plan['tts_sampling_profile']\n        return result"),
("                               self.plan['identity'])","                               self.plan['identity'],\n                               sampling_profile=profile_evidence.tts_sampling(previous))"),
("        value = dict(format=profile_evidence.format_for(plan['profiles'][name],\n            plan['identity'], capability), profile=name,","        business_value = read(out/(name+'-business.json'))\n        value = dict(format=profile_evidence.format_for(plan['profiles'][name],\n            plan['identity'], capability, business_value), profile=name,"),
("            business=read(out/(name+'-business.json')), environment=env)","            business=business_value, environment=env)"),
("    p.add_argument('--tts-config', type=Path,","    p.add_argument('--tts-checkpoint-sampling', action='store_true',\n                   help='use versioned complete checkpoint-sampling audio witnesses')\n    p.add_argument('--tts-config', type=Path,")])
edit('tools/native_tts/managed_service.py',[
("        evidence.tts_business(witness, identity)","        if 'tts_sampling_profile' in plan:\n            witness['sampling_profile'] = plan['tts_sampling_profile']\n        evidence.tts_business(witness, identity)"),
("            actual_chat_audio_sha256=evidence.TTS_AUDIO['chat'][1],","            actual_chat_audio_sha256=hashlib.sha256(base64.b64decode(\n                chat['choices'][0]['message']['audio']['data'], validate=True)).hexdigest(),")])
edit('tools/native_asr/service_acceptance.py',[
("        plan['native_tts'] = native_tts\n        backend", "        plan['native_tts'] = native_tts\n        sampling = profile_evidence.tts_sampling(qualified['business']['tts'])\n        other = engine.read(pack/'profile-light.json')\n        require(profile_evidence.tts_sampling(other['business']['tts']) == sampling,\n                'managed primary/light sampling witnesses differ')\n        if sampling is not None: plan['tts_sampling_profile'] = sampling\n        backend")])
print('updated four reviewed qualification helpers; production unchanged')

from pathlib import Path
import json,tarfile
from tools.native_tts.voice_service_acceptance import read,save,sha,defaults
from tools.serve_audit import check_inventory as audit
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=R/'docs/evidence/serve-tts-checkpoint-profile-cpu-20261119'
def write(p,s):
 q=p.with_suffix(p.suffix+'.edit');q.write_text(s);q.replace(p)
cpu=read(V/'tts-checkpoint-cpu-01/result.json');assert cpu['status']=='PASS' and cpu['cases']==22
sources=read(V/'tts-checkpoint-cpu-01/sources.json');assert all(sha(R/n)==h for n,h in sources.items())
a=audit.current_surface(R);inv=read(audit.INVENTORY);changed={n for n,h in a['sources_sha256'].items() if inv['sources_sha256'].get(n)!=h}
assert changed=={'tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_acceptance.py'},changed
for n in changed:inv['sources_sha256'][n]=a['sources_sha256'][n]
write(audit.INVENTORY,json.dumps(inv,ensure_ascii=False,indent=2)+'\n');errors=audit.check(inv,a);mutations=audit.mutation_checks(inv,a);assert not errors and mutations==17
O.mkdir();save(O/'audit.json',dict(anchors=len(a['sources_sha256']),reviewed=sorted(changed),mutations=mutations,errors=errors,other_reviewed_sources=sources))
assert defaults()==read(V/'tts-checkpoint-content-02/plan.json')['defaults']
save(O/'result.json',dict(status='PASS_VERSIONED_TTS_COMPLETE_PROFILE_WITNESSES_CPU',cpu=cpu,sources=sources,old_witness_formats_preserved=['v8','v9'],new_witness_formats=['v10','v11'],real_witness='evidence/serve-tts-checkpoint-witness-20261119/README.md',actual_new_profiles='PENDING',default_replaced=False,gpu_actions=0))
files=[V/'version_tts_witness_01.py',V/'tts-checkpoint-validator-plan-01.json',V/'run_tts_checkpoint_cpu_01.py',V/'archive_tts_checkpoint_cpu_01.py']+[R/n for n in sources]+[p for p in (V/'tts-checkpoint-cpu-01').rglob('*') if p.is_file()]
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}))
(O/'README.md').write_text('''# 内置采样的版本化配置与恢复见证

旧v8/v9完整音频校验保持。新v10/v11要求显式checkpoint-seed0标记，
完整字节必须对应独立内容通过的新见证；未知/空标记、删标记、旧新
音频混用、静音、截断、错误用量或健康状态均拒绝。版本由实际业务
记录选择，并受原配置、引擎和资格记录SHA绑定，不能重签旧记录。

主/轻驱动通过显式--tts-checkpoint-sampling冻结选择；家族卸载/重载
同样核对新完整字节。受监护验收从已核验两profile读取一致标记，
每次恢复阶段单独核对原wire、使用量和健康，不复用另一个阶段输出。

22项针对CPU全部通过，进程10.926秒、0GPU；包含6项新合同、13项
直接旧合同及3项注册/恢复反例。940来源锚点与17遗漏负控通过。
生产C05不变、默认rev316未替换，真实两profile及受监护恢复继续。
[新完整内容证据](../serve-tts-checkpoint-witness-20261119/README.md)
保留原加载预算失败；听感、完整音色质量和长稳未由此声明通过。
''')
p=R/'docs/serve-master-goals-v2.json';g=read(p);g['native_tts_progress']['custom_voice']['service']['builtin_sampling_profile']=dict(profile='qwen3-tts-checkpoint-seed0-v1',witness='evidence/serve-tts-checkpoint-witness-20261119/README.md',validator='evidence/serve-tts-checkpoint-profile-cpu-20261119/README.md',cpu_cases=22,legacy_preserved=True,actual_profiles_pending=True);write(p,json.dumps(g,ensure_ascii=False,indent=2)+'\n')
text='''[内置采样版本化见证22项CPU通过](evidence/serve-tts-checkpoint-profile-cpu-20261119/README.md)：
10.926秒/0GPU；旧v8/v9保留，新v10/v11严格绑定新完整音频、采样标记、
实际用量和健康。原固定两段音频独立识别通过，加载预算失败保留。
940锚点/17负控，C05与默认rev316保持，继续两profile及受监护恢复。
'''
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 新旧采样见证分版本，22项CPU通过\n\n'+text+'\n为什么：恢复后完整音频与旧包身份都需核验；下一步：两profile真实业务。\n\n')]:
 p=R/n;s=p.read_text();write(p,s.replace(m,m+c,1))
print(json.dumps(dict(status='PASS',cases=22,anchors=len(a['sources_sha256']),mutations=mutations)))

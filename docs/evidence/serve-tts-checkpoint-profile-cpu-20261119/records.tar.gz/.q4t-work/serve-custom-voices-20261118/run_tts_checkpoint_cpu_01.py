from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'tts-checkpoint-cpu-01'
p=json.loads((V/'tts-checkpoint-validator-plan-01.json').read_text());assert p['count']==len(p['cases'])==22
O.mkdir();assert shutil.disk_usage(R).free>=256<<20
names=['tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_acceptance.py','tools/native_tts/managed_service.py','tools/native_asr/service_acceptance.py','tools/serve_recovery/test_tts_checkpoint_profiles.py']
(O/'sources.json').write_text(json.dumps({n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in names},indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',Q4T_TEST_OUTPUT_DIR=str(O/'fixtures'))
cmd=['python3','-B','-m','unittest','-v',*p['cases']];start=time.monotonic()
with (O/'tests.log').open('xb') as log:
 r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=p['seconds'])
result=dict(status='PASS' if r.returncode==0 else 'FAIL',returncode=r.returncode,cases=p['count'],seconds=time.monotonic()-start,models=0,gpu=0,command=cmd)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='command'}));raise SystemExit(r.returncode)

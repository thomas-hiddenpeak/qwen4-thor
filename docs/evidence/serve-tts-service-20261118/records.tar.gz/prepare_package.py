"""Seal accepted input/TTS engine; prepare exact native recovery payload pending real runs."""
import copy,hashlib,os,runpy,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;O=W/'service-package-01';P=W/'managed-profiles-04';C=W/'alternating-candidate-01';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';OLD=(R/'build/service').resolve(strict=True)
helpers=runpy.run_path(str(R/'.q4t-work/serve-embeddings-20261111/deliver.py'))
CONTROL={'tools/serve_recovery/'+n+'.py' for n in ['bundle','deployment','profile_bundle','profile_contract','profile_controller','profile_evidence','profile_migration','service']}|{'tools/serve_service/package.py','tools/serve_service/service.py'}
NATIVE={'CMakeLists.txt','include/q4t/trace/sha256.h','src/service/ingress_main.cpp','src/trace/sha256.cpp','tests/host/CMakeLists.txt'}
DIRECT={'cmake/'+n for n in ['ChatProtocolIdentity.cmake','HostTestSources.cmake','ModelAssetTests.cmake']}|{'include/q4t/'+n for n in ['audio/separator_tracks.h','runtime/memory_budget.h','server/asr_service.h','server/auxiliary_resources.h','server/chat_server.h','server/model_assets.h','server/tts_assets.h','server/tts_service.h']}|{'src/'+n for n in ['audio/separator_tracks.cpp','runtime/memory_budget.cpp','server/aligner_service.cpp','server/asr_service.cpp','server/chat_aligner_backend.cpp','server/chat_aligner_execution.cpp','server/chat_asr_backend.cpp','server/chat_asr_execution.cpp','server/chat_capabilities.cpp','server/chat_embedding_backend.cpp','server/chat_separator_backend.cpp','server/chat_separator_execution.cpp','server/chat_server.cpp','server/chat_speaker_backend.cpp','server/chat_speaker_execution.cpp','server/chat_tts_backend.cpp','server/chat_tts_execution.cpp','server/model_asset_io.h','server/model_assets.cpp','server/separator_service.cpp','server/speaker_service.cpp','server/tts_service.cpp']}
def cp(a,b):
 b.parent.mkdir(mode=0o700,parents=True,exist_ok=True);shutil.copyfile(a,b)
def main():
 os.umask(0o077);p.require(not O.exists(),'preserve previous candidate');p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'commit reviewed sources first')
 protected={n:p.sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
 original=bundle.verify(OLD,p.sha(OLD/'manifest.json'));oldmeta=p.read(OLD/'engine/q4t.release.json');plan=p.read(P/'plan.json');qualification=p.read(P/'acceptance.json')
 speech=p.read(R/'docs/evidence/serve-speech-http-20261118/index.json')['summary'];chat=p.read(R/'docs/evidence/serve-chat-audio-output-http-20261118/index.json')['summary']
 p.require(speech['status']=='PASS_SPEECH_HTTP_SDK_CONTENT' and chat['status']=='PASS_CHAT_AUDIO_BUSINESS_CONTENT','direct speech/content evidence absent')
 p.require(qualification['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and qualification['environment']['cleanup_complete'],'complete actual profile qualification absent')
 runtime=helpers['source_hashes']();compiled=p.read(C/'generated/q4t/server/chat_protocol_sources.json');runtime.update(compiled)
 p.require(all(p.sha(R/n)==h and plan['sources'].get(n,compiled.get(n))==h for n,h in runtime.items()),'qualified runtime source drift')
 p.require(p.sha(C/'q4t')==plan['binary_sha256'],'qualified candidate binary drift')
 previous=p.read(oldmeta['tested_source_manifest']);delta={n for n,h in runtime.items() if previous.get(n)!=h}
 directplan=p.read(W/'chat-http-06/plan.json');directsources=directplan['sources'];notice='third_party/quickjs/SOURCE.json';directsources[notice]=hashlib.sha256(subprocess.check_output(['git','show',directplan['source_commit']+':'+notice],cwd=R)).hexdigest()
 directdelta={n for n,h in runtime.items() if directsources.get(n)!=h};p.require(directdelta==DIRECT,'unreviewed change since direct Chat audio qualification')
 control={n for n in bundle.SOURCES if p.sha(R/n)!=p.sha(OLD/'source'/n)};p.require(control==CONTROL,'unreviewed control delta')
 nativeold=p.read(OLD/'native-build.json');nativedelta={n for n,h in nativeold['source_files'].items() if p.sha(R/n)!=h};p.require(nativedelta==NATIVE,'unreviewed native helper delta')
 built=p.read(W/'native-build-02/result-02.json');p.require(built['status']=='PASS' and not built['warnings'],'current native helper build missing')
 native=dict(version=1,source_repository=str(R),source_files={n:p.sha(R/n) for n in sorted(bundle.NATIVE_SOURCES)})
 for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),('ingress','q4t-ingress'),('device_control','q4t-device-control')]:
  p.require(p.sha(B/name)==built['binaries'][name],'native helper identity changed');native[field+'_sha256']=built['binaries'][name]
 O.mkdir(mode=0o700);engine=O/'engine'
 for n in ['q4t','CMakeCache.txt']:cp(C/n,engine/n)
 (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
 protocol=hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest();caps=p.read(P/'primary-capabilities.json');config=p.read(P/'primary-config.json')
 p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,'actual protocol declaration differs')
 scope='Direct Speech six formats/8 content checks and Chat output/history/usage/tool/SDK evidence retained by exact unchanged numerical and projection code. The 33 reviewed differences add direct auxiliary asset I/O, owned serialized family eviction/reload and its RAM accounting, metadata declaration and alternating-source routing. Targeted CPU contracts plus exact current primary/light26 requests verify whole audio, real usage, full input composition and bidirectional reload. Native TLS/recovery packaging remains pending; 4x content, voice coverage and all master tasks remain open.'
 decision=dict(status='PASS_NATIVE_TTS_INPUT_ENGINE_PROFILE_BUSINESS',acceptance='ACCEPT_NATIVE_TTS_INPUT_ENGINE_PROFILE_BUSINESS',binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,source_commit=plan['source_commit'],actual_primary_light=qualification,direct_speech=speech,direct_chat_audio=chat,direct_engine_delta=sorted(directdelta),direct_reuse_scope=scope,source_delta=sorted(delta),control_delta=sorted(control),native_delta=sorted(nativedelta),targeted_cpu=['docs/evidence/serve-auxiliary-capacity-cpu-20261118/README.md','docs/evidence/serve-overlap-alternating-cpu-20261118/README.md','docs/evidence/serve-tts-managed-service-cpu-20261118/README.md'],full_model_quality=False,performance_acceptance=False,version_composition_pending=True,default_changed=False,remaining_master_tasks_open=True)
 metadata=copy.deepcopy(oldmeta);metadata.update(version='serve-native-tts-input-20261118',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],acceptance=decision['acceptance'],acceptance_decision=str(O/'decision.json'),build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),tested_source_manifest=str(engine/'runtime-source.json'),tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),previous_release=str(OLD/'engine/q4t.release.json'),inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),sha256=p.sha(OLD/'engine/q4t.release.json')),source_note=scope)
 metadata['native_tts_input_engine_acceptance']=decision
 declarations=engine/'declarations';declarations.mkdir(mode=0o700);p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
 metadata['chat_protocol'].update(caps,protocol_sha256=protocol,declaration_evidence='Actual Speech/Chat full audio, input and paired asset residency with primary/light document-tool/media/embedding; native managed TLS and recovery pending.')
 for name,stem in helpers['SCHEMAS'].items():
  source=R/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'));target=declarations/'schemas'/(name+'.json');cp(source,target);metadata['chat_protocol'][name+'_schema']=str(target);metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
 metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,directory=str(declarations),binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,files={n:p.sha(declarations/n) for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
 for source in (R/'third_party/licenses').rglob('*'):
  if source.is_file():cp(source,engine/'licenses'/source.relative_to(R/'third_party/licenses'))
 metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output');metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
 for name,record in metadata['file_input_system_dependencies'].items():
  source=Path(record['artifact']);p.require(p.sha(source)==record['sha256'],'system notice drift');target=engine/'licenses/system'/name;cp(source,target);record['artifact']=str(target)
 clients=metadata['client_artifacts'];p.require(not {n for n,h in clients['files'].items() if p.sha(R/n)!=h},'unreviewed client change')
 for n in clients['files']:cp(R/n,O/'clients'/n)
 clients['directory']=str(O/'clients');p.save(O/'decision.json',decision);metadata['acceptance_decision_sha256']=p.sha(O/'decision.json');p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True);p.save(O/'native-build.json',native)
 kwargs={key:OLD/'engine'/n for key,n in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json'),('web_policy','web-policy.json')] if (OLD/'engine'/n).is_file()}
 settings=copy.deepcopy(plan['base']['settings']);policy=p.read(OLD/'engine/client-policy.json');prior=copy.deepcopy(policy)
 for client in policy['clients']:
  if client['id']=='alpha':client['max_output_tokens']=max(client['max_output_tokens'],settings['profile']['max_tokens']+settings['native_tts']['limits']['max_frames']*16+1)
 p.save(O/'clients.json',policy)
 receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',plan['model'],B/'q4t-guardian',B/'q4t-cuda-probe',None,OLD/'gateway-policy.json',O/'clients.json',O/'bundle',native_receipt=O/'native-build.json',native_ingress=B/'q4t-ingress',device_control=B/'q4t-device-control',capacity_config=dict(version=2,**{k:v for k,v in settings['profile'].items() if k not in ('name','host')}),application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},embedding_model_dir=Path(settings['native_embedding']['directory']),asr_model_dir=Path(settings['native_asr']['directory']),asr_limits=settings['native_asr']['limits'],asr_auxiliary={k:v for k,v in settings['native_asr'].items() if k in p.ASR_AUXILIARY},tts_model_dir=Path(settings['native_tts']['directory']),tts_limits=settings['native_tts']['limits'],recovery_profiles=P/'qualified/registry.json',recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
 p.save(O/'receipt.json',receipt);p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,'unrelated settings drift');p.require(all(p.sha(R/n)==h for n,h in protected.items()),'default changed')
 p.save(O/'prepare-review.json',dict(status='TTS_INPUT_CANDIDATE_MANAGED_ACCEPTANCE_PENDING',previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),package_sha256=receipt['manifest_sha256'],runtime_source_sha256=runtime,runtime_delta=sorted(delta),direct_runtime_delta=sorted(directdelta),control_source_delta=sorted(control),native_source_delta=sorted(nativedelta),native_executables=built['binaries'],client_policy_before=prior,client_policy_after=policy,client_artifacts_changed=False,new_gpu_starts=0,default_changed=False,managed_composition_pending=True))
 print(receipt['manifest_sha256'])
if __name__=='__main__':main()

"""Four bounded, independently leased actual TTS/input service stages; stop on any failure."""
import hashlib,json,os,signal,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
protected=['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']
def defaults():return {n:sha(R/n) for n in protected}
F=W/'service-sequence-plan-01.json'
assert not F.exists()
assert shutil.disk_usage(W).free>=384*1024**2
frozen=dict(status='FROZEN_BEFORE_EXECUTION',scope='Four separate complete leases, not one continuous lease across stages; retained modern/legacy control, native TLS gateway recovery with both SDKs, whole-payload fallback. Input/TTS audio actually executes in each required phase. No full numerical/performance/long stability matrix.',aggregate_limits=dict(model_starts=5,counted_posts=37,cuda_probes=1,seconds=1800),stage_artifact_limit=32*1024**2,aggregate_artifact_limit=128*1024**2,min_free_before_stage=256*1024**2,initial_free=shutil.disk_usage(W).free,defaults=defaults(),stage_plan_hashes={n:sha(W/n/'plan.json') for n in ['modern-service-01','retained-service-01','tls-service-01']},pending_version_plan=dict(scenario='tool_version',starts=2,chats=12,probes=1,seconds=600,depends_on='finalized retained-service-01 receipt'),driver_sha256=sha(Path(__file__)),automatic_request_retry=False)
save(F,frozen);records=[]
def call(label,command,seconds):
 start=time.monotonic();timed_out=False
 with (W/(label+'.stdout')).open('xb') as stdout,(W/(label+'.stderr')).open('xb') as stderr:
  child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=child.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 value=dict(label=label,command=command,returncode=code,seconds=time.monotonic()-start,timed_out=timed_out);records.append(value);save(W/'service-sequence-result-01.json',records);print(json.dumps(value),flush=True)
 if code or timed_out:
  print((W/(label+'.stderr')).read_text()[-2500:],flush=True);raise SystemExit(code or 1)
 return value

def run(name):
 out=W/name;plan=read(out/'plan.json');assert defaults()==frozen['defaults'];assert shutil.disk_usage(W).free>=frozen['min_free_before_stage']
 scope=dict(plan_sha256=sha(out/'plan.json'),limits=plan['limits'],max_artifact_bytes=frozen['stage_artifact_limit'],default_identity=frozen['defaults'],initial_free=shutil.disk_usage(W).free,strict_complete_stage_lease=True)
 save(out/'resource-scope.json',scope)
 command=['/usr/bin/python3','-B',str(R/'tools/evalscope/gpu_exclusive.py'),'--compute-backend','nvml','--inherit-lease','--output',str(out/'lease'),'--',*plan['command']]
 save(out/'lease-command.json',command)
 record=call(name+'-launch',command,plan['limits']['seconds']+60);save(out/'launch.json',record)
 result=read(out/'execution/result.json');print(json.dumps(dict(stage=name,status=result['status'],seconds=result['seconds'],counts=result['budget']['counts'])),flush=True)
 call(name+'-finalize',['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'finalize','--plan',str(out/'plan.json')],120)
 size=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert size<=frozen['stage_artifact_limit'];assert defaults()==frozen['defaults'];save(out/'resource-result.json',dict(status='PASS',artifact_bytes=size,default_unchanged=True,free=shutil.disk_usage(W).free));print(read(out/'decision.json')['acceptance'],flush=True)

for name in ['modern-service-01','retained-service-01','tls-service-01']:run(name)
name='version-service-01'
command=['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'prepare','--scenario','tool_version','--package',str(W/'service-package-01/bundle'),'--output',str(W/name),'--retained',str(W/'retained-01/bundle'),'--release',str(W/'retained-service-01/service-release.json'),'--decision',str(W/'retained-service-01/decision.json'),'--separator-audio',str(R/'.q4t-work/serve-overlap-20261118/http-05/mixed.wav')]
call(name+'-prepare',command,120)
plan=read(W/name/'plan.json');assert plan['limits']==dict(starts=2,chats=12,probes=1,controls=2500,seconds=600)
save(W/'version-plan-binding-01.json',dict(plan_sha256=sha(W/name/'plan.json'),original_sequence_plan_sha256=sha(F)))
run(name)
print('ALL_FOUR_FROZEN_STAGES_FINALIZED',flush=True)

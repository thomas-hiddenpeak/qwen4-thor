from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'managed-duplex-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tools/serve_realtime/'+n for n in ('duplex_managed.py','duplex_recovery_sdk.mjs','duplex_service_acceptance.py','test_duplex_service.py','test_duplex_recovery_sdk.py','managed.py','speech_checks.py','duplex_checks.py','duplex_task_checks.py','conversation_checks.mjs','bounded_journal.mjs','prompt_service_acceptance.py')]+['.github/workflows/host-checks.yml']
commands=[['python3','-B','-m','unittest','-v','tools.serve_realtime.test_duplex_service','tools.serve_realtime.test_duplex_recovery_sdk'],['node','--check','tools/serve_realtime/duplex_recovery_sdk.mjs'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
plan=dict(scope='Actual SDK/native TLS CPU peer and source/counter checks for frozen native duplex recovery; no model actions.',limits=dict(tests=12,source_counterexamples=20,seconds=120,gpu_starts=0),commands=commands,sources={n:sha(R/n) for n in files},protected={n:sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')},gpu_scope=sha(W/'duplex-recovery-scope-01.json'));save('plan.json',plan)
started=time.monotonic();rows=[];status='PASS'
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=max(1,120-(time.monotonic()-started)),env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O),Q4T_NODE_SDK_DIR=str(R/'.q4t-work/serve-realtime-20261119/profile-sdk-01'),Q4T_INGRESS=str(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t-ingress')))
 (O/f'{i}.stdout').write_bytes(r.stdout);(O/f'{i}.stderr').write_bytes(r.stderr);rows.append(dict(command=cmd,exit_code=r.returncode))
 if r.returncode:status='FAIL'
m=re.search(r'Ran (\d+) tests?',(O/'0.stderr').read_text());count=int(m[1]) if m else 0
if count!=12:status='FAIL'
assert all(sha(R/n)==h for n,h in plan['protected'].items())
result=dict(status=status,tests=count,commands=rows,seconds=time.monotonic()-started,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

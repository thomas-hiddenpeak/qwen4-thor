from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-duplex-managed-cpu-20261120';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
C=W/'managed-duplex-cpu-01';cpu=read(C/'result.json');built=read(W/'native-build-01/result.json');assert cpu['status']==built['status']=='PASS'
for n,h in read(C/'plan.json')['sources'].items():assert sha(R/n)==h
review=dict(cpu=cpu,native_build=built,scope=read(W/'duplex-recovery-scope-01.json'),default_unchanged=True,actual_recovery_pending=True,master_active=True);save(O/'review.json',review)
paths=[p for p in C.iterdir() if p.is_file()]+[p for p in C.rglob('*') if p.is_file() and (p.name.endswith('.events.jsonl') or p.name.startswith(('stdout-','stderr-')) or p.name=='ready.json')]+[W/'native-build-01'/n for n in ('plan.json','result.json','build.log')]+[W/n for n in ('run_managed_duplex_cpu_01.py','build_native_helpers_01.py','duplex-recovery-scope-01.json')]+[Path(__file__)]
rows=[]
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for p in dict.fromkeys(paths):
  name=str(p.relative_to(W));tar.add(p,arcname=name,recursive=False);rows.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
save(O/'index.json',dict(records=rows,archive_sha256=sha(O/'records.tar.gz')))
(O/'README.md').write_text('''# 原生双向恢复驱动CPU通过

2026-11-20，12项针对CPU/3.133秒及20来源反例通过，包括3项实际固定
SDK/原生入口的CPU对端检查。真实TLS传输、同一conversation的输入/
回答、连续ASR未提交前故障、整入口丢失后的显式新连接、原始事件
持续落盘、用量和所属资源保护有CPU证据；夹具不是模型业务资格。

必要原生helper构建1.716秒、零警告；Guardian、CUDA探针、入口和
设备控制二进制与既有验收身份一致。候选引擎ecd6cc23未改。没有新增
GPU工作或外部依赖，默认rev376保持STOPPED。

实际恢复短验固定为保留包1模型/3工作/1WSS/300秒，TLS网关+控制器
2模型/9工作/3WSS/360秒，整包回退2模型/6工作/2WSS/1探针/540秒。
每组严格租约，全部工作数包含5次启动自检；只故障注入所属测试
服务，实际PCM→ASR→模型回答、真实波形检索及清理。旧请求不重放，
入口退出不应重启健康模型，控制器死亡沿用完整配额窗口再重启。

下一步封装已具主轻资格的v24包并执行这些真实短验，通过后可回退
发布/合入，继续全部master；模型质量失败和用户延期听感仍保留。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认');p.write_text(s[:i]+'''
[双向原生恢复驱动CPU](evidence/serve-realtime-duplex-managed-cpu-20261120/README.md)：
12项/3.133秒与20来源反例通过，含实际SDK/原生TLS的CPU故障对端。
helper构建1.716秒零警告且身份未变，新增GPU0。冻结5模型/18工作/
6WSS/1探针/1200秒实际恢复，接着执行保留包/TLS/整包回退再交付；
候选ecd6cc23、默认rev376保持，全部master继续。
''' +s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 双向原生恢复驱动与有界故障短验准备

日期：2026-11-20。

做了什么：同会话PCM→ASR→回答、检索、未提交连续ASR故障和显式
新连接驱动完成，12CPU/20来源反例3.133秒通过，包含实际SDK/TLS。
原生helper构建1.716秒零警告，身份未变，新增GPU0。

为什么：恢复验收要观察真实正在执行的输入、结算和模型所有权，
不能用连接建立或空请求代替；原始事件持续落盘保证中断仍可审计。

下一步：冻结5模型/18原生工作/1200秒真实保留包、TLS及整包回退，
通过后可回退交付并继续全部master；默认rev376保持STOPPED。
''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['realtime_progress']['duplex_input_20261120'].update(state='managed_cpu_pass_actual_recovery_pending',managed_recovery_cpu=dict(evidence=str(O.relative_to(R)/'README.md'),result=cpu,native_build=built));save(p,v)
print(json.dumps(dict(evidence=str(O),archive_bytes=(O/'records.tar.gz').stat().st_size)))

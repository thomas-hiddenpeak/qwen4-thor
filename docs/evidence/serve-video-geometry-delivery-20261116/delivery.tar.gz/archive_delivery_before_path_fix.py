"""Archive public delivery receipts without copying private state or payloads."""
import json
import re
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_service.package import read, require, save, sha

W = Path(__file__).resolve().parent
OUT = ROOT / 'docs/evidence/serve-video-geometry-delivery-20261116'
result = read(W / 'delivery-01/result.json')
current = result['publication']['current']
require(result['status'] == 'PASS_NATIVE_VIDEO_GEOMETRY_DELIVERED' and
        result['publication']['revision'] == 150 and
        result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0,
        'delivery not accepted')
for name, key in [('q4t', 'engine_binary_sha256'),
                  ('q4t.release.json', 'engine_release_sha256'),
                  ('service.release.json', 'service_release_sha256'),
                  ('service.acceptance.json', 'service_acceptance_sha256')]:
    require(sha(ROOT / 'build' / name) == current[key], 'default identity drift')

secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)

for policy in ('build/service/engine/client-policy.json', 'build/service/gateway-policy.json'):
    collect(read(ROOT / policy))
files = [(p, 'delivery-01/' + p.name) for p in (W / 'delivery-01').iterdir()
         if p.is_file() and not p.is_symlink()]
files += [(p, 'publication-archive-01/' + p.name)
          for p in (W / 'publication-archive-01').iterdir()
          if p.is_file() and not p.is_symlink()]
for name in ('archive_delivery.py', 'deliver.py', 'run_delivery.py',
             'archive_generations.py', 'publication-archive-prepared.json',
             'publication-archive-applied.json'):
    files.append((W / name, name))
for stem in ('delivery-prepare-01', 'delivery-run-01', 'publication-archive-01'):
    for extension in ('json', 'stdout', 'stderr'):
        files.append((W / (stem + '.' + extension), stem + '.' + extension))
for path, _ in files:
    raw = path.read_bytes()
    require(not any(secret in raw for secret in secrets), 'secret in public evidence')
    require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', raw), 'private key in evidence')
OUT.mkdir()
with tarfile.open(OUT / 'delivery.tar.gz', 'w:gz') as archive:
    for path, name in sorted(files, key=lambda item: item[1]):
        archive.add(path, arcname=name, recursive=False)
(OUT / 'delivery-01').mkdir()
for name in ('result.json', 'plan.json', 'recovery-anchor.json'):
    (OUT / 'delivery-01' / name).write_bytes((W / 'delivery-01' / name).read_bytes())
save(OUT / 'acceptance.json', dict(
    status='ACCEPT_NATIVE_VIDEO_GEOMETRY_DELIVERY', revision=150,
    current=current, commands=len(result['commands']), seconds=result['seconds'],
    new_gpu_starts=0, state='STOPPED',
    core_client_outer_state_preserved=True, profile_budget_preserved=True,
    retained_anchor_generation=result['retained_anchor_generation'],
    files=len(files), archive_sha256=sha(OUT / 'delivery.tar.gz'),
    secret_scan_matches=0, remaining_master_tasks_active=True))
(OUT / 'README.md').write_text('''# 原生视频显示几何可回退发行 rev150

默认引擎a7bd6785、正式服务包8d9c07f1，generation
37da32d909a70fb06e80dd505daa4ccbbe4831c2a4ffc32e05ee7e4c135ff83a。
17项STOPPED交付检查通过，54.855秒，0新增GPU：保留锚点、正式发布、
新恢复周期、实际整根回退再前进，以及默认check/status/observe。

原视频正交旋转/镜像、真实像素比例转方形像素、分配前尺寸预算与
v3来源几何/旧冻结快照读取已实现；共享输入说明使用已验证显示宽高。
真实SDK JSON/SSE四角、布局、计数及同PID文本通过，首轮失败保留。
新引擎主轻资格、精确包整树回退后的冻结镜像SSE另有实际业务证据。
控制源码、四个服务辅助程序与数值计算未改，原RAM压力/监护证据按
原身份复用；不把元数据辅助回答称为模型内部视觉能力改变。

逐命令core/client/outer字节保持，容量/Key/配额不变；主轻身份迁移
保持历史、选择、预算、冷却和配置，版本新周期保留前驱。最终STOPPED，
outer enabled且累计0启动，GPU保持释放。rev142默认/状态私有备份、
两个无活动引用generation的可恢复归档保留，包和旧证据没有删除。
公开归档不含私有状态、Key或二进制，实际密钥与私钥扫描0命中。

保留包a9bd9c73是旧v12控制器、既有媒体适配和同一当前引擎；自动版本
恢复保留现代根，人工整根回退的旧入口无outer，不是独立旧引擎回退。
PR30最终head检查与实际合main待完成。任意仿射/其余格式、媒体缓存、
完整客户端矩阵、真实云账户、资源与冷启动等剩余master继续推进；
本次不宣称完整协议、性能/全模型质量或长稳通过。
''')
print(json.dumps(dict(status='ACCEPT_DELIVERY', revision=150,
                      files=len(files), secret_scan_matches=0)))

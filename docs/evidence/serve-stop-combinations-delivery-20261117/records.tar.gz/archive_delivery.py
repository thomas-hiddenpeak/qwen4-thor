import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-01'
O=R/'docs/evidence/serve-stop-combinations-delivery-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');assert v['status']=='PASS_STOP_COMBINATIONS_DELIVERED' and v['publication']['revision']==224
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands']) and v['state']=='STOPPED' and v['new_gpu_starts']==0
c=v['publication']['current'];composition=read(W/'publication-composition.json')
assert c['manifest_sha256']==composition['candidate']['manifest_sha256'] and sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
files=[(p,'delivery-01/'+p.name) for p in D.iterdir() if p.is_file() and not p.is_symlink()]
for pattern in ('delivery-prepare-*.*','delivery-run-*.*','publication-archive-*.*','version-archive-*.*'):
 files.extend((p,p.name) for p in W.glob(pattern) if p.is_file())
for n in ['archive_delivery.py','deliver.py','run_delivery.py','archive_generations.py','archive_version_cycles.py','prepare_package.py','publication-composition.json','package-01/prepare-review.json']:
 files.append((W/n,n))
files=sorted({n:p for p,n in files}.items());secrets=[]
def collect(value):
 if isinstance(value,dict):
  for key,x in value.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(value,list):
  for x in value:collect(x)
for p in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(p))
for n,p in files:
 raw=p.read_bytes();assert not any(x in raw for x in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),n
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for n,p in files:tar.add(p,arcname=n,recursive=False)
for n in ('result.json','recovery-anchor.json'):shutil.copyfile(D/n,O/n)
a=dict(status='ACCEPT_STOP_COMBINATIONS_DELIVERY',revision=224,current=c,commands=19,seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,core_client_outer_bytes_preserved=True,profile_migration='Explicit complete stop/constraints/cache contract upgrade; historical budgets and cycles preserved',root_cycles_preserved=True,manual_root=composition['manual_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_whole_package_gpu_run=False,composed_change='Current engine business and exact primary/light + retained control acceptance; only explicit publication migration differs in live control sources; Python request builder separately verified',older_engine_fallback=False,prior_rev214_preserved=True,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Stop、结构化输出与缓存默认交付 rev224

实际包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`；引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU。最终STOPPED，outer已配置且累计启动0次。

Stop能与工具/JSON约束和私有/共享缓存共同使用；可见值仍必须完整
且匹配语义receipt，截断不发布成功终态。私有缓存只保存完整prompt，
不把隐藏推测尾部写成可复用响应。[业务验收](../serve-stop-combinations-business-20261117/README.md)
累计6启动27请求、342.380秒，含原视觉题合法拒绝及driver失败。前9条
独立接受、仅补实际图片3条；原失败不追认，续问EOS不冒称stop命中。
主轻和精确保留组合已实跑；原生helper与live控制保持原身份。

核心/client/outer预算字节保持，profile仅显式扩展已验完整Stop能力；
history/pending/selected/deadline/clock/configuration保持。实际切换恢复
各根原周期，仅递增revision。Python构造器的合法Stop/session接入有
直接验证；未再跑完整性能或模型质量矩阵。

先前prepare与归档的互斥竞争被正常拒绝，归档结束后prepare通过；
原失败保留，未放松保护。退休generation/版本登记各两份可恢复归档，
0删除。人工根`{a['manual_root'][:12]}`和自动payload`{a['automatic_payload'][:12]}`
均保留当前能力，使用当前引擎，不冒称独立旧引擎回退；rev214包与
原长稳计划另保留。继续当前day交接、实际合main和全部master任务。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev224；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；outer/周期及Stop/缓存能力完整，前驱214另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退'}
for label,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(label)+r' \| .* \|$',lambda _:f'| {label} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev224 Stop组合交付](evidence/serve-stop-combinations-delivery-20261117/README.md)
已完成19项STOPPED发布、真实整根回退与再前进，{v['seconds']:.3f}秒、0新增
GPU。完整可见终态/receipt、prompt-only私有状态、实际工具/图片及
主轻/保留组合已验；原预算与周期保持，原失败如实保留。用户day
准备新独立快照，原rev214计划保留；PR38及本组实际合main继续。
全部33项master仍是总目标完成条件，其余协议/模型/资源缺口继续实现。

'''
s=s.replace('[rev214媒体缓存交付]',intro+'前驱[rev214媒体缓存交付]',1);s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro,1);p.write_text(s)
p=R/'docs/log/2026-11-17.md';head,rest=p.read_text().split('\n',1);p.write_text(head+f'''

## rev224 Stop组合可回退默认交付

2026-11-17：19项STOPPED发布/整根回退/再前进通过，{v['seconds']:.3f}秒，0GPU。
完整可见值与语义receipt、停止后的prompt-only缓存、实际工具和图片
组合已验；core/client/outer字节与各根原周期保持，profile只显式升级
Stop能力。先前prepare与版本归档竞争被拒绝，归档完后通过；原失败
保留，2代副本/2份退休登记可恢复归档，未删除。原214包及长稳入口
保留。下一步冻结新day、PR38及本组实际合main，其余master持续推进。
'''+rest)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 if task['id']=='A05':
  task['state']='implemented_delivered_main_pending'
  task['remaining_required']=['Actual main integration of accepted Stop combination delivery']
  task['stop_combinations_20261117'].update(state='delivered_main_pending',revision=224,manifest_sha256=c['manifest_sha256'],delivery_evidence='evidence/serve-stop-combinations-delivery-20261117/README.md')
  task['development_status']='官方schema能力、工具/媒体/缓存与Stop组合实现并针对性验证，rev224实际可回退交付；本组实际合main待完成，不以阶段结束代替总目标。'
 if task['id']=='Q02':
  task['state']='latest_release_delivered_main_pending_remaining_tasks_active'
  task['stop_combinations_delivery_20261117']=a|dict(evidence='evidence/serve-stop-combinations-delivery-20261117/README.md')
  task['remaining_required']=['PR38 and Stop delivery exact-head checks and actual main merge','Delivery of every remaining implementation']
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev224 or then-current default; do not stop camera/jtop without pending maintenance handoff.'
j['next']=j['next_task']='Freeze rev224 native day handoff; complete PR38 and Stop delivery checks and actual main merges. Continue native web-search execution, Chat/audio/media backend/SDK and cold/resource/host tasks; all required master tasks remain active.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev224 Stop/约束/缓存交付](evidence/serve-stop-combinations-delivery-20261117/README.md)：可见终态和prompt-only恢复、真实业务及整根回退，原失败保留。\n')
p=R/'docs/SERVE_STOP_COMBINATIONS_2026-11-17.md';p.write_text(p.read_text()+'''
## 当前实际交付

rev224已完成19项STOPPED检查/发布、整根回退与再前进，0新增GPU。
累计6启动27请求、342.380秒已含原失败和保留包自检，原证据不追认。
数值内核、原生helper和live控制未变，预算/周期保持；迁移与客户端
按精确改动验证。见[交付记录](evidence/serve-stop-combinations-delivery-20261117/README.md)。
继续day交接、实际合main及其余全部master任务。
''')
p=R/'tools/serve_audit/inventory.json';j=read(p)
j['fields']['messages']['boundary']='当前托管包启用单槽媒体，直接serve显式启用。原文件、HTTP(S)/inline图像、MP4/WebM、真实显示尺寸和冻结快照通过共享准备/模板/计数；普通文本保留MTP。普通Chat媒体限user，内部Responses工具媒体有认证路径。assistant url_citation历史校验字符偏移并进入原模板，未据此执行联网检索；audio历史仍属A02/A10。rev214已实际交付完整内容/处理器/几何身份、视觉块边界、target三轴/RoPE及视觉分块，rev224补齐Stop/约束/私有缓存组合。'
j['fields']['stop']['boundary']='约束输出必须通过可见完整值/receipt终态校验；stop请求私有缓存复用完整prompt，不发布MTP不可见尾部。包含推理/工具标记，部分工具错误；usage计至命中token，不宣称没有额外计算。针对性CPU及真实MTP/图片/schema/主轻/保留组合已验，rev224可回退交付；原失败和EOS未命中保持原记录。'
for key in ('messages','stop'):
 j['fields'][key]['evidence'].append('docs/evidence/serve-stop-combinations-delivery-20261117/README.md')
j['stop_combinations_20261117'].update(state='delivered_main_pending',default_revision=224,default_changed=True,evidence='docs/evidence/serve-stop-combinations-delivery-20261117/README.md')
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(revision=224,files=len(files),seconds=v['seconds'],secret_scan_matches=0)))

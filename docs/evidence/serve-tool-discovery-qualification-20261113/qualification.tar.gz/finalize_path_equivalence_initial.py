"""Postflight only: verify equivalent argv paths, retain all original evidence."""
import copy
import json
from pathlib import Path
import runpy
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.serve_service import package as p


def equivalent(actual, expected):
    if (len(actual)!=6 or len(expected)!=6 or actual[1]!='-B' or
        actual[3:5]!=['run','--plan'] or actual[1]!=expected[1] or
        actual[3:5]!=expected[3:5]):
        raise ValueError('unexpected command syntax')
    resolved=shutil.which(actual[0])
    if resolved is None or Path(resolved).resolve(strict=True)!=Path(expected[0]).resolve(strict=True):
        raise ValueError('different interpreter')
    for index in (2,5):
        if (ROOT/actual[index]).resolve(strict=True)!=Path(expected[index]).resolve(strict=True):
            raise ValueError('different script or plan')
    return True


def main():
    path=W/'managed-retained-01/plan.json'
    plan=p.read(path);guard=p.read(path.parent/'lease/exit.json')
    driver=ROOT/plan['command'][2]
    assert p.sha(driver)==plan['sources'][str(driver.relative_to(ROOT))]
    wrapper=p.read(W/'managed-retained-run-01.json')
    assert wrapper['exit_code']==0 and wrapper['default_unchanged'] is True
    assert wrapper['argv'][wrapper['argv'].index('--')+1:]==guard['command']
    assert Path.cwd()==ROOT
    equivalent(guard['command'],plan['command'])
    package=p.read(Path(plan['package']['package'])/'manifest.json')
    assert p.sha(Path(plan['command'][0]))==package['python']['sha256']
    # Negative controls use the actual frozen paths; none dispatch a process.
    mutations=[['/bin/false',*guard['command'][1:]],
               [guard['command'][0],'-I',*guard['command'][2:]],
               [*guard['command'][:2],str(__file__),*guard['command'][3:]],
               [*guard['command'][:5],str(driver)]]
    for wrong in mutations:
        try:equivalent(wrong,plan['command'])
        except ValueError:pass
        else:raise AssertionError('different command accepted')
    proof=dict(status='PASS_ARGV_PATH_EQUIVALENCE',actual=guard['command'],expected=plan['command'],
        working_directory=str(ROOT),driver_sha256=p.sha(driver),interpreter_sha256=p.sha(Path(plan['command'][0])),
        negative_controls=len(mutations),plan_sha256=p.sha(path),guard_sha256=p.sha(path.parent/'lease/exit.json'),
        wrapper_record_sha256=p.sha(W/'managed-retained-run-01.json'),new_gpu_starts=0,original_records_unchanged=True)
    module=runpy.run_path(str(driver));original=module['accepted_run']
    def checked(plan,result,raw,queries,events):
        assert raw==guard
        equivalent(raw['command'],plan['command'])
        canonical=copy.deepcopy(raw);canonical['command']=plan['command']
        return original(plan,result,canonical,queries,events)
    module['finalize'].__globals__['accepted_run']=checked
    module['finalize'](path)
    assert p.sha(path)==proof['plan_sha256'] and p.sha(path.parent/'lease/exit.json')==proof['guard_sha256']
    p.save(W/'managed-retained-01/path-equivalence.json',proof)


if __name__=='__main__':main()

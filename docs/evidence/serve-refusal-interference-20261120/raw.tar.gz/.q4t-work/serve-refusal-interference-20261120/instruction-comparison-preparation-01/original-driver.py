"""One light-capacity process, four frozen greedy raw-prompt comparisons.

This is diagnosis, not a qualification retry. Both prompts carry the same
explicit refusal frame contract. No runtime or default setting is changed.
"""
import copy
import json
from pathlib import Path
import signal
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import profile_acceptance as full
from tools.serve_responses import encryption_acceptance as encrypted
from tools.serve_service.package import read, require, save, sha

WORK = Path(__file__).resolve().parent
OUT = WORK / 'instruction-comparison-01'
LIMITS = dict(starts=1, chats=4, controls=1000, seconds=300)


def requests():
    return read(WORK / 'input-review-01/requests.json')


class Stage(full.Stage):
    limits = LIMITS
    request_templates = staticmethod(requests)
    success_status = 'OBSERVATIONS_COMPLETE_NOT_QUALIFICATION'

    def __init__(self, plan):
        require(plan['diagnostic_capacity'] == 'light' and
            plan['profiles']['primary'] == plan['profiles']['light'] and
            plan['profiles']['primary']['mtp_enabled'] is False,
            'single diagnostic slot must use the actual light capacity')
        encrypted.Stage.__init__(self, plan)

    def business(self):
        config = read(self.out / 'primary-config.json')
        require(config['mtp_enabled'] is False, 'diagnosis unexpectedly enabled MTP')
        observed = {}
        for label, body in self.plan['requests'].items():
            save(self.out / (label + '.request.json'), body)
            self.budget('chats')
            status, raw = self.http('/v1/completions', body, label=label, timeout=120)
            value = json.loads(raw)
            self.same_model(); self.drained(label + '-drain')
            text = value['choices'][0]['text'] if status == 200 else None
            observed[label] = dict(http_status=status, answer=text, raw=value,
                model_quality='PASS' if text and text.strip() == 'rev356' else 'FAIL',
                input_tokens=value.get('usage', {}).get('prompt_tokens'),
                fixed_temperature=0, fixed_seed=0, default_changed=False)
            save(self.out / 'observed.json', observed)
        require(self.counts['chats'] == 4, 'missing frozen prompt comparison')


def prepare():
    OUT.mkdir(mode=0o700)
    old = ROOT / '.q4t-work/serve-realtime-prompt-20261120/profiles-02/plan.json'
    plan = copy.deepcopy(read(old))
    # The inherited one-process launcher calls its slot primary; its full
    # frozen capacity is explicitly the previous light (MTP-off) definition.
    plan['profiles']['primary'] = copy.deepcopy(plan['profiles']['light'])
    plan.update(output=str(OUT), limits=LIMITS, requests=requests(), scope=__doc__,
        diagnostic_capacity='light', qualification=False, automatic_retries=False,
        planned=dict(starts=1, completions=4, seconds=300),
        source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip())
    for key in ('continued_primary_text', 'conversation', 'prompt'):
        plan.pop(key, None)
    for name in plan['sources']:
        if Path(name).resolve() == ROOT / 'docs/STATUS.md':
            plan['sources'][name] = sha(name)
    for path in (Path(__file__), old, *(WORK / 'input-review-01').glob('*.json')):
        plan['sources'][str(path)] = sha(path)
    full.candidate_build_base(plan['base'], Path(plan['binary']), Path(plan['candidate_identity']['build']))
    save(OUT / 'plan.json', plan)


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']: prepare()
    else:
        require(sys.argv[1:] == ['run'], 'explicit frozen mode required')
        def stopped(_signum, _frame): raise TimeoutError('bounded comparison ended')
        signal.signal(signal.SIGTERM, stopped); signal.signal(signal.SIGALRM, stopped)
        signal.alarm(LIMITS['seconds'])
        try: Stage(read(OUT / 'plan.json')).run()
        finally: signal.alarm(0)

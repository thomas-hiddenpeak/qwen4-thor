from pathlib import Path
import json,gzip,hashlib,os
here=Path(__file__).resolve().parent;root=here.parents[2];p=json.loads((here/'plan.json').read_text());target=root/p['source']
raw=gzip.decompress((here/'qualified-contracts.gz').read_bytes());assert len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256']
if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==p['sha256']
else:
 with target.open('xb') as f:f.write(raw)
 target.chmod(p['mode'])

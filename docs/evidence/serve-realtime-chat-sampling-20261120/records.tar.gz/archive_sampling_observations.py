"""Publish immutable diagnostic observations; no service qualification."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
OUT = ROOT / 'docs/evidence/serve-realtime-chat-sampling-20261120'
OUT.mkdir()
names = ('recovery-sampling-diagnostic-02',
         'recovery-sampling-diagnostic-03', 'recovery-greedy-control-01')
files, observations = [], []
for name in names:
    stage = W / name
    result = json.loads((stage / 'result.json').read_bytes())
    lease = json.loads((stage / 'lease/exit.json').read_bytes())
    samples = [json.loads(line) for line in
               (stage / 'lease/nvml-queries.jsonl').read_text().splitlines()]
    assert all(row['status'] == 'OK' for row in samples)
    assert not samples[-1]['pids'] and result['cleanup_failure'] is None
    assert result['default_unchanged'] and not result['service_qualified']
    assert lease['command'] == json.loads((stage / 'plan.json').read_bytes())['command']
    observations.append(dict(stage=name, result=result,
                             guard_status=lease['status'], nvml_ok=len(samples)))
    files.extend(p for p in stage.rglob('*') if p.is_file())
for name in ('diagnostic-terminal-cpu-01', 'retired-pools-01'):
    files.extend(p for p in (W / name).iterdir() if p.is_file())
files.extend(W / name for name in ('observe_greedy_control.py',
    'recovery_sampling_diagnostic.py', 'archive_delivery_pools.py',
    'archive_sampling_observations.py'))
index = []
with tarfile.open(OUT / 'records.tar.gz', 'w:gz') as archive:
    for path in sorted(set(files)):
        data = path.read_bytes()
        assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', data)
        assert not re.search(rb'(?:sk-proj-|Bearer )[A-Za-z0-9_-]{24,}', data)
        relative = str(path.relative_to(W))
        archive.add(path, arcname=relative, recursive=False)
        index.append(dict(path=relative, bytes=len(data),
                          sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(OUT / 'records.tar.gz', 'r:gz') as archive:
    for record in index:
        data = archive.extractfile(record['path']).read()
        assert hashlib.sha256(data).hexdigest() == record['sha256']
summary = dict(status='DIAGNOSTIC_ONLY_NOT_SERVICE_QUALIFICATION',
    original_failures_preserved=True, service_qualified=False,
    model_starts=sum(x['result']['counts']['starts'] for x in observations),
    chat_requests=sum(x['result']['counts']['chats'] for x in observations),
    seconds=sum(x['result']['seconds'] for x in observations),
    nvml_ok=sum(x['nvml_ok'] for x in observations), observations=observations,
    greedy=json.loads((W / names[-1] / 'observation.json').read_bytes()),
    pool_maintenance=json.loads((W / 'retired-pools-01/result.json').read_bytes()),
    files=len(index), secret_scan_matches=0,
    archive_sha256=hashlib.sha256((OUT / 'records.tar.gz').read_bytes()).hexdigest())
for name, value in (('summary.json',summary),('index.json',index)):
    (OUT / name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()
                  if k not in ('observations','greedy','pool_maintenance')}))

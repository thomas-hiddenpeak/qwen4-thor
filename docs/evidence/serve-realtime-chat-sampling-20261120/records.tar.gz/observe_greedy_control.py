"""One remaining greedy observation of the exact actual failed prompt.

The preceding two cold runs both generated refusals without any injected
fault. The second diagnostic failed to regard a refusal delta as output, so
no cancellation occurred. Preserve both failures; do not repeat that arm.
This one request completes the sampling contrast, not service acceptance.
"""
from pathlib import Path
import json
import os
import runpy
import sys

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
base = runpy.run_path(str(W / 'recovery_sampling_diagnostic.py'))
save, sha, require = (base[k] for k in ('save','sha','require'))
OUT = W / 'recovery-greedy-control-01'
LIMITS = dict(starts=1,chats=1,controls=2000,seconds=300)
base['Stage'].__init__.__globals__['LIMITS'] = LIMITS


class Stage(base['Stage']):
    def exercise(self):
        observed = self.answer('greedy')
        save(self.out / 'observation.json',dict(actual=observed,
            original_failures_preserved=True,service_qualified=False,
            scope='Single greedy control; not a within-process cancellation comparison'))
        final = self.drained('final-drained')
        require(self.counts['chats'] == 1 and final['q4t_requests_total'] == 1
            and final['q4t_requests_success_total'] == 1
            and final['q4t_requests_aborted_total'] == 0
            and final['q4t_requests_error_total'] == 0,'single observation accounting')


if __name__ == '__main__':
    os.umask(0o077)
    if sys.argv[1:] == ['prepare']:
        OUT.mkdir(mode=0o700)
        plan = json.loads((W / 'recovery-sampling-diagnostic-03/plan.json').read_bytes())
        plan.update(scope=__doc__,limits=LIMITS,output=str(OUT),
            requests={'greedy':plan['requests']['greedy']},
            command=['/usr/bin/python3','-I','-B',str(Path(__file__).resolve()),'run'],
            cumulative_diagnostic_maximum_starts=3,cumulative_diagnostic_maximum_chats=3,
            comparison_across_model_processes=True,
            no_cancellation_in_prior_diagnostics=True)
        plan['sources'][str(Path(__file__).resolve())] = sha(__file__)
        for name in ('result.json','cancel.partial.wire','lease/exit.json','executed-driver.py'):
            path = W / 'recovery-sampling-diagnostic-03' / name
            plan['sources'][str(path)] = sha(path)
        save(OUT / 'plan.json',plan)
        print(json.dumps(dict(status='PREPARED_ONLY',limits=LIMITS,new_gpu_starts=0)))
    elif sys.argv[1:] == ['run']:
        raise SystemExit(Stage(json.loads((OUT / 'plan.json').read_bytes())).run())
    else: raise SystemExit('expected prepare or run')

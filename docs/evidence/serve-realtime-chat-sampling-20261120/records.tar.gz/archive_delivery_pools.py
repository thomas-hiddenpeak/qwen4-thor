"""Reversibly retire four inactive generations and four inactive registrations.

Uses the existing STOPPED-owner maintenance tools and their fresh dependency
checks. No package, evidence, budget or default program is deleted or changed.
"""
from pathlib import Path
import json
import os
import signal
import sys
import time
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sys.path.insert(0,str(ROOT))
from tools.serve_recovery import publication_archive as pa, version_archive as va
from tools.serve_service.package import sha, save, require

OUT = W / 'retired-pools-01'
STATE = ROOT / 'build/service-native-state'
GENERATIONS = ['8aa10de895990cf1f735f42c34e25d1dac6e272a8ac3e71a76456a413b732ce3',
    '3dcce5e7e93b129c90d4e862fee2fcc6f3881aae3f8442ea9d59230ecc0ffd61',
    'd548cf475ccf93d1ddffb794a8845c8524ffc80889bf7e426eab0e369da28bf0',
    'c613deb3f59c3bb03733637a8755e40469cc160b45c32dea86176f69b6539d71']
CYCLES = ['c14e1a7f-1a4c-443c-88ad-f4723293754d',
    '494a52f2-edbf-4d81-a610-10905815265d',
    '29270c36-55fb-4a5b-bfdd-d95044f1098b',
    '76b164d0-ee1c-4b04-8ccc-442b4b607be3']


def protected():
    paths = [ROOT / p for p in ('build/q4t','build/q4t.release.json',
        'build/service/manifest.json','build/service.release.json')]
    paths += [p for p in STATE.rglob('*') if p.is_file() and
              (p.name == 'ledger.json' or p.name == 'policy.json')]
    return {str(p):sha(p) for p in paths}


os.umask(0o077)
OUT.mkdir(mode=0o700)
before = protected()
save(OUT / 'plan.json',dict(scope=__doc__, maximum_seconds=900,
    generations=GENERATIONS,cycles=CYCLES,new_gpu_starts=0,deleted_files=0,
    maximum_operations=4,protected=before,driver_sha256=sha(__file__)))
started = time.monotonic()
steps = []


def deadline(*_):
    raise TimeoutError('bounded offline maintenance deadline')


signal.signal(signal.SIGALRM,deadline);signal.alarm(900)
try:
    for label,module,selected in [('generations',pa,GENERATIONS),('cycles',va,CYCLES)]:
        preparation = module.prepare(STATE,OUT / label,selected)
        save(OUT / (label+'-prepared.json'),preparation)
        require(preparation['files_moved'] is False and preparation['model_actions'] is False,
                'unexpected prepare mutation')
        steps.append(label+'-prepared')
        require(protected() == before,'default, policy or historical budget changed')
        result = module.apply(preparation['plan'],preparation['sha256'])
        save(OUT / (label+'-applied.json'),result)
        require(result['status'] == 'RETIRED' and result['deleted_files'] == 0
                and result['model_actions'] is False,'archive did not complete')
        steps.append(label+'-applied')
        require(protected() == before,'default, policy or historical budget changed')
        print(json.dumps(dict(step=label,status=result['status'],count=4)),flush=True)
    result = dict(status='PASS_REVERSIBLE_RETIRED_POOL_MAINTENANCE',
        seconds=time.monotonic()-started,steps=steps,
        active_generations=len(list((ROOT / 'build/.q4t-publication/generations').iterdir())),
        active_registrations=len(list((STATE / 'version-registrations').glob('*.json'))),
        protected_unchanged=protected() == before,new_gpu_starts=0,deleted_files=0)
    require((result['active_generations'],result['active_registrations']) == (27,12),
            'unexpected active pool size')
    save(OUT / 'result.json',result);print(json.dumps(result),flush=True)
except BaseException:
    save(OUT / 'result.json',dict(status='FAILED',steps=steps,
        seconds=time.monotonic()-started,failure=traceback.format_exc(),
        protected_unchanged=protected() == before,new_gpu_starts=0))
    raise
finally:
    signal.alarm(0)

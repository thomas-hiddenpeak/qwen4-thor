"""Reuse the cold seed-0 refusal; compare a new model after one cancellation.

This is a diagnostic, never a replacement for the original failed answer.
Preparation performs no GPU work. Run only under the frozen strict lease.
"""
from pathlib import Path
import copy
import hashlib
import http.client
import json
import os
import signal
import socket
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
ROOT = W.parents[1]
sys.path.insert(0, str(ROOT))
from tools.serve_grammar_reap import acceptance as lifecycle
from tools.serve_service.package import require, save, sha
from tools.serve_recovery.bundle import check_assets

OUT = W / 'recovery-sampling-diagnostic-03'
PRIOR = W / 'recovery-sampling-diagnostic-02'
LIMITS = dict(starts=1, chats=3, controls=2000, seconds=600)


def observed_answer(body, expected):
    require(type(body) is dict and type(body.get('choices')) is list and
            len(body['choices']) == 1, 'actual response choice')
    choice = body['choices'][0]
    message = choice['message']
    content, refusal = message.get('content'), message.get('refusal')
    require(choice['finish_reason'] in ('stop','length','content_filter') and
        message.get('role') == 'assistant' and not message.get('tool_calls') and
        ((type(content) is str and refusal is None) or
         (content is None and type(refusal) is str and bool(refusal))),
        'actual response terminal')
    usage = body['usage']
    require(all(type(usage.get(k)) is int and usage[k] > 0
                for k in ('prompt_tokens','completion_tokens','total_tokens')) and
        usage['total_tokens'] == usage['prompt_tokens']+usage['completion_tokens'],
        'actual usage differs')
    return dict(choice=choice,usage=usage,
        source_answer_matches=choice['finish_reason'] == 'stop' and
            type(content) is str and content.strip() == expected,
        refused=refusal is not None)


def prepare():
    OUT.mkdir(mode=0o700)
    observed = json.loads((W / 'recovery-prompt-review-01/observed.json').read_bytes())
    require(observed[0]['executed_prompt'] == observed[1]['executed_prompt'],
            'actual source-bound prompt differs')
    request = copy.deepcopy(observed[1]['generation_request'])
    seeded = dict(request, seed=0, logprobs=True, top_logprobs=5)
    cancel = dict(model=request['model'], temperature=1, seed=0,
        enable_thinking=False, stream=True, max_completion_tokens=2048,
        messages=[dict(role='user', content='Write the integers from 1 to 10000, '
                       'one per line. Continue until the output limit.')])
    greedy = dict(request, temperature=0)
    source_plan = json.loads((W / 'business-04/run/plan.json').read_bytes())
    original = json.loads((PRIOR / 'result.json').read_bytes())
    require(original['status'] == 'FAILED' and original['counts']['starts'] == 1
        and original['counts']['chats'] == 1 and original['cleanup_failure'] is None,
        'retain the exact prior early diagnostic stop')
    original_plan = json.loads((PRIOR / 'plan.json').read_bytes())
    require(original_plan['requests']['seeded_before'] == seeded and
        sha(PRIOR / 'executed-driver.py') == original_plan['sources'][str(Path(__file__).resolve())],
        'original actual diagnostic identity changed')
    prior_answer = observed_answer(json.loads((PRIOR / 'seeded_before.wire').read_bytes()),'rev346')
    require(prior_answer['refused'] and not prior_answer['source_answer_matches'],
        'retain the actual cold quality failure')
    model_assets = source_plan['model_assets']
    binary = W / 'runtime-build-05/qualified_q4t'
    require(sha(binary) == 'f5af36c6c5d7232f9b180be8c9100616d0cfbe73b30f77135cb4b91a12eb609d',
            'qualified candidate required')
    sources = {str(ROOT / p):sha(ROOT / p) for p in subprocess.check_output(
        ['git','ls-files','src','include','tools/evalscope',
         'tools/serve_grammar_reap','tools/serve_service','tools/serve_recovery/bundle.py'],
        cwd=ROOT,text=True).splitlines()}
    sources.update({str(p):sha(p) for p in (Path(__file__),
        W / 'recovery-prompt-review-01/observed.json',
        W / 'tls-service-01/execution/tls-after-conversation.sdk.json',
        PRIOR / 'plan.json', PRIOR / 'result.json', PRIOR / 'seeded_before.wire',
        PRIOR / 'executed-driver.py', PRIOR / 'lease/exit.json')})
    protected = {str(ROOT / p):sha(ROOT / p) for p in
        ('build/q4t','build/q4t.release.json','build/service/manifest.json',
         'build/service.release.json','build/service-native-state/ledger.json')}
    plan = dict(scope=__doc__, limits=LIMITS, output=str(OUT),
        binary=str(binary),binary_sha256=sha(binary), model=source_plan['model'],
        model_assets=model_assets, port=18454,operations_port=18455,
        protected=protected,sources=sources,
        requests=dict(cancel=cancel,seeded_after=copy.deepcopy(seeded),greedy=greedy),
        reused_prior_answer=prior_answer, reused_prior_directory=str(PRIOR),
        comparison_across_model_processes=True,
        cumulative_diagnostic_maximum_starts=2,cumulative_diagnostic_maximum_chats=4,
        expected_version='rev346', original_failure_relabelled=False,
        model_launch_profile='same core capacity and MTP; no auxiliary model loads',
        command=['/usr/bin/python3','-I','-B',str(Path(__file__).resolve()),'run'],
        pending_owner_quality_classification=True,
        acceptance='DIAGNOSTIC_ONLY_NOT_SERVICE_QUALIFICATION')
    save(OUT / 'plan.json',plan)
    print(json.dumps(dict(status='PREPARED_ONLY',limits=LIMITS,new_gpu_starts=0)))


class Stage(lifecycle.Stage):
    def __init__(self, plan):
        self.plan, self.out = plan, Path(plan['output'])
        self.started = time.monotonic()
        self.counts = {k:0 for k in LIMITS if k != 'seconds'}
        self.model = self.model_identity = self.fault_thread = None
        self.history = {}
        self.lease = int(os.environ['Q4T_MANAGED_LEASE_FD'])
        lifecycle.verify_lease(self.lease,lifecycle.guard.common_lock())
        require(plan['limits'] == LIMITS,'frozen diagnostic budget drift')
        for path,digest in {**plan['sources'],**plan['protected']}.items():
            require(sha(path) == digest,'frozen input drift')
        require(sha(plan['binary']) == plan['binary_sha256'],'engine drift')
        check_assets(plan['model'],plan['model_assets'])

    def budget(self, kind):
        require(time.monotonic()-self.started < LIMITS['seconds']-40,'diagnostic deadline')
        require(self.counts[kind] < LIMITS[kind],'diagnostic count exceeded')
        self.counts[kind] += 1
        save(self.out / 'counts.json',self.counts)

    def start(self):
        for port in (self.plan['port'],self.plan['operations_port']):
            with socket.socket() as sock: sock.bind(('127.0.0.1',port))
        command = [self.plan['binary'],'serve','--model-dir',self.plan['model'],
            '--host','127.0.0.1','--port',str(self.plan['port']),
            '--operations-port',str(self.plan['operations_port']),
            '--mtp','--max-seq','1','--max-len','8192','--max-prefill','2048',
            '--max-tokens','256','--max-inflight-requests','8','--max-queued-requests','3']
        save(self.out / 'model-command.json',command)
        self.budget('starts')
        with (self.out / 'model.log').open('xb',buffering=0) as log:
            self.model = subprocess.Popen(command,cwd=ROOT,stdout=log,
                stderr=subprocess.STDOUT,pass_fds=(self.lease,))
        self.model_identity = lifecycle.guard.processes()[self.model.pid]
        self.history[self.model.pid] = self.model_identity
        save(self.out / 'model-identity.json',dict(pid=self.model.pid,**self.model_identity))
        end = time.monotonic()+180
        while time.monotonic() < end:
            self.same_model()
            try:
                if self.http('/readyz',timeout=1)[0] == 200: return
            except (OSError,http.client.HTTPException): pass
            time.sleep(.1)
        raise TimeoutError('readiness')

    def answer(self,label):
        status,raw = self.submit(label,self.plan['requests'][label])
        require(status == 200,'HTTP response failed')
        body = json.loads(raw)
        observed = observed_answer(body,self.plan['expected_version'])
        self.drained(label+'-drained')
        return observed

    def cancel(self):
        body = self.plan['requests']['cancel']
        self.budget('chats');save(self.out / 'cancel.request.json',body)
        connection = http.client.HTTPConnection('127.0.0.1',self.plan['port'],timeout=30)
        raw = bytearray();first = None;response = None
        try:
            connection.request('POST','/v1/chat/completions',json.dumps(body),
                               {'Content-Type':'application/json'})
            response = connection.getresponse()
            require(response.status == 200,'cancel stream status')
            while len(raw) < 1 << 20:
                line = response.readline(65537)
                require(line and len(line) <= 65536,'cancel stream bound')
                raw.extend(line)
                if not line.startswith(b'data: {'): continue
                value = json.loads(line[6:])
                for choice in value.get('choices',[]):
                    require(choice['finish_reason'] is None,'response completed before cancel')
                    if choice.get('delta',{}).get('content'):
                        first = choice['delta']['content'];break
                if first is not None: break
            require(first is not None,'actual delta absent')
        finally:
            if response is not None: response.close()
            connection.close()
            (self.out / 'cancel.partial.wire').write_bytes(raw)
        drained = self.drained('cancel-drained')
        require(drained['q4t_requests_aborted_total'] == 1,'actual cancel not settled')
        save(self.out / 'cancel.result.json',dict(first_delta=first,actual_abort=True,
                                                automatic_replay=False))

    def exercise(self):
        before = self.plan['reused_prior_answer']
        self.cancel()
        after = self.answer('seeded_after')
        greedy = self.answer('greedy')
        comparison = dict(before=before,after=after,greedy=greedy,
            fixed_seed_choice_identical=before['choice'] == after['choice'],
            fixed_seed_usage_identical=before['usage'] == after['usage'],
            original_unseeded_failure_preserved=True,one_preselected_seed=0,
            no_seed_search=True,original_failure_relabelled=False,
            comparison_across_model_processes=True,
            inference_limit='Prior cold request and this new model after cancellation; '
                            'not a within-process before/after pair or a proof of '
                            'the unique cause of the original unseeded answer.')
        save(self.out / 'comparison.json',comparison)
        self.same_model()
        final = self.drained('final-drained')
        require(final['q4t_requests_total'] == 3 and final['q4t_requests_success_total'] == 2
            and final['q4t_requests_aborted_total'] == 1 and
            final['q4t_requests_error_total'] == 0,'diagnostic accounting')
        return comparison

    def run(self):
        failure = cleanup = None
        def deadline(*_): raise TimeoutError('absolute diagnostic bound')
        prior = signal.signal(signal.SIGALRM,deadline)
        signal.alarm(LIMITS['seconds'])
        try:
            self.start();self.exercise()
        except BaseException:
            failure = traceback.format_exc()
        finally:
            try: self.cleanup()
            except BaseException: cleanup = traceback.format_exc()
            signal.alarm(0);signal.signal(signal.SIGALRM,prior)
            result = dict(status='OBSERVED_DIAGNOSTIC' if not failure and not cleanup else 'FAILED',
                failure=failure,cleanup_failure=cleanup,seconds=time.monotonic()-self.started,
                counts=self.counts,default_unchanged=all(sha(p)==h
                    for p,h in self.plan['protected'].items()),
                original_quality_failure_preserved=True,service_qualified=False)
            save(self.out / 'result.json',result);print(json.dumps(result))
        return int(failure is not None or cleanup is not None)


if __name__ == '__main__':
    os.umask(0o077)
    if sys.argv[1:] == ['prepare']: prepare()
    elif sys.argv[1:] == ['run']:
        raise SystemExit(Stage(json.loads((OUT / 'plan.json').read_bytes())).run())
    else: raise SystemExit('expected prepare or run')

#include <iostream>
#include "q4t/server/realtime_chat_plan.h"
#include "q4t/server/chat_prompt.h"
#include "q4t/server/output_schema.h"
#include "src/server/object_protocol.h"
int main() {
 using namespace q4t::server; using namespace object_detail;
 ChatPlanConfig c; c.model="qwen3.8-flash-next"; c.structured=true; c.max_len=8192;
 auto settings=DefaultRealtimeChatSettings(c, "");
 Json response; q4t::io::ParseJson(R"({"conversation":"none","input":[],"instructions":"Compute 6 * 7. Reply only 42.","tools":[],"tool_choice":"none","max_output_tokens":32})", &response, true);
 RealtimeChatPlan p; ChatPlanError e;
 auto s=PlanRealtimeChat(settings,response,Array(),c,&p,&e);
 if(!s){std::cerr<<s.message();return 1;}
 std::string prompt;std::vector<VisionItem> media;
 const auto& plan=p.generation;
 const auto& request=plan.chat.Request(plan.generation_request);
 s=PrepareChatPrompt(request,plan.chat.constraints,&prompt,&media,&e.param,&e.code,nullptr,false,plan.chat.async_tool_call_ids,plan.chat.responses_tool_media,plan.chat.HeaderTools(),plan.chat.tool_call_formats,plan.chat.prepared_source_data);
 if(!s){std::cerr<<s.message();return 2;}
 std::cout << OutputJson(Object({{"request",request},{"prompt",String(prompt)}}));
}

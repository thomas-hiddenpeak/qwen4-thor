import fcntl,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import profile_acceptance as q
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent;out=W/'combinations-01'
plan,result=read(out/'plan.json'),read(out/'result.json')
require(result['status']=='PASS_MEDIA_PREFILL_AFFECTED_COMBINATIONS' and result['counts']['starts']==1 and result['counts']['chats']==9 and result['seconds']<360,'bounded result')
for n,h in {**plan['sources'],**plan['protected']}.items():require(sha(ROOT/n)==h,'identity drift '+n)
require(sha(plan['binary'])==plan['binary_sha256'],'engine drift')
q.bundle.check_assets(plan['model'],plan['model_assets'])
exit=read(out/'lease/exit.json');queries=[json.loads(x) for x in (out/'lease/nvml-queries.jsonl').read_text().splitlines()];c=read(out/'cleanup.json')
require(exit['status']=='COMPLETED' and exit['child_returncode']==0 and exit['compute_backend']=='nvml' and exit['lease_inherited_by_child'],'strict guard')
require(queries and all(x.get('status')=='OK' and x.get('returncode')==0 for x in queries),'monitor')
require(c['remaining']==[] and c['model_exit']==0 and c['ports_released'] and c['lease_continuously_held'],'cleanup')
g=q.encrypted.foreground.base.lifecycle.guard;records=g.processes()
require(not any(records.get(int(pid),{}).get('start_ticks')==row['start_ticks'] for pid,row in c['owned'].items()),'owned process remains')
q.background.probe_ports((plan['port'],plan['operations_port']))
with g.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
a=dict(status='ACCEPT_MEDIA_PREFILL_AFFECTED_COMBINATIONS',binary_sha256=plan['binary_sha256'],counts=result['counts'],seconds=result['seconds'],nvml_queries=len(queries),cleanup_complete=True,default_unchanged=True,performance_claim=False,business=read(out/'business-checks.json'),private=read(out/'private-business-checks.json'))
save(out/'acceptance.json',a);print({k:v for k,v in a.items() if k not in ('business','private')})

"""One start/nine affected image, schema and private-cache requests after numerical fix."""
import argparse,copy,json,signal,sys,io,re
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_protocol import media_cache_acceptance as m
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent
LIMITS=dict(starts=1,chats=9,controls=1500,seconds=360)
ORDER=('image_uncached','image_write','image_hit','image_changed','image_append','schema_write','schema_hit','private_write','private_follow')
def requests():return {k:m.requests()[k] for k in ORDER}
class Stage(m.Stage):
 limits=LIMITS;request_templates=staticmethod(requests);baseline_first=False
 success_status='PASS_MEDIA_PREFILL_AFFECTED_COMBINATIONS'
 def business(self):
  rows=self.plan['requests'];values={}
  for label in ORDER[:-2]:values[label]=self.chat(label,rows[label],hit=label in ('image_hit','image_append','schema_hit'))
  for kind in ('image','schema'):
   a,b=values[kind+'_write'],values[kind+'_hit'];require(a.message==b.message and a.logprobs==b.logprobs,'cold/warm exact '+kind)
  old=W/'business-01';before=m.read_json(io.BytesIO((old/'base_image.wire').read_bytes()));current=values['image_uncached']
  require(current.message==before.message and current.logprobs==before.logprobs,'accepted full/new chunk image differs')
  a,b=read(old/'base_image-preflight.json'),read(self.out/'image_uncached-preflight.json')
  require(a['prompt']==b['prompt'] and a['token_ids']==b['token_ids'],'same image prompt')
  self.private_business(rows)
  log=(self.out/'candidate-model.log').read_text();proof={}
  for label in ORDER[:-2]:
   writes=re.findall(r'\[prefix-cache\] request='+re.escape(rows[label]['request_id'])+r' event=write prefix=(\d+) ttl=(\d+) saved=(\d+) bytes=(\d+)',log)
   restores=re.findall(r'\[session-cache\] request='+re.escape(rows[label]['request_id'])+r' event=restore prefix=(\d+) ms=\S+ error=(\S+) source=(\w+) layout=(\w+)',log)
   hit=label in ('image_hit','image_append','schema_hit')
   require(bool(writes)==(not hit and label!='image_uncached') and all(int(p)>=1024 and ttl=='1800' and saved=='1' and int(size)>0 for p,ttl,saved,size in writes),'SSD write '+label)
   if hit:require(restores==[(str(values[label].usage['prompt_tokens_details']['cached_tokens']),'none','shared','target')],'target restore '+label)
   else:require(not any(int(x[0])>0 for x in restores),'negative restores '+label)
   proof[label]=dict(writes=writes,restores=restores)
  save(self.out/'business-checks.json',dict(actual_requests=9,old_full_new_chunk_exact=True,cold_warm_exact=True,state_evidence=proof,private_restore=True))
def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run']);p.add_argument('--output',type=Path);p.add_argument('--plan',type=Path);a=p.parse_args()
 if a.mode=='prepare':
  a.binary=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t';a.port=18772
  m.responses.base.prepare(a,rows=requests(),limits=LIMITS,scope=__doc__)
  path=a.output/'plan.json';v=read(path)
  base=(ROOT/'build/q4t').resolve(strict=True);v['baseline']=dict(binary=str(base),sha256=sha(base))
  for n in [*m.FILES,m.DOCUMENT,'tools/serve_protocol/media_cache_acceptance.py',str(Path(__file__)),'docs/evidence/serve-media-state-cache-business-review-20261117/acceptance.json',str(W/'business-01/base_image.wire'),str(W/'business-01/base_image-preflight.json')]:v['sources'][n]=sha(ROOT/n)
  v['planned']=dict(starts=1,requests=9,accepted_baseline_replayed=False,performance_claim=False);save(path,v)
 else:
  def deadline(*_):raise TimeoutError('affected media combinations deadline')
  signal.signal(signal.SIGALRM,deadline);signal.setitimer(signal.ITIMER_REAL,320)
  with m.responses.base.lifecycle.child_subreaper():Stage(read(a.plan)).run()
if __name__=='__main__':main()

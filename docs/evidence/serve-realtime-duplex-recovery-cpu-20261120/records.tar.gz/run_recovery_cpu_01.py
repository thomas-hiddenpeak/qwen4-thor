from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parents[2];A=Path(__file__).parent;O=A/'recovery-cpu-01'
assert json.loads((A/'recovery-build-01/result.json').read_text())['status']=='BUILD_PASS'
O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
new=json.loads((A/'recovery-plan-01.json').read_text())['tests'];assert len(new)==18
old=[]
for name,names in [('new',new),('old',old)]:(O/(name+'.txt')).write_text('\n'.join(names)+'\n')
commands=[[str(R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests'),'--required-list',str(O/'new.txt')],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
files=['include/q4t/server/realtime_audio_queue.h','src/server/realtime_audio_queue.cpp','tests/server_realtime_audio_queue_test.cpp','src/server/chat_realtime.cpp','src/server/chat_realtime_conversation.cpp','src/server/chat_capabilities.cpp','src/server/realtime_chat_plan.cpp','include/q4t/server/realtime_chat_plan.h','include/q4t/server/chat_server.h','tests/server_realtime_chat_plan_test.cpp','src/server/realtime_wire_shape.cpp','include/q4t/server/realtime_shape.h','include/q4t/server/realtime_conversation_session.h','src/server/realtime_conversation_session.cpp','tests/server_realtime_conversation_session_test.cpp','include/q4t/server/realtime_conversation_input.h','src/server/realtime_conversation_input.cpp','tests/server_realtime_conversation_input_test.cpp','tests/server_realtime_conversation_test.cpp','src/server/realtime_conversation.cpp','include/q4t/server/realtime_conversation.h','src/server/realtime_transcription_session.cpp','include/q4t/server/realtime_transcription_session.h','tests/server_realtime_transcription_test.cpp','src/server/realtime_transcription_protocol.cpp','src/server/realtime_semantic_session.cpp','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake','tools/release/required_host_tests.txt','tools/serve_audit/inventory.json'];plan=dict(scope=json.loads((A/'recovery-plan-01.json').read_text())['scope'],limits=dict(tests=18,source_counterexamples=20,seconds=120,gpu_starts=0),tests=new+old,commands=commands,sources={n:sha(R/n) for n in files},binaries={cmd[0]:sha(Path(cmd[0])) for cmd in commands[:1]},protected={n:sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']})
save('plan.json',plan);start=time.monotonic();runs=[];status='PASS'
env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O),PYTHONDONTWRITEBYTECODE='1')
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,timeout=max(.1,120-(time.monotonic()-start)));(O/f'command-{i}.stdout').write_bytes(r.stdout);(O/f'command-{i}.stderr').write_bytes(r.stderr);runs.append(dict(command=cmd,returncode=r.returncode))
 if r.returncode:status='FAIL';break
assert all(sha(R/n)==h for n,h in plan['protected'].items());result=dict(status=status,seconds=time.monotonic()-start,commands=runs,tests=18 if status=='PASS' else None,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

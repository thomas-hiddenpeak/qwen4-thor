from pathlib import Path
import hashlib,json,subprocess,time,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';O=V/'voice-identity-diagnostic-build-01';O.mkdir(exist_ok=False);sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
original=(R/'tools/native_speaker/model_replay.cpp').read_text();prefix=original[:original.index('void SaveDevice(')];loader=original[original.index('int Replay('):original.index('  size_t maximum_workspace = 0;')];loader=loader.replace('cases->array.size() == 4','cases->array.size() == 3').replace('four frozen cases required','three recorded clips required')
body=r'''
  audio::SileroVad vad;
  Check(vad.Load(ReadFile(plan.GetString("vad"), audio::kVadFileBytes)));
  std::ofstream report(output / "windows.json");
  report << "[";
  size_t row = 0;
  for (size_t clip = 0; clip < 3; ++clip) {
    const auto& input = cases->array[clip];
    auto bytes = ReadFile(input.GetString("pcm"), 60 * 16000 * 4);
    Require(bytes.size() % 4 == 0 && trace::HexDigest(trace::Sha256(bytes)) ==
                input.GetString("pcm_sha256"), "recorded PCM identity");
    std::vector<float> pcm(bytes.size() / 4);
    std::memcpy(pcm.data(), bytes.data(), bytes.size());
    std::vector<audio::VadFrame> frames;
    Check(vad.Score(pcm, 60 * 16000, &frames));
    audio::VadChunkOptions options;
    options.max_samples = 60 * 16000;
    options.max_chunks = 8;
    std::vector<audio::VadChunk> chunks;
    Check(audio::SplitVadChunks(frames, pcm.size(), options, &chunks));
    std::vector<audio::SpeakerWindow> windows;
    Check(audio::PlanSpeakerWindows(chunks, pcm.size(), {48000, 12000, 32},
                                    &windows));
    Require(!windows.empty(), "actual source has no VAD windows");
    // Whole-clip identity is a diagnostic reference, never a substitute for
    // checking the production windows or evidence that multiple voices agree.
    windows.push_back({0, pcm.size(), 0, pcm.size()});
    for (size_t index = 0; index < windows.size(); ++index) {
      checkpoint();
      Require(row < 99, "embedding attempt bound");
      const auto& window = windows[index];
      auto audio = std::span(pcm).subspan(window.begin_sample,
                                          window.end_sample-window.begin_sample);
      audio::SpeakerFeatures features;
      Check(audio::ComputeSpeakerFeatures(audio, 16000, {}, &features));
      audio::SpeakerWorkspaceLayout layout;
      Check(audio::PlanSpeakerWorkspace(features.frames, 3001, 300ULL << 20,
                                        &layout));
      Device workspace(layout.bytes);
      audio::SpeakerRun run;
      Check(run.Begin(weights, features.mel, features.frames, workspace.value,
                       layout.bytes));
      for (int stage = 0; stage < 7; ++stage) {
        checkpoint(); Check(run.NextStage());
      }
      std::array<float, 192> embedding;
      Check(run.Finish(embedding));
      Save<float>(output / ("embedding-" + std::to_string(row) + ".f32"), embedding);
      if (row) report << ",";
      report << "{\"row\":" << row++ << ",\"clip\":" << clip
             << ",\"index\":" << index << ",\"whole\":"
             << (index+1 == windows.size() ? "true" : "false")
             << ",\"begin\":" << window.begin_sample << ",\"end\":" << window.end_sample
             << ",\"core_begin\":" << window.core_begin_sample
             << ",\"core_end\":" << window.core_end_sample << "}";
    }
  }
  report << "]\n"; report.close(); Require(report.good(), "window receipt");
  Cuda(cudaDeviceSynchronize());
  std::ofstream result(output / "result.json");
  result << "{\"status\":\"OBSERVATIONS_NOT_VERIFICATION_ACCEPTANCE\","
         << "\"speaker_loads\":1,\"vad_loads\":1,\"embeddings\":" << row
         << ",\"seconds\":" << std::chrono::duration<double>(Clock::now()-started).count()
         << "}\n";
  result.close(); Require(result.good(), "result write"); return 0;
}
}  // namespace
int main(int argc, char** argv) {
  try {
    Require(argc == 4, "usage: diagnostic ASSETS PLAN OUTPUT");
    return Replay(argv[1], argv[2], argv[3]);
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n'; return 1;
  }
}
'''
source=O/'replay.cpp';source.write_text(prefix.replace('#include "q4t/audio/speaker_model.h"','#include "q4t/audio/speaker_model.h"\n#include "q4t/audio/diarization.h"')+loader+body)
names=['src/audio/speaker_config.cpp','src/audio/speaker_layout.cpp','src/audio/speaker_features.cpp','src/audio/speaker_model.cu','src/audio/vad.cpp','src/audio/vad_chunks.cpp','src/audio/diarization.cpp'];objects=[];provenance=[]
manifest=json.loads((B/'generated/q4t/server/chat_protocol_sources.json').read_text())
for name in names:
 p=B/'CMakeFiles/q4t_model.dir'/(name+'.o');assert p.is_file() and sha(R/name)==manifest[name];objects.append(str(p));provenance.append({'object':str(p),'sha256':sha(p),'source':name,'source_sha256':sha(R/name)})
prior=json.loads((V/'base-compute-build-01/plan.json').read_text())
for i in [6,8,9,10]:
 p=V/'base-compute-build-01'/f'{i}.o';cmd=prior['commands'][i];name=cmd[cmd.index('-c')+1];assert sha(R/name)==prior['sources'][name];objects.append(str(p));provenance.append({'object':str(p),'sha256':sha(p),'source':name,'source_sha256':sha(R/name)})
assert shutil.disk_usage(R).free>256<<20;nv='/usr/local/cuda-13.3/bin/nvcc';binary=O/'q4t_voice_identity_diagnostic'
commands=[[nv,'-std=c++23','-O3','-arch=sm_110a','-ccbin','g++-14','-Iinclude','-Ithird_party','-Xcompiler=-Wall,-Wextra,-Werror','-c',str(source),'-o',str(O/'replay.o')],[nv,'-arch=sm_110a','-ccbin','g++-14',str(O/'replay.o'),*objects,'-lcublasLt','-lpthread','-o',str(binary)]]
(O/'plan.json').write_text(json.dumps({'original_source_sha256':sha(R/'tools/native_speaker/model_replay.cpp'),'derived_source_sha256':sha(source),'provenance':provenance,'commands':commands,'gpu':0},indent=2)+'\n');start=time.monotonic();rows=[]
for i,cmd in enumerate(commands):
 with (O/f'{i}.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'command':cmd,'exit_code':r.returncode})
 if r.returncode:break
result={'status':'PASS_BUILD_ONLY' if r.returncode==0 else 'FAILED_BUILD','seconds':time.monotonic()-start,'warnings':sum(p.read_text().count('warning:') for p in O.glob('*.log')),'steps':rows}
if not r.returncode:result['binary_sha256']=sha(binary)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)

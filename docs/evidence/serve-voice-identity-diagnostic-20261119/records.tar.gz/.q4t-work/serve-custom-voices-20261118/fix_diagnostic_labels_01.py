from pathlib import Path
import json
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
p=R/'include/q4t/server/request_diagnostics.h';s=p.read_text();s=s.replace('  void Stage(const char* value) {\n    stage_ = value;\n    const std::string_view name(value);','  void Stage(std::string_view value) {\n    CopyLabel(stage_, value);\n    const auto name = value;');s=s.replace('  void Outcome(const char* value, const char* reason) {\n    outcome_ = value;\n    reason_ = reason;\n  }','  void Outcome(std::string_view value, std::string_view reason) noexcept {\n    CopyLabel(outcome_, value);\n    CopyLabel(reason_, reason);\n  }');s=s.replace(' private:\n  static ProgressWait ToProgressWait',' private:\n  // Request scopes often outlive the temporary error that supplied a label.\n  // Own bounded copies without allocating on a business failure path. Never\n  // turn an oversized label into a truncated but apparently valid error code.\n  template <size_t N>\n  static void CopyLabel(char (&out)[N], std::string_view value) noexcept {\n    constexpr std::string_view overflow = "diagnostic_label_too_long";\n    static_assert(N > overflow.size());\n    if (value.size() >= N) value = overflow;\n    std::copy(value.begin(), value.end(), out);\n    out[value.size()] = \'\\0\';\n  }\n  static ProgressWait ToProgressWait');s=s.replace('  const char* stage_ = "validation";\n  const char* outcome_ = "error";\n  const char* reason_ = "handler_error";','  char stage_[128] = "validation";\n  char outcome_[128] = "error";\n  char reason_[128] = "handler_error";');write(p,s)
p=R/'tests/server_request_diagnostics_test.cpp';s=p.read_text();s+='''
Q4T_TEST(request_diagnostics_owns_labels_past_mutation_and_error_lifetime) {
  FILE* file = std::tmpfile();
  Q4T_CHECK(file);
  {
    q4t::server::RequestDiagnostics d(file);
    {
      std::string stage = "voice_condition_embedding";
      std::string outcome = "error";
      std::string reason = "voice_speaker_mismatch";
      d.Stage(stage);
      d.Outcome(outcome, reason);
      // Mutate the original storage before it is released. A borrowed pointer
      // would record these replacements or freed memory at request teardown.
      std::fill(stage.begin(), stage.end(), 'x');
      std::fill(outcome.begin(), outcome.end(), 'y');
      std::fill(reason.begin(), reason.end(), 'z');
    }
  }
  const auto text = Read(file);
  std::fclose(file);
  const auto terminal = text.substr(text.find("event=end"));
  Q4T_CHECK(terminal.find("stage=voice_condition_embedding ") != terminal.npos);
  Q4T_CHECK(terminal.find("outcome=error reason=voice_speaker_mismatch ") !=
            terminal.npos);
  return true;
}

Q4T_TEST(request_diagnostics_label_overflow_is_bounded_and_does_not_throw) {
  FILE* file = std::tmpfile();
  Q4T_CHECK(file);
  {
    q4t::server::RequestDiagnostics d(file);
    static_assert(noexcept(d.Outcome("success", "completed")));
    const std::string label(4096, 'z');
    d.Stage(label);
    d.Outcome(label, label);
  }
  const auto text = Read(file);
  std::fclose(file);
  Q4T_CHECK(text.size() < 2048 && text.find("zzz") == text.npos);
  Q4T_CHECK(text.find("outcome=diagnostic_label_too_long "
                      "reason=diagnostic_label_too_long ") != text.npos);
  return true;
}
''';write(p,s)
required=['request_diagnostics_owns_labels_past_mutation_and_error_lifetime','request_diagnostics_label_overflow_is_bounded_and_does_not_throw','request_diagnostics_attribution_failed_sink_does_not_fail_business','request_diagnostics_terminal_and_reuse','request_diagnostics_wait_accounting']
plan=dict(scope='Own terminal diagnostic labels; no borrowed dynamic error or allocation on Outcome',required=required,cases=5,seconds=60,gpu=0,disk_reserve_bytes=256<<20)
write(V/'diagnostic-labels-plan-01.json',json.dumps(plan,indent=2)+'\n')
update='声纹诊断18个原生向量已完成（1.387秒、严格租约正常）：授权完整3秒\n窗口间最低余弦0.049，整段授权/样本0.439，不能归因短窗口或直接放宽。\n冻结官方CPU同18窗口/180秒独立前端+模型复核；门槛保持0.65。\n同时修复RequestDiagnostics对动态stage/outcome/reason的借用，改为\n有界自有存储，超长标签明确标记且Outcome不分配。冻结5 CPU/60秒。\n'
for name,marker,text in [('docs/STATUS.md','## 正在推进\n\n',update+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19：声纹低相似度复核与日志所有权修复\n\n'+update+'\n为什么：真实HTTP终态reason已出现释放后乱码；实际声纹差异远超\n轻微门槛偏差。下一步官方算术复核及针对CPU，不调整注册保护。\n\n')]:
 p=R/name;write(p,p.read_text().replace(marker,marker+text,1))

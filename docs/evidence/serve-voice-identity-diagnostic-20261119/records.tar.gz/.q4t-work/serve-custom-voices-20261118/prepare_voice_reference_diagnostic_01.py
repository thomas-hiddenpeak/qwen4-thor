from pathlib import Path
import json,hashlib
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-reference-diagnostic-01';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
source=R/'tools/native_speaker/model_reference.py';text=source.read_text();text=text[:text.index('    args.output.mkdir(exist_ok=False)')]
text+=r'''
    plan = json.loads(args.plan.read_text())
    assert plan['limits'] == dict(cpu_loads=1, gpu_loads=0, cases=18, seconds=180, artifact_bytes=8388608)
    for name, expected in plan['identities'].items():
        assert digest(Path(name)) == expected, 'source/input drift: '+name
    rows = json.loads((args.native/'native/windows.json').read_text())
    assert len(rows) == 18
    args.output.mkdir(exist_ok=False)
    vectors=[]; checks=[]
    for row in rows:
        assert time.monotonic()-started < 160
        pcm=np.fromfile(args.native/f"decoded/case-{row['clip']}/pcm.f32", '<f4')
        pcm=pcm[row['begin']:row['end']]
        with torch.inference_mode():
            mel=feature(torch.from_numpy(pcm.copy()).unsqueeze(0))
            mel=mel-mel.mean(dim=1,keepdim=True)
            vector=model(mel).reshape(192).numpy().copy()
        native=np.fromfile(args.native/f"native/embedding-{row['row']}.f32",'<f4')
        assert vector.shape==native.shape==(192,) and np.isfinite(vector).all()
        a=vector.astype(np.float64);b=native.astype(np.float64)
        cosine=float(a@b/np.linalg.norm(a)/np.linalg.norm(b))
        relative=float(np.linalg.norm(a-b)/np.linalg.norm(a))
        checks.append(dict(row=row['row'],cosine=cosine,relative_l2=relative,passed=relative<=.001 and cosine>=.999999))
        vectors.append(a/np.linalg.norm(a))
        (args.output/f"embedding-{row['row']}.f32").write_bytes(vector.astype('<f4').tobytes())
    matrix=[[float(a@b) for b in vectors] for a in vectors]
    assert not torch.cuda.is_initialized()
    result=dict(status='PASS_REFERENCE_COMPUTATION' if all(x['passed'] for x in checks) else 'FAIL_REFERENCE_COMPUTATION',seconds=time.monotonic()-started,cpu_loads=1,gpu_loads=0,checks=checks,cosines=matrix,cuda_initialized=False,source_sha256=sources,torch=torch.__version__,checkpoint_sha256=digest(args.checkpoint),max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','seconds','cuda_initialized')}),flush=True)
    assert all(x['passed'] for x in checks)

if __name__=='__main__':main()
'''
script=O/'reference.py';script.write_text(text)
old=json.loads((R/'.q4t-work/serve-diarization-20261118/component-01/plan.json').read_text());native=V/'voice-identity-diagnostic-01/run'
identities={n:h for n,h in old['identities'].items() if '/metadata' in n or '/refenv/' in n or n.endswith('embedding_model.ckpt')}
for p in [script,source,*native.glob('decoded/case-*/pcm.f32'),*native.glob('native/embedding-*.f32'),native/'native/windows.json']:
 identities[str(p)]=sha(p)
plan=dict(limits=dict(cpu_loads=1,gpu_loads=0,cases=18,seconds=180,artifact_bytes=8388608),identities=identities,comparison=dict(relative_l2=.001,cosine=.999999),threshold_unchanged=.65)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
cmd=[old['reference_python'],'-I','-B',str(script),'--source',old['source'],'--mask-source',old['mask_source'],'--checkpoint',old['checkpoint'],'--plan',str(O/'plan.json'),'--native',str(native),'--output',str(O/'run')]
(O/'command.json').write_text(json.dumps(cmd,indent=2)+'\n');print(O)

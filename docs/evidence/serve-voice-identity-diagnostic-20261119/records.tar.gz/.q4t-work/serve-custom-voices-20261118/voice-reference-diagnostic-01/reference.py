"""Exact fixed upstream ECAPA definitions on CPU, without optional pipelines.

Only unrelated imports are omitted; selected AST definitions remain unchanged.
The reference consumes native Fbank operands for isolated model arithmetic and
independently produces official Fbank matrices for the preprocessing check.
"""
import __future__
import argparse
import ast
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import resource
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['source', 'mask-source', 'checkpoint', 'plan', 'native', 'output']:
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    import numpy as np
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_float32_matmul_precision('highest')
    torch.backends.mkldnn.enabled = False
    started = time.monotonic()
    receipt = json.loads((args.source/'source-receipt.json').read_bytes())
    assert receipt['source_revision'] == 'c0241278f93ef02cd5191f03caf4e5f8e1292bf6'
    identities = {row['name']: row['sha256'] for row in receipt['records']}
    scope = dict(torch=torch, nn=nn, F=F, math=math,
                 logger=logging.getLogger(__name__),
                 fwd_default_precision=lambda **unused: lambda fn: fn)
    sources = {}

    def extract(path, names, expected):
        assert digest(path) == expected
        tree = ast.parse(path.read_text(), filename=str(path))
        nodes = [node for node in tree.body
                 if isinstance(node, (ast.ClassDef, ast.FunctionDef))
                 and node.name in names]
        assert {node.name for node in nodes} == set(names)
        fragment = ast.Module(body=nodes, type_ignores=[])
        exec(compile(fragment, str(path), 'exec',
                     flags=__future__.annotations.compiler_flag), scope)
        sources[str(path)] = expected

    extract(args.mask_source, ['length_to_mask'],
            '48e7013220bb8a7f4f073de76124245d5cf0ef20fcf95497f72766dc2ecc0b6f')
    name = 'speechbrain/nnet/CNN.py'
    extract(args.source/name, ['Conv1d', 'get_padding_elem'], identities[name])
    scope['_Conv1d'] = scope['Conv1d']
    name = 'speechbrain/nnet/normalization.py'
    extract(args.source/name, ['BatchNorm1d'], identities[name])
    scope['_BatchNorm1d'] = scope['BatchNorm1d']
    name = 'speechbrain/lobes/models/ECAPA_TDNN.py'
    extract(args.source/name, ['Conv1d', 'BatchNorm1d', 'TDNNBlock',
        'Res2NetBlock', 'SEBlock', 'AttentiveStatisticsPooling',
        'SERes2NetBlock', 'ECAPA_TDNN'], identities[name])
    for name, names in [
        ('speechbrain/processing/features.py',
         ['STFT', 'Filterbank', 'Deltas', 'ContextWindow', 'spectral_magnitude']),
        ('speechbrain/lobes/features.py', ['Fbank'])]:
        extract(args.source/name, names, identities[name])
    assert args.checkpoint.stat().st_size == 83316686
    assert digest(args.checkpoint) == (
        '0575cb64845e6b9a10db9bcb74d5ac32b326b8dc90352671d345e2ee3d0126a2')
    state = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    assert len(state) == 231
    model = scope['ECAPA_TDNN'](input_size=80,
        channels=[1024, 1024, 1024, 1024, 3072], lin_neurons=192).eval()
    model.load_state_dict(state, strict=True)
    del state
    feature = scope['Fbank'](n_mels=80).eval()

    plan = json.loads(args.plan.read_text())
    assert plan['limits'] == dict(cpu_loads=1, gpu_loads=0, cases=18, seconds=180, artifact_bytes=8388608)
    for name, expected in plan['identities'].items():
        assert digest(Path(name)) == expected, 'source/input drift: '+name
    rows = json.loads((args.native/'native/windows.json').read_text())
    assert len(rows) == 18
    args.output.mkdir(exist_ok=False)
    vectors=[]; checks=[]
    for row in rows:
        assert time.monotonic()-started < 160
        pcm=np.fromfile(args.native/f"decoded/case-{row['clip']}/pcm.f32", '<f4')
        pcm=pcm[row['begin']:row['end']]
        with torch.inference_mode():
            mel=feature(torch.from_numpy(pcm.copy()).unsqueeze(0))
            mel=mel-mel.mean(dim=1,keepdim=True)
            vector=model(mel).reshape(192).numpy().copy()
        native=np.fromfile(args.native/f"native/embedding-{row['row']}.f32",'<f4')
        assert vector.shape==native.shape==(192,) and np.isfinite(vector).all()
        a=vector.astype(np.float64);b=native.astype(np.float64)
        cosine=float(a@b/np.linalg.norm(a)/np.linalg.norm(b))
        relative=float(np.linalg.norm(a-b)/np.linalg.norm(a))
        checks.append(dict(row=row['row'],cosine=cosine,relative_l2=relative,passed=relative<=.001 and cosine>=.999999))
        vectors.append(a/np.linalg.norm(a))
        (args.output/f"embedding-{row['row']}.f32").write_bytes(vector.astype('<f4').tobytes())
    matrix=[[float(a@b) for b in vectors] for a in vectors]
    assert not torch.cuda.is_initialized()
    result=dict(status='PASS_REFERENCE_COMPUTATION' if all(x['passed'] for x in checks) else 'FAIL_REFERENCE_COMPUTATION',seconds=time.monotonic()-started,cpu_loads=1,gpu_loads=0,checks=checks,cosines=matrix,cuda_initialized=False,source_sha256=sources,torch=torch.__version__,checkpoint_sha256=digest(args.checkpoint),max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','seconds','cuda_initialized')}),flush=True)
    assert all(x['passed'] for x in checks)

if __name__=='__main__':main()

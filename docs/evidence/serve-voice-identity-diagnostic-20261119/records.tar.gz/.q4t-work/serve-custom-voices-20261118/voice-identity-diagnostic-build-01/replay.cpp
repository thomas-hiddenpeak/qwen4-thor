// Fixed real ECAPA numerical replay with caller-owned stages and strict lease.
#include <cuda_runtime_api.h>
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>

#include <bit>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>

#include "q4t/audio/speaker_model.h"
#include "q4t/audio/diarization.h"
#include "q4t/audio/speaker_features.h"
#include "q4t/runtime/system_memory.h"
#include "q4t/trace/sha256.h"

namespace {
namespace fs = std::filesystem;
using Clock = std::chrono::steady_clock;
using namespace q4t;
using C = audio::SpeakerConfig;

void Require(bool ok, const std::string& message) {
  if (!ok) throw std::runtime_error(message);
}
void Check(const Status& status) { Require(status.ok(), status.message()); }
void Check(const audio::SpeakerComputeResult& result) {
  Require(result.ok(), result.status.message());
}
void Cuda(cudaError_t result) {
  Require(result == cudaSuccess, cudaGetErrorString(result));
}

struct Fd {
  int value;
  ~Fd() {
    if (value >= 0) close(value);
  }
};
struct Device {
  void* value = nullptr;
  explicit Device(size_t bytes) { Cuda(cudaMalloc(&value, bytes)); }
  ~Device() {
    if (value) (void)cudaFree(value);
  }
  Device(const Device&) = delete;
  Device& operator=(const Device&) = delete;
};

std::vector<uint8_t> ReadFile(const fs::path& path, size_t limit) {
  Fd fd{open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK)};
  struct stat before {
  }, after{};
  Require(fd.value >= 0 && !fstat(fd.value, &before) &&
              S_ISREG(before.st_mode) && before.st_size >= 0 &&
              static_cast<uint64_t>(before.st_size) <= limit,
          "invalid file " + path.filename().string());
  std::vector<uint8_t> bytes(static_cast<size_t>(before.st_size));
  size_t offset = 0;
  while (offset < bytes.size()) {
    const auto count = read(fd.value, bytes.data() + offset,
                            std::min(size_t{1 << 20}, bytes.size() - offset));
    if (count < 0 && errno == EINTR) continue;
    Require(count > 0, "short file read");
    offset += static_cast<size_t>(count);
  }
  Require(!fstat(fd.value, &after) && before.st_size == after.st_size &&
              before.st_mtim.tv_sec == after.st_mtim.tv_sec &&
              before.st_mtim.tv_nsec == after.st_mtim.tv_nsec &&
              before.st_ctim.tv_sec == after.st_ctim.tv_sec &&
              before.st_ctim.tv_nsec == after.st_ctim.tv_nsec,
          "file changed during read");
  return bytes;
}
std::string TextFile(const fs::path& path, size_t limit) {
  const auto bytes = ReadFile(path, limit);
  return {reinterpret_cast<const char*>(bytes.data()), bytes.size()};
}
io::Json Json(const std::string& text) {
  io::Json result;
  Check(io::ParseJson(text, &result, false, {.reject_duplicate_keys = true}));
  return result;
}
template <typename T>
void Save(const fs::path& path, std::span<const T> values) {
  std::ofstream file(path, std::ios::binary | std::ios::out);
  file.write(reinterpret_cast<const char*>(values.data()), values.size_bytes());
  file.close();
  Require(file.good(), "output write failed");
}
int Replay(const fs::path& assets, const fs::path& plan_path,
           const fs::path& output) {
  const char* lease = std::getenv("Q4T_MANAGED_LEASE_FD");
  Require(lease && *lease, "strict GPU lease required");
  char* end = nullptr;
  const long lease_fd = std::strtol(lease, &end, 10);
  struct stat lock_stat {};
  Require(end && !*end && lease_fd >= 0 && lease_fd < 1048576 &&
              !fstat(lease_fd, &lock_stat) && S_ISREG(lock_stat.st_mode) &&
              !flock(lease_fd, LOCK_EX | LOCK_NB),
          "inherited lease unavailable");
  const auto started = Clock::now();
  const auto deadline = started + std::chrono::seconds(180);
  const auto checkpoint = [&] {
    Require(Clock::now() < deadline, "speaker replay time budget exceeded");
  };
  const auto plan = Json(TextFile(plan_path, 1 << 20));
  const auto* cases = plan.GetArray("cases");
  Require(cases && cases->array.size() == 3, "three recorded clips required");
  Require(!fs::exists(output) && fs::create_directories(output),
          "fresh output required");
  Require(runtime::ReadSystemMemory().CanAllocate(2ULL << 30),
          "insufficient observed unified RAM for speaker qualification");
  Check(audio::ValidateSpeakerConfig(
      Json(TextFile(assets / "config.json", 8192))));
  auto file = ReadFile(assets / "model.safetensors", C::kFileBytes);
  Require(file.size() == C::kFileBytes &&
              trace::HexDigest(trace::Sha256(file)) == C::kWeightSha256,
          "speaker checkpoint identity differs");
  static_assert(std::endian::native == std::endian::little);
  uint64_t header_bytes = 0;
  std::memcpy(&header_bytes, file.data(), sizeof(header_bytes));
  Require(header_bytes == C::kHeaderBytes, "speaker header differs");
  audio::SpeakerTensorLayout tensor_layout;
  Check(audio::ParseSpeakerTensorLayout(
      Json(std::string(reinterpret_cast<const char*>(file.data() + 8),
                       header_bytes)),
      C::kWeightBytes, &tensor_layout));
  Device device_weights(C::kWeightBytes);
  Cuda(cudaMemcpy(device_weights.value, file.data() + 8 + header_bytes,
                  C::kWeightBytes, cudaMemcpyHostToDevice));
  std::vector<uint8_t>().swap(file);
  audio::SpeakerDeviceWeights weights;
  Check(audio::BindSpeakerDeviceWeights(device_weights.value, C::kWeightBytes,
                                        tensor_layout, &weights));

  audio::SileroVad vad;
  Check(vad.Load(ReadFile(plan.GetString("vad"), audio::kVadFileBytes)));
  std::ofstream report(output / "windows.json");
  report << "[";
  size_t row = 0;
  for (size_t clip = 0; clip < 3; ++clip) {
    const auto& input = cases->array[clip];
    auto bytes = ReadFile(input.GetString("pcm"), 60 * 16000 * 4);
    Require(bytes.size() % 4 == 0 && trace::HexDigest(trace::Sha256(bytes)) ==
                input.GetString("pcm_sha256"), "recorded PCM identity");
    std::vector<float> pcm(bytes.size() / 4);
    std::memcpy(pcm.data(), bytes.data(), bytes.size());
    std::vector<audio::VadFrame> frames;
    Check(vad.Score(pcm, 60 * 16000, &frames));
    audio::VadChunkOptions options;
    options.max_samples = 60 * 16000;
    options.max_chunks = 8;
    std::vector<audio::VadChunk> chunks;
    Check(audio::SplitVadChunks(frames, pcm.size(), options, &chunks));
    std::vector<audio::SpeakerWindow> windows;
    Check(audio::PlanSpeakerWindows(chunks, pcm.size(), {48000, 12000, 32},
                                    &windows));
    Require(!windows.empty(), "actual source has no VAD windows");
    // Whole-clip identity is a diagnostic reference, never a substitute for
    // checking the production windows or evidence that multiple voices agree.
    windows.push_back({0, pcm.size(), 0, pcm.size()});
    for (size_t index = 0; index < windows.size(); ++index) {
      checkpoint();
      Require(row < 99, "embedding attempt bound");
      const auto& window = windows[index];
      auto audio = std::span(pcm).subspan(window.begin_sample,
                                          window.end_sample-window.begin_sample);
      audio::SpeakerFeatures features;
      Check(audio::ComputeSpeakerFeatures(audio, 16000, {}, &features));
      audio::SpeakerWorkspaceLayout layout;
      Check(audio::PlanSpeakerWorkspace(features.frames, 3001, 300ULL << 20,
                                        &layout));
      Device workspace(layout.bytes);
      audio::SpeakerRun run;
      Check(run.Begin(weights, features.mel, features.frames, workspace.value,
                       layout.bytes));
      for (int stage = 0; stage < 7; ++stage) {
        checkpoint(); Check(run.NextStage());
      }
      std::array<float, 192> embedding;
      Check(run.Finish(embedding));
      Save<float>(output / ("embedding-" + std::to_string(row) + ".f32"), embedding);
      if (row) report << ",";
      report << "{\"row\":" << row++ << ",\"clip\":" << clip
             << ",\"index\":" << index << ",\"whole\":"
             << (index+1 == windows.size() ? "true" : "false")
             << ",\"begin\":" << window.begin_sample << ",\"end\":" << window.end_sample
             << ",\"core_begin\":" << window.core_begin_sample
             << ",\"core_end\":" << window.core_end_sample << "}";
    }
  }
  report << "]\n"; report.close(); Require(report.good(), "window receipt");
  Cuda(cudaDeviceSynchronize());
  std::ofstream result(output / "result.json");
  result << "{\"status\":\"OBSERVATIONS_NOT_VERIFICATION_ACCEPTANCE\","
         << "\"speaker_loads\":1,\"vad_loads\":1,\"embeddings\":" << row
         << ",\"seconds\":" << std::chrono::duration<double>(Clock::now()-started).count()
         << "}\n";
  result.close(); Require(result.good(), "result write"); return 0;
}
}  // namespace
int main(int argc, char** argv) {
  try {
    Require(argc == 4, "usage: diagnostic ASSETS PLAN OUTPUT");
    return Replay(argv[1], argv[2], argv[3]);
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n'; return 1;
  }
}

"""Archive public delivery receipts without copying private state or payloads."""
import json
import re
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_service.package import read, require, save, sha

W = Path(__file__).resolve().parent
OUT = ROOT / 'docs/evidence/serve-input-attribution-delivery-20261116'
result = read(W / 'delivery-01/result.json')
current = result['publication']['current']
require(result['status'] == 'PASS_INPUT_ATTRIBUTION_DELIVERED' and
        result['publication']['revision'] == 166 and
        result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0,
        'delivery not accepted')
for name, key in [('q4t', 'engine_binary_sha256'),
                  ('q4t.release.json', 'engine_release_sha256'),
                  ('service.release.json', 'service_release_sha256'),
                  ('service.acceptance.json', 'service_acceptance_sha256')]:
    require(sha(ROOT / 'build/.q4t-publication/current' / name) == current[key], 'default identity drift')

secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)

for policy in ('build/service/engine/client-policy.json', 'build/service/gateway-policy.json'):
    collect(read(ROOT / policy))
files = [(p, 'delivery-01/' + p.name) for p in (W / 'delivery-01').iterdir()
         if p.is_file() and not p.is_symlink()]
files += [(p, 'publication-archive-01/' + p.name)
          for p in (W / 'publication-archive-01').iterdir()
          if p.is_file() and not p.is_symlink()]
for name in ('archive_delivery.py', 'deliver.py', 'run_delivery.py',
             'archive_generations.py', 'publication-archive-prepared.json',
             'publication-archive-applied.json'):
    files.append((W / name, name))
for stem in ('delivery-prepare-01', 'delivery-run-01', 'publication-archive-01', 'publication-archive-02'):
    for extension in ('json', 'stdout', 'stderr'):
        files.append((W / (stem + '.' + extension), stem + '.' + extension))
for path, _ in files:
    raw = path.read_bytes()
    require(not any(secret in raw for secret in secrets), 'secret in public evidence')
    require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', raw), 'private key in evidence')
OUT.mkdir()
with tarfile.open(OUT / 'delivery.tar.gz', 'w:gz') as archive:
    for path, name in sorted(files, key=lambda item: item[1]):
        archive.add(path, arcname=name, recursive=False)
(OUT / 'delivery-01').mkdir()
for name in ('result.json', 'plan.json', 'recovery-anchor.json'):
    (OUT / 'delivery-01' / name).write_bytes((W / 'delivery-01' / name).read_bytes())
save(OUT / 'acceptance.json', dict(
    status='ACCEPT_INPUT_ATTRIBUTION_DELIVERY', revision=166,
    current=current, commands=len(result['commands']), seconds=result['seconds'],
    new_gpu_starts=0, state='STOPPED',
    core_client_outer_state_preserved=True, profile_budget_preserved=True,
    retained_anchor_generation=result['retained_anchor_generation'],
    files=len(files), archive_sha256=sha(OUT / 'delivery.tar.gz'),
    secret_scan_matches=0, remaining_master_tasks_active=True))
(OUT / 'README.md').write_text(f'''# 标准输入归属与 Responses 默认合同可回退发行 rev166

默认引擎7a23cb30、正式服务包0bbfd5e6，generation
{current['generation_sha256']}。17项STOPPED检查通过，{result['seconds']:.3f}秒，
0新增GPU：保留锚点、正式发布、新恢复周期、实际整根回退再前进及
默认check/status/observe/profiles/version/outer/publication核对。

Chat安全归属按客户端摘要记录、JSON/SSE/存储返回实际default档位，
Responses省略/null使用medium且旧queued任务保留已接受effort和归属。
18项C++、schema/native对照及实际六种业务通过；两个驱动投影失败
保留并按实际wire重验，原生CPU删除残留自有对象且确认404。精确主轻
和保留/正式包业务回退通过。全部控制、四个原生程序及客户端字节不变。

逐命令core/client/outer状态保持，容量/Key/配额不变；主轻身份迁移
保持历史/预算/冷却/配置，新版本周期保留前驱。最终STOPPED，outer
已启用且累计0启动。rev158默认/状态备份及两个无活动引用generation
可恢复归档保留，不删除包或证据。首次归档因本轮工作目录组写权限
被拒，收紧该目录权限后通过；失败原记录保留，无业务或默认被改动。
密钥/私钥扫描0命中。

保留98b4b47e为旧v12控制/当前引擎；自动恢复保持现代根，人工整根
回退旧入口无outer仍须修复，不是独立旧引擎回退。PR32检查和实际
合main待完成。其余Chat字段、媒体缓存/后端、客户端/资源与冷启动
等全部33项master继续，不宣称完整兼容、性能或长稳通过。
''')
print(json.dumps(dict(status='ACCEPT_DELIVERY', revision=166,
                      files=len(files), secret_scan_matches=0)))

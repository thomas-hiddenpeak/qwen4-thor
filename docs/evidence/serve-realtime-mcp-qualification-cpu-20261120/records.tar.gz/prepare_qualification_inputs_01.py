"""Freeze actual leaves and complete runtime delta; no qualification issued."""
from pathlib import Path
import hashlib,json,sys,gzip,base64
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_recovery import ledger,profile_record
from tools.serve_service.package import read,sha,save,require
O=W/'qualification-inputs-01';O.mkdir(mode=0o700)
D=R/'.q4t-work/serve-realtime-duplex-20261120'
previous=D/'composed-profiles-01/qualified'
newplan=read(W/'sdk-business-04/plan.json');oldplan=read(D/'cancel-usage-runtime-01/plan.json');newbuild=read(W/'session-runtime-01/plan.json')
a,b=oldplan['sources'],newbuild['sources']
review=dict(previous_binary='ecd6cc23bd768a81e3fbd3fd1e59543176dc329e2ae7c8378956f09ffafe5580',previous_protocol='f0c82ef97660964b63fb5a245a151af98d667b43478f1c367364db7df8ac5f11',candidate_binary=newplan['identity']['binary_sha256'],candidate_protocol=newplan['identity']['protocol_sha256'],changed={n:dict(before=a[n],after=b[n]) for n in a.keys()&b.keys() if a[n]!=b[n]},added={n:b[n] for n in b.keys()-a.keys()},removed={n:a[n] for n in a.keys()-b.keys()},unchanged_count=sum(a[n]==b[n] for n in a.keys()&b.keys()),native_cpu_sha256=sha(R/'docs/evidence/serve-realtime-mcp-session-cpu-20261120/acceptance.json'),lifecycle_cpu_sha256=sha(R/'docs/evidence/serve-realtime-mcp-lifecycle-cpu-20261120/acceptance.json'),actual_fault_acceptance_sha256=sha(W/'sdk-business-04/acceptance.json'),prior_registry_sha256=sha(previous/'registry.json'),model_quality_repaired=False,old_failed_answers_preserved=True)
require(not review['removed'] and len(review['changed'])==15 and len(review['added'])==16 and review['unchanged_count']==970,'exact complete runtime source delta')
for n,h in b.items():require(sha(R/n)==h,'compiled source changed')
save(O/'source-review.json',review)
summary={};sources={}
for name in ('primary','light'):
 original=W/('sdk-business-02' if name=='primary' else 'sdk-business-03')
 repair=W/('sdk-business-03' if name=='primary' else 'sdk-business-04')
 def witness(stage):
  p=stage/(name+'-mcp-observed.json')
  return read(p) if p.exists() else dict(session=read(stage/(name+'-mcp.sdk.json')),remote=read(stage/(name+'-peer-results.json')),before=None,after=None)
 data=dict(source=newplan['document_source'],original=witness(original),repair=witness(repair))
 leaves={}
 for label,stage in [('original',original),('repair',repair)]:
  receipt=read(stage/(name+'-mcp.sdk.json'));journal=[json.loads(l) for l in (stage/(name+'-mcp.events.jsonl')).read_text().splitlines()]
  require(receipt['events']==journal,'journal mismatch')
  plan=read(stage/'plan.json');require(plan['identity']==newplan['identity'],'actual backend or binary changed')
  leaves[label]={n:sha(stage/n) for n in ['plan.json','result.json',name+'-mcp.sdk.json',name+'-mcp.events.jsonl','lease/exit.json','lease/events.jsonl','lease/nvml-queries.jsonl']}
 raw=ledger.canonical(data);save(O/(name+'-input.json'),data)
 old=profile_record.read(previous/(name+'.json'))
 source=dict(record_sha256=sha(previous/(name+'.json')),identity=ledger.digest(old['identity']),capacity=ledger.digest(old['capacity']),capabilities=ledger.digest(old['capabilities']),business={k:ledger.digest(v) for k,v in old['business'].items()},reuse=ledger.digest(old['reused_business']))
 sources[name]=source
 summary[name]=dict(data_digest=ledger.digest(data),leaves=leaves,raw_bytes=len(raw),compressed_base64_bytes=len(base64.b64encode(gzip.compress(raw,mtime=0))))
save(O/'observed.json',summary);save(O/'previous-sources.json',sources)
print(json.dumps({'changed':len(review['changed']),'added':len(review['added']),'unchanged':review['unchanged_count'],'observed':{n:{k:v for k,v in row.items() if k not in ('leaves',)} for n,row in summary.items()},'qualification_issued':False}))

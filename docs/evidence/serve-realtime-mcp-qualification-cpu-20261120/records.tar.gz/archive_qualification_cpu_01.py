from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-mcp-qualification-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
a=read(W/'qualification-cpu-01/result.json');b=read(W/'qualification-cpu-02/result.json');assert a['status']=='FAIL' and b['status']=='PASS'
files={'archive_qualification_cpu_01.py':Path(__file__),'prepare_qualification_inputs_01.py':W/'prepare_qualification_inputs_01.py'}
for folder in ('qualification-cpu-01','qualification-cpu-02'):
 for n in ('plan.json','result.json','stdout.txt','stderr.txt'):files[folder+'/'+n]=W/folder/n
files['qualification-cpu-01/original_test_native_bundle.py']=W/'qualification-cpu-01/original_test_native_bundle.py'
for p in (W/'qualification-inputs-01').glob('*.json'):files['qualification-inputs-01/'+p.name]=p
for n,h in b['sources'].items():assert sha(R/n)==h;files['source/'+n]=R/n
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 for m in archive:assert hashlib.sha256(archive.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
value=dict(status='PASS_MCP_QUALIFICATION_CPU',distinct_cases=42,executions=43,first_passed=40,first_failed=1,repair_passed=2,seconds=a['seconds']+b['seconds'],runtime_changed=False,gpu_actions=0,original_fixture_failure_preserved=True,qualification_issued=False,profile_bytes_bound=8<<20,mcp_witness_decoded_bound=2<<20,old_v24_compatible=True,isolated_package_import=True,master_goal_active=True);save(O/'acceptance.json',value)
(O/'README.md').write_text('''# MCP主轻资格与封包合同CPU

2026-11-20。42项不同检查完成，43次执行、1.930秒：首轮41项40通过/
1夹具NameError，修复断言所属函数后只重验该项与受影响原测试2项，
另外40项复用。原失败与源码保留，运行时未改、新增GPU 0。

实际原业务与补验逐项绑定，保留错答/拒答和原缺失的metrics边界。
来源证明冻结15份修改/16份新增/970份未改运行时文件，现有业务逐叶
按摘要复用；容量、后端、原证据、MCP权限及来源变化不能借用资格。
MCP纯验证模块不再导入GPU驱动或测试MCP服务，实际隔离Python封包
导入通过；v25包含新增模块、v24旧清单继续验证。

新增MCP叶有界压缩：编码128KiB、展开2MiB，仍保持资格文件8MiB和
一般元数据2MiB。验证截断、尾随流、展开超限、摘要或重复键等反例。
本组没有发新主轻资格，没有完成服务恢复或发行；下一步据本组和
原实际业务生成资格，接着原生服务恢复与可回退交付。总目标active。

[结果](acceptance.json) · [索引](index.json) · [源码、原件与CPU](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text().replace('仍需验证。准备41项针对性CPU，\n不重复GPU或音频/视觉矩阵。','''继续兼容。[42项不同CPU完成](evidence/serve-realtime-mcp-qualification-cpu-20261120/README.md)，
43次执行含原夹具失败及2项修复补验；不重复GPU或音频/视觉矩阵。
正在生成主轻资格，尚未完成服务恢复或发行。''');p.write_text(s)
p=R/'docs/log/2026-11-20.md';p.write_text('''## MCP资格与封包42项CPU完成

日期：2026-11-20。

做了什么：[42项不同CPU完成](../evidence/serve-realtime-mcp-qualification-cpu-20261120/README.md)，
43次执行/1.930秒，原失败保留；修复仅移动夹具断言，无运行时修改。
v24兼容和v25隔离导入通过，资格/展开上限保持有界，实际原失败与
后续通过证据分别保存。来源、容量、业务、审批及压缩篡改反例覆盖。

为什么：让当前MCP能力能进入可验证的主轻发行与回退包，而不是只有
开发工作区能运行；不引入MCP验收服务作为生产依赖。

下一步：生成实际主轻资格和同能力候选/保留包，推进恢复短验与发行；
总目标active，默认rev396保持。

'''+p.read_text())
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'\n[42项不同CPU已完成](evidence/serve-realtime-mcp-qualification-cpu-20261120/README.md)，\n原NameError夹具错误保留，修复2项补验通过；43次执行，0GPU。\n接着生成实际资格与服务恢复包，默认保持。\n')
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['realtime_progress']['mcp_20261120'].update(state='mcp_qualification_and_bundle_contracts_verified_issuing_profiles',qualification_cpu=value,qualification_cpu_evidence='evidence/serve-realtime-mcp-qualification-cpu-20261120/README.md');save(p,d)
print(json.dumps(value))

import hashlib,json,re,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,j:p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
for name in ['host-build-04','engine-build-03','host-test-03','source-audit-03','generated-check-03']:
 r=json.loads((W/(name+'.json')).read_text());assert r['exit_code']==0 and r['default_unchanged']
 assert 'warning:' not in (W/(name+'.stderr')).read_text()+(W/(name+'.stdout')).read_text()
assert len(re.findall(r'\[PASS\]',(W/'host-test-03.stdout').read_text()))==8
b=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build';c=W/'candidate-02';c.mkdir()
shutil.copy2(b/'q4t',c/'q4t');shutil.copy2(b/'generated/q4t/server/chat_protocol_sources.json',c/'chat_protocol_sources.json')
m=json.loads((c/'chat_protocol_sources.json').read_text());assert all(sha(ROOT/n)==h for n,h in m.items())
old=json.loads((W/'candidate-01/chat_protocol_sources.json').read_text());delta={n for n,h in m.items() if old.get(n)!=h}
assert delta=={'include/q4t/server/generation_style.h','src/server/chat_template.cpp','src/server/output_constraints.cpp'},delta
protocol=re.search(r'kProtocol\[\] = "([0-9a-f]+)"',(b/'generated/q4t/server/chat_protocol_identity.h').read_text())[1]
save(W/'identity-02.json',dict(binary=str(c/'q4t'),binary_sha256=sha(c/'q4t'),protocol_sha256=protocol,compiled_sources=m,delta=sorted(delta)))
e=ROOT/'docs/evidence/serve-chat-style-grammar-cpu-20261116';e.mkdir()
files=['required-03.txt','freeze-repair-01.json','record_failure.py','archive_repair.py','identity-02.json']
for stem in ['host-build-03','host-build-04','engine-build-02','engine-build-03','host-test-03','source-audit-02','source-audit-03','generated-check-02','generated-check-03']:
 files += [stem+'.'+suffix for suffix in ['json','stdout','stderr']]
with tarfile.open(e/'cpu.tar.gz','w:gz') as tar:
 for n in files:tar.add(W/n,arcname=n)
 tar.add(c/'chat_protocol_sources.json',arcname='candidate/chat_protocol_sources.json')
receipt=dict(status='ACCEPT_CHAT_NONE_GRAMMAR_TARGETED_CPU',cpp=8,build_warnings=0,binary_sha256=sha(c/'q4t'),protocol_sha256=protocol,source_delta=sorted(delta),prior_build_failure='string_view key incompatible with existing Json::Find(const string&); key type corrected before successful build',business_pending=True,gpu_starts=0,default_unchanged=True,archive_sha256=sha(e/'cpu.tar.gz'))
save(e/'acceptance.json',receipt)
(e/'README.md').write_text('''# none 模板/约束一致性修复通过 CPU

8项针对性C++通过，包括真实exec grammar worker逐token单调用/JSON负控，
none、嵌套优先/null、medium/显式思考与模板前缀一致，Responses原适配
保持。715来源/7负控及生成物检查通过。初次构建key类型不匹配已保存，
修正为既有Json查找签名；最终主机/引擎零警告。

相对失败候选只改共享样式头、模板、输出约束三项运行时源码。其余
schema/客户端/32项解析对照成功按原源码证据复用；默认rev150未改，
0新增GPU。新候选身份在acceptance.json；继续原六条业务与原判定，
最多1启动/6Chat/900秒，不能把局部修复当总兼容完成。
''')
p=ROOT/'docs/STATUS.md';s=p.read_text();h='## 最近完成的实现和验证\n\n';p.write_text(s.replace(h,h+'''[none模板/约束修复CPU通过](evidence/serve-chat-style-grammar-cpu-20261116/README.md)：
8项直接C++含真实grammar负控，来源/生成物检查通过，最终零警告。
仅共享样式、模板、约束三项运行时变化；初次key类型构建失败保留。
候选`'''+receipt['binary_sha256'][:8]+'''`继续原六条业务/原判定，最多1启动/6Chat/900秒。
rev150未改，全部master继续。

''',1))
p=ROOT/'docs/log/2026-11-16.md';s=p.read_text();h='# 开发日志（2026-11-16）\n\n';p.write_text(h+'''## none 约束修复 CPU 通过

- 日期：2026-11-16。8项直接C++含真实grammar逐token负控通过；模板
  和语法共用思考边界。全源码检索未发现其他独立enable_thinking布尔
  解析；Responses已有独立默认xhigh仍是后续A07默认合同待解决项。
- 初次构建string_view key不匹配现有Json签名，改为const string&后
  主机/引擎零警告，原失败保留；715来源/7负控及生成物通过。
- 下一步：同一新候选原六条业务最多1启动/6Chat/900秒，原问题与
  质量判定不改。0新增GPU，rev150保持，全部master继续。
- 证据：[CPU](../evidence/serve-chat-style-grammar-cpu-20261116/README.md)。

'''+s[len(h):])
p=ROOT/'docs/serve-master-goals-v2.json';j=json.loads(p.read_text())
for t in j['tasks']:
 if 'chat_style_parity_20261116' in t:
  t['chat_style_parity_20261116'].update(state='real_business_failure_repaired_targeted_cpu_passed',binary_sha256=receipt['binary_sha256'],failure_evidence='evidence/serve-chat-style-business-failure-20261116/README.md',repair_evidence='evidence/serve-chat-style-grammar-cpu-20261116/README.md')
 if t['id']=='A07':
  t.setdefault('remaining_required',[])
  text='Responses default reasoning_effort remains xhigh; align omitted/null with frozen official medium default in next input-contract group.'
  if text not in t['remaining_required']:t['remaining_required'].append(text)
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(receipt['binary_sha256'])

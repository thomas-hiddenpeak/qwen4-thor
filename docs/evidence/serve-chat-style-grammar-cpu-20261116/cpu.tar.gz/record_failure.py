import hashlib,json,re,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;P=W/'business-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,j:p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
r=json.loads((P/'result.json').read_text());c=json.loads((P/'cleanup.json').read_text());l=json.loads((P/'lease/exit.json').read_text())
assert r['status']=='FAILED' and r['counts']['chats']==4 and l['status']=='COMMAND_FAILED'
assert not c['remaining'] and c['ports_released'] and c['model_exit']==0
queries=[json.loads(x) for x in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(x['status']=='OK' for x in queries)
assert not (P/'tool-execution.json').exists()
e=ROOT/'docs/evidence/serve-chat-style-business-failure-20261116';e.mkdir()
with tarfile.open(e/'business.tar.gz','w:gz') as tar:
 for p in sorted(P.rglob('*')):
  if p.is_file():
   assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes())
   tar.add(p,arcname=str(p.relative_to(P)))
shutil=None
save(e/'acceptance.json',dict(status='FAIL_CHAT_STYLE_BUSINESS',starts=1,chat_creates=4,seconds=r['seconds'],binary_sha256=r['binary_sha256'],passed=['default medium JSON','max/low SSE opt-out','none n=2 SSE/probability/usage with padding'],failure='none closes native prompt but grammar still assumes an open thinking region; generated tool output is unconstrained, second call rejected by parser',tool_executions=0,nvml_ok_samples=len(queries),cleanup=c,default_unchanged=True,default_revision=150,archive_sha256=sha(e/'business.tar.gz'),master_active=True))
(e/'README.md').write_text('''# Chat 样式首轮业务失败与原因

2026-11-16，1启动/4Chat/45.196秒，默认medium JSON、max/low SSE关闭
混淆、none双choice带混淆及概率/usage通过。第4条工具请求产生第二次
调用，被解析器报structured_output_invalid；没有成功终态，没有执行
工具。原请求/响应/日志完整保留，不能计该候选验收通过。

根因是新none选项已关闭模板thinking前缀，但output_constraints仍只
读取enable_thinking，语法worker误停留在自由思考区域。不是padding
破坏参数；须统一模板和语法的选项解析，none从首token启用约束。

NVML全程正常，自有模型正常退出、端口/进程/租约清理，默认rev150
未改。下一步真实grammar CPU负控、受影响模板/Responses检查，修复
后再冻结原六条业务；不放宽单调用合同，不追加性能或长稳测试。
''')
p=ROOT/'docs/STATUS.md';s=p.read_text();h='## 最近完成的实现和验证\n\n';p.write_text(s.replace(h,h+'''[Chat 样式实际业务首轮未通过](evidence/serve-chat-style-business-failure-20261116/README.md)：
1启动/4Chat/45.196秒，前三条通过，第4条工具无成功终态、0工具执行。
根因是none模板关闭thinking、语法仍按enable_thinking缺省开启，第二次
调用未被解码约束屏蔽。现统一解析，正在做真实grammar/模板针对性CPU；
原失败保留，rev150未改，自有GPU资源已清理，全部master继续。

''',1))
p=ROOT/'docs/log/2026-11-16.md';s=p.read_text();h='# 开发日志（2026-11-16）\n\n';p.write_text(h+'''## none 的模板和约束状态不同步：业务发现并修复

- 日期：2026-11-16。首轮1启动/4Chat/45.196秒，前三条通过，第4条
  工具请求生成第二次调用后被解析器拒绝，0工具执行；NVML正常。
- 根因/修复：none关闭模板thinking，但grammar仍只读取enable_thinking，
  首token约束没有生效。模板和约束共用嵌套优先/null/effort解析，
  保留parser终态保护，不能放宽parallel=false或把失败说成模型问题。
- 下一步：冻结8项直接C++（含真实worker单调用/JSON负控）及来源核对，
  零警告构建后补验原六条业务。修复影响共享模板解析，复验该接口组合；
  不扩大为全性能/质量。当前默认未改，自有GPU/端口已清理，master继续。
- 证据：[原失败](../evidence/serve-chat-style-business-failure-20261116/README.md)。

'''+s[len(h):])
required=['output_constraints_style_and_template_share_thinking_boundary','structured_decoder_none_starts_constraints_before_any_think_tag','structured_decoder_required_named_and_parallel_masks','structured_decoder_json_object_and_thinking','chat_style_default_null_and_explicit_effort_rendering','chat_style_none_and_nested_precedence_use_native_prefix','chat_verbosity_preserves_original_message_source_coordinates','responses_plan_reasoning_effort_and_verbosity_model_adaptation']
(W/'required-03.txt').write_text('\n'.join(required)+'\n')
save(W/'freeze-repair-01.json',dict(cpp=required,business_limits=dict(starts=1,chats=6,seconds=900),reason='Actual tool failure requires shared renderer/grammar style resolution; original six requests and oracles unchanged, checks cover defaults/null/none and constraints with the corrected resolver.',unchanged_cpu_evidence_reused=True,full_quality_or_performance=False))
print(json.dumps(dict(archived=r['status'],nvml=len(queries),cpp=len(required))))

from pathlib import Path
import hashlib,json,re,shutil,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=W/'session-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(name,cmd,timeout=120):
 start=time.monotonic()
 with (O/(name+'.log')).open('w') as f:
  try:code=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 row=dict(command=cmd,exit_code=code,seconds=time.monotonic()-start)
 save(O/(name+'-result.json'),row);print(name,code,round(row['seconds'],3),flush=True)
 if code:
  print((O/(name+'.log')).read_text()[-6000:],flush=True);raise SystemExit(code)
 return row
sources=['tests/server_realtime_conversation_session_test.cpp',
 'tests/server_realtime_conversation_test.cpp','tests/server_realtime_response_output_test.cpp',
 'src/server/realtime_conversation_session.cpp','src/server/realtime_conversation.cpp',
 'src/server/realtime_response_output.cpp','src/server/websocket.cpp','src/server/websocket_session.cpp']
names=[]
for n in sources[:3]:names+=re.findall(r'Q4T_TEST\(\s*(\w+)\s*\)',(R/n).read_text())
assert len(names)==46 and len(set(names))==46,len(names)
reused=[]
old=json.loads((W/'output-cpu-03/freeze.json').read_text())
for row in old['reused']:
 if row['source']=='src/server/realtime_conversation.cpp':continue
 assert sha(R/row['source'])==row['source_sha256']
 assert sha(Path(row['object']))==row['sha256']
 reused.append(row)
n='src/server/native_chat_generation.cpp';p=W/'output-cpu-03/objects/02.o'
assert sha(R/n)==old['sources'][n]
reused.append(dict(source=n,source_sha256=sha(R/n),object=str(p),sha256=sha(p)))
freeze=dict(tests=names,maximum_test_seconds=120,gpu_actions=0,
 scope='Native session/history/output/worker ownership CPU only, actual parser and framed SDK events; callback model is an explicit fixture. No model/endpoint/recovery acceptance.',
 sources={n:sha(R/n) for n in sources},reused=reused,
 bounded_responses=4,default_conversation_writers=1,
 prior_syntax_failure='Missing input_contract.h include for ValidRequestId; fixed before tests, zero tests ran in syntax commands.')
save(O/'freeze.json',freeze)
for n in [*sources,'include/q4t/server/realtime_conversation_session.h','include/q4t/server/realtime_conversation.h','include/q4t/server/realtime_response_output.h']:
 p=O/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
main=O/'main.cpp';main.write_text('#include "q4t/test.h"\nint main() { return q4t::test::RunAllTests(); }\n')
objects=[r['object'] for r in reused];rows=[];(O/'objects').mkdir()
for i,n in enumerate([*sources,str(main)]):
 obj=O/'objects'/f'{i:02d}.o';objects.append(str(obj))
 rows.append(run(f'build-{i:02d}',['g++-14','-std=c++23','-O1','-Wall','-Wextra','-Werror',
  '-ffunction-sections','-fdata-sections','-MMD','-MP','-Iinclude','-I'+str(W/'cpu-02/generated'),'-c',n,'-o',str(obj)]))
binary=O/'contracts';rows.append(run('link',['g++-14',*objects,'-Wl,--gc-sections','-pthread','-ldl','-o',str(binary)],60))
assert not any('warning:' in p.read_text() for p in O.glob('build-*.log'))
save(O/'build-result.json',dict(seconds=sum(r['seconds'] for r in rows),warnings=0,binary_sha256=sha(binary)))
run('contracts',[str(binary)],120)
log=(O/'contracts.log').read_text();assert log.count('[PASS] ')==46 and '[FAIL]' not in log and '[SKIP]' not in log
assert all(sha(R/n)==h for n,h in freeze['sources'].items())
save(O/'result.json',dict(status='PASS_REALTIME_CONVERSATION_SESSION_CPU',tests=46,gpu_actions=0,
 seconds=json.loads((O/'contracts-result.json').read_text())['seconds'],actual_business_accepted=False,default_unchanged=True))

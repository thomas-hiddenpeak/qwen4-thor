#include "q4t/test.h"
int main() { return q4t::test::RunTests({"realtime_session_settings_atomic_merge_and_response_override_snapshot"}); }

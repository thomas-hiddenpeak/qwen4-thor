import hashlib,json,shutil,tarfile
from pathlib import Path
r=Path(__file__).resolve().parents[2];w=Path(__file__).resolve().parent;o=r/'docs/evidence/serve-native-soak-cpu-20261116';o.mkdir()
for stem in ('cpu-01','seal-cpu-02','source-gate-01'):
 for ext in ('json','stdout','stderr'):shutil.copyfile(w/(stem+'.'+ext),o/(stem+'.'+ext))
names=['tools/serve_soak/'+n for n in ('native_contract.py','native_stage.py','native_report.py','test_native_soak.py','README.md')]+['docs/SERVE_NATIVE_SOAK_2026-11-16.md','.github/workflows/host-checks.yml','tools/serve_audit/check_inventory.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(o/'source.tar.gz','w:gz') as t:
 for n in names:t.add(r/n,arcname=n,recursive=False)
 t.add(w/'archive_cpu.py',arcname='archive_cpu.py',recursive=False)
 t.add(w/'run.py',arcname='run.py',recursive=False)
first=json.loads((w/'cpu-01.json').read_text());second=json.loads((w/'seal-cpu-02.json').read_text());assert first['exit_code']==second['exit_code']==0
value=dict(status='ACCEPT_TARGETED_NATIVE_SOAK_CPU',unique_tests=14,initial_passed=14,review_strengthened_seal_rechecks=1,seconds=first['seconds']+second['seconds'],source_gate=json.loads((w/'source-gate-01.stdout').read_text()),sources={n:sha(r/n) for n in names},source_archive_sha256=sha(o/'source.tar.gz'),gpu_starts=0,default_revision=182,default_changed=False,short_business_pending=True,day_run_owner='user',master_active=True)
(o/'acceptance.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
(o/'README.md').write_text('''# 原生长稳交接 CPU 接受

14项不同CPU全部首过；复核补强缺失密封记录的拒绝后只重验1项，
累计15调用/0.724秒。计划/期限/1h与day区分、真实工具来源与历史、
质量/截断拒绝、计数在派生前扣减、有界事件尾、wire篡改/链接/缺项、
fresh namespace以及真实CPU子进程故障清理通过。723来源锚点/7负控通过。

新入口冻结当前精确包，原生outer/Guardian、不依赖systemd/nginx；
day24小时1440组/7200生成加自检，每分钟一组保持alpha 30RPM/6000TPM。
short60秒3组/15业务生成加自检，最多1启动/16Chat/0探测/600秒。
周期资源仅原模型进程，连续GPU监控日志按轮转保留；14CPU不算真实
HTTP或长期稳定通过。下一步实际包prepare/check及short，day由用户执行。

0GPU，默认rev182及其他服务保持。R07相机/监控维护授权待定，所有
master任务继续；本工具不消除其余协议/媒体/物理资源与恢复缺口。
''')
p=r/'docs/STATUS.md';s=p.read_text();h='## 最近完成的实现和验证\n\n';p.write_text(s.replace(h,h+'''[原生长稳交接CPU通过](evidence/serve-native-soak-cpu-20261116/README.md)：
14项首过，密封记录复核后只补1项，723来源/7负控通过。当前包/原生
outer、实际工具及原始wire/清理复核已实现；day每分钟一组保持原配额，
24小时由用户执行。继续精确prepare/check及1启动/16Chat/600秒short。

''',1))
p=r/'docs/log/2026-11-16.md';s=p.read_text();h='# 开发日志（2026-11-16）\n\n';p.write_text(h+'''## 原生长稳交接14项CPU首过

- 日期：2026-11-16。14项不同CPU首过；密封缺项复核后只补1项，
  原模型身份、预算前置、有界事件尾、真实CPU子进程回收与来源通过。
- 为什么：当前原生发行需要不依赖systemd/nginx、可重验原始wire和
  清理证据的长稳入口；不按旧包的固定目录冒充当前默认验收。
- day明确1440周期/7200业务请求、每分钟一组，保持原alpha配额；
  24小时与第一小时证据分开，day仅用户执行。0GPU/默认保持。
- 下一步：精确包准备和short 1启动/16Chat/0探测/600秒；核对PR34
  修复head的CI，全部master继续。
- 证据：[针对性CPU](../evidence/serve-native-soak-cpu-20261116/README.md)。

'''+s[len(h):])
p=r/'docs/serve-master-goals-v2.json';d=json.loads(p.read_text())
for t in d['tasks']:
 if t['id']=='Q03':t['native_soak_20261116'].update(state='implemented_targeted_cpu_accepted_short_pending',evidence='evidence/serve-native-soak-cpu-20261116/README.md',cpu_tests=14,recheck_tests=1,day_cycles=1440,day_business_requests=7200)
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-mcp-item-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
r=read(W/'item-cpu-01/result.json');b=read(W/'item-build-01/result.json');assert r['status']=='PASS' and r['tests']==16 and b['warnings']==0
assert all(sha(R/p)==h for p,h in r['sources'].items())
files={n:W/n for n in ['item-plan.json','item-required.txt','build_item_01.py','run_item_cpu_01.py','archive_item_01.py','item-build-01/plan.json','item-build-01/result.json','item-build-01/build.log','item-cpu-01/result.json','item-cpu-01/stdout.txt','item-cpu-01/stderr.txt']};files.update({'source/'+p:R/p for p in r['sources']});O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_REALTIME_MCP_RESULT_AND_APPROVAL_HISTORY_CPU',cases=16,passed=16,failed=0,cpu_seconds=r['seconds'],build_seconds=b['seconds'],build_warnings=0,binary_sha256=r['binary_sha256'],runtime_connected=False,gpu_actions=0,llm_requests=0,default_revision=396,default_unchanged=True,service_state='STOPPED',all_master_tasks_active=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP真实结果投影与审批关联：CPU

2026-11-20。16项针对性CPU全部通过，0.064秒；必要host构建50.088秒、
零警告。12项新增结果/审批检查，4项直接受影响的历史合同。

原生成功、协议错误、工具错误和HTTP错误投影为真实SDK形状；公开
item没有status，实际结果/structuredContent保留。待调用、完成和
失败状态明确分开，矛盾状态、私有字段、重复字段和容量超限拒绝。
错误内容转字符串后的实际存储也受限，不能通过展开绕过预算。

审批只能绑定服务拥有的pending调用；服务器/工具/原始参数相同，
审批ID只绑定一次。普通Update、外来/旧ticket、client输入、已完成
调用不能替换审批；容量失败保持原历史。生成前捕获的历史可以等
审批及真实结果，但已绑定ID不能变更；删除后不可替换旧代际。

这些是纯组件检查，未执行远端工具、模型或公开Realtime MCP会话。
默认rev396 STOPPED，0GPU；继续原生审批/调用、会话接线、SDK业务
和恢复，不把本组当完整MCP或总目标验收。

[结果](acceptance.json) · [索引](index.json) · [源码与完整记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text().replace('已冻结16项结果投影/审批绑定CPU：核对原生错误到SDK映射、实际\n结果保真、审批单次关联、删除/迟到和容量失败；0GPU，待构建验证。','[结果投影与审批历史16项CPU](evidence/serve-realtime-mcp-item-cpu-20261120/README.md)\n全部通过，0.064秒，构建零警告；默认保持。继续原生审批/执行，\n公开会话仍待接线，不将本组当成真实工具闭环。');p.write_text(s)
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[16项CPU全部通过](evidence/serve-realtime-mcp-item-cpu-20261120/README.md)，\n0.064秒，必要host构建50.088秒/零警告。默认rev396保持，0GPU。\n下一组复用原生持久权限和MCP传输，补实际审批、单次调用、取消及\n未知结果不重放，然后接入真实会话；总目标继续。\n''')
p=R/'docs/log/2026-11-20.md';p.write_text('''## Realtime MCP结果与审批历史16项CPU通过

日期：2026-11-20。

做了什么：[16项针对性CPU](../evidence/serve-realtime-mcp-item-cpu-20261120/README.md)
全部通过/0.064秒，必要host构建50.088秒/零警告。SDK真实结果与三类
错误投影、容量展开、审批单次关联和代际保护均覆盖；默认保持。

为什么：工具结果必须来自实际原生执行，不能把生成或审批当完成；
公开形状不能泄露私有字段或把错误内容丢掉，迟到更新不能改绑历史。

下一步：连接持久审批、单次远端调用与取消/未知结果保护，继而会话
集成、SDK业务和恢复。当前组件无远端调用/模型/GPU，总目标active。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m['state']='result_projection_and_approval_history_cpu_accepted_native_execution_integration_next';m['item_cpu']=a;m['item_evidence']='evidence/serve-realtime-mcp-item-cpu-20261120/README.md';save(p,d)
print(json.dumps(a))

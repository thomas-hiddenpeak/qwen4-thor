from pathlib import Path
import argparse,json,subprocess,shutil
from tools.serve_recovery import profile_acceptance as driver
from tools.serve_service import package
from tools.native_tts.acceptance import defaults
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';I=V/'voice-profiles-inputs-02';P=V/'voice-profiles-01';O=V/'voice-profiles-02';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build'
assert not subprocess.check_output(['git','status','--porcelain'])
assert package.read(P/'lease/exit.json')['status']=='ENV_ABORT'
assert package.read(V/'voice-monitor-preflight-01/result.json')==dict(status='COMPLETED',queries=5,all_ok=True,all_empty=True,future_stability_claim=False,model_loads=0,http=0)
prior=package.read(P/'plan.json');review=package.read(I/'review.json');assert defaults()==review['defaults'] and shutil.disk_usage(R).free>(256<<20)+(32<<20)
args=argparse.Namespace(package=Path(review['retained_package']),binary=B/'q4t',output=O,candidate_build=B,candidate_release=None,capacity_config=I/'capacity.json',tts_config=I/'tts.json',tts_base_config=I/'tts-base.json',voice_fixtures=I/'voices.json',tts_checkpoint_sampling=True,asr_config=None,asr_audio=Path(prior['asr_audio']['path']),chat_audio=True,speaker_audio=Path(prior['speaker_audio']['path']),separator_audio=Path(prior['separator_audio']['path']),port=19192)
driver.prepare(args);p=package.read(O/'plan.json')
for name in ['identity','profiles','native_assets','requests','limits','voice_clips','tts_sampling_profile']:
 assert p[name]==prior[name],name
for f in [Path(__file__).resolve(),V/'voice-monitor-preflight-01/result.json',P/'lease/exit.json',I/'review.json']:
 p['sources'][str(f)]=package.sha(f)
p['prior_environment_abort']=dict(path=str(P),result_sha256=package.sha(P/'lease/exit.json'),no_prior_business_used_to_qualify=True)
p['continuation_policy']='one new bounded attempt after idle monitoring works; no automatic replay or further ENV_ABORT retry'
package.save(O/'plan.json',p)
text='空闲严格租约5次NVML正常且无GPU进程，仅证明当前可用；冻结一次\n原主轻清单续验：2启动/50POST/900秒，同C05、配置、录音及请求，\n不复用ENV_ABORT作通过证据。若再环境中止，不连续重试，继续CPU\n开发；默认rev316保持，恢复驱动14 CPU及元数据补核已提交。\n'
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 空闲监控恢复，冻结一次原清单续验\n\n'+text+'\n为什么：补齐原实际资格，严格监控边界不放宽；下一步：通过后受监护恢复，否则继续CPU开发。\n\n')]:
 q=R/n;s=q.read_text();t=q.with_suffix('.edit');t.write_text(s.replace(m,m+c,1));t.replace(q)
print(json.dumps(dict(plan=str(O/'plan.json'),limits=p['limits'])))

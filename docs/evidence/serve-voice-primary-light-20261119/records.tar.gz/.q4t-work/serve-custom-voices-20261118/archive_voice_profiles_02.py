from pathlib import Path
import json,shutil,tarfile
from tools.native_tts.voice_service_acceptance import read,save,sha,defaults
from tools.serve_audit import check_inventory as audit
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'voice-profiles-02';O=R/'docs/evidence/serve-voice-primary-light-20261119'
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
a=read(P/'acceptance.json');r=read(P/'result.json');plan=read(P/'plan.json')
assert a['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and r['status']=='PASS_QUALIFIED_PRIMARY_LIGHT_BUSINESS' and r['counts']['starts']==2 and r['counts']['chats']==50
assert defaults()==read(V/'voice-profiles-inputs-02/review.json')['defaults']
assert all(sha(R/n)==h for n,h in plan['sources'].items())
queries=[json.loads(x) for x in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(q['status']=='OK' for q in queries) and queries[-1]['pids']==[]
assert read(P/'lease/exit.json')['status']=='COMPLETED'
registry=read(P/'qualified/registry.json');observed={}
for name in ('primary','light'):
 record=read(P/'qualified'/(name+'.json'));assert record['format']=='q4t-profile-business-v11'
 value=record['business']['voice'];observed[name]=dict(speech=value['speech_transcript']['text'],chat=value['chat_transcript']['text'],consent_id=value['consent']['id'],voice_id=value['voice']['id'],revocation=value['revocation'],sampling=record['business']['tts']['sampling_profile'])
actual=audit.current_surface(R);inv=read(audit.INVENTORY);errors=audit.check(inv,actual);mutations=audit.mutation_checks(inv,actual);assert not errors and mutations==17
O.mkdir();save(O/'audit.json',dict(anchors=len(actual['sources_sha256']),errors=errors,mutations=mutations));save(O/'default-unchanged.json',defaults())
summary=dict(status='ACCEPT_BASE_VOICE_AND_BUILTIN_PRIMARY_LIGHT_BUSINESS',engine_sha256=plan['binary_sha256'],acceptance=a,results=observed,nvml_queries=len(queries),all_nvml_ok=True,default_replaced=False,actual_managed_recovery=False,prior_env_abort_preserved=True,retained_storage=read(V/'retained-storage-01/result.json'),full_task_complete=False,listening='PENDING')
save(O/'result.json',summary)
# These are point observations, not a fabricated continuous resource bound.
save(O/'disk-observation-note.json',dict(manual_sample_order=[dict(available_mib=164),dict(available_bytes=314671104,stage_artifacts_bytes=6811026),dict(available_mib=295),dict(available_mib=286)],stage_io_failure=False,continuous_free_space_floor_not_measured=True,cleanup_scope='subsequent four exact immutable duplicate binaries only; no raw records, old versions or paths removed'))
files=[]
for base in [P,V/'voice-monitor-preflight-01',V/'retained-storage-01']:
 for p in base.rglob('*'):
  if p.is_file() and p.suffix not in ('.wav','.f32','.pyc') and '__pycache__' not in p.parts:files.append(p)
for n in ['prepare_voice_profiles_04.py','deduplicate_retained_tts_01.py','deduplicate_retained_tts_02.py','retained-storage-prepare-failure-01.json','archive_voice_profiles_02.py']:files.append(V/n)
assert shutil.disk_usage(R).free>(256<<20)+sum(p.stat().st_size for p in files)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}))
(O/'README.md').write_text('''# C05注册音色与全部已配置能力：主轻资格通过

候选943964c4208b1b802ca04562155e203e797d891196978881031e36e588e71ab9，
同一严格GPU租约2启动/50业务POST、311.903秒通过。每profile实际登记
Consent/Voice，跨客户、错误授权、异声、配额反例、Speech/Chat新文本
独立ASR、完整历史及撤销通过。固定录音不重新生成。两档完整旧能力
保留：输入ASR/对齐/VAD/说话人/重叠分离、Chat输入、资料工具、结构化、
embedding和视频；新采样内置Speech/Chat按完整字节核验，输入家族后
再次合成验证实际卸载/重载。两档均使用v11业务证据。

私有配置仅增加Base身份，公平队列2→3，共享TTS帧160→200；其余
已接受配置、真实录音及请求绑定保留。原NVML ENV_ABORT不复用为
通过证据；空闲5查询正常后，只进行了本次完整有界续验。所有查询
正常、两个自有模型均退出0、子树/端口/锁清理及来源/资产核对通过。
资格与原始wire见records.tar.gz和index.json。

打包前，当前任务四份SHA相同的只读旧引擎副本经核对改共享inode，
释放112940928字节，所有路径、内容、版本及默认出版入口保持。
保存了精确路径/旧stat/恢复独立副本办法。测试期间磁盘空闲曾短暂
采样164MiB，随后恢复；没有I/O失败，不主张连续磁盘余量证明。

940来源锚点/17遗漏负控通过。默认rev316尚未替换；真实Guardian
入口/整包恢复、Base-only消费资格、保存状态兼容回退和可回退发行
继续。固定完整内容通过不代表听感、真人相似度、全音色或长稳通过。
''')
p=R/'docs/serve-master-goals-v2.json';g=read(p);row=g['native_tts_progress']['custom_voice']['service'];row['primary_light_qualification']=dict(status=summary['status'],evidence='evidence/serve-voice-primary-light-20261119/README.md',engine_sha256=plan['binary_sha256'],starts=2,posts=50,seconds=r['seconds'],business_format='v11',default_replaced=False);row['builtin_sampling_profile']['actual_profiles_pending']=False
row['remaining']=['managed recovery and reversible delivery','preserved-state compatible rollback','Base-only existing registered voice qualification','reference audio ICL, prompt voices and Live','listening and speaker similarity'];write(p,json.dumps(g,ensure_ascii=False,indent=2)+'\n')
text='''[C05主/轻资格通过](evidence/serve-voice-primary-light-20261119/README.md)：
2启动/50业务POST/311.903秒；两档真实音色闭环、新采样完整音频、
旧输入/工具/结构化/媒体能力及家族重载通过，严格租约/来源/清理通过。
原NVML ENV_ABORT保留；940锚点/17负控。四份相同只读旧引擎共享
存储释放112.94MB，原路径/内容/默认保持。接着真实Guardian/回退
及可回退发行，Base-only/ICL/提示词音色/Live和听感仍须继续。
'''
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 含注册音色的全部已配置能力主轻资格通过\n\n'+text+'\n为什么：新增能力必须与已交付能力一起降级可用；下一步：实际受监护和持久回退。\n\n')]:
 p=R/n;s=p.read_text();write(p,s.replace(m,m+c,1))
print(json.dumps(dict(status=summary['status'],queries=len(queries),files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size)))

from pathlib import Path
import hashlib,json,os,stat,shutil
from tools.native_tts.acceptance import defaults
from tools.serve_grammar_reap import acceptance as lifecycle
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';T=R/'.q4t-work/serve-native-tts-20261118';O=V/'retained-storage-01'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def snapshot(p):
 s=p.stat();return dict(dev=s.st_dev,inode=s.st_ino,bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,links=s.st_nlink)
canonical=(R/'build/q4t').resolve(strict=True);assert canonical==T/'service-package-01/bundle/engine/q4t'
expected='5130cae65358f151cbf9c055af9d2c521e6acc46183c32aa70b6581ab39f6fee';assert sha(canonical)==expected
paths=[T/n/'engine/q4t' for n in ['service-package-01','retained-01/bundle','modern-retained-01/bundle','tls-package-01/bundle']]
assert not any(str(T) in p.get('executable','') for p in lifecycle.guard.processes().values()),'active retained payload'
protected=defaults();before=shutil.disk_usage(R).free;rows=[]
for p in paths:
 s=snapshot(p);assert p.is_file() and not p.is_symlink() and s['mode']==0o500 and s['links']==1 and sha(p)==expected
 rows.append(dict(path=str(p),before=s,sha256=expected))
O.mkdir();plan=dict(scope='four inactive byte-identical immutable executable copies from this task only',canonical=str(canonical),canonical_sha256=expected,paths=rows,default_before=protected,retains_every_path=True,restore='copy canonical to a new sibling file, chmod 0500, verify SHA256, then atomically replace the chosen hardlink',models=0,gpu=0)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for row in rows:
 p=Path(row['path']);assert snapshot(p)==row['before'] and sha(p)==expected and sha(canonical)==expected
 tmp=p.with_name('q4t.dedup-current-task');assert not tmp.exists();os.link(canonical,tmp);os.replace(tmp,p)
 fd=os.open(p.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 assert sha(p)==expected and snapshot(p)['mode']==0o500
 (O/'progress.json').write_text(json.dumps([dict(path=x['path'],current=snapshot(Path(x['path']))) for x in rows],indent=2)+'\n')
assert defaults()==protected and all(sha(p)==expected for p in paths)
result=dict(status='IDENTICAL_IMMUTABLE_COPIES_SHARE_STORAGE',default_unchanged=True,paths_retained=True,sha256=expected,free_before=before,free_after=shutil.disk_usage(R).free,logical_duplicate_bytes=sum(x['before']['bytes'] for x in rows),canonical_after=snapshot(canonical),model_actions=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

import hashlib,json,sys,subprocess,time,os
from pathlib import Path
R=Path.cwd();T=R/'.q4t-work/serve-native-tts-20261118';sys.path.insert(0,str(R/'tools/native_tts'))
from acceptance import digest,defaults
from clock_content_acceptance import LIMITS,CONTROLS
out=T/'clock-content-cpu-01';out.mkdir(exist_ok=False)
names=['tools/native_tts/clock_content.py','tools/native_tts/test_clock_content.py','tools/native_tts/clock_content_acceptance.py','tools/native_tts/utterance_acceptance.py','tools/native_tts/acceptance.py']
p=dict(scope='4x owner-approved content check; listening remains pending',cpu_cases=8,cpu_seconds=60,gpu_actions=0,model_loads=0,sources={str(R/n):digest(R/n) for n in names})
(out/'plan.json').write_text(json.dumps(p,indent=2)+'\n')
for file in ['docs/STATUS.md','docs/log/2026-11-18.md']:
 q=R/file;v=q.read_text();head='用户已允许4倍语音按时间归一化内容复核验收，保留原速ASR错词与\n正常播放听感待验项。冻结8针对CPU/60秒、1ASR/4反例/600秒；\n中英文各全静音和仅留前四分之一，原四正例复用。主模型/默认不动。\n\n' if 'STATUS' in file else '## 2026-11-18：落实4倍语音验收口径与反例\n\n用户已明确允许时间归一化复核，原直接ASR失败及听感待验保持。\n补齐损坏PCM与防误判检查，冻结8 CPU/60秒，再同一严格租约1 ASR/\n4反例/600秒/16MiB，磁盘余量256MiB；0TTS/主LLM/HTTP。\n下一步执行反例，独立记录内容与听感，再持续自定义音色等总计划。\n\n'
 if 'STATUS' in file:v=v.replace('## 正在推进\n\n','## 正在推进\n\n'+head,1)
 else:v=v.split('\n',1)[0]+'\n\n'+head+v.split('\n',1)[1].lstrip('\n')
 temp=q.with_suffix('.edit');temp.write_text(v);temp.replace(q)
start=time.monotonic();cmd=['/usr/bin/python3','-B','-m','unittest','tools.native_tts.test_clock_content','-v']
with (out/'test.log').open('wb') as log: run=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=60)
result=dict(exit_code=run.returncode,seconds=time.monotonic()-start,cpu_cases=8,gpu_actions=0,command=cmd,plan_sha256=digest(out/'plan.json'))
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert run.returncode==0
old=json.loads((T/'tempo-clock-plan-01.json').read_text());prior=T/'tempo-clock-diagnostic-01/run'
sources=dict(p['sources']); sources.update(old['sources'])
for folder in [prior, prior.parent/'lease',out]:
 for q in folder.rglob('*'):
  if q.is_file(): sources[str(q)]=digest(q)
for n in ['tempo-02/run/result.json','phase-tempo-content-02/run/result.json','tempo-clock-plan-01.json']:
 q=T/n;sources[str(q)]=digest(q)
for item in old['cases']:
 for name in ['pcm','mel']:
  q=Path(item['input'][name]);sources[str(q)]=digest(q)
plan=dict(schema='q4t-tts-clock-content-owner-decision-v1',limits=LIMITS,controls=CONTROLS,defaults=defaults(),owner_decision=dict(allowed=True,listening_pending=True,exact_reply='允许，补齐反例并保留听感待验项（推荐）'),sources=sources,asr_binary=old['asr_binary'],asr_assets=old['asr_assets'],positive_run=str(prior),original_inputs=[old['cases'][i]['input'] for i in [0,2]],reference_pythonpath=str(R/'.q4t-work/serve-audio-native-20261117/reference-deps'))
(T/'clock-content-plan-01.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
print('GPU plan frozen; not run')

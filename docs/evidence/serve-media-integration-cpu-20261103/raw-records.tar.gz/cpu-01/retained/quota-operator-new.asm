
/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-media-integration-20261103/processor-quota/processor_contract:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000067c40 <_Znwm>:
   67c40:	f100001f 	cmp	x0, #0x0
   67c44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
   67c48:	9a9f1400 	csinc	x0, x0, xzr, ne	// ne = any
   67c4c:	910003fd 	mov	x29, sp
   67c50:	97fffd4c 	bl	67180 <__wrap_malloc>
   67c54:	d53bd041 	mrs	x1, tpidr_el0
   67c58:	91400021 	add	x1, x1, #0x0, lsl #12
   67c5c:	91004021 	add	x1, x1, #0x10
   67c60:	3900043f 	strb	wzr, [x1, #1]
   67c64:	b4000060 	cbz	x0, 67c70 <_Znwm+0x30>
   67c68:	a8c27bfd 	ldp	x29, x30, [sp], #32
   67c6c:	d65f03c0 	ret
   67c70:	d2800100 	mov	x0, #0x8                   	// #8
   67c74:	f9000bf3 	str	x19, [sp, #16]
   67c78:	97ffef9a 	bl	63ae0 <__cxa_allocate_exception@plt>
   67c7c:	aa0003f3 	mov	x19, x0
   67c80:	b4000340 	cbz	x0, 67ce8 <_Znwm+0xa8>
   67c84:	f240081f 	tst	x0, #0x7
   67c88:	54000301 	b.ne	67ce8 <_Znwm+0xa8>  // b.any
   67c8c:	d343fc02 	lsr	x2, x0, #3
   67c90:	d2c00201 	mov	x1, #0x1000000000          	// #68719476736
   67c94:	38e16841 	ldrsb	w1, [x2, x1]
   67c98:	35000321 	cbnz	w1, 67cfc <_Znwm+0xbc>
   67c9c:	900003c1 	adrp	x1, df000 <__FRAME_END__+0x194e8>
   67ca0:	f947d821 	ldr	x1, [x1, #4016]
   67ca4:	f900001f 	str	xzr, [x0]
   67ca8:	91004022 	add	x2, x1, #0x10
   67cac:	b100403f 	cmn	x1, #0x10
   67cb0:	54000282 	b.cs	67d00 <_Znwm+0xc0>  // b.hs, b.nlast
   67cb4:	900003c1 	adrp	x1, df000 <__FRAME_END__+0x194e8>
   67cb8:	f947d421 	ldr	x1, [x1, #4008]
   67cbc:	f9000002 	str	x2, [x0]
   67cc0:	b1004022 	adds	x2, x1, #0x10
   67cc4:	54000262 	b.cs	67d10 <_Znwm+0xd0>  // b.hs, b.nlast
   67cc8:	f9000002 	str	x2, [x0]
   67ccc:	97ffefd5 	bl	63c20 <__asan_handle_no_return@plt>
   67cd0:	900003c2 	adrp	x2, df000 <__FRAME_END__+0x194e8>
   67cd4:	f947d042 	ldr	x2, [x2, #4000]
   67cd8:	aa1303e0 	mov	x0, x19
   67cdc:	900003c1 	adrp	x1, df000 <__FRAME_END__+0x194e8>
   67ce0:	f947dc21 	ldr	x1, [x1, #4024]
   67ce4:	97ffef9b 	bl	63b50 <__cxa_throw@plt>
   67ce8:	d00003c0 	adrp	x0, e1000 <__dso_handle+0xff8>
   67cec:	910d8000 	add	x0, x0, #0x360
   67cf0:	aa1303e1 	mov	x1, x19
   67cf4:	913c8000 	add	x0, x0, #0xf20
   67cf8:	97ffef2a 	bl	639a0 <__ubsan_handle_type_mismatch_v1_abort@plt>
   67cfc:	97ffefbd 	bl	63bf0 <__asan_report_store8@plt>
   67d00:	d00003c0 	adrp	x0, e1000 <__dso_handle+0xff8>
   67d04:	910d8000 	add	x0, x0, #0x360
   67d08:	913e8000 	add	x0, x0, #0xfa0
   67d0c:	97fff07d 	bl	63f00 <__ubsan_handle_pointer_overflow_abort@plt>
   67d10:	d00003c0 	adrp	x0, e1000 <__dso_handle+0xff8>
   67d14:	910d8000 	add	x0, x0, #0x360
   67d18:	913f8000 	add	x0, x0, #0xfe0
   67d1c:	97fff079 	bl	63f00 <__ubsan_handle_pointer_overflow_abort@plt>

Disassembly of section .fini:

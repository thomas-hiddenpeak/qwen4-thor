// Hyper-Connection (GatedResidual) implementation. See hyperconnection.h.
//
// mix:
//   1. GroupedGemmaRMSNorm(hyper_input) -> normed            (kernel)
//   2. down = normed @ W_down^T            [T, lowrank]      (Bf16Gemm)
//   3. silu(down / hc)                     [T, lowrank]     (kernel)
//   4. up = silu_down @ W_up^T             [T, hc*hs]        (Bf16Gemm)
//   5. gate = sigmoid(up); mixed = mean_b(gate*normed)       (kernel)
// combine:
//   1. inject_raw = normed @ W_inject^T   [T, hc]            (Bf16Gemm)
//   2. 2*sigmoid(inject_raw/hc)           [T, hc]            (kernel)
//   3. out = R + block_output * inject     [T, hc*hs]        (kernel)
#include "q4t/model/hyperconnection.h"

#include <cuda_bf16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "q4t/model/hc_mix_subtiming.h"
#include "q4t/model/linear.h"

namespace q4t {
namespace model {

bool HcInjectGevGated(const uint16_t* x, const uint16_t* w, uint16_t* y,
                     cudaStream_t stream);

namespace {

constexpr int kBlock = 256;

__device__ __forceinline__ float Bf16ToFloat(uint16_t b) {
  uint32_t bits = static_cast<uint32_t>(b) << 16;
  float f;
  std::memcpy(&f, &bits, sizeof(f));
  return f;
}
__device__ __forceinline__ uint16_t FloatToBf16(float f) {
  const __nv_bfloat16 b = __float2bfloat16_rn(f);
  return *reinterpret_cast<const uint16_t*>(&b);
}

// GroupedGemmaRMSNorm: per-branch (group of `hs`) RMSNorm, then scale by
// (1 + weight). One block per row; each BRANCH is owned by one warp (warp w
// handles branch w) so the hc branches reduce in parallel via warp shuffles
// instead of the old sequential block-wide barrier chain (44 __syncthreads).
// blockDim = 32 * hc. float4-vectorized over hs.
__global__ void GroupedRmsNormKernel(const uint16_t* __restrict__ x,
                                     const uint16_t* __restrict__ weight,
                                     uint16_t* __restrict__ out, int T, int hc,
                                     int hs, float eps) {
  const int t = blockIdx.x;
  if (t >= T) return;
  const int b = threadIdx.x >> 5;  // branch = warp id
  const int lane = threadIdx.x & 31;
  if (b >= hc) return;
  const uint16_t* g = x + (static_cast<size_t>(t) * hc + b) * hs;
  uint16_t* orow = out + (static_cast<size_t>(t) * hc + b) * hs;
  const uint16_t* wg = weight + static_cast<size_t>(b) * hs;
  const float4* gv = reinterpret_cast<const float4*>(g);
  const float4* wv = reinterpret_cast<const float4*>(wg);
  float4* ov = reinterpret_cast<float4*>(orow);
  const int n8 = hs / 8;  // float4 = 16 B = 8 bf16
  // Pass 1: sum of squares for this branch.
  float acc = 0.f;
  for (int i = lane; i < n8; i += 32) {
    const __nv_bfloat162* p = reinterpret_cast<const __nv_bfloat162*>(&gv[i]);
    float2 v0 = __bfloat1622float2(p[0]);
    float2 v1 = __bfloat1622float2(p[1]);
    float2 v2 = __bfloat1622float2(p[2]);
    float2 v3 = __bfloat1622float2(p[3]);
    acc += v0.x * v0.x + v0.y * v0.y + v1.x * v1.x + v1.y * v1.y +
           v2.x * v2.x + v2.y * v2.y + v3.x * v3.x + v3.y * v3.y;
  }
  for (int i = n8 * 8 + lane; i < hs; i += 32) {
    const float v = Bf16ToFloat(g[i]);
    acc += v * v;
  }
#pragma unroll
  for (int off = 16; off > 0; off >>= 1)
    acc += __shfl_xor_sync(0xffffffffu, acc, off);
  const float rs = rsqrtf(acc / hs + eps);
  // Pass 2: normalize + scale, write back.
  for (int i = lane; i < n8; i += 32) {
    const __nv_bfloat162* p = reinterpret_cast<const __nv_bfloat162*>(&gv[i]);
    const __nv_bfloat162* q = reinterpret_cast<const __nv_bfloat162*>(&wv[i]);
    float2 v0 = __bfloat1622float2(p[0]);
    float2 v1 = __bfloat1622float2(p[1]);
    float2 v2 = __bfloat1622float2(p[2]);
    float2 v3 = __bfloat1622float2(p[3]);
    float2 w0 = __bfloat1622float2(q[0]);
    float2 w1 = __bfloat1622float2(q[1]);
    float2 w2 = __bfloat1622float2(q[2]);
    float2 w3 = __bfloat1622float2(q[3]);
    v0.x *= rs * (1.f + w0.x);
    v0.y *= rs * (1.f + w0.y);
    v1.x *= rs * (1.f + w1.x);
    v1.y *= rs * (1.f + w1.y);
    v2.x *= rs * (1.f + w2.x);
    v2.y *= rs * (1.f + w2.y);
    v3.x *= rs * (1.f + w3.x);
    v3.y *= rs * (1.f + w3.y);
    float4 o;
    __nv_bfloat162* op = reinterpret_cast<__nv_bfloat162*>(&o);
    op[0] = __floats2bfloat162_rn(v0.x, v0.y);
    op[1] = __floats2bfloat162_rn(v1.x, v1.y);
    op[2] = __floats2bfloat162_rn(v2.x, v2.y);
    op[3] = __floats2bfloat162_rn(v3.x, v3.y);
    ov[i] = o;
  }
  for (int i = n8 * 8 + lane; i < hs; i += 32) {
    const float v = Bf16ToFloat(g[i]);
    const float w = Bf16ToFloat(wg[i]);
    orow[i] = FloatToBf16(v * rs * (1.f + w));
  }
}

// Exact Combine -> BF16 round-trip -> grouped RMSNorm for hs=2560/hc=4.
// Combined remains in global memory for the next residual Write. Shared
// staging avoids reading it twice from global memory during normalization.
__global__ void CombineAndGroupedNormKernel(
    const uint16_t* __restrict__ block_output,
    const uint16_t* __restrict__ residual,
    const uint16_t* __restrict__ inject_gate,
    const uint16_t* __restrict__ weight, uint16_t* __restrict__ combined,
    uint16_t* __restrict__ out, int T, int hc, int hs, float eps) {
  const int t = blockIdx.x;
  if (t >= T) return;
  const int b = threadIdx.x >> 5;  // branch = warp id
  const int lane = threadIdx.x & 31;
  if (b >= hc) return;
  __shared__ __align__(16) uint16_t staged[4 * 2560];
  const size_t base = (static_cast<size_t>(t) * hc + b) * hs;
  uint16_t* g = staged + b * hs;
  const float inj = Bf16ToFloat(inject_gate[static_cast<size_t>(t) * hc + b]);
  uint16_t* orow = out + (static_cast<size_t>(t) * hc + b) * hs;
  const uint16_t* wg = weight + static_cast<size_t>(b) * hs;
  float4* gv = reinterpret_cast<float4*>(g);
  const float4* wv = reinterpret_cast<const float4*>(wg);
  float4* ov = reinterpret_cast<float4*>(orow);
  const int n8 = hs / 8;  // float4 = 16 B = 8 bf16
  // Pass 1: sum of squares for this branch.
  float acc = 0.f;
  for (int i = lane; i < n8; i += 32) {
    // Keep the eight-value arithmetic order, but load contiguous vectors.
    const float4 residual_pack =
        reinterpret_cast<const float4*>(residual + base)[i];
    const float4 block_pack = reinterpret_cast<const float4*>(
        block_output + static_cast<size_t>(t) * hs)[i];
    const uint16_t* residual_values =
        reinterpret_cast<const uint16_t*>(&residual_pack);
    const uint16_t* block_values =
        reinterpret_cast<const uint16_t*>(&block_pack);
    float4 packed;
    uint16_t* values = reinterpret_cast<uint16_t*>(&packed);
#pragma unroll
    for (int j = 0; j < 8; ++j) {
      const float residual_value = Bf16ToFloat(residual_values[j]);
      const float block_value = Bf16ToFloat(block_values[j]);
      values[j] = FloatToBf16(residual_value + block_value * inj);
    }
    reinterpret_cast<float4*>(combined + base)[i] = packed;
    gv[i] = packed;
    const __nv_bfloat162* p = reinterpret_cast<const __nv_bfloat162*>(&packed);

    float2 v0 = __bfloat1622float2(p[0]);
    float2 v1 = __bfloat1622float2(p[1]);
    float2 v2 = __bfloat1622float2(p[2]);
    float2 v3 = __bfloat1622float2(p[3]);
    acc += v0.x * v0.x + v0.y * v0.y + v1.x * v1.x + v1.y * v1.y + v2.x * v2.x +
           v2.y * v2.y + v3.x * v3.x + v3.y * v3.y;
  }
#pragma unroll
  for (int off = 16; off > 0; off >>= 1)
    acc += __shfl_xor_sync(0xffffffffu, acc, off);
  const float rs = rsqrtf(acc / hs + eps);
  // Pass 2: normalize + scale, write back.
  for (int i = lane; i < n8; i += 32) {
    const __nv_bfloat162* p = reinterpret_cast<const __nv_bfloat162*>(&gv[i]);
    const __nv_bfloat162* q = reinterpret_cast<const __nv_bfloat162*>(&wv[i]);
    float2 v0 = __bfloat1622float2(p[0]);
    float2 v1 = __bfloat1622float2(p[1]);
    float2 v2 = __bfloat1622float2(p[2]);
    float2 v3 = __bfloat1622float2(p[3]);
    float2 w0 = __bfloat1622float2(q[0]);
    float2 w1 = __bfloat1622float2(q[1]);
    float2 w2 = __bfloat1622float2(q[2]);
    float2 w3 = __bfloat1622float2(q[3]);
    v0.x *= rs * (1.f + w0.x);
    v0.y *= rs * (1.f + w0.y);
    v1.x *= rs * (1.f + w1.x);
    v1.y *= rs * (1.f + w1.y);
    v2.x *= rs * (1.f + w2.x);
    v2.y *= rs * (1.f + w2.y);
    v3.x *= rs * (1.f + w3.x);
    v3.y *= rs * (1.f + w3.y);
    float4 o;
    __nv_bfloat162* op = reinterpret_cast<__nv_bfloat162*>(&o);
    op[0] = __floats2bfloat162_rn(v0.x, v0.y);
    op[1] = __floats2bfloat162_rn(v1.x, v1.y);
    op[2] = __floats2bfloat162_rn(v2.x, v2.y);
    op[3] = __floats2bfloat162_rn(v3.x, v3.y);
    ov[i] = o;
  }
}

// silu(x / hc) in place on a [T, lowrank] BF16 buffer.
// Matches SGLang _mix_compute: F.silu(F.linear(...) / hc) — divide FIRST,
// then silu (NOT silu(x)/hc; the two differ because silu is nonlinear).
__global__ void SiluDivKernel(uint16_t* __restrict__ x, int total, float inv_hc) {
  const int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= total) return;
  const float v = Bf16ToFloat(x[i]) * inv_hc;
  x[i] = FloatToBf16(v / (1.0f + __expf(-v)));
}

// gate = sigmoid(up); mixed[t, c] = (1/hc) * sum_b gate[t, b*hs+c] *
// normed[t, b*hs+c]. One thread per (t, c); loops over hc branches.
__global__ void MixGateKernel(const uint16_t* __restrict__ up,
                              const uint16_t* __restrict__ normed,
                              uint16_t* __restrict__ mixed, int T, int hc,
                              int hs) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * hs) return;
  const int t = idx / hs;
  const int c = idx % hs;
  const uint16_t* uprow = up + static_cast<size_t>(t) * hc * hs;
  const uint16_t* nrow = normed + static_cast<size_t>(t) * hc * hs;
  float acc = 0.0f;
  for (int b = 0; b < hc; ++b) {
    const float g = 1.0f / (1.0f + __expf(-Bf16ToFloat(uprow[b * hs + c])));
    acc += g * Bf16ToFloat(nrow[b * hs + c]);
  }
  mixed[idx] = FloatToBf16(acc / hc);
}

// Two adjacent BF16 channels per thread. Each channel keeps the original
// branch order, FP32 gate arithmetic and final BF16 rounding.
__global__ void MixGatePairKernel(const uint16_t* __restrict__ up,
                                  const uint16_t* __restrict__ normed,
                                  uint16_t* __restrict__ mixed, int T, int hc,
                                  int hs) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  const int pairs = hs / 2;
  if (idx >= T * pairs) return;
  const int t = idx / pairs;
  const int c = idx % pairs;
  const auto* uprow = reinterpret_cast<const __nv_bfloat162*>(
      up + static_cast<size_t>(t) * hc * hs);
  const auto* nrow = reinterpret_cast<const __nv_bfloat162*>(
      normed + static_cast<size_t>(t) * hc * hs);
  float ax = 0.0f, ay = 0.0f;
  for (int b = 0; b < hc; ++b) {
    const float2 u = __bfloat1622float2(uprow[b * pairs + c]);
    const float2 n = __bfloat1622float2(nrow[b * pairs + c]);
    const float gx = 1.0f / (1.0f + __expf(-u.x));
    const float gy = 1.0f / (1.0f + __expf(-u.y));
    ax += gx * n.x;
    ay += gy * n.y;
  }
  reinterpret_cast<__nv_bfloat162*>(mixed)[idx] =
      __floats2bfloat162_rn(ax / hc, ay / hc);
}

// Precompute the inject gate 2*sigmoid(inject_raw/hc) in place, once per
// (t, b). The gate does not depend on the channel c, so folding it out of
// CombineWithGateKernel removes an hs-fold redundant sigmoid recompute there
// (CombineWithGate ran well below MixGate's memory bandwidth despite an almost
// identical access pattern; the per-c gate recompute was the gap). Bit-
// identical: the BF16 round-trip is the same one the fused kernel did in-reg.
__global__ void ApplyInjectGateKernel(uint16_t* __restrict__ inject, int total,
                                      float inv_hc) {
  const int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= total) return;
  const float v = Bf16ToFloat(inject[i]) * inv_hc;
  inject[i] = FloatToBf16(2.0f / (1.0f + __expf(-v)));
}

// Fused inject-gate + combine: out[t, b*hs+c] = R[t, b*hs+c] +
// block_output[t, c] * gate[t, b], where gate = 2*sigmoid(inject_raw[t,b]/hc)
// was precomputed into inject_gated by ApplyInjectGateKernel (one sigmoid per
// (t,b) instead of per (t,b,c)). The gate went through the same BF16 round-trip
// as the old in-register recompute, so the result is bit-identical.
__global__ void CombineWithGateKernel(
    const uint16_t* __restrict__ block_output, const uint16_t* __restrict__ R,
    const uint16_t* __restrict__ inject_gated, uint16_t* __restrict__ out,
    int T, int hc, int hs) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * hc * hs) return;
  const int t = idx / (hc * hs);
  const int rem = idx % (hc * hs);
  const int b = rem / hs;
  const int c = rem % hs;
  const float inj = Bf16ToFloat(inject_gated[static_cast<size_t>(t) * hc + b]);
  const float r = Bf16ToFloat(R[idx]);
  const float bo = Bf16ToFloat(block_output[static_cast<size_t>(t) * hs + c]);
  out[idx] = FloatToBf16(r + bo * inj);
}

Status CheckGemm(const Bf16GemmResult& r) {
  if (r.status != CUBLAS_STATUS_SUCCESS || !r.has_algo) {
    return Status::Fail(std::string("Bf16Gemm failed (status=") +
                        std::to_string((int)r.status) + ")");
  }
  return Status();
}

// Generic (T>1) HC inject path: cuBLASLt GEMM followed by the per-(t,b)
// gated sigmoid. Production code reaches it through PrepareInjectGate; the
// exported HcInjectGateGeneric (below the anonymous namespace) wraps this so
// the operator-level comparison test can run the exact T>1 path on fixed
// inputs (docs/STATUS.md 当前阶段 O0/O1).
Status HcInjectGateGenericImpl(const uint16_t* normed,
                               const uint16_t* block_inject,
                               uint16_t* inject, int T, int hc, int hs,
                               void* workspace, size_t workspace_bytes,
                               cudaStream_t stream) {
  Status s = CheckGemm(Bf16Gemm(normed, block_inject, inject, T, hc, hc * hs,
                                1.0f, 0.0f, workspace, workspace_bytes, stream));
  if (!s) return s;
  const int total = T * hc;
  ApplyInjectGateKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
      inject, total, 1.0f / hc);
  const cudaError_t error = cudaGetLastError();
  if (error != cudaSuccess) return Status::Fail(cudaGetErrorString(error));
  return {};
}

// Test-only operator capture (off by default): when Q4T_OP_CAPTURE is set to
// a directory, dump the HC inject gate operator's input, weight and output
// for operator-level comparison (docs/STATUS.md 当前阶段 O0/O1). The
// comparison test pairs the T=1 capture with the T>1 capture whose normed
// row matches, so every call is dumped (weights included; ~100 KB per call).
void MaybeCaptureHcInject(const uint16_t* normed, const uint16_t* block_inject,
                          const uint16_t* inject, int T, int hc, int hs,
                          bool fused_gate) {
  const char* dir = std::getenv("Q4T_OP_CAPTURE");
  if (dir == nullptr || *dir == '\0') return;
  static int call = 0;
  const int idx = call++;
  const std::string base = std::string(dir) + "/hc_" + std::to_string(idx) +
                           "_T" + std::to_string(T);
  auto write = [&base](const uint16_t* d, const char* name, size_t n) {
    std::vector<uint16_t> h(n);
    if (cudaMemcpy(h.data(), d, n * sizeof(uint16_t),
                   cudaMemcpyDeviceToHost) != cudaSuccess)
      return;
    FILE* f = std::fopen((std::string(base) + "_" + name + ".bin").c_str(),
                         "wb");
    if (f != nullptr) {
      std::fwrite(h.data(), 1, n * sizeof(uint16_t), f);
      std::fclose(f);
    }
  };
  // Truncate the meta on the first call so a stale capture directory does not
  // accumulate duplicate entries across runs.
  const char* meta_mode = idx == 0 ? "w" : "a";
  FILE* meta = std::fopen((std::string(dir) + "/hc_meta.txt").c_str(),
                          meta_mode);
  if (meta != nullptr) {
    std::fprintf(meta, "idx=%d T=%d hc=%d hs=%d fused=%d\n", idx, T, hc, hs,
                 fused_gate ? 1 : 0);
    std::fclose(meta);
  }
  write(normed, "normed", static_cast<size_t>(T) * hc * hs);
  write(block_inject, "block_inject", static_cast<size_t>(hc) * hc * hs);
  write(inject, "inject", static_cast<size_t>(T) * hc);
}

// Test-only capture of the mix down GEMM (the first GEMM in the layer), the
// candidate first-divergence operator (docs/STATUS.md 当前阶段 O0/O1). Gated
// on the same Q4T_OP_CAPTURE dir; dumps normed (input), mix_down (weight) and
// d_down (pre-silu output).
void MaybeCaptureMixDown(const uint16_t* normed, const uint16_t* mix_down,
                         const uint16_t* d_down, int T, int lr, int hc_dim) {
  const char* dir = std::getenv("Q4T_OP_CAPTURE");
  if (dir == nullptr || *dir == '\0') return;
  static int call = 0;
  const int idx = call++;
  const std::string base = std::string(dir) + "/mix_" + std::to_string(idx) +
                           "_T" + std::to_string(T);
  auto write = [&base](const uint16_t* d, const char* name, size_t n) {
    std::vector<uint16_t> h(n);
    if (cudaMemcpy(h.data(), d, n * sizeof(uint16_t),
                   cudaMemcpyDeviceToHost) != cudaSuccess)
      return;
    FILE* f = std::fopen((std::string(base) + "_" + name + ".bin").c_str(),
                         "wb");
    if (f != nullptr) {
      std::fwrite(h.data(), 1, n * sizeof(uint16_t), f);
      std::fclose(f);
    }
  };
  const char* meta_mode = idx == 0 ? "w" : "a";
  FILE* meta = std::fopen((std::string(dir) + "/mix_meta.txt").c_str(),
                          meta_mode);
  if (meta != nullptr) {
    std::fprintf(meta, "idx=%d T=%d lr=%d hc_dim=%d\n", idx, T, lr, hc_dim);
    std::fclose(meta);
  }
  write(normed, "normed", static_cast<size_t>(T) * hc_dim);
  write(mix_down, "mix_down", static_cast<size_t>(lr) * hc_dim);
  write(d_down, "down", static_cast<size_t>(T) * lr);
}

Status PrepareInjectGate(const HyperConnectionWeights& w,
                         const uint16_t* normed, uint16_t* inject, int T,
                         void* workspace, size_t workspace_bytes,
                         cudaStream_t stream) {
  const int hc = w.hc_count, hs = w.hidden_size;
  // ABLATION (test-only, off by default): force the T=1 HC inject to use the
  // generic Bf16Gemm + ApplyInjectGateKernel path (the same as T>1), so the HC
  // inject gate is no longer a T-dependence source. Used to confirm whether QSA
  // is the only T-dependence source in the MTP vs plain-greedy divergence (see
  // docs/log/2026-10-10.md). Default runtime behavior is unchanged when the
  // env var is unset.
  const bool ablate_hc_t1 = std::getenv("Q4T_ABLATE_HC_T1") != nullptr;
  const bool aligned =
      ((reinterpret_cast<uintptr_t>(normed) |
        reinterpret_cast<uintptr_t>(w.block_inject)) &
       15u) == 0;
  // GEMV-aligned routing: T=1 uses the fused single-row GEMV; small T (2..8,
  // the MTP verify shape T=k+1) uses the multi-row GEMV whose per-row
  // accumulation is bit-identical to the T=1 GEMV. The cuBLASLt GEMM is
  // ~129 us/call on this degenerate 4x4x10240 shape (measured 12.4 ms per
  // verify forward, 2026-10-13) versus ~5 us for the GEMV stream, and it
  // carries a 1-2 ULP accumulation delta vs the T=1 path that the GEMV
  // routing removes. Large T keeps cuBLASLt.
  const bool gemv_aligned =
      !ablate_hc_t1 && hc == 4 && hs == 2560 && aligned && T <= 8;
  bool fused_gate = false;
  if (gemv_aligned) {
    if (T == 1) {
      fused_gate = HcInjectGevGated(normed, w.block_inject, inject, stream);
    } else {
      fused_gate = HcInjectGevGatedMultirow(normed, w.block_inject, inject,
                                            T, stream);
    }
    if (!fused_gate)
      return Status::Fail("HC gated projection launch failed");
  } else {
    Status s = HcInjectGateGenericImpl(normed, w.block_inject, inject, T, hc,
                                       hs, workspace, workspace_bytes, stream);
    if (!s) return s;
  }
  MaybeCaptureHcInject(normed, w.block_inject, inject, T, hc, hs, fused_gate);
  return {};
}
}  // namespace

void HyperConnectionWeights::Free() {
  if (hc_norm) cudaFree(hc_norm);
  if (mix_down) cudaFree(mix_down);
  if (mix_up) cudaFree(mix_up);
  if (block_inject) cudaFree(block_inject);
  mix_down_fp8.Free();
  mix_up_fp8.Free();
  hc_norm = mix_down = mix_up = block_inject = nullptr;
}

Status LoadHyperConnection(const io::WeightLoader& loader,
                           const std::string& prefix, int hc_count,
                           int hidden_size, int lowrank, float eps,
                           bool use_combine, HyperConnectionWeights* out,
                           cudaStream_t stream) {
  if (hc_count <= 0 || hidden_size <= 0 || lowrank <= 0) {
    return Status::Fail("invalid HC dims");
  }
  out->hc_count = hc_count;
  out->hidden_size = hidden_size;
  out->lowrank = lowrank;
  out->eps = eps;
  out->use_combine = use_combine;
  const int hc_dim = hc_count * hidden_size;

  auto alloc = [](uint16_t** p, size_t bytes) -> Status {
    if (cudaMalloc(reinterpret_cast<void**>(p), bytes) != cudaSuccess) {
      return Status::Fail("cudaMalloc failed");
    }
    return Status();
  };
  auto load = [&loader, stream](const std::string& name, uint16_t* dst,
                                size_t bytes) -> Status {
    return loader.LoadTensorToDevice(name, dst, bytes, stream);
  };

  Status s;
  if (!(s = alloc(&out->hc_norm, hc_dim * sizeof(uint16_t)))) return s;
  if (!(s = alloc(&out->mix_down,
                  static_cast<size_t>(lowrank) * hc_dim * sizeof(uint16_t))))
    return s;
  if (!(s = alloc(&out->mix_up,
                  static_cast<size_t>(hc_dim) * lowrank * sizeof(uint16_t))))
    return s;
  if (use_combine) {
    if (!(s = alloc(&out->block_inject,
                    static_cast<size_t>(hc_count) * hc_dim * sizeof(
                        uint16_t))))
      return s;
  }

  if (!(s = load(prefix + ".hc_norm.weight", out->hc_norm,
                 hc_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".input_mix_weight_down.weight", out->mix_down,
                 static_cast<size_t>(lowrank) * hc_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".input_mix_weight_up.weight", out->mix_up,
                 static_cast<size_t>(hc_dim) * lowrank * sizeof(uint16_t))))
    return s;
  if (use_combine) {
    if (!(s = load(prefix + ".block_inject_weight.weight", out->block_inject,
                   static_cast<size_t>(hc_count) * hc_dim * sizeof(uint16_t))))
      return s;
  }
  // FP8 (e4m3) decode shadows for the low-rank mix projections (gated by
  // Q4T_FP8_PROJ / Q4T_FP8_HC). block_inject (N=hc) is tiny -> BF16.
  if (!BuildFp8Shadow(out->mix_down, lowrank, hc_dim, &out->mix_down_fp8,
                      Fp8Part::kHc, stream))
    return Status::Fail("mix_down FP8 shadow");
  if (!BuildFp8Shadow(out->mix_up, hc_dim, lowrank, &out->mix_up_fp8,
                      Fp8Part::kHc, stream))
    return Status::Fail("mix_up FP8 shadow");
  if (stream != nullptr &&
      cudaStreamSynchronize(stream) != cudaSuccess) {
    return Status::Fail("stream sync failed");
  }
  return Status();
}

// mix-down step (the first GEMM in the HC mix): down = normed @ W_down^T
// ([T, hc_dim] x [lr, hc_dim]^T -> [T, lr]). Extracted as-is from
// HyperConnectionMixImpl so the operator-level test (tests/
// gemm_t1_vs_tk1_test.cpp; docs/STATUS.md 当前阶段 O2) can drive the exact
// Debug: when Q4T_MLP_DUMP=<tag>, copy the GRRead `mixed` output (the
// attention input for the first GRRead of a layer, the MoE input for the
// second) to <tag>_mix_<idx>.bin (BF16, [T, hs]). idx is a per-tag counter
// (0-based, reset when the tag changes), so within one forward of a 2-layer
// model: layer0 GRRead#1=idx0, layer0 GRRead#2=idx1, layer1 GRRead#1=idx2,
// layer1 GRRead#2=idx3. Used to attribute the first T-path divergence inside
// the attention path (before the layer-boundary moe_in dump).
void DumpHcMixed(const uint16_t* mixed, int T, int hs) {
  const char* e = std::getenv("Q4T_MLP_DUMP");
  if (!e || !*e) return;
  static std::string last_tag_mix;
  static int idx_mix = 0;
  if (std::string(e) != last_tag_mix) {
    last_tag_mix = e;
    idx_mix = 0;
  }
  const int li = idx_mix++;
  const std::string p =
      std::string(e) + "_mix_" + std::to_string(li) + ".bin";
  std::vector<uint16_t> h(static_cast<size_t>(T) * hs);
  cudaMemcpy(h.data(), mixed, h.size() * sizeof(uint16_t),
             cudaMemcpyDeviceToHost);
  FILE* f = std::fopen(p.c_str(), "wb");
  if (f) {
    std::fwrite(h.data(), sizeof(uint16_t), h.size(), f);
    std::fclose(f);
  }
}

// production branch — row-wise candidate gate, ProjGemm fallback, capture
// hook — on fixed captured inputs, without re-running the layer norm. The
// caller owns d_down and any scratch cleanup.

// Observation-only HC mix step timing (gated by Q4T_LAYER_SUBTIMING).
inline void HcT(int op, cudaStream_t stream, bool start) {
  auto& t = HcMixSubTiming::Instance();
  if (!t.active()) return;
  if (start) t.Start(op, stream); else t.Stop(op, stream);
}

Status MixDownStep(const HyperConnectionWeights& w, const uint16_t* normed,
                   uint16_t* d_down, int T, void* workspace,
                   size_t workspace_bytes, cudaStream_t stream) {
  const int lr = w.lowrank, hc_dim = w.hc_count * w.hidden_size;
  // CANDIDATE (revertible, off by default; O2 minimal fix, see
  // docs/STATUS.md 当前阶段): for small verify/prefill batches
  // (2 <= T <= 8, cap8 experiment; cap4 was the original bound) without an
  // FP8 shadow, compute mix-down row-wise with the same M=1 GEMV kernel the
  // T=1 decode path uses, so small-batch verify follows the same
  // accumulation/rounding semantics as single-step decode. Scoped to the
  // mix-down path only (where the T=1-vs-T=4 difference was located with
  // fixed inputs); the FP8 shadow path and all other GEMMs are untouched.
  // Default runtime behavior is unchanged (env var unset).
  const bool rowwise_mix =
      std::getenv("Q4T_HC_MIX_ROWWISE_GEMV") != nullptr && T >= 2 && T <= 8 &&
      w.mix_down_fp8.w == nullptr && (hc_dim % 8) == 0;
  Status s;
  if (rowwise_mix) {
    bool ok = true;
    for (int t = 0; t < T && ok; ++t)
      ok = Bf16Gev(normed + static_cast<size_t>(t) * hc_dim, w.mix_down,
                   d_down + static_cast<size_t>(t) * lr, lr, hc_dim, 1.0f,
                   stream);
    if (!ok) return Status::Fail("mix-down rowwise GEMV failed");
  } else {
    s = CheckGemm(ProjGemm(normed, w.mix_down, &w.mix_down_fp8, d_down, T,
                           lr, hc_dim, 1.0f, 0.0f, workspace,
                           workspace_bytes, stream));
  }
  if (!s.ok()) return s;
  MaybeCaptureMixDown(normed, w.mix_down, d_down, T, lr, hc_dim);
  return s;
}

static Status HyperConnectionMixImpl(
    const HyperConnectionWeights& w, const uint16_t* hyper_input,
    uint16_t* mixed, uint16_t* normed, int T, void* workspace,
    size_t workspace_bytes, cudaStream_t stream,
    const HyperConnectionMixScratch* mix_scratch, bool normed_ready) {
  const int hc = w.hc_count, hs = w.hidden_size, lr = w.lowrank;
  const int hc_dim = hc * hs;
  if (T <= 0) return Status();
  const float inv_hc = 1.0f / hc;
  const size_t down_bytes = static_cast<size_t>(T) * lr * sizeof(uint16_t);
  const size_t up_bytes = static_cast<size_t>(T) * hc_dim * sizeof(uint16_t);
  if (mix_scratch && (!mix_scratch->down || !mix_scratch->up ||
                      mix_scratch->down_bytes < down_bytes ||
                      mix_scratch->up_bytes < up_bytes)) {
    return Status::Fail("HC mix scratch too small or missing");
  }

  if (!normed_ready) {
    // 1. Grouped RMSNorm (warp-per-branch: blockDim = 32*hc).
    HcT(0, stream, true);
    GroupedRmsNormKernel<<<T, 32 * hc, 0, stream>>>(hyper_input, w.hc_norm,
                                                    normed, T, hc, hs, w.eps);
    HcT(0, stream, false);
    const cudaError_t norm_error = cudaGetLastError();
    if (norm_error != cudaSuccess)
      return Status::Fail(std::string("rmsnorm launch: ") +
                          cudaGetErrorString(norm_error));
  }

  uint16_t* d_down = mix_scratch ? mix_scratch->down : nullptr;
  uint16_t* d_up = mix_scratch ? mix_scratch->up : nullptr;
  if (!mix_scratch) {
    if (cudaMallocAsync(&d_down, down_bytes, stream) != cudaSuccess)
      return Status::Fail("cudaMallocAsync down");
    if (cudaMallocAsync(&d_up, up_bytes, stream) != cudaSuccess) {
      cudaFreeAsync(d_down, stream);
      return Status::Fail("cudaMallocAsync up");
    }
  }
  auto release_owned = [&] {
    if (!mix_scratch) {
      cudaFreeAsync(d_down, stream);
      cudaFreeAsync(d_up, stream);
    }
  };

  // 2. down = normed @ W_down^T  ([T, hc_dim] x [lr, hc_dim]^T -> [T, lr]).
  HcT(1, stream, true);
  Status s = MixDownStep(w, normed, d_down, T, workspace, workspace_bytes,
                         stream);
  HcT(1, stream, false);
  if (!s.ok()) {
    release_owned();
    return s;
  }
  // 3. silu(down/hc) in place, with BF16 output.
  {
    const int total = T * lr;
    HcT(2, stream, true);
    SiluDivKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
        d_down, total, inv_hc);
    HcT(2, stream, false);
  }
  // 4. up = silu_down @ W_up^T  ([T, lr] x [hc_dim, lr]^T -> [T, hc_dim]).
  HcT(3, stream, true);
  s = CheckGemm(ProjGemm(d_down, w.mix_up, &w.mix_up_fp8, d_up, T, hc_dim, lr,
                         1.0f, 0.0f, workspace, workspace_bytes, stream));
  HcT(3, stream, false);
  if (!s.ok()) {
    release_owned();
    return s;
  }
  // 5. gate + mean.
  {
    HcT(4, stream, true);
    const int total = T * hs;
    const bool paired = hc == 4 && hs == 2560 &&
        ((reinterpret_cast<uintptr_t>(d_up) |
          reinterpret_cast<uintptr_t>(normed) |
          reinterpret_cast<uintptr_t>(mixed)) & 3u) == 0;
    if (paired) {
      // Keep the same number of output channels per CTA as the scalar path.
      MixGatePairKernel<<<(total + kBlock - 1) / kBlock, kBlock / 2, 0,
                          stream>>>(d_up, normed, mixed, T, hc, hs);
    } else {
      MixGateKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
          d_up, normed, mixed, T, hc, hs);
    }
    HcT(4, stream, false);
  }
  DumpHcMixed(mixed, T, hs);
  release_owned();
  return Status();
}

Status HyperConnectionMix(const HyperConnectionWeights& w,
                          const uint16_t* hyper_input, uint16_t* mixed,
                          uint16_t* normed, int T, void* workspace,
                          size_t workspace_bytes, cudaStream_t stream,
                          const HyperConnectionMixScratch* mix_scratch) {
  return HyperConnectionMixImpl(w, hyper_input, mixed, normed, T, workspace,
                                workspace_bytes, stream, mix_scratch, false);
}

GatedResidualFrame::~GatedResidualFrame() { Release(); }

cudaError_t GatedResidualFrame::Release() {
  cudaError_t error = cudaSuccess;
  if (inject_gate_ && owns_gate_) error = cudaFreeAsync(inject_gate_, stream_);
  inject_gate_ = nullptr;
  owns_gate_ = false;
  residual_ = nullptr;
  tokens_ = hc_ = hs_ = 0;
  stream_ = nullptr;
  ready_ = false;
  return error;
}

Status GatedResidualFrame::Read(const HyperConnectionWeights& w,
                                const uint16_t* residual, uint16_t* mixed,
                                uint16_t* normed_scratch, int tokens,
                                void* workspace, size_t workspace_bytes,
                                cudaStream_t stream,
                                const HyperConnectionMixScratch* mix_scratch,
                                const GatedResidualGateStorage* gate_storage) {
  return ReadImpl(w, residual, mixed, normed_scratch, tokens, workspace,
                  workspace_bytes, stream, mix_scratch, gate_storage, false);
}

Status GatedResidualFrame::ReadImpl(
    const HyperConnectionWeights& w, const uint16_t* residual, uint16_t* mixed,
    uint16_t* normed_scratch, int tokens, void* workspace,
    size_t workspace_bytes, cudaStream_t stream,
    const HyperConnectionMixScratch* mix_scratch,
    const GatedResidualGateStorage* gate_storage, bool normed_ready) {
  if (ready_ || inject_gate_)
    return Status::Fail("GR frame must be consumed before another Read");
  const bool needs_gate = tokens > 0 && w.use_combine && w.block_inject;
  const size_t gate_bytes =
      needs_gate ? static_cast<size_t>(tokens) * w.hc_count * sizeof(uint16_t)
                 : 0;
  if (needs_gate && gate_storage &&
      (!gate_storage->data || gate_storage->bytes < gate_bytes))
    return Status::Fail("GR gate storage too small or missing");
  Status s = HyperConnectionMixImpl(w, residual, mixed, normed_scratch, tokens,
                                    workspace, workspace_bytes, stream,
                                    mix_scratch, normed_ready);
  if (!s) return s;
  residual_ = residual;
  stream_ = stream;
  tokens_ = tokens;
  hc_ = w.hc_count;
  hs_ = w.hidden_size;
  if (needs_gate) {
    const cudaError_t pending = cudaGetLastError();
    if (pending != cudaSuccess) {
      Release();
      return Status::Fail(cudaGetErrorString(pending));
    }
    if (gate_storage) {
      inject_gate_ = gate_storage->data;
    } else {
      const cudaError_t error =
          cudaMallocAsync(&inject_gate_, gate_bytes, stream_);
      if (error != cudaSuccess) {
        Release();
        return Status::Fail(cudaGetErrorString(error));
      }
      owns_gate_ = true;
    }
    HcT(5, stream_, true);
    s = PrepareInjectGate(w, normed_scratch, inject_gate_, tokens, workspace,
                          workspace_bytes, stream_);
    HcT(5, stream_, false);
    if (!s) {
      Release();
      return s;
    }
  }
  ready_ = true;
  return {};
}

Status GatedResidualFrame::Write(const uint16_t* block_output,
                                 uint16_t* output) {
  if (!ready_) return Status::Fail("GR Write requires a ready frame");
  cudaError_t error = cudaSuccess;
  if (tokens_ > 0) {
    if (inject_gate_) {
      const int total = tokens_ * hc_ * hs_;
      HcT(6, stream_, true);
      CombineWithGateKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0,
                              stream_>>>(block_output, residual_, inject_gate_,
                                         output, tokens_, hc_, hs_);
      HcT(6, stream_, false);
      error = cudaGetLastError();
    } else {
      error = cudaMemcpyAsync(output, residual_,
                              static_cast<size_t>(tokens_) * hc_ * hs_ * 2,
                              cudaMemcpyDeviceToDevice, stream_);
    }
  }
  const cudaError_t release_error = Release();
  if (error != cudaSuccess) return Status::Fail(cudaGetErrorString(error));
  if (release_error != cudaSuccess)
    return Status::Fail(cudaGetErrorString(release_error));
  return {};
}
Status GatedResidualFrame::WriteAndRead(
    const uint16_t* block_output, uint16_t* combined,
    const HyperConnectionWeights& next_weights, GatedResidualFrame& next_frame,
    uint16_t* mixed, uint16_t* normed, void* workspace, size_t workspace_bytes,
    const HyperConnectionMixScratch* mix_scratch,
    const GatedResidualGateStorage* gate_storage) {
  if (!ready_) return Status::Fail("GR Write requires a ready frame");
  if (&next_frame == this || next_frame.ready_ || next_frame.inject_gate_)
    return Status::Fail("GR next frame must be distinct and empty");
  const int tokens = tokens_;
  const cudaStream_t stream = stream_;
  const bool aligned =
      ((reinterpret_cast<uintptr_t>(block_output) |
        reinterpret_cast<uintptr_t>(residual_) |
        reinterpret_cast<uintptr_t>(next_weights.hc_norm) |
        reinterpret_cast<uintptr_t>(combined) |
        reinterpret_cast<uintptr_t>(normed)) & 15u) == 0;
  if (!inject_gate_ || tokens <= 0 || hc_ != 4 || hs_ != 2560 || !aligned ||
      next_weights.hc_count != 4 || next_weights.hidden_size != 2560) {
    Status s = Write(block_output, combined);
    if (!s) return s;
    return next_frame.Read(next_weights, combined, mixed, normed, tokens,
                           workspace, workspace_bytes, stream, mix_scratch,
                           gate_storage);
  }
  HcT(6, stream, true);
  CombineAndGroupedNormKernel<<<tokens, 128, 0, stream>>>(
      block_output, residual_, inject_gate_, next_weights.hc_norm, combined,
      normed, tokens, hc_, hs_, next_weights.eps);
  HcT(6, stream, false);
  const cudaError_t launch_error = cudaGetLastError();
  const cudaError_t release_error = Release();
  if (launch_error != cudaSuccess)
    return Status::Fail(cudaGetErrorString(launch_error));
  if (release_error != cudaSuccess)
    return Status::Fail(cudaGetErrorString(release_error));
  return next_frame.ReadImpl(next_weights, combined, mixed, normed, tokens,
                             workspace, workspace_bytes, stream, mix_scratch,
                             gate_storage, true);
}

Status HyperConnectionCombine(const HyperConnectionWeights& w,
                              const uint16_t* block_output,
                              const uint16_t* hyper_input,
                              const uint16_t* normed, uint16_t* out, int T,
                              void* workspace, size_t workspace_bytes,
                              cudaStream_t stream) {
  const int hc = w.hc_count, hs = w.hidden_size;
  const int hc_dim = hc * hs;
  if (T <= 0) return Status();
  if (!w.use_combine || w.block_inject == nullptr) {
    // No combine (mixer): pass the residual through unchanged.
    if (cudaMemcpyAsync(out, hyper_input, static_cast<size_t>(T) * hc_dim *
                                              sizeof(uint16_t),
                        cudaMemcpyDeviceToDevice, stream) != cudaSuccess) {
      return Status::Fail("D2D copy failed");
    }
    return Status();
  }
  // Check for a pending async error from a prior kernel (e.g. an illegal
  // memory access in the attention path). A tiny 8-byte cudaMalloc failing
  // with 37 GB available is a classic sign of a poisoned context, not a
  // genuine OOM.
  const cudaError_t perr = cudaGetLastError();
  if (perr != cudaSuccess) {
    return Status::Fail(std::string("pending CUDA error before cudaMalloc "
                                    "inject: ") +
                        cudaGetErrorString(perr));
  }
  uint16_t* d_inject = nullptr;  // [T, hc]
  const cudaError_t merr =
      cudaMallocAsync(&d_inject, static_cast<size_t>(T) * hc * sizeof(uint16_t),
                      stream);
  if (merr != cudaSuccess) {
    return Status::Fail(std::string("cudaMallocAsync inject: ") +
                        cudaGetErrorString(merr));
  }
  HcT(5, stream, true);
  Status s = PrepareInjectGate(w, normed, d_inject, T, workspace,
                               workspace_bytes, stream);
  HcT(5, stream, false);
  if (!s) {
    cudaFreeAsync(d_inject, stream);
    return s;
  }
  const int total = T * hc_dim;
  HcT(6, stream, true);
  CombineWithGateKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
      block_output, hyper_input, d_inject, out, T, hc, hs);
  HcT(6, stream, false);
  cudaFreeAsync(d_inject, stream);
  return Status();
}

// Exported wrapper for the operator-level comparison test
// (tests/gemm_t1_vs_tk1_test.cpp). See HcInjectGateGenericImpl above.
Status HcInjectGateGeneric(const uint16_t* normed, const uint16_t* block_inject,
                           uint16_t* inject, int T, int hc, int hs,
                           void* workspace, size_t workspace_bytes,
                           cudaStream_t stream) {
  return HcInjectGateGenericImpl(normed, block_inject, inject, T, hc, hs,
                                 workspace, workspace_bytes, stream);
}

}  // namespace model
}  // namespace q4t

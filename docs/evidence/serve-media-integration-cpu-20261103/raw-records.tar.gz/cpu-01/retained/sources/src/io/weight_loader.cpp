// Weight loading orchestration implementation.
#include "q4t/io/weight_loader.h"

#include <deque>
#include <fstream>
#include <sstream>

#include "q4t/io/json.h"
#include "q4t/io/pending_host_storage.h"

namespace q4t {
namespace io {

namespace {

Status ReadFile(const std::string& path, std::string* out) {
  std::ifstream in(path, std::ios::binary);
  if (!in) return Status::Fail("cannot open " + path);
  std::ostringstream ss;
  ss << in.rdbuf();
  *out = ss.str();
  return Status();
}

}  // namespace

// ---------------------------------------------------------------------------
// WeightIndex
// ---------------------------------------------------------------------------
struct WeightIndex::Impl {
  std::unordered_map<std::string, std::string> weight_map;
  uint64_t total_size = 0;
  // shard -> tensors (in index order).
  std::vector<std::pair<std::string, std::vector<std::string>>> groups;
  std::unordered_map<std::string, size_t> group_index;
};

WeightIndex::WeightIndex(Impl* impl) : impl_(impl) {}

WeightIndex::~WeightIndex() {
  delete impl_;
  impl_ = nullptr;
}

Status WeightIndex::Open(const std::string& path, WeightIndex** out) {
  *out = nullptr;
  std::string text;
  Status s = ReadFile(path, &text);
  if (!s.ok()) return s;

  Json root;
  s = ParseJson(text, &root);
  if (!s.ok()) return s;
  if (!root.IsObject()) return Status::Fail("index.json is not an object");

  const Json* wm = root.GetArray("weight_map");
  if (!wm && (wm = root.Find("weight_map")) && !wm->IsObject()) {
    return Status::Fail("index.json missing weight_map object");
  }
  if (!wm || !wm->IsObject()) {
    return Status::Fail("index.json missing weight_map object");
  }

  Impl* impl = new Impl();
  impl->weight_map.reserve(wm->object.size());
  for (const auto& kv : wm->object) {
    if (!kv.second.IsString()) {
      delete impl;
      return Status::Fail("weight_map value is not a string: " + kv.first);
    }
    impl->weight_map.emplace(kv.first, kv.second.str);
    auto it = impl->group_index.find(kv.second.str);
    if (it == impl->group_index.end()) {
      it = impl->group_index.emplace(kv.second.str, impl->groups.size()).first;
      impl->groups.emplace_back(kv.second.str, std::vector<std::string>());
    }
    impl->groups[it->second].second.push_back(kv.first);
  }

  const Json* meta = root.Find("metadata");
  if (meta && meta->IsObject()) {
    impl->total_size = static_cast<uint64_t>(meta->GetNumber("total_size"));
  }

  *out = new WeightIndex(impl);
  return Status();
}

const std::string* WeightIndex::ShardOf(const std::string& name) const {
  auto it = impl_->weight_map.find(name);
  return it == impl_->weight_map.end() ? nullptr : &it->second;
}

bool WeightIndex::Has(const std::string& name) const {
  return impl_->weight_map.find(name) != impl_->weight_map.end();
}

size_t WeightIndex::num_tensors() const { return impl_->weight_map.size(); }

size_t WeightIndex::num_shards() const { return impl_->groups.size(); }

uint64_t WeightIndex::total_size() const { return impl_->total_size; }

std::vector<std::pair<std::string, std::vector<std::string>>>
WeightIndex::ShardGroups() const {
  return impl_->groups;
}

// ---------------------------------------------------------------------------
// WeightLoader
// ---------------------------------------------------------------------------
struct WeightLoader::Impl {
  std::string model_dir;
  const WeightIndex* index = nullptr;
  size_t max_open = 8;
  std::mutex* owner_mu = nullptr;  // the loader's mutex (set in Create)
  // Page-cache retention (tiered MoE residency): shards whose name contains
  // keep_marker (empty = all) skip the destructor's FADV_DONTNEED.
  bool keep_page_cache = false;
  std::string keep_marker;

  // Mutable: EnsureOpen is logically const (no observable change to the
  // loader's contract) but manages the open-shard cache.
  using ShardHandle = std::shared_ptr<SafetensorsFile>;
  mutable std::unordered_map<std::string, ShardHandle> open;
  mutable std::deque<std::string> lru;  // most-recent at back
  // FindTensor returns a stable pointer. Cache metadata independently of the
  // shard handles: LRU eviction must not invalidate a caller's TensorInfo.
  // Entries are immutable and never erased during the loader's lifetime.
  mutable std::unordered_map<std::string, TensorInfo> metadata;

  Status EnsureOpen(const std::string& shard, ShardHandle* out) const;
};

Status WeightLoader::Impl::EnsureOpen(const std::string& shard,
                                     ShardHandle* out) const {
  // Called concurrently by the parallel MoE expert load; guard the LRU cache.
  std::lock_guard<std::mutex> lock(*owner_mu);
  auto it = open.find(shard);
  if (it != open.end()) {
    // Move to MRU.
    for (auto l = lru.begin(); l != lru.end(); ++l) {
      if (*l == shard) {
        lru.erase(l);
        break;
      }
    }
    lru.push_back(shard);
    *out = it->second;
    return Status();
  }

  // Evict LRU if at capacity.
  while (open.size() >= max_open && !lru.empty()) {
    const std::string victim = lru.front();
    lru.pop_front();
    open.erase(victim);
  }

  const std::string path = model_dir + "/" + shard;
  SafetensorsFile* f = nullptr;
  Status s = SafetensorsFile::Open(path, &f);
  if (!s.ok()) return s;
  if (keep_page_cache &&
      (keep_marker.empty() || shard.find(keep_marker) != std::string::npos)) {
    f->SetKeepPageCache(true);
  }
  auto inserted = open.emplace(shard, std::shared_ptr<SafetensorsFile>(f));
  lru.push_back(shard);
  *out = inserted.first->second;
  return Status();
}

void WeightLoader::SetKeepPageCache(bool keep,
                                    const std::string& shard_marker) {
  std::lock_guard<std::mutex> lock(mu_);
  impl_->keep_page_cache = keep;
  impl_->keep_marker = shard_marker;
  for (auto& [name, sh] : impl_->open) {
    if (keep &&
        (shard_marker.empty() ||
         name.find(shard_marker) != std::string::npos)) {
      sh->SetKeepPageCache(true);
    }
  }
}

WeightLoader::WeightLoader(Impl* impl) : impl_(impl) {}

WeightLoader::~WeightLoader() {
  delete impl_;
  impl_ = nullptr;
}

Status WeightLoader::Create(const std::string& model_dir,
                            const WeightIndex& index, size_t max_open_shards,
                            WeightLoader** out) {
  *out = nullptr;
  if (max_open_shards == 0) max_open_shards = 1;
  Impl* impl = new Impl();
  impl->model_dir = model_dir;
  impl->index = &index;
  impl->max_open = max_open_shards;
  WeightLoader* loader = new WeightLoader(impl);
  impl->owner_mu = &loader->mu_;  // wire the LRU lock after construction
  *out = loader;
  return Status();
}

const TensorInfo* WeightLoader::FindTensor(const std::string& name) const {
  {
    std::lock_guard<std::mutex> lock(mu_);
    auto it = impl_->metadata.find(name);
    if (it != impl_->metadata.end()) return &it->second;
  }
  const std::string* shard = impl_->index->ShardOf(name);
  if (!shard) return nullptr;
  std::shared_ptr<SafetensorsFile> sh;
  if (!impl_->EnsureOpen(*shard, &sh).ok()) return nullptr;
  const TensorInfo* info = sh->Find(name);
  if (!info) return nullptr;
  std::lock_guard<std::mutex> lock(mu_);
  return &impl_->metadata.emplace(name, *info).first->second;
}

const std::string* WeightLoader::ShardOf(const std::string& name) const {
  return impl_->index->ShardOf(name);
}

Status WeightLoader::ReadTensor(const std::string& name, void* dst) const {
  const std::string* shard = impl_->index->ShardOf(name);
  if (!shard) return Status::Fail("tensor not in index: " + name);
  std::shared_ptr<SafetensorsFile> sh;
  Status s = impl_->EnsureOpen(*shard, &sh);
  if (!s.ok()) return s;
  const TensorInfo* info = sh->Find(name);
  if (!info) return Status::Fail("tensor not in shard " + *shard + ": " + name);
  return sh->ReadTensor(*info, dst);
}

Status WeightLoader::ReadTensor(const std::string& name, void* dst,
                                size_t expected_bytes) const {
  const std::string* shard = impl_->index->ShardOf(name);
  if (!shard) return Status::Fail("tensor not in index: " + name);
  std::shared_ptr<SafetensorsFile> sh;
  Status s = impl_->EnsureOpen(*shard, &sh);
  if (!s.ok()) return s;
  const TensorInfo* info = sh->Find(name);
  if (!info || info->byte_size() != expected_bytes ||
      (!dst && expected_bytes != 0)) {
    return Status::Fail("tensor destination/size mismatch: " + name);
  }
  return sh->ReadTensor(*info, dst);
}

Status WeightLoader::ReadRange(const std::string& name, uint64_t offset,
                               size_t length, void* dst) const {
  const std::string* shard = impl_->index->ShardOf(name);
  if (!shard) return Status::Fail("tensor not in index: " + name);
  std::shared_ptr<SafetensorsFile> sh;
  Status s = impl_->EnsureOpen(*shard, &sh);
  if (!s.ok()) return s;
  return sh->ReadRange(offset, length, dst);
}

Status WeightLoader::ReadRangeShard(const std::string& shard, uint64_t offset,
                                    size_t length, void* dst) const {
  std::shared_ptr<SafetensorsFile> sh;
  Status s = impl_->EnsureOpen(shard, &sh);
  if (!s.ok()) return s;
  return sh->ReadRange(offset, length, dst);
}

Status WeightLoader::ReadRangevShard(const std::string& shard, uint64_t offset,
                                     size_t count, const void* const* dsts,
                                     const size_t* lens) const {
  std::shared_ptr<SafetensorsFile> sh;
  Status s = impl_->EnsureOpen(shard, &sh);
  if (!s.ok()) return s;
  return sh->ReadRangev(offset, count, dsts, lens);
}

Status WeightLoader::ReadTensorToDevice(const std::string& name, void* dst,
                                        void* device_dst,
                                        cudaStream_t stream) const {
  const std::string* shard = impl_->index->ShardOf(name);
  if (!shard) return Status::Fail("tensor not in index: " + name);
  std::shared_ptr<SafetensorsFile> sh;
  Status s = impl_->EnsureOpen(*shard, &sh);
  if (!s.ok()) return s;
  const TensorInfo* info = sh->Find(name);
  if (!info) return Status::Fail("tensor not in shard " + *shard + ": " + name);
  return sh->ReadTensorToDevice(*info, dst, device_dst, stream);
}

Status WeightLoader::LoadTensorToDevice(const std::string& name,
                                         void* device_dst,
                                         size_t expected_bytes,
                                         cudaStream_t stream) const {
  const TensorInfo* info = FindTensor(name);
  if (!device_dst || expected_bytes == 0 || !info ||
      info->byte_size() != expected_bytes)
    return Status::Fail("load tensor: destination/size mismatch: " + name);
  try {
    PendingHostStorage<std::vector<uint8_t>> host(stream, expected_bytes);
    Status status = ReadTensor(name, host.Get().data(), expected_bytes);
    if (!status.ok()) return status;
    host.MarkPending();
    const cudaError_t error = cudaMemcpyAsync(
        device_dst, host.Get().data(), expected_bytes, cudaMemcpyHostToDevice,
        stream);
    status = host.Drain();  // Also drain a failed, possibly submitted call.
    if (!status.ok()) return status;
    if (error != cudaSuccess)
      return Status::Fail("load tensor H2D: " + name + ": " +
                          cudaGetErrorString(error));
    return Status();
  } catch (const std::bad_alloc&) {
    return Status::Fail("load tensor host allocation: " + name);
  }
}

size_t WeightLoader::open_shards() const {
  std::lock_guard<std::mutex> lock(mu_);
  return impl_->open.size();
}

}  // namespace io
}  // namespace q4t

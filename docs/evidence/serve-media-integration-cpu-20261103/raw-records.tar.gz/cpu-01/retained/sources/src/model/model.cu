// Complete qwen4_exp model — implementation. See include/q4t/model/model.h.
//
// ModelForward (prefill, fresh sequence, positions 0..T-1):
//   1. d_ids = input_ids; positions = 0..T-1
//   2. emb = head.EmbedLookup(d_ids)            [T, hs]
//   3. trunk = head.ExpandTrunk(emb)            [T, hc*hs]
//   4. for l in [0, num_layers):
//        [if layers[l].has_ple]
//          history[t] = ngram_size-1 preceding tokens (EOS-filled at start)
//          ple_emb = PleEmbedding::Gather(ids, history)   [T, pe] (SSD stream)
//          ple_emb *= weight_scale
//        trunk = DecoderLayerForward(layers[l], trunk, ple_emb, positions, ...)
//   5. logits = head.HeadForward(trunk)         [T, vocab]
//
// The trunk ping-pongs between d_trunk / d_trunk2 so each layer reads one
// buffer and writes the other. The forward workspace d_ws is reused across
// layers (they run sequentially); its size is the max over all layers.
#include "q4t/model/model.h"
#include "q4t/model/layer_subtiming.h"
#include "q4t/model/hc_mix_subtiming.h"
#include "q4t/quant/moe_subtiming.h"

#include "q4t/runtime/residency_config.h"
#include "q4t/runtime/cleanup_policy.h"

#include <cuda_bf16.h>
#include <cuda_runtime.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <numeric>
#include <string>
#include <utility>
#include <vector>

namespace {
// Optional per-phase load timing (Q4T_LOAD_TIMING=1). Zero overhead when the
// env var is unset (a single getenv check per phase).
inline bool LoadTimingEnabled() {
  static const bool on = std::getenv("Q4T_LOAD_TIMING") != nullptr;
  return on;
}
inline double NowMs() {
  return std::chrono::duration<double, std::milli>(
             std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
}  // namespace

#include "q4t/model/linear.h"

namespace q4t {
namespace model {

namespace {

constexpr int kBlock = 256;

void InvalidateVerifyCheckpoints(const Model& m) {
  m.verify_ckpt_rows = 0;
  m.verify_ckpt_slots.clear();
}

Status CheckVerifyCheckpointCapacity(const Model& m, int rows) {
  if (rows == 0) return Status();
  if (rows < 0 || rows > m.verify_ckpt_cap || !m.d_verify_ssm_ckpt ||
      !m.d_verify_conv_ckpt)
    return Status::Fail("verify checkpoints: reserve at least T-1 rows first");
  for (const auto& layer : m.layers) {
    if (layer.has_ple && !m.d_verify_ple_conv_ckpt)
      return Status::Fail("verify checkpoints: missing PLE checkpoint buffer");
  }
  return Status();
}

// The inactive trunk buffer is dead after the decoder loop. Pack each
// sequence's final row there before the head, without another allocation.
__global__ void GatherSequenceLastRowsKernel(
    const uint16_t* __restrict__ trunk, uint16_t* __restrict__ selected,
    const int* __restrict__ offsets, int width) {
  const int b = blockIdx.y;
  const int col = blockIdx.x * blockDim.x + threadIdx.x;
  if (col < width) {
    selected[static_cast<size_t>(b) * width + col] =
        trunk[static_cast<size_t>(offsets[b + 1] - 1) * width + col];
  }
}


// ple_emb[i] *= scale (in place, BF16).
__global__ void ScaleBf16Kernel(uint16_t* __restrict__ x, int total,
                                float scale) {
  const int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= total) return;
  uint32_t bits = static_cast<uint32_t>(x[i]) << 16;
  float f;
  std::memcpy(&f, &bits, sizeof(f));
  const __nv_bfloat16 r = __float2bfloat16_rn(f * scale);
  x[i] = *reinterpret_cast<const uint16_t*>(&r);
}

// Replace image-token embeddings with vision features (multimodal injection).
// d_img_pos[i] = the position of the i-th <image> token in the sequence;
// vision_src[i*hs .. (i+1)*hs] (device BF16) is copied over d_emb at that
// position. One thread per (i, j) element. Mirrors vllm's
// `_merge_multimodal_embeddings` (inputs_embeds[is_multimodal] = mm_embeds).
__global__ void InjectVisionKernel(const uint16_t* __restrict__ vision_src,
                                   const int* __restrict__ d_img_pos,
                                   uint16_t* __restrict__ d_emb, int hs,
                                   int num_tokens) {
  const int i = blockIdx.x * blockDim.x + threadIdx.x;
  const int total = num_tokens * hs;
  if (i >= total) return;
  const int tok = i / hs;
  const int j = i - tok * hs;
  const int pos = d_img_pos[tok];
  d_emb[pos * hs + j] = vision_src[i];
}

}  // namespace

void Model::Free() {
  const runtime::CleanupPhase phase("model.release");
  metadata_upload.reset();
  decode_metadata_upload.reset();
  head.Free();
  for (auto& l : layers) l.Free();
  layers.clear();
  weight_loader.reset();
  weight_index.reset();
  if (ple_emb) delete ple_emb;
  ple_emb = nullptr;
  auto freep = [](void* p) {
    if (p) cudaFree(p);
  };
  freep(d_ids);
  freep(d_positions);
  freep(d_seq_id);
  freep(d_token_seq_id);
  freep(d_ragged_seq_offset);
  freep(d_ragged_token_local);
  freep(d_rope_pos);
  freep(d_emb);
  freep(d_trunk);
  freep(d_trunk2);
  freep(d_ple_emb);
  freep(d_img_pos);
  freep(d_ws);
  freep(d_verify_ssm_ckpt);
  freep(d_verify_conv_ckpt);
  freep(d_verify_ple_conv_ckpt);
  d_ids = nullptr;
  d_positions = nullptr;
  d_seq_id = nullptr;
  d_token_seq_id = nullptr;
  d_ragged_seq_offset = nullptr;
  d_ragged_token_local = nullptr;
  d_rope_pos = nullptr;
  d_emb = nullptr;
  d_trunk = nullptr;
  d_trunk2 = nullptr;
  d_ple_emb = nullptr;
  d_img_pos = nullptr;
  d_ws = nullptr;
  d_verify_ssm_ckpt = nullptr;
  d_verify_conv_ckpt = nullptr;
  d_verify_ple_conv_ckpt = nullptr;
  verify_ckpt_cap = 0;
  InvalidateVerifyCheckpoints(*this);
  ws_bytes = 0;
}

Status LoadPleHashParams(const io::WeightLoader& loader,
                         const std::string& ple_prefix,
                         ple::NgramHashParams* out, float* weight_scale,
                         cudaStream_t stream) {
  (void)stream;
  const std::string base = ple_prefix + ".ple_embedding.";
  // layer_multipliers: I64 [ngram_size]
  {
    const io::TensorInfo* info = loader.FindTensor(base + "layer_multipliers");
    if (!info) return Status::Fail("missing layer_multipliers");
    out->multipliers.assign(info->numel(), 0);
    Status s = loader.ReadTensor(base + "layer_multipliers",
                                 out->multipliers.data());
    if (!s.ok()) return s;
  }
  // ngram_heads_vocab_sizes: I64 [ngram_heads]
  {
    const io::TensorInfo* info =
        loader.FindTensor(base + "ngram_heads_vocab_sizes");
    if (!info) return Status::Fail("missing ngram_heads_vocab_sizes");
    out->head_vocab_sizes.assign(info->numel(), 0);
    Status s = loader.ReadTensor(base + "ngram_heads_vocab_sizes",
                                 out->head_vocab_sizes.data());
    if (!s.ok()) return s;
  }
  // ngram_heads_offsets: I64 [ngram_heads]
  {
    const io::TensorInfo* info =
        loader.FindTensor(base + "ngram_heads_offsets");
    if (!info) return Status::Fail("missing ngram_heads_offsets");
    out->head_offsets.assign(info->numel(), 0);
    Status s = loader.ReadTensor(base + "ngram_heads_offsets",
                                 out->head_offsets.data());
    if (!s.ok()) return s;
  }
  // ngram_embedding.weight_scale: BF16 [1]
  {
    uint16_t raw = 0;
    Status s = loader.ReadTensor(base + "ngram_embedding.weight_scale", &raw);
    if (!s.ok()) return s;
    uint32_t bits = static_cast<uint32_t>(raw) << 16;
    std::memcpy(weight_scale, &bits, sizeof(float));
  }
  return Status();
}

Status LoadModel(const ModelConfig& cfg, Model* m, cudaStream_t stream) {
  const runtime::CleanupPhase phase("model.load");
  if (!runtime::ValidSequenceCapacities(cfg.seq_capacities, cfg.max_len,
                                        cfg.max_seq))
    return Status::Fail("invalid model slot capacities");
  runtime::ResidencyConfig residency_config;
  Status residency_status = runtime::LoadResidencyConfig(
      cfg.moe_hot_list, cfg.num_layers, cfg.E, cfg.moe_resident_slots,
      &residency_config);
  if (!residency_status.ok()) return residency_status;
  m->cfg = cfg;
  // RAII: the mmap'd safetensors shards must be released on every exit path.
  // On Jetson Thor's 122 GB unified memory, keeping the ~84 GB of file
  // mappings alive alongside the ~84 GB of GPU weights exceeds the budget.
  // (Same fix as qwen35-thor model.cpp: "统一内存: 立即释放 mmap".)
  {
    io::WeightIndex* raw = nullptr;
    Status s = io::WeightIndex::Open(cfg.index_path, &raw);
    if (!s.ok()) return s;
    m->weight_index.reset(raw);
  }
  {
    io::WeightLoader* raw = nullptr;
    // max_open_shards: the parallel MoE expert load reads from multiple
    // shards concurrently. A small LRU (32) thrashes under tiered residency
    // decode: each expert miss does ~15 EnsureOpen calls on its shard, and
    // with 16 staging workers and only 32 open slots the shard is evicted
    // (munmap) and reopened (open+mmap+200 KB header JSON parse, ~1.5 ms)
    // between those calls, so the decode miss critical path is dominated by
    // reopens, not preads. Raising the cap so all ~197 shards stay open
    // removes the reopen cost. This does NOT repeat the old OpenAllShards
    // regression (docs/log/2026-09-19): that pre-opened every shard at
    // startup and read data through the mmap, so 14 workers' data page
    // faults contended on the kernel VMA/page-table locks. Here shards open
    // lazily on first use and data is read with pread (no process page
    // faults; the mmap is touched only for the header), so keeping them
    // open costs only the one-time header parse plus virtual address space.
    // Override with Q4T_MOE_MAX_OPEN_SHARDS (0 = all shards in the index).
    size_t max_open_shards = 32;
    if (const char* env = std::getenv("Q4T_MOE_MAX_OPEN_SHARDS")) {
      const int v = std::atoi(env);
      if (v > 0) max_open_shards = static_cast<size_t>(v);
      else if (v == 0) {
        max_open_shards = m->weight_index->num_shards() + 8;
      }
    }
    Status s = io::WeightLoader::Create(cfg.model_dir, *m->weight_index,
                                       max_open_shards, &raw);
    if (!s.ok()) return s;
    m->weight_loader.reset(raw);
  }
  io::WeightLoader& loader = *m->weight_loader;
  Status s;

  const int hc_dim = cfg.hc * cfg.hs;
  double t_head = 0, t_layers = 0, t_ple = 0, t_buf = 0, t_sync = 0;
  const bool lt = LoadTimingEnabled();
  double t0 = lt ? NowMs() : 0.0;

  // 1. Head (embed + lm_head + mixer).
  s = LoadModelHead(loader, cfg.vocab, cfg.hs, cfg.hc, cfg.lowrank, cfg.eps,
                    &m->head, stream);
  if (!s.ok()) return s;
  if (lt) t_head = NowMs() - t0;

  // 2. Decoder layers [0, num_layers).
  m->layers.resize(cfg.num_layers);
  // Tiered residency keeps the loader for the model's lifetime (on-demand
  // expert loads); the baseline path releases it once loading is done.
  const bool keep_loader = cfg.moe_resident_slots > 0;
  if (keep_loader) {
    // C5 (page-cache retention, residency layer; GEMM untouched): slot mode
    // streams experts from ~192 shards for the model's lifetime, but the
    // open-shard LRU evicts shards as they rotate out of the 32-entry set,
    // and the SafetensorsFile destructor then issues POSIX_FADV_DONTNEED on
    // the whole evicted shard. That wipes the page-cache pages the C3
    // pre-warm filled, so every on-demand expert pread falls back to NVMe
    // (~4 ms) instead of the warm cache (~0.5 ms) -- the dominant decode
    // miss critical-path cost (pilot-45056: pread_avg 4.0 ms, decode
    // 4.86 tps = 27% of baseline vs the 50% gate). Keep the expert shards'
    // pages; non-expert shards (already GPU-resident) still evict as before.
    loader.SetKeepPageCache(true, "-experts-");
    // Slot-mode stream safety (residency-layer guard; GEMM itself untouched):
    // on-demand expert loads/evictions are stream-ordered on the caller's
    // stream, but MoERoutedForward's extra GEMM streams read slot weights
    // without waiting for those H2Ds (cross-stream race -> wrong weights).
    // The GEMM stream count is env-configured (Q4T_MOE_STREAMS, default 4);
    // slot mode forces single-stream GEMM so every slot read is ordered after
    // its load and before its eviction. Set before the first forward.
    const char* env = std::getenv("Q4T_MOE_STREAMS");
    const int n = env ? std::atoi(env) : 4;
    if (n != 1) {
      setenv("Q4T_MOE_STREAMS", "1", 1);
      std::fprintf(stderr,
                   "[q4t][residency] Q4T_MOE_STREAMS forced to 1: slot-mode "
                   "loads are stream-ordered; extra GEMM streams would race "
                   "slot H2Ds\n");
    }
  }
  // The budget and loader share empty/missing-layer capacity semantics.
  const auto& hot_lists = residency_config.hot_lists;
  const auto& c_layer = residency_config.layer_slots;
  const int c_total = static_cast<int>(residency_config.total_slots);
  const bool nonuniform = std::any_of(
      c_layer.begin(), c_layer.end(),
      [&](int slots) { return slots != cfg.moe_resident_slots; });
  if (lt && nonuniform) {
    std::fprintf(stderr,
                 "[q4t][residency] non-uniform per-layer C: total=%d "
                 "(max/layer=%d): ",
                 c_total, cfg.moe_resident_slots);
    for (int l = 0; l < cfg.num_layers; ++l) {
      std::fprintf(stderr, "%d%s", c_layer[l],
                   l + 1 < cfg.num_layers ? "," : "\n");
    }
  }
  t0 = lt ? NowMs() : 0.0;
  for (int l = 0; l < cfg.num_layers; ++l) {
    const std::vector<int>* hot =
        (cfg.moe_resident_slots > 0 && !hot_lists[l].empty())
            ? &hot_lists[l]
            : nullptr;
    s = LoadDecoderLayer(loader, l, cfg.hs, cfg.hc, cfg.lowrank, cfg.eps, cfg.E,
                         cfg.moe_is, cfg.shared_is, cfg.topk, cfg.max_len,
                         cfg.max_seq, &m->layers[l], stream, c_layer[l], hot,
                         cfg.moe_hot_protect, cfg.seq_capacities);
    if (!s.ok()) return s;
  }
  if (lt) t_layers = NowMs() - t0;

  // 3. PLE embedding (only if a PLE layer is in range).
  bool any_ple = false;
  for (auto& l : m->layers) any_ple = any_ple || l.has_ple;
  if (any_ple) {
    t0 = lt ? NowMs() : 0.0;
    // Load hash params + weight_scale from the (first) PLE layer.
    int ple_layer = -1;
    for (int l = 0; l < cfg.num_layers; ++l) {
      if (m->layers[l].has_ple) {
        ple_layer = l;
        break;
      }
    }
    const std::string ple_prefix =
        "model.language_model.layers." + std::to_string(ple_layer) + ".ple";
    m->ple_hash.ngram_size = cfg.ple_ngram_size;
    m->ple_hash.heads_per_ngram = cfg.ple_heads_per_ngram;
    s = LoadPleHashParams(loader, ple_prefix, &m->ple_hash,
                          &m->ple_weight_scale, stream);
    if (!s.ok()) return s;

    ple::PleEmbedding::Config pcfg;
    pcfg.sidecar_path = cfg.ple_sidecar;
    pcfg.row_bytes = cfg.ple_row_bytes;
    pcfg.total_rows = cfg.ple_total_rows;
    pcfg.hash_params = m->ple_hash;
    pcfg.eos_token_id = cfg.eos_token_id;
    pcfg.capacity_tokens = cfg.ple_capacity_tokens;
    s = ple::PleEmbedding::Create(pcfg, &m->ple_emb);
    if (!s.ok()) return s;
    if (lt) t_ple = NowMs() - t0;
  }

  // 4. Persistent forward buffers.
  t0 = lt ? NowMs() : 0.0;
  const size_t max_t = static_cast<size_t>(cfg.max_prefill);
  auto alloc = [](void** p, size_t bytes) -> Status {
    if (cudaMalloc(p, bytes) != cudaSuccess) return Status::Fail("cudaMalloc");
    return Status();
  };
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_ids), max_t * sizeof(int32_t))))
    return s;
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_positions),
                  max_t * sizeof(int))))
    return s;
  // B2 multi-seq decode: per-token pooled-state slice index (H2D per forward,
  // sized for the max batch of concurrent sequences).
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_seq_id),
                  static_cast<size_t>(cfg.max_seq) * sizeof(int))))
    return s;
  m->metadata_upload = std::make_unique<MetadataUploadBatch>();
  m->decode_metadata_upload = std::make_unique<DecodeMetadataUpload>();
  s = m->decode_metadata_upload->Init(cfg.max_seq);
  if (!s.ok()) return s;
  // Phase 2 MTP multi-seq verify: per-token seq id for the B*T packed verify
  // tokens (sized for the max prefill, since B*T <= max_prefill).
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_token_seq_id),
                  max_t * sizeof(int))))
    return s;
  // Ragged batched prefill: cu_seqlens [max_seq+1] + per-token local position
  // [max_prefill]. Filled per ModelPrefillBatch, null in every other forward.
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_ragged_seq_offset),
                  static_cast<size_t>(cfg.max_seq + 1) * sizeof(int))))
    return s;
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_ragged_token_local),
                  max_t * sizeof(int))))
    return s;
  // Persistent 3D MRoPE table: [max_seq, 3, max_len] (t, h, w) rows, POOLED
  // over concurrent sequences (Phase 2). Each sequence's rope coordinates are
  // written at prefill and read across its decode steps, so the table must be
  // per-sequence (a shared table would be clobbered by a concurrent prefill).
  // Sized for the full sequence capacity (not max_prefill) because the
  // compressed-key builder reads the rope position of a group's first token,
  // which can be anywhere in the sequence during decode.
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_rope_pos),
                  static_cast<size_t>(cfg.max_seq) * 3u *
                      static_cast<size_t>(cfg.max_len) * sizeof(int))))
    return s;
  // Per-sequence mrope_position_delta (written at prefill, read at decode).
  m->rope_delta.assign(static_cast<size_t>(cfg.max_seq), 0);
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_emb),
                  max_t * cfg.hs * 2)))
    return s;
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_img_pos),
                  max_t * sizeof(int))))
    return s;
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_trunk),
                  max_t * hc_dim * 2)))
    return s;
  if (!(s = alloc(reinterpret_cast<void**>(&m->d_trunk2),
                  max_t * hc_dim * 2)))
    return s;
  if (m->ple_emb) {
    const size_t pe = m->ple_emb->ple_embed_dim();
    if (!(s = alloc(reinterpret_cast<void**>(&m->d_ple_emb),
                    max_t * pe * 2)))
      return s;
  }

  if (lt) t_buf = NowMs() - t0;
  // Forward workspace: max over layers (and the head).
  size_t ws = ModelHeadWorkspaceBytes(cfg.max_prefill, cfg.hs);
  for (auto& l : m->layers) {
    ws = std::max(
        ws, DecoderLayerWorkspaceBytes(
                cfg.max_prefill, l.is_full_attention, l.has_ple, cfg.hs, cfg.E,
                cfg.moe_is, cfg.shared_is, cfg.topk, &l.full,
                std::max(l.attn_hc.lowrank, l.mlp_hc.lowrank)));
  }
  m->ws_bytes = ws;
  if (!(s = alloc(&m->d_ws, ws))) return s;

  // Establish completion before releasing the model-owned loader/index.
  // Failure cannot unwind storage whose device lifetime remains unknown.
  t0 = lt ? NowMs() : 0.0;
  runtime::RequireCleanupSuccess(cudaStreamSynchronize(stream),
                                 "model.load completion");
  if (lt) {
    t_sync = NowMs() - t0;
    std::fprintf(stderr,
                 "[q4t][load] head=%.0f ms layers=%.0f ms ple=%.0f ms "
                 "buffers=%.0f ms sync=%.0f ms\n",
                 t_head, t_layers, t_ple, t_buf, t_sync);
  }
  // Baseline path (no tiered residency): release the loader now, as before,
  // dropping the shard mappings before the decode loop. Tiered residency
  // keeps it for the model's lifetime: on-demand expert loads stream shards
  // from NVMe after startup, and each layer's MoEResidency borrows it.
  if (!keep_loader) {
    m->weight_loader.reset();
    m->weight_index.reset();
  }
  return Status();
}

// Q4T_LAYER_TIMING report: sync the last event, print per-group totals
// (embedding / linear-attention layers / full-attention layers / head) plus
// the five slowest layers, and destroy the events. `hs` is the head status
// when the head ran (null when skipped). Observation-only.
Status FinishLayerTiming(const Model& m, bool layer_timing,
                         std::vector<cudaEvent_t>& lt_ev, int T,
                         Status* hs = nullptr) {
  if (!layer_timing) return hs ? *hs : Status();
  const int nl = m.cfg.num_layers;
  const cudaError_t se = cudaEventSynchronize(lt_ev[2 * (nl + 1) + 1]);
  if (se != cudaSuccess) {
    // Observation-only: report, then clear the sticky error so it cannot
    // poison the caller's next cudaGetLastError() check.
    std::fprintf(stderr, "[layer-timing] sync failed: %s\n",
                 cudaGetErrorString(se));
    cudaGetLastError();
  } else {
    std::vector<float> seg(nl + 2, 0.0f);
    float embed = 0.0f, lin = 0.0f, full = 0.0f, head = 0.0f;
    cudaEventElapsedTime(&embed, lt_ev[0], lt_ev[2]);
    for (int l = 0; l < nl; ++l) {
      cudaEventElapsedTime(&seg[l + 1], lt_ev[2 * (l + 1)],
                           lt_ev[2 * (l + 2)]);
      if (m.layers[l].is_full_attention) full += seg[l + 1];
      else lin += seg[l + 1];
    }
    cudaEventElapsedTime(&head, lt_ev[2 * (nl + 1)], lt_ev[2 * (nl + 1) + 1]);
    std::vector<int> order(nl);
    std::iota(order.begin(), order.end(), 0);
    std::partial_sort(order.begin(), order.begin() + std::min(5, nl),
                      order.end(),
                      [&](int a, int b) { return seg[a + 1] > seg[b + 1]; });
    std::fprintf(stderr,
                 "[layer-timing] T=%d embed=%.2fms lin=%.2fms full=%.2fms "
                 "head=%.2fms total=%.2fms top5=",
                 T, embed, lin, full, head, embed + lin + full + head);
    for (int i = 0; i < std::min(5, nl); ++i)
      std::fprintf(stderr, " L%d(%.2f)", order[i], seg[order[i] + 1]);
    std::fprintf(stderr, "\n");
  }
  for (auto& e : lt_ev) cudaEventDestroy(e);
  lt_ev.clear();
  return hs ? *hs : Status();
}

// Shared layer loop over [0, num_layers), reading `trunk`/`next` (ping-pong)
// and the per-token PLE embeddings `ple_emb` (null when no PLE layer in range).
// `ids64` / `hist` are the host int64 token ids and ngram history used to
// gather the PLE embedding at the PLE layer.
// `trunk_out` (MTP scheme A hook, optional): if non-null, the pre-final-mixer
// multi stream [T, hc*hs] (the trunk after the last decoder layer, before
// hyper_connection_mixer) is copied here. This is the MTP draft model's
// `hidden_states` input (see reference/vllm/.../nvidia/mtp.py).
Status RunLayers(const Model& m, const uint16_t* trunk_in, uint16_t* trunk2,
                 const int64_t* ids64, const int64_t* hist,
                 const int* host_positions, int T, uint16_t* logits,
                 cudaStream_t stream,
                 uint16_t* trunk_out = nullptr, float* ssm_ckpt = nullptr,
                 uint16_t* conv_ckpt = nullptr, int num_ckpt = 0,
                 int seq_id = 0, const int* d_seq_id = nullptr,
                 int tokens_per_seq = 0, uint16_t* ple_conv_ckpt = nullptr,
                 const RaggedBatch* ragged = nullptr,
                 LogitsRows logits_rows = LogitsRows::kAllRows,
                 bool sequence_last_rows = false,
                 float** ssm_captures = nullptr,
                 uint16_t** qkv_raw_captures = nullptr,
                 uint16_t** gated_n_captures = nullptr) {
  // Checkpoints describe the most recent successful verify only. Invalidate
  // before any layer mutates recurrent state, including failed forwards.
  InvalidateVerifyCheckpoints(m);
  const ModelConfig& cfg = m.cfg;
  // Every model entry point already owns the logical positions copied to
  // m.d_positions. Reduce once on host, not once per full-attention layer.
  // Packed/ragged batches need the maximum over all rows, not the last row.
  const int max_position =
      *std::max_element(host_positions, host_positions + T);
  const uint16_t* trunk = trunk_in;
  uint16_t* next = trunk2;
  // Per-sequence 3D MRoPE table slice [3, max_len] (the pooled table is
  // [max_seq, 3, max_len]; seq_id selects this sequence's rows).
  const int* seq_rope_pos =
      m.d_rope_pos + static_cast<size_t>(seq_id) * 3 * cfg.max_len;
  // DIAG (Q4T_DIAG=1): check for async CUDA errors after each layer to
  // localize illegal-memory-access sources during concurrency debugging.
  const bool diag = std::getenv("Q4T_DIAG") != nullptr;
  int lin_idx = 0;   // running linear-layer index (for checkpoint offsets)
  int ple_idx = 0;   // running PLE-layer index (for checkpoint offsets)
  // Checkpoint layout is pooled over max_seq: [num_layers, max_seq, cap,
  // elems] (cap = verify_ckpt_cap, the reserved stride). The kernels index the
  // per-layer slice by the POOLED seq id (multi seq, d_seq_id != null: pass
  // the layer base, seq_off = 0) or by the single sequence's slice (single
  // seq: seq_off = seq_id). With max_seq == 1 this degenerates to the legacy
  // [num_layers, cap, elems] layout.
  const size_t max_seq = static_cast<size_t>(cfg.max_seq);
  const size_t seq_off = d_seq_id ? 0 : static_cast<size_t>(seq_id);
  // The checkpoint buffer is allocated with stride cap = verify_ckpt_cap
  // (ModelReserveVerifyCheckpoints). The save MUST use the same stride so
  // restore/direct-read (which index by cap) find the data, regardless of how
  // many checkpoints (num_ckpt) this call writes. num_ckpt <= cap.
  const size_t ckpt_stride = static_cast<size_t>(m.verify_ckpt_cap);
  if (ssm_ckpt && (ckpt_stride == 0 ||
                   static_cast<size_t>(num_ckpt) > ckpt_stride)) {
    return Status::Fail("RunLayers: checkpoint stride mismatch (num_ckpt > "
                        "verify_ckpt_cap)");
  }
  // Q4T_LAYER_TIMING: observation-only per-layer GPU timing. Records
  // cudaEvents around embedding, each decoder layer, and the head, then
  // syncs and prints per-group totals. Never touches compute; off by
  // default.
  const bool layer_timing = std::getenv("Q4T_LAYER_TIMING") != nullptr;
  std::vector<cudaEvent_t> lt_ev;
  if (layer_timing) {
    lt_ev.resize(2 * (static_cast<size_t>(cfg.num_layers) + 2));
    for (auto& e : lt_ev)
      if (cudaEventCreate(&e) != cudaSuccess) {
        for (auto& f : lt_ev)
          if (f) cudaEventDestroy(f);
        return Status::Fail("Q4T_LAYER_TIMING: cudaEventCreate");
      }
  }
  const bool layer_subtiming = std::getenv("Q4T_LAYER_SUBTIMING") != nullptr;
  if (layer_subtiming) LayerSubTiming::Instance().Begin(cfg.num_layers);
  if (layer_subtiming) quant::MoESubTiming::Instance().Begin();
  if (layer_subtiming) HcMixSubTiming::Instance().Begin();
  if (layer_timing) cudaEventRecord(lt_ev[0], stream);
  for (int l = 0; l < cfg.num_layers; ++l) {
    if (diag) {
      const cudaError_t e = cudaGetLastError();
      if (e != cudaSuccess) {
        std::fprintf(stderr,
                     "[q4t][diag] pre-layer %d (seq_id=%d T=%d): %s\n", l,
                     seq_id, T, cudaGetErrorString(e));
        return Status::Fail(std::string("diag pre-layer ") +
                            std::to_string(l) + ": " + cudaGetErrorString(e));
      }
    }
    const uint16_t* ple_emb = nullptr;
    if (m.layers[l].has_ple) {
      Status s =
          m.ple_emb->Gather(ids64, T, hist, m.d_ple_emb, stream);
      if (!s.ok()) return s;
      // Apply the per-table weight_scale (SGLang: embeddings *= weight_scale).
      const int total = T * static_cast<int>(m.ple_emb->ple_embed_dim());
      ScaleBf16Kernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
          m.d_ple_emb, total, m.ple_weight_scale);
      if (cudaGetLastError() != cudaSuccess) {
        return Status::Fail("ple scale launch");
      }
      ple_emb = m.d_ple_emb;
    }
    // Per-linear-layer checkpoint slices (only when saving for MTP verify).
    // Pooled layout [num_lin, max_seq, cap, elems]: the per-layer slice starts
    // at (lin_idx * max_seq + seq_off) * cap * elems (cap = ckpt_stride).
    float* layer_ssm_ckpt = nullptr;
    uint16_t* layer_conv_ckpt = nullptr;
    uint16_t* layer_ple_conv_ckpt = nullptr;
    if (ssm_ckpt && !m.layers[l].is_full_attention) {
      const auto& lin = m.layers[l].linear;
      const size_t ssm_elems =
          static_cast<size_t>(lin.nv) * lin.kd * lin.vd;
      const size_t conv_elems =
          static_cast<size_t>(lin.in_qkv()) * (lin.conv_k - 1);
      layer_ssm_ckpt = ssm_ckpt +
                       (static_cast<size_t>(lin_idx) * max_seq + seq_off) *
                           ckpt_stride * ssm_elems;
      layer_conv_ckpt = conv_ckpt +
                        (static_cast<size_t>(lin_idx) * max_seq + seq_off) *
                            ckpt_stride * conv_elems;
    }
    // PLE conv checkpoint slice (the PLE short-conv is an in-place recurrence
    // too; a partial accept must restore it — see ModelRestoreCheckpoint).
    // Uses the SEPARATE d_verify_ple_conv_ckpt buffer ([num_ple, max_seq,
    // cap, ple_elems]), not the linear conv buffer.
    if (ple_conv_ckpt && m.layers[l].has_ple) {
      const size_t ple_elems = static_cast<size_t>(m.layers[l].hc_dim) *
                               (m.layers[l].ple.conv_kernel - 1) *
                               m.layers[l].ple.conv_dilation;
      layer_ple_conv_ckpt = ple_conv_ckpt +
                            (static_cast<size_t>(ple_idx) * max_seq + seq_off) *
                                ckpt_stride * ple_elems;
    }
    if (layer_timing) cudaEventRecord(lt_ev[2 * (l + 1)], stream);
    Status s = DecoderLayerForward(m.layers[l], trunk, ple_emb, next,
                                   m.d_positions, seq_rope_pos, T, m.d_ws,
                                   m.ws_bytes, stream, layer_ssm_ckpt,
                                   layer_conv_ckpt, num_ckpt, seq_id, d_seq_id,
                                   m.d_rope_pos, tokens_per_seq,
                                   layer_ple_conv_ckpt, ragged, max_position,
                                   m.router_trace, l,
                                   static_cast<int>(ckpt_stride),
                                   (!m.layers[l].is_full_attention &&
                                    ssm_captures)
                                       ? ssm_captures[lin_idx]
                                       : nullptr,
                                   (!m.layers[l].is_full_attention &&
                                    qkv_raw_captures)
                                       ? qkv_raw_captures[lin_idx]
                                       : nullptr,
                                   (m.layers[l].has_ple && gated_n_captures)
                                       ? gated_n_captures[ple_idx]
                                       : nullptr);
    if (!s.ok()) return s;
    if (layer_timing) cudaEventRecord(lt_ev[2 * (l + 2)], stream);
    if (!m.layers[l].is_full_attention) lin_idx++;
    if (m.layers[l].has_ple) ple_idx++;
    if (diag) {
      const cudaError_t e = cudaGetLastError();
      if (e != cudaSuccess) {
        std::fprintf(stderr,
                     "[q4t][diag] post-layer %d (%s, seq_id=%d T=%d): %s\n", l,
                     m.layers[l].is_full_attention ? "full" : "linear", seq_id,
                     T, cudaGetErrorString(e));
        return Status::Fail(std::string("diag post-layer ") +
                            std::to_string(l) + ": " + cudaGetErrorString(e));
      }
    }
    const uint16_t* t = trunk;
    trunk = next;
    next = const_cast<uint16_t*>(t);
  }
  if (layer_subtiming) LayerSubTiming::Instance().Report(T);
  if (layer_subtiming) quant::MoESubTiming::Instance().Report(T);
  if (layer_subtiming) HcMixSubTiming::Instance().Report(T);
  // MTP scheme A hook: expose the pre-final-mixer multi stream [T, hc*hs]
  // (the trunk after the last decoder layer, before hyper_connection_mixer).
  // Device-to-device copy; the caller owns `trunk_out` (>= T * hc_dim bytes).
  if (trunk_out) {
    const size_t bytes = static_cast<size_t>(T) * m.hc_dim() * sizeof(uint16_t);
    if (cudaMemcpyAsync(trunk_out, trunk, bytes, cudaMemcpyDeviceToDevice,
                        stream) != cudaSuccess) {
      return Status::Fail("RunLayers: trunk_out D2D copy");
    }
  }
  // logits == nullptr: the caller only wants the trunk (e.g. the MTP draft
  // extend's hidden gather) and skips the lm_head GEMM. HeadForward would
  // otherwise pass a null output pointer to Bf16Gemm (CUBLAS_STATUS_INVALID_
  // VALUE).
  if (!logits) {
    if (layer_timing)
      cudaEventRecord(lt_ev[2 * (cfg.num_layers + 1) + 1], stream);
    return FinishLayerTiming(m, layer_timing, lt_ev, T);
  }
  Status hs;
  if (sequence_last_rows) {
    const int width = m.hc_dim();
    const dim3 grid((width + kBlock - 1) / kBlock, ragged->B);
    GatherSequenceLastRowsKernel<<<grid, kBlock, 0, stream>>>(
        trunk, next, ragged->seq_offset, width);
    if (cudaGetLastError() != cudaSuccess)
      return Status::Fail("RunLayers: gather sequence last rows");
    hs = HeadForward(m.head, next, logits, ragged->B, m.d_ws, m.ws_bytes,
                     stream);
  } else if (logits_rows == LogitsRows::kLastRow) {
    hs = HeadForward(m.head, trunk + static_cast<size_t>(T - 1) * m.hc_dim(),
                     logits, 1, m.d_ws, m.ws_bytes, stream);
  } else {
    hs = HeadForward(m.head, trunk, logits, T, m.d_ws, m.ws_bytes, stream);
  }
  if (layer_timing)
    cudaEventRecord(lt_ev[2 * (cfg.num_layers + 1) + 1], stream);
  return FinishLayerTiming(m, layer_timing, lt_ev, T, &hs);
}

// Reset all per-layer persistent state (linear SSM/conv, full KV/indexer)
// to zero — prepare to process a fresh sequence from the start.
// Invalidates the mutable checkpoint record as well as device state.
Status ResetAllLayers(const Model& m, cudaStream_t stream, int seq_id = 0) {
  InvalidateVerifyCheckpoints(m);
  for (const auto& l : m.layers) l.ResetState(seq_id, stream);
  return Status();
}

// Build the 3D MRoPE position table (host) for a prefill, mirroring
// transformers qwen4_exp get_rope_index + get_vision_position_ids.
//
// The table has 3 rows (t, h, w) of length T, stored row-major into
// `rope_pos` (device [3, max_len]). For pure text the three rows are all the
// logical position 0..T-1 (delta = 0), so partial MRoPE reduces to standard
// RoPE. For multimodal prompts, each image/video placeholder block (grid
// (t, h, w) in PATCH units, in `vision->grids`, in prompt position order)
// contributes t*(h/m)*(w/m) tokens whose merged index k maps to
//   t_coord = k / ((h/m)*(w/m)),  h_coord = (k % ...) / (w/m),  w_coord = k % (w/m)
// and the three rows take (t_coord + clock, h_coord + clock, w_coord + clock).
// The text clock advances by `len` over a text run and by max(h, w) / m over a
// vision block (NOT the token count) — this is what creates the rope delta.
// Returns the mrope_position_delta (decode rope row = logical + delta).
int BuildRopePositions(const int32_t* input_ids, int T, int m,
                       int img_id, int vid_id, int max_len,
                       const std::vector<std::array<int, 3>>& grids,
                       std::vector<int>* rope_pos) {
  // Layout [3, max_len]: row r at ABSOLUTE position p is rope_pos[r*max_len+p].
  // The RoPE kernels index by positions[t] (== t in prefill, == absolute pos
  // in decode), so the table must be addressable by absolute position.
  rope_pos->assign(3 * max_len, 0);
  int clock = 0;  // text clock (current_pos in the reference)
  int gi = 0;  // grid index (in prompt position order)
  int t = 0;
  int maxv = 0;
  while (t < T) {
    const int32_t id = input_ids[t];
    if (id != img_id && id != vid_id) {
      // Text run: all three rows = clock + offset.
      int run = 0;
      while (t + run < T) {
        const int32_t d = input_ids[t + run];
        if (d == img_id || d == vid_id) break;
        ++run;
      }
      for (int j = 0; j < run; ++j) {
        const int v = clock + j;
        (*rope_pos)[t + j] = v;
        (*rope_pos)[max_len + (t + j)] = v;
        (*rope_pos)[2 * max_len + (t + j)] = v;
        if (v > maxv) maxv = v;
      }
      clock += run;
      t += run;
      continue;
    }
    // Vision block: consume the next grid.
    if (gi >= static_cast<int>(grids.size())) {
      // No grid for a placeholder: fall back to the logical position for this
      // token (defensive; the caller should always supply matching grids).
      const int v = t;
      (*rope_pos)[t] = v;
      (*rope_pos)[max_len + t] = v;
      (*rope_pos)[2 * max_len + t] = v;
      if (v > maxv) maxv = v;
      ++t;
      continue;
    }
    const int gt = grids[gi][0];  // temporal (patch groups)
    const int gh = grids[gi][1];  // height (patches)
    const int gw = grids[gi][2];  // width (patches)
    const int mh = gh / m, mw = gw / m;  // merged grid
    const int per_frame = mh * mw;
    const int n = gt * per_frame;  // merged tokens in this block
    for (int k = 0; k < n && t + k < T; ++k) {
      const int tc = k / per_frame;
      const int rem = k % per_frame;
      const int hc = rem / mw;
      const int wc = rem % mw;
      const int idx = t + k;
      (*rope_pos)[idx] = clock + tc;
      (*rope_pos)[max_len + idx] = clock + hc;
      (*rope_pos)[2 * max_len + idx] = clock + wc;
      const int v = clock + tc;
      if (v > maxv) maxv = v;
    }
    clock += (std::max(gh, gw) / m);
    t += n;
    ++gi;
  }
  return maxv + 1 - T;
}

// Prefill without reset: assumes per-layer state is already at the sequence
// start (call ResetAllLayers / ModelBeginSequence first). positions = 0..T-1.
// `trunk_out` (MTP scheme A hook) is forwarded to RunLayers. `vision` (optional)
// replaces image-token embeddings with vision features before ExpandTrunk.
Status RunPrefill(const Model& m, const int32_t* input_ids, int T,
                  uint16_t* logits, cudaStream_t stream,
                  uint16_t* trunk_out = nullptr,
                  const VisionFeatures* vision = nullptr, int seq_id = 0,
                  LogitsRows logits_rows = LogitsRows::kAllRows) {
  const ModelConfig& cfg = m.cfg;
  if (T <= 0 || T > cfg.max_prefill || T > cfg.Capacity(seq_id))
    return Status::Fail("RunPrefill: invalid token capacity");
  if (seq_id < 0 || seq_id >= cfg.max_seq)
    return Status::Fail("RunPrefill: seq_id exceeds max_seq");
  if (!m.metadata_upload)
    return Status::Fail("RunPrefill: upload owner missing");
  auto& upload = *m.metadata_upload;
  Status upload_status = upload.Begin(stream);
  if (!upload_status.ok()) return upload_status;

  // 1. ids + positions.
  if (!(upload_status = upload.Copy(m.d_ids, input_ids, T * sizeof(int32_t)))
           .ok())
    return upload_status;
  // PLE gather takes int64 token ids; build a host int64 copy.
  std::vector<int64_t> ids64(input_ids, input_ids + T);
  std::vector<int> positions(T);
  for (int t = 0; t < T; ++t) positions[t] = t;
  if (!(upload_status =
            upload.Copy(m.d_positions, positions.data(), T * sizeof(int)))
           .ok())
    return upload_status;
  // 1b. 3D MRoPE table [3, max_len] (t, h, w) for the RoPE angles, addressed by
  //     ABSOLUTE position (rope_pos[r*max_len+p]). Pure text -> three identical
  //     rows (== logical), delta 0. Multimodal -> vision blocks carry their grid
  //     coordinates and the text clock advances by max(h, w) / merge over each
  //     block, producing a nonzero delta. The full table is H2D'd so the decode
  //     path (and the compressed-key builder) can read any absolute position.
  {
    const std::vector<std::array<int, 3>>* grids =
        (vision && !vision->grids.empty()) ? &vision->grids : nullptr;
    std::vector<int> rope_pos;
    m.rope_delta[seq_id] = BuildRopePositions(
        input_ids, T, cfg.spatial_merge_size, cfg.image_token_id,
        cfg.video_token_id, cfg.max_len,
        grids ? *grids : std::vector<std::array<int, 3>>{}, &rope_pos);
    // Write into this sequence's [3, max_len] slice of the pooled table.
    if (!(upload_status = upload.Copy(
              m.d_rope_pos + static_cast<size_t>(seq_id) * 3 * cfg.max_len,
              rope_pos.data(), rope_pos.size() * sizeof(int)))
             .ok())
      return upload_status;
  }

  // 2. emb.
  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, T, stream);
  if (!s.ok()) return s;

  // 2b. Multimodal injection: replace image/video-token embeddings with vision
  //     features (vllm `_merge_multimodal_embeddings`). Feature rows are
  //     consumed in PROMPT POSITION ORDER (left-to-right): the i-th
  //     image_token_id or video_token_id occurrence (in sequence order) takes
  //     feature row i. The caller must lay out `vision->device` in that same
  //     left-to-right position order (interleaved images and videos allowed).
  if (vision && vision->num_tokens > 0) {
    std::vector<int> mm_pos;
    mm_pos.reserve(static_cast<size_t>(vision->num_tokens));
    for (int t = 0; t < T; ++t) {
      if (input_ids[t] == cfg.image_token_id ||
          input_ids[t] == cfg.video_token_id) {
        mm_pos.push_back(t);
      }
    }
    if (static_cast<int>(mm_pos.size()) != vision->num_tokens) {
      return Status::Fail("vision: multimodal-token count mismatch " +
                           std::to_string(mm_pos.size()) + " vs " +
                           std::to_string(vision->num_tokens));
    }
    if (!(upload_status = upload.Copy(m.d_img_pos, mm_pos.data(),
                                      mm_pos.size() * sizeof(int)))
             .ok())
      return upload_status;
    const int total = vision->num_tokens * cfg.hs;
    const int grid = (total + kBlock - 1) / kBlock;
    InjectVisionKernel<<<grid, kBlock, 0, stream>>>(vision->device, m.d_img_pos,
                                                    m.d_emb, cfg.hs,
                                                    vision->num_tokens);
  }

  upload_status = upload.Finish();
  if (!upload_status.ok()) return upload_status;

  // 3. trunk.
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, T, stream);
  if (!s.ok()) return s;

  // 4. Build the PLE ngram history (host): for token t, the ngram_size-1
  //    preceding tokens oldest->newest, EOS-filled before the sequence start.
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int hist_w = m.ple_hash.ngram_size - 1;
    hist.resize(static_cast<size_t>(T) * hist_w);
    for (int t = 0; t < T; ++t) {
      for (int j = 0; j < hist_w; ++j) {
        const int src = t - (hist_w - j);  // oldest first
        hist[static_cast<size_t>(t) * hist_w + j] =
            (src >= 0) ? static_cast<int64_t>(input_ids[src])
                       : cfg.eos_token_id;
      }
    }
  }

  // 5. Layer loop + head.
  return RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                   positions.data(), T, logits, stream, trunk_out, nullptr,
                   nullptr, 0, seq_id, nullptr, 0, nullptr, nullptr,
                   logits_rows);
}

Status ModelForward(const Model& m, const int32_t* input_ids, int T,
                    uint16_t* logits, cudaStream_t stream,
                    const VisionFeatures* vision, int seq_id) {
  const ModelConfig& cfg = m.cfg;
  if (T <= 0) return Status();
  if (T > cfg.max_prefill) {
    return Status::Fail("ModelForward: T exceeds max_prefill");
  }
  if (T > cfg.max_len)
    return Status::Fail("ModelForward: T exceeds max_len");
  if (seq_id < 0 || seq_id >= cfg.max_seq)
    return Status::Fail("ModelForward: seq_id exceeds max_seq");
  // Prefill of a fresh sequence starts from empty per-layer state (linear
  // SSM/conv, full KV/indexer). Reset so repeated calls are deterministic.
  Status s = ResetAllLayers(m, stream, seq_id);
  if (!s.ok()) return s;
  return RunPrefill(m, input_ids, T, logits, stream, nullptr, vision, seq_id);
}

Status ModelDecodeStep(const Model& m, int32_t token_id, int position,
                       const int32_t* history, uint16_t* logits,
                       cudaStream_t stream, uint16_t* trunk_out, int seq_id) {
  const ModelConfig& cfg = m.cfg;
  if (position < 0) return Status::Fail("ModelDecodeStep: position < 0");
  if (position >= cfg.Capacity(seq_id)) {
    return Status::Fail("ModelDecodeStep: position exceeds max_len");
  }

  if (seq_id < 0 || seq_id >= cfg.max_seq)
    return Status::Fail("ModelDecodeStep: seq_id exceeds max_seq");
  if (!m.metadata_upload)
    return Status::Fail("ModelDecodeStep: upload owner missing");
  auto& upload = *m.metadata_upload;
  Status upload_status = upload.Begin(stream);
  if (!upload_status.ok()) return upload_status;

  // Per-layer state is NOT reset: it continues from the prior steps.
  // 1. ids + positions (single token at its absolute position).
  if (!(upload_status = upload.Copy(m.d_ids, &token_id, sizeof(int32_t))).ok())
    return upload_status;
  const int pos = position;
  if (!(upload_status = upload.Copy(m.d_positions, &pos, sizeof(int))).ok())
    return upload_status;
  // 1b. 3D MRoPE for this decode token: all three rows = logical + delta
  //     (the rope delta computed at prefill; 0 for pure text). The RoPE
  //     kernels index rope_pos by the ABSOLUTE position: row r at position p
  //     is rope_pos[r * max_len + p] (layout [3, max_len]). Write the three
  //     rows at their strided offsets.
  {
    const int rp = pos + m.rope_delta[seq_id];
    const size_t ml = static_cast<size_t>(cfg.max_len);
    int* seq_rope = m.d_rope_pos + static_cast<size_t>(seq_id) * 3 * ml;
    for (int r = 0; r < 3; ++r) {
      if (!(upload_status =
                upload.Copy(seq_rope + r * ml + pos, &rp, sizeof(int)))
               .ok())
        return upload_status;
    }
  }

  upload_status = upload.Finish();
  if (!upload_status.ok()) return upload_status;

  // 2-3. emb + trunk.
  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, 1, stream);
  if (!s.ok()) return s;
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, 1, stream);
  if (!s.ok()) return s;

  // 4. PLE ngram history for this token: the ngram_size-1 preceding tokens
  //    (from `history`, oldest->newest), EOS-filled before the start.
  std::vector<int64_t> ids64(1, static_cast<int64_t>(token_id));
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int hist_w = m.ple_hash.ngram_size - 1;
    hist.resize(hist_w);
    for (int j = 0; j < hist_w; ++j) {
      const int src = position - (hist_w - j);  // oldest first
      hist[j] = (src >= 0) ? static_cast<int64_t>(history[src])
                           : cfg.eos_token_id;
    }
  }

  // 5. Layer loop + head.
  return RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                   &pos, 1, logits, stream, trunk_out, nullptr, nullptr, 0, seq_id);
}

// Batched decode over T tokens at absolute positions [base..base+T-1] WITHOUT
// resetting per-layer state (continues from the current KV/SSM/conv). Returns
// [T, vocab] logits (and optionally [T, hc*hs] trunk_out). Used by MTP to
// verify k+1 speculative tokens in a single bandwidth-bound forward instead of
// k+1 separate T=1 decodes. `history` (length `history_len`) supplies the PLE
// n-gram context for positions before `base`; the in-batch prefix supplies the
// rest.
Status ModelDecodeBatch(const Model& m, const int32_t* input_ids, int T,
                        int base_position, const int32_t* history,
                        int history_len, uint16_t* logits, cudaStream_t stream,
                        uint16_t* trunk_out, bool save_checkpoints,
                        int seq_id, LogitsRows logits_rows,
                        float** ssm_captures,
                        uint16_t** qkv_raw_captures,
                        uint16_t** gated_n_captures) {
  InvalidateVerifyCheckpoints(m);
  const ModelConfig& cfg = m.cfg;
  if (T <= 0) return Status::Fail("ModelDecodeBatch: T must be > 0");
  if (T > cfg.max_prefill)
    return Status::Fail("ModelDecodeBatch: T exceeds max_prefill");
  if (base_position < 0 || T > cfg.Capacity(seq_id) ||
      base_position > cfg.Capacity(seq_id) - T)
    return Status::Fail("ModelDecodeBatch: position range exceeds max_len");
  if (seq_id < 0 || seq_id >= cfg.max_seq)
    return Status::Fail("ModelDecodeBatch: seq_id exceeds max_seq");
  if (save_checkpoints) {
    // This single-sequence batch path writes PLE conv checkpoints (the
    // ple_conv_ckpt slice below reaches PleLayerForward's single-seq branch),
    // so save_checkpoints is valid for PLE models: the T>1 MTP verify path
    // relies on it.
    Status capacity = CheckVerifyCheckpointCapacity(m, T - 1);
    if (!capacity.ok()) return capacity;
  }

  if (!m.metadata_upload)
    return Status::Fail("ModelDecodeBatch: upload owner missing");
  auto& upload = *m.metadata_upload;
  Status upload_status = upload.Begin(stream);
  if (!upload_status.ok()) return upload_status;

  if (!(upload_status = upload.Copy(m.d_ids, input_ids, T * sizeof(int32_t)))
           .ok())
    return upload_status;
  std::vector<int64_t> ids64(input_ids, input_ids + T);
  std::vector<int> positions(T);
  for (int t = 0; t < T; ++t) positions[t] = base_position + t;
  if (!(upload_status =
            upload.Copy(m.d_positions, positions.data(), T * sizeof(int)))
           .ok())
    return upload_status;
  // 3D MRoPE for the decode batch (all text tokens): each row = logical +
  // delta (the rope delta from prefill; 0 for pure text). The RoPE kernels
  // index rope_pos by the ABSOLUTE position (positions[t] == base_position+t),
  // so write the three rows at their strided [3, max_len] offsets.
  //
  // All three rows carry the SAME value for a text token (t = h = w = logical
  // position + delta), so build the T values once and copy each of the 3 rows
  // as a SINGLE contiguous H2D into [base_position, base_position+T). The old
  // per-token 3xT tiny (4-byte) copies serialized ~3T H2D launches per call —
  // a 2048-token chunk meant 6144 launches, which dominated chunked-prefill
  // time at 262K (see LOG 2026-09-15). Bit-identical (same values, same
  // destination offsets), just batched.
  {
    const size_t ml = static_cast<size_t>(cfg.max_len);
    int* seq_rope = m.d_rope_pos + static_cast<size_t>(seq_id) * 3 * ml;
    std::vector<int> rope_pos(T);
    for (int t = 0; t < T; ++t) rope_pos[t] = base_position + t + m.rope_delta[seq_id];
    for (int r = 0; r < 3; ++r) {
      if (!(upload_status = upload.Copy(seq_rope + r * ml + base_position,
                                        rope_pos.data(), T * sizeof(int)))
               .ok())
        return upload_status;
    }
  }

  upload_status = upload.Finish();
  if (!upload_status.ok()) return upload_status;

  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, T, stream);
  if (!s.ok()) return s;
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, T, stream);
  if (!s.ok()) return s;

  // PLE n-gram history: token t at absolute (base+t); its context spans the
  // caller's `history` (positions < base) and the in-batch prefix.
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int hist_w = m.ple_hash.ngram_size - 1;
    hist.resize(static_cast<size_t>(T) * hist_w);
    for (int t = 0; t < T; ++t) {
      const int abs = base_position + t;
      for (int j = 0; j < hist_w; ++j) {
        const int src = abs - (hist_w - j);  // oldest first
        int64_t tok;
        if (src < 0)
          tok = cfg.eos_token_id;
        else if (src < base_position)
          tok = (src < history_len) ? static_cast<int64_t>(history[src])
                                    : cfg.eos_token_id;
        else
          tok = static_cast<int64_t>(input_ids[src - base_position]);
        hist[static_cast<size_t>(t) * hist_w + j] = tok;
      }
    }
  }

  // Layer loop + head — NO reset, continues from the current per-layer state.
  // When save_checkpoints, capture per-token SSM/conv/PLE-conv state for the
  // first T-1 tokens (checkpoint[t] = state after token t) so an MTP partial
  // accept can restore checkpoint[accept_count] via D2D instead of re-running
  // the forward. The PLE conv slice MUST be passed too: the single-sequence
  // verify path is the only checkpoint saver that reaches
  // PleLayerForward's single-seq branch, and a partial accept restores the
  // PLE conv state from this buffer (ModelRestoreCheckpoint).
  float* ssm_ckpt = save_checkpoints ? m.d_verify_ssm_ckpt : nullptr;
  uint16_t* conv_ckpt = save_checkpoints ? m.d_verify_conv_ckpt : nullptr;
  uint16_t* ple_conv_ckpt =
      save_checkpoints ? m.d_verify_ple_conv_ckpt : nullptr;
  const int num_ckpt = save_checkpoints ? (T - 1) : 0;
  s = RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                positions.data(), T, logits, stream, trunk_out, ssm_ckpt,
                conv_ckpt, num_ckpt, seq_id, nullptr, 0, ple_conv_ckpt,
                nullptr, logits_rows, false, ssm_captures, qkv_raw_captures,
                gated_n_captures);
  if (s.ok() && num_ckpt > 0) {
    m.verify_ckpt_rows = num_ckpt;
    m.verify_ckpt_slots.assign(1, seq_id);
  }
  return s;
}

// B2 continuous batching: decode ONE token for each of B sequences in a single
// packed forward (T = B). See the header for the argument contract. The GEMMs
// (HC/MoE/head/projections) are stateless and operate on the packed [B, ...]
// rows (weights read once); the recurrent state (linear SSM/conv, PLE conv,
// full KV/indexer, 3D MRoPE) is selected per-token via d_seq_id.
Status ModelDecodeBatchMulti(const Model& m, const int32_t* tokens,
                             const int* positions, const int* seq_ids,
                             const int32_t* history, int B, uint16_t* logits,
                             cudaStream_t stream, uint16_t* trunk_out) {
  const ModelConfig& cfg = m.cfg;
  if (B <= 0) return Status::Fail("ModelDecodeBatchMulti: B must be > 0");
  if (B > cfg.max_seq)
    return Status::Fail("ModelDecodeBatchMulti: B exceeds max_seq");
  if (B > cfg.max_prefill)
    return Status::Fail("ModelDecodeBatchMulti: B exceeds max_prefill");
  for (int t = 0; t < B; ++t) {
    if (positions[t] < 0 || positions[t] >= cfg.Capacity(seq_ids[t]))
      return Status::Fail("ModelDecodeBatchMulti: position exceeds max_len");
    if (seq_ids[t] < 0 || seq_ids[t] >= cfg.max_seq)
      return Status::Fail("ModelDecodeBatchMulti: seq_id exceeds max_seq");
  }

  // Keep upload sources alive independently of the caller and loop scopes.
  // The owner completes the previous upload before refilling its CPU buffer;
  // model scratch consumers remain serialized by the caller as before.
  if (!m.decode_metadata_upload)
    return Status::Fail("ModelDecodeBatchMulti: upload owner missing");
  Status uploaded = m.decode_metadata_upload->Upload(
      {tokens, static_cast<size_t>(B)}, {positions, static_cast<size_t>(B)},
      {seq_ids, static_cast<size_t>(B)}, m.rope_delta,
      {m.d_ids, m.d_positions, m.d_seq_id, m.d_rope_pos, cfg.max_len,
       cfg.max_seq}, stream);
  if (!uploaded.ok()) return uploaded;

  std::vector<int64_t> ids64(tokens, tokens + B);

  // 2. PLE n-gram history: the caller supplies per-token context (oldest
  //    first, EOS-filled) in `history` (B * (ngram_size-1) int32), so it maps
  //    directly to the int64 hist RunLayers expects (one row per token).
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int hist_w = m.ple_hash.ngram_size - 1;
    hist.resize(static_cast<size_t>(B) * hist_w);
    for (size_t i = 0; i < hist.size(); ++i)
      hist[i] = static_cast<int64_t>(history[i]);
  }

  // 3. emb + trunk (packed [B, ...]).
  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, B, stream);
  if (!s.ok()) return s;
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, B, stream);
  if (!s.ok()) return s;

  // 4. Layer loop + head — NO reset, continues from each sequence's current
  //    per-layer state (selected per-token via d_seq_id).
  return RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                   positions, B, logits, stream, trunk_out, nullptr, nullptr, 0, 0,
                   m.d_seq_id);
}

// Phase 2 MTP multi-seq verify: feed `tokens_per_seq` tokens for EACH of B
// sequences in ONE packed forward (T_total = B * tokens_per_seq, sequence-
// major). See the header for the full contract. Unlike ModelDecodeBatch (one
// sequence), this packs B sequences so the GEMMs read the weights once for the
// whole speculative batch; the per-sequence recurrent state (linear SSM/conv,
// PLE conv, full KV/indexer, 3D MRoPE) is selected per-token via
// d_token_seq_id. Per-sequence per-token SSM/conv/PLE-conv checkpoints are
// saved (num_ckpt = tokens_per_seq - 1) so each sequence can independently
// roll back to its own accepted prefix.
Status ModelVerifyMulti(const Model& m, const int32_t* tokens,
                        const int* base_positions, const int* seq_ids,
                        const int32_t* history, int history_len, int B,
                        int tokens_per_seq, uint16_t* logits,
                        cudaStream_t stream, uint16_t* trunk_out) {
  InvalidateVerifyCheckpoints(m);
  const ModelConfig& cfg = m.cfg;
  const int T = tokens_per_seq;
  if (B <= 0 || T <= 0)
    return Status::Fail("ModelVerifyMulti: B and T must be > 0");
  if (B > cfg.max_seq)
    return Status::Fail("ModelVerifyMulti: B exceeds max_seq");
  if (T > cfg.max_prefill / B)
    return Status::Fail("ModelVerifyMulti: B*T exceeds max_prefill");
  const int Ttot = B * T;
  Status capacity = CheckVerifyCheckpointCapacity(m, T - 1);
  if (!capacity.ok()) return capacity;
  for (int b = 0; b < B; ++b) {
    if (base_positions[b] < 0 || T > cfg.Capacity(seq_ids[b]) ||
        base_positions[b] > cfg.Capacity(seq_ids[b]) - T)
      return Status::Fail("ModelVerifyMulti: position range exceeds max_len");
    if (seq_ids[b] < 0 || seq_ids[b] >= cfg.max_seq)
      return Status::Fail("ModelVerifyMulti: seq_id exceeds max_seq");
    for (int prior = 0; prior < b; ++prior) {
      if (seq_ids[prior] == seq_ids[b])
        return Status::Fail("ModelVerifyMulti: duplicate seq_id");
    }
  }

  // Own every upload source until checked completion, including RoPE
  // entries that previously borrowed a reused loop-local scalar.
  std::vector<int> positions(Ttot);
  std::vector<int> token_seq(Ttot);
  std::vector<int> rope_positions(Ttot);
  for (int b = 0; b < B; ++b) {
    for (int t = 0; t < T; ++t) {
      const size_t row = static_cast<size_t>(b) * T + t;
      positions[row] = base_positions[b] + t;
      token_seq[row] = seq_ids[b];
      rope_positions[row] = positions[row] + m.rope_delta[seq_ids[b]];
    }
  }

  std::vector<int64_t> ids64(tokens, tokens + Ttot);

  // PLE n-gram history: per sequence, token (b, t) at absolute
  // base_positions[b]+t; its context spans the sequence's `history` (positions
  // < base) and the in-batch prefix. Mirrors ModelDecodeBatch, per sequence.
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int hist_w = m.ple_hash.ngram_size - 1;
    hist.resize(static_cast<size_t>(Ttot) * hist_w);
    for (int b = 0; b < B; ++b) {
      for (int t = 0; t < T; ++t) {
        const int abs = base_positions[b] + t;
        for (int j = 0; j < hist_w; ++j) {
          const int src = abs - (hist_w - j);  // oldest first
          int64_t tok;
          if (src < 0)
            tok = cfg.eos_token_id;
          else if (src < base_positions[b])
            tok = (src < history_len)
                      ? static_cast<int64_t>(
                            history[static_cast<size_t>(b) * history_len + src])
                      : cfg.eos_token_id;
          else
            tok = static_cast<int64_t>(
                tokens[static_cast<size_t>(b) * T + (src - base_positions[b])]);
          hist[static_cast<size_t>(b) * T * hist_w + t * hist_w + j] = tok;
        }
      }
    }
  }

  // No host source is released before this boundary. Do not publish
  // checkpoint validity for an incomplete or failed forward.
  const auto finish = [&](Status status) -> Status {
    const cudaError_t error = cudaStreamSynchronize(stream);
    if (error != cudaSuccess) {
      status = Status::Fail(
          std::string("ModelVerifyMulti: completion failed: ") +
          cudaGetErrorString(error));
    }
    if (!status.ok()) InvalidateVerifyCheckpoints(m);
    return status;
  };
  if (cudaMemcpyAsync(m.d_ids, tokens, Ttot * sizeof(int32_t),
                      cudaMemcpyHostToDevice, stream) != cudaSuccess)
    return finish(Status::Fail("H2D tokens"));
  if (cudaMemcpyAsync(m.d_positions, positions.data(), Ttot * sizeof(int),
                      cudaMemcpyHostToDevice, stream) != cudaSuccess)
    return finish(Status::Fail("H2D positions"));
  if (cudaMemcpyAsync(m.d_token_seq_id, token_seq.data(), Ttot * sizeof(int),
                      cudaMemcpyHostToDevice, stream) != cudaSuccess)
    return finish(Status::Fail("H2D token_seq"));
  const size_t ml = static_cast<size_t>(cfg.max_len);
  for (int b = 0; b < B; ++b) {
    int* seq_rope = m.d_rope_pos + static_cast<size_t>(seq_ids[b]) * 3 * ml;
    for (int t = 0; t < T; ++t) {
      const size_t row = static_cast<size_t>(b) * T + t;
      for (int r = 0; r < 3; ++r) {
        if (cudaMemcpyAsync(seq_rope + r * ml + positions[row],
                            &rope_positions[row], sizeof(int),
                            cudaMemcpyHostToDevice, stream) != cudaSuccess)
          return finish(Status::Fail("H2D rope_pos"));
      }
    }
  }

  // emb + trunk (packed [B*T, ...]).
  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, Ttot, stream);
  if (!s.ok()) return finish(s);
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, Ttot, stream);
  if (!s.ok()) return finish(s);

  // Layer loop + head — NO reset; per-token state via d_token_seq_id, and
  // per-sequence per-token SSM/conv/PLE-conv checkpoints for the first T-1
  // tokens so each sequence rolls back to its own accepted prefix.
  const int num_ckpt = T - 1;
  s = RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                positions.data(), Ttot, logits, stream, trunk_out,
                m.d_verify_ssm_ckpt, m.d_verify_conv_ckpt, num_ckpt, 0,
                m.d_token_seq_id, T, m.d_verify_ple_conv_ckpt);
  s = finish(s);
  if (s.ok() && num_ckpt > 0) {
    m.verify_ckpt_rows = num_ckpt;
    m.verify_ckpt_slots.assign(seq_ids, seq_ids + B);
  }
  return s;
}

// Ragged batched prefill (Phase 2): prefill B FRESH sequences of variable
// length in ONE packed forward. `tokens` is the sequence-major concatenation
// of the B prompts (Ttot = sum(lens) rows), `lens[b]` the b-th prompt length,
// `seq_ids[b]` the pooled recurrent-state slice it fills. Each sequence's
// per-layer state is RESET first (fresh prefill from position 0). `logits`
// receives the packed [Ttot, vocab] logits (row seq_offset[b]+t = sequence b's
// token t). The projection / MoE / attention GEMMs read the dense weights ONCE
// for the whole batch, so B short prefills cost ~one weight sweep instead of B
// — the serve win when several requests prefill together. Pure text only (no
// vision); per-sequence rope_delta = 0.
Status ModelPrefillBatch(const Model& m, const int32_t* tokens,
                         const int* lens, const int* seq_ids, int B,
                         uint16_t* logits, cudaStream_t stream,
                         PrefillBatchLogitsRows logits_rows) {
  const ModelConfig& cfg = m.cfg;
  if (B <= 0) return Status::Fail("ModelPrefillBatch: B must be > 0");
  if (B > cfg.max_seq)
    return Status::Fail("ModelPrefillBatch: B exceeds max_seq");

  // cu_seqlens + per-sequence validation.
  std::vector<int> seq_offset(B + 1);
  seq_offset[0] = 0;
  for (int b = 0; b < B; ++b) {
    if (lens[b] <= 0) return Status::Fail("ModelPrefillBatch: len must be > 0");
    if (lens[b] > cfg.Capacity(seq_ids[b]))
      return Status::Fail("ModelPrefillBatch: len exceeds max_len");
    if (seq_ids[b] < 0 || seq_ids[b] >= cfg.max_seq)
      return Status::Fail("ModelPrefillBatch: seq_id exceeds max_seq");
    if (lens[b] > cfg.max_prefill - seq_offset[b])
      return Status::Fail("ModelPrefillBatch: Ttot exceeds max_prefill");
    seq_offset[b + 1] = seq_offset[b] + lens[b];
  }
  const int Ttot = seq_offset[B];
  if (Ttot > cfg.max_prefill)
    return Status::Fail("ModelPrefillBatch: Ttot exceeds max_prefill");

  if (!m.metadata_upload)
    return Status::Fail("ModelPrefillBatch: upload owner missing");
  auto& upload = *m.metadata_upload;
  Status upload_status = upload.Begin(stream);
  if (!upload_status.ok()) return upload_status;

  // Fresh prefill: reset each sequence's per-layer state (per-sequence slice).
  for (int b = 0; b < B; ++b) ResetAllLayers(m, stream, seq_ids[b]);

  // Per-token positions (local 0..len-1 for a fresh sequence), pooled seq id,
  // local position (the ragged token_local array).
  std::vector<int> positions(Ttot);
  std::vector<int> token_seq(Ttot);
  std::vector<int> token_local(Ttot);
  for (int b = 0; b < B; ++b) {
    const int off = seq_offset[b];
    for (int t = 0; t < lens[b]; ++t) {
      positions[off + t] = t;
      token_seq[off + t] = seq_ids[b];
      token_local[off + t] = t;
    }
    m.rope_delta[seq_ids[b]] = 0;  // pure text
  }

  // H2D packed tokens / positions / per-token seq id / ragged descriptor.
  if (!(upload_status = upload.Copy(m.d_ids, tokens, Ttot * sizeof(int32_t)))
           .ok())
    return upload_status;
  if (!(upload_status =
            upload.Copy(m.d_positions, positions.data(), Ttot * sizeof(int)))
           .ok())
    return upload_status;
  if (!(upload_status =
            upload.Copy(m.d_token_seq_id, token_seq.data(), Ttot * sizeof(int)))
           .ok())
    return upload_status;
  if (!(upload_status = upload.Copy(m.d_ragged_seq_offset, seq_offset.data(),
                                    (B + 1) * sizeof(int)))
           .ok())
    return upload_status;
  if (!(upload_status = upload.Copy(m.d_ragged_token_local, token_local.data(),
                                    Ttot * sizeof(int)))
           .ok())
    return upload_status;

  // 3D MRoPE: pure text, each sequence's three rows = local position 0..len-1
  // (delta 0). Write into the pooled table at the sequence's [3, max_len] slice.
  {
    const size_t ml = static_cast<size_t>(cfg.max_len);
    std::vector<int> rope_row;
    for (int b = 0; b < B; ++b) {
      int* seq_rope = m.d_rope_pos + static_cast<size_t>(seq_ids[b]) * 3 * ml;
      rope_row.resize(lens[b]);
      for (int t = 0; t < lens[b]; ++t) rope_row[t] = t;
      for (int r = 0; r < 3; ++r) {
        if (!(upload_status = upload.Copy(seq_rope + r * ml, rope_row.data(),
                                          lens[b] * sizeof(int)))
                 .ok())
          return upload_status;
      }
    }
  }

  upload_status = upload.Finish();
  if (!upload_status.ok()) return upload_status;

  std::vector<int64_t> ids64(tokens, tokens + Ttot);

  // PLE n-gram history: per sequence, per token, the ngram_size-1 preceding
  // tokens (oldest first, EOS-filled before the sequence start), local to the
  // sequence (fresh prefill, no cross-sequence context).
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int hist_w = m.ple_hash.ngram_size - 1;
    hist.resize(static_cast<size_t>(Ttot) * hist_w);
    for (int b = 0; b < B; ++b) {
      const int off = seq_offset[b];
      for (int t = 0; t < lens[b]; ++t) {
        for (int j = 0; j < hist_w; ++j) {
          const int src = t - (hist_w - j);  // oldest first, local position
          hist[static_cast<size_t>(off + t) * hist_w + j] =
              (src >= 0) ? static_cast<int64_t>(tokens[off + src])
                         : cfg.eos_token_id;
        }
      }
    }
  }

  // emb + trunk (packed [Ttot, ...]).
  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, Ttot, stream);
  if (!s.ok()) return s;
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, Ttot, stream);
  if (!s.ok()) return s;

  // Layer loop + head. Per-token pooled state via d_token_seq_id; variable
  // lengths via the ragged descriptor (cu_seqlens + token_local). No
  // checkpoints (fresh prefill, not a speculative verify).
  RaggedBatch ragged;
  ragged.seq_offset = m.d_ragged_seq_offset;
  ragged.token_local = m.d_ragged_token_local;
  ragged.B = B;
  return RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                   positions.data(), Ttot, logits, stream, nullptr, nullptr,
                   nullptr, 0, 0, m.d_token_seq_id, 0, nullptr, &ragged,
                   LogitsRows::kAllRows,
                   logits_rows == PrefillBatchLogitsRows::kSequenceLastRows);
}

// Fused mixed prefill+decode forward (see model.h). A generalization of
// ModelPrefillBatch: each sequence may start fresh (base_position 0 -> reset)
// or continue (base_position > 0 -> keep state), so fresh-prefill chunks and
// continuing-decode tokens share ONE weight sweep. The ragged causal path
// (cu_seqlens + token_local) drives the per-sequence linear/PLE chains for both
// kinds; the reset and the absolute base position are the only per-seq knobs.
Status ModelMixedBatch(const Model& m, const int32_t* tokens, const int* lens,
                       const int* seq_ids, const int* base_positions,
                       const int32_t* prior_history, int B, uint16_t* logits,
                       cudaStream_t stream) {
  const ModelConfig& cfg = m.cfg;
  if (B <= 0) return Status::Fail("ModelMixedBatch: B must be > 0");
  if (B > cfg.max_seq)
    return Status::Fail("ModelMixedBatch: B exceeds max_seq");

  std::vector<int> seq_offset(B + 1);
  seq_offset[0] = 0;
  for (int b = 0; b < B; ++b) {
    if (lens[b] <= 0) return Status::Fail("ModelMixedBatch: len must be > 0");
    if (base_positions[b] < 0 || lens[b] > cfg.Capacity(seq_ids[b]) ||
        base_positions[b] > cfg.Capacity(seq_ids[b]) - lens[b])
      return Status::Fail("ModelMixedBatch: position range exceeds max_len");
    if (seq_ids[b] < 0 || seq_ids[b] >= cfg.max_seq)
      return Status::Fail("ModelMixedBatch: seq_id exceeds max_seq");
    if (lens[b] > cfg.max_prefill - seq_offset[b])
      return Status::Fail("ModelMixedBatch: Ttot exceeds max_prefill");
    seq_offset[b + 1] = seq_offset[b] + lens[b];
  }
  const int Ttot = seq_offset[B];
  if (Ttot > cfg.max_prefill)
    return Status::Fail("ModelMixedBatch: Ttot exceeds max_prefill");

  if (!m.metadata_upload)
    return Status::Fail("ModelMixedBatch: upload owner missing");
  auto& upload = *m.metadata_upload;
  Status upload_status = upload.Begin(stream);
  if (!upload_status.ok()) return upload_status;

  // Fresh sequences (base_position == 0) reset their per-layer state; continue
  // sequences keep it — this is what lets fresh-prefill chunks and continuing-
  // decode tokens share one forward.
  for (int b = 0; b < B; ++b)
    if (base_positions[b] == 0) ResetAllLayers(m, stream, seq_ids[b]);

  std::vector<int> positions(Ttot);
  std::vector<int> token_seq(Ttot);
  std::vector<int> token_local(Ttot);
  for (int b = 0; b < B; ++b) {
    const int off = seq_offset[b];
    const int base = base_positions[b];
    for (int t = 0; t < lens[b]; ++t) {
      positions[off + t] = base + t;  // absolute position
      token_seq[off + t] = seq_ids[b];
      token_local[off + t] = t;  // local within this chunk (drives causal chain)
    }
    if (base == 0) m.rope_delta[seq_ids[b]] = 0;  // fresh text sequence
  }

  if (!(upload_status = upload.Copy(m.d_ids, tokens, Ttot * sizeof(int32_t)))
           .ok())
    return upload_status;
  if (!(upload_status =
            upload.Copy(m.d_positions, positions.data(), Ttot * sizeof(int)))
           .ok())
    return upload_status;
  if (!(upload_status =
            upload.Copy(m.d_token_seq_id, token_seq.data(), Ttot * sizeof(int)))
           .ok())
    return upload_status;
  if (!(upload_status = upload.Copy(m.d_ragged_seq_offset, seq_offset.data(),
                                    (B + 1) * sizeof(int)))
           .ok())
    return upload_status;
  if (!(upload_status = upload.Copy(m.d_ragged_token_local, token_local.data(),
                                    Ttot * sizeof(int)))
           .ok())
    return upload_status;

  // 3D MRoPE (pure text): each sequence's three rows = absolute position
  // base+t, written into the [base, base+len) slice of its [3, max_len] table.
  {
    const size_t ml = static_cast<size_t>(cfg.max_len);
    std::vector<int> rope_row;
    for (int b = 0; b < B; ++b) {
      int* seq_rope = m.d_rope_pos + static_cast<size_t>(seq_ids[b]) * 3 * ml;
      const int base = base_positions[b];
      rope_row.resize(lens[b]);
      for (int t = 0; t < lens[b]; ++t) rope_row[t] = base + t;
      for (int r = 0; r < 3; ++r) {
        if (!(upload_status =
                  upload.Copy(seq_rope + r * ml + base, rope_row.data(),
                              lens[b] * sizeof(int)))
                 .ok())
          return upload_status;
      }
    }
  }

  upload_status = upload.Finish();
  if (!upload_status.ok()) return upload_status;

  std::vector<int64_t> ids64(tokens, tokens + Ttot);

  // PLE n-gram history: for token (off+t) the w preceding tokens (oldest
  // first). In-chunk part (j+t >= w) from `tokens`; before-chunk part from the
  // caller's per-seq `prior_history` (EOS-filled for fresh sequences, so a
  // fresh sequence reproduces ModelPrefillBatch exactly).
  std::vector<int64_t> hist;
  if (m.ple_emb) {
    const int w = m.ple_hash.ngram_size - 1;
    hist.resize(static_cast<size_t>(Ttot) * w);
    for (int b = 0; b < B; ++b) {
      const int off = seq_offset[b];
      const int32_t* ph = prior_history + static_cast<size_t>(b) * w;
      for (int t = 0; t < lens[b]; ++t) {
        for (int j = 0; j < w; ++j) {
          const int src = j + t - w;  // in-chunk local index if >= 0
          hist[static_cast<size_t>(off + t) * w + j] =
              (src >= 0) ? static_cast<int64_t>(tokens[off + src])
                         : static_cast<int64_t>(ph[j + t]);
        }
      }
    }
  }

  Status s = EmbedLookup(m.head, m.d_ids, m.d_emb, Ttot, stream);
  if (!s.ok()) return s;
  s = ExpandTrunk(m.head, m.d_emb, m.d_trunk, Ttot, stream);
  if (!s.ok()) return s;

  RaggedBatch ragged2;
  ragged2.seq_offset = m.d_ragged_seq_offset;
  ragged2.token_local = m.d_ragged_token_local;
  ragged2.B = B;
  return RunLayers(m, m.d_trunk, m.d_trunk2, ids64.data(), hist.data(),
                   positions.data(), Ttot, logits, stream, nullptr, nullptr,
                   nullptr, 0, 0, m.d_token_seq_id, 0, nullptr, &ragged2);
}


// the same dims, which they do for this architecture).
namespace {
struct LinCkptDims {
  size_t ssm_elems = 0;
  size_t conv_elems = 0;
  size_t ple_conv_elems = 0;  // PLE short-conv state (0 if no PLE layer)
  int num_lin = 0;
  int num_ple = 0;
};
LinCkptDims CollectLinCkptDims(const Model& m) {
  LinCkptDims d;
  for (const auto& l : m.layers) {
    if (l.is_full_attention) continue;
    if (d.num_lin == 0) {
      d.ssm_elems = static_cast<size_t>(l.linear.nv) * l.linear.kd * l.linear.vd;
      d.conv_elems =
          static_cast<size_t>(l.linear.in_qkv()) * (l.linear.conv_k - 1);
    }
    d.num_lin++;
    if (l.has_ple) {
      if (d.num_ple == 0) {
        d.ple_conv_elems = static_cast<size_t>(l.hc_dim) *
                           (l.ple.conv_kernel - 1) * l.ple.conv_dilation;
      }
      d.num_ple++;
    }
  }
  return d;
}
}  // namespace

Status ModelReserveVerifyCheckpoints(Model& m, int num_ckpt) {
  if (num_ckpt < 0 || m.cfg.max_seq <= 0)
    return Status::Fail("ModelReserveVerifyCheckpoints: invalid capacity");
  if (num_ckpt <= m.verify_ckpt_cap) return Status();
  InvalidateVerifyCheckpoints(m);
  const LinCkptDims d = CollectLinCkptDims(m);
  if (d.num_lin == 0) return Status();  // no linear layers (nothing to save)
  if (m.d_verify_ssm_ckpt) cudaFree(m.d_verify_ssm_ckpt);
  if (m.d_verify_conv_ckpt) cudaFree(m.d_verify_conv_ckpt);
  if (m.d_verify_ple_conv_ckpt) cudaFree(m.d_verify_ple_conv_ckpt);
  m.d_verify_ssm_ckpt = nullptr;
  m.d_verify_conv_ckpt = nullptr;
  m.d_verify_ple_conv_ckpt = nullptr;
  m.verify_ckpt_cap = 0;
  // Publish capacity only after all three allocations succeed. A failed grow
  // leaves no partial checkpoint owner and remains safe to retry.
  struct PendingCheckpoints {
    Model* model;
    ~PendingCheckpoints() {
      if (!model) return;
      if (model->d_verify_ssm_ckpt) cudaFree(model->d_verify_ssm_ckpt);
      if (model->d_verify_conv_ckpt) cudaFree(model->d_verify_conv_ckpt);
      if (model->d_verify_ple_conv_ckpt)
        cudaFree(model->d_verify_ple_conv_ckpt);
      model->d_verify_ssm_ckpt = nullptr;
      model->d_verify_conv_ckpt = nullptr;
      model->d_verify_ple_conv_ckpt = nullptr;
    }
  } pending{&m};
  // Pooled over max_seq (Phase 2 MTP multi-seq verify): [num_layers, max_seq,
  // cap, elems]. max_seq == 1 degenerates to the legacy [num_layers, cap,
  // elems] layout (bit-identical single-seq path).
  const size_t max_seq = static_cast<size_t>(m.cfg.max_seq);
  const size_t ssm_bytes = static_cast<size_t>(d.num_lin) * max_seq * num_ckpt *
                           d.ssm_elems * sizeof(float);
  const size_t conv_bytes = static_cast<size_t>(d.num_lin) * max_seq * num_ckpt *
                            d.conv_elems * sizeof(uint16_t);
  const size_t ple_bytes = static_cast<size_t>(d.num_ple) * max_seq * num_ckpt *
                           d.ple_conv_elems * sizeof(uint16_t);
  if (cudaMalloc(reinterpret_cast<void**>(&m.d_verify_ssm_ckpt), ssm_bytes) !=
      cudaSuccess)
    return Status::Fail("ModelReserveVerifyCheckpoints: cudaMalloc ssm");
  if (cudaMalloc(reinterpret_cast<void**>(&m.d_verify_conv_ckpt), conv_bytes) !=
      cudaSuccess)
    return Status::Fail("ModelReserveVerifyCheckpoints: cudaMalloc conv");
  if (d.num_ple > 0 &&
      cudaMalloc(reinterpret_cast<void**>(&m.d_verify_ple_conv_ckpt),
                 ple_bytes) != cudaSuccess)
    return Status::Fail("ModelReserveVerifyCheckpoints: cudaMalloc ple_conv");
  m.verify_ckpt_cap = num_ckpt;
  pending.model = nullptr;
  return Status();
}

Status ModelRestoreCheckpoint(const Model& m, int ckpt_idx,
                              cudaStream_t stream, int seq_id) {
  if (seq_id < 0 || seq_id >= m.cfg.max_seq || ckpt_idx < 0 ||
      ckpt_idx >= m.verify_ckpt_rows ||
      m.verify_ckpt_rows > m.verify_ckpt_cap ||
      std::find(m.verify_ckpt_slots.begin(), m.verify_ckpt_slots.end(),
                seq_id) == m.verify_ckpt_slots.end())
    return Status::Fail("ModelRestoreCheckpoint: unwritten or stale row/slot");
  Status capacity = CheckVerifyCheckpointCapacity(m, m.verify_ckpt_rows);
  if (!capacity.ok()) return capacity;
  const LinCkptDims d = CollectLinCkptDims(m);
  const int cap = m.verify_ckpt_cap;
  const size_t max_seq = static_cast<size_t>(m.cfg.max_seq);
  const size_t seq = static_cast<size_t>(seq_id);
  // Writers and readers use the reserved capacity as the physical stride:
  // [num_layers, max_seq, cap, elems]. verify_ckpt_rows only bounds which
  // rows are valid; it does not change the allocation layout.
  // Restored into the same sequence's pooled recurrent-state slice. (The PLE
  // conv restore fixes the pre-existing single-seq gap: the PLE short-conv is
  // an in-place recurrence and must roll back on a partial accept too.)
  int lin_idx = 0;
  int ple_idx = 0;
  for (const auto& l : m.layers) {
    if (l.is_full_attention) continue;
    const size_t lin_slice =
        (static_cast<size_t>(lin_idx) * max_seq + seq) * cap;
    const float* ssm_src = m.d_verify_ssm_ckpt + lin_slice * d.ssm_elems +
                           static_cast<size_t>(ckpt_idx) * d.ssm_elems;
    const uint16_t* conv_src = m.d_verify_conv_ckpt + lin_slice * d.conv_elems +
                               static_cast<size_t>(ckpt_idx) * d.conv_elems;
    float* ssm_dst = l.ssm_state + seq * d.ssm_elems;
    uint16_t* conv_dst = l.conv_state + seq * d.conv_elems;
    if (cudaMemcpyAsync(ssm_dst, ssm_src, d.ssm_elems * sizeof(float),
                        cudaMemcpyDeviceToDevice, stream) != cudaSuccess)
      return Status::Fail("ModelRestoreCheckpoint: D2D ssm");
    if (cudaMemcpyAsync(conv_dst, conv_src, d.conv_elems * sizeof(uint16_t),
                        cudaMemcpyDeviceToDevice, stream) != cudaSuccess)
      return Status::Fail("ModelRestoreCheckpoint: D2D conv");
    lin_idx++;
    if (l.has_ple) {
      const size_t ple_slice =
          (static_cast<size_t>(ple_idx) * max_seq + seq) * cap;
      const uint16_t* ple_src =
          m.d_verify_ple_conv_ckpt + ple_slice * d.ple_conv_elems +
          static_cast<size_t>(ckpt_idx) * d.ple_conv_elems;
      uint16_t* ple_dst = l.ple_conv_state + seq * d.ple_conv_elems;
      if (cudaMemcpyAsync(ple_dst, ple_src, d.ple_conv_elems * sizeof(uint16_t),
                          cudaMemcpyDeviceToDevice, stream) != cudaSuccess)
        return Status::Fail("ModelRestoreCheckpoint: D2D ple_conv");
      ple_idx++;
    }
  }
  return Status();
}

// ---------------------------------------------------------------------------
// PD-ready 阶段边界 API (see model.h).
// ---------------------------------------------------------------------------

Status ModelCompleteSequence(ModelSequence* seq, cudaStream_t stream,
                             const Status& submitted) {
  return CompleteSequenceWork({&seq, 1}, submitted, [stream] {
    const cudaError_t error = cudaStreamSynchronize(stream);
    if (error != cudaSuccess)
      return Status::Fail(std::string("sequence completion: ") +
                          cudaGetErrorString(error));
    return Status();
  });
}

Status ModelBeginSequence(const Model& m, ModelSequence* seq,
                          cudaStream_t stream, int seq_id) {
  if (!seq || seq_id < 0 || seq_id >= m.cfg.max_seq || seq->HasPending())
    return Status::Fail("ModelBeginSequence: invalid slot or pending work");
  Status s = ResetAllLayers(m, stream, seq_id);
  const cudaError_t error = cudaStreamSynchronize(stream);
  if (error != cudaSuccess)
    s = Status::Fail(std::string("sequence reset: ") +
                     cudaGetErrorString(error));
  if (!s.ok()) {
    seq->Fail();
    return s;
  }
  return seq->Begin(seq_id);
}

Status ModelPrefill(const Model& m, ModelSequence* seq,
                    const int32_t* input_ids, int T, uint16_t* logits,
                    cudaStream_t stream, uint16_t* trunk_out,
                    const VisionFeatures* vision, int seq_id,
                    LogitsRows logits_rows, SequenceCompletion completion) {
  if (!seq || !input_ids) return Status::Fail("ModelPrefill: null input");
  if (seq_id == -1) seq_id = seq->seq_id;
  if (seq->seq_id < 0 || seq->seq_id >= m.cfg.max_seq ||
      seq_id != seq->seq_id || seq->stage != ModelSequence::Stage::kPrefill ||
      seq->position != 0 || T <= 0 || T > m.cfg.max_prefill)
    return Status::Fail("ModelPrefill: invalid sequence or range");
  Status s =
      seq->Submit({input_ids, static_cast<size_t>(T)},
                  ModelSequence::Stage::kDecode, m.cfg.Capacity(seq->seq_id));
  if (!s.ok()) return s;
  s = RunPrefill(m, input_ids, T, logits, stream, trunk_out, vision,
                 seq_id, logits_rows);
  if (!s.ok()) seq->Fail();
  return completion == SequenceCompletion::kWait
             ? ModelCompleteSequence(seq, stream, s) : s;
}

Status ModelPrefillTextChunk(const Model& m, ModelSequence* seq,
                            const int32_t* prompt, int prompt_length,
                            int chunk_length, uint16_t* logits,
                            cudaStream_t stream, uint16_t* trunk_out,
                            LogitsRows logits_rows,
                            SequenceCompletion completion) {
  if (!seq || !prompt)
    return Status::Fail("ModelPrefillTextChunk: null sequence or prompt");
  const int base = seq->position;
  if (seq->stage != ModelSequence::Stage::kPrefill || prompt_length <= 0 ||
      prompt_length > m.cfg.Capacity(seq->seq_id) || base < 0 ||
      base >= prompt_length || chunk_length <= 0 ||
      chunk_length > m.cfg.max_prefill || chunk_length > prompt_length - base ||
      seq->seq_id < 0 || seq->seq_id >= m.cfg.max_seq)
    return Status::Fail("ModelPrefillTextChunk: invalid sequence or range");
  const auto next = base + chunk_length == prompt_length
                        ? ModelSequence::Stage::kDecode
                        : ModelSequence::Stage::kPrefill;
  Status s = seq->Submit({prompt + base, static_cast<size_t>(chunk_length)},
                         next, m.cfg.Capacity(seq->seq_id));
  if (!s.ok()) return s;
  s = base == 0
      ? RunPrefill(m, prompt, chunk_length, logits, stream, trunk_out,
                   nullptr, seq->seq_id, logits_rows)
      : ModelDecodeBatch(m, prompt + base, chunk_length, base,
                         seq->history.data(), base, logits, stream,
                         trunk_out, false, seq->seq_id, logits_rows);
  if (!s.ok()) seq->Fail();
  return completion == SequenceCompletion::kWait
             ? ModelCompleteSequence(seq, stream, s) : s;
}

Status ModelDecodeStepSeq(const Model& m, ModelSequence* seq,
                          int32_t token_id, uint16_t* logits,
                          cudaStream_t stream, uint16_t* trunk_out,
                          int seq_id, SequenceCompletion completion) {
  if (!seq) return Status::Fail("ModelDecodeStepSeq: null seq");
  if (seq_id == -1) seq_id = seq->seq_id;
  if (seq->seq_id < 0 || seq->seq_id >= m.cfg.max_seq ||
      seq_id != seq->seq_id || seq->stage != ModelSequence::Stage::kDecode)
    return Status::Fail("ModelDecodeStepSeq: invalid sequence slot/stage");
  Status s = seq->Submit({&token_id, 1}, ModelSequence::Stage::kDecode,
                         m.cfg.Capacity(seq->seq_id));
  if (!s.ok()) return s;
  s = ModelDecodeStep(m, token_id, seq->position, seq->history.data(),
                      logits, stream, trunk_out, seq_id);
  if (!s.ok()) seq->Fail();
  return completion == SequenceCompletion::kWait
             ? ModelCompleteSequence(seq, stream, s) : s;
}

Status ModelEndSequence(ModelSequence* seq) {
  return seq ? seq->End() : Status::Fail("ModelEndSequence: null seq");
}

// ---------------------------------------------------------------------------
// Recurrent-state snapshot (speculative-decoding rollback). See model.h.
//
// The paged full-attention caches (KV + indexer) are written at absolute
// positions and grow monotonically; a speculative re-run of the same positions
// overwrites the same pages, so they need no rollback. Only the recurrent
// state (linear SSM/conv, PLE short-conv) is updated in place and cannot be
// rewound by position, so it is snapshotted before verification and restored
// after a partial accept.
// ---------------------------------------------------------------------------

namespace {

struct RecurrentStateRef {
  void* dev;
  size_t bytes;
};

// Collect every recurrent-state buffer (device pointer + byte size) across all
// layers, in a stable order. The paged KV/indexer buffers are deliberately
// excluded (see the note above).
std::vector<RecurrentStateRef> CollectRecurrentState(const Model& m) {
  std::vector<RecurrentStateRef> refs;
  for (const auto& l : m.layers) {
    if (l.ssm_state) {
      refs.push_back({l.ssm_state,
                      static_cast<size_t>(l.linear.nv) * l.linear.kd *
                          l.linear.vd * 4});
      refs.push_back({l.conv_state,
                      static_cast<size_t>(l.linear.in_qkv()) *
                          (l.linear.conv_k - 1) * 2});
    }
    if (l.ple_conv_state) {
      refs.push_back({l.ple_conv_state,
                      static_cast<size_t>(l.hc_dim) *
                          (l.ple.conv_kernel - 1) * l.ple.conv_dilation * 2});
    }
  }
  return refs;
}


}  // namespace

// Test-only: read the verify checkpoint buffers (ssm/conv/ple_conv) for a
// given ckpt_idx into a host snapshot, in the SAME order as
// CollectRecurrentState (per layer: ssm, conv, then ple_conv if present).
// Lets a test directly compare checkpoint-N against the T=1 recurrent state
// WITHOUT going through ModelRestoreCheckpoint (which overwrites the live
// state). Fails if no checkpoints are reserved. Lives in the q4t::model
// namespace (not the anonymous one) so tests can link it; computes the
// element counts directly instead of reusing the anonymous-namespace helper.
Status ModelSnapshotCheckpoint(const Model& m, int ckpt_idx,
                               ModelStateSnapshot* snap, cudaStream_t stream,
                               int seq_id) {
  if (!snap) return Status::Fail("ModelSnapshotCheckpoint: null");
  if (!m.d_verify_ssm_ckpt || ckpt_idx < 0 ||
      ckpt_idx >= m.verify_ckpt_cap)
    return Status::Fail("ModelSnapshotCheckpoint: no/invalid ckpt");
  size_t ssm_elems = 0, conv_elems = 0, ple_elems = 0;
  for (const auto& l : m.layers) {
    if (l.ssm_state && ssm_elems == 0) {
      ssm_elems =
          static_cast<size_t>(l.linear.nv) * l.linear.kd * l.linear.vd;
      conv_elems = static_cast<size_t>(l.linear.in_qkv()) *
                   (l.linear.conv_k - 1);
    }
    if (l.ple_conv_state && ple_elems == 0) {
      ple_elems = static_cast<size_t>(l.hc_dim) *
                  (l.ple.conv_kernel - 1) * l.ple.conv_dilation;
    }
  }
  const size_t max_seq = static_cast<size_t>(m.cfg.max_seq);
  const size_t cap = static_cast<size_t>(m.verify_ckpt_cap);
  const size_t seq = static_cast<size_t>(seq_id);
  const size_t ci = static_cast<size_t>(ckpt_idx);
  struct Ref {
    void* dev;
    size_t bytes;
  };
  std::vector<Ref> refs;
  int lin_idx = 0;
  int ple_idx = 0;
  for (const auto& l : m.layers) {
    if (l.ssm_state) {
      const size_t lin_slice =
          (static_cast<size_t>(lin_idx) * max_seq + seq) * cap;
      refs.push_back(
          {m.d_verify_ssm_ckpt + (lin_slice + ci) * ssm_elems,
           ssm_elems * sizeof(float)});
      refs.push_back(
          {m.d_verify_conv_ckpt + (lin_slice + ci) * conv_elems,
           conv_elems * sizeof(uint16_t)});
      lin_idx++;
    }
    if (l.ple_conv_state) {
      const size_t ple_slice =
          (static_cast<size_t>(ple_idx) * max_seq + seq) * cap;
      refs.push_back(
          {m.d_verify_ple_conv_ckpt + (ple_slice + ci) * ple_elems,
           ple_elems * sizeof(uint16_t)});
      ple_idx++;
    }
  }
  size_t total = 0;
  for (const auto& r : refs) total += r.bytes;
  if (total == 0) {
    snap->Free();
    return Status();
  }
  snap->data.resize(total);
  size_t off = 0;
  for (const auto& r : refs) {
    if (cudaMemcpyAsync(snap->data.data() + off, r.dev, r.bytes,
                        cudaMemcpyDeviceToHost, stream) != cudaSuccess) {
      return Status::Fail("ModelSnapshotCheckpoint: D2H copy");
    }
    off += r.bytes;
  }
  if (cudaStreamSynchronize(stream) != cudaSuccess) {
    return Status::Fail("ModelSnapshotCheckpoint: sync");
  }
  snap->bytes = total;
  snap->valid = true;
  return Status();
}


void ModelStateSnapshot::Free() {
  data.clear();
  data.shrink_to_fit();
  bytes = 0;
  valid = false;
}

size_t ModelStateSnapshotBytes(const Model& m) {
  size_t total = 0;
  for (const auto& r : CollectRecurrentState(m)) total += r.bytes;
  return total;
}

Status ModelSnapshotState(const Model& m, ModelStateSnapshot* snap,
                          cudaStream_t stream) {
  if (!snap) return Status::Fail("ModelSnapshotState: null");
  const auto refs = CollectRecurrentState(m);
  size_t total = 0;
  for (const auto& r : refs) total += r.bytes;
  if (total == 0) {
    snap->Free();
    return Status();
  }
  snap->data.resize(total);
  size_t off = 0;
  for (const auto& r : refs) {
    if (cudaMemcpyAsync(snap->data.data() + off, r.dev, r.bytes,
                        cudaMemcpyDeviceToHost, stream) != cudaSuccess) {
      return Status::Fail("ModelSnapshotState: D2H copy");
    }
    off += r.bytes;
  }
  // Synchronize so the host buffer is fully populated before the caller uses
  // it (the snapshot is a host-side copy).
  if (cudaStreamSynchronize(stream) != cudaSuccess) {
    return Status::Fail("ModelSnapshotState: sync");
  }
  snap->bytes = total;
  snap->valid = true;
  return Status();
}

Status ModelRestoreState(const Model& m, const ModelStateSnapshot& snap,
                         cudaStream_t stream) {
  if (!snap.valid) return Status::Fail("ModelRestoreState: invalid snapshot");
  InvalidateVerifyCheckpoints(m);
  const auto refs = CollectRecurrentState(m);
  size_t off = 0;
  for (const auto& r : refs) {
    if (cudaMemcpyAsync(r.dev, snap.data.data() + off, r.bytes,
                        cudaMemcpyHostToDevice, stream) != cudaSuccess) {
      return Status::Fail("ModelRestoreState: H2D copy");
    }
    off += r.bytes;
  }
  // Synchronize so the device state is fully restored before the caller runs
  // the next forward (the re-run reads the recurrent state immediately).
  if (cudaStreamSynchronize(stream) != cudaSuccess) {
    return Status::Fail("ModelRestoreState: sync");
  }
  return Status();
}

}  // namespace model
}  // namespace q4t

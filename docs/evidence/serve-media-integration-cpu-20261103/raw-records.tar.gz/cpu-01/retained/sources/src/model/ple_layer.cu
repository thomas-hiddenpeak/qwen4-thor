// PLE layer forward implementation. See ple_layer.h.
//
//   1. key   = embeddings @ key_proj^T    [T, hc*hs]   (Bf16Gemm)
//   2. value = embeddings @ value_proj^T  [T, hs]       (Bf16Gemm)
//   3. key_n   = GroupedGemmaRMSNorm(key, norm_key)     (kernel)
//   4. query_n = GroupedGemmaRMSNorm(hyper_input, norm_query) (kernel)
//   5. gate = sigmoid(sqrt(|dot(key_n, query_n)/sqrt(hs)|))  [T, hc] (kernel)
//   6. gated_value[b,c] = gate[b] * value[c]              [T, hc*hs] (kernel)
//   7. gated_n = GroupedGemmaRMSNorm(gated_value, norm_conv) (kernel)
//   8. out = gated_value + silu(depthwise-causal-conv(gated_n))  (fused)
#include "q4t/model/ple_layer.h"

#include <cuda_bf16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "q4t/model/linear.h"

namespace q4t {
namespace model {

namespace {

constexpr int kBlock = 256;
constexpr size_t kGemmScratch = 32 * 1024 * 1024;  // 32 MiB cuBLASLt scratch

__device__ __forceinline__ float Bf16ToFloat(uint16_t b) {
  uint32_t bits = static_cast<uint32_t>(b) << 16;
  float f;
  std::memcpy(&f, &bits, sizeof(f));
  return f;
}
__device__ __forceinline__ uint16_t FloatToBf16(float f) {
  const __nv_bfloat16 b = __float2bfloat16_rn(f);
  return *reinterpret_cast<const uint16_t*>(&b);
}
__device__ __forceinline__ float Silu(float v) {
  return v / (1.0f + __expf(-v));
}

// GroupedGemmaRMSNorm: per-branch (group of `hs`) RMSNorm, then scale by
// (1 + weight). One block per row; each BRANCH is owned by one warp (warp w
// handles branch w) so the hc branches reduce in parallel via warp shuffles
// instead of the old sequential block-wide barrier chain (44 __syncthreads).
// blockDim = 32 * hc. float4-vectorized over hs.
// (Same op as the hyper-connection norm; re-implemented here to keep this
// translation unit self-contained.)
__global__ void GroupedRmsNormKernel(const uint16_t* __restrict__ x,
                                     const uint16_t* __restrict__ weight,
                                     uint16_t* __restrict__ out, int T, int hc,
                                     int hs, float eps) {
  const int t = blockIdx.x;
  if (t >= T) return;
  const int b = threadIdx.x >> 5;  // branch = warp id
  const int lane = threadIdx.x & 31;
  if (b >= hc) return;
  const uint16_t* g = x + (static_cast<size_t>(t) * hc + b) * hs;
  uint16_t* orow = out + (static_cast<size_t>(t) * hc + b) * hs;
  const uint16_t* wg = weight + static_cast<size_t>(b) * hs;
  const float4* gv = reinterpret_cast<const float4*>(g);
  const float4* wv = reinterpret_cast<const float4*>(wg);
  float4* ov = reinterpret_cast<float4*>(orow);
  const int n8 = hs / 8;  // float4 = 16 B = 8 bf16
  // Pass 1: sum of squares for this branch.
  float acc = 0.f;
  for (int i = lane; i < n8; i += 32) {
    const __nv_bfloat162* p = reinterpret_cast<const __nv_bfloat162*>(&gv[i]);
    float2 v0 = __bfloat1622float2(p[0]);
    float2 v1 = __bfloat1622float2(p[1]);
    float2 v2 = __bfloat1622float2(p[2]);
    float2 v3 = __bfloat1622float2(p[3]);
    acc += v0.x * v0.x + v0.y * v0.y + v1.x * v1.x + v1.y * v1.y +
           v2.x * v2.x + v2.y * v2.y + v3.x * v3.x + v3.y * v3.y;
  }
  for (int i = n8 * 8 + lane; i < hs; i += 32) {
    const float v = Bf16ToFloat(g[i]);
    acc += v * v;
  }
#pragma unroll
  for (int off = 16; off > 0; off >>= 1)
    acc += __shfl_xor_sync(0xffffffffu, acc, off);
  const float rs = rsqrtf(acc / hs + eps);
  // Pass 2: normalize + scale, write back.
  for (int i = lane; i < n8; i += 32) {
    const __nv_bfloat162* p = reinterpret_cast<const __nv_bfloat162*>(&gv[i]);
    const __nv_bfloat162* q = reinterpret_cast<const __nv_bfloat162*>(&wv[i]);
    float2 v0 = __bfloat1622float2(p[0]);
    float2 v1 = __bfloat1622float2(p[1]);
    float2 v2 = __bfloat1622float2(p[2]);
    float2 v3 = __bfloat1622float2(p[3]);
    float2 w0 = __bfloat1622float2(q[0]);
    float2 w1 = __bfloat1622float2(q[1]);
    float2 w2 = __bfloat1622float2(q[2]);
    float2 w3 = __bfloat1622float2(q[3]);
    v0.x *= rs * (1.f + w0.x);
    v0.y *= rs * (1.f + w0.y);
    v1.x *= rs * (1.f + w1.x);
    v1.y *= rs * (1.f + w1.y);
    v2.x *= rs * (1.f + w2.x);
    v2.y *= rs * (1.f + w2.y);
    v3.x *= rs * (1.f + w3.x);
    v3.y *= rs * (1.f + w3.y);
    float4 o;
    __nv_bfloat162* op = reinterpret_cast<__nv_bfloat162*>(&o);
    op[0] = __floats2bfloat162_rn(v0.x, v0.y);
    op[1] = __floats2bfloat162_rn(v1.x, v1.y);
    op[2] = __floats2bfloat162_rn(v2.x, v2.y);
    op[3] = __floats2bfloat162_rn(v3.x, v3.y);
    ov[i] = o;
  }
  for (int i = n8 * 8 + lane; i < hs; i += 32) {
    const float v = Bf16ToFloat(g[i]);
    const float w = Bf16ToFloat(wg[i]);
    orow[i] = FloatToBf16(v * rs * (1.f + w));
  }
}

// gate[t, b] = sigmoid( sqrt(|raw|) * sign(raw) ),
// raw = (sum_c key_n[t, b*hs+c] * query_n[t, b*hs+c]) / sqrt(hs).
// One thread per (t, b); loops over hs.
__global__ void PleGateKernel(const uint16_t* __restrict__ key_n,
                              const uint16_t* __restrict__ query_n,
                              uint16_t* __restrict__ gate, int T, int hc,
                              int hs, float inv_sqrt_hs) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * hc) return;
  const int t = idx / hc;
  const int b = idx % hc;
  const uint16_t* k = key_n + static_cast<size_t>(t) * hc * hs + b * hs;
  const uint16_t* q = query_n + static_cast<size_t>(t) * hc * hs + b * hs;
  float acc = 0.0f;
  for (int c = 0; c < hs; ++c) {
    acc += Bf16ToFloat(k[c]) * Bf16ToFloat(q[c]);
  }
  float raw = acc * inv_sqrt_hs;
  float g = sqrtf(fabsf(raw) + 1e-6f) * (raw < 0.0f ? -1.0f : 1.0f);
  gate[idx] = FloatToBf16(1.0f / (1.0f + __expf(-g)));
}

// gated_value[t, b*hs+c] = gate[t, b] * value[t, c]. One thread per element;
// value is broadcast over the hc branches.
__global__ void GatedValueKernel(const uint16_t* __restrict__ gate,
                                 const uint16_t* __restrict__ value,
                                 uint16_t* __restrict__ out, int T, int hc,
                                 int hs) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * hc * hs) return;
  const int t = idx / (hc * hs);
  const int rem = idx % (hc * hs);
  const int b = rem / hs;
  const int c = rem % hs;
  const float g = Bf16ToFloat(gate[t * hc + b]);
  const float v = Bf16ToFloat(value[t * hs + c]);
  out[idx] = FloatToBf16(g * v);
}

// Depthwise causal convolution over the token sequence, then SiLU, then add
// the (un-normed) gated_value:
//   out[t, c] = gated[t, c] + silu( sum_{j=0}^{K-1} conv1d[c, j] *
//                          gated_n[t - (K-1-j)*dilation, c] )
// Taps before the sequence start (src < 0) read from the persistent
// `state` ([C, state_len] BF16, oldest-first, state_len = (K-1)*dilation)
// instead of zero-padding: state[c, src + state_len] is the gated_n value at
// global position src (the reference _short_conv keeps this 9-element state
// via update_conv_state). For a fresh sequence the state is zero, so this
// reduces to zero-padding (the prefill path is unchanged).
// Fused with the old PleAddKernel: the conv result goes through the same BF16
// round-trip (store-then-read) as the old two-kernel path, so the sum is
// bit-identical. When trunk_add is non-null, also fuses the old
// PleAddTrunkKernel: out = BF16(trunk_add + BF16(gated + conv)) — the double
// BF16 rounding matches the old two-kernel path exactly.
// One thread per (t, c); loops over K taps.
__global__ void DepthwiseConvAddKernel(const uint16_t* __restrict__ x,
                                       const uint16_t* __restrict__ conv1d,
                                       const uint16_t* __restrict__ state,
                                       const uint16_t* __restrict__ gated,
                                       const uint16_t* __restrict__ trunk_add,
                                       uint16_t* __restrict__ out, int T,
                                       int C, int K, int dilation,
                                       int state_len) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * C) return;
  const int t = idx / C;
  const int c = idx % C;
  float acc = 0.0f;
  for (int j = 0; j < K; ++j) {
    const int src = t - (K - 1 - j) * dilation;
    float xv;
    if (src < 0)
      xv = Bf16ToFloat(state[static_cast<size_t>(c) * state_len + (src + state_len)]);
    else
      xv = Bf16ToFloat(x[static_cast<size_t>(src) * C + c]);
    const float w = Bf16ToFloat(conv1d[c * K + j]);
    acc += w * xv;
  }
  const float conv = Bf16ToFloat(FloatToBf16(Silu(acc)));
  const uint16_t ple_out = FloatToBf16(Bf16ToFloat(gated[idx]) + conv);
  if (trunk_add)
    out[idx] = FloatToBf16(Bf16ToFloat(trunk_add[idx]) + Bf16ToFloat(ple_out));
  else
    out[idx] = ple_out;
}

// Update the PLE short-conv state to the last `state_len` gated_n values of
// (old state + this chunk). Mirrors Conv1dUpdateStateKernel in
// linear_attention.cu, but with state_len = (K-1)*dilation (9 for K=4, d=3)
// instead of conv_k-1.
//
//   T >= state_len: state[k] = input[T - state_len + k]  (whole window from
//              the chunk; the prefill path).
//   T <  state_len (DECODE, e.g. T = 1): the window slides by T. Let
//              shift = state_len - T.
//                state[k] = state[k + T]      for k <  shift  (slide the old
//                                            window; reads a higher index,
//                                            so ascending k is in-place safe)
//                state[k] = input[k - shift]  for k >= shift  (the new tokens)
//              e.g. [0,0,0,0,0,g0,g1,g2,g3] + g4 -> [0,0,0,0,g0,g1,g2,g3,g4].
__global__ void PleConvUpdateStateKernel(uint16_t* __restrict__ state,
                                         const uint16_t* __restrict__ input,
                                         int T, int C, int state_len) {
  const int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= C) return;
  const int shift = state_len - T;  // > 0 only in the decode path (T < state_len)
  if (shift > 0) {
    for (int k = 0; k < shift; ++k)
      state[static_cast<size_t>(c) * state_len + k] =
          state[static_cast<size_t>(c) * state_len + k + T];
    for (int k = shift; k < state_len; ++k)
      state[static_cast<size_t>(c) * state_len + k] =
          input[static_cast<size_t>(k - shift) * C + c];
  } else {
    for (int k = 0; k < state_len; ++k) {
      const int src = T - state_len + k;
      if (src >= 0)
        state[static_cast<size_t>(c) * state_len + k] =
            input[static_cast<size_t>(src) * C + c];
    }
  }
}

// Depthwise causal conv + SiLU + add for B2 multi-sequence decode. One thread
// per (t, c). Token t belongs to sequence d_seq_id[t]; its conv history lives
// ENTIRELY in that sequence's conv_state slice (each packed token is the NEXT
// decode token of its own sequence, so the dilated window needs no cross-token
// input — only the per-sequence old_state and the current input[t]). Mirrors
// one decode step of DepthwiseConvAddKernel (T=1) with the state selected by
// d_seq_id[t].
__global__ void DepthwiseConvAddMultiSeqKernel(
    const uint16_t* __restrict__ x, const uint16_t* __restrict__ conv1d,
    const uint16_t* __restrict__ state, const uint16_t* __restrict__ gated,
    const uint16_t* __restrict__ trunk_add, uint16_t* __restrict__ out,
    const int* __restrict__ d_seq_id, int T, int C, int K, int dilation,
    int state_len) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * C) return;
  const int t = idx / C;
  const int c = idx % C;
  const uint16_t* seq_state =
      state + static_cast<size_t>(d_seq_id[t]) * C * state_len;
  float acc = 0.0f;
  for (int j = 0; j < K; ++j) {
    const int src = -(K - 1 - j) * dilation;  // decode: next token of seq
    float xv;
    if (src < 0)
      xv = Bf16ToFloat(seq_state[static_cast<size_t>(c) * state_len +
                                 (src + state_len)]);
    else
      // The single non-negative tap (j == K-1) is the CURRENT token, which
      // lives at packed index t (NOT 0 — that would be token 0's row).
      xv = Bf16ToFloat(x[static_cast<size_t>(t) * C + c]);
    const float w = Bf16ToFloat(conv1d[c * K + j]);
    acc += w * xv;
  }
  const float conv = Bf16ToFloat(FloatToBf16(Silu(acc)));
  const uint16_t ple_out = FloatToBf16(Bf16ToFloat(gated[idx]) + conv);
  if (trunk_add)
    out[idx] = FloatToBf16(Bf16ToFloat(trunk_add[idx]) + Bf16ToFloat(ple_out));
  else
    out[idx] = ple_out;
}

// Update the PLE short-conv state for B2 multi-sequence decode. One thread per
// channel; slides the conv_state of sequence d_seq_id[t] by one token:
// state[k] = state[k+1] for k < state_len-1, state[state_len-1] = input[t].
// Mirrors the decode branch (shift = state_len - T, T = 1) of
// PleConvUpdateStateKernel.
__global__ void PleConvUpdateStateMultiSeqKernel(
    uint16_t* __restrict__ state, const uint16_t* __restrict__ input,
    const int* __restrict__ d_seq_id, int C, int state_len) {
  const int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= C) return;
  const int t = blockIdx.y;
  uint16_t* seq_state = state + static_cast<size_t>(d_seq_id[t]) * C * state_len;
  for (int k = 0; k < state_len - 1; ++k)
    seq_state[static_cast<size_t>(c) * state_len + k] =
        seq_state[static_cast<size_t>(c) * state_len + k + 1];
  seq_state[static_cast<size_t>(c) * state_len + state_len - 1] =
      input[static_cast<size_t>(t) * C + c];
}

// PLE short-conv for MTP multi-sequence VERIFY (Phase 2): the packed [T, C]
// input is sequence-major (t = b*T + tt, tt in [0,T), B = T/tokens_per_seq
// sequences). Each token's dilated causal conv reads (a) earlier LOCAL tokens
// of the SAME sequence from the packed input (taps within the current
// sequence) and (b) the per-sequence old_state (taps before the sequence
// start). The single non-negative tap (j == K-1, src == 0) is the CURRENT
// token at packed index t. Mirrors one prefill step of
// DepthwiseConvAddKernel with the state selected by d_seq_id[t]. PLE has no
// checkpoint (it sits at layer 1, before the first linear-attention layer).
__global__ void DepthwiseConvAddMultiSeqCausalKernel(
    const uint16_t* __restrict__ x, const uint16_t* __restrict__ conv1d,
    const uint16_t* __restrict__ state, const uint16_t* __restrict__ gated,
    const uint16_t* __restrict__ trunk_add, uint16_t* __restrict__ out,
    const int* __restrict__ d_seq_id, int T, int Tps, int C, int K,
    int dilation, int state_len, const int* __restrict__ token_local) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= T * C) return;  // T = total packed tokens (grid bound)
  const int t = idx / C;
  const int c = idx % C;
  // Local position within the sequence. Uniform (MTP): t % Tps. Ragged
  // (batched prefill): token_local[t]. `t - tt` is the sequence's packed start
  // offset in both cases, so the tap index `t - (tt - src)` stays correct.
  const int tt = token_local ? token_local[t] : (t % Tps);
  const uint16_t* seq_state =
      state + static_cast<size_t>(d_seq_id[t]) * C * state_len;
  float acc = 0.0f;
  for (int j = 0; j < K; ++j) {
    int src = tt - (K - 1 - j) * dilation;  // local position of the tap
    float xv;
    if (src < 0)
      xv = Bf16ToFloat(seq_state[static_cast<size_t>(c) * state_len +
                                 (src + state_len)]);
    else
      xv = Bf16ToFloat(x[static_cast<size_t>(t - (tt - src)) * C + c]);
    const float w = Bf16ToFloat(conv1d[c * K + j]);
    acc += w * xv;
  }
  const float conv = Bf16ToFloat(FloatToBf16(Silu(acc)));
  const uint16_t ple_out = FloatToBf16(Bf16ToFloat(gated[idx]) + conv);
  if (trunk_add)
    out[idx] = FloatToBf16(Bf16ToFloat(trunk_add[idx]) + Bf16ToFloat(ple_out));
  else
    out[idx] = ple_out;
}

// Save the PLE short-conv state after each of the first `num_ckpt` local
// tokens, for MTP multi-sequence VERIFY rollback (the PLE conv is an in-place
// recurrence, so a partial accept must restore the PLE conv state too — not
// just the linear layers). Layout [max_seq, num_ckpt, C, state_len] (per PLE
// layer). For sequence b's local token tt, the conv state window = the last
// `state_len` gated_n values ending at tt (from the packed input if in-range,
// else the per-sequence old_state). MUST run BEFORE the in-place state update
// (PleConvUpdateStateMultiSeqCausalKernel) so `old_state` is still the
// pre-batch state. Mirrors Conv1dCheckpointMultiSeqKernel with
// state_len = (K-1)*dilation.
__global__ void PleConvCheckpointMultiSeqKernel(
    const uint16_t* __restrict__ input, const uint16_t* __restrict__ old_state,
    uint16_t* __restrict__ ckpt, const int* __restrict__ d_seq_id, int C,
    int state_len, int T, int num_ckpt, int ckpt_stride) {
  const int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= C) return;
  const int z = blockIdx.y;  // = b * num_ckpt + tt
  const int b = z / num_ckpt;
  const int tt = z % num_ckpt;
  const int seq = d_seq_id[b * T];
  const uint16_t* seq_state =
      old_state + static_cast<size_t>(seq) * C * state_len;
  uint16_t* dst = ckpt +
                  ((static_cast<size_t>(seq) * ckpt_stride + tt) * C + c) *
                      state_len;
  for (int k = 0; k < state_len; ++k) {
    const int s = tt - state_len + 1 + k;  // local position (can be negative)
    dst[k] = (s >= 0) ? input[static_cast<size_t>(b * T + s) * C + c]
                      : seq_state[c * state_len + (s + state_len)];
  }
}

// Save the PLE short-conv state after each of the first `num_ckpt` local
// tokens, for SINGLE-SEQUENCE MTP VERIFY rollback. The packed [T, C] input is
// one sequence (packed index == local token index). For local token tt the
// conv state window = the last `state_len` gated_n values ending at tt (from
// the packed input if in-range, else the pre-batch old_state). Layout
// [num_ckpt, C, state_len] (per-layer slice; the sequence offset is applied by
// the caller). MUST run BEFORE the in-place state update
// (PleConvUpdateStateKernel) so `old_state` is still the pre-batch state.
// Mirrors PleConvCheckpointMultiSeqKernel with B = 1.
__global__ void PleConvCheckpointSingleSeqKernel(
    const uint16_t* __restrict__ input, const uint16_t* __restrict__ old_state,
    uint16_t* __restrict__ ckpt, uint16_t* __restrict__ capture, int C,
    int state_len, int num_ckpt) {
  const int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= C) return;
  const int tt = blockIdx.y;  // checkpoint index = local token index
  uint16_t* dst = ckpt + (static_cast<size_t>(tt) * C + c) * state_len;
  for (int k = 0; k < state_len; ++k) {
    const int s = tt - state_len + 1 + k;  // local position (can be negative)
    dst[k] = (s >= 0) ? input[static_cast<size_t>(s) * C + c]
                      : old_state[c * state_len + (s + state_len)];
  }
  // Independent writer-row0 capture (test-only, default null): copy the
  // tt==0 row to a separate buffer, NOT via ckpt.
  if (tt == 0 && capture) {
    for (int k = 0; k < state_len; ++k) capture[c * state_len + k] = dst[k];
  }
}

// Update the PLE short-conv state for MTP multi-sequence VERIFY: the packed
// [T, C] input is sequence-major (t = b*T + tt, T = tokens per sequence).
// After the causal conv, each sequence's conv_state becomes its last
// `state_len` gated_n values (the prefill branch of
// PleConvUpdateStateKernel), selected by d_seq_id[t].
__global__ void PleConvUpdateStateMultiSeqCausalKernel(
    uint16_t* __restrict__ state, const uint16_t* __restrict__ input,
    const int* __restrict__ d_seq_id, int T, int C, int state_len,
    const int* __restrict__ seq_offset) {
  const int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= C) return;
  const int b = blockIdx.y;
  // Sequence b's packed [off, off+len) rows. Uniform (MTP): off=b*T, len=T.
  // Ragged (batched prefill): cu_seqlens seq_offset[b..b+1].
  const int off = seq_offset ? seq_offset[b] : b * T;
  const int len = seq_offset ? (seq_offset[b + 1] - off) : T;
  uint16_t* seq_state =
      state + static_cast<size_t>(d_seq_id[off]) * C * state_len;
  // Slide the window by len: the new window = the last `state_len` gated_n
  // values of (old state + the sequence's len tokens). For local token index
  // src = len - state_len + k: src >= 0 reads the packed input (in-batch), else
  // it reads the OLD state at (src + state_len) (pre-sequence history). This
  // mirrors the single-seq PleConvUpdateStateKernel decode branch (T <
  // state_len slides the window; the in-place read is safe because src+
  // state_len > k and k is ascending). MTP verify has T = k+1 < state_len =
  // (K-1)*dilation, so the slide is the common case.
  for (int k = 0; k < state_len; ++k) {
    const int src = len - state_len + k;  // local token index (can be negative)
    if (src >= 0)
      seq_state[static_cast<size_t>(c) * state_len + k] =
          input[static_cast<size_t>(off + src) * C + c];
    else
      seq_state[static_cast<size_t>(c) * state_len + k] =
          seq_state[static_cast<size_t>(c) * state_len + (src + state_len)];
  }
}

Status CheckGemm(const Bf16GemmResult& r) {
  if (r.status != CUBLAS_STATUS_SUCCESS || !r.has_algo) {
    return Status::Fail(std::string("Bf16Gemm failed (status=") +
                        std::to_string((int)r.status) + ")");
  }
  return Status();
}

// Debug: when Q4T_MLP_DUMP=<tag>, copy the PLE short-conv INPUT (gated_n,
// [T, hc_dim] BF16) and OUTPUT (d_conv, [T, hc_dim] BF16) to
// <tag>.{ple_gated_n,ple_conv_out}.bin. This isolates the PLE conv: if
// ple_gated_n is identical between the batch and incremental paths but
// ple_conv_out diverges, the divergence is the conv's missing left context
// (the C++ DepthwiseConvKernel zero-pads src<0 and has NO persistent state,
// whereas the reference _short_conv keeps a 9-element state via
// update_conv_state). Only the PLE layer calls this, so no layer index.
void DumpPleConv(const uint16_t* gated_n, const uint16_t* conv_out, int T,
                 int hc_dim) {
  const char* e = std::getenv("Q4T_MLP_DUMP");
  if (!e || !*e) return;
  auto w = [&](const char* name, const uint16_t* src) {
    std::string p = std::string(e) + "." + name + ".bin";
    std::vector<uint16_t> h(static_cast<size_t>(T) * hc_dim);
    cudaMemcpy(h.data(), src, h.size() * sizeof(uint16_t),
               cudaMemcpyDeviceToHost);
    FILE* f = std::fopen(p.c_str(), "wb");
    if (f) {
      std::fwrite(h.data(), sizeof(uint16_t), h.size(), f);
      std::fclose(f);
    }
  };
  w("ple_gated_n", gated_n);
  w("ple_conv_out", conv_out);
}

inline size_t AlignUp(size_t n, size_t a) { return (n + a - 1) & ~(a - 1); }

}  // namespace

size_t PleLayerWorkspaceBytes(int T, int hc, int hs) {
  const int hc_dim = hc * hs;
  const size_t hc_bytes = static_cast<size_t>(T) * hc_dim * sizeof(uint16_t);
  const size_t hs_bytes = static_cast<size_t>(T) * hs * sizeof(uint16_t);
  const size_t gate_bytes = static_cast<size_t>(T) * hc * sizeof(uint16_t);
  // Mirror the carve in PleLayerForward exactly (each offset AlignUp(256)).
  size_t off = 0;
  auto carve = [&](size_t bytes) {
    off = AlignUp(off, 256);
    off += bytes;
  };
  carve(hc_bytes);  // key
  carve(hs_bytes);  // value
  carve(hc_bytes);  // key_n
  carve(hc_bytes);  // query_n
  carve(gate_bytes);  // gate
  carve(hc_bytes);  // gated
  carve(hc_bytes);  // gated_n

  carve(kGemmScratch);  // gemm scratch
  return off;
}

void PleLayerWeights::Free() {
  if (key_proj) cudaFree(key_proj);
  if (value_proj) cudaFree(value_proj);
  if (norm_key) cudaFree(norm_key);
  if (norm_query) cudaFree(norm_query);
  if (norm_conv) cudaFree(norm_conv);
  if (conv1d) cudaFree(conv1d);
  key_proj = value_proj = norm_key = norm_query = norm_conv = conv1d = nullptr;
}

Status LoadPleLayer(const io::WeightLoader& loader, const std::string& prefix,
                    int hc_count, int hidden_size, int ple_embed_dim,
                    int conv_kernel, int conv_dilation, float eps,
                    PleLayerWeights* out, cudaStream_t stream) {
  if (hc_count <= 0 || hidden_size <= 0 || ple_embed_dim <= 0 ||
      conv_kernel <= 0) {
    return Status::Fail("invalid PLE dims");
  }
  out->hc_count = hc_count;
  out->hidden_size = hidden_size;
  out->ple_embed_dim = ple_embed_dim;
  out->conv_kernel = conv_kernel;
  out->conv_dilation = conv_dilation;
  out->eps = eps;
  const int hc_dim = hc_count * hidden_size;

  auto alloc = [](uint16_t** p, size_t bytes) -> Status {
    if (cudaMalloc(reinterpret_cast<void**>(p), bytes) != cudaSuccess) {
      return Status::Fail("cudaMalloc failed");
    }
    return Status();
  };
  auto load = [&loader, stream](const std::string& name, uint16_t* dst,
                                size_t bytes) -> Status {
    return loader.LoadTensorToDevice(name, dst, bytes, stream);
  };

  Status s;
  if (!(s = alloc(&out->key_proj,
                  static_cast<size_t>(hc_dim) * ple_embed_dim * sizeof(uint16_t))))
    return s;
  if (!(s = alloc(&out->value_proj,
                  static_cast<size_t>(hidden_size) * ple_embed_dim * sizeof(uint16_t))))
    return s;
  if (!(s = alloc(&out->norm_key, hc_dim * sizeof(uint16_t)))) return s;
  if (!(s = alloc(&out->norm_query, hc_dim * sizeof(uint16_t)))) return s;
  if (!(s = alloc(&out->norm_conv, hc_dim * sizeof(uint16_t)))) return s;
  if (!(s = alloc(&out->conv1d,
                  static_cast<size_t>(hc_dim) * conv_kernel * sizeof(uint16_t))))
    return s;

  if (!(s = load(prefix + ".key_proj.weight", out->key_proj,
                 static_cast<size_t>(hc_dim) * ple_embed_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".value_proj.weight", out->value_proj,
                 static_cast<size_t>(hidden_size) * ple_embed_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".norm_key.weight", out->norm_key,
                 hc_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".norm_query.weight", out->norm_query,
                 hc_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".norm_conv.weight", out->norm_conv,
                 hc_dim * sizeof(uint16_t))))
    return s;
  if (!(s = load(prefix + ".conv1d.weight", out->conv1d,
                 static_cast<size_t>(hc_dim) * conv_kernel * sizeof(uint16_t))))
    return s;
  if (stream != nullptr &&
      cudaStreamSynchronize(stream) != cudaSuccess) {
    return Status::Fail("stream sync failed");
  }
  return Status();
}

Status PleLayerForward(const PleLayerWeights& w, const uint16_t* embeddings,
                       const uint16_t* hyper_input, uint16_t* out, int T,
                       uint16_t* conv_state, void* workspace,
                       size_t workspace_bytes, cudaStream_t stream,
                       const uint16_t* trunk_add, const int* d_seq_id,
                       int tokens_per_seq, uint16_t* conv_ckpt, int num_ckpt,
                       const RaggedBatch* ragged, int ckpt_stride,
                       uint16_t* gated_n_capture,
                       uint16_t* ple_conv_capture) {
  const int hc = w.hc_count, hs = w.hidden_size, pe = w.ple_embed_dim;
  const int hc_dim = hc * hs;
  const int K = w.conv_kernel, dil = w.conv_dilation;
  if (T <= 0) return Status();
  const float inv_sqrt_hs = 1.0f / std::sqrt(static_cast<float>(hs));
  // Ragged (batched-prefill) packing: per-token local position + per-sequence
  // cu_seqlens replace the uniform tokens_per_seq stride (null in the uniform
  // MTP path, keeping the kernels bit-identical).
  const bool multi_causal = d_seq_id && (tokens_per_seq > 1 || ragged);
  const int* rag_offset = ragged ? ragged->seq_offset : nullptr;
  const int* rag_local = ragged ? ragged->token_local : nullptr;

  // Carve the single workspace (256-byte aligned offsets; cuBLASLt requires
  // aligned scratch pointers).
  char* base = static_cast<char*>(workspace);
  size_t off = 0;
  auto carve = [&](size_t bytes) -> char* {
    off = AlignUp(off, 256);
    char* p = base + off;
    off += bytes;
    return p;
  };
  const size_t hc_bytes = static_cast<size_t>(T) * hc_dim * sizeof(uint16_t);
  const size_t hs_bytes = static_cast<size_t>(T) * hs * sizeof(uint16_t);
  const size_t gate_bytes = static_cast<size_t>(T) * hc * sizeof(uint16_t);
  char* d_key = carve(hc_bytes);
  char* d_value = carve(hs_bytes);
  char* d_key_n = carve(hc_bytes);
  char* d_query_n = carve(hc_bytes);
  char* d_gate = carve(gate_bytes);
  char* d_gated = carve(hc_bytes);
  char* d_gated_n = carve(hc_bytes);
  char* d_gemm = carve(kGemmScratch);
  if (off > workspace_bytes) {
    return Status::Fail("PLE workspace too small");
  }

  // 1. key = embeddings @ key_proj^T  [T, pe] x [hc_dim, pe]^T -> [T, hc_dim].
  Status s = CheckGemm(Bf16Gemm(embeddings, w.key_proj,
                                reinterpret_cast<uint16_t*>(d_key), T, hc_dim,
                                pe, 1.0f, 0.0f, d_gemm, kGemmScratch, stream));
  if (!s.ok()) return s;
  // 2. value = embeddings @ value_proj^T  [T, pe] x [hs, pe]^T -> [T, hs].
  s = CheckGemm(Bf16Gemm(embeddings, w.value_proj,
                         reinterpret_cast<uint16_t*>(d_value), T, hs, pe, 1.0f,
                         0.0f, d_gemm, kGemmScratch, stream));
  if (!s.ok()) return s;
  // 3. key_n = GroupedGemmaRMSNorm(key, norm_key) (warp-per-branch).
  GroupedRmsNormKernel<<<T, 32 * hc, 0, stream>>>(
      reinterpret_cast<uint16_t*>(d_key), w.norm_key,
      reinterpret_cast<uint16_t*>(d_key_n), T, hc, hs, w.eps);
  // 4. query_n = GroupedGemmaRMSNorm(hyper_input, norm_query).
  GroupedRmsNormKernel<<<T, 32 * hc, 0, stream>>>(
      hyper_input, w.norm_query, reinterpret_cast<uint16_t*>(d_query_n), T, hc,
      hs, w.eps);
  if (cudaGetLastError() != cudaSuccess) return Status::Fail("ple rmsnorm");
  // 5. gate.
  {
    const int total = T * hc;
    PleGateKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
        reinterpret_cast<uint16_t*>(d_key_n),
        reinterpret_cast<uint16_t*>(d_query_n),
        reinterpret_cast<uint16_t*>(d_gate), T, hc, hs, inv_sqrt_hs);
  }
  // 6. gated_value.
  {
    const int total = T * hc_dim;
    GatedValueKernel<<<(total + kBlock - 1) / kBlock, kBlock, 0, stream>>>(
        reinterpret_cast<uint16_t*>(d_gate),
        reinterpret_cast<uint16_t*>(d_value),
        reinterpret_cast<uint16_t*>(d_gated), T, hc, hs);
  }
  // 7. gated_n = GroupedGemmaRMSNorm(gated_value, norm_conv).
  GroupedRmsNormKernel<<<T, 32 * hc, 0, stream>>>(
      reinterpret_cast<uint16_t*>(d_gated), w.norm_conv,
      reinterpret_cast<uint16_t*>(d_gated_n), T, hc, hs, w.eps);
  if (cudaGetLastError() != cudaSuccess) return Status::Fail("ple rmsnorm2");
  // Test-only writer-row0 capture: copy row 0 of the PLE short-conv INPUT
  // (gated_n) to the caller-owned buffer. Independent reference for the PLE
  // conv checkpoint row-0 window (host-side reconstruction), separate from
  // the checkpoint write path. nullptr in production; the D2D copy does not
  // alter the forward.
  if (gated_n_capture) {
    if (cudaMemcpyAsync(gated_n_capture, d_gated_n,
                        static_cast<size_t>(hc_dim) * sizeof(uint16_t),
                        cudaMemcpyDeviceToDevice, stream) != cudaSuccess) {
      return Status::Fail("gated_n_capture D2D");
    }
  }
  // 8. out = gated_value + silu(depthwise-causal-conv(gated_n)). The dilated
  //    conv (K, dilation) has receptive field (K-1)*dilation, so the
  //    persistent state holds that many gated_n values per channel
  //    (oldest-first). Fused with the old PleAddKernel: the conv result is
  //    added to gated_value in-register (same BF16 round-trip as the old
  //    store-then-read path), so no separate d_conv buffer / launch.
  const int state_len = (K - 1) * dil;
  {
    const int total = T * hc_dim;
    const int blocks = (total + kBlock - 1) / kBlock;
    if (multi_causal) {
      // MTP multi-sequence VERIFY / ragged batched prefill: per-sequence causal
      // conv (sequence-major packed input); taps read earlier local tokens of
      // the same sequence + the per-sequence old_state.
      DepthwiseConvAddMultiSeqCausalKernel<<<blocks, kBlock, 0, stream>>>(
          reinterpret_cast<uint16_t*>(d_gated_n), w.conv1d, conv_state,
          reinterpret_cast<uint16_t*>(d_gated), trunk_add, out, d_seq_id, T,
          tokens_per_seq, hc_dim, K, dil, state_len, rag_local);
      if (cudaGetLastError() != cudaSuccess) return Status::Fail("ple conv");
    } else if (d_seq_id) {
      // B2 multi-sequence decode: each token t uses its own sequence's conv
      // slice (d_seq_id[t]); conv_state is the pooled [max_seq, ...] base.
      DepthwiseConvAddMultiSeqKernel<<<blocks, kBlock, 0, stream>>>(
          reinterpret_cast<uint16_t*>(d_gated_n), w.conv1d, conv_state,
          reinterpret_cast<uint16_t*>(d_gated), trunk_add, out, d_seq_id, T,
          hc_dim, K, dil, state_len);
      if (cudaGetLastError() != cudaSuccess) return Status::Fail("ple conv");
    } else {
      DepthwiseConvAddKernel<<<blocks, kBlock, 0, stream>>>(
          reinterpret_cast<uint16_t*>(d_gated_n), w.conv1d, conv_state,
          reinterpret_cast<uint16_t*>(d_gated), trunk_add, out, T, hc_dim, K,
          dil, state_len);
    }
  }
  // DumpPleConv: when trunk_add is active, `out` is the trunk-corrected value
  // (hyper_input + ple_out), not raw ple_out. The dump is only used for
  // manual E1–E10 debugging (no test/tool reads these files).
  DumpPleConv(reinterpret_cast<uint16_t*>(d_gated_n),
              reinterpret_cast<uint16_t*>(out), T, hc_dim);
  // 8b. Slide the state to the last state_len gated_n values (old + chunk).
  {
    const int blocks = (hc_dim + kBlock - 1) / kBlock;
    if (multi_causal) {
      // MTP multi-sequence VERIFY / ragged batched prefill: per-sequence state
      // update (sequence-major packed input).
      const int B = ragged ? ragged->B : (T / tokens_per_seq);
      // Save the per-token PLE conv checkpoint BEFORE the in-place update so
      // `conv_state` is still the pre-batch state when the checkpoint kernel
      // reads it (a partial accept restores the PLE conv state via D2D). Ragged
      // batched prefill never checkpoints (conv_ckpt == null).
      if (conv_ckpt && num_ckpt > 0) {
        PleConvCheckpointMultiSeqKernel<<<dim3(blocks, B * num_ckpt), kBlock,
                                          0, stream>>>(
            reinterpret_cast<uint16_t*>(d_gated_n), conv_state, conv_ckpt,
            d_seq_id, hc_dim, state_len, tokens_per_seq, num_ckpt,
            ckpt_stride);
        if (cudaGetLastError() != cudaSuccess)
          return Status::Fail("ple conv ckpt");
      }
      PleConvUpdateStateMultiSeqCausalKernel<<<dim3(blocks, B), kBlock, 0,
                                               stream>>>(
          conv_state, reinterpret_cast<uint16_t*>(d_gated_n), d_seq_id,
          tokens_per_seq, hc_dim, state_len, rag_offset);
    } else if (d_seq_id) {
      PleConvUpdateStateMultiSeqKernel<<<dim3(blocks, T), kBlock, 0, stream>>>(
          conv_state, reinterpret_cast<uint16_t*>(d_gated_n), d_seq_id, hc_dim,
          state_len);
    } else {
      // Single-sequence T>1 verify: save the per-token PLE conv checkpoint
      // BEFORE the in-place update (mirrors the multi-seq branch). The
      // checkpoint rows read the pre-update state + packed input; a partial
      // accept restores the PLE conv state via D2D (ModelRestoreCheckpoint).
      if (conv_ckpt && num_ckpt > 0) {
        PleConvCheckpointSingleSeqKernel<<<dim3(blocks, num_ckpt), kBlock,
                                           0, stream>>>(
            reinterpret_cast<uint16_t*>(d_gated_n), conv_state, conv_ckpt,
            ple_conv_capture, hc_dim, state_len, num_ckpt);
        if (cudaGetLastError() != cudaSuccess)
          return Status::Fail("ple conv ckpt");
      }
      PleConvUpdateStateKernel<<<blocks, kBlock, 0, stream>>>(
          conv_state, reinterpret_cast<uint16_t*>(d_gated_n), T, hc_dim,
          state_len);
    }
  }
  if (cudaGetLastError() != cudaSuccess) return Status::Fail("ple kernel");
  return Status();
}

}  // namespace model
}  // namespace q4t

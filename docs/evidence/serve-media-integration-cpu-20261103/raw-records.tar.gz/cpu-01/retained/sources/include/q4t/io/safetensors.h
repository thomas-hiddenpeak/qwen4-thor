// Safetensors reader: mmap-based, zero-copy access to tensor metadata and
// data.
//
// A .safetensors file is laid out as:
//   [ 8-byte little-endian u64: header_len ]
//   [ header_len bytes: JSON header ]
//   [ data: contiguous tensor bytes ]
//
// The JSON header is a map of tensor name -> { "dtype": str, "shape": [..],
// "data_offsets": [start, end] } where data_offsets are byte offsets into the
// data region (which starts right after the header). "__metadata__" (optional)
// is ignored.
//
// This reader mmaps the file read-only, so opening a 10 GB shard costs nothing
// up front; tensor bytes are read on demand (the page cache pages them in).
#pragma once

#include <cuda_runtime.h>

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

#include "q4t/status.h"

namespace q4t {
namespace io {

// Element dtype of a safetensors tensor.
enum class Dtype {
  kF64,
  kF32,
  kF16,
  kBF16,
  kI64,
  kI32,
  kI16,
  kI8,
  kU8,
  kBool,
  kF8E4M3,
  kF8E5M2,
};

// Byte size of one element for a dtype.
size_t DtypeSize(Dtype dtype);

// Parse a safetensors dtype string (e.g. "BF16", "F32", "I64", "F8_E4M3").
// Returns false on an unknown string.
bool ParseDtype(const std::string& s, Dtype* out);

// A tensor's metadata (no data pointer; data is read on demand).
struct TensorInfo {
  std::string name;
  Dtype dtype = Dtype::kF32;
  std::vector<int64_t> shape;
  uint64_t data_start = 0;  // byte offset into the data region
  uint64_t data_end = 0;    // exclusive
  uint64_t numel() const;
  uint64_t byte_size() const;
};

// A read-only, mmap'd .safetensors file.
class SafetensorsFile {
 public:
  // Open and validate integer shapes, disjoint extents and file bounds.
  // Does not read tensor data. On failure *out is null and fd/map are released,
  // including when host allocation throws. Zero-sized tensors are supported.
  static Status Open(const std::string& path, SafetensorsFile** out);
  ~SafetensorsFile();
  SafetensorsFile(const SafetensorsFile&) = delete;
  SafetensorsFile& operator=(const SafetensorsFile&) = delete;

  const std::vector<TensorInfo>& tensors() const;
  // Look up a tensor by name; nullptr if absent.
  const TensorInfo* Find(const std::string& name) const;
  size_t num_tensors() const;

  // Read a tensor's bytes into `dst` (must be at least byte_size()).
  Status ReadTensor(const TensorInfo& t, void* dst) const;
  // Read `length` bytes from the data region starting at `data_start`
  // (TensorInfo::data_start coordinates). One pread covers several adjacent
  // tensors, which the residency loader uses to fetch an expert's
  // down/gate/up weights (or scale blocks) in a single contiguous read.
  Status ReadRange(uint64_t data_start, uint64_t length, void* dst) const;
  // Scatter variant of ReadRange: read `length` bytes (sum of `lens`) from
  // the contiguous data range starting at `data_start` into `count`
  // destination buffers (dsts[i] receives lens[i] bytes, in order). One
  // preadv normally copies the whole range; partial reads and EINTR are
  // retried, and EOF before all bytes are read fails. Zero-length buffers
  // are ignored. Large buffer counts split at the system iovec limit.
  // The residency loader can fetch several adjacent experts' weight (or SF)
  // regions in a single read instead of one pread per expert.
  Status ReadRangev(uint64_t data_start, size_t count,
                    const void* const* dsts, const size_t* lens) const;
  // Read a tensor's bytes into `dst`, then H2D-copy to `device_dst` on
  // `stream` (both must be at least byte_size()).
  // Caller retains both buffers through stream completion, including errors.
  Status ReadTensorToDevice(const TensorInfo& t, void* dst, void* device_dst,
                            cudaStream_t stream) const;

  uint64_t file_size() const;

  // Keep this file's clean page-cache pages on destruction (skip the
  // POSIX_FADV_DONTNEED eviction). Used by tiered MoE residency, where the
  // expert shards are streamed on demand for the model's lifetime and the
  // page cache is the C3 pre-warm tier; evicting a shard's pages when it
  // leaves the open-shard LRU would force every later pread back to NVMe.
  void SetKeepPageCache(bool keep);

 private:
  struct Impl;
  explicit SafetensorsFile(Impl* impl);
  Impl* impl_;
};

}  // namespace io
}  // namespace q4t

// Complete qwen4_exp decoder layer — wires the verified building blocks into
// one layer's forward:
//
//   hyper_input [T, hc*hs]
//     1. [PLE, layer 1 only]  hyper_input += ple(ple_embeddings, hyper_input)
//     2. mixed_attn, attn_frame = GRRead(hyper_input)         [T, hs]
//     3. attn_out = attn_block(mixed_attn)                    linear or full
//     4. combined_a = GRWrite(attn_out, attn_frame)            [T, hc*hs]
//     5. mixed_mlp, mlp_frame = GRRead(combined_a)             [T, hs]
//     6. mlp_out = moe(mixed_mlp)                             [T, hs]
//     7. out = GRWrite(mlp_out, mlp_frame)                     [T, hc*hs]
//
// The layer owns all sub-block weights (attn + MoE + the two Hyper-Connection
// GatedResiduals + optional PLE) and the per-layer persistent caches (linear
// SSM/conv state, full-attention KV + indexer caches). The caller owns the
// device workspace. A common layout determines DecoderLayerWorkspaceBytes
// and the per-submodule offsets; both GRRead calls reuse one normed region.
//
// PLE injection (step 1) is wired for layer 1 (checkpoint `ple_layer_ids = [2]`
// is 1-indexed). The caller passes the gathered n-gram embeddings
// (`ple_embeddings`, [T, ple_embed_dim] BF16) to DecoderLayerForward; when
// non-null and `layer.has_ple`, the PLE correction is added to hyper_input
// before the attention HC mix.
#pragma once

#include <cuda_runtime.h>

#include <cstdint>
#include <string>
#include <vector>

#include "q4t/io/weight_loader.h"
#include "q4t/model/full_attention.h"
#include "q4t/model/hyperconnection.h"
#include "q4t/model/linear_attention.h"
#include "q4t/model/moe.h"
#include "q4t/model/ple_layer.h"
#include "q4t/model/ragged_batch.h"
#include "q4t/quant/moe_residency.h"
#include "q4t/quant/moe_weights.h"
#include "q4t/status.h"

namespace q4t::trace { class RouterCollector; }

namespace q4t {
namespace model {

// Ragged multi-sequence packing (RaggedBatch) is declared in ragged_batch.h.

// One qwen4_exp decoder layer (all 48 layers share this structure; the
// attention block is linear_attention for 36 layers and full_attention for 12).
struct DecoderLayer {
  int layer_id = 0;
  int hs = 2560;
  int hc = 4;
  int hc_dim = 10240;
  int moe_is = 640;  // moe_intermediate_size (arch constant; workspace sizing)
  int topk = 10;  // num_experts_per_tok (MoE router top-k)
  bool is_full_attention = false;  // layer_id % 4 == 3
  bool has_ple = false;  // layer_id + 1 in ple_layer_ids (0-indexed layer 1)

  // Attention block (one of the two, the other's weights stay null).
  LinearAttentionWeights linear;
  FullAttentionWeights full;

  // PLE layer (only loaded for the PLE layer; weights stay null otherwise).
  PleLayerWeights ple;

  // MoE (every layer). In slot mode (moe_residency.Slots() > 0) `routed` is
  // the default-constructed layout and the routed weights live in
  // moe_residency's C-slot pool; forward selects the live layout.
  quant::MoEWeightLayout routed;
  quant::MoEResidency moe_residency;
  MoEExtraWeights mlp;

  // Hyper-Connection GatedResiduals (both use_mix + use_combine).
  HyperConnectionWeights attn_hc;
  HyperConnectionWeights mlp_hc;

  // Per-layer persistent caches (allocated in Load, freed in Free).
  float* ssm_state = nullptr;  // linear: [nv, kd, vd] (FP32, matches reference)
  uint16_t* conv_state = nullptr;  // linear: [in_qkv, conv_k-1]
  uint16_t* ple_conv_state = nullptr;  // ple: [hc*hs, (K-1)*dilation] (BF16)
  uint16_t* kv_cache = nullptr;  // full: paged [n_pages, kKvPageSize, nkv, 2, hd]
  int* page_table = nullptr;  // full: [max_len] logical pos -> physical page
  uint16_t* idx_raw = nullptr;  // full: [max_len, idx_hd]
  uint16_t* idx_comp = nullptr;  // full: [max_len, idx_hd]

  // Max sequence length the full-attention caches are sized for.
  int max_len = 2048;
  // Number of concurrent sequences the recurrent state (ssm/conv/ple_conv)
  // is pooled for. Sequence s uses the s-th slice. 1 = legacy layout.
  int max_seq = 1;
  std::vector<int> seq_capacities;

  void Free();
  // Reset ONE sequence's per-layer state (linear SSM/conv slice, or the full
  // KV/indexer) to zero — prepare to process a fresh sequence from the start.
  // `seq_id` selects the pooled recurrent-state slice (0 = legacy single
  // sequence). Full-attention KV/indexer are pooled over max_seq as well, but
  // the reset zeroes the whole allocation (identity page mapping makes a
  // per-sequence slice reset unsafe while other sequences are live; a fresh
  // sequence always starts at logical position 0 and overwrites its pages).
  // const: only touches device memory, not the object's ownership.
  void ResetState(int seq_id, cudaStream_t stream) const;
};

// Device bytes required for the DecoderLayerForward `workspace` argument for a
// layer of type `is_full_attention` handling up to `T` tokens. `has_ple` adds
// the PLE layer's GEMM scratch + carved intermediates. When `is_full_attention`
// is true, pass the layer's `full` weights so the attention region is sized by
// FullAttentionWorkspaceBytes (exact); otherwise `full` may be null.
size_t DecoderLayerWorkspaceBytes(int T, bool is_full_attention, bool has_ple,
                                  int hs, int E, int moe_is, int shared_is,
                                  int k,
                                  const FullAttentionWeights* full = nullptr,
                                  int lowrank = 320);

// Load one decoder layer's weights from `loader`.
//
//   layer_id : 0-based layer index (determines the attention block type and
//              the checkpoint prefixes)
//   E        : num_experts (512)
//   moe_is   : moe_intermediate_size (640)
//   shared_is: shared_expert_intermediate_size (640)
//   k        : num_experts_per_tok (10)
//   max_len  : full-attention cache length (linear layers ignore it)
//
// Checkpoint prefixes (base = "model.language_model.layers.{layer_id}"):
//   {base}.attn_hyper_connection / {base}.mlp_hyper_connection  (HC)
//   {base}.linear_attn  (linear layers)  or  {base}.self_attn   (full layers)
//   {base}.mlp  (MoE routed + router/shared)
Status LoadDecoderLayer(const io::WeightLoader& loader, int layer_id, int hs,
                        int hc, int lowrank, float eps, int E, int moe_is,
                        int shared_is, int k, int max_len, int max_seq,
                        DecoderLayer* out, cudaStream_t stream,
                        int moe_resident_slots = 0,
                        const std::vector<int>* hot_experts = nullptr,
                        bool hot_protected = false,
                        std::span<const int> seq_capacities = {});

// Run one decoder layer forward for a single sequence (prefill).
//
//   hyper_input    : device [T, hc*hs] uint16 (BF16) — the trunk residual
//   ple_embeddings : device [T, ple_embed_dim] uint16 (BF16) gathered n-gram
//                    embeddings; must be non-null when layer.has_ple
//   out            : device [T, hc*hs] uint16 (BF16) — updated trunk residual
//   positions      : device int [T] logical positions (full attention only;
//                    KV paging, indexer grouping, causal mask)
//   rope_pos       : device int [3, max_len] 3D MRoPE (t,h,w) for RoPE angles
//                    (full attention only; identical rows for pure text)
//   T              : number of tokens
//   workspace      : device scratch (>= DecoderLayerWorkspaceBytes)
// `ssm_ckpt`/`conv_ckpt`/`num_ckpt` (MTP speculative verify, linear layers
// only): if non-null, save the per-token SSM/conv state after each of the
// first `num_ckpt` tokens so a partial accept can restore via D2D. Layout:
// ssm_ckpt = [num_ckpt, nv*kd*vd] f32, conv_ckpt = [num_ckpt, in_qkv*(k-1)] bf16.
Status DecoderLayerForward(const DecoderLayer& layer, const uint16_t* hyper_input,
                           const uint16_t* ple_embeddings, uint16_t* out,
                           const int* positions, const int* rope_pos, int T,
                           void* workspace, size_t workspace_bytes,
                           cudaStream_t stream, float* ssm_ckpt = nullptr,
                           uint16_t* conv_ckpt = nullptr, int num_ckpt = 0,
                           int seq_id = 0, const int* d_seq_id = nullptr,
                           const int* d_rope_pos = nullptr,
                           int tokens_per_seq = 0,
                           uint16_t* ple_conv_ckpt = nullptr,
                           const RaggedBatch* ragged = nullptr,
                           int max_position = -1,
                           trace::RouterCollector* trace = nullptr,
                           int layer_id = -1, int ckpt_stride = 0,
                           float* ssm_capture = nullptr,
                           uint16_t* qkv_raw_capture = nullptr,
                           uint16_t* gated_n_capture = nullptr);
// `max_position`: exact maximum logical position, or -1 for device readback.
// `ple_conv_ckpt` (MTP verify rollback, PLE layer only): when non-null and
// num_ckpt > 0, save the per-token PLE short-conv state after each of the
// first `num_ckpt` (local) tokens — the PLE conv is an in-place recurrence,
// so a partial accept must restore it (layout [max_seq, num_ckpt, C, len],
// indexed by pooled seq id, matching the linear conv checkpoint scheme).
// `tokens_per_seq` (MTP multi-sequence VERIFY, Phase 2): when d_seq_id is
// non-null and tokens_per_seq > 1, the packed [T, ...] rows are sequence-major
// (B = T / tokens_per_seq sequences) and the linear/PLE layers run a
// per-sequence causal chain (prefill semantics); 0 = B2 decode / single-seq.
// `d_rope_pos` (B2 multi-sequence decode): the POOLED 3D MRoPE base
// [max_seq, 3, max_len]. When d_seq_id != null the full-attention kernels
// select the per-token rope slice via d_seq_id from this base, so it must be
// the pooled base (NOT a per-sequence slice). When d_seq_id == null it is
// ignored and `rope_pos` (the per-sequence slice) is used.

}  // namespace model
}  // namespace q4t

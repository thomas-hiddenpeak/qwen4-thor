// BF16 linear layer (y = x * W^T) via cuBLASLt.
//
// The general-purpose BF16 GEMM primitive for the model layer: attention
// projections, hyper-connection mix/combine, shared expert, lm_head, etc.
// (NVFP4 routed experts use q4t::quant::Fp4Gemm instead.)
//
// Weight `W` is stored row-major [N, K] (checkpoint layout: out_features x
// in_features, no bias). The GEMM computes, in cuBLASLt column-major terms,
//   D (col-major [N, M]) = alpha * op(A=W, OP_T) * op(B=x, OP_N) + beta * C
// which is the row-major [M, N] result  y[m, n] = sum_k x[m, k] * W[n, k].
#pragma once

#include <cublasLt.h>

#include <cstdint>
#include <cstdlib>

#include "q4t/model/gemv.h"
#include "q4t/quant/lt_cache.h"

namespace q4t {
namespace model {

// Result of a BF16 GEMM.
struct Bf16GemmResult {
  cublasStatus_t status = CUBLAS_STATUS_SUCCESS;
  bool has_algo = false;
};

// Build (or fetch from cache) the cuBLASLt plan for a BF16 GEMM of shape
// (M, N, K) with the given workspace budget. On a cache miss this creates the
// descriptor + three layouts and runs the heuristic once; on a hit it returns
// the cached plan. The caller must hold LtCacheMutex().
inline quant::LtPlan* GetBf16Plan(int M, int N, int K, size_t workspace_bytes) {
  quant::LtPlanKey key{M, N, K, workspace_bytes};
  quant::LtPlanMap& cache = quant::Bf16PlanCache();
  auto it = cache.find(key);
  if (it != cache.end()) return &it->second;

  cublasLtHandle_t handle = quant::GlobalLtHandle();
  if (handle == nullptr) return nullptr;

  quant::LtPlan plan;
  cublasStatus_t s =
      cublasLtMatmulDescCreate(&plan.op, CUBLAS_COMPUTE_32F, CUDA_R_32F);
  if (s != CUBLAS_STATUS_SUCCESS) return nullptr;
  cublasOperation_t op_w = CUBLAS_OP_T;
  cublasOperation_t op_x = CUBLAS_OP_N;
  cublasLtMatmulDescSetAttribute(plan.op, CUBLASLT_MATMUL_DESC_TRANSA, &op_w,
                                 sizeof(op_w));
  cublasLtMatmulDescSetAttribute(plan.op, CUBLASLT_MATMUL_DESC_TRANSB, &op_x,
                                 sizeof(op_x));

  // A slot = W: col-major [K, N] (ld = K), OP_T -> [N, K].
  cublasLtMatrixLayoutCreate(&plan.la, CUDA_R_16BF, K, N, K);
  // B slot = x: col-major [K, M] (ld = K), OP_N -> [K, M].
  cublasLtMatrixLayoutCreate(&plan.lb, CUDA_R_16BF, K, M, K);
  // C: col-major [N, M] (ld = N) == row-major [M, N].
  cublasLtMatrixLayoutCreate(&plan.lc, CUDA_R_16BF, N, M, N);

  cublasLtMatmulPreference_t pref;
  cublasLtMatmulPreferenceCreate(&pref);
  cublasLtMatmulPreferenceSetAttribute(pref,
                                       CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,
                                       &workspace_bytes, sizeof(workspace_bytes));
  // Disable split-K: for tall-skinny shapes (small M, large K) cuBLASLt picks
  // a split-K algorithm whose splitKreduce_kernel writes out of bounds on
  // SM110a (verified via compute-sanitizer on the router GEMM). Non-split-K
  // algorithms are always correct; split-K is only a perf optimization.
  uint32_t reduction_mask = CUBLASLT_REDUCTION_SCHEME_NONE;
  cublasLtMatmulPreferenceSetAttribute(
      pref, CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK, &reduction_mask,
      sizeof(reduction_mask));
  cublasLtMatmulHeuristicResult_t heur;
  int nres = 0;
  s = cublasLtMatmulAlgoGetHeuristic(handle, plan.op, plan.la, plan.lb, plan.lc,
                                     plan.lc, pref, 1, &heur, &nres);
  cublasLtMatmulPreferenceDestroy(pref);
  if (s != CUBLAS_STATUS_SUCCESS || nres <= 0) {
    // Leave the partially-built plan out of the cache; caller sees has_algo
    // false. Clean up the objects we created.
    cublasLtMatrixLayoutDestroy(plan.la);
    cublasLtMatrixLayoutDestroy(plan.lb);
    cublasLtMatrixLayoutDestroy(plan.lc);
    cublasLtMatmulDescDestroy(plan.op);
    return nullptr;
  }
  plan.algo = heur.algo;
  plan.has_algo = true;
  auto inserted = cache.emplace(key, plan);
  return &inserted.first->second;
}

// y[M, N] = x[M, K] * W[N, K]^T  (BF16 in/out, FP32 accumulate).
//
//   x   : device row-major [M, K] uint16 (BF16)
//   w   : device row-major [N, K] uint16 (BF16)
//   y   : device row-major [M, N] uint16 (BF16), caller-allocated
//   alpha, beta : FP32 scalars (beta typically 0)
//   workspace   : device buffer of at least `workspace_bytes`
//   stream      : CUDA stream
inline Bf16GemmResult Bf16Gemm(const uint16_t* x, const uint16_t* w,
                               uint16_t* y, int M, int N, int K, float alpha,
                               float beta, void* workspace,
                               size_t workspace_bytes, cudaStream_t stream) {
  Bf16GemmResult res;
  // ABLATION (test-only, off by default): force the M=1 path to use the
  // cuBLASLt GEMM (the same kernel family as M>1), so the GEMM is no longer
  // a T-dependence source. Used to confirm whether the M=1 GEMV is the source
  // of the MTP vs plain-greedy divergence (see docs/log/2026-10-10.md).
  // Default runtime behavior is unchanged when the env var is unset.
  const bool ablate_gemv_t1 = std::getenv("Q4T_ABLATE_GEMV_T1") != nullptr;
  // ABLATION (test-only, off by default): force the M=1 path to use the M=4
  // cuBLASLt plan (the same algorithm family the T=4 verify GEMM gets) by
  // padding M=1 to M=4, so the cuBLASLt algorithm selection is no longer a
  // T-dependence source. Used to confirm whether the M=1 vs M=4 GEMM tiling
  // is a source of the MTP vs plain-greedy divergence (see
  // docs/log/2026-10-11.md). Default runtime behavior is unchanged when the
  // env var is unset.
  const bool ablate_gemm_tile = std::getenv("Q4T_ABLATE_GEMM_TILE") != nullptr;
  if (M == 1 && beta == 0.0f && ablate_gemm_tile) {
    uint16_t* x4 = nullptr;
    uint16_t* y4 = nullptr;
    if (cudaMalloc(&x4, sizeof(uint16_t) * 4 * K) != cudaSuccess) return res;
    if (cudaMalloc(&y4, sizeof(uint16_t) * 4 * N) != cudaSuccess) {
      cudaFree(x4);
      return res;
    }
    cudaMemcpyAsync(x4, x, sizeof(uint16_t) * K, cudaMemcpyDeviceToDevice,
                    stream);
    cudaMemsetAsync(x4 + K, 0, sizeof(uint16_t) * 3 * K, stream);
    Bf16GemmResult r4 = Bf16Gemm(x4, w, y4, 4, N, K, alpha, beta, workspace,
                                 workspace_bytes, stream);
    cudaMemcpyAsync(y, y4, sizeof(uint16_t) * N, cudaMemcpyDeviceToDevice,
                    stream);
    cudaStreamSynchronize(stream);
    cudaFree(x4);
    cudaFree(y4);
    return r4;
  }
  // M=1 (decode): dedicated GEMV kernel — reads W at full DRAM bandwidth.
  // beta must be 0 (all call sites use 0).
  if (M == 1 && beta == 0.0f && !ablate_gemv_t1) {
    if (Bf16Gev(x, w, y, N, K, alpha, stream)) {
      res.status = CUBLAS_STATUS_SUCCESS;
      res.has_algo = true;
      return res;
    }
    // Unsupported shape (K % 8 != 0) or launch failure: fall through to
    // the cuBLASLt path.
  }
  // 2 <= M <= 8 (batched decode / MTP verify): hand-written small-M GEMM
  // for the shapes measured to beat cuBLASLt on SM110a (src/model/
  // small_m_gemm.cu, tools/small_m_gemm_v2_bench). beta must be 0 (all call
  // sites use 0). Skipped under the M=1->M=4 cuBLASLt ablation so that
  // ablation keeps forcing the cuBLASLt algorithm family. Unsupported
  // shapes return false and fall through to cuBLASLt below.
  if (M >= 2 && M <= 8 && beta == 0.0f && !ablate_gemm_tile) {
    if (Bf16SmallMGemm(x, w, y, M, N, K, alpha, stream)) {
      res.status = CUBLAS_STATUS_SUCCESS;
      res.has_algo = true;
      return res;
    }
  }
  std::lock_guard<std::mutex> lock(quant::LtCacheMutex());
  quant::LtPlan* plan = GetBf16Plan(M, N, K, workspace_bytes);
  if (plan == nullptr || !plan->has_algo) {
    res.status = CUBLAS_STATUS_NOT_INITIALIZED;
    res.has_algo = false;
    return res;
  }
  res.has_algo = true;
  res.status = cublasLtMatmul(quant::GlobalLtHandle(), plan->op, &alpha, w,
                              plan->la, x, plan->lb, &beta, y, plan->lc, y,
                              plan->lc, &plan->algo, workspace, workspace_bytes,
                              stream);
  return res;
}

// Projection GEMM with an optional FP8 decode shadow. On the M=1 decode path
// (beta 0), when `shadow` is present (Q4T_FP8_PROJ on -> weight was quantized
// at load), the FP8 W8A16 GEMV runs (half the weight bytes, ~2x). Otherwise —
// prefill (M>1), no shadow, or an unsupported shape — this is exactly
// Bf16Gemm. The BF16 weight `w` is still required for those paths, so the FP8
// shadow is purely additive and the BF16/prefill path is bit-identical.
inline Bf16GemmResult ProjGemm(const uint16_t* x, const uint16_t* w,
                               const Fp8Shadow* shadow, uint16_t* y, int M,
                               int N, int K, float alpha, float beta,
                               void* workspace, size_t workspace_bytes,
                               cudaStream_t stream) {
  const bool ablate_gemv_t1 = std::getenv("Q4T_ABLATE_GEMV_T1") != nullptr;
  if (M == 1 && beta == 0.0f && shadow != nullptr && shadow->w != nullptr &&
      !ablate_gemv_t1) {
    if (Fp8Gev(x, *shadow, y, N, K, alpha, stream)) {
      Bf16GemmResult res;
      res.status = CUBLAS_STATUS_SUCCESS;
      res.has_algo = true;
      return res;
    }
    // Unsupported shape / launch failure: fall through to the BF16 path.
  }
  // Batched decode (2 <= M <= kFp8SmallMMax): the hand-written FP8 small-M
  // kernel is memory-bound and beats cuBLASLt BF16; above kFp8SmallMMax the
  // GEMM is compute-bound and cuBLASLt tensor cores win, so keep BF16 there.
  if (M >= 2 && M <= kFp8SmallMMax && beta == 0.0f && shadow != nullptr &&
      shadow->w != nullptr) {
    if (Fp8SmallMGemm(x, *shadow, y, M, N, K, alpha, stream)) {
      Bf16GemmResult res;
      res.status = CUBLAS_STATUS_SUCCESS;
      res.has_algo = true;
      return res;
    }
  }
  return Bf16Gemm(x, w, y, M, N, K, alpha, beta, workspace, workspace_bytes,
                  stream);
}

}  // namespace model
}  // namespace q4t

// Complete qwen4_exp model — orchestrates the head, the 48 decoder layers,
// and the PLE SSD-stream embedding into one forward pass.
//
// Forward (prefill of a fresh sequence, positions 0..T-1):
//   1. emb   = head.EmbedLookup(input_ids)          [T, hs]
//   2. trunk = head.ExpandTrunk(emb)                [T, hc*hs] (hc identical)
//   3. for l in [0, num_layers):
//        [if layers[l].has_ple] ple_emb = PleEmbedding::Gather(ids, history)
//                                 * weight_scale                       [T, pe]
//        trunk = DecoderLayerForward(layers[l], trunk, ple_emb, ...)
//   4. logits = head.HeadForward(trunk)             [T, vocab]
//
// The model owns all device weights (head + per-layer attn/MoE/HC/PLE) and the
// PLE embedding (io_uring SSD reader). Weights total ~84 GB (69 GB NVFP4 MoE +
// 15 GB BF16) and fit in the Thor's 128 GB unified memory. The 51 GB PLE table
// stays on NVMe and is streamed per-token by the PLE embedding.
#pragma once

#include "q4t/runtime/sequence_capacity.h"

#include <cuda_runtime.h>

#include <array>
#include <cstdint>
#include <string>
#include <vector>

#include "q4t/io/weight_loader.h"
#include "q4t/model/decoder_layer.h"
#include "q4t/model/decode_metadata_upload.h"
#include "q4t/model/metadata_upload_batch.h"
#include "q4t/model/model_head.h"
#include "q4t/model/sequence.h"
#include "q4t/ple/ngram_hash.h"
#include "q4t/ple/ple_embedding.h"
#include "q4t/status.h"

namespace q4t::trace { class RouterCollector; }

namespace q4t {
namespace model {

// Single-sequence head rows. kLastRow writes [1, vocab] at logits start;
// nullptr skips head. trunk_out always keeps all [T, hc*hs] rows.
enum class LogitsRows { kAllRows, kLastRow };

// Packed prefill output order follows the input sequence order, not slot IDs.
enum class PrefillBatchLogitsRows { kAllRows, kSequenceLastRows };

// Static configuration of the model (all from config.json / the checkpoint).
struct ModelConfig {
  std::string model_dir;
  std::string index_path;
  int num_layers = 48;  // load layers [0, num_layers)
  int hs = 2560;
  int hc = 4;
  int lowrank = 320;
  int E = 512;
  int moe_is = 640;
  int shared_is = 640;
  int topk = 10;
  int vocab = 248320;
  int image_token_id = 248056;  // <image> placeholder (vision feature injection)
  int video_token_id = 248057;  // <video> placeholder (vision feature injection)
  int spatial_merge_size = 2;  // vision merger block size (3D MRoPE grid)
  // full-attention cache length. Sized to the kernel cap (kMaxT=8192 in
  // full_attention.cu) and ple_capacity_tokens, so the QSA sparse path
  // (active once context > indexer_budget) is reachable during decode.
  int max_len = 8192;
  int max_prefill = runtime::kDefaultMaxPrefill;  // Forward workspace rows.
  // Number of concurrent sequences the per-layer recurrent state (linear
  // SSM/conv, PLE conv) is pooled for. Each sequence owns an independent
  // state slice [seq_id, ...], enabling multi-request continuous batching
  // (Phase 2). 1 = legacy single-sequence behavior (bit-identical).
  int max_seq = 1;
  std::vector<int> seq_capacities;  // Empty keeps uniform slot capacity.
  int Capacity(int seq) const {
    return runtime::SequenceCapacity(seq_capacities, seq, max_len);
  }
  float eps = 1e-6f;

  // Tiered expert residency: C resident slots per MoE layer (0 = all E
  // experts resident, the bit-identical baseline path).
  int moe_resident_slots = 0;
  // Optional per-layer static hot list JSON (layer id -> expert id array).
  std::string moe_hot_list;
  // Protect hot-list experts from LRU eviction (dynamic capacity C - hot).
  bool moe_hot_protect = false;

  // PLE SSD stream (the core differentiator).
  std::string ple_sidecar;  // path to the 51 GB FP8 n-gram table
  int64_t ple_total_rows = 320001536;
  size_t ple_row_bytes = 160;
  int ple_capacity_tokens = 8192;
  int64_t eos_token_id = 248044;
  int ple_ngram_size = 3;
  int ple_heads_per_ngram = 8;
};

// The full model: head + decoder layers + PLE embedding + persistent buffers.
struct Model {
  // Optional observer, borrowed from serve; never controls execution.
  trace::RouterCollector* router_trace = nullptr;
  // Owned weight loader. Kept alive for the model's lifetime only when
  // tiered MoE residency is enabled (moe_resident_slots > 0): on-demand
  // expert loads stream shards from NVMe after startup, so the borrowed
  // pointers held by each layer's MoEResidency must outlive LoadModel.
  // Released (reset) at the end of LoadModel when residency is disabled,
  // preserving the baseline path exactly. The loader borrows the index, so
  // both must outlive the model together.
  std::unique_ptr<io::WeightIndex> weight_index;
  std::unique_ptr<io::WeightLoader> weight_loader;
  ModelConfig cfg;
  ModelHeadWeights head;
  std::vector<DecoderLayer> layers;  // size = cfg.num_layers
  ple::PleEmbedding* ple_emb = nullptr;  // null if no PLE layer in range
  ple::NgramHashParams ple_hash;
  float ple_weight_scale = 1.0f;

  // Upload-source ownership only; consumers still use the existing scratch.
  std::unique_ptr<DecodeMetadataUpload> decode_metadata_upload;
  std::unique_ptr<MetadataUploadBatch> metadata_upload;

  // Persistent device buffers (allocated in LoadModel, freed in Free).
  int32_t* d_ids = nullptr;  // [max_prefill]
  int* d_positions = nullptr;  // [max_prefill] logical positions (KV paging,
                               // indexer grouping, causal mask)
  int* d_seq_id = nullptr;  // [max_seq] B2 multi-seq decode: per-token
                            // pooled-state slice index (H2D per forward)
  int* d_token_seq_id = nullptr;  // [max_prefill] Phase 2 MTP multi-seq verify:
                                  // per-token seq id for the B*T packed tokens
  // Ragged batched prefill (Phase 2): pack B variable-length prompts into one
  // forward. d_ragged_seq_offset = [max_seq+1] cu_seqlens, d_ragged_token_local
  // = [max_prefill] per-token local position. Filled per ModelPrefillBatch;
  // null in every other forward (uniform path, bit-identical).
  int* d_ragged_seq_offset = nullptr;  // [max_seq + 1]
  int* d_ragged_token_local = nullptr;  // [max_prefill]
  int* d_rope_pos = nullptr;  // [max_seq, 3, max_len] 3D MRoPE (t, h, w)
  // mrope_position_delta per sequence: during incremental decode the 3 rope
  // rows for a token at logical position p are all (p + rope_delta[seq_id]).
  // Computed at prefill (mutable so it can be written through a const Model&
  // in RunPrefill). Sized to cfg.max_seq in LoadModel.
  mutable std::vector<int> rope_delta;
  uint16_t* d_emb = nullptr;  // [max_prefill, hs]
  uint16_t* d_trunk = nullptr;  // [max_prefill, hc*hs] (ping)
  uint16_t* d_trunk2 = nullptr;  // [max_prefill, hc*hs] (pong)
  uint16_t* d_ple_emb = nullptr;  // [max_prefill, ple_embed_dim]
  int* d_img_pos = nullptr;  // [max_prefill] image-token positions (device)
  void* d_ws = nullptr;  // forward workspace (reused across layers)
  size_t ws_bytes = 0;

  // MTP speculative-verify checkpoints (lazy-allocated by
  // ModelReserveVerifyCheckpoints): per-linear-layer per-token SSM/conv state,
  // so a partial accept restores the accepted-prefix boundary via D2D instead
  // of re-running the forward. POOLED over max_seq sequences (Phase 2 MTP
  // multi-seq verify). Writers and readers use the reserved cap as stride:
  // [num_layers, max_seq, cap, elems]. verify_ckpt_rows bounds valid rows
  // without changing that physical layout. The PLE
  // conv state is an in-place recurrence too, so a partial accept must restore
  // it (the single-seq path historically missed this — see LOG 2026-09-13).
  float* d_verify_ssm_ckpt = nullptr;
  uint16_t* d_verify_conv_ckpt = nullptr;
  uint16_t* d_verify_ple_conv_ckpt = nullptr;
  int verify_ckpt_cap = 0;
  // Only slots written by the most recent successful checkpointed forward
  // are restorable. Any new layer forward/reset invalidates these records.
  mutable int verify_ckpt_rows = 0;
  mutable std::vector<int> verify_ckpt_slots;

  int hc_dim() const { return cfg.hc * cfg.hs; }
  void Free();
};

// Load the PLE n-gram hash params + weight_scale from the checkpoint tensors
//   {ple_prefix}.ple_embedding.layer_multipliers           I64 [ngram_size]
//   {ple_prefix}.ple_embedding.ngram_heads_vocab_sizes     I64 [ngram_heads]
//   {ple_prefix}.ple_embedding.ngram_heads_offsets         I64 [ngram_heads]
//   {ple_prefix}.ple_embedding.ngram_embedding.weight_scale BF16 [1]
Status LoadPleHashParams(const io::WeightLoader& loader,
                         const std::string& ple_prefix,
                         ple::NgramHashParams* out, float* weight_scale,
                         cudaStream_t stream);

// Load the full model (head + cfg.num_layers decoder layers + PLE embedding).
// On success the caller owns all device memory (free with Model::Free).
Status LoadModel(const ModelConfig& cfg, Model* out, cudaStream_t stream);

// Vision features for multimodal prefill (see ModelForward / ModelPrefill).
//
// The vision tower (q4t_vision) emits [num_image_tokens, hs] BF16 features,
// one row per <image> placeholder token, in spatial order. Injection mirrors
// vllm's `_merge_multimodal_embeddings`: every input_ids position equal to
// cfg.image_token_id is overwritten in the embedding buffer with the next
// feature row (the i-th image token takes feature row i). `num_tokens` must
// equal the number of image_token_id occurrences in input_ids.
struct VisionFeatures {
  const uint16_t* device = nullptr;  // [num_tokens, hs] device BF16
  int num_tokens = 0;
  // Per vision item (in prompt position order) the ViT grid (t, h, w) in
  // PATCH units (grid_t, grid_h, grid_w). Used to compute the 3D MRoPE
  // positions for the expanded image/video tokens. Empty = text-only (or the
  // caller does not need 3D positions). One entry per image_token_id /
  // video_token_id placeholder, in the same left-to-right order as the
  // feature rows.
  std::vector<std::array<int, 3>> grids;
};

// Expand image placeholders for multimodal prefill.
//
// The chat template renders each image as a single <image> token
// (image_token_id). The vision tower, however, emits `grid_h/merge *
// grid_w/merge` merged feature rows per image, so each placeholder must be
// expanded to that many image_token_id entries (the injection then overwrites
// them in order). `counts[i]` is the expansion factor for the i-th image.
// Returns false if the number of image_token_id occurrences in `ids` does not
// match `counts.size()` (a placeholder without an image, or vice versa).
inline bool ExpandImageTokens(const int32_t* ids, int T, int image_token_id,
                              const std::vector<int>& counts,
                              std::vector<int32_t>* out) {
  out->clear();
  out->reserve(static_cast<size_t>(T) +
               static_cast<size_t>(counts.size()));
  size_t img_idx = 0;
  for (int i = 0; i < T; ++i) {
    if (ids[i] == image_token_id) {
      if (img_idx >= counts.size()) return false;
      const int c = counts[img_idx];
      if (c <= 0) return false;
      for (int k = 0; k < c; ++k) out->push_back(image_token_id);
      ++img_idx;
    } else {
      out->push_back(ids[i]);
    }
  }
  return img_idx == counts.size();
}

// Expand BOTH image and video placeholders in a single pass. Each
// image_token_id occurrence expands by the next image_count, each
// video_token_id occurrence by the next video_count (independent counters,
// left-to-right). Returns false if a placeholder has no matching count, or if
// any count is left unconsumed.
inline bool ExpandMultimodalTokens(
    const int32_t* ids, int T, int image_token_id, int video_token_id,
    const std::vector<int>& image_counts, const std::vector<int>& video_counts,
    std::vector<int32_t>* out) {
  out->clear();
  out->reserve(static_cast<size_t>(T) + image_counts.size() +
               video_counts.size());
  size_t img_idx = 0, vid_idx = 0;
  for (int i = 0; i < T; ++i) {
    if (ids[i] == image_token_id) {
      if (img_idx >= image_counts.size()) return false;
      const int c = image_counts[img_idx];
      if (c <= 0) return false;
      for (int k = 0; k < c; ++k) out->push_back(image_token_id);
      ++img_idx;
    } else if (ids[i] == video_token_id) {
      if (vid_idx >= video_counts.size()) return false;
      const int c = video_counts[vid_idx];
      if (c <= 0) return false;
      for (int k = 0; k < c; ++k) out->push_back(video_token_id);
      ++vid_idx;
    } else {
      out->push_back(ids[i]);
    }
  }
  return img_idx == image_counts.size() && vid_idx == video_counts.size();
}

// Run one prefill forward: input_ids [T] (host int32) -> logits [T, vocab]
// (device BF16). T must be <= cfg.max_prefill. Prefill starts from empty
// per-layer state (positions 0..T-1).
//
// `vision` (optional): if non-null and vision->num_tokens > 0, the image
// token embeddings are replaced with the vision features (see
// VisionFeatures). Null = pure-text prefill.
Status ModelForward(const Model& m, const int32_t* input_ids, int T,
                    uint16_t* logits, cudaStream_t stream,
                    const VisionFeatures* vision = nullptr, int seq_id = 0);

// Run one decode step for a single new token: token_id at absolute position
// `position` -> logits [1, vocab] (device BF16). Per-layer state is NOT reset
// (it continues from the prior steps, so call ModelForward first for the
// prompt). `history` is the host int32 array of the tokens already generated
// before this one (prompt + previously decoded tokens), length >= position;
// it supplies the PLE n-gram context for the new token.
//
// `trunk_out` (MTP scheme A hook, optional): if non-null, the pre-final-mixer
// multi stream [T, hc*hs] (device BF16, row-major) is copied here — the trunk
// after the last decoder layer, before hyper_connection_mixer. This is the
// input the MTP draft model consumes as `hidden_states` (see
// reference/vllm/vllm/models/qwen4_exp/nvidia/mtp.py). Null = not exposed.
Status ModelDecodeStep(const Model& m, int32_t token_id, int position,
                       const int32_t* history, uint16_t* logits,
                       cudaStream_t stream, uint16_t* trunk_out = nullptr,
                       int seq_id = 0);

// Batched decode over T tokens at absolute positions [base_position ..
// base_position+T-1] WITHOUT resetting per-layer state (continues from the
// current KV/SSM/conv). Returns [T, vocab] logits (and optionally [T, hc*hs]
// trunk_out). This lets MTP verify k+1 speculative tokens in ONE bandwidth-
// bound forward (weights read once) instead of k+1 separate T=1 decodes.
// `history` (length `history_len`) supplies the PLE n-gram context for the
// positions before `base_position`; the in-batch prefix supplies the rest.
// The caller owns logits (T*vocab, or vocab for kLastRow) and
// trunk_out (T*hc*hs); selecting logits rows never shortens trunk_out.
// save_checkpoints requires at least T-1 reserved rows and saves complete
// SSM/conv/PLE state for the selected sequence.
Status ModelDecodeBatch(const Model& m, const int32_t* input_ids, int T,
                        int base_position, const int32_t* history,
                        int history_len, uint16_t* logits, cudaStream_t stream,
                        uint16_t* trunk_out = nullptr,
                        bool save_checkpoints = false, int seq_id = 0,
                        LogitsRows logits_rows = LogitsRows::kAllRows,
                        float** ssm_captures = nullptr,
                        uint16_t** qkv_raw_captures = nullptr,
                        uint16_t** gated_n_captures = nullptr);

// B2 continuous batching: decode ONE token for each of B sequences in a SINGLE
// packed forward (T = B). This is the bandwidth win — the 84 GB of weights is
// read ONCE for all B tokens instead of B times (each GEMM is stateless and
// operates on the packed [B, ...] rows; the recurrent state is selected
// per-token via d_seq_id).
//
//   tokens   : host int32 [B] — the next decode token of each sequence
//   positions: host int [B]   — the absolute position of each token
//   seq_ids  : host int [B]   — the pooled-state slice index of each token
//   history  : host int32 [B * (ngram_size-1)] — per-token PLE n-gram context
//              (oldest first, EOS-filled before the sequence start), one row
//              per token in the same order as `tokens`
//   logits   : device BF16 [B, vocab] (caller-owned)
//
// B must be positive and <= both cfg.max_seq and cfg.max_prefill. Packed
// token scratch is sized by max_prefill, independently of the slot pool.
//
// Per-sequence state (linear SSM/conv, PLE conv, full KV/indexer, 3D MRoPE)
// is isolated by seq_ids[t]; each token continues its own sequence's
// recurrent state from the prior step. The caller must have already run
// ModelPrefill (or a prior ModelDecodeBatchMulti) for each sequence. Returns
// [B, vocab] logits; row t is the logits for token t.
Status ModelDecodeBatchMulti(const Model& m, const int32_t* tokens,
                             const int* positions, const int* seq_ids,
                             const int32_t* history, int B, uint16_t* logits,
                             cudaStream_t stream,
                             uint16_t* trunk_out = nullptr);

// Reserve per-linear-layer per-token SSM/conv/PLE-conv checkpoint buffers for
// MTP verify (idempotent; grows if num_ckpt exceeds the current capacity).
// Allocation is pooled over m.cfg.max_seq with reserved capacity as stride.
// Only rows/slots written by the last successful verify are restorable.
// Call before ModelVerifyMulti or ModelDecodeBatch(save_checkpoints=true).
// Both paths save PLE recurrent state for partial acceptance.
Status ModelReserveVerifyCheckpoints(Model& m, int num_ckpt);

// Restore every linear layer's SSM/conv state AND the PLE layer's conv state
// from checkpoint `ckpt_idx` for sequence `seq_id` (D2D). Used after a
// partial-accept MTP verify to roll the recurrent state back to the
// accepted-prefix boundary WITHOUT re-running the forward. (The PLE conv
// restore fixes a pre-existing gap: the single-seq path only restored the
// linear layers, leaving the PLE short-conv window polluted with rejected
// tokens after a partial accept.)
// Rejects unwritten rows/slots and checkpoints invalidated by another model
// forward, state reset, or allocation growth. Repeated restores are allowed
// while that checkpoint set remains current.
Status ModelRestoreCheckpoint(const Model& m, int ckpt_idx, cudaStream_t stream,
                              int seq_id = 0);

// MTP multi-sequence VERIFY (Phase 2): verify k+1 speculative tokens for each
// of B sequences in ONE packed forward (T = B * tokens_per_seq, sequence-major
// rows). This is the multi-sequence analogue of ModelDecodeBatch(save_
// checkpoints=true): the GEMMs (HC/MoE/head/proj) are stateless and operate on
// the packed rows (weights read once); the linear/PLE layers run a per-
// sequence causal chain (prefill semantics, tokens_per_seq > 1) with the
// recurrent state selected per-sequence via d_seq_id; the full-attention layers
// use the per-seq paged KV (B2a d_seq_id kernels). Per-sequence per-token
// checkpoints are saved so a partial accept can restore each sequence's state
// to its accepted-prefix boundary via ModelRestoreCheckpoint(m, a_i, stream,
// seq_id).
// ModelVerifyMulti owns its upload sources through checked stream completion.
// After submission, all Status exits wait before local host buffers expire;
// checkpoint rows become valid only after a successfully completed forward.
//
//   tokens        : host int32 [B * T] — sequence-major (seq 0's T tokens,
//                   then seq 1's, ...). Row b*T+t is sequence b's (t+1)-th
//                   verify token (bonus + k drafts).
//   base_positions: host int [B] — the absolute position of sequence b's FIRST
//                   verify token (row b*T). Row b*T+t is at base_positions[b]+t.
//   seq_ids       : host int [B] — the pooled-state slice index of sequence b
//                   (written to d_seq_id[b*T .. b*T+T-1]).
//   history       : host int32 [B * history_len] — per-sequence PLE n-gram
//                   context for positions before base_positions[b] (oldest
//                   first), one row per sequence.
//   logits        : device BF16 [B*T, vocab] (out) — row b*T+t is the logits
//                   for sequence b's (t+1)-th verify token.
//   stream        : CUDA stream.
//   trunk_out     : optional device BF16 [B*T, hc*hs] (out) — the pre-final-
//                   mixer multi stream (MTP extend input), sequence-major.
//
// The caller must have already run ModelPrefill (or a prior verify) for each
// sequence so the per-seq recurrent state is at base_positions[b]-1. Returns
// [B*T, vocab] logits; the caller argmaxes row b*T+t to get the main model's
// prediction for sequence b's (t+1)-th token and compares against its draft.
Status ModelVerifyMulti(const Model& m, const int32_t* tokens,
                        const int* base_positions, const int* seq_ids,
                        const int32_t* history, int history_len, int B,
                        int tokens_per_seq, uint16_t* logits,
                        cudaStream_t stream, uint16_t* trunk_out = nullptr);

// Ragged batched prefill (Phase 2): prefill B FRESH, variable-length sequences
// in ONE packed forward so the dense weights are read once for the whole batch
// (the serve win when several requests prefill together). Unlike ModelVerify-
// Multi (uniform tokens_per_seq), the sequences may have different lengths; the
// per-sequence causal linear/PLE chains are driven by cu_seqlens + per-token
// local positions (the RaggedBatch descriptor). Each sequence's per-layer state
// is RESET first (fresh prefill from position 0), so the caller must NOT have
// begun these sequences. Pure text only (no vision).
//
//   tokens  : host int32 [Ttot] — sequence-major concatenation of the B prompts
//             (seq 0's lens[0] tokens, then seq 1's, ...); Ttot = sum(lens).
//   lens    : host int [B] — prompt length of each sequence (>0, <= max_len).
//   seq_ids : host int [B] — the pooled-state slice index each sequence fills.
//   logits  : device BF16 [Ttot, vocab] (out) — row seq_offset[b]+t is sequence
//             b's token t (seq_offset = prefix sum of lens). The caller reads
//             row seq_offset[b+1]-1 for sequence b's next-token distribution.
//   stream  : CUDA stream.
//   logits_rows: kAllRows preserves the packed output above;
//             kSequenceLastRows writes [B, vocab], row b for sequence b.
//
// After the call each sequence's per-layer recurrent state (linear SSM/conv,
// PLE conv, full KV/indexer, 3D MRoPE) is at position lens[b]-1, ready for
// incremental decode (ModelDecodeBatchMulti) — identical to B independent
// ModelPrefill calls, but with the weights swept once.
Status ModelPrefillBatch(const Model& m, const int32_t* tokens,
                         const int* lens, const int* seq_ids, int B,
                         uint16_t* logits, cudaStream_t stream,
                         PrefillBatchLogitsRows logits_rows =
                             PrefillBatchLogitsRows::kAllRows);

// Fused mixed prefill+decode batch (aggregated continuous batching): process B
// sequences in ONE packed forward where each sequence is EITHER a fresh prefill
// chunk (base_position 0 -> its per-layer state is reset) OR a continuing
// decode/prefill chunk (base_position > 0 -> state kept). The dense weights are
// read ONCE for the whole batch, so concurrent decode tokens "ride" a prefill
// chunk's weight sweep instead of paying a second one — the vLLM continuous-
// batching win. This is ADDITIVE: ModelPrefillBatch (prefill-only) and
// ModelDecodeBatchMulti (decode-only) remain the PD-disaggregation operations;
// the fused path is only used when prefill and decode are co-located.
//
//   tokens        : host int32 [Ttot] — sequence-major concatenation (Ttot =
//                   sum(lens)).
//   lens          : host int [B] — token count of each sequence (prefill chunk
//                   size, or 1 for a decode step). > 0.
//   seq_ids       : host int [B] — the pooled recurrent-state slice each fills.
//   base_positions: host int [B] — absolute position of each sequence's first
//                   token (0 = fresh sequence start -> state reset; > 0 =
//                   continue from the existing state).
//   prior_history : host int32 [B * (ngram_size-1)] — the ngram_size-1 tokens
//                   BEFORE base_positions[b] for each sequence (oldest first,
//                   EOS-filled for a fresh sequence). Supplies the PLE n-gram
//                   context for positions before this batch's tokens.
//   logits        : device BF16 [Ttot, vocab] (out) — row seq_offset[b]+t is
//                   sequence b's token t (seq_offset = prefix sum of lens).
//
// With all base_positions == 0 and EOS prior_history this is bit-identical to
// ModelPrefillBatch. A len-1 continuing sequence matches ModelDecodeBatchMulti
// to within the causal-vs-decode-kernel rounding (same math, different float
// order), like the existing batched-prefill acceptance.
Status ModelMixedBatch(const Model& m, const int32_t* tokens, const int* lens,
                       const int* seq_ids, const int* base_positions,
                       const int32_t* prior_history, int B, uint16_t* logits,
                       cudaStream_t stream);

// ---------------------------------------------------------------------------
// Sequence APIs wait for checked GPU completion by default. kDeferred leaves
// position/history committed at the old prefix and retains a pending advance.
// The caller must complete it (including failures) under scratch ownership,
// using ModelCompleteSequence or CompleteSequenceWork with a checked GPU wait.
// Low-level packed APIs do not own host cursors; their caller uses the SAME
// ModelSequence Submit/CompleteSequenceWork contract for all packed sequences.
Status ModelCompleteSequence(ModelSequence* seq, cudaStream_t stream,
                             const Status& submitted = Status());

// 重置 per-layer 状态 (KV/SSM/conv 清零), 序列进入 kPrefill 阶段。
// 等价于 ModelForward 内部的 ResetState 循环。`seq_id` 选择池化的 recurrent
// 状态切片 (0 = 旧单序列布局), 并记入 seq->seq_id 供后续 Prefill/Decode 使用。
Status ModelBeginSequence(const Model& m, ModelSequence* seq,
                          cudaStream_t stream, int seq_id = 0);

// 完成 prefill: seq 须处于 kPrefill 阶段。input_ids [T] -> logits [T, vocab]
// (device BF16)。成功后阶段 = kDecode, position = T, history = prompt。
// 默认等待GPU完成；kDeferred仅入队，须显式完成后才可交接。
// trunk_out: 可选, 非 null 时把 pre-final-mixer 多流 [T, hc*hs] 拷入
// (MTP scheme A 钩子, 见 ModelDecodeStep 的说明)。
// vision: 可选, 非 null 且 num_tokens>0 时把 image token 的 embedding 替换为
// 视觉特征 (见 VisionFeatures)。
// seq_id=-1 uses seq->seq_id; an explicit different slot is rejected.
Status ModelPrefill(const Model& m, ModelSequence* seq, const int32_t* input_ids,
                    int T, uint16_t* logits, cudaStream_t stream,
                    uint16_t* trunk_out = nullptr,
                    const VisionFeatures* vision = nullptr, int seq_id = -1,
                    LogitsRows logits_rows = LogitsRows::kAllRows,
                    SequenceCompletion completion = SequenceCompletion::kWait);

// Submit a chunk from the committed prefix. kDeferred requires completion
// before the next chunk or reuse. The final chunk transitions to kDecode only
// after successful completion. Failed execution requires reset before reuse.
// kLastRow affects logits only, not the optional complete trunk output.
Status ModelPrefillTextChunk(const Model& m, ModelSequence* seq,
                            const int32_t* prompt, int prompt_length,
                            int chunk_length, uint16_t* logits,
                            cudaStream_t stream,
                            uint16_t* trunk_out = nullptr,
                            LogitsRows logits_rows = LogitsRows::kAllRows,
                            SequenceCompletion completion =
                                SequenceCompletion::kWait);

// 一个 decode step: seq 须处于 kDecode 阶段。token_id 写入 position,
// -> logits [1, vocab]。自动 ++position 并追加 history (PLE 上下文)。
// 等价于 ModelDecodeStep (history 由 seq 内部维护)。trunk_out 同上。
// seq_id=-1 uses seq->seq_id; an explicit different slot is rejected.
Status ModelDecodeStepSeq(const Model& m, ModelSequence* seq, int32_t token_id,
                          uint16_t* logits, cudaStream_t stream,
                          uint16_t* trunk_out = nullptr, int seq_id = -1,
                          SequenceCompletion completion =
                              SequenceCompletion::kWait);

// 序列结束: 状态机复位为 kIdle (不释放 device 内存, 内存归 Model 所有)。
// Refuses to discard pending work; callers must finish it first.
Status ModelEndSequence(ModelSequence* seq);

// ---------------------------------------------------------------------------
// 主模型 recurrent 状态快照 (推测解码回滚用)。
//
// 主模型的 per-layer 状态分两类:
//   - paged (full-attention KV + indexer): 按绝对 position 写入, 单调增长。
//     推测解码重跑同一 position 会覆盖同一 page, 无需回滚。
//   - recurrent (linear SSM/conv, PLE conv): 原地递推, 无法按 position 回退。
//     推测解码验证 k 个 draft token 后若只接受 a<k 个, 必须回滚到验证前的
//     recurrent 状态再重跑 a 个 token。
//
// ModelStateSnapshot 只持有 recurrent 状态 (paged 状态不动)。
struct ModelStateSnapshot {
  std::vector<uint8_t> data;  // 所有 recurrent 状态拼接
  size_t bytes = 0;
  bool valid = false;
  void Free();
};

// 所有 recurrent 状态的 device 字节数 (SSM FP32 + conv BF16 + PLE conv BF16)。
size_t ModelStateSnapshotBytes(const Model& m);

// 快照当前 recurrent 状态 (device -> host)。验证前调用。
Status ModelSnapshotState(const Model& m, ModelStateSnapshot* snap,
                          cudaStream_t stream);

// 恢复 recurrent 状态 (host -> device)。验证后回滚调用。
Status ModelRestoreState(const Model& m, const ModelStateSnapshot& snap,
                         cudaStream_t stream);

// Test-only: read the verify checkpoint buffers (ssm/conv/ple_conv) for a
// given ckpt_idx into a host snapshot, in the same order as
// ModelSnapshotState. Lets a test directly compare checkpoint-N against the
// T=1 recurrent state without going through ModelRestoreCheckpoint.
Status ModelSnapshotCheckpoint(const Model& m, int ckpt_idx,
                               ModelStateSnapshot* snap, cudaStream_t stream,
                               int seq_id = 0);

// Aggregate per-layer MoE residency counters (all-zero when tiered
// residency is disabled, i.e. every layer has Slots() == 0).
inline quant::MoEResidency::Stats SumResidencyStats(const Model& m) {
  quant::MoEResidency::Stats total;
  for (const auto& layer : m.layers) {
    const auto& s = layer.moe_residency.GetStats();
    total.resolve_calls += s.resolve_calls;
    total.expert_lookups += s.expert_lookups;
    total.hits += s.hits;
    total.misses += s.misses;
    total.loads += s.loads;
    total.evictions += s.evictions;
    total.load_bytes += s.load_bytes;
    total.decode_lookups += s.decode_lookups;
    total.decode_misses += s.decode_misses;
    total.prefill_lookups += s.prefill_lookups;
    total.prefill_misses += s.prefill_misses;
    total.l2_hits += s.l2_hits;
    total.l2_misses += s.l2_misses;
    total.l2_evictions += s.l2_evictions;
    total.l2_decode_hits += s.l2_decode_hits;
    total.l2_decode_misses += s.l2_decode_misses;
    total.l2_decode_evictions += s.l2_decode_evictions;
    total.l2_prefill_hits += s.l2_prefill_hits;
    total.l2_prefill_misses += s.l2_prefill_misses;
    total.l2_prefill_evictions += s.l2_prefill_evictions;
    total.mirror_hits += s.mirror_hits;
    total.mirror_writebacks += s.mirror_writebacks;
    total.mirror_skips += s.mirror_skips;
    total.pread_merge_runs += s.pread_merge_runs;
    total.pread_merge_experts += s.pread_merge_experts;
    total.nvme_read_bytes += s.nvme_read_bytes;
  }
  return total;
}

// Plain snapshot of the per-layer MoE residency timing counters (the
// atomics in MoEResidency::TimingStats are loaded once per layer).
// count/ns are summed across layers; max is the max of the per-layer maxes
// (cumulative, not per-request). All-zero when residency is disabled.
struct ResidencyTimingSnapshot {
  uint64_t stage_count = 0, stage_ns = 0, stage_max_ns = 0;
  uint64_t pread_count = 0, pread_ns = 0, pread_max_ns = 0;
  uint64_t swz_count = 0, swz_ns = 0, swz_max_ns = 0;
  uint64_t phase1_count = 0, phase1_ns = 0, phase1_max_ns = 0;
  uint64_t d2h_count = 0, d2h_ns = 0, d2h_max_ns = 0;
  // Decode-phase split (C5 diagnosis).
  uint64_t dstage_count = 0, dstage_ns = 0, dstage_max_ns = 0;
  uint64_t dpread_count = 0, dpread_ns = 0, dpread_max_ns = 0;
  uint64_t dphase1_count = 0, dphase1_ns = 0, dphase1_max_ns = 0;
  // Item 3b: one event per batched preadv run (total ns across the run).
  uint64_t pread_merge_count = 0, pread_merge_ns = 0,
      pread_merge_max_ns = 0;
  bool enabled = false;
};

inline ResidencyTimingSnapshot SumResidencyTiming(const Model& m) {
  ResidencyTimingSnapshot total;
  for (const auto& layer : m.layers) {
    const auto& t = layer.moe_residency.GetTiming();
    total.enabled = total.enabled ||
                    t.enabled.load(std::memory_order_relaxed);
    total.stage_count += t.stage_count.load(std::memory_order_relaxed);
    total.stage_ns += t.stage_ns.load(std::memory_order_relaxed);
    total.stage_max_ns =
        std::max(total.stage_max_ns, t.stage_max_ns.load(std::memory_order_relaxed));
    total.pread_count += t.pread_count.load(std::memory_order_relaxed);
    total.pread_ns += t.pread_ns.load(std::memory_order_relaxed);
    total.pread_max_ns =
        std::max(total.pread_max_ns, t.pread_max_ns.load(std::memory_order_relaxed));
    total.swz_count += t.swz_count.load(std::memory_order_relaxed);
    total.swz_ns += t.swz_ns.load(std::memory_order_relaxed);
    total.swz_max_ns =
        std::max(total.swz_max_ns, t.swz_max_ns.load(std::memory_order_relaxed));
    total.phase1_count += t.phase1_count.load(std::memory_order_relaxed);
    total.phase1_ns += t.phase1_ns.load(std::memory_order_relaxed);
    total.phase1_max_ns =
        std::max(total.phase1_max_ns, t.phase1_max_ns.load(std::memory_order_relaxed));
    total.d2h_count += t.d2h_count.load(std::memory_order_relaxed);
    total.d2h_ns += t.d2h_ns.load(std::memory_order_relaxed);
    total.d2h_max_ns =
        std::max(total.d2h_max_ns, t.d2h_max_ns.load(std::memory_order_relaxed));
    total.dstage_count += t.dstage_count.load(std::memory_order_relaxed);
    total.dstage_ns += t.dstage_ns.load(std::memory_order_relaxed);
    total.dstage_max_ns =
        std::max(total.dstage_max_ns, t.dstage_max_ns.load(std::memory_order_relaxed));
    total.dpread_count += t.dpread_count.load(std::memory_order_relaxed);
    total.dpread_ns += t.dpread_ns.load(std::memory_order_relaxed);
    total.dpread_max_ns =
        std::max(total.dpread_max_ns, t.dpread_max_ns.load(std::memory_order_relaxed));
    total.dphase1_count += t.dphase1_count.load(std::memory_order_relaxed);
    total.dphase1_ns += t.dphase1_ns.load(std::memory_order_relaxed);
    total.dphase1_max_ns =
        std::max(total.dphase1_max_ns, t.dphase1_max_ns.load(std::memory_order_relaxed));
    total.pread_merge_count +=
        t.pread_merge_count.load(std::memory_order_relaxed);
    total.pread_merge_ns +=
        t.pread_merge_ns.load(std::memory_order_relaxed);
    total.pread_merge_max_ns = std::max(
        total.pread_merge_max_ns,
        t.pread_merge_max_ns.load(std::memory_order_relaxed));
  }
  return total;
}

}  // namespace model
}  // namespace q4t

// Full attention (QSA sparse attention) — the qwen4_exp "full_attention"
// decoder layer's attention block (12 layers, every 4th).
//
// qwen4_exp full attention = GQA (24 q heads / 2 kv heads, head_dim 256) with
// partial MRoPE (rotary_dim 64 = 0.25 * 256, theta 1e7) + an attention output
// gate, PLUS a Qwen Sparse Attention (QSA) indexer that selects a sparse set
// of key positions per query instead of attending to the whole prefix.
//
// Main attention (per token, causal):
//   qg = x @ W_q^T   [T, 24*2*256]  (Q and Gate interleaved per head)
//   k  = x @ W_k^T   [T, 2*256]
//   v  = x @ W_v^T   [T, 2*256]
//   deinterleave qg -> q [T,24,256], gate [T,24,256]
//   q = per-head RMSNorm(q, centered) ; k = per-head RMSNorm(k, centered)
//   q, k = partial MRoPE (first 64 dims)
//   write k, v to the per-layer KV cache
//   topk = QSA indexer (below)
//   attn = sparse GQA attention over the selected token positions
//   attn = attn * sigmoid(gate)
//   out  = attn @ W_o^T   [T, hs]
//
// QSA indexer (compressed variant, compress_ratio 4, budget 2048, block_topk
// 512): a tiny 4-query/1-key MQA head (head_dim 128) that scores *compressed*
// keys (groups of 4 tokens, average-pooled) and picks the top-512 groups,
// expanded to 2048 token positions (+ the incomplete group's tail tokens).
//   iq, ik = x @ W_index_qk^T  -> iq [T,4,128], ik [T,1,128]
//   iq = GemmaRMSNorm(iq), with centered weight (1 + weight)
//   iq = partial MRoPE (first 64 dims): (a*cos-b*sin, a*sin+b*cos)
//   raw ik stored before normalization; each complete group is average-pooled,
//   GemmaRMSNorm'd and MRoPE'd (at the group's first position) -> compressed K
//   logits[t, g] = sum_h relu(iq[t,h] . ck[g]) / sqrt(128)   (g < (pos+1)/4)
//   topk = top-512 blocks -> expand to 2048 token indices + tail
//
// NOTE: `positions` carries the LOGICAL positions (0..T-1) used for KV
// paging, indexer group boundaries and causal masking. `rope_pos` carries the
// 3D MRoPE coordinates [3, max_len] (t, h, w) used for the RoPE angles (main
// attention Q/K, indexer Q/K, compressed keys). For pure text the three rows
// are identical to the logical position, so partial MRoPE reduces to standard
// RoPE on the first 64 dims; for multimodal prompts the vision tokens carry
// their own (t, h, w) grid coordinates (see model::VisionFeatures.grids).
#pragma once

#include <cuda_runtime.h>

#include <cstdint>
#include <string>
#include <span>
#include "q4t/runtime/sequence_capacity.h"

#include "q4t/io/weight_loader.h"
#include "q4t/model/gemv.h"
#include "q4t/status.h"

namespace q4t {
namespace model {

// Device weights of one full_attention (QSA) block. BF16 (uint16) row-major.
struct FullAttentionWeights {
  int hidden_size = 2560;
  int nq = 24;  // num_attention_heads
  int nkv = 2;  // num_key_value_heads
  int hd = 256;  // head_dim
  int rot_d = 64;  // partial rotary dim (0.25 * hd)
  float rope_theta = 1e7f;
  float eps = 1e-6f;
  // Non-null: indexer offsets in uint16 elements; KV pages are global.
  size_t* idx_seq_offsets = nullptr;
  int min_slot_capacity = 0;
  int max_len = 0;  // sequence capacity; sizes the persistent rope_pos rows
  // QSA indexer
  int idx_n_heads = 4;
  int idx_kv_heads = 1;
  int idx_head_dim = 128;
  int idx_budget = 2048;  // token_topk
  int idx_compress = 4;  // compress_ratio
  int idx_block_topk() const { return idx_budget / idx_compress; }  // 512

  uint16_t* q_proj = nullptr;  // [nq*2*hd, hs] (Q+Gate interleaved)
  uint16_t* k_proj = nullptr;  // [nkv*hd, hs]
  uint16_t* v_proj = nullptr;  // [nkv*hd, hs]
  uint16_t* o_proj = nullptr;  // [hs, nq*hd]
  uint16_t* q_norm = nullptr;  // [hd] (centered)
  uint16_t* k_norm = nullptr;  // [hd] (centered)
  // QSA indexer
  uint16_t* index_qk_proj = nullptr;  // [(idx_n_heads+idx_kv_heads)*idx_head_dim, hs]
  uint16_t* index_q_norm = nullptr;  // [idx_head_dim] (centered)
  uint16_t* index_k_norm = nullptr;  // [idx_head_dim] (centered)

  // FP8 (e4m3) decode shadows of the large projections (built at load when
  // Q4T_FP8_PROJ is on; null otherwise). index_qk stays BF16 (its GEMM slices
  // the merged [iq|ik] rows at an offset, and it is tiny).
  Fp8Shadow q_proj_fp8;
  Fp8Shadow k_proj_fp8;
  Fp8Shadow v_proj_fp8;
  Fp8Shadow o_proj_fp8;

  void Free();
};

Status ConfigureAttentionSlots(FullAttentionWeights* weights,
                               std::span<const int> capacities);

// Paged KV cache: the full-attention KV is organized into pages of
// kKvPageSize positions. A device page table (page_table[p] = physical page
// index for logical position p) makes the KV a migratable sequence of pages —
// the PD-ready prerequisite (see ARCHITECTURE.md "PD-ready 架构"). With the
// identity mapping (page_table[p] = p / kKvPageSize) the physical layout is
// bit-identical to the legacy contiguous layout, so attention output is
// unchanged. kKvPageSize=16 -> one page = 16 * nkv * 2 * hd * 2 bytes
// (32 KiB for nkv=2, hd=256).
constexpr int kKvPageSize = 16;

// Load one full_attention block's weights from `loader` under
//   {prefix}.q_proj.weight / k_proj.weight / v_proj.weight / o_proj.weight
//   {prefix}.q_norm.weight / k_norm.weight
//   {prefix}.indexer.index_qk_proj.weight
//   {prefix}.indexer.q_layernorm.weight / k_layernorm.weight
// e.g. prefix = "model.language_model.layers.3.self_attn".
Status LoadFullAttention(const io::WeightLoader& loader, const std::string& prefix,
                         int hidden_size, int nq, int nkv, int hd, int rot_d,
                         float rope_theta, float eps, int idx_n_heads,
                         int idx_kv_heads, int idx_head_dim, int idx_budget,
                         int idx_compress, FullAttentionWeights* out,
                         cudaStream_t stream);

// Run one full_attention (QSA) block forward for a single sequence (prefill).
//
//   x        : device row-major [T, hs] uint16 (BF16)
//   out      : device row-major [T, hs] uint16 (out)
//   positions: device int [T] absolute token positions (single sequence, so
//              positions[i] = seq_start + i). Must already be on the device
//              (same contract as `rope_pos`); no host->device copy is made.
//   kv_cache : device paged KV, [n_pages, kKvPageSize, nkv, 2, hd] uint16
//              (K and V interleaved per position within a page). Logical
//              position p maps to physical slot
//              page_table[p] * kKvPageSize + (p % kKvPageSize). n_pages is
//              sized for max_len (>= ceil(max_len / kKvPageSize) * kKvPageSize
//              positions). Persistent.
//   page_table: device int32 [max_len] — page_table[p] = physical page index
//              for logical position p. Identity mapping (p / kKvPageSize)
//              reproduces the legacy contiguous layout bit-for-bit.
//   idx_raw  : device [max_len, idx_head_dim] uint16 — raw (pre-RoPE) index
//              keys, persistent (contiguous by position, not paged)
//   idx_comp : device [max_len, idx_head_dim] uint16 — compressed keys (one
//              per group of idx_compress tokens), persistent (contiguous)
//   T        : number of tokens in this chunk (== sequence length for a
//              single prefill)
//   workspace: scratch device buffer (>= FullAttentionWorkspaceBytes(T)) for
//              projections + logits + topk + GEMM scratch
// `d_seq_id` (B2 multi-sequence decode): when non-null, a device int[T] giving
// the sequence id of each token. `rope_pos`, `kv_cache`, `page_table`,
// `idx_raw`, `idx_comp` are then the POOLED bases ([max_seq, ...]) and each
// token t indexes the slice for d_seq_id[t] (the kernels select the per-token
// base via d_seq_id). When null (legacy single-sequence prefill/decode) the
// pointers are the per-sequence slices and the kernels use them directly
// (bit-identical to the prior behavior). The projection GEMMs are stateless
// and operate on the packed [T, ...] rows directly (weights read once).
// max_position is the EXACT maximum of positions[0:T] (logical, not MRoPE).
// Supply it from the same host array uploaded to positions to avoid a D2H
// synchronization. -1 preserves readback for callers with device-only inputs.
Status FullAttentionForward(const FullAttentionWeights& w, const uint16_t* x,
                            uint16_t* out, const int* positions,
                            const int* rope_pos,
                            uint16_t* kv_cache, const int* page_table,
                            uint16_t* idx_raw, uint16_t* idx_comp, int T,
                            void* workspace, size_t workspace_bytes,
                            cudaStream_t stream, const int* d_seq_id = nullptr,
                            int max_position = -1, int layer_id = -1);

// Exact workspace bytes FullAttentionForward carves for `T` tokens: the
// projection/logits/topk intermediates (256-byte aligned each, sized from the
// weights' dims) plus a 32 MiB GEMM scratch. Mirrors the carve in
// FullAttentionForward so callers can size a shared buffer without re-deriving
// the layout.
size_t FullAttentionWorkspaceBytes(const FullAttentionWeights& w, int T);

}  // namespace model
}  // namespace q4t

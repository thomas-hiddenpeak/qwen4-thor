
/home/rm01/models/dev/qwen4-thor/.q4t-work/serve-media-integration-20261103/engine/q4t_host_memory_contract:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000005e04 <_Znwm>:
    5e04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e08:	910003fd 	mov	x29, sp
    5e0c:	f9000bf3 	str	x19, [sp, #16]
    5e10:	d53bd053 	mrs	x19, tpidr_el0
    5e14:	91400273 	add	x19, x19, #0x0, lsl #12
    5e18:	91004273 	add	x19, x19, #0x10
    5e1c:	a9408a61 	ldp	x1, x2, [x19, #8]
    5e20:	91000421 	add	x1, x1, #0x1
    5e24:	d1000442 	sub	x2, x2, #0x1
    5e28:	f9000661 	str	x1, [x19, #8]
    5e2c:	eb02003f 	cmp	x1, x2
    5e30:	54000128 	b.hi	5e54 <_Znwm+0x50>  // b.pmore
    5e34:	f100001f 	cmp	x0, #0x0
    5e38:	9a9f1400 	csinc	x0, x0, xzr, ne	// ne = any
    5e3c:	97ffff49 	bl	5b60 <__wrap_malloc>
    5e40:	3900627f 	strb	wzr, [x19, #24]
    5e44:	b40000a0 	cbz	x0, 5e58 <_Znwm+0x54>
    5e48:	f9400bf3 	ldr	x19, [sp, #16]
    5e4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e50:	d65f03c0 	ret
    5e54:	97fff45b 	bl	2fc0 <_ZN12_GLOBAL__N_19BeforeNewEv.part.0>
    5e58:	d2800100 	mov	x0, #0x8                   	// #8
    5e5c:	97fff36d 	bl	2c10 <__cxa_allocate_exception@plt>
    5e60:	d0000243 	adrp	x3, 4f000 <__FRAME_END__+0x194c4>
    5e64:	f947c863 	ldr	x3, [x3, #3984]
    5e68:	d0000242 	adrp	x2, 4f000 <__FRAME_END__+0x194c4>
    5e6c:	f947c042 	ldr	x2, [x2, #3968]
    5e70:	91004063 	add	x3, x3, #0x10
    5e74:	d0000241 	adrp	x1, 4f000 <__FRAME_END__+0x194c4>
    5e78:	f947dc21 	ldr	x1, [x1, #4024]
    5e7c:	f9000003 	str	x3, [x0]
    5e80:	97fff414 	bl	2ed0 <__cxa_throw@plt>

Disassembly of section .fini:

"""Archive exact public receipts; private policies/state are never selected."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

W = Path(__file__).resolve().parent
R = W.parents[1]
D = W / "binding-delivery-01"
O = R / "docs/evidence/serve-realtime-mcp-binding-delivery-20261120"
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
value = read(D / "result.json")
assert value["status"] == "PASS_MCP_BINDING_GUARD_DELIVERED"
assert value["publication"]["revision"] == 416
assert value["state"] == "STOPPED" and value["new_gpu_starts"] == 0
assert len(value["commands"]) == 19
assert all(c["returncode"] == 0 for c in value["commands"])
maintenance = read(W / "binding-maintenance-01/result.json")
assert maintenance["status"] == "PASS_REVERSIBLE_RETIRED_METADATA_ARCHIVE"
assert maintenance["live_state_unchanged"] and maintenance["deleted_files"] == 0
qualification = read(W / "binding-qualified-01/acceptance.json")
assert qualification["status"] == "ACCEPT_MCP_PRIMARY_LIGHT"
assert not O.exists()
files = {}
for name in ("result.json", "candidate-decision.json", "retained-decision.json",
             "candidate-service.release.json", "retained-service.release.json",
             "candidate-registration.json", "retained-registration.json",
             "recovery-anchor.json", "candidate-cycle.json", "anchor-cycle.json"):
    files["delivery/" + name] = D / name
for row in value["commands"]:
    for suffix in ("stdout", "stderr"):
        name = row["label"] + "." + suffix
        files["delivery/commands/" + name] = D / name
for name in ("acceptance.json", "plan.json", "primary-config.json",
             "light-config.json", "primary-capabilities.json",
             "light-capabilities.json", "qualified/registry.json",
             "qualified/primary.json", "qualified/light.json"):
    files["qualification/" + name] = W / "binding-qualified-01" / name
for name in ("decision.json", "receipt.json", "native-build.json"):
    files["candidate/" + name] = W / "binding-package-01" / name
for name in ("review.json", "receipt.json"):
    files["retained/" + name] = W / "binding-retained-01" / name
for name in ("binding-publication-composition-03.json",
             "binding-composition-01/failure.json",
             "binding-composition-02/metadata-review.json",
             "binding-composition-03/candidate-decision.json",
             "binding-composition-03/retained-decision.json",
             "binding-composition-03/candidate-service-release.json",
             "binding-composition-03/retained-service-release.json",
             "binding-maintenance-01/result.json"):
    files["composition/" + name] = W / name
for name in ("deliver_binding_01.py", "maintain_binding_01.py",
             "qualify_binding_01.py", "compose_binding_01.py",
             "compose_binding_02.py", "compose_binding_03.py",
             "prepare_binding_package_01.py", "prepare_binding_retained_01.py",
             "scan_public_changes_04.py", "archive_binding_delivery_01.py"):
    files["source/" + name] = W / name
index = {}
O.mkdir()
with tarfile.open(O / "evidence.tar.gz", "w:gz") as archive:
    for name, path in sorted(files.items()):
        raw = path.read_bytes()
        index[name] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        archive.addfile(info, io.BytesIO(raw))
(O / "index.json").write_text(json.dumps(index, indent=2) + "\n")
result = dict(status=value["status"], revision=416, state="STOPPED",
              seconds=value["seconds"], commands=len(value["commands"]),
              new_gpu_starts=0, new_managed_fault_runs=0,
              candidate_manifest_sha256="4ca02574aca05e98081f3db5fde79ca40ef5549f051c03af2684139df84a5568",
              retained_manifest_sha256="2fc04b4767f7b3cc7750442af253c80147c323fe1fcdd9b2d953f75713db94d3",
              binary_sha256="40359a27d7c59bf892a85aa239de3db81b9670305170849d6c9118088f99ec95",
              protocol_sha256="98fa9452fce551cfaed7c344869fa599780d43cd0122e2f4013e0a59f0934001",
              registry_sha256=qualification["registry_sha256"],
              customers_quotas_usage_core_outer_preserved=True,
              profile_history_clock_and_budgets_preserved=True,
              actual_stopped_root_rollback_and_forward=True,
              old_recovery_receipts_preserve_original_identities=True,
              original_model_quality_failures_preserved=True,
              original_model_quality_status="FAIL",
              targeted_model_quality_status="PASS",
              performance_acceptance=False, full_model_quality_accepted=False,
              long_stability_accepted=False, master_goal_active=True,
              reversible_metadata_maintenance=dict(
                  commands=len(maintenance["commands"]), deleted_files=0,
                  old_revision=406, live_state_unchanged=True),
              archive_sha256=sha(O / "evidence.tar.gz"))
(O / "acceptance.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ("status", "revision", "seconds", "commands")}))

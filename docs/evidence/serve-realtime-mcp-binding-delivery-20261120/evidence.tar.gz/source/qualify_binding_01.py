"""Bind the accepted allocation guard to unchanged original business leaves."""
import copy,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import bundle,ledger,profile_contract,profile_evidence,profile_record,profile_mcp_reuse as reuse
from tools.serve_recovery.profile_mcp_source import BINDING_GUARD
from tools.serve_ops import contracts
O=W/'binding-qualified-01';S=W/'binding-business-02';OLD=W/'qualified-profiles-02/qualified'
require(not O.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=R),'preserve clean qualification');O.mkdir(mode=0o700)
accepted=read(S/'acceptance.json');require(accepted['status']=='PASS_MCP_BINDING_GUARD_PRIMARY_LIGHT','actual business missing')
cpu=read(W/'binding-gate-cpu-01/result.json');require(cpu['status']=='PASS','CPU missing')
for n,h in read(W/'binding-gate-cpu-01/plan.json')['sources'].items():require(sha(R/n)==h,'CPU source drift')
plan=read(S/'plan.json')
for n,h in {**plan['reviewed_sources'],**plan['native_assets'],**plan['protected']}.items():require(sha(R/n)==h,'runtime/assets/default drift')
bundle.check_assets(plan['model'],plan['model_assets']);require(sha(plan['binary'])==BINDING_GUARD['binary_sha256'],'engine drift')
previous=read(OLD/'registry.json');require(sha(OLD/'registry.json')==BINDING_GUARD['prior_registry_sha256'],'prior qualification drift')
registry=dict(format=profile_contract.FORMAT,identity=plan['identity'],profiles=plan['profiles'],qualifications={});q=O/'qualified';q.mkdir(mode=0o700)
for name in ('primary','light'):
 p=OLD/(name+'.json');require(sha(p)==BINDING_GUARD['profiles'][name]['prior_record_sha256'],'prior record drift')
 value=profile_record.read(p);profile_evidence.validate(value,previous,name,sha(p));business=copy.deepcopy(value['business'])
 caps=read(S/(name+'-capabilities.json'));config=read(S/(name+'-config.json'))
 value.update(identity=plan['identity'],capabilities=caps,configuration=contracts.configuration(config,version=5),startup_memory=config['startup_memory']['checks']['before_allocations'],environment=accepted['environment'])
 value=reuse.attach_binding_guard(value,read(S/(name+'-binding-witness.json')));require(value['business']==business,'old business changed')
 p=q/(name+'.json');profile_record.save(p,value)
 registry['qualifications'][name]=profile_contract.qualification(name,value['capacity'],value['identity'],value['capabilities'],value['configuration'],value['startup_memory'],sha(p))
 save(O/(name+'-capabilities.json'),caps);save(O/(name+'-config.json'),config)
profile_contract.validate(registry)
for name in ('primary','light'):
 p=q/(name+'.json');profile_evidence.validate(profile_record.read(p),registry,name,sha(p))
profile_contract.capability_pair(read(O/'primary-capabilities.json'),read(O/'light-capabilities.json'));save(q/'registry.json',registry)
plan.update(output=str(O),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),targeted_format='q4t-mcp-binding-guard-qualification-v1',scope='Targeted two-profile MCP allocation fix; exact prior business and original failures retained; no new managed fault run',observed_source_review=BINDING_GUARD,sources={n:sha(R/n) for n in bundle.SOURCES})
plan['sources'].update(plan['reviewed_sources'])
for p in (Path(__file__).resolve(),S/'plan.json',S/'acceptance.json',W/'binding-gate-cpu-01/result.json'):plan['sources'][str(p)]=sha(p)
save(O/'plan.json',plan)
result=dict(status='ACCEPT_MCP_PRIMARY_LIGHT',registry_sha256=sha(q/'registry.json'),environment=accepted['environment'],new_gpu_starts=0,actual_model_starts=3,actual_jobs=5,original_failures_preserved=True,original_model_quality_status='FAIL',model_quality_repaired=False,targeted_model_quality_status=accepted['model_quality_status'],default_unchanged=True,managed_recovery_repeated=False,full_matrix=False,master_active=True,source_review_sha256=ledger.digest(BINDING_GUARD),profile_bytes={n:(q/(n+'.json')).stat().st_size for n in ('primary','light')})
save(O/'acceptance.json',result);print(json.dumps(result))

"""Exact allocation fix and original managed recovery, without relabelling runs."""
import copy,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service import package as p
from tools.serve_recovery import bundle,version_contract,profile_migration,profile_manager,profile_record,profile_evidence
from tools.serve_recovery.profile_mcp_source import BINDING_GUARD
O=W/'binding-composition-01';p.require(not O.exists(),'preserve composition');O.mkdir(mode=0o700)
actual=p.read(W/'binding-business-02/acceptance.json');q=p.read(W/'binding-qualified-01/acceptance.json');prior=p.read(W/'publication-composition.json')
p.require(actual['status']=='PASS_MCP_BINDING_GUARD_PRIMARY_LIGHT' and actual['environment']['status']=='PASS' and q['status']=='ACCEPT_MCP_PRIMARY_LIGHT','targeted qualification missing')
roots={n:{k:v[k] for k in ('package','manifest_sha256')} for n,v in [('candidate',p.read(W/'binding-package-01/receipt.json')),('retained',p.read(W/'binding-retained-01/receipt.json'))]}
proof={};decisions={}
for n,stage,original in [('candidate','managed-default-version-02','service-package-03'),('retained','managed-default-retained-03','retained-03')]:
 target=Path(roots[n]['package']);old=W/original/'bundle'
 first=bundle.verify(old,p.sha(old/'manifest.json'));second=bundle.verify(target,roots[n]['manifest_sha256'])
 oldengine=p.read(old/'engine/manifest.json');newengine=p.read(target/'engine/manifest.json')
 p.require(oldengine['settings']==newengine['settings'] and oldengine['model_assets']==newengine['model_assets'],'backend settings or assets changed')
 delta={k for k,h in first['files'].items() if second['files'].get(k)!=h}
 allowed={'profile-primary.json','profile-light.json','source/tools/serve_recovery/profile_mcp_reuse.py','source/tools/serve_recovery/profile_mcp_source.py'}
 p.require(delta==allowed and set(first['files'])==set(second['files']),'unreviewed service source delta')
 # Engine manifests are verified independently and linked by the outer hash.
 p.require(first['native_build']==second['native_build'] if 'native_build' in first else p.sha(old/'native-build.json')==p.sha(target/'native-build.json'),'native helper identity changed')
 for name in ('primary','light'):
  path=target/('profile-'+name+'.json');profile_evidence.validate(profile_record.read(path),second['recovery_profiles'],name,p.sha(path))
 olddecision=p.read(W/stage/'decision.json');oldrelease=p.read(W/stage/'service-release.json')
 original_receipt={k:dict(path=str(W/stage/f),sha256=p.sha(W/stage/f)) for k,f in [('release','service-release.json'),('decision','decision.json')]}
 version_contract.accepted_fallback(original_receipt,version_contract.payload(dict(package=str(old),manifest_sha256=p.sha(old/'manifest.json'))))
 proof[n]=dict(previous=dict(package=str(old),manifest_sha256=p.sha(old/'manifest.json')),target=roots[n],service_delta=sorted(delta),native_helpers_unchanged=True,controller_ingress_and_recovery_sources_unchanged=True,application_settings_and_assets_unchanged=True,original_service_acceptance=original_receipt,original_service_business=olddecision['actual_business'],fresh_engine_business=dict(path=str(W/'binding-business-02/acceptance.json'),sha256=p.sha(W/'binding-business-02/acceptance.json')),runtime_delta=BINDING_GUARD['runtime_delta'],new_managed_fault_runs=0)
 business=dict(status='PASS_MCP_BINDING_GUARD_WITH_REUSED_SERVICE_RECOVERY',env_abort=False,postflight=dict(sources_unchanged=True,owned_processes_gone=True,ports_free=True,lock_released=True,default_unchanged=True),fresh_engine=copy.deepcopy(actual),source_composition=proof[n],new_managed_fault_runs=0,original_quality_failures_preserved=True)
 accepted='ACCEPT_MCP_BINDING_GUARD_'+n.upper()+'_COMPOSITION'
 decision=dict(status='PASS_MCP_BINDING_GUARD_'+n.upper()+'_COMPOSITION',acceptance=accepted,manifest_sha256=roots[n]['manifest_sha256'],engine_binary_sha256=BINDING_GUARD['binary_sha256'],actual_business=business,default_replaced=False,performance_acceptance=False,long_stability_accepted=False)
 p.save(O/(n+'-decision.json'),decision)
 release=copy.deepcopy(oldrelease);release.update(acceptance=accepted,manifest_sha256=roots[n]['manifest_sha256'],package=str(target),engine_binary_sha256=BINDING_GUARD['binary_sha256'],acceptance_record=str(O/(n+'-decision.json')),acceptance_sha256=p.sha(O/(n+'-decision.json')),source_composed_recovery=True,new_managed_fault_runs=0,source_composition=proof[n],scope='Exact MCP allocation guard qualification plus source-identical prior managed recovery; no new managed fault run or full model quality claim')
 p.save(O/(n+'-service-release.json'),release)
 receipt={k:dict(path=str(O/(n+f)),sha256=p.sha(O/(n+f))) for k,f in [('release','-service-release.json'),('decision','-decision.json')]}
 version_contract.accepted_fallback(receipt,version_contract.payload(roots[n]));decisions[n]=decision
p.require(version_contract.compatible(version_contract.payload(roots['candidate']),version_contract.payload(roots['retained']))['automatic'],'fallback compatibility')
value=dict(status='ACCEPT_MCP_BINDING_GUARD_SERVICE_COMPOSITION',candidate=roots['candidate'],automatic_fallback=roots['retained'],modern_retained_root=roots['retained'],candidate_service_acceptance=decisions['candidate'],modern_service_acceptance=decisions['retained'],binary_sha256=BINDING_GUARD['binary_sha256'],protocol_sha256=BINDING_GUARD['protocol_sha256'],counts=dict(starts=3,actual_generations=5,reserved_generations=6,websocket_sessions=3,probes=0),service_seconds=159.3220474338159,nvml_queries=150,nvml_all_ok=True,cleanup_complete=True,actual_reads=2,model_quality_status='FAIL',targeted_model_quality_status=actual['model_quality_status'],original_profile_model_quality_failures_preserved=True,full_model_quality=False,performance_claim=False,older_engine_fallback=False,default_unchanged=True,publication_pending=True,all_master_tasks_complete=False,primary_light_evidence=dict(path=str(W/'binding-qualified-01/acceptance.json'),sha256=p.sha(W/'binding-qualified-01/acceptance.json')),tls_composition=prior['tls_composition'],guardian_repair=prior['guardian_repair'],unchanged_backend_recovery_source=dict(path=str(W/'publication-composition.json'),sha256=p.sha(W/'publication-composition.json'),scope='Exact original package identities retained. Only the allocation guard and its qualification verifier change; accepted native helpers, controllers, TLS, app settings and backend assets are unchanged. No new managed fault run.'),candidate_whole_package_gpu_run=False,new_managed_fault_runs=0,default_policy_unchanged=True,private_test_policy_shipped=False,automatic_request_or_tool_replay=False,proof=proof)
p.save(W/'binding-publication-composition.json',value)
print(json.dumps(dict(status=value['status'],roots=roots,new_managed_fault_runs=0)))

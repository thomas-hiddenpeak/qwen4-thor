"""Inspect public diff bytes, including nested tar members, without printing keys."""
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = R / '.q4t-work/serve-realtime-duplex-20261120'
C = D / 'credential-remediation-01'
secrets = set()


def collect(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"api_key", "gateway_token", "shared_secret", "private_key",
                       "token", "authorization", "key", "mcp_token"} and isinstance(child, str):
                if len(child) >= 24 and not (key == "key" and Path(child).is_absolute() and Path(child).is_file()):
                    secrets.add(child.encode())
            else:
                collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)


private = [D / "service-package-01/clients.json",
           C / "candidate/bundle/engine/client-policy.json",
           C / "retained/bundle/engine/client-policy.json",
           R / "build/service/gateway-policy.json"]
private += list(D.glob("recovery-*/execution/state/**/client-policy.json"))
private += list(W.glob('*/bundle/gateway-policy.json'))
private += list(W.glob('*/bundle/engine/client-policy.json'))
private += list(W.glob('managed-*/execution/state/**/client-policy.json'))
private += list(W.glob('binding-business-*/client-policy.json'))
private += list(W.glob('binding-business-*/*-binding/ingress.json'))
private += list((R/'build/service-native-state').glob('client-*/policy.json'))
for path in private:
    collect(json.loads(path.read_text()))
assert len(secrets) >= 2

paths = set()
for args in (["git", "diff", "--name-only", "origin/main", "--"],
             ["git", "ls-files", "--others", "--exclude-standard",
              "docs", "src", "include", "tests", "tools", ".github"]):
    paths.update(subprocess.check_output(args, cwd=R, text=True).splitlines())
hits = []
members = 0
private_key = re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----\s+[A-Za-z0-9+/=]{10,}")


def scan(label, data, depth=0):
    global members
    if any(secret in data for secret in secrets) or private_key.search(data):
        hits.append(label)
    if data.startswith(b"\x1f\x8b") and depth < 4:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
            for member in archive:
                if member.isfile():
                    members += 1
                    scan(label + "::" + member.name,
                         archive.extractfile(member).read(), depth + 1)


rows = {}
for name in sorted(paths):
    path = R / name
    if path.is_file():
        raw = path.read_bytes()
        rows[name] = hashlib.sha256(raw).hexdigest()
        scan(name, raw)
result = dict(status="PASS" if not hits else "FAIL", files=len(rows),
              archive_members=members, matches=hits,
              inspected_private_files=len(private),
              public_file_sha256=rows, secrets_printed=False)
(W / "public-diff-scan.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "public_file_sha256"}))
assert not hits, "private data in public changes"

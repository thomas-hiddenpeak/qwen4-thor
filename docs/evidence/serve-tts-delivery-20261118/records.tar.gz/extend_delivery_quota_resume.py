"""Resume explicit quota migration through the same durable API under STOPPED locks."""
import sys,json,os,time
from contextlib import ExitStack
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;S=R/'build/service-native-state';O=W/'delivery-quota-02';P=W/'delivery-quota-01';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service import package as p
from tools.serve_recovery import publication,deployment,quota_manager,bundle,service
os.umask(0o077);p.require(not O.exists(),'preserve quota continuation');O.mkdir(mode=0o700);started=time.monotonic()
def protected():
 return {str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-'))) and not f.relative_to(S).parts[0].startswith('client-limits')}
before=protected();proposal=P/'direct-proposal-diagnostic.json';value=p.read(proposal);original=p.read(P/'original-policy.json');p.require(value['expected_revision']==0,'wrong proposal')
with ExitStack() as locks:
 locks.enter_context(deployment.claim(S,name='publication.lock'));desc=deployment.read_descriptor(S);manifest=bundle.verify(desc['package'],desc['manifest_sha256']);lease=service.acquire_lease(manifest['lock_path']);locks.callback(os.close,lease)
 locks.enter_context(publication.quiescent(S,desc));p.require(p.read(S/'client-limits/policy.json')['state']['policy']==original,'quota predecessor changed')
 receipt=quota_manager.apply(S,desc,manifest,proposal,wait_seconds=0)
 p.require(p.read(S/'client-limits/policy.json')['state']['policy']==value['policy'] and protected()==before,'unexpected state mutation')
full={str(f.relative_to(S)):p.sha(f) for f in S.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(S).parts[0].startswith(('client-','outer-')))}
p.save(O/'result.json',dict(status='PASS_EXPLICIT_OUTPUT_BUDGET_MIGRATION',seconds=time.monotonic()-started,receipt=receipt,previous=original,candidate=value['policy'],preserved_except_limits=before,post_migration_preserved=full,usage_reset=False,new_gpu_starts=0,publication_intent_unchanged=True,api='quota_manager.apply',original_cli_failure_retained=True))
print(json.dumps(dict(status='PASS_EXPLICIT_OUTPUT_BUDGET_MIGRATION',seconds=time.monotonic()-started,revision=receipt['revision'])))

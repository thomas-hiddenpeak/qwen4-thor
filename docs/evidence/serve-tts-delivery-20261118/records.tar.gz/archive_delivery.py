"""Archive the exact native auxiliary delivery and its interrupted maintenance."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
D=W/'delivery-01';O=R/'docs/evidence/serve-tts-delivery-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
v=read(D/'result.json');composition=read(W/'publication-composition.json')
assert v['status']=='PASS_NATIVE_TTS_INPUT_DELIVERED' and v['publication']['revision']==316
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands'])
assert v['state']=='STOPPED' and v['new_gpu_starts']==0 and v['outer']['charged_total']==0
c=v['publication']['current'];assert c['manifest_sha256']==composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
release=read((R/'build/service.release.json').resolve());capacity=read(W/'capacity-01/result.json')
assert capacity['status']=='PASS_DELIVERY_CAPACITY_RESERVED'
assert not capacity['deleted_files'] and capacity['default_unchanged'] and capacity['recovery_budget_unchanged']
files={}
for p in (W/'capacity-01').glob('*-archive/*.json'):files[str(p.relative_to(W))]=p
for d in [D,W/'capacity-01',W/'delivery-quota-01',W/'delivery-quota-02']:
 for p in d.iterdir():
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(W))]=p
for pattern in ['delivery-prepare-*.*','delivery-run-*.*']:
 for p in W.glob(pattern):
  if p.is_file():files[p.name]=p
for name in ['archive_delivery.py','deliver.py','reserve_delivery_capacity.py','deliver_resume.py','extend_delivery_quota.py','extend_delivery_quota_resume.py','maintenance-before.json','publication-composition.json']:
 files[name]=W/name
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,item in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(item,str) and len(item)>=24:secrets.append(item.encode())
   else:collect(item)
 elif isinstance(v,list):
  for item in v:collect(item)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for name,p in files.items():
 raw=p.read_bytes();assert not any(secret in raw for secret in secrets),name
 assert b'-----BEGIN '+b'PRIVATE KEY-----\n' not in raw,name
assert not O.exists();O.mkdir()
index={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in files.items()}
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
quota=read(W/'delivery-quota-02/result.json');assert quota['status']=='PASS_EXPLICIT_OUTPUT_BUDGET_MIGRATION' and not quota['usage_reset']
a=dict(status='ACCEPT_NATIVE_TTS_INPUT_DELIVERY',revision=316,current=c,
 commands=len(v['commands']),seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,
 executed_continuation_commands=16,reused_completed_checks=3,original_delivery_failed_commands=4,
 original_failure_preserved=True,client_output_extension=dict(client='alpha',previous=256,current=2817,policy_revision=1),usage_reset=False,
 manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],
 candidate_whole_package_gpu_run=True,older_engine_fallback=False,previous_rev306_preserved=True,
 retired_intents_archived=5,retired_generations_archived=2,retired_versions_archived=2,
 maintenance_original_read_contention_preserved=False,maintenance_cumulative_seconds=capacity['seconds'],deleted_files=0,
 files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,
 full_model_quality=False,performance_claim=False,long_stability_run=False,full_openai_compatibility=False,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 语音输入与输出可回退交付 rev316

默认服务包 {c['manifest_sha256']}，引擎 {c['engine_binary_sha256']}。
19项STOPPED步骤（3项复用、16项续办）、整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU；outer启用且累计启动0，服务保持STOPPED。

Speech/Chat真实音频输出、私有音频历史和重叠分离进入默认；主轻
配置均验证输入/输出、完整音频、usage及辅助权重释放后按需重载。
TLS入口恢复与整包回退前后实际收音/发声，双SDK、证书、独立Key、
活动取消、存储Chat和原恢复历史/冷却保持。复用
[主轻26条](../serve-tts-input-profiles-20261118/README.md)、
[TLS与恢复40条](../serve-tts-service-20261118/README.md)及直接
[Speech](../serve-speech-http-20261118/README.md)/
[Chat](../serve-chat-audio-output-http-20261118/README.md)精确身份记录。

核心/usage/outer预算字节保持；client仅显式将alpha输出上限从256
升至2817，策略revision 0→1，使用正式持久化API，不重置用量。
首次发布因初始化配额不匹配被拒，原FAILED保留；续办原事务，
复用3项已完成检查，仅执行余下16命令。profile显式加入分离/TTS合同；
原history/pending/selected/deadline保持。人工根 {a['manual_root']}、
自动payload {a['automatic_payload']}均使用当前引擎与保留控制；
前驱rev306及day入口保留。5旧intent、2旧generation和2旧registration
按现有工具可恢复归档，0删除，无模型动作。

按用户决定，仅指定混音的hurt→hurts词形误差可接受，保留WER=1/7
与原失败；不放宽漏句、说话人/重叠或改变句意。4倍内容、完整
voice/style/注册voice、非语言声学、Responses/Batch/Realtime及全部
master剩余项继续。下一步主线检查合入；未宣称完整OpenAI兼容、
全模型质量、性能或长稳通过，总目标仍active。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev316；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','Guardian':'`'+release['guardian_sha256']+'`','原生入口':'`'+release['ingress_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；实际输入/TTS/原周期/原生入口已验，前驱rev306另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退','外部依赖':'原生入口/自监护不要求nginx/systemd；ASR/对齐/VAD/speaker/分离/TTS资产按部署显式启用，codec按请求隔离，辅助失能不拖停健康Chat'}
for name,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(name)+r' \| .* \|$',lambda _:f'| {name} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev316语音输入输出可回退交付](evidence/serve-tts-delivery-20261118/README.md)
完成，19项STOPPED步骤（复用3、续办16）/{v['seconds']:.3f}秒，0新增GPU。实际整根回退
再前进通过，原用量/历史保持，alpha输出显式256→2817；前驱rev306和day保留。接着主线
检查合入、4倍内容、完整voices与全部master，不在本阶段结束总目标。

'''
s=s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1);put(p,s)
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);put(p,h+f'''\n\n## rev316语音输入输出可回退交付（2026-11-18）

19项STOPPED步骤（复用3、续办16）/{v['seconds']:.3f}秒，0新增GPU；实际整根回退及
再前进完成，原历史/用量保持，alpha输出上限显式256→2817；Speech/Chat输出与历史、真实重叠及辅助容量切换进入默认。
可恢复归档0删除，维护按每组最多4项执行。原因：已验功能
须进入可用发行并验证回退。前驱rev306/day保留；下一步主线
检查合入、4倍内容、完整voices和全部master继续。
[证据](../evidence/serve-tts-delivery-20261118/README.md)。\n'''+b)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for t in j['tasks']:
 if t['id'] in ['A01','A02','A10','A12','Q01','Q02']:t['tts_input_delivery_20261118']=a|dict(evidence='evidence/serve-tts-delivery-20261118/README.md')
 if t['id']=='A01':t['remaining_required']=['Complete voice/style/custom-voice and extreme-speed content coverage; Speech/Chat input/output is delivered in rev316','Remaining default/null, nested message and response projection parity']
 if t['id']=='A02':t['remaining_required']=['Remaining full template/history parity; non-null audio history and actual speech round trips delivered in rev316']
 if t['id']=='Q02':
  t['latest_release']=t['tts_input_delivery_20261118'];t['remaining_required']=['Speech/input PR final-head checks and actual main merge','Delivery of every remaining implementation']
 if t['id']=='R07':t['current_execution_prerequisite']='Refresh exact cold qualification against rev316 or then-current default; pending host/camera maintenance handoff remains required.'
j['native_tts_progress']['managed']['state']='delivered_rev316_main_pending';j['native_tts_progress']['managed']['delivery']=a|dict(evidence='evidence/serve-tts-delivery-20261118/README.md')
j['next_task']='Speech/input main integration and remaining audio/voice/Realtime plus all master tasks';j['next']='Complete main integration, four-times-speed content, complete voices and remaining Responses/Batch/Realtime and every A/N/R/Q task.';put(p,json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';put(p,p.read_text()+'\n- [rev316语音输入输出交付](evidence/serve-tts-delivery-20261118/README.md)：真实Speech/Chat与重叠分离、可回退原生服务。\n')
print(json.dumps({k:a[k] for k in ['status','revision','commands','seconds']}))

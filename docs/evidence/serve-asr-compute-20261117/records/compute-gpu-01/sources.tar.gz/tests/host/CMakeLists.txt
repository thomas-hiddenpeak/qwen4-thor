# Public Linux checks: no CUDA, ICU, weights, or private fixtures required.
cmake_minimum_required(VERSION 3.25)
project(q4t_public_host_checks LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

include(../../cmake/HostTestSources.cmake)
find_package(Threads REQUIRED)
add_executable(q4t_host_tests ${Q4T_HOST_TEST_SOURCES} ../../src/io/json.cpp)
target_compile_definitions(q4t_host_tests PRIVATE Q4T_GRAMMAR_PROCESS_TESTS=1)
q4t_link_structured_output(q4t_host_tests)
q4t_link_native_crypto(q4t_host_tests)
q4t_link_native_documents(q4t_host_tests)
q4t_link_native_programmatic(q4t_host_tests)
target_include_directories(q4t_host_tests PRIVATE ../../include)
target_include_directories(q4t_host_tests SYSTEM PRIVATE ../../third_party)
target_include_directories(q4t_host_tests PRIVATE ${Q4T_CHAT_PROTOCOL_INCLUDE_DIR})
target_compile_options(q4t_host_tests PRIVATE -Wall -Wextra -Werror)
target_link_libraries(q4t_host_tests PRIVATE Threads::Threads ${CMAKE_DL_LIBS})

# Local real-checkpoint qualification is opt-in and has no CUDA dependency.
add_executable(q4t_asr_contract_tests EXCLUDE_FROM_ALL
  ../test_main.cpp ../asr_config_test.cpp ../asr_asset_test.cpp
  ../../src/audio/asr_config.cpp ../../src/io/json.cpp)
target_include_directories(q4t_asr_contract_tests PRIVATE ../../include)
target_compile_options(q4t_asr_contract_tests PRIVATE -Wall -Wextra -Werror)
add_executable(q4t_asr_layout_tests EXCLUDE_FROM_ALL
  ../test_main.cpp ../asr_layout_test.cpp
  ../../src/audio/asr_layout.cpp ../../src/audio/asr_config.cpp
  ../../src/io/json.cpp ../../src/model/embedding_layout.cpp
  ../../src/model/embedding_config.cpp)
target_include_directories(q4t_asr_layout_tests PRIVATE ../../include)
target_compile_options(q4t_asr_layout_tests PRIVATE -Wall -Wextra -Werror)
add_executable(q4t_asr_feature_tests EXCLUDE_FROM_ALL
  ../test_main.cpp ../asr_features_test.cpp ../../src/audio/features.cpp)
target_include_directories(q4t_asr_feature_tests PRIVATE ../../include)
target_compile_options(q4t_asr_feature_tests PRIVATE -Wall -Wextra -Werror)

# Optional local tokenizer qualification; ICU is not required by public CI.
find_package(PkgConfig QUIET)
if(PkgConfig_FOUND)
  pkg_check_modules(ASR_ICU QUIET icu-uc icu-i18n)
endif()
if(ASR_ICU_FOUND)
  add_executable(q4t_asr_tokenizer_tests EXCLUDE_FROM_ALL
    ../test_main.cpp ../asr_tokenizer_test.cpp ../embedding_contract_test.cpp
    ../../src/text/tokenizer.cpp ../../src/io/json.cpp
    ../../src/model/embedding_config.cpp ../../src/model/embedding_layout.cpp)
  target_include_directories(q4t_asr_tokenizer_tests PRIVATE
    ../../include ${ASR_ICU_INCLUDE_DIRS})
  target_link_libraries(q4t_asr_tokenizer_tests PRIVATE ${ASR_ICU_LINK_LIBRARIES})
  target_compile_options(q4t_asr_tokenizer_tests PRIVATE -Wall -Wextra -Werror)
endif()

add_executable(q4t_client_policy_check
  ../../tools/serve_recovery/client_policy_check.cpp
  ../../src/server/client_policy.cpp ../../src/server/client_rate_state.cpp
  ../../src/trace/sha256.cpp ../../src/io/json.cpp)
target_include_directories(q4t_client_policy_check PRIVATE ../../include)
target_compile_options(q4t_client_policy_check PRIVATE -Wall -Wextra -Werror)
target_link_libraries(q4t_client_policy_check PRIVATE Threads::Threads)

add_executable(q4t_client_policy_fixture
  ../client_policy_admin_fixture.cpp ../../src/server/client_policy.cpp
  ../../src/server/client_rate_state.cpp
  ../../src/server/client_policy_admin.cpp ../../src/service/guardian_process.cpp
  ../../src/trace/sha256.cpp ../../src/io/json.cpp)
target_include_directories(q4t_client_policy_fixture PRIVATE ../../include)
target_compile_options(q4t_client_policy_fixture PRIVATE -Wall -Wextra -Werror)
target_link_libraries(q4t_client_policy_fixture PRIVATE Threads::Threads)

enable_testing()
include(../../cmake/GuardianProcess.cmake)
include(../../cmake/NativeIngress.cmake)
include(../../cmake/ServiceCLI.cmake)
set(guardian_output "${CMAKE_CURRENT_BINARY_DIR}/guardian-process-tests")
file(MAKE_DIRECTORY "${guardian_output}")
add_test(NAME q4t_guardian_process_contracts
  COMMAND q4t_guardian_process_tests)
set_tests_properties(q4t_guardian_process_contracts PROPERTIES
  TIMEOUT 60 ENVIRONMENT "Q4T_TEST_OUTPUT_DIR=${guardian_output}")
# Run the complete public registry, strictly: no filters or allowed skips.
add_test(NAME q4t_public_host_contracts COMMAND q4t_host_tests)
set(host_output "${CMAKE_CURRENT_BINARY_DIR}/public-host-tests")
file(MAKE_DIRECTORY "${host_output}")
set_tests_properties(q4t_public_host_contracts PROPERTIES TIMEOUT 600
  ENVIRONMENT "Q4T_TEST_OUTPUT_DIR=${host_output};TMPDIR=${host_output}")

# Offline trace validation shares no runtime/CUDA dependencies.
add_executable(q4t_router_trace_check ../../tools/trace/router_trace_check.cpp
  ../../src/trace/router_trace.cpp)
target_include_directories(q4t_router_trace_check PRIVATE ../../include)
target_compile_options(q4t_router_trace_check PRIVATE -Wall -Wextra -Werror)
find_package(Python3 REQUIRED COMPONENTS Interpreter)
set(journal_output "${CMAKE_CURRENT_BINARY_DIR}/guardian-journal-tests")
file(MAKE_DIRECTORY "${journal_output}")
add_test(NAME q4t_guardian_journal_contracts
  COMMAND q4t_guardian_journal_tests ${Python3_EXECUTABLE}
    ${CMAKE_CURRENT_SOURCE_DIR}/../../tools/serve_recovery/journal.py)
set_tests_properties(q4t_guardian_journal_contracts PROPERTIES
  TIMEOUT 60 ENVIRONMENT "Q4T_TEST_OUTPUT_DIR=${journal_output}")
add_test(NAME q4t_router_trace_wire_contracts
  COMMAND ${Python3_EXECUTABLE} -B
    ${CMAKE_CURRENT_SOURCE_DIR}/../../tools/trace/test_wire.py
    --checker $<TARGET_FILE:q4t_router_trace_check>
    --output ${CMAKE_CURRENT_BINARY_DIR}/trace-wire-tests)
set_tests_properties(q4t_router_trace_wire_contracts PROPERTIES TIMEOUT 180)

# Python contracts use synthetic inputs and keep artifacts in this build tree.
# Select an environment containing numpy with -DPython3_EXECUTABLE=... if needed.
function(q4t_add_python_contract name script)
  set(output_dir "${CMAKE_CURRENT_BINARY_DIR}/${name}")
  file(MAKE_DIRECTORY "${output_dir}")
  add_test(NAME ${name}
    COMMAND ${Python3_EXECUTABLE} -B
      ${CMAKE_CURRENT_SOURCE_DIR}/../../${script} ${ARGN})
  get_filename_component(script_dir "${script}" DIRECTORY)
  set_tests_properties(${name} PROPERTIES
    TIMEOUT 180
    WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/../../${script_dir}"
    ENVIRONMENT "Q4T_TEST_OUTPUT_DIR=${output_dir};TMPDIR=${output_dir};PYTHONDONTWRITEBYTECODE=1")
endfunction()

q4t_add_python_contract(q4t_monitored_stage_contracts
  tools/evalscope/test_monitored_stage.py)

q4t_add_python_contract(q4t_router_trace_source_contracts
  tools/trace/test_analyze.py
  --checker $<TARGET_FILE:q4t_router_trace_check>
  --output ${CMAKE_CURRENT_BINARY_DIR}/trace-analysis-tests)
q4t_add_python_contract(q4t_router_cache_replay_contracts
  tools/trace/test_replay.py)
q4t_add_python_contract(q4t_router_shadow_contracts
  tools/trace/test_shadow.py
  --checker $<TARGET_FILE:q4t_router_trace_check>
  --output ${CMAKE_CURRENT_BINARY_DIR}/shadow-contracts)

# test_distribution.py needs numpy. Prefer a machine-local venv when present
# (.q4t-work/venvs/public-host); otherwise the default interpreter, which the
# CI workflow provisions with python3-numpy.
find_program(Q4T_DISTRIBUTION_PYTHON
  NAMES python3
  PATHS ${CMAKE_CURRENT_SOURCE_DIR}/../../.q4t-work/venvs/public-host/bin
  NO_DEFAULT_PATH)
if(NOT Q4T_DISTRIBUTION_PYTHON)
  set(Q4T_DISTRIBUTION_PYTHON ${Python3_EXECUTABLE})
endif()
add_test(NAME q4t_router_distribution_contracts
  COMMAND ${Q4T_DISTRIBUTION_PYTHON} -B
    ${CMAKE_CURRENT_SOURCE_DIR}/../../tools/trace/test_distribution.py
    --checker $<TARGET_FILE:q4t_router_trace_check>)
set_tests_properties(q4t_router_distribution_contracts PROPERTIES TIMEOUT 180)

q4t_add_python_contract(q4t_router_hybrid_contracts
  tools/trace/test_hybrid.py)

# Offline research algorithm copies are isolated from runner include/src trees.
add_executable(q4t_gpu_cache_schedule ../../tools/trace/gpu_cache_schedule.cpp)
add_executable(q4t_offload_sort ../../tools/trace/offload_sort.cpp)
foreach(target q4t_gpu_cache_schedule q4t_offload_sort)
  target_compile_options(${target} PRIVATE -Wall -Wextra -Werror)
endforeach()
q4t_add_python_contract(q4t_offload_trace_contracts
  tools/trace/test_offload_trace.py
  --checker $<TARGET_FILE:q4t_router_trace_check>
  --output ${CMAKE_CURRENT_BINARY_DIR}/offload-trace-contracts)
q4t_add_python_contract(q4t_offload_log_contracts
  tools/trace/test_offload_log.py)
q4t_add_python_contract(q4t_gpu_cache_schedule_contracts
  tools/trace/test_gpu_cache_schedule.py
  --helper $<TARGET_FILE:q4t_gpu_cache_schedule>
  --sort-helper $<TARGET_FILE:q4t_offload_sort>)
q4t_add_python_contract(q4t_gpu_cache_replay_contracts
  tools/trace/test_gpu_cache_replay.py)
q4t_add_python_contract(q4t_gpu_cache_study_contracts
  tools/trace/test_gpu_cache_study.py)
q4t_add_python_contract(q4t_decode_supply_bounds_contracts
  tools/trace/test_decode_supply_bounds.py)
q4t_add_python_contract(q4t_analyze_decode_supply_contracts
  tools/trace/test_analyze_decode_supply.py)
q4t_add_python_contract(q4t_mirror_retention_contracts
  tools/trace/test_mirror_retention.py)
q4t_add_python_contract(q4t_analyze_mirror_retention_contracts
  tools/trace/test_analyze_mirror_retention.py)
q4t_add_python_contract(q4t_physical_ram_contracts
  tools/evalscope/test_physical_ram.py)
q4t_add_python_contract(q4t_response_identity_contracts
  tools/evalscope/test_response_identity.py)
q4t_add_python_contract(q4t_agent_tool_client_contracts
  tools/examples/test_chat_client.py)
q4t_add_python_contract(q4t_schema_client_contracts
  tools/examples/test_schema_client.py)
q4t_add_python_contract(q4t_vision_timing_parser_contracts
  tools/vision_service/test_timing.py)
q4t_add_python_contract(q4t_vision_forward_timing_parser_contracts
  tools/vision_service/test_forward_timing.py)
q4t_add_python_contract(q4t_tool_recovery_contracts
  tools/examples/test_tool_recovery.py)
q4t_add_python_contract(q4t_project_query_contracts
  tools/examples/test_project_query.py)
q4t_add_python_contract(q4t_application_delivery_contracts
  tools/application_service/test_stage.py)
q4t_add_python_contract(q4t_structured_output_stage_contracts
  tools/structured_output/test_stage.py)
q4t_add_python_contract(q4t_input_contract_stage_contracts
  tools/input_contract/test_stage.py)
q4t_add_python_contract(q4t_serve_resource_stage_contracts
  tools/serve_resources/test_stage.py)
q4t_add_python_contract(q4t_serve_role_stage_contracts
  tools/serve_stage_b1/test_stage.py)
q4t_add_python_contract(q4t_chat_acceptance_contracts
  tools/response_protocol/test_acceptance.py)
q4t_add_python_contract(q4t_recovery_fault_policy_contracts
  tools/serve_recovery/test_policy.py)
q4t_add_python_contract(q4t_recovery_ledger_contracts
  tools/serve_recovery/test_ledger.py)
q4t_add_python_contract(q4t_recovery_journal_contracts
  tools/serve_recovery/test_journal.py)
q4t_add_python_contract(q4t_guardian_runtime_contracts
  tools/serve_recovery/test_runtime.py --guardian $<TARGET_FILE:q4t_guardian>)
q4t_add_python_contract(q4t_recovery_child_contracts
  tools/serve_recovery/test_child.py)
q4t_add_python_contract(q4t_recovery_gateway_contracts
  tools/serve_recovery/test_gateway.py)
q4t_add_python_contract(q4t_native_ingress_contracts
  tools/serve_recovery/test_native_ingress.py --ingress $<TARGET_FILE:q4t_ingress>)
if(Q4T_ENABLE_NATIVE_TLS)
  set(Q4T_NODE_SDK_DIR "${CMAKE_CURRENT_BINARY_DIR}/sdk" CACHE PATH
    "Official pinned SDK installed from tools/serve_protocol/package-lock.json")
  q4t_add_python_contract(q4t_native_access_contracts
    tools/serve_recovery/test_native_access.py --ingress $<TARGET_FILE:q4t_ingress>
    --no-tls-ingress $<TARGET_FILE:q4t_ingress_no_tls>
    --host-tests $<TARGET_FILE:q4t_host_tests>)
  set_property(TEST q4t_native_access_contracts APPEND PROPERTY
    ENVIRONMENT "Q4T_NODE_SDK_DIR=${Q4T_NODE_SDK_DIR}")
endif()
q4t_add_python_contract(q4t_native_bundle_contracts
  tools/serve_recovery/test_native_bundle.py)
q4t_add_python_contract(q4t_native_admission_contracts
  tools/serve_recovery/test_native_admission.py --ingress $<TARGET_FILE:q4t_ingress>)
q4t_add_python_contract(q4t_recovery_production_contracts
  tools/serve_recovery/test_production.py)
q4t_add_python_contract(q4t_recovery_observation_io_contracts
  tools/serve_recovery/test_observation_io.py)
q4t_add_python_contract(q4t_recovery_acceptance_contracts
  tools/serve_recovery/test_acceptance.py)
# A build of Python can omit pidfd APIs despite a new version number. Probe the
# guard's actual contract before assigning its real descendant-cleanup tests.
set(Q4T_GPU_GUARD_PYTHON "" CACHE FILEPATH
  "Python interpreter with working pidfd APIs for GPU guard contracts")
if(Q4T_GPU_GUARD_PYTHON)
  set(guard_candidates "${Q4T_GPU_GUARD_PYTHON}")
else()
  set(guard_candidates "${Python3_EXECUTABLE}" /usr/bin/python3 /bin/python3)
endif()
set(guard_probe "import sys; sys.path.insert(0, sys.argv[1]); import gpu_exclusive; gpu_exclusive.require_pidfd_support()")
set(guard_python "")
foreach(candidate IN LISTS guard_candidates)
  execute_process(COMMAND "${candidate}" -B -c "${guard_probe}"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../tools/evalscope"
    RESULT_VARIABLE guard_result OUTPUT_QUIET ERROR_VARIABLE guard_error
    TIMEOUT 10)
  if(guard_result STREQUAL "0")
    set(guard_python "${candidate}")
    break()
  endif()
endforeach()
if(NOT guard_python)
  message(FATAL_ERROR
    "GPU guard requires working pidfd APIs; set Q4T_GPU_GUARD_PYTHON. ${guard_error}")
endif()
message(STATUS "GPU guard Python: ${guard_python}")
block()
  set(Python3_EXECUTABLE "${guard_python}")
  q4t_add_python_contract(q4t_gpu_exclusive_contracts
    tools/evalscope/test_gpu_exclusive.py)
  q4t_add_python_contract(q4t_managed_telemetry_contracts
    tools/serve_service/test_telemetry.py)
  q4t_add_python_contract(q4t_nvml_classification_contracts
    tools/serve_service/test_nvml_policy.py)
  q4t_add_python_contract(q4t_nvml_query_contracts
    tools/evalscope/test_nvml_process_query.py)
  q4t_add_python_contract(q4t_monitor_resume_contracts
    tools/serve_service/test_monitor_recovery.py)
  q4t_add_python_contract(q4t_auxiliary_isolation_contracts
    tools/serve_service/test_auxiliary.py)
  q4t_add_python_contract(q4t_resource_control_isolation_contracts
    tools/serve_service/test_resource_control.py)
  q4t_add_python_contract(q4t_managed_telemetry_exit_contracts
    tools/serve_service/test_nvml_acceptance.py)
endblock()
q4t_add_python_contract(q4t_request_cancellation_contracts
  tools/evalscope/test_request_cancellation.py)
q4t_add_python_contract(q4t_supervisor_contracts
  tools/release/test_supervisor.py)
q4t_add_python_contract(q4t_audit_rollback_contracts
  tools/verify/audit_p2/test_rollback.py)

q4t_add_python_contract(q4t_grammar_isolation_stage_contracts
  tools/grammar_isolation/test_stage.py)

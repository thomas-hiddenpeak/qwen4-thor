"""Preserve exact business inputs, real replies, source identity and strict lease."""
from pathlib import Path
import json,hashlib,shutil,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=W/'business-01'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(B/'plan.json');r=read(B/'result.json');g=read(B/'lease/exit.json');c=read(B/'cleanup.json')
assert r['status']=='PASS_NATIVE_VIDEO_PROJECTIVE_BUSINESS' and r['counts']['starts']==1 and r['counts']['chats']==4
assert g['status']=='COMPLETED' and g['child_returncode']==0 and g['compute_backend']=='nvml' and g['lease_inherited_by_child'] and not g['external_lease']
assert all(sha(R/name)==digest for name,digest in p['sources'].items()),'source drift'
assert sha(Path(p['binary']))==r['binary_sha256']
events=[json.loads(x) for x in (B/'lease/events.jsonl').read_text().splitlines()]
a=[x for x in events if x.get('event')=='lease_acquired'];z=[x for x in events if x.get('event')=='lease_released'];assert len(a)==len(z)==1 and a[0]['pid']==z[0]['pid'] and z[0]['status']=='COMPLETED'
queries=[json.loads(x) for x in (B/'lease/nvml-queries.jsonl').read_text().splitlines()]
assert queries and all(x['status']=='OK' and x['returncode']==0 for x in queries)
assert c['ports_released'] and not c['remaining'] and c['model_exit']==0 and c['lease_continuously_held'],c
seconds=z[0]['monotonic']-a[0]['monotonic'];assert seconds<600
accepted=dict(status='ACCEPT_NATIVE_VIDEO_PROJECTIVE_BUSINESS',binary_sha256=r['binary_sha256'],source_commit=p['source_commit'],accepted_starts=1,accepted_requests=4,cumulative_starts=1,cumulative_requests=4,cumulative_lease_seconds=seconds,cumulative_wrapper_seconds=read(W/'business-gpu-01.json')['seconds'],nvml_ok_samples=len(queries),cleanup_complete=True,cleanup=c,default_unchanged=True,stage_sources_verified=len(p['sources']),runtime_accepted=True,business=read(B/'business-summary.json'),full_model_quality=False,performance_acceptance=False,service_delivery_pending=True,master_complete=False)
O=R/'docs/evidence/serve-video-projective-business-20261117';O.mkdir(exist_ok=True);assert not (O/'records.tar.gz').exists()
for n in ['plan.json','result.json','business-summary.json','cleanup.json','capabilities.json','config.json']:shutil.copyfile(B/n,O/n)
files=[(p.name,p) for p in B.iterdir() if p.is_file()]+[('lease/'+p.name,p) for p in (B/'lease').iterdir() if p.is_file()]
for n in ['business-prepare-01.json','business-gpu-01.json','business-gpu-01.stdout','business-gpu-01.stderr','archive_business.py','archive_business-01.py','archive_business-02.py','archive-business-repair.json']:files.append((n,W/n))
# This direct loopback stage uses no credentials. Exclude private store data;
# only the explicitly listed top-level request/response/diagnostic files enter.
for n,path in files:
 data=path.read_bytes()
 if path.suffix != '.py':assert b'BEGIN PRIVATE KEY' not in data and b'Authorization: Bearer' not in data,n
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,path in sorted(files):tar.add(path,arcname=name,recursive=False)
accepted['archive_sha256']=sha(O/'records.tar.gz')
(W/'feature-acceptance.json').write_text(json.dumps(accepted,indent=2)+'\n');(O/'acceptance.json').write_text(json.dumps(accepted,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生有限透视视频真实业务接受\n\n非单位齐次比例JSON、透视SSE与删除原上传后的冻结历史SSE均实际\n正确报告四象限及画幅。input_tokens与实际usage相同；奇异矩阵\n局部400后同PID普通问答42通过。使用原H264压缩像素和原问题，\n显式high细节；没有将预变换PNG或预期答案提供给模型。\n\n1启动4生成，{seconds:.3f}秒严格租约，{len(queries)}项NVML正常。自有模型/\nworker全部退出，端口与锁已释放。源码身份与候选7f25058d核对；\n默认rev244保持。20项针对性CPU按原身份复用，不作完整模型质量、\n性能或长稳结论。继续主轻/保留包组合、可回退发行及实际合main；\n其他媒体/后端、历史质量失败和全部master任务继续。\n''')
print(json.dumps({k:accepted[k] for k in ['status','cumulative_lease_seconds','nvml_ok_samples','stage_sources_verified']}))

"""Three bounded, independently leased actual registered-voice recovery stages; stop on any failure."""
import hashlib,json,os,signal,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
protected=['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']
def defaults():return {n:sha(R/n) for n in protected}
F=W/'service-sequence-plan-03.json'
assert not F.exists()
assert shutil.disk_usage(W).free>=268*1024**2
frozen=dict(status='FROZEN_BEFORE_EXECUTION',scope='Only remaining already-frozen whole-payload stage. Retained14 and TLS25 requests already finalized; no repeat. Prior outer sequence stopped before this stage because disk headroom fell below 256MiB. Original aggregate remains4starts/63posts/1500s. One retained modern controller serves automatic payload and stopped root rollback. Same registered IDs, independent ASR, full history, cross-client and final revocation are exercised before/after actual recovery. Existing native input/TTS and TLS SDK obligations remain. No full numerical/performance/long stability matrix.',aggregate_limits=dict(model_starts=2,counted_posts=24,cuda_probes=1,seconds=600),stage_artifact_limit=32*1024**2,aggregate_artifact_limit=96*1024**2,min_free_before_stage=256*1024**2,initial_free=shutil.disk_usage(W).free,defaults=defaults(),stage_plan_hashes={n:sha(W/n/'plan.json') for n in ['version-service-01']},pending_version_plan=dict(scenario='tool_version',starts=2,chats=24,probes=1,seconds=600,depends_on='finalized retained-service-02 receipt'),driver_sha256=sha(Path(__file__)),automatic_request_retry=False)
save(F,frozen);records=[]
def call(label,command,seconds):
 start=time.monotonic();timed_out=False
 with (W/(label+'.stdout')).open('xb') as stdout,(W/(label+'.stderr')).open('xb') as stderr:
  child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=child.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 value=dict(label=label,command=command,returncode=code,seconds=time.monotonic()-start,timed_out=timed_out);records.append(value);save(W/'service-sequence-result-03.json',records);print(json.dumps(value),flush=True)
 if code or timed_out:
  print((W/(label+'.stderr')).read_text()[-2500:],flush=True);raise SystemExit(code or 1)
 return value

def run(name):
 out=W/name;plan=read(out/'plan.json');assert defaults()==frozen['defaults'];assert shutil.disk_usage(W).free>=frozen['min_free_before_stage']
 scope=dict(plan_sha256=sha(out/'plan.json'),limits=plan['limits'],max_artifact_bytes=frozen['stage_artifact_limit'],default_identity=frozen['defaults'],initial_free=shutil.disk_usage(W).free,strict_complete_stage_lease=True)
 save(out/'resource-scope.json',scope)
 command=['/usr/bin/python3','-B',str(R/'tools/evalscope/gpu_exclusive.py'),'--compute-backend','nvml','--inherit-lease','--output',str(out/'lease'),'--',*plan['command']]
 save(out/'lease-command.json',command)
 record=call(name+'-launch',command,plan['limits']['seconds']+60);save(out/'launch.json',record)
 result=read(out/'execution/result.json');print(json.dumps(dict(stage=name,status=result['status'],seconds=result['seconds'],counts=result['budget']['counts'])),flush=True)
 call(name+'-finalize',['/usr/bin/python3','-I','-B',str(R/'tools/native_asr/service_acceptance.py'),'finalize','--plan',str(out/'plan.json')],120)
 size=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert size<=frozen['stage_artifact_limit'];assert defaults()==frozen['defaults'];save(out/'resource-result.json',dict(status='PASS',artifact_bytes=size,default_unchanged=True,free=shutil.disk_usage(W).free));print(read(out/'decision.json')['acceptance'],flush=True)

run('version-service-01')
print('FROZEN_VOICE_VERSION_STAGE_FINALIZED',flush=True)

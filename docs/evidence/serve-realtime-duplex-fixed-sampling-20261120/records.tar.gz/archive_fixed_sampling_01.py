from pathlib import Path
import hashlib
import json
import tarfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).parent
B = W/'fixed-sampling-01'
O = R/'docs/evidence/serve-realtime-duplex-fixed-sampling-20261120'
O.mkdir()
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
save = lambda p,v: p.write_text(json.dumps(v, indent=2, ensure_ascii=False)+'\n')
comparison = read(B/'comparison.json')
assert comparison['environment']['status'] == 'PASS'
assert all(comparison['after_unrelated_request_exact'].values())
assert all(comparison['primary_light_exact'].values())
plan = read(B/'plan.json')
assert all(sha(R/n) == h for n,h in plan['sources'].items())
assert all(sha(R/n) == h for n,h in plan['protected'].items())
token = read(B/'client-policy.json')['gateway_token'].encode()
paths = [p for p in B.iterdir() if p.is_file() and p.name != 'client-policy.json']
paths += [p for p in (B/'lease').iterdir() if p.is_file()]
paths += [p for p in (W/'audio-boundary-prompt-01').iterdir() if p.is_file() and p.name != 'probe']
paths += [W/'diagnose_profile_sampling_01.py', Path(__file__)]
rows, omitted = [], []
with tarfile.open(O/'records.tar.gz', 'w:gz') as tar:
    for p in paths:
        if token in p.read_bytes():
            omitted.append(dict(path=str(p.relative_to(W)), sha256=sha(p), reason='private token'))
            continue
        name = str(p.relative_to(W))
        tar.add(p, arcname=name, recursive=False)
        rows.append(dict(path=name, bytes=p.stat().st_size, sha256=sha(p)))
save(O/'index.json', dict(records=rows, omitted=omitted, archive_sha256=sha(O/'records.tar.gz')))
review = {k:v for k,v in comparison.items() if k != 'rows'}
review.update(run=read(B/'result.json'), default_unchanged=True, model_quality_repaired=False,
              master_active=True, actual_seed41='甚至出现', actual_seed42='甚至出现交易几乎停滞的情况。')
save(O/'review.json', review)
(O/'README.md').write_text('''# 两档固定输入与请求间隔离诊断

2026-11-20，实际候选485a38a3。同一严格租约2模型、8HTTP、97.681秒，
92次NVML正常，两模型退出0、所属进程/端口/锁释放，默认rev376保持。
每档依次执行inline/seed41、独立工具请求/41、再次inline/41、inline/42。
所有回答和返回的selected/top-logprob逐项相同；仅忽略工具随机call ID。
插入独立工具请求前后，seed41回答和返回概率逐项相同。

两档seed41都只回答“甚至出现”，seed42都完整复述。诊断未显示本组
输入的轻量计算或请求状态污染；不能外推为全部隐藏logits/全部请求
等价，也不能把采样失败改记成功。当前重复指令包含无关READY分支，
首token候选中READY仍有约9.3%概率；这是客户端任务说明的竞争来源，
不是已证明的唯一根因。没有修改服务默认采样或挑选有利种子验收。

下一步只补原轻量失败任务：客户端逐轮明确当前任务，真实工具结果
使用显式历史引用；打断以实际输出音频触发，避免计数回答提前结束。
保留原错误答案，不重跑已通过的主档或整组场景。恢复/交付及master继续。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
entry = '''
[固定采样诊断](evidence/serve-realtime-duplex-fixed-sampling-20261120/README.md)：
2模型/8HTTP/97.681秒，92NVML正常、清理通过。两档返回的token及
概率一致，工具请求前后相同seed结果也一致；seed41均缺句、seed42
均完整。未观察到本组执行/状态差异，原质量FAIL保持。只完善客户端
任务说明和实际语音打断前提，再补轻量失败项；默认rev376保持。
'''
p = R/'docs/STATUS.md';s = p.read_text();i = s.index('\n## 当前实际默认');p.write_text(s[:i]+entry+s[i:])
p = R/'docs/log/2026-11-20.md';s = p.read_text();i = s.index('\n')+1
p.write_text(s[:i]+'''
## 两档固定采样与插入工具请求诊断完成

日期：2026-11-20。

做了什么：2模型/8HTTP/97.681秒、92NVML正常，两档实际输出与返回
概率逐项相同，工具请求前后同seed也相同，清理与默认保护通过。
seed41均缺句、seed42均完整，原错答保持；没有证明模型质量修复。

为什么：先区分轻量执行/状态和随机质量，避免反复整组采样求通过。
范围仅覆盖原始记录中的实际返回概率，未声称全隐藏logits等价。

下一步：轻量失败任务明确每轮指令/工具引用，以真实音频验证打断，
不改默认采样；继续恢复/交付和全部master。
''' + s[i:])
p = R/'docs/serve-master-goals-v2.json';v = read(p)
v['realtime_progress']['duplex_input_20261120'].update(
    state='fixed_sampling_equal_profiles_original_quality_fail_targeted_client_work_pending',
    fixed_sampling=dict(evidence=str(O.relative_to(R)/'README.md'), result=review))
save(p,v)
print(json.dumps(dict(archived=str(O), bytes=(O/'records.tar.gz').stat().st_size)))

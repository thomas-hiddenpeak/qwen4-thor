"""Fixed-input primary/light sampling and inter-request isolation diagnosis.

Two models, eight HTTP requests, 900 seconds in one strict lease. Each profile
runs inline seed41, a separate forced tool query, inline seed41 again, then
inline seed42. Capture real selected/top log probabilities; never retry. This
is diagnostic evidence, not duplex qualification or a model quality waiver.
"""
import argparse
import copy
import http.client
import json
from pathlib import Path
import runpy
import signal
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
WORK=Path(__file__).parent
P=runpy.run_path(str(WORK/'audio_boundary_business_01.py'))
prior,full,encrypted=P['prior'],P['full'],P['encrypted']
read,save,sha,require=P['read'],P['save'],P['sha'],P['require']
LIMITS=dict(starts=2,chats=8,controls=600,seconds=900)
FORMAT='q4t-duplex-fixed-logprob-diagnosis-v1'
SUCCESS='PASS_DIAGNOSTIC_COLLECTION'
ROWS=(('inline41','inline',41),('tool41','tool',41),
      ('inline41-after-tool','inline',41),('inline42','inline',42))


def requests():
    values=read(WORK/'audio-boundary-prompt-01/requests.json')
    result={}
    for label,kind,seed in ROWS:
        body=copy.deepcopy(values[kind])
        # Both profiles see identical bounded text work; original audio TTS
        # reserve was 3457 but none of its failed text answers reached 128.
        body.update(seed=seed,max_completion_tokens=128)
        result[label]=body
    return result


def check_plan(plan):
    old=read(WORK/'audio-boundary-business-01/plan.json')
    require(plan['targeted_format']==FORMAT and plan['limits']==LIMITS and
        plan['requests']=={} and plan['diagnostic_requests']==requests() and
        plan['automatic_retries'] is False and
        plan['planned']==dict(starts=2,chats=8), 'fixed diagnostic scope changed')
    for key in ('binary_sha256','identity','profiles','native_assets','model_assets',
                'base','candidate_identity','reviewed_sources'):
        require(plan[key]==old[key],'diagnostic model/capacity changed')
    for name,h in plan['reviewed_sources'].items():require(sha(ROOT/name)==h,'source drift')


def prepare(out):
    require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),
            'commit actual previous outcome first')
    out.mkdir(mode=0o700,parents=True)
    plan=read(WORK/'audio-boundary-business-01/plan.json')
    plan.update(targeted_format=FORMAT,limits=LIMITS,output=str(out),port=18558,
        operations_port=18559,scope=__doc__,diagnostic_requests=requests(),
        planned=dict(starts=2,chats=8),source_commit=subprocess.check_output(
            ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
    plan['sources']={n:sha(ROOT/n) for n in plan['sources']}
    prompt=WORK/'audio-boundary-prompt-01'
    for path in [Path(__file__),*(p for p in prompt.iterdir() if p.is_file() and p.name!='probe')]:
        plan['sources'][str(path.resolve())]=sha(path)
    check_plan(plan);save(out/'plan.json',plan)
    print(json.dumps(dict(plan=str(out/'plan.json'),limits=LIMITS)),flush=True)


class Stage(prior.Stage):
    limits=LIMITS
    success_status=SUCCESS

    def __init__(self,plan):
        check_plan(plan);encrypted.Stage.__init__(self,plan)

    def profile_business(self):
        policy=read(self.out/'client-policy.json')
        for label,_,_ in ROWS:
            prefix=self.profile_name+'-'+label
            body=self.plan['diagnostic_requests'][label]
            save(self.out/(prefix+'-request.json'),body)
            self.budget('chats')
            connection=http.client.HTTPConnection('127.0.0.1',self.plan['port'],timeout=120)
            try:
                connection.request('POST','/v1/chat/completions',json.dumps(body),headers={
                    'Content-Type':'application/json','X-Q4T-Client-Id':encrypted.CLIENT,
                    'X-Q4T-Gateway-Token':policy['gateway_token']})
                response=connection.getresponse();raw=response.read((1<<20)+1)
                (self.out/(prefix+'.wire')).write_bytes(raw)
                require(response.status==200 and len(raw)<=1<<20,'diagnostic HTTP failure')
                value=json.loads(raw)
                save(self.out/(prefix+'-response.json'),value)
            finally:connection.close()
            self.same_model();self.drained(prefix+'-drain')
            choice=value['choices'][0]
            require(choice['logprobs'] is not None and choice['finish_reason'] in ('stop','tool_calls'),
                    'missing actual complete diagnostic probability trace')


def finalize(out):
    plan=read(out/'plan.json');check_plan(plan);result=read(out/'result.json')
    require(result['status']==SUCCESS and result['counts']['starts']==2 and
        result['counts']['chats']==8 and result['seconds']<=900,'incomplete diagnostic run')
    for name,h in {**plan['sources'],**plan['protected'],**plan['native_assets']}.items():
        require(sha(ROOT/name)==h,'postflight source drift')
    lease=out/'lease';queries=[json.loads(l) for l in (lease/'nvml-queries.jsonl').read_text().splitlines()]
    environment=full.environment(read(lease/'exit.json'),queries,
        [read(out/n) for n in ('primary-cleanup.json','cleanup.json')])
    rows={}
    for profile in ('primary','light'):
        rows[profile]={}
        for label,_,_ in ROWS:
            value=read(out/(profile+'-'+label+'-response.json'))['choices'][0]
            rows[profile][label]={k:value[k] for k in ('message','finish_reason','logprobs')}
    def comparable(row):
        value=copy.deepcopy(row)
        for call in value['message'].get('tool_calls',[]):call.pop('id',None)
        return value
    same_profile={name:row['inline41']==row['inline41-after-tool'] for name,row in rows.items()}
    same_capacities={label:comparable(rows['primary'][label])==comparable(rows['light'][label]) for label,_,_ in ROWS}
    save(out/'comparison.json',dict(status=SUCCESS,environment=environment,
        after_unrelated_request_exact=same_profile,primary_light_exact=same_capacities,
        all_original_answers_retained=True,model_quality_acceptance=False,
        ignored_transport_fields=['message.tool_calls[].id'],
        numerical_scope='Observed token choices and returned top-logprob traces, not all hidden logits',
        rows=rows))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('prepare','run','finalize'))
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output.resolve()
    require(out.is_relative_to(WORK.resolve()),'private output directory required')
    if a.mode=='prepare':prepare(out)
    elif a.mode=='finalize':finalize(out)
    else:
        def interrupted(_signum,_frame):raise TimeoutError('bounded diagnostic interrupted')
        signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGALRM,interrupted)
        signal.alarm(900)
        try:Stage(read(out/'plan.json')).run()
        finally:signal.alarm(0)

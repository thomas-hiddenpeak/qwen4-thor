// Reconstruct failed inputs using the production native history/planner.
#include <iostream>
#include "src/server/object_protocol.h"
#include "q4t/server/realtime_conversation.h"
#include "q4t/server/realtime_chat_plan.h"
#include "q4t/server/chat_prompt.h"
using namespace q4t::server;
using namespace q4t::server::object_detail;
int main() {
  std::string line;
  if (!std::getline(std::cin, line)) return 2;
  Json fixture;
  if (!q4t::io::ParseJson(line, &fixture, true)) return 2;
  RealtimeConversation history("reconstructed");
  const auto& item = *fixture.Find("item");
  RealtimeItemTicket ticket;
  if (fixture.GetBool("native", true)) {
    if (!history.ReserveAudioInput(item, "unused", true, 1 << 20, &ticket) ||
        !history.CommitAudioInput(ticket)) return 3;
  } else if (!history.Create(item, "plain", {}, &ticket)) {
    return 3;
  }
  for (const auto& completion : fixture.Find("completions")->array)
    if (!history.CompleteAudioPart(ticket, completion.GetInt("content_index"),
                                   completion.GetString("transcript"))) return 4;
  RealtimeConversationSnapshot snapshot;
  const auto& response = *fixture.Find("response");
  if (!history.Snapshot(response.Find("input"), &snapshot)) return 5;
  ChatPlanConfig config;
  config.model = "qwen3.8-flash-next";
  config.structured = true;
  config.max_len = 8192;
  config.max_prefill = 2048;
  RealtimeChatPlan plan;
  ChatPlanError error;
  auto status = PlanRealtimeChat(*fixture.Find("settings"), response,
                                snapshot.items, config, &plan, &error,
                                nullptr, true);
  if (!status) { std::cerr << status.message(); return 6; }
  const auto& request = plan.generation.generation_request;
  std::string prompt;
  std::vector<VisionItem> media;
  status = PrepareChatPrompt(request, plan.generation.chat.constraints,
                            &prompt, &media, &error.param);
  if (!status) { std::cerr << status.message(); return 7; }
  std::cout << OutputJson(Object({{"request", request},
      {"prompt", String(prompt)}, {"snapshot", snapshot.items}})) << '\n';
}

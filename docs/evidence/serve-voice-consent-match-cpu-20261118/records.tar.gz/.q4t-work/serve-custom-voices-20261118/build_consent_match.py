from pathlib import Path
import subprocess,hashlib,json,re,time,shutil,os
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def edit(n,old,new):
 p=R/n;s=p.read_text();assert s.count(old)==1,(n,s.count(old));write(p,s.replace(old,new))
edit('CMakeLists.txt','  add_library(q4t_text STATIC src/text/tokenizer.cpp\n','  add_library(q4t_text STATIC src/text/tokenizer.cpp\n    src/text/voice_consent.cpp\n')
edit('cmake/ChatProtocolIdentity.cmake','  include/q4t/text/tokenizer.h','  include/q4t/text/voice_consent.h\n  src/text/voice_consent.cpp\n  include/q4t/text/tokenizer.h')
edit('cmake/NativeTtsTests.cmake','if(TTS_ICU_FOUND)\n','if(TTS_ICU_FOUND)\n  # Consent comparison reuses the inference tokenizer\'s ICU dependency.\n  add_executable(q4t_voice_consent_tests EXCLUDE_FROM_ALL\n    ${tts_test_root}/tests/test_main.cpp\n    ${tts_test_root}/tests/voice_consent_test.cpp\n    ${tts_test_root}/src/text/voice_consent.cpp)\n  target_include_directories(q4t_voice_consent_tests PRIVATE\n    ${tts_test_root}/include ${TTS_ICU_INCLUDE_DIRS})\n  target_link_libraries(q4t_voice_consent_tests PRIVATE ${TTS_ICU_LINK_LIBRARIES})\n  target_compile_options(q4t_voice_consent_tests PRIVATE -Wall -Wextra -Werror)\n')
files=['include/q4t/text/voice_consent.h','src/text/voice_consent.cpp','tests/voice_consent_test.cpp']
for n in files:
 p=R/n;r=subprocess.run(['clang-format',str(p)],capture_output=True,check=True);t=p.with_suffix(p.suffix+'.edit');t.write_bytes(r.stdout);t.replace(p)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
required=re.findall(r'Q4T_TEST\(\s*([a-z0-9_]+)\s*\)',(R/'tests/voice_consent_test.cpp').read_text());assert len(required)==8
plan={'scope':'Strict independently-recognized consent text comparison, trusted expected phrase never provided to ASR','cases':8,'seconds':60,'required':required,'model_loads':0,'gpu_actions':0,'disk_reserve_bytes':256<<20,'max_artifact_bytes':4<<20,'source_sha256':{n:sha(R/n) for n in files},'normalization':'strict UTF8, NFC and full case fold, omit punctuation/whitespace only; keep letters/digits/marks/order/negation; reject hidden formatting and confusables','not_claimed':['real ASR audio verification','same-speaker identity verification','language phrase catalog or full Voice HTTP']}
(V/'consent-match-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
note='''真实consent核验的文本比较层已实现：复用现有ICU，规范Unicode\n大小写与标点空格；否定词、附加语句、字母/声调与顺序保留，隐藏\n字符及伪字母拒绝。冻结8 CPU/60秒、0模型/GPU；预期短语仅由\n服务端提供，不能送给ASR或取自请求。真实录音/同人验证继续。\n\n'''
p=R/'docs/STATUS.md';s=p.read_text();write(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：真实授权核验的Unicode文本比较开发\n\n'+note+'24kHz检查点525ceda9已推送。下一步针对CPU后接真实模型与授权\n目录；此处文本相同不能单独当作授权和身份验收。\n\n'+s.split('\n',1)[1].lstrip('\n'))
O=V/'consent-match-build-01';O.mkdir(exist_ok=False);assert shutil.disk_usage(R).free>=256<<20
commands=[['cmake','-S','tests/host','-B','.q4t-work/serve-file-search-20261112/host'],['cmake','--build','.q4t-work/serve-file-search-20261112/host','--target','q4t_voice_consent_tests','--parallel','4']];start=time.monotonic();steps=[]
with (O/'build.log').open('wb') as f:
 for cmd in commands:
  r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=180);steps.append({'command':cmd,'returncode':r.returncode})
  if r.returncode:break
result={'status':'PASS_BUILD_ONLY' if r.returncode==0 else 'FAIL_BUILD','seconds':time.monotonic()-start,'commands':steps,'warnings':(O/'build.log').read_text().count('warning:')};binary=R/'.q4t-work/serve-file-search-20261112/host/q4t_voice_consent_tests'
if r.returncode==0:result['binary_sha256']=sha(binary)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert r.returncode==0
O=V/'consent-match-cpu-01';O.mkdir(exist_ok=False);(O/'required.txt').write_text('\n'.join(required)+'\n');start=time.monotonic()
cmd=[str(binary),'--required-list',str(O/'required.txt')]
with (O/'test.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=60)
result={'status':'PASS' if r.returncode==0 else 'FAIL','seconds':time.monotonic()-start,'returncode':r.returncode,'cases':8,'model_loads':0,'gpu_actions':0,'command':cmd,'binary_sha256':sha(binary),'plan_sha256':sha(V/'consent-match-plan-01.json')};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)

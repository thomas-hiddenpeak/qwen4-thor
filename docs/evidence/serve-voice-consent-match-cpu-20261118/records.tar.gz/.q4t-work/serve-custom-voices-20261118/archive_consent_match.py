from pathlib import Path
import json,hashlib,tarfile,sys
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';E=R/'docs/evidence/serve-voice-consent-match-cpu-20261118'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
sys.path.insert(0,str(R));from tools.serve_audit.check_inventory import current_surface,check,mutation_checks
surface=current_surface(R);p=R/'tools/serve_audit/inventory.json';inv=read(p);changes={n:{'old':inv['sources_sha256'].get(n),'new':h} for n,h in surface['sources_sha256'].items() if inv['sources_sha256'].get(n)!=h}
expected={'include/q4t/text/voice_consent.h','src/text/voice_consent.cpp','CMakeLists.txt','cmake/ChatProtocolIdentity.cmake'};assert set(changes)==expected,changes
review={'sources':changes,'scope':'strict recognized consent comparison using existing inference ICU','contracts':['UTF8 scalar validity and no invisible controls','NFC and casefold, remove punctuation/space only, preserve letters/numbers/marks/order/negation','actual ASR does not receive expected phrase; request must not control catalog','text equality alone does not prove waveform, voice identity or publish authority']}
(V/'consent-match-source-review-01.json').write_text(json.dumps(review,indent=2)+'\n')
for n,d in changes.items():inv['sources_sha256'][n]=d['new']
inv['native_voice_consent_match_2026_11_18']={'state':'CONSENT_TEXT_COMPARISON_CPU_QUALIFIED_AUDIO_PENDING','evidence':['docs/evidence/serve-voice-consent-match-cpu-20261118/README.md'],'reviewed_sources':sorted(changes),'runtime_api_accepted':False};write(p,json.dumps(inv,ensure_ascii=False,indent=2)+'\n');assert not check(inv,surface);mutations=mutation_checks(inv,surface)
(V/'consent-match-inventory-01.json').write_text(json.dumps({'inventory_current':True,'source_anchors':len(surface['sources_sha256']),'mutation_checks':mutations},indent=2)+'\n')
E.mkdir(exist_ok=False);files={R/n for n in expected|{'tests/voice_consent_test.cpp','cmake/NativeTtsTests.cmake'}}
for folder in ['consent-match-build-01','consent-match-cpu-01']:
 files|={p for p in (V/folder).iterdir() if p.is_file()}
for name in ['consent-match-plan-01.json','consent-match-source-review-01.json','consent-match-inventory-01.json','build_consent_match.py','archive_consent_match.py']:files.add(V/name)
index={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}
with tarfile.open(E/'records.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(R)),recursive=False)
(E/'index.json').write_text(json.dumps(index,indent=2)+'\n');result=read(V/'consent-match-cpu-01/result.json');before=read(V/'audio-24k-cpu-01/result.json')['default_after'];after={n:sha(R/n) for n in before};assert before==after
result.update(state='CONSENT_TEXT_COMPARISON_CPU_QUALIFIED_AUDIO_PENDING',build=read(V/'consent-match-build-01/result.json'),archive_sha256=sha(E/'records.tar.gz'),archive_files=len(index),default_before=before,default_after=after,default_unchanged=True,full_task_complete=False)
(E/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(E/'README.md').write_text('''# 授权录音文本比较：8项CPU通过

8项针对检查全过，0.003386秒，必要构建2.233秒零警告；0模型/GPU。
复用推理tokenizer已依赖的ICU，不新增语言处理服务或Python路径。
[结果](result.json)、[身份](index.json)、[源码与记录](records.tar.gz)。

独立ASR转写只可在大小写、规范Unicode、标点和空格上与服务端
可信短语不同。否定、附加内容、换词、截断、字母顺序、数字及语音
组合符号都保留；隐藏格式字符、伪字母及坏UTF8拒绝。错误不发布
半成品比较结果，正常不匹配与输入/依赖失败分开。中英文、重音/
规范组合、Hindi元音、否定及附加内容反例已覆盖。

这个组件不读取音频或鉴定人物。调用方仍须独立识别实际录音、
核对样本与consent的同一说话人，再原子登记；预期短语不能传入
ASR或由HTTP请求选择。可信短语目录、实际后端/HTTP及有状态回退
继续。默认rev316的五份身份保持，全部master仍active。
''')
note='''[consent文本比较8项CPU通过](evidence/serve-voice-consent-match-cpu-20261118/README.md)：
0.003386秒，构建2.233秒零警告；0GPU、默认保持。Unicode规范\n差异允许，否定/附加内容/换词/截断、隐藏字符及伪字母反例通过。\n只验证独立ASR后比较合同，真实录音/说话人及HTTP登记继续。\n\n'''
p=R/'docs/STATUS.md';s=p.read_text();write(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：真实授权文本比较8项CPU通过\n\n'+note+'只复用现有ICU，不添加服务依赖；下一步可信短语目录、实际模型\n核验及Base按需执行，不把文本匹配视作人物授权证明。\n\n'+s.split('\n',1)[1].lstrip('\n'))
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['native_tts_progress']['custom_voice']['consent_match']={'state':result['state'],'evidence':str((E/'README.md').relative_to(R/'docs')),'cpu_cases':8,'gpu_loads':0};write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':result['state'],'archive_files':len(index),'source_anchors':len(surface['sources_sha256']),'mutation_checks':mutations}))

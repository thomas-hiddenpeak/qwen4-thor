from pathlib import Path
import hashlib,json,subprocess,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-mcp-sdk-followup-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
cpu=read(W/'sdk-cpu-02/result.json');assert cpu['status']=='PASS'
files={'archive_sdk_failure_01.py':Path(__file__)}
for n in ('plan.json','result.json','stdout.txt','stderr.txt'):files['sdk-cpu-02/'+n]=W/'sdk-cpu-02'/n
for n,h in cpu['sources'].items():assert sha(R/n)==h;files['source/'+n]=R/n
for stage in ('sdk-business-01','sdk-business-02'):
 names=['plan.json','lease/exit.json','lease/events.jsonl','lease/nvml-queries.jsonl']
 names += ['preflight-failure.json'] if stage.endswith('01') else ['result.json','counts.json','cleanup.json','primary-mcp.sdk.json','primary-mcp.events.jsonl','primary-mcp.stderr','primary-peer-results.json','primary-config.json','primary-capabilities.json']
 for n in names:files[stage+'/'+n]=W/stage/n
old=W/'sdk-original-source';old.mkdir()
for n in cpu['sources']:
 p=old/n;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(subprocess.check_output(['git','show','c07aec0aa:'+n],cwd=R))
 assert sha(p)==read(W/'sdk-cpu-01/result.json')['sources'][n]
 files['original-source/'+n]=p
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_FOLLOWUP_VERIFIER_CPU_REAL_BUSINESS_INCOMPLETE',cpu_tests=14,cpu_seconds=cpu['seconds'],original_business_status='FAILED',original_model_starts=1,original_model_jobs=4,original_seconds=read(W/'sdk-business-02/result.json')['seconds'],original_nvml_samples=53,original_model_exit=0,prior_launcher_model_starts=0,original_failed_answer_preserved=True,runtime_unchanged=True,followup_budget=dict(starts=2,model_jobs=5,seconds=900),master_goal_active=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP业务失败保留与针对性补验准备

2026-11-20。首次入口漏`--inherit-lease`，0模型/0请求退出。纠正后
实际主档1启动/4生成/54.970秒：工具真实读取、模型标题/引用回答、
审批拒绝及目录故障正常；最后普通问答仅覆盖系统指令、未新增用户
轮次，错答并在32token预算处返回合法incomplete。原驱动因此FAIL，
该失败及错误答案保留，不追认其已通过。53次NVML均正常，模型
正常退出，进程/端口清理完成。原失败驱动未保存最后用量快照，
不能将该项结算宣称通过；补驱动使失败时也先保留实际结算。

14项CPU反例通过：新增任务必须在生成前成为真实user消息；合法
预算截断的协议语义与模型质量分别记录，截断答案仍不通过质量。
运行时与默认采样未改。原前三项业务复用，补验冻结2启动/5生成/
900秒：主档只做一次新user任务，认证原成功/拒绝工具历史并再次
触发目录故障；轻档做尚未执行的四项。不同阶段分别保留租约。

公共归档采用显式文件清单；不含私有入口配置、证书私钥、MCP策略
和对象存储。原完整现场在本机私有阶段目录保留。当前默认rev396
保持，总目标active；补验和恢复交付尚未完成。

[结果](acceptance.json) · [索引](index.json) · [原失败和CPU记录](records.tar.gz)。
''')
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[首轮实际业务与14项补验CPU](evidence/serve-realtime-mcp-sdk-followup-cpu-20261120/README.md)
保留原FAIL：主档真实工具及文档回答通过，末条普通问答错答/32token
截断；新增任务补实际user轮次，运行时与默认采样保持。补验限定
2启动/5生成/900秒：主档1条新user任务并认证原成功/拒绝历史、再验
目录故障；轻档4条原未执行任务。原前三项不重跑，不追认原质量通过。
''')
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m.update(state='real_primary_tool_loop_observed_ordinary_quality_failed_targeted_followup_prepared',first_sdk_business=a,first_sdk_evidence='evidence/serve-realtime-mcp-sdk-followup-cpu-20261120/README.md');save(p,d)
print(json.dumps(a))

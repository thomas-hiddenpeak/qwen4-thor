import hashlib
import json
import os
import subprocess
import tarfile
import time
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
S = W/'validation-src'
O = W/'frozen-handoff-01'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def protected():
    return {str(R/n): sha(R/n) for n in (
        'build/q4t', 'build/q4t.release.json', 'build/service/manifest.json',
        'build/service.release.json', 'build/service-native-state/ledger.json')}
os.umask(0o077)
assert not S.exists() and not O.exists()
before = protected()
v = read(W/'delivery-01/result.json')
assert v['status'] == 'PASS_STOP_COMBINATIONS_DELIVERED'
current = v['publication']['current']
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
O.mkdir()
with (O/'worktree.stdout').open('x') as out, (O/'worktree.stderr').open('x') as err:
    subprocess.run(['git','worktree','add','--detach',str(S),commit], cwd=R,
                   stdout=out, stderr=err, check=True, timeout=120)
package = Path(current['package'])
links = {'q4t': package/'engine/q4t',
         'q4t.release.json': package/'engine/q4t.release.json',
         'service': package,
         'service.release.json': W/'delivery-01/candidate-service.release.json'}
(S/'build').mkdir()
for name, path in links.items():
    (S/'build'/name).symlink_to(path)
assert subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=S,text=True).strip() == str(R/'.git')
steps = []
for name, argv in (
    ('prepare', ['/usr/bin/python3','-I','-B','tools/serve_soak/native_stage.py',
                 'prepare','--profile','day','--package','build/service',
                 '--output','.q4t-work/day-01']),
    ('check', ['/usr/bin/python3','-I','-B','tools/serve_soak/native_stage.py',
               'check','--plan','.q4t-work/day-01/plan.json'])):
    start = time.monotonic()
    with (O/(name+'.stdout')).open('x') as out, (O/(name+'.stderr')).open('x') as err:
        result = subprocess.run(argv,cwd=S,stdout=out,stderr=err,timeout=90)
    step = dict(name=name,argv=argv,cwd=str(S),exit_code=result.returncode,
                seconds=time.monotonic()-start)
    (O/(name+'.json')).write_text(json.dumps(step,indent=2)+'\n')
    steps.append(step)
    assert result.returncode == 0, name
assert protected() == before
plan = read(S/'.q4t-work/day-01/plan.json')
assert plan['package']['manifest_sha256'] == current['manifest_sha256']
assert not (S/'.q4t-work/day-01/execution').exists()
a = dict(status='PASS_FROZEN_DAY_HANDOFF',source_commit=commit,workspace=str(S),
         revision=224,package=plan['package'],service_id=plan['service_id'],
         plan=str(S/'.q4t-work/day-01/plan.json'),
         plan_sha256=sha(S/'.q4t-work/day-01/plan.json'),sources=len(plan['sources']),
         links={n:str(p) for n,p in links.items()}, protected_default=before,
         production_unchanged=True,same_git_common_dir=True,steps=steps,
         model_actions=0,executed=False,owner='user')
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
P = R/'docs/evidence/serve-stop-combinations-day-handoff-20261117'
P.mkdir()
with tarfile.open(P/'handoff.tar.gz','w:gz') as tar:
    for p in sorted(O.iterdir()):
        tar.add(p,arcname='review/'+p.name,recursive=False)
    for n in ('plan.json','handoff.json'):
        tar.add(S/'.q4t-work/day-01'/n,arcname=n,recursive=False)
    tar.add(W/'freeze_day.py',arcname='freeze_day.py',recursive=False)
a['archive_sha256'] = sha(P/'handoff.tar.gz')
(P/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(P/'README.md').write_text("""# rev224独立快照长稳交接

当前精确包和源码快照的day prepare/check通过，0模型动作，未占GPU。
后续开发不改变本计划；共享跨worktree的严格GPU锁。24小时仍由用户
显式执行，未安装后台任务；原rev214及更早快照、包和计划保持原身份。
当前功能短验与前驱rev188长稳驱动short分别记录，不替换或冒称实跑。
执行、状态和清理见[交接入口](../../SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)。
""")
p=R/'docs/SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md';s=p.read_text()
start=s.index('当前rev214');end=s.index('## 当前已准备的入口')
s=s[:start]+f"""当前rev224包`{current['manifest_sha256']}`
已完成Stop/结构化输出/私有和媒体缓存、主轻及保留控制组合的真实
功能验收，含原失败累计6启动27请求。原视觉题合法拒绝与脚本错误
保留，前9条独立接受、只补媒体3条；续问EOS不冒称stop命中。
[业务证据](evidence/serve-stop-combinations-business-20261117/README.md)及
[实际交付](evidence/serve-stop-combinations-delivery-20261117/README.md)保留完整界限。
连续60秒长稳驱动短验属于前驱rev188，
[原证据](evidence/serve-native-soak-business-20261116/README.md)按原身份保留。

[当前独立day prepare/check](evidence/serve-stop-combinations-day-handoff-20261117/README.md)
已完成，24小时未运行。快照固定`{commit[:8]}`及rev224包，不依赖活动
工作区和未来默认指针；原rev214及更早快照仍按原身份保留。

"""+s[end:]
s=s.replace('ee49c36a-b9dc-4636-981e-e8e1e78f2b9b',plan['service_id'])
s=s.replace('serve-media-state-cache-20261117/validation-src','serve-stop-combinations-20261117/validation-src')
s=s.replace('此计划继续验证rev214','此计划继续验证rev224').replace('把rev214证据移称新版本证据','把rev224证据移称新版本证据')
s=s.replace('原rev204独立快照、工作区day-01及更早计划保留','原rev214/rev204独立快照、工作区day-01及更早计划保留');p.write_text(s)
p=R/'docs/STATUS.md';s=p.read_text().replace('用户day\n准备新独立快照，原rev214计划保留；','用户day\n新独立快照已prepare/check且未运行，原rev214计划保留；');p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 if task['id']=='Q03':task['current_native_day_handoff']=a|dict(evidence='evidence/serve-stop-combinations-day-handoff-20261117/README.md')
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/log/2026-11-17.md';h,t=p.read_text().split('\n',1);p.write_text(h+"""

## rev224独立长稳交接已固定

2026-11-17：当前精确包及源码detached快照的day prepare/check通过，
0模型动作，默认和账本保持。原rev214及更早快照/计划保留，后续
开发不会漂移用户长稳入口。下一步实际合main和原生网页搜索等
剩余全部master任务；未启动24小时，不把短验说成长稳通过。
"""+t)
print(json.dumps({k:a[k] for k in ('status','source_commit','revision','service_id','sources','model_actions')}))

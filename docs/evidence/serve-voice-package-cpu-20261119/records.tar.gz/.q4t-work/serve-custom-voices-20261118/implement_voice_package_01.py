from pathlib import Path
R=Path.cwd()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def edit(p,a,b):
 s=p.read_text();assert s.count(a)==1,(p,a,s.count(a));write(p,s.replace(a,b))
p=R/'tools/serve_service/package.py'
edit(p,"TTS_LIMITS = dict(max_text_tokens=16384", "NATIVE_TTS_BASE = dict(NATIVE_TTS, model='qwen3-tts-12hz-1.7b-base',\n    revision='fd4b254389122332181a7c3db7f27e918eec64e3',\n    weight_sha256='38fc7fc51c5e776e840414b6fd443962e9411b9654888fd7913e4da643cb857c')\nTTS_LIMITS = dict(max_text_tokens=16384")
edit(p,'def asr_auxiliary_settings(value):','def asr_auxiliary_settings(value, *, voice_registration=False):')
edit(p,"    require('speaker' not in value or {'alignment', 'vad'} <= value.keys(),\n            'speaker requires alignment and VAD backends')", "    require(type(voice_registration) is bool, 'invalid voice registration context')\n    require('speaker' not in value or\n            ('vad' in value and ('alignment' in value or voice_registration)),\n            'speaker requires VAD and either alignment or TTS Base')")
edit(p,'    return asr_auxiliary_settings(result) or None',"    return asr_auxiliary_settings(result, voice_registration=\n        getattr(args, 'tts_base_model_dir', None) is not None) or None")
edit(p,'def asr_settings(value):','def asr_settings(value, *, voice_registration=False):')
edit(p,"    auxiliary = asr_auxiliary_settings({k:v for k,v in value.items() if k in ASR_AUXILIARY})","    auxiliary = asr_auxiliary_settings(\n        {k:v for k,v in value.items() if k in ASR_AUXILIARY},\n        voice_registration=voice_registration)")
edit(p,"def tts_settings(value):\n    require(type(value) is dict and value.keys() == {*NATIVE_TTS, 'directory', 'limits'}\n            and all(value[k] == v for k, v in NATIVE_TTS.items()),", "def tts_settings(value, *, base=False):\n    fixed = NATIVE_TTS_BASE if base else NATIVE_TTS\n    require(type(value) is dict and value.keys() == {*fixed, 'directory', 'limits'}\n            and all(value[k] == v for k, v in fixed.items()),")
edit(p,'             capacity_profile=None, native_embedding=None, native_asr=None, native_tts=None):','             capacity_profile=None, native_embedding=None, native_asr=None,\n             native_tts=None, native_tts_base=None):')
edit(p,'        selected = asr_settings(native_asr)','        selected = asr_settings(native_asr,\n                                voice_registration=native_tts_base is not None)')
edit(p,"        result['native_tts'] = selected\n    return result", "        result['native_tts'] = selected\n    if native_tts_base is not None:\n        selected = tts_settings(native_tts_base, base=True)\n        names = result.get('model_names', dict(name='qwen3.8-flash-next', aliases=[]))\n        require(selected['model'] not in [names['name'], *names['aliases']],\n                'native TTS Base model conflicts with Chat registry')\n        require(native_tts is None or\n                same_json(result['native_tts']['limits'], selected['limits']),\n                'native TTS families must share effective limits')\n        result['native_tts_base'] = selected\n    return result")
edit(p,'            tts_model_dir=None, tts_limits=None):','            tts_model_dir=None, tts_limits=None, tts_base_model_dir=None):')
edit(p,"    require(tts_model_dir is not None or tts_limits is None,", "    require(tts_model_dir is not None or tts_base_model_dir is not None or\n            tts_limits is None,")
edit(p,'    auxiliary = {} if asr_auxiliary is None else asr_auxiliary_settings(asr_auxiliary)',"    auxiliary = {} if asr_auxiliary is None else asr_auxiliary_settings(\n        asr_auxiliary, voice_registration=tts_base_model_dir is not None)")
edit(p,"                          if tts_model_dir is not None else None))", "                          if tts_model_dir is not None else None),\n                      native_tts_base=(dict(NATIVE_TTS_BASE,\n                          directory=str(tts_base_model_dir),\n                          limits=dict(TTS_LIMITS, **(tts_limits or {})))\n                          if tts_base_model_dir is not None else None))")
s=p.read_text();assert s.count("check_asr_declaration(metadata, config['native_asr'])")==2;s=s.replace("check_asr_declaration(metadata, config['native_asr'])","check_asr_declaration(metadata, config['native_asr'],\n                              voice_registration='native_tts_base' in config)")
assert s.count("check_tts_declaration(metadata, config.get('native_tts'))")==2;s=s.replace("check_tts_declaration(metadata, config.get('native_tts'))","check_tts_declaration(metadata, config.get('native_tts'),\n                          config.get('native_tts_base'), config.get('native_asr'))")
s=s.replace("                      config.get('native_tts'))","                      config.get('native_tts'), config.get('native_tts_base'))");write(p,s)
edit(p,'def check_asr_declaration(metadata, selected):\n    selected = asr_settings(selected):','') if False else None
edit(p,'def check_asr_declaration(metadata, selected):\n    selected = asr_settings(selected)','def check_asr_declaration(metadata, selected, *, voice_registration=False):\n    selected = asr_settings(selected, voice_registration=voice_registration)')
s=p.read_text();a=s.index('def check_tts_declaration(metadata, selected):');b=s.index('\ndef check_media_declaration',a)
s=s[:a]+'''def check_tts_capabilities(capabilities, selected, base=None, asr=None):
    speech = capabilities.get('speech', {})
    chat = capabilities.get('chat_audio_output', {})
    registration = capabilities.get('voice_registration', {})
    require(all(type(v) is dict for v in (speech, chat, registration)),
            'invalid native TTS capabilities')
    enabled = selected is not None or base is not None
    if not enabled:
        require(speech.get('enabled') is not True and chat.get('enabled') is not True,
                'package drops configured native TTS backend')
    else:
        fixed = NATIVE_TTS if selected is not None else NATIVE_TTS_BASE
        require(speech.get('enabled') is True and chat.get('enabled') is True and
                all(speech.get(k) == v for k, v in fixed.items()) and
                speech.get('core_health_dependency') is False,
                'accepted engine does not declare configured native TTS identity')
    require(speech.get('registered_custom_voices', False) is (base is not None) and
            speech.get('builtin_enabled', selected is not None) is (selected is not None),
            'package drops or changes a configured native TTS family')
    expected_registration = (base is not None and asr is not None and
                             {'speaker', 'vad'} <= asr.keys())
    require(registration.get('enabled', False) is expected_registration,
            'package changes configured voice registration dependencies')
    if base is not None:
        require(speech.get('registered_voice_model') == NATIVE_TTS_BASE['model'] and
                speech.get('base_revision') == NATIVE_TTS_BASE['revision'] and
                speech.get('base_weight_sha256') == NATIVE_TTS_BASE['weight_sha256'],
                'accepted engine does not declare configured TTS Base identity')
        require(registration.get('owner_scoped') is True and
                registration.get('recheck_consent_per_synthesis') is True and
                registration.get('metadata_requires_healthy_model') is False and
                registration.get('core_health_dependency') is False,
                'voice registration owner/revocation/isolation contract differs')


def check_tts_declaration(metadata, selected, base=None, asr=None):
    check_tts_capabilities(metadata.get('chat_protocol', {}), selected, base, asr)
    configuration = metadata.get('observed_configuration', {})
    for key, value, is_base in (('native_tts', selected, False),
                                ('native_tts_base', base, True)):
        health = configuration.get(key+'_health', {})
        require(type(health) is dict, 'invalid native TTS health')
        if value is None:
            require(health.get('state', 'disabled') == 'disabled',
                    'package drops configured native TTS backend: '+key)
            continue
        value = tts_settings(value, base=is_base)
        require(health.get('model') == value['model'] and
                health.get('core_readiness_dependency') is False and
                health.get('state') in ('configured', 'loading', 'metadata_ready',
                                        'ready', 'degraded') and
                same_json(configuration.get('native_tts_limits'), value['limits']),
                'accepted engine does not declare configured native TTS limits/identity')
    voice = configuration.get('native_voice_health', {})
    require(type(voice) is dict, 'invalid native voice health')
    if base is None:
        require(voice.get('state', 'disabled') == 'disabled',
                'package drops configured native voice condition backend')
    else:
        require(voice.get('model') == NATIVE_TTS_BASE['model']+'-speaker' and
                voice.get('core_readiness_dependency') is False and
                voice.get('state') in ('configured', 'loading', 'metadata_ready',
                                       'ready', 'degraded'),
                'accepted engine does not declare isolated native voice condition')

''' + s[b:];write(p,s)
edit(p,"        selected = asr_settings(cfg['native_asr'])", "        selected = asr_settings(cfg['native_asr'],\n                                voice_registration='native_tts_base' in cfg)")
a="    if 'native_tts' in cfg:\n        selected = tts_settings(cfg['native_tts'])\n        args += ['--tts-model-dir', selected['directory']]\n        for key, value in selected['limits'].items():\n            args += ['--tts-'+key.replace('_', '-'), str(value)]"
b="    tts_limits = None\n    for name, is_base, flag in (('native_tts', False, '--tts-model-dir'),\n                                ('native_tts_base', True, '--tts-base-model-dir')):\n        if name not in cfg:\n            continue\n        selected = tts_settings(cfg[name], base=is_base)\n        require(tts_limits is None or same_json(tts_limits, selected['limits']),\n                'native TTS families must share effective limits')\n        tts_limits = selected['limits']\n        args += [flag, selected['directory']]\n    for key, value in (tts_limits or {}).items():\n        args += ['--tts-'+key.replace('_', '-'), str(value)]"
edit(p,a,b)
for name,parser in [('tools/serve_service/service.py','p'),('tools/serve_recovery/service.py','prepare')]:
 p=R/name;edit(p,f"    {parser}.add_argument('--tts-model-dir', type=Path)",f"    {parser}.add_argument('--tts-model-dir', type=Path)\n    {parser}.add_argument('--tts-base-model-dir', type=Path)")
 s=p.read_text();a='tts_model_dir=args.tts_model_dir,';assert s.count(a)==1;s=s.replace(a,a+'\n'+(' '* (s.split(a)[0].split('\n')[-1].count(' ')))+'tts_base_model_dir=args.tts_base_model_dir,');write(p,s)
p=R/'tools/serve_recovery/bundle.py';edit(p,'            tts_model_dir=None, tts_limits=None):','            tts_model_dir=None, tts_limits=None, tts_base_model_dir=None):');edit(p,'        tts_model_dir=tts_model_dir, tts_limits=tts_limits,','        tts_model_dir=tts_model_dir, tts_limits=tts_limits,\n        tts_base_model_dir=tts_base_model_dir,')
for name,variable in [('tools/serve_recovery/profile_managed_acceptance.py',"base['settings']"),('tools/serve_recovery/outer_acceptance.py','settings'),('tools/serve_recovery/version_acceptance.py','settings')]:
 p=R/name;a=f"        tts_limits={variable}.get('native_tts', {{}}).get('limits'),";b=f"        tts_base_model_dir=(Path({variable}['native_tts_base']['directory'])\n                            if {variable}.get('native_tts_base') else None),\n        tts_limits=({variable}.get('native_tts') or\n                    {variable}.get('native_tts_base', {{}})).get('limits'),";edit(p,a,b)
p=R/'tools/serve_recovery/deployment.py';edit(p,"    asr = old_core['settings'].get('native_asr')", "    base = old_core['settings'].get('native_tts_base')\n    if base is not None:\n        selected = new_core['settings'].get('native_tts_base', {})\n        ledger.require(all(selected.get(k) == base[k] for k in engine.NATIVE_TTS_BASE),\n                       'deployment would remove or change accepted TTS Base model/codec')\n    asr = old_core['settings'].get('native_asr')")
print('package/CLI/owned bundle propagation written; recovery qualification binding pending')

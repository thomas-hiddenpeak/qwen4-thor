from pathlib import Path

def write(p,s):
    q=p.with_name(p.name+'.edit');q.write_text(s);q.replace(p)
p=Path('tools/serve_recovery/profile_evidence.py');s=p.read_text()
a="    fixed = identity['native_tts_base']\n    profile_contract.tts_configuration(fixed, base=True)"
b="""    fixed = identity['native_tts_base']
    profile_contract.tts_configuration(fixed, base=True)
    asr = identity.get('native_asr')
    ledger.require(type(asr) is dict and {'speaker', 'vad'} <= asr.keys(),
                   'voice registration receipt lacks qualified ASR/VAD/speaker')
    profile_contract.asr_configuration(asr, voice_registration=True)"""
assert s.count(a)==1;write(p,s.replace(a,b))
p=Path('tools/serve_recovery/test_voice_profiles.py');s=p.read_text()
s=s.replace('from tools.serve_recovery.test_tts_profiles import TtsProfiles', '''from tools.serve_recovery.test_tts_profiles import TtsProfiles
from tools.serve_recovery.test_speaker_profiles import SpeakerProfiles
from tools.serve_recovery import test_profile_migration as previous
from tools.serve_recovery import profile_policy as policy''')
s=s.replace("        identity = dict(native_tts_base=contract.tts_binding(selected(), base=True))\n", "        identity = dict(native_tts_base=contract.tts_binding(selected(), base=True),\n            native_asr=contract.asr_binding(registration_asr(), voice_registration=True))\n")
s=s.replace("            lambda d:d['chat']['usage']['q4t_audio_synthesis'].update(output_tokens=64),", "            lambda d:d['chat']['usage']['q4t_audio_synthesis'].update(output_tokens=64),\n            lambda d:d['chat'].update(usage=None),\n            lambda d:d['chat']['usage'].update(completion_tokens_details=[]),")
s=s.replace("        value = cpu_record();evidence.voice_business(value, identity)\n", "        value = cpu_record();evidence.voice_business(value, identity)\n        with self.assertRaisesRegex(ValueError, 'lacks qualified'):\n            evidence.voice_business(value, dict(native_tts_base=identity['native_tts_base']))\n")
pos=s.index("\n\nif __name__")
s=s[:pos]+'''
    def voice_registry(self, builtin=False):
        fixture = SpeakerProfiles();fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        _, _, registry, source = fixture.extended()
        registry['identity']['native_tts_base'] = contract.tts_binding(selected(), base=True)
        if builtin:
            registry['identity']['native_tts'] = contract.tts_binding(self.selected())
        records = {n:copy.deepcopy(row['record']) for n,row in source.items()}
        for row in records.values():
            row['format'] = evidence.VOICE_FORMAT
            row['capabilities'].update(capabilities(builtin, registration=True))
            row['business']['voice'] = cpu_record()
            if builtin:
                from tools.serve_recovery.test_tts_profiles import retained
                row['business']['tts'] = retained()[0]
        return registry, previous.bind_records(registry, records)

    def pending_for(self, registry):
        initial = policy.initial(registry, self.stamp(0), self.config)
        return policy.prepare(initial, 'light', 'sustained_memory_pressure',
            self.pending['pending']['request_id'], 7, self.stamp(1))

    def test_minimal_registration_context_is_bound_before_and_after_migration(self):
        before = contract.asr_binding(dict(package.NATIVE_ASR,
            directory='/asr', limits=dict(package.ASR_LIMITS)))
        after = contract.asr_binding(registration_asr(), voice_registration=True)
        self.assertEqual(migration.audio_change(before, after, after_voice=True),
                         (True, False))
        with self.assertRaises(RuntimeError):migration.audio_change(before, after)
        self.assertEqual(migration.audio_change(after, after,
            before_voice=True, after_voice=True), (False, False))
        with self.assertRaises(RuntimeError):
            migration.audio_change(after, after, after_voice=True)
        caps = capabilities(registration=True)
        caps['transcriptions'] = dict(package.NATIVE_ASR, configured=True)
        for name in ('vad', 'speaker'):
            caps['transcriptions'][name] = dict(package.ASR_AUXILIARY[name][0], configured=True)
        caps['transcriptions']['vad']['max_chunks'] = package.VAD_LIMITS['max_chunks']
        normalized = migration.semantic_capabilities(caps)
        self.assertEqual(normalized['voice_registration']['enabled'], dict(enabled=True))
        self.assertTrue(caps['voice_registration']['enabled'])
        inactive = capabilities()
        inactive['speech'].update(enabled=False, registered_custom_voices=False,
            builtin_enabled=False, **package.NATIVE_TTS)
        inactive['chat_audio_output']['enabled'] = False
        self.assertTrue(migration.extends(migration.semantic_capabilities(inactive),
                                         migration.semantic_capabilities(capabilities())))

    def test_base_capacity_change_keeps_consumed_budget_pending_and_original_identity(self):
        registry, rows = self.voice_registry()
        for n in contract.NAMES:
            evidence.validate(rows[n]['record'], registry, n, rows[n]['sha256'])
        pending = self.pending_for(registry)
        newer = copy.deepcopy(registry)
        newer['identity']['native_tts_base']['limits']['max_frames'] = 161
        records = {n:copy.deepcopy(row['record']) for n,row in rows.items()}
        for row in records.values():row['business']['voice']['limits']['max_frames'] = 161
        following = previous.bind_records(newer, records)
        for options in ({}, dict(automatic=True, allow_capacity_change=True)):
            with self.assertRaises(ValueError):
                migration.permit(registry, newer, rows, following, self.config, self.config, **options)
        grant = migration.permit(registry, newer, rows, following, self.config, self.config,
                                 allow_capacity_change=True)
        self.assertEqual(grant['format'], migration.VOICE_FORMAT)
        value = migration.candidate(pending, grant, self.stamp(999999))
        for key in ('history', 'pending', 'not_before_ns', 'selected', 'profiles',
                    'completed_generation', 'light_since_ns'):
            self.assertEqual(value[key], pending[key])
        self.assertEqual(value['clock']['logical_ns'], pending['clock']['logical_ns'])
        self.assertEqual(value['history_bindings'][pending['pending']['request_id']]
                         ['registry_sha256'], contract.digest(registry))
        migration.AuthorizedContract(grant).transition(pending, value)
        for mutate in (lambda d:d.update(automatic=True),
                       lambda d:d.update(to_native_tts_base=None),
                       lambda d:d['to_native_tts_base'].update(weight_sha256='0'*64),
                       lambda d:d.update(to_native_asr=None),
                       lambda d:d.update(to_native_tts_base=copy.deepcopy(d['from_native_tts_base']))):
            bad=copy.deepcopy(grant);mutate(bad)
            with self.assertRaises((ValueError, RuntimeError)):migration.validate(bad)

    def test_both_families_migrate_shared_limits_and_automatic_recovery_keeps_features(self):
        registry, rows = self.voice_registry(builtin=True)
        newer = copy.deepcopy(registry)
        newer['identity'].update(binary_sha256='e'*64, protocol_sha256='f'*64)
        records = {n:copy.deepcopy(row['record']) for n,row in rows.items()}
        following = previous.bind_records(newer, records)
        grant = migration.permit(registry, newer, rows, following,
                                 self.config, self.config, automatic=True)
        self.assertTrue(grant['automatic'])
        self.assertEqual(grant['format'], migration.FORMAT)
        for family in ('native_tts', 'native_tts_base'):
            newer['identity'][family]['limits']['max_frames'] = 161
        for row in records.values():
            for family in ('tts', 'voice'):row['business'][family]['limits']['max_frames'] = 161
        following = previous.bind_records(newer, records)
        grant = migration.permit(registry, newer, rows, following,
                                 self.config, self.config, allow_capacity_change=True)
        self.assertEqual(grant['format'], migration.VOICE_FORMAT)
        bad=copy.deepcopy(grant);bad['to_native_tts']['limits']['max_frames'] = 162
        with self.assertRaisesRegex(ValueError, 'share effective'):migration.validate(bad)
        bad=copy.deepcopy(grant);bad['to_native_tts']=None
        with self.assertRaisesRegex(ValueError, 'accepted TTS'):migration.validate(bad)

    def test_explicit_base_addition_cannot_remove_or_reuse_builtin_only_business(self):
        registry, rows = self.voice_registry()
        grant = migration.permit(self.old, registry, self.first, rows,
            self.config, self.config, allow_capability_extension=True)
        self.assertEqual(grant['format'], migration.VOICE_FORMAT)
        for options in ({}, dict(automatic=True, allow_capability_extension=True)):
            with self.assertRaises(ValueError):
                migration.permit(self.old, registry, self.first, rows,
                    self.config, self.config, **options)
        with self.assertRaises(ValueError):
            migration.permit(registry, self.old, rows, self.first,
                self.config, self.config, allow_capability_extension=True)
        bad=copy.deepcopy(rows)
        del bad['primary']['record']['business']['voice']
        with self.assertRaises(ValueError):
            migration.permit(self.old, registry, self.first, bad,
                self.config, self.config, allow_capability_extension=True)
''' +s[pos:]
write(p,s)

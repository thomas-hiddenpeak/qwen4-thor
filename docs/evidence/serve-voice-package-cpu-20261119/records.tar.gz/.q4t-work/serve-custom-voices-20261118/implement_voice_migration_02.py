from pathlib import Path
p=Path('tools/serve_recovery/profile_migration.py');s=p.read_text()
def replace(a,b):
    global s
    assert s.count(a)==1,(a[:100],s.count(a))
    s=s.replace(a,b)
replace("TTS_CAPACITY_FORMAT = 'q4t-profile-migration-permit-v6'", "TTS_CAPACITY_FORMAT = 'q4t-profile-migration-permit-v6'\nVOICE_FORMAT = 'q4t-profile-migration-permit-v7'")
replace('def tts_capacity_change(before, after):\n    profile_contract.tts_configuration(before)\n    profile_contract.tts_configuration(after)', 'def tts_capacity_change(before, after, *, base=False):\n    profile_contract.tts_configuration(before, base=base)\n    profile_contract.tts_configuration(after, base=base)')
replace('def audio_change(before, after, *, voice_registration=False):\n', 'def audio_change(before, after, *, before_voice=False, after_voice=False):\n')
replace('    profile_contract.asr_configuration(before, voice_registration=voice_registration)\n    profile_contract.asr_configuration(after, voice_registration=voice_registration)', '    profile_contract.asr_configuration(before, voice_registration=before_voice)\n    profile_contract.asr_configuration(after, voice_registration=after_voice)')
replace("    ledger.require(old_base == new_base or\n        (old_base is None and new_base is not None and extension and", "    base_capacity = (tts_capacity_change(old_base, new_base, base=True)\n        if old_base is not None and new_base is not None else False)\n    ledger.require(old_base == new_base or base_capacity or\n        (old_base is None and new_base is not None and extension and")
replace('        voice_registration=old_base is not None and new_base is not None)', '        before_voice=old_base is not None, after_voice=new_base is not None)')
replace('(not (changed or asr_capacity or tts_capacity) or (allow_capacity_change and not automatic))', '(not (changed or asr_capacity or tts_capacity or base_capacity) or\n         (allow_capacity_change and not automatic))')
replace("    return validate(dict(format=TTS_CAPACITY_FORMAT if tts_capacity else", """    voice = (old_base is not None or new_base is not None) and (
        extension or changed or asr_capacity or tts_capacity or base_capacity)
    return validate(dict(format=VOICE_FORMAT if voice else
        TTS_CAPACITY_FORMAT if tts_capacity else""")
replace('if changed or extension or asr_capacity or audio_extension or tts_capacity else {}),', 'if voice or changed or extension or asr_capacity or audio_extension or tts_capacity else {}),')
replace('if extension or asr_capacity or audio_extension or tts_capacity else {}),', 'if voice or extension or asr_capacity or audio_extension or tts_capacity else {}),')
replace('if asr_capacity or audio_extension or tts_capacity else {}),', 'if voice or asr_capacity or audio_extension or tts_capacity else {}),')
replace("                to_native_tts=copy.deepcopy(new_tts)) if tts_capacity else {})))", """                to_native_tts=copy.deepcopy(new_tts)) if voice or tts_capacity else {}),
        **(dict(from_native_tts_base=copy.deepcopy(old_base),
                to_native_tts_base=copy.deepcopy(new_base)) if voice else {})))""")
insert='''def voice_transition(value):
    """Validate family/context changes without losing historical qualification."""
    added = changed = False
    contexts = []
    for prefix in ('from', 'to'):
        builtin, base = (value[prefix+'_native_'+name]
                         for name in ('tts', 'tts_base'))
        for backend, is_base in ((builtin, False), (base, True)):
            if backend is not None:
                profile_contract.tts_configuration(backend, base=is_base)
        ledger.require(builtin is None or base is None or
            builtin['limits'] == base['limits'],
            'voice migration families must share effective limits')
        contexts.append(base is not None)
    ledger.require(any(contexts), 'voice migration lacks a Base binding')
    for name in ('tts', 'tts_base'):
        before, after = (value[prefix+'_native_'+name] for prefix in ('from', 'to'))
        if before is None:
            added |= after is not None
        else:
            ledger.require(after is not None, 'voice migration removes an accepted TTS family')
            changed |= tts_capacity_change(before, after, base=name == 'tts_base')
    before, after = (value[prefix+'_native_asr'] for prefix in ('from', 'to'))
    if before is None:
        if after is not None:
            profile_contract.asr_configuration(after, voice_registration=contexts[1])
            added = True
    else:
        ledger.require(after is not None, 'voice migration removes accepted ASR')
        audio_added, audio_changed = audio_change(before, after,
            before_voice=contexts[0], after_voice=contexts[1])
        added |= audio_added
        changed |= audio_changed
    feature_change = value['target_capabilities_sha256'] != value['capabilities_sha256']
    ledger.require(not added or feature_change,
                   'voice backend addition lacks changed capabilities')
    ledger.require(changed or feature_change or value['profiles'] != value['target_profiles'],
                   'voice migration lacks an actual capacity or feature change')


'''
replace('def validate(value):\n',insert+'def validate(value):\n')
replace("    tts = type(value) is dict and value.get('format') == TTS_CAPACITY_FORMAT", "    tts = type(value) is dict and value.get('format') == TTS_CAPACITY_FORMAT\n    voice = type(value) is dict and value.get('format') == VOICE_FORMAT")
# Restrict format extension to validate's own condition block.
a=s.index('def validate(value):');b=s.index('\ndef candidate(',a);v=s[a:b]
v=v.replace('or tts else', 'or tts or voice else').replace('or tts:', 'or tts or voice:')
v=v.replace("*(('from_native_tts', 'to_native_tts') if tts else ())))", "*(('from_native_tts', 'to_native_tts') if tts or voice else ()),\n        *(('from_native_tts_base', 'to_native_tts_base') if voice else ())))")
v=v.replace('TTS_CAPACITY_FORMAT) and', 'TTS_CAPACITY_FORMAT, VOICE_FORMAT) and')
v=v.replace('(extension or backend or audio or tts or value', '(extension or backend or audio or tts or voice or value')
v=v.replace("    ledger.keys(value['profiles'], profile_contract.NAMES)", "    if voice:\n        voice_transition(value)\n    ledger.keys(value['profiles'], profile_contract.NAMES)")
s=s[:a]+v+s[b:]
replace('                                    TTS_CAPACITY_FORMAT) or (', '                                    TTS_CAPACITY_FORMAT, VOICE_FORMAT) or (')
t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)

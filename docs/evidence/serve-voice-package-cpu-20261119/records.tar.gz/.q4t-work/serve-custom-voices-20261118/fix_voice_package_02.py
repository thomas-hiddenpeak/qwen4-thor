from pathlib import Path

def edit(name, old, new):
    p = Path(name); s = p.read_text()
    assert s.count(old) == 1, (name, old[:100], s.count(old))
    q = p.with_name(p.name+'.edit');q.write_text(s.replace(old, new));q.replace(p)

edit('tools/serve_recovery/test_voice_profiles.py',
     '    setUp = TtsProfiles.setUp\n',
     '    setUp = TtsProfiles.setUp\n    stamp = TtsProfiles.stamp\n')
edit('tools/serve_recovery/profile_contract.py',
     'def tts_capability_binding(fixed, capability, base=None, asr=None):\n    try:',
     '''def tts_capability_binding(fixed, capability, base=None, asr=None):
    speech = capability.get('speech', {})
    ledger.require(type(speech) is dict and not (
        fixed is None and base is None and speech.get('enabled') is True),
        'configured TTS backend lacks qualification binding')
    try:''')
edit('tools/serve_recovery/profile_controller.py',
     "\n        base['settings'].get('native_tts_base'))",
     "\n            base['settings'].get('native_tts_base'))")
edit('tools/serve_service/package.py',
     "    expected_registration = (base is not None and asr is not None and\n                             {'speaker', 'vad'} <= asr.keys())",
     "    require(asr is None or type(asr) is dict, 'invalid native voice ASR binding')\n    expected_registration = (base is not None and asr is not None and\n                             {'speaker', 'vad'} <= asr.keys())")
edit('tools/serve_recovery/profile_evidence.py',
     "    usage = response.get('usage', {});parts = usage.get('completion_tokens_details', {})",
     "    usage = response.get('usage', {})\n    ledger.require(type(usage) is dict, 'invalid registered voice Chat usage')\n    parts = usage.get('completion_tokens_details', {})")
edit('tools/serve_recovery/profile_migration.py',
     '    asr_capabilities(result)\n    tts_capabilities(result)',
     '    tts_capabilities(result)\n    asr_capabilities(result)')
edit('tools/serve_recovery/profile_migration.py',
     "    for key in ('registered_custom_voices', 'builtin_enabled'):\n",
     """    # The root model selects an active family. Normalize that selection
    # into a set of fixed qualified families, so adding Base does not replace
    # a previously accepted builtin family (or an inactive model declaration).
    speech['qualified_families'] = {}
    for name, active, fixed in [('builtin', builtin, package.NATIVE_TTS),
                                 ('base', base, package.NATIVE_TTS_BASE)]:
        if active:
            speech['qualified_families'][name] = dict(fixed)
    for key in package.NATIVE_TTS:
        speech.pop(key, None)
    for key in ('registered_custom_voices', 'builtin_enabled'):
""")

import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
root=Path.cwd();work=root/'.q4t-work/serve-custom-voices-20261118'
old=json.loads((work/'voice-package-plan-01.json').read_text())
names=[x for x in old['required'] if '.VoiceProfiles.' in x or x.endswith('test_profile_cannot_omit_spoken_business_or_misbind_the_codec') or x.endswith('test_observed_base_condition_health_and_registration_cannot_be_dropped')]
names += ['tools.serve_recovery.test_voice_profiles.VoiceProfiles.'+x for x in (
 'test_minimal_registration_context_is_bound_before_and_after_migration',
 'test_base_capacity_change_keeps_consumed_budget_pending_and_original_identity',
 'test_both_families_migrate_shared_limits_and_automatic_recovery_keeps_features',
 'test_explicit_base_addition_cannot_remove_or_reuse_builtin_only_business')]
names += ['tools.serve_recovery.test_tts_profiles.TtsProfiles.'+x for x in (
 'test_explicit_addition_keeps_pending_recovery_budget_and_never_downgrades',
 'test_disabled_to_enabled_is_explicit_and_all_other_capabilities_stay_bound',
 'test_automatic_version_recovery_requires_identical_tts_identity_and_budgets',
 'test_explicit_budget_change_retains_original_history_qualification',
 'test_combined_asr_addition_and_tts_budget_migration_has_both_evidence')]
names += ['tools.serve_recovery.test_audio_auxiliary_profiles.AudioAuxiliaryProfiles.'+x for x in (
 'test_explicit_auxiliary_addition_keeps_history_pending_and_all_wait',
 'test_explicit_vad_capacity_change_retains_original_qualification_and_wait',
 'test_automatic_same_features_work_and_removal_or_unsealed_addition_fail')]
plan=dict(scope='Fix five original failures; Base and shared TTS migration, minimal registration context, immutable identity, no consumed recovery budget reset',
 required=names,cases=len(names),seconds=180,gpu=0,model_loads=0,
 original_failure_preserved='voice-package-cpu-01',real_voice_http_pending=True,
 profile_execution_driver_pending=True,disk_reserve_bytes=256*1024**2)
plan_path=work/'voice-package-plan-02.json'
with plan_path.open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
for name,text in [('docs/STATUS.md','Base包首轮22 CPU有17项通过：4项新夹具缺时间戳、1项错误消息合同不一致，\n失败原样保留。已修复并补Base/双TTS预算迁移、注册专用ASR前后绑定；\n冻结18项受影响CPU/180秒/0GPU，不重复其余已通过项。实际HTTP、\nprofile执行和持久状态回退继续，默认不变。\n\n'),
 ('docs/log/2026-11-19.md','## 2026-11-19 — Base包首轮失败修复及迁移合同冻结\n\n- 做了什么：保留22项首轮17通过/5失败；修复夹具时间戳和既有错误消息，\n  加入Base与共享TTS预算的显式迁移，绑定迁移前后注册ASR依赖；\n  修复capability归一化顺序，注册证据要求ASR/VAD/speaker固定身份。\n- 为什么：恢复不能丢模型、绕过注册依赖或重置已消耗的恢复预算。\n- 验证：冻结18项直接受影响CPU/180秒/0GPU；原证据保留，未替换默认。\n- 下一步：完成此组验收和实际profile驱动，再续真实音色闭环/状态回退。\n\n')]:
 p=root/name;s=p.read_text();at=s.index('\n')+1 if 'log/' in name else s.index('## 正在推进\n')+len('## 正在推进\n')
 tmp=p.with_name(p.name+'.edit');tmp.write_text(s[:at]+'\n'+text+s[at:]);tmp.replace(p)
out=work/'voice-package-cpu-02';out.mkdir()
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['tools/serve_recovery/test_voice_profiles.py','tools/serve_service/test_voice_package.py']
(out/'sources.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths))},indent=2)+'\n')
assert shutil.disk_usage(root).free >= plan['disk_reserve_bytes']
cmd=[sys.executable,'-B','-m','unittest','-v',*names];start=time.monotonic()
with (out/'tests.log').open('x') as log:
 run=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
result=dict(status='PASS' if run.returncode==0 else 'FAILED',command=cmd,returncode=run.returncode,seconds=time.monotonic()-start,cases=len(names),gpu=0,model_loads=0)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((out/'tests.log').read_text()[-5500:]);sys.exit(run.returncode)

from pathlib import Path
R=Path.cwd()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def edit(p,a,b):
 s=p.read_text();assert s.count(a)==1,(p,a,s.count(a));write(p,s.replace(a,b))
p=R/'tools/serve_recovery/profile_contract.py'
edit(p,'def asr_binding(value):\n    selected = package.asr_settings(value)','def asr_binding(value, *, voice_registration=False):\n    selected = package.asr_settings(value, voice_registration=voice_registration)')
edit(p,'def asr_configuration(value):','def asr_configuration(value, *, voice_registration=False):')
edit(p,'    return package.asr_settings(selected)','    return package.asr_settings(selected, voice_registration=voice_registration)')
edit(p,'            native_asr=None, native_tts=None):','            native_asr=None, native_tts=None, native_tts_base=None):')
edit(p,"        result['native_asr'] = asr_binding(native_asr)","        result['native_asr'] = asr_binding(native_asr,\n            voice_registration=native_tts_base is not None)")
edit(p,"        result['native_tts'] = tts_binding(native_tts)\n    return result","        result['native_tts'] = tts_binding(native_tts)\n    if native_tts_base is not None:\n        result['native_tts_base'] = tts_binding(native_tts_base, base=True)\n        ledger.require(native_tts is None or package.same_json(\n            result['native_tts']['limits'], result['native_tts_base']['limits']),\n            'qualified TTS families must share effective limits')\n    return result")
edit(p,'def tts_binding(value):\n    selected = package.tts_settings(value)','def tts_binding(value, *, base=False):\n    selected = package.tts_settings(value, base=base)')
edit(p,"def tts_configuration(value):\n    ledger.keys(value, (*package.NATIVE_TTS, 'limits'))\n    return package.tts_settings(dict(value, directory='/qualified/tts-assets'))", "def tts_configuration(value, *, base=False):\n    ledger.keys(value, (*package.NATIVE_TTS, 'limits'))\n    return package.tts_settings(dict(value, directory='/qualified/tts-assets'),\n                                base=base)")
s=p.read_text();a=s.index('def tts_capability_binding(');b=s.index('\ndef configuration(',a);s=s[:a]+'''def tts_capability_binding(fixed, capability, base=None, asr=None):
    try:
        package.check_tts_capabilities(capability, fixed, base, asr)
    except RuntimeError as error:
        raise ValueError('qualified TTS backend identity/isolation differs: '+str(error)) from error

''' + s[b:];write(p,s)
edit(p,"                       *(('native_tts',) if 'native_tts' in value else ())))", "                       *(('native_tts',) if 'native_tts' in value else ()),\n                       *(('native_tts_base',) if 'native_tts_base' in value else ())))")
edit(p,'        asr = asr_configuration(asr)','        asr = asr_configuration(asr,\n            voice_registration=\'native_tts_base\' in value)')
edit(p,"    return binding(value['binary_sha256'], value['protocol_sha256'],\n                   value['model_files'], value['model_assets'], native, asr, tts)", "    base = (tts_configuration(value['native_tts_base'], base=True)\n            if 'native_tts_base' in value else None)\n    return binding(value['binary_sha256'], value['protocol_sha256'],\n                   value['model_files'], value['model_assets'], native, asr, tts, base)")
edit(p,"    tts_capability_binding(fixed.get('native_tts'), capability)", "    tts_capability_binding(fixed.get('native_tts'), capability,\n                           fixed.get('native_tts_base'), fixed.get('native_asr'))")
for name in ['tools/serve_recovery/profile_controller.py','tools/serve_recovery/profile_bundle.py']:
 p=R/name;edit(p,"base['settings'].get('native_asr'), base['settings'].get('native_tts'))", "base['settings'].get('native_asr'), base['settings'].get('native_tts'),\n        base['settings'].get('native_tts_base'))")
p=R/'tools/serve_recovery/profile_migration.py'
edit(p,"    profile_contract.tts_capability_binding(package.NATIVE_TTS if enabled else None, value)", "    base = speech.get('registered_custom_voices', False)\n    builtin = speech.get('builtin_enabled', enabled and not base)\n    ledger.require(type(base) is bool and type(builtin) is bool,\n                   'invalid TTS family activation')\n    transcription = value.get('transcriptions', {})\n    asr = ({name: {} for name in package.ASR_AUXILIARY\n            if transcription.get(name, {}).get('configured') is True}\n           if transcription.get('configured') is True else None)\n    profile_contract.tts_capability_binding(\n        package.NATIVE_TTS if builtin else None, value,\n        package.NATIVE_TTS_BASE if base else None, asr)\n    for key in ('registered_custom_voices', 'builtin_enabled'):\n        if key in speech:\n            speech[key] = dict(enabled=True) if speech[key] else {}\n    registration = value.get('voice_registration')\n    if registration is not None:\n        ledger.require(type(registration.get('enabled')) is bool,\n                       'invalid voice registration activation')\n        registration['enabled'] = dict(enabled=True) if registration['enabled'] else {}")
# Keep immutable Base bindings explicit in migrations. Capacity changes for
# both model families are implemented separately; do not silently ignore Base.
edit(p,"    old_asr, new_asr = (registry['identity'].get('native_asr')", "    old_base, new_base = (registry['identity'].get('native_tts_base')\n                          for registry in (previous, target))\n    ledger.require(old_base == new_base or\n        (old_base is None and new_base is not None and extension and\n         allow_capability_extension and not automatic),\n        'migration would change or remove qualified TTS Base identity/capacity')\n    old_asr, new_asr = (registry['identity'].get('native_asr')")
# Speaker-only registration configuration requires a fixed Base context even
# when the unchanged ASR identities are inspected for migration.
edit(p,'def audio_change(before, after):','def audio_change(before, after, *, voice_registration=False):')
edit(p,'    profile_contract.asr_configuration(before)\n    profile_contract.asr_configuration(after)', '    profile_contract.asr_configuration(before, voice_registration=voice_registration)\n    profile_contract.asr_configuration(after, voice_registration=voice_registration)')
edit(p,'(audio_change(old_asr, new_asr)\n', '(audio_change(old_asr, new_asr,\n        voice_registration=old_base is not None and new_base is not None)\n')
print('Base identity/path/isolation and migration no-drop binding written; actual voice business receipt next')

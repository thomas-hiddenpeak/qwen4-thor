from pathlib import Path
R=Path.cwd()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
p=R/'tools/serve_recovery/profile_evidence.py';s=p.read_text();marker="TTS_FORMAT = 'q4t-profile-business-v8'\n";assert marker in s;s=s.replace(marker,marker+"VOICE_FORMAT = 'q4t-profile-business-v9'\nVOICE_TARGETS = ('The blue train arrives at noon.', 'Please close the window.')\n",1)
pos=s.index('\n\nCHAT_AUDIO_FORMAT =')
addition=r'''

def voice_requests(consent, voice):
    from tools.serve_service import package
    return dict(consent=dict(name='local-consent', language='en'),
        voice=dict(name='local-sample', type='audio_sample', consent=consent),
        speech=dict(model=package.NATIVE_TTS_BASE['model'], input=VOICE_TARGETS[0],
            voice=dict(id=voice), response_format='wav', stream_format='sse'),
        chat=dict(model='qwen3.8-flash-next', temperature=0, enable_thinking=False,
            max_completion_tokens=1536, messages=[dict(role='user',
                content='Repeat exactly without adding any words: '+VOICE_TARGETS[1])],
            modalities=['text', 'audio'], audio=dict(voice=dict(id=voice), format='wav'),
            stream=False, store=True),
        transcription=dict(model='qwen3-asr-0.6b', response_format='json'))


def voice_audio(value, limits):
    ledger.require(type(value) is str and 0 < len(value) <= 4*1024*1024,
                   'invalid qualified voice audio encoding')
    try:
        raw = base64.b64decode(value, validate=True)
        ledger.require(base64.b64encode(raw).decode() == value,
                       'noncanonical qualified voice audio')
        with wave.open(io.BytesIO(raw)) as source:
            count = source.getnframes()
            ledger.require(source.getnchannels() == 1 and
                source.getsampwidth() == 2 and source.getframerate() == 24000 and
                count % 1920 == 0 and 2 <= count//1920 <= limits['max_frames'],
                'qualified voice WAV geometry differs')
            data = source.readframes(count)
            ledger.require(len(data) == 2*count, 'truncated qualified voice WAV')
    except (ValueError, EOFError, wave.Error) as error:
        raise ValueError('invalid qualified voice WAV') from error
    import struct
    samples = struct.unpack('<'+'h'*count, data)
    ledger.require(max(abs(x) for x in samples) > 327 and
        sum(float(x)*x for x in samples)/count > (32768*.0001)**2,
        'silent qualified voice audio')
    return count//1920


def voice_error(value, status, code=None):
    ledger.keys(value, ('status', 'body'))
    error = value['body'].get('error') if type(value['body']) is dict else None
    ledger.require(type(value['status']) is int and value['status'] == status and
        type(error) is dict and type(error.get('code')) is str and error['code'] and
        'id' not in value['body'] and (code is None or error['code'] == code),
        'qualified voice rejection differs')


def voice_business(value, identity):
    """Validate retained actual results, not proof that a helper ran HTTP."""
    ledger.keys(value, ('requests', 'consent', 'voice', 'speech', 'speech_transcript',
        'chat', 'chat_transcript', 'negative', 'revocation', 'health', 'limits'))
    fixed = identity['native_tts_base']
    profile_contract.tts_configuration(fixed, base=True)
    ledger.require(ledger.canonical(value['limits']) == ledger.canonical(fixed['limits']),
                   'qualified voice effective capacity differs')
    for name, prefix, field in [('consent', 'cons_', 'language'),
                                 ('voice', 'voice_', 'type')]:
        row = value[name]
        ledger.keys(row, ('id', 'object', 'created_at', 'name', field))
        expected = 'audio.voice_consent' if name == 'consent' else 'audio.voice'
        ledger.require(type(row['id']) is str and row['id'].startswith(prefix) and
            len(row['id']) <= 128 and len(row['id']) > len(prefix) and
            row['object'] == expected and ledger.integer(row['created_at'], minimum=1) and
            row['name'] == ('local-consent' if name == 'consent' else 'local-sample') and
            row[field] == ('en' if name == 'consent' else 'audio_sample'),
            'qualified voice metadata differs or leaks private evidence')
    expected = voice_requests(value['consent']['id'], value['voice']['id'])
    ledger.require(ledger.canonical(value['requests']) == ledger.canonical(expected),
                   'qualified voice requests lost the actual ID or supplied ASR hints')
    speech = value['speech']
    ledger.keys(speech, ('audio_base64', 'usage'))
    frames = voice_audio(speech['audio_base64'], fixed['limits'])
    usage = speech['usage']
    ledger.keys(usage, ('input_tokens', 'output_tokens', 'total_tokens'))
    ledger.require(all(ledger.integer(n, minimum=1) for n in usage.values()) and
        usage['output_tokens'] == frames*16+1 and
        usage['total_tokens'] == usage['input_tokens']+usage['output_tokens'],
        'qualified voice speech lacks natural EOS or actual usage')
    response = value['chat']
    msg = message(response, 'stop');audio = msg.get('audio')
    ledger.require(type(audio) is dict and type(audio.get('id')) is str and
        audio['id'].startswith('audio_') and ledger.integer(audio.get('expires_at'), minimum=1) and
        audio.get('transcript') == VOICE_TARGETS[1],
        'qualified registered voice Chat history differs')
    frames = voice_audio(audio.get('data'), fixed['limits'])
    usage = response.get('usage', {});parts = usage.get('completion_tokens_details', {})
    synthesis = usage.get('q4t_audio_synthesis', {})
    ledger.require(all(type(x) is dict for x in (usage, parts, synthesis)) and
        all(ledger.integer(usage.get(k), minimum=1) for k in
            ('prompt_tokens', 'completion_tokens', 'total_tokens')) and
        usage['total_tokens'] == usage['prompt_tokens']+usage['completion_tokens'] and
        parts.get('audio_tokens') == frames*16 and
        synthesis.get('output_tokens') == frames*16+1 and
        ledger.integer(synthesis.get('input_tokens'), minimum=1) and
        usage['completion_tokens'] > synthesis['output_tokens'] and
        usage['prompt_tokens'] > synthesis['input_tokens'],
        'qualified registered voice Chat combined usage differs')
    for key, text in [('speech_transcript', VOICE_TARGETS[0]),
                       ('chat_transcript', VOICE_TARGETS[1])]:
        ledger.require(type(value[key]) is dict and value[key].get('text') == text,
                       'qualified voice independent transcription differs')
    negatives = {'negated_consent': (400, 'voice_consent_mismatch'),
                 'different_speaker': (400, 'voice_speaker_mismatch'),
                 'cross_consent': (404, None), 'cross_voice': (404, None),
                 'cross_speech': (404, None), 'quota': (429, 'client_tpm_exhausted')}
    ledger.keys(value['negative'], negatives)
    for key, (status, code) in negatives.items():
        voice_error(value['negative'][key], status, code)
    revoked = value['revocation']
    ledger.keys(revoked, ('consent_deleted', 'voice_deleted', 'speech', 'consent'))
    for key in ('consent', 'voice'):
        deleted = revoked[key+'_deleted']
        ledger.keys(deleted, ('id', 'object', 'deleted'))
        ledger.require(deleted['id'] == value[key]['id'] and
            deleted['object'] == value[key]['object'] and deleted['deleted'] is True,
            'qualified voice revocation did not retire the registered ID')
    voice_error(revoked['speech'], 404);voice_error(revoked['consent'], 404)
    ledger.keys(value['health'], ('base', 'condition'))
    for key, model in [('base', fixed['model']), ('condition', fixed['model']+'-speaker')]:
        health = value['health'][key]
        ledger.require(type(health) is dict and
            health.get('state') in ('ready', 'metadata_ready') and
            health.get('model') == model and health.get('core_readiness_dependency') is False and
            health.get('reason') == 'none' and type(health.get('compute_failures')) is int and
            health['compute_failures'] == 0,
            'qualified voice backend failed or depends on core readiness')
'''
s=s[:pos]+addition+s[pos:]
s=s.replace("def format_for(profile, identity=None, capabilities=None):\n", "def format_for(profile, identity=None, capabilities=None):\n    if (identity or {}).get('native_tts_base') is not None:\n        return VOICE_FORMAT\n")
s=s.replace("def has_speaker(identity):\n    return 'speaker' in (identity.get('native_asr') or {})", "def has_speaker(identity):\n    # Diarization requires alignment. A registration-only speaker is verified\n    # by the voice lifecycle receipt rather than a fictitious aligned result.\n    return {'speaker', 'alignment'} <= (identity.get('native_asr') or {}).keys()")
s=s.replace("(('tts',) if identity.get('native_tts') is not None else ()))", "(('tts',) if identity.get('native_tts') is not None else ()) +\n                       (('voice',) if identity.get('native_tts_base') is not None else ()))")
s=s.replace("    if identity.get('native_tts') is not None:\n        tts_business(value['tts'], identity)", "    if identity.get('native_tts') is not None:\n        tts_business(value['tts'], identity)\n    if identity.get('native_tts_base') is not None:\n        voice_business(value['voice'], identity)")
write(p,s)
print('Base qualification requires complete per-profile voice registration, new-text synthesis, independent ASR, owner/quota negatives, revocation and isolated health')

from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,tarfile
from tools.serve_audit import check_inventory as audit
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
O=R/'docs/evidence/serve-voice-package-cpu-20261119';O.mkdir(exist_ok=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def save(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
reviewed={p for p in changed if p.startswith(('tools/serve_service/','tools/serve_recovery/'))}
actual=audit.current_surface(R);inv=json.loads(audit.INVENTORY.read_text())
source_changes={p for p,h in actual['sources_sha256'].items() if inv['sources_sha256'].get(p)!=h}
assert source_changes==reviewed,(source_changes,reviewed)
assert actual['whitelists']==inv['whitelists']
for k in ('fields','completion_fields','routes','native_routes'):
 assert set(actual[k])==set(inv[k]),k
for p in reviewed:inv['sources_sha256'][p]=actual['sources_sha256'][p]
save(audit.INVENTORY,inv)
errors=audit.check(inv,actual);mutations=audit.mutation_checks(inv,actual)
assert not errors and mutations==17,(errors,mutations)
save(O/'audit.json',dict(inventory_current=True,anchors=len(actual['sources_sha256']),mutation_checks=mutations,reviewed=sorted(reviewed),semantics_certified=False))
expected={'build/q4t':'5130cae65358f151cbf9c055af9d2c521e6acc46183c32aa70b6581ab39f6fee','build/q4t.release.json':'aa20961387ab39cbd40df9c6e331964c4275a89037b411b436f887d29af4e7de','build/service/manifest.json':'e992bae3e6a090c595605ff1fbb4c122c96838510bef1f3f6ec6f3c7b4fd111d','build/service.release.json':'52e03d9bad5a933170664bd65fed247623024ebc6dc3eed49ef263e453c2ac49','build/service-native-state/ledger.json':'2a4e326b50e2867482cdc06cc9d343dbb42fdffbc85bd884c7e2d9a09efdab16'}
assert {p:sha(R/p) for p in expected}==expected
save(O/'default-unchanged.json',expected)
results=[];passed=set();attempted=set()
for n in range(1,4):
 folder=V/f'voice-package-cpu-{n:02d}';result=json.loads((folder/'result.json').read_text());results.append(result)
 log=(folder/'tests.log').read_text()
 for name,owner,status in re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR)$',log,re.M):
  test=owner+'.'+name;attempted.add(test)
  if status=='ok':passed.add(test)
assert attempted==passed and len(passed)==34,(len(attempted),len(passed))
files=[V/n for n in ('implement_voice_package_01.py','implement_voice_binding_01.py','implement_voice_profile_evidence_01.py','fix_voice_package_02.py','implement_voice_migration_02.py','add_voice_migration_tests_02.py','run_voice_package_02.py','fix_voice_migration_fixtures_03.py','archive_voice_package_03.py','archive_voice_package_04.py')]
files += sorted(V.glob('voice-package-plan-*.json'))
for n in range(1,4):files+=sorted(p for p in (V/f'voice-package-cpu-{n:02d}').rglob('*') if p.is_file())
files += [R/p for p in sorted(reviewed|{'tools/serve_recovery/test_voice_profiles.py','tools/serve_service/test_voice_package.py'})]
assert shutil.disk_usage(R).free> (256<<20)+sum(p.stat().st_size for p in files)
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}))
summary=dict(status='PASS_TARGETED_CPU_PENDING_REAL_VOICE_PROFILE',distinct_cases=34,
 runs=[{k:r[k] for k in ('status','cases','seconds')} for r in results],
 total_seconds=sum(r['seconds'] for r in results),gpu=0,model_loads=0,
 failed_runs_retained=True,default_replaced=False,profile_driver_pending=True,
 real_voice_http_pending=True,persistent_voice_state_rollback_pending=True)
save(O/'result.json',summary)
write(O/'README.md',f'''# Base音色包与恢复迁移的针对性CPU验证

14项新增与20项直接受影响合同，共34项不同CPU用例有通过记录，
0GPU/模型加载，三次进程合计{summary['total_seconds']:.3f}秒。
首轮22项17通过：4项夹具缺stamp、1项既有错误消息不一致；修复后
18项受影响检查16通过，新增两个迁移夹具分别误用了独立临时模型
inode和不同共享预算；仅修正这两份夹具，最后2项通过。三轮原日志、
冻结清单和源码快照均保留；未重复其余已通过项目。

服务包和原生恢复CLI可显式绑定--tts-base-model-dir；Base/talker/codec
固定身份、独立声纹健康、可迁移资产路径与共享预算同时校验。注册
ASR/speaker/VAD不强制aligner，分离器仍须完整依赖。部署/恢复不能
静默移除Base或内置音色，自动回退不能改变已验功能或预算。

显式Base或双TTS预算迁移保留原资格、pending、历史、冷却和消耗；
v7迁移凭据绑定前后音色/ASR上下文，旧v1—v6合同直接受影响项通过。
恢复证据须包含真实ID注册、自然EOS音频及实际usage、独立ASR、
跨客户/配额/错误授权/异声反例与撤销，不能用内置音色证据替代。
CPU生成的正弦WAV及虚构转录仅用于验证器反例，绝非真实业务证据。

来源审计{len(actual['sources_sha256'])}锚点/17遗漏反例通过，仅刷新13个已审查Python
文件；默认rev316及STOPPED账本身份保持。实际profile执行驱动、
完整音色HTTP与旧存储回退仍待完成；Base-only无注册依赖的已有
音色消费资格也须补实际保存状态流程，本证据不将其宣布完成。
''')
p=R/'docs/serve-master-goals-v2.json';data=json.loads(p.read_text());data['updated']='2026-11-19'
data['native_tts_progress']['custom_voice']['service']['package_recovery']=dict(
 state=summary['status'],evidence='evidence/serve-voice-package-cpu-20261119/README.md',
 distinct_cpu_cases=34,base_capacity_migration=True,real_profile_driver_pending=True,
 base_only_saved_voice_qualification_pending=True,default_replaced=False)
save(p,data)
text='''[Base包/恢复迁移34项CPU通过](evidence/serve-voice-package-cpu-20261119/README.md)：
固定身份、共享预算、注册专用ASR依赖和历史恢复额度保持；939来源锚点/
17遗漏反例通过。原两轮夹具/消息失败保留，0GPU，默认rev316保持。
接着实际profile驱动、音色注册质量和保存状态回退；Base-only已有音色
消费资格另补真实保存状态，不将CPU夹具当成业务或发布通过。
'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — Base音色包与恢复迁移CPU闭合\n\n'+text+'\n做了什么：包/CLI、固定身份、依赖、证据与v7显式预算迁移一起补齐；\n为什么：防止能力声明通过但实际打包/恢复丢模型或重置预算；\n下一步：真实驱动、音色正反例与有状态回退，保持总目标active。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;write(p,s.replace(marker,marker+content,1))
print(json.dumps(summary))
print(json.dumps(dict(archive_bytes=(O/'records.tar.gz').stat().st_size,source_anchors=len(actual['sources_sha256']),reviewed_python=len(reviewed))))

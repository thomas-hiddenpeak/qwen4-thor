from pathlib import Path
p=Path('tools/serve_recovery/test_voice_profiles.py');s=p.read_text()
a='''        fixture = SpeakerProfiles();fixture.setUp()
        self.addCleanup(fixture.doCleanups)
'''
b='''        fixture = SpeakerProfiles()
        # Share the same synthetic immutable model inventory across versions;
        # a separately created temporary model has different inode identities.
        for key in ('old', 'new', 'first', 'second'):
            setattr(fixture, key, copy.deepcopy(getattr(self, key)))
'''
assert s.count(a)==1;s=s.replace(a,b)
a="        registry['identity']['native_tts_base'] = contract.tts_binding(selected(), base=True)\n        if builtin:\n            registry['identity']['native_tts'] = contract.tts_binding(self.selected())"
b="""        base = selected()
        if builtin:
            native = self.selected()
            base['limits'] = copy.deepcopy(native['limits'])
            registry['identity']['native_tts'] = contract.tts_binding(native)
        registry['identity']['native_tts_base'] = contract.tts_binding(base, base=True)"""
assert s.count(a)==1;s=s.replace(a,b)
a="            row['business']['voice'] = cpu_record()\n"
b=a+"            row['business']['voice']['limits'] = copy.deepcopy(base['limits'])\n"
assert s.count(a)==1;s=s.replace(a,b)
t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)

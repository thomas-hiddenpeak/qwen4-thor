from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-mcp-execution-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
r=read(W/'execution-cpu-01/result.json');b=read(W/'execution-build-02/result.json');assert r['status']=='PASS' and r['tests']==16 and b['warnings']==0
assert read(W/'execution-build-01/result.json')['status']=='BUILD_FAIL'
assert all(sha(R/p)==h for p,h in r['sources'].items())
assert sha(W/'execution-original-source.cpp')==read(W/'execution-plan.json')['sources']['src/server/realtime_mcp_execution.cpp']
files={n:W/n for n in ['execution-plan.json','execution-build-repair-plan.json','execution-required.txt','execution-original-source.cpp','build_execution_01.py','build_execution_02.py','run_execution_cpu_01.py','archive_execution_01.py','execution-build-01/plan.json','execution-build-01/result.json','execution-build-01/build.log','execution-build-02/plan.json','execution-build-02/result.json','execution-build-02/build.log','execution-cpu-01/result.json','execution-cpu-01/stdout.txt','execution-cpu-01/stderr.txt']};files.update({'source/'+p:R/p for p in r['sources']});O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
# Explicit allowlist: the object stores and private remote session state stay local.
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_REALTIME_MCP_NATIVE_EXECUTION_CPU',cases=16,passed=16,failed=0,new_localhost_mcp_cases=12,cpu_seconds=r['seconds'],build_seconds=b['seconds'],build_warnings=0,original_build_failure='Missing explicit InputValueIdentity declaration header; original source and compiler failure preserved',binary_sha256=r['binary_sha256'],runtime_connected=False,gpu_actions=0,llm_requests=0,default_revision=396,default_unchanged=True,service_state='STOPPED',all_master_tasks_active=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP原生审批与调用：CPU网络验收

2026-11-20。16项针对性CPU通过，0.865秒：12项新增真实本机MCP网络
夹具及4项直接依赖的CAS/未知结果/会话/辅助清理合同。首次必要构建
因缺InputValueIdentity声明头失败；补显式include后构建22.974秒、
零警告。原构建失败与原源码保留，CPU没有失败或额外重跑。

调用复用ResponsesMcpState与InvokeMcp。完整参数和实际导入目录才可
Propose，审批匹配原调用、只消费一次；目标/scope/凭据/当前策略和
进程/response身份在初始化前检查。只有持久Permit成功才能发实际
工具调用，重复/伪造/删除权限不授予第二次执行。

真实网络覆盖：成功结果、批准/拒绝、当前策略收紧、凭据缺失与
重新提供、调用前取消/到期、远端协议错误、工具错误structuredContent
保真。获准后远端已收到调用但未返回结果时，使用独立清理期限持久
记录unknown；再次执行被拒绝，实际远端调用次数仍为1。

已落盘工具结果与后续会话维护分开记录；辅助维护不能将已知结果
变成重放。此组复用已有原生传输清理失败检查，未故障注入新适配层
中最终BindSession的持久化失败分支；该组合仍需后续集成覆盖。

记录只按显式文件清单归档，不发布私有ObjectStore/session或凭据文件。
全部使用CPU与本机真实HTTP夹具，0模型/0GPU；尚未接入公开Realtime
会话，不能称完整MCP业务闭环。默认rev396 STOPPED保持，继续异步
会话状态、审批事件/取消清理、客户端/模型业务和恢复交付。

[结果](acceptance.json) · [索引](index.json) · [源码与原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text().replace('原生审批/执行适配已成组实现，冻结16项CPU/120秒，以真实本机MCP\n网络验证单次调用、权限、取消和未知结果不重放；待构建验证，0GPU。','[原生审批与调用16项CPU](evidence/serve-realtime-mcp-execution-cpu-20261120/README.md)\n通过，包含12项真实本机MCP网络夹具；0模型/GPU。缺声明头的首次\n构建失败保留；修复后零警告。继续会话所有者、公开接线及实际业务。');p.write_text(s)
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[16项CPU网络检查通过](evidence/serve-realtime-mcp-execution-cpu-20261120/README.md)，\n0.865秒；首次缺声明头的构建失败保留，补include后零警告。
获准后无结果的真实远端调用持久为unknown，重复尝试不再发送。
默认rev396 STOPPED、0GPU。接着连接会话/审批事件和原生清理，
最终BindSession持久化失败的集成故障组合仍保留待验。
''')
p=R/'docs/log/2026-11-20.md';p.write_text('''## Realtime MCP原生审批与调用16项CPU网络检查通过

日期：2026-11-20。

做了什么：[16项CPU](../evidence/serve-realtime-mcp-execution-cpu-20261120/README.md)
全部通过/0.865秒，含12项真实本机网络夹具。首次缺声明头导致构建
失败，补include后零警告；原失败与原源码保留，未重跑通过项。

为什么：调用必须具有实际密封权限与原执行身份；批准/拒绝、凭据
变化、当前策略和取消都不能绕过单次发送。获准后远端无结果时，
真实调用记录unknown且不重放；已知结果与辅助维护错误分开。

下一步：串联异步会话执行所有者、审批事件和取消/删除清理，接入
公开运行时并做客户端/真实模型及恢复。最终BindSession存储失败
集成组合仍待验；默认rev396 STOPPED，0模型/GPU，总目标active。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m['state']='native_proposal_approval_and_execution_cpu_accepted_session_integration_next';m['execution_cpu']=a;m['execution_evidence']='evidence/serve-realtime-mcp-execution-cpu-20261120/README.md';m['execution_remaining']=['Connect asynchronous call ownership to public Realtime session and actual model bindings','Verify final session metadata persistence failure preserves the durable native tool outcome','Complete SDK, real model tool loop, recovery and usable delivery'];save(p,d)
print(json.dumps(a))

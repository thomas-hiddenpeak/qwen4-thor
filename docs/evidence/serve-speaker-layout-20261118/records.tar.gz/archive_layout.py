import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-speaker-layout-20261118'
a=json.loads((W/'layout-cpu-01/result.json').read_text());assert a['status']=='PASS'
assert json.loads((W/'model-cuda-build-02/result.json').read_text())['returncode']==0
assert all(x['returncode']==0 for x in json.loads((W/'model-host-build-02/result.json').read_text()))
files=[Path(__file__).resolve(),W/'build_model.py']
for name in ['model-build-01','model-host-build-02','model-cuda-build-02','layout-cpu-01']:files+=list((W/name).iterdir())
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(W)),recursive=False)
a.update(archive_sha256=hashlib.sha256((O/'records.tar.gz').read_bytes()).hexdigest(),cuda_model_executed=False,http_business=False,default_revision=286,initial_host_build_missing_configure_preserved=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text('''# 原生ECAPA布局与构建（2026-11-18）

6项CPU/0.032秒、0GPU通过：真实231张量中的全部200个F32绑定、
基址迁移、逐个坏偏移、空/截断/地址溢出、全工作区不重叠和预算。
完整ECAPA FP32 pedantic CUDA实现编译零警告，运行时尚未数值验证。
工作区包括原生所有显式中间值与4MiB GEMM空间；不声称cuBLAS内部
没有开销，后续实际统一RAM观测另计。每阶段同步后才发布进度，
非有限结果禁止发布，CUDA错误独立传播；没有新增推理依赖。

首次host构建未重新configure，找不到新增目标，失败保留；配置后
构建与6项检查通过。CUDA二次构建只调整先验形状检查顺序，不重复
已通过布局测试。无GPU/HTTP/完整质量/性能或长稳结论。
默认rev286不变；继续固定官方参考、真实计算、分段/匹配/API和
恢复/交付，全部master保持active。
''')
intro='''[ECAPA实际计算布局6项CPU通过](evidence/serve-speaker-layout-20261118/README.md)
（0.032秒、0GPU）；完整F32计算已零警告编译，实际数值仍待验证。
首次host未configure的构建失败保留；接着固定官方CPU对照和有界
GPU，再完成分段/参考/API/恢复/交付及全部master。默认rev286不变。

'''
p=R/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();h,b=s.split('\n',1);p.write_text(h+'''\n\n## ECAPA完整计算开发与布局6项通过（2026-11-18）

F32/pedantic卷积、Res2/SE、全局注意力池化与输出已实现并零警告
编译；6项布局CPU/0.032秒、0GPU。首次新增host目标未配置失败
保留，configure后通过；进度只在真实完成同步后推进，失败不发布。
原因：需要实际声纹计算，不能仅登记资产。下一步官方数值对照、
真实说话人业务及恢复/交付，全部master继续，默认rev286保持。
[证据](../evidence/serve-speaker-layout-20261118/README.md)。\n'''+b)
print(json.dumps(a))

import concurrent.futures,json,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'model-build-01';O.mkdir()
commands={'host':['cmake','--build',str(R/'.q4t-work/serve-file-search-20261112/host'),'--target','q4t_speaker_layout_tests','--parallel','4'],'cuda':['cmake','--build',str(R/'.q4t-work/serve-custom-tools-20261108/engine-build'),'--target','q4t_model','--parallel','4']}
def build(item):
 name,cmd=item;t=time.monotonic()
 with (O/(name+'.log')).open('w') as f:rc=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=360).returncode
 result=dict(command=cmd,returncode=rc,seconds=time.monotonic()-t);(O/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');return name,result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=dict(pool.map(build,commands.items()))
(O/'result.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results));raise SystemExit(any(r['returncode'] for r in results.values()))

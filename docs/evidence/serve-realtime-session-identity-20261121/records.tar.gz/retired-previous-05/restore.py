import gzip,hashlib,json,os,sys
from pathlib import Path
O=Path(__file__).resolve().parent
for row in json.loads((O/'plan.json').read_text())['files']:
 if len(sys.argv)>1 and not any(p in sys.argv[1:] for p in row['paths']):continue
 paths=list(map(Path,row['paths']));assert not any(p.exists() for p in paths)
 q=Path(row['archive']);assert hashlib.sha256(q.read_bytes()).hexdigest()==row['archive_sha256']
 raw=gzip.decompress(q.read_bytes());assert hashlib.sha256(raw).hexdigest()==row['sha256']
 with paths[0].open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 paths[0].chmod(row['mode']);os.utime(paths[0],ns=(row['atime_ns'],row['mtime_ns']))
 for p in paths[1:]:os.link(paths[0],p)
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'] for p in paths)

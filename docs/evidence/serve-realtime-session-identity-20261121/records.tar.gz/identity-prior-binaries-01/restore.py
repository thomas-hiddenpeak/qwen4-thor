import gzip,hashlib,json,os,sys
from pathlib import Path
O=Path(__file__).resolve().parent
for row in json.loads((O/'plan.json').read_text())['files']:
 if len(sys.argv)>1 and row['path'] not in sys.argv[1:]:continue
 q=Path(row['archive']);assert hashlib.sha256(q.read_bytes()).hexdigest()==row['archive_sha256']
 raw=gzip.decompress(q.read_bytes());assert hashlib.sha256(raw).hexdigest()==row['sha256']
 p=Path(row['path']);assert not p.exists(),'refuse to overwrite '+str(p)
 with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 p.chmod(row['mode']);os.utime(p,ns=(row['atime_ns'],row['mtime_ns']))
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']

import hashlib,io,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];T=Path(__file__).parent
O=R/'docs/evidence/serve-realtime-session-identity-20261121';O.mkdir()
files=[]
for name in ['session-identity-cpu-01','session-identity-cpu-02','sdk-cpu-04','native-runtime-04']:
 base=T/name
 files += [p for p in base.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(base).parts and 'fixtures' not in p.relative_to(base).parts]
for name in ['result.json','primary-tracing.sdk.json','primary-tracing.events.jsonl','primary-tracing-observed.json','primary-tracing.stderr','cleanup.json','lease/exit.json','lease/nvml-queries.jsonl']:
 files.append(T/'sdk-business-04'/name)
files += [T/'identity-inventory.json',T/'retired-previous-05/result.json',T/'retired-previous-05/plan.json',T/'retired-previous-05/restore.py',T/'identity-prior-binaries-01/plan.json',T/'identity-prior-binaries-01/restore.py',Path(__file__).resolve()]
rows=[]
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for p in sorted(files):
  raw=p.read_bytes();name=str(p.relative_to(T));info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644
  archive.addfile(info,io.BytesIO(raw));rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(O/'index.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256((O/'records.tar.gz').read_bytes()).hexdigest(),files=rows),indent=2)+'\n')
r=json.loads((T/'session-identity-cpu-02/result.json').read_text());b=json.loads((T/'native-runtime-04/result.json').read_text())
accept=dict(status='CPU_AND_NATIVE_BUILD_PASS_GPU_REVALIDATION_PENDING',native_cpu=r,native_build=b,driver_checker_cases=13,reused_driver_cases=9,original_failure=dict(model_starts=1,actual_generations=0,seconds=44.08987349597737,retained=True),default_revision=416,default_unchanged=True,master_active=True)
(O/'acceptance.json').write_text(json.dumps(accept,indent=2)+'\n')
(O/'README.md').write_text('''# Realtime会话身份遗漏修复（2026-11-21）

实际TLS SDK短验暴露session.created缺少id/object：1次模型启动、0实际
生成，44.090秒。三次预留生成槽没有被使用；原失败、零用量、NVML
和正常清理原件保留，不能写成业务通过。

按[官方服务事件合同](https://developers.openai.com/api/reference/resources/realtime/server-events)
补齐创建/更新的服务端身份；客户端不得改写，生成设置保持。冻结
SDK 7.47把服务事件声明为请求设置，因此校验仅在服务输出侧检查并
投影id/object，再使用原类型图；畸形/重复/未知字段仍拒绝。

9项受影响原生CPU通过，0.314秒、构建44.996秒/零警告；原编译遗漏
声明头失败保留，未运行用例。13项判据CPU通过，原9项驱动证据复用。
原生服务重建45.235秒/零警告，候选ae84a6be；原生入口8bd79b7a身份
保持。精确SHA、原始记录和来源见[索引](index.json)与[归档](records.tar.gz)。

修复后最多2启动/6生成/900秒补验尚未运行；包含首次失败累计最多
3启动/6实际生成。默认rev416保持STOPPED，主轻资格、交付和main
尚未完成，Serve总目标继续active。未重跑完整性能或模型质量矩阵。
''')
print(json.dumps(dict(files=len(rows),archive_bytes=(O/'records.tar.gz').stat().st_size)))

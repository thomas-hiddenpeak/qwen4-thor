"""Archive actual reversible projective publication; update current state only."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-01'
O=R/'docs/evidence/serve-video-projective-delivery-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');assert v['status']=='PASS_NATIVE_VIDEO_PROJECTIVE_DELIVERED' and v['publication']['revision']==254
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands']) and v['state']=='STOPPED' and v['new_gpu_starts']==0
c=v['publication']['current'];composition=read(W/'publication-composition.json')
assert c['manifest_sha256']==composition['candidate']['manifest_sha256'] and sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
files=[(p,'delivery-01/'+p.name) for p in D.iterdir() if p.is_file() and not p.is_symlink()]
for pattern in ('delivery-prepare-*.*','delivery-run-*.*','publication-archive-*.*','version-archive-*.*'):
 files.extend((p,p.name) for p in W.glob(pattern) if p.is_file())
for n in ['archive_delivery.py','deliver.py','run_delivery.py','archive_generations.py','archive_versions.py','prepare_package.py','publication-composition.json','package-01/prepare-review.json']:
 files.append((W/n,n))
files=sorted({n:p for p,n in files}.items());secrets=[]
def collect(value):
 if isinstance(value,dict):
  for key,x in value.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(value,list):
  for x in value:collect(x)
for p in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(p))
for n,p in files:assert not any(x in p.read_bytes() for x in secrets),n
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
a=dict(status='ACCEPT_NATIVE_VIDEO_PROJECTIVE_DELIVERY',revision=254,current=c,commands=len(v['commands']),seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_whole_package_gpu_run=False,composed_change='Exact engine projective pixels, primary/light and retained control business; unchanged controller/client/native helpers; explicit capability extension preserves budgets and disallows capability loss; actual STOPPED whole-root rollback and forward.',older_engine_fallback=False,prior_rev244_preserved=True,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生有限透视视频默认交付 rev254\n\n实际包`{c['manifest_sha256']}`，generation\n`{c['generation_sha256']}`；引擎`{c['engine_binary_sha256']}`。\n19项STOPPED检查/发布、整根回退与再前进完成，{v['seconds']:.3f}秒，\n0新增GPU；outer保持enabled且累计启动0次。\n\n合法非单位w与有限透视真正变换像素，v5历史可无codec重放，\n保留原八方向/v4仿射与显式细节合同。功能及发行组合累计\n{composition['total_starts']}启动{composition['total_external_requests']}请求（含自检及embedding）、\n{composition['strict_lease_seconds']:.3f}秒严格租约，{composition['nvml_queries']}项NVML正常，完整清理。\n[发行组合](../serve-video-projective-composition-20261117/README.md)保留原始证据。\n\ncore/client/outer预算字节保持，profile仅增加已验透视能力，原历史、\npending、selected、deadline和周期保持。实际回退恢复各根原周期；\n人工保留根`{a['manual_root']}`与自动旧控制payload\n`{a['automatic_payload']}`均使用当前引擎，未声称独立旧引擎回退。\n控制器/native helper/client未变，不重复其未受影响的故障矩阵。\n\n退休generation及登记各两份可恢复归档，0删除，原244包和day入口\n保留。继续独立day交接及实际合main，全部master仍active；多轨、\n其余格式和真实后端、历史模型质量问题仍需解决，长稳由用户执行。\n''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev254；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；原生outer/周期及有限透视视频能力完整，前驱244另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退'}
for label,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(label)+r' \| .* \|$',lambda _:f'| {label} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev254有限透视交付](evidence/serve-video-projective-delivery-20261117/README.md)\n完成19项STOPPED发布、实际整根回退与再前进，{v['seconds']:.3f}秒、0新增\nGPU。原预算/周期保持，控制器/native helper/client未变；原244包、\n历史失败及长稳计划保留。继续独立day交接、实际合main及全部master。\n\n'''
s=s.replace('[rev244仿射与视频细节交付]',intro+'前驱[rev244仿射与视频细节交付]',1)
s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro,1);p.write_text(s)
p=R/'docs/log/2026-11-17.md';h,t=p.read_text().split('\n',1);p.write_text(h+f'''\n\n## rev254有限透视视频可回退交付\n\n19项STOPPED升级/整根回退/再前进通过，{v['seconds']:.3f}秒，0新增GPU。\n预算字节及原周期保持，profile仅增加已验能力；原244包和day计划\n保留。退休副本/登记各两份可恢复归档，无删除。实际能力必须\n进入可用发行，下一步独立day交接、实际合main及全部master；\n多轨/其余后端、原质量问题仍未完成，未开展用户负责的长稳。\n'''+t)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 if task['id']=='A10':
  task['video_projective_20261117'].update(state='delivered_main_pending',revision=254,manifest_sha256=c['manifest_sha256'],delivery_evidence='evidence/serve-video-projective-delivery-20261117/README.md')
  task['remaining_required']=['Multiple video tracks, presentation canvas/clipping and remaining format combinations','Audio/Realtime/image-generation/video-generation model assets and actual backend execution','Recorded model quality failures remain unresolved; never relabelled by other input/mode successes']
 if task['id']=='Q02':
  task['latest_release']=a|dict(evidence='evidence/serve-video-projective-delivery-20261117/README.md')
  task['remaining_required']=['Projective video delivery exact-head checks and actual main merge','Delivery of every remaining implementation']
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev254 or then-current default; do not stop camera/jtop without pending maintenance handoff.'
j['next_task']='Q02';j['next']='Freeze rev254 native day handoff, complete exact-head checks and actual main merge; continue every remaining master task.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev254有限透视视频交付](evidence/serve-video-projective-delivery-20261117/README.md)：原生精确像素变换、v5冻结重放及可回退发行。\n')
p=R/'README.md';s=p.read_text();assert '一般透视、多轨和其余格式继续实现。' in s
s=s.replace('一般透视、多轨和其余格式继续实现。','rev254进一步补齐非单位齐次比例与有限透视，\n[原生整数像素变换/v5冻结重放](docs/evidence/serve-video-projective-delivery-20261117/README.md)\n已经实际验证并可回退交付。多轨、裁剪画布和其余格式继续实现。')
s=s.replace('正交旋转/镜像、像素比例及有界仿射已校正，显式视频high细节可用；','正交旋转/镜像、像素比例、仿射和有限透视已校正，视频high细节可用；');p.write_text(s)
print(json.dumps({k:a[k] for k in ['status','revision','commands','seconds','archive_sha256']}))

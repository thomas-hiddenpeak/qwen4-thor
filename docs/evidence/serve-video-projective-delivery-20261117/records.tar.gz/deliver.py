"""STOPPED native projective video delivery with modern root rollback and preserved budgets."""
import copy,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle,publication,profile_manager,profile_migration,ledger,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'delivery-01';DEFAULT=R/'build';STATE=DEFAULT/'service-native-state'
OLD='ad8f443e7e16adaa864ad1729c4c7cda5fc7338473d89da5e1cb3aadf3e7d976'

def preserved():
 return {str(f.relative_to(STATE)):p.sha(f) for f in STATE.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(STATE).parts[0].startswith(('client-','outer-')))}
def version():return p.read(STATE/'version-selection/policy.json')['state']['policy']
def profiles():return p.read(STATE/'profile-selection/policy.json')['state']['policy']
def exact(before,after):p.require({k:v for k,v in before.items() if k!='revision'}=={k:v for k,v in after.items() if k!='revision'} and after['revision']>before['revision'],'root switch lost original cycle')
def receipt(directory):return {key:dict(path=str(directory/name),sha256=p.sha(directory/name)) for key,name in [('release','service-release.json'),('decision','decision.json')]}
def prepare():
 p.require(not OUT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=R),'clean committed delivery required')
 current=publication.status(STATE);roots=dict(candidate=p.read(W/'package-01/receipt.json'),retained=p.read(W/'modern-retained-01/receipt.json'))
 # Use only the descriptors; prepare receipts also carry ancillary fields.
 roots={name:{k:v[k] for k in ('package','manifest_sha256')} for name,v in roots.items()}
 accept=p.read(W/'publication-composition.json')
 p.require(current['ready'] and current['revision']==244 and current['current']['manifest_sha256']==OLD,'default predecessor changed')
 p.require(accept['status']=='ACCEPT_NATIVE_VIDEO_PROJECTIVE_COMPOSITION' and accept['cleanup_complete'] and accept['nvml_all_ok'],'business incomplete')
 p.require(len(list((DEFAULT/'.q4t-publication/generations').iterdir()))<=30 and len(list((STATE/'version-registrations').glob('*.json')))<=14,'bounded pools need retired archival')
 old=bundle.verify(current['current']['package'],OLD);manifests={n:bundle.verify(v['package'],v['manifest_sha256']) for n,v in roots.items()}
 for n,h in manifests['candidate']['files'].items():
  if n.startswith('source/'):p.require(p.sha(R/n[7:])==h,'runtime source drift')
 for n,h in p.read(Path(roots['candidate']['package'])/'native-build.json')['source_files'].items():p.require(p.sha(R/n)==h,'native source drift')
 permit=profile_manager.compatible(old,manifests['retained'],current['current']['package'],roots['retained']['package'])
 p.require(permit is not None and profile_manager.compatible(manifests['retained'],manifests['candidate'],roots['retained']['package'],roots['candidate']['package']) is None,'reviewed one-time profile extension required')
 prior_profiles=profiles();clock=prior_profiles['clock'];expected_profiles=profile_migration.candidate(prior_profiles,permit,ledger.Stamp(clock['boot_id'],clock['monotonic_ns']))
 p.require(all(prior_profiles[k]==expected_profiles[k] for k in ('history','pending','selected','not_before_ns','light_since_ns','clock','configuration')),'profile extension changed historical budgets')
 previous_version=version();p.require(previous_version['registry']['root_manifest_sha256']==OLD and previous_version['switch'] is None and previous_version['terminal_fault'] is None,'original cycle not quiescent')
 modern=receipt(W/'modern-business-01');legacy_receipt=receipt(W/'legacy-business-01');legacy=accept['automatic_fallback']
 version_contract.accepted_fallback(modern,version_contract.payload(roots['retained']))
 version_contract.accepted_fallback(legacy_receipt,version_contract.payload(legacy))
 OUT.mkdir(mode=0o700);shutil.copytree(STATE,OUT/'previous-state',symlinks=True)
 generation=(DEFAULT/'q4t').resolve().parent;(OUT/'previous').mkdir(mode=0o700)
 for n in ('q4t','q4t.release.json','service.release.json','service.acceptance.json'):shutil.copyfile(generation/n,OUT/'previous'/n)
 registrations={n:version_contract.prepare(root,root,legacy,str(uuid.uuid4()),fallback_acceptance=legacy_receipt) for n,root in roots.items()}
 for name,value in registrations.items():p.save(OUT/(name+'-registration.json'),value)
 review=dict(previous=current,previous_version=previous_version,preserved=preserved(),previous_profiles=prior_profiles,expected_profiles=expected_profiles,profile_upgrade_permit=permit,roots=roots,registrations=registrations,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),acceptance=accept,automatic_payload_fallback=legacy,manual_modern_root_fallback=roots['retained'],new_gpu_starts=0,driver_sha256=p.sha(Path(__file__)))
 p.save(OUT/'review.json',review);original=p.read(OUT/'previous/service.release.json')
 for name,target in roots.items():
  package=Path(target['package']);kind='NATIVE_VIDEO_PROJECTIVE_'+name.upper()+'_DELIVERY'
  actual=copy.deepcopy(accept['modern_service_acceptance']['actual_business'])
  if name=='candidate':
   actual.update(status='ACCEPT_COMPOSED_NATIVE_VIDEO_PROJECTIVE_DELIVERY',candidate_whole_package_gpu_run=False,source_composition=dict(changed_modules=accept['candidate_control_delta'],targeted_cpu='docs/evidence/serve-video-affine-service-preflight-20261117/README.md',live_controller_unchanged=True,native_helpers_unchanged=True),profile_qualification=p.read(W/'profiles-01/acceptance.json'),modern_retained_original_package=roots['retained'])
  decision=dict(status='PASS_'+kind,acceptance='ACCEPT_'+kind,manifest_sha256=target['manifest_sha256'],engine_binary_sha256=accept['binary_sha256'],actual_business=actual,original_decision=dict(path=str(W/'publication-composition.json'),sha256=p.sha(W/'publication-composition.json')),control_review=str(OUT/'review.json'),new_gpu_starts=0,performance_acceptance=False,long_stability_accepted=False,remaining_master_tasks_open=True)
  p.save(OUT/(name+'-decision.json'),decision);reg=registrations[name];engine=p.read(package/'engine/q4t.release.json')
  release=copy.deepcopy(original);release.update(acceptance=decision['acceptance'],acceptance_record=str(OUT/(name+'-decision.json')),acceptance_sha256=p.sha(OUT/(name+'-decision.json')),package=str(package),manifest_sha256=target['manifest_sha256'],recovery_accepted=True,engine_binary_sha256=p.sha(package/'engine/q4t'),engine_release_sha256=p.sha(package/'engine/q4t.release.json'),guardian_sha256=p.sha(package/'bin/q4t-guardian'),cuda_probe_sha256=p.sha(package/'bin/q4t-cuda-probe'),ingress_sha256=p.sha(package/'bin/q4t-ingress'),recovery_bundle_profile=manifests[name]['profile'],control_review=str(OUT/'review.json'),control_source_commit=review['source_commit'],engine_metadata_unchanged=False,engine_default_replaced=True,engine_qualification_receipt_immutable=True,previous_acceptance_record=original['acceptance_record'],adaptive_profiles_registry=manifests[name]['recovery_profiles'],adaptive_profiles_policy=manifests[name]['recovery_profile_policy'],client_artifacts=engine['client_artifacts']['directory'],state=str(STATE),initial_desired='STOPPED',automatically_started=False,version_recovery_registration=str(OUT/(name+'-registration.json')),version_recovery_registration_sha256=p.sha(OUT/(name+'-registration.json')),version_recovery_cycle_id=reg['registry']['cycle_id'],native_outer_enabled=True,unaffected_control_recovery_reused_by_exact_source_identity=True,native_video_affine_detail_business_evidence=decision['original_decision']['path'],gpu_starts_for_install=0,scope='Native finite projective display through JSON/SSE and frozen history accepted on this exact engine. Primary/light document-tool, structure, embedding and media passed. Exact retained controls demonstrate real projective high-detail SSE, stored response, client isolation and singular-error same-PID text. Control/client/native-helper runtime implementations unchanged and prior recovery evidence reused. Automatic/manual paths preserve current engine and capabilities; independent old-engine fallback not claimed. Original auto tiny-input model quality failure remains separate; no performance/full-quality claim. Remaining master tasks continue.')
  if name=='retained':release.pop('rollback_receipt',None);release.pop('rollback_sha256',None)
  p.save(OUT/(name+'-service.release.json'),release)
 anchor=dict(**roots['retained'],service_release=str(OUT/'retained-service.release.json'),service_release_sha256=p.sha(OUT/'retained-service.release.json'),manual_root_rollback_requires_stopped=True,retains_native_outer_and_cycle_migration=True)
 p.save(OUT/'recovery-anchor.json',anchor);release=p.read(OUT/'candidate-service.release.json');release.update(rollback_receipt=str(OUT/'recovery-anchor.json'),rollback_sha256=p.sha(OUT/'recovery-anchor.json'));p.save(OUT/'candidate-service.release.json',release)
 p.save(OUT/'requests.json',{k:str(uuid.uuid4()) for k in ('upgrade','anchor','candidate','rollback','forward')});print(json.dumps(dict(status='PREPARED_NATIVE_VIDEO_PROJECTIVE_DELIVERY',roots=roots,new_gpu_starts=0)))

def run():
 review=p.read(OUT/'review.json');roots=review['roots'];ids=p.read(OUT/'requests.json');cli=Path(roots['candidate']['package'])/'bin/q4t';rows=[];started=time.monotonic();expected_profiles=review['previous_profiles']
 def call(label,args):
  p.require(len(rows)<20,'STOPPED command bound');raw=list(map(str,args));r=subprocess.run(raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
  (OUT/(label+'.stdout')).write_text(r.stdout);(OUT/(label+'.stderr')).write_text(r.stderr);rows.append(dict(label=label,argv=raw,returncode=r.returncode))
  p.require(r.returncode==0,'delivery command failed: '+label);p.require(preserved()==review['preserved'],'core/client/outer changed');p.require(profiles()==expected_profiles,'profile migration/budget changed');return json.loads(r.stdout)
 def publish(label,name,previous,revision,key):
  t=roots[name];return call(label,[cli,'service','publish','--state',STATE,'--default-root',DEFAULT,'--package',t['package'],'--manifest-sha256',t['manifest_sha256'],'--service-release',OUT/(name+'-service.release.json'),'--expected-manifest-sha256',previous,'--expected-revision',revision,'--request-id',ids[key]])
 def register(name,previous):
  v=call(name+'-register',[DEFAULT/'q4t','service','version-register','--state',STATE,'--registration',OUT/(name+'-registration.json'),'--expected-cycle',previous]);p.require(v['registered'] and not v['fallback_consumed'],'registration failed');return version()
 try:
  p.require(call('previous-check',[cli,'service','check','--state',STATE,'--package',review['previous']['current']['package'],'--manifest-sha256',OLD])['desired']=='STOPPED','default active')
  for name,t in roots.items():p.require(call(name+'-check',[cli,'service','check','--package',t['package'],'--manifest-sha256',t['manifest_sha256']])['status']=='PASS','package check')
  expected_profiles=review['expected_profiles']
  value=publish('capability-upgrade','candidate',OLD,244,'upgrade');p.require(value['durable'] and value['revision']==246,'explicit native projective video capability upgrade')
  candidate_state=register('candidate',review['previous_version']['registry']['cycle_id']);p.save(OUT/'candidate-cycle.json',candidate_state)
  value=publish('anchor-publish','retained',roots['candidate']['manifest_sha256'],246,'anchor');p.require(value['durable'] and value['revision']==248,'anchor publication');generation=value['current']['generation_sha256']
  anchor_state=register('retained',candidate_state['registry']['cycle_id']);p.save(OUT/'anchor-cycle.json',anchor_state)
  value=publish('candidate-publish','candidate',roots['retained']['manifest_sha256'],248,'candidate');p.require(value['durable'] and value['revision']==250,'candidate publication');exact(candidate_state,version())
  value=call('rollback',[cli,'service','publish-rollback','--state',STATE,'--default-root',DEFAULT,'--package',roots['candidate']['package'],'--manifest-sha256',roots['candidate']['manifest_sha256'],'--generation-sha256',generation,'--expected-manifest-sha256',roots['candidate']['manifest_sha256'],'--expected-revision',250,'--request-id',ids['rollback']]);p.require(value['durable'] and value['revision']==252,'root rollback');exact(anchor_state,version())
  p.require(call('rollback-check',[DEFAULT/'q4t','service','check','--state',STATE])['desired']=='STOPPED','retained root failed')
  p.require(call('rollback-outer',[DEFAULT/'q4t','service','outer-status','--state',STATE])['enabled'],'retained outer absent')
  value=publish('forward','candidate',roots['retained']['manifest_sha256'],252,'forward');p.require(value['durable'] and value['revision']==254,'forward');exact(candidate_state,version())
  for action in ('check','status','observe'):
   v=call('default-'+action,[DEFAULT/'q4t','service',action,'--state',STATE]);p.require(v['status']=='PASS' if action=='check' else v['state']=='STOPPED','default health')
  pro=call('profiles',[DEFAULT/'q4t','service','profiles-status','--state',STATE]);p.require(pro['selected']=='primary','profile selected changed')
  ver=call('version',[DEFAULT/'q4t','service','version-status','--state',STATE]);p.require(ver['cycle_id']==candidate_state['registry']['cycle_id'] and not ver['fallback_consumed'],'cycle changed')
  outer=call('outer',[DEFAULT/'q4t','service','outer-status','--state',STATE]);p.require(outer['enabled'] and outer['charged_total']==0,'outer budget changed')
  final=call('publication',[DEFAULT/'q4t','service','publish-status','--state',STATE]);p.require(final['ready'] and final['revision']==254 and final['current']['manifest_sha256']==roots['candidate']['manifest_sha256'],'default differs')
  p.save(OUT/'result.json',dict(status='PASS_NATIVE_VIDEO_PROJECTIVE_DELIVERED',seconds=time.monotonic()-started,commands=rows,publication=final,retained_anchor_generation=generation,profiles=pro,versions=ver,outer=outer,anchor_cycle=anchor_state,candidate_cycle=candidate_state,final_cycle=version(),preserved=review['preserved'],expected_profiles=expected_profiles,state='STOPPED',new_gpu_starts=0,all_master_tasks_active=True));print(json.dumps(dict(status='PASS_NATIVE_VIDEO_PROJECTIVE_DELIVERED',revision=254,commands=len(rows))))
 except BaseException as error:
  p.save(OUT/'result.json',dict(status='FAILED',commands=rows,error=repr(error),seconds=time.monotonic()-started));raise
if __name__=='__main__':
 os.umask(0o077);{'prepare':prepare,'run':run}[sys.argv[1]]()

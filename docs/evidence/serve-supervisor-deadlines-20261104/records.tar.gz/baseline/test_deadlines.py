"""Supervisor phase deadlines and stop precedence; no HTTP/model required."""
import time
import unittest
from tools.serve_service.test_service import Case
from tools.serve_service import package as pkg,supervisor as sup


class Deadlines(unittest.TestCase):
    def setUp(self):
        self.fixture=Case()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def events(self):
        return (self.fixture.root/'runtime/events.log').read_text().splitlines()

    def test_late_first_ready_is_rejected_before_publication(self):
        calls=[]
        def observe(pid,_port):
            calls.append(pid)
            if len(calls)==1:time.sleep(.15)
            else:pkg.save(self.fixture.root/'runtime/stop.request.json',{})
            return self.fixture.observation(pid)
        code,state=self.fixture.run_supervisor(observe,restarts=3)
        self.assertEqual(code,1)
        self.assertEqual(state['error'],'startup deadline exceeded')
        self.assertEqual((state['attempts'],state['restarts']),(1,0))
        self.assertFalse(any(row.endswith(' READY') for row in self.events()))
        self.assertTrue(state['cleanup_confirmed'])

    def test_late_recovery_cannot_clear_observation_deadline(self):
        calls=[]
        def observe(pid,_port):
            calls.append(pid)
            if len(calls)==2:raise sup.contracts.InvalidObservation('http_deadline')
            if len(calls)==3:time.sleep(.15)
            if len(calls)>3:pkg.save(self.fixture.root/'runtime/stop.request.json',{})
            return self.fixture.observation(pid)
        code,state=self.fixture.run_supervisor(observe,restarts=3)
        self.assertEqual(code,1)
        self.assertEqual(state['error'],'observation deadline exceeded')
        self.assertEqual(sum(row.endswith(' READY') for row in self.events()),1)
        self.assertEqual((state['attempts'],state['restarts']),(1,0))
        self.assertTrue(state['cleanup_confirmed'])

    def test_stop_during_probe_never_publishes_ready(self):
        def observe(pid,_port):
            pkg.save(self.fixture.root/'runtime/stop.request.json',{})
            return self.fixture.observation(pid)
        code,state=self.fixture.run_supervisor(observe,restarts=3)
        self.assertEqual(code,0)
        self.assertEqual(state['state'],'STOPPED')
        self.assertEqual((state['attempts'],state['restarts']),(1,0))
        self.assertFalse(any(row.endswith(' READY') for row in self.events()))
        self.assertTrue(state['cleanup_confirmed'])


if __name__=='__main__':unittest.main(verbosity=2)

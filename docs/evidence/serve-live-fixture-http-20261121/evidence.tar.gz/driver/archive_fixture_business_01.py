import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'fixture-business-01';O=R/'docs/evidence/serve-live-fixture-http-20261121';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
a=read(P/'acceptance.json');plan=read(P/'plan.json');assert a['status']=='PASS_LIVE_FIXTURE_AND_CLIENT_PROTOCOL' and a['quality']=='PASS'
files={}
for n in ['acceptance.json','counts.json','result.json','cleanup.json','before.json','live-drained.json','final-drained.json','final-config.http.json','final-config.wire','core-after.wire','query-fixture.json','query.pcm','observation.json','speech-health.json','client.events.jsonl','client.sdk.json','client.stderr','model.log','lease/exit.json','lease/nvml-queries.jsonl']:
 files['original/'+n]=(P/n).read_bytes()
for n in ['tools/serve_live/fixture_acceptance.py','tools/serve_live/fixture_checks.py','tools/serve_live/fixture_sdk.mjs','tools/serve_live/checks.py','tools/serve_live/client_acceptance.py','tools/serve_live/client_wait.mjs']:
 raw=(R/n).read_bytes();assert sha(raw)==plan['sources'][n];files['source/'+n]=raw
files['driver/archive_fixture_business_01.py']=Path(__file__).read_bytes();index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as archive:
 for n,raw in sorted(files.items()):
  index[n]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(raw),0o600,0;archive.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
summary=dict(a,source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],ingress_sha256=plan['ingress_sha256'],plan_sha256=sha((P/'plan.json').read_bytes()),cumulative_live=dict(starts=4,actual_work=14,seconds=255.282121422+a['seconds'],prior_failures_retained=True),archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',summary)
(O/'README.md').write_text('''# Live原生音频播放及真实业务恢复

实际候选8bba3d11、原生TLS入口与官方OpenAI JS 7.47.0 LiveWS通过。
1模型/1连接/1片段/1ASR+2前台+1普通Chat，68.022秒；65次NVML正常，
严格租约完成且进程、端口和锁释放，默认rev426保持STOPPED。

138240字节原录音以PCM24逐字节播放，接收区间2.884秒；此为本次观察，
不声称性能。播放中输入和显式静音后的输入均为含同一真实语音的探针，
没有额外ASR/委派或模型工作，静音保持到显式解除。之后正确转写
“请查询当前项目版本号。”，实际客户端读取STATUS并回填，原生语音
答复rev426，正常session.closed/1000，后续Chat=42。alpha RPM3不变，
实际3次准入/1717 tokens结算、预留归零。最终ASR合法释放、TTS就绪，
无加载/计算失败；声音是否实际听到及听感仍未验。

累计四轮4启动/14工作/323.305秒，早期未委派、静音尾部与旧健康断言
原失败保留。片段复用第二轮中已确认的真实合成子步骤，原轮次整体FAIL
不改写。[21项原生CPU及驱动反例](../serve-live-fixture-cpu-20261121/README.md)
与本次实际事件、结算、清理分别留证，不替代其他委派/恢复/媒体验收。

[result.json](result.json)、[原始事件与日志](evidence.tar.gz)、[逐文件SHA](index.json)。
完整私有计划只公开SHA，客户策略/网关配置/证书私钥不进归档。继续
Responses/Decisions、上下文保留、存储/旁路/fork、媒体及全部master任务。
''')
p=R/'docs/STATUS.md';s=p.read_text();begin=s.index('[Live音频片段21项CPU]');end=s.index('\n[Live主WSS客户端真实闭环已验]',begin)
s=s[:begin]+'''[Live音频播放与业务恢复短验通过](evidence/serve-live-fixture-http-20261121/README.md)：
1启动/1片段/4工作/68.022秒，65次NVML正常且资源释放。实际播放逐字节
一致，播放中/显式静音输入未引发额外工作；解除静音后完成正确ASR、
资料读取/回填、语音rev426、正常关闭和Chat=42。原RPM3保持，1717 tokens
结算且预留归零。已有21项CPU与5项驱动反例。累计4启动/14工作/323.305秒，
旧失败保留；听感未验。默认未改，继续Responses/Decisions及全部master。
''' + s[end:];p.write_text(s)
p=R/'docs/SERVE_LIVE_2026-11-21.md';p.write_text(p.read_text()+'''\n[音频播放实际SDK闭环](evidence/serve-live-fixture-http-20261121/README.md)通过：
1启动/1片段/4工作/68.022秒，逐字节输出、输入丢弃/静音保持、解除后
真实资料闭环、正常关闭及Chat=42均已验。65次NVML正常并释放租约；
累计4启动/14工作/323.305秒。默认未改、旧失败保留，继续其他全部子项。
''')
p=R/'docs/log/2026-11-21.md';p.write_text('''## Live音频播放及播放后真实资料闭环通过

日期：2026-11-21。做了什么：候选8bba3d11在严格租约下1模型、1片段、
4实际工作、68.022秒通过，65次NVML正常并完整清理。138240字节原音频
输出一致，播放中输入丢弃、显式静音保持；解除静音后真实ASR、资料
读取/回填、语音rev426、closed/1000及Chat=42通过。原RPM3、实际3次
alpha准入/1717 tokens结算、预留归零。为什么：证明播放与真实业务共用
实际所有权且可恢复，不能以CPU事件形状替代。下一步：Responses/Decisions
委派及上下文保留，再继续全部master；默认STOPPED未改，旧失败与听感
待验保留，累计4启动/14工作/323.305秒。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';master=read(p);master['native_live_20261121'].update(fixture_state='actual_sdk_fixture_playback_and_client_resume_pass',fixture_business_evidence='evidence/serve-live-fixture-http-20261121/README.md',gpu_starts=4,actual_work=14,gpu_seconds=summary['cumulative_live']['seconds']);save(p,master)
p=R/'tools/serve_audit/inventory.json';inv=read(p)
for group in ['routes','native_routes']:
 row=inv[group]['GET /v1/live/sessions'];row['boundary']='主WSS客户端委派与原生音频片段播放/静音/恢复真实资料闭环已验。Responses/Decisions、录制、旁路与媒体继续实现；主轻/恢复/发行待完成，不宣称完整Live兼容。';row['evidence'].append('docs/evidence/serve-live-fixture-http-20261121/README.md')
save(p,inv)
print(json.dumps(dict(status=summary['status'],archive_sha256=summary['archive_sha256'],files=len(files))))

from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-mcp-output-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
results=[read(W/f'output-cpu-0{i}/result.json') for i in range(1,4)];r=results[-1];assert [x['status'] for x in results]==['FAIL','FAIL','PASS'];assert r['tests']==12
assert all(sha(R/p)==h for p,h in r['sources'].items())
assert sha(W/'output-original-source.cpp')==results[0]['sources']['src/server/realtime_response_output.cpp']
assert sha(W/'output-original-test.cpp')==results[0]['sources']['tests/server_realtime_mcp_output_test.cpp']
assert sha(W/'output-second-test.cpp')==results[1]['sources']['tests/server_realtime_mcp_output_test.cpp']
files={n:W/n for n in ['output-plan.json','output-required.txt','output-repair-plan.json','output-repair-required.txt','output-binding-repair-plan.json','output-binding-repair-required.txt','output-original-source.cpp','output-original-test.cpp','output-second-test.cpp','archive_output_01.py']}
for i in range(1,4):
 for n in [f'build_output_0{i}.py',f'run_output_cpu_0{i}.py',f'output-build-0{i}/plan.json',f'output-build-0{i}/result.json',f'output-build-0{i}/build.log',f'output-cpu-0{i}/result.json',f'output-cpu-0{i}/stdout.txt',f'output-cpu-0{i}/stderr.txt']:files[n]=W/n
 assert read(W/f'output-build-0{i}/result.json')['warnings']==0
files.update({'source/'+p:R/p for p in r['sources']});O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
accepted=dict(status='PASS_REALTIME_MCP_ARGUMENTS_AND_HANDOFF_CPU',distinct_cases=20,case_executions=33,initial_passed=19,initial_failed=1,first_fixture_repair_failed=1,affected_mcp_recheck_passed=12,reused_ordinary_and_speech_passed=8,cpu_seconds=sum(x['seconds'] for x in results),builds_zero_warnings=3,binary_sha256=r['binary_sha256'],runtime_connected=False,complete_model_message_required=True,native_alias_must_match_public_server_tool=True,remote_completion_not_fabricated=True,handoff_at_most_once_after_accepted_response_done=True,original_failures_and_sources_preserved=True,first_capacity_only_diagnosis_was_incomplete=True,gpu_actions=0,llm_requests=0,default_revision=396,default_unchanged=True,service_state='STOPPED',all_master_tasks_active=True)
save(O/'acceptance.json',accepted)
(O/'README.md').write_text(f'''# Realtime MCP参数流与单次交接：CPU

2026-11-20。20项不同用例已覆盖：12项MCP输出最终通过，8项原函数/
语音合同复用首轮通过；累计33次执行、{accepted['cpu_seconds']:.3f}秒。
3次必要host构建零警告，旧binary与原失败来源均保留。

首轮19通过/1失败；最初仅归因为字符串复制丢弃reserve的判断不完整。
修正容量夹具后仍失败，发现通用ValidInputName允许空格，不能证明
内部MCP别名对应公开服务器/工具。补精确原生适配器映射校验，重验
受影响12项全部通过。8项空MCP绑定表的原函数/语音路径未受影响；
未将两次失败追认为成功，未降低容量或别名合同。

实际共享parser逐字节输出MCP专用参数delta/done，公开server_label和
name保持，内部别名不外泄；不同服务器同名工具与普通函数混合不
串用身份。有限模型消息、完整JSON对象、事件确认共同约束一次性交接。
截断、取消、失败、删除、身份差异、事件失败都不给执行交接；不存在
自动下一轮模型调用或参数完成即远端成功的伪造事件。

response.done之后，尚未执行的MCP条目仍pending；最终远端执行、审批
和conversation/output item终态由后续原生所有者完成。本组没有远端
调用或模型启动，公开会话入口尚未连接；0GPU、默认rev396 STOPPED。
继续串联配置/快照、原生审批/调用及SDK业务和恢复，全部master继续。

[计划](../../SERVE_REALTIME_MCP_2026-11-20.md) · [结果](acceptance.json) ·
[索引](index.json) · [原始失败、修复及源码](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();s=s.replace('正在补MCP生成参数与远端执行的终态分离，冻结20项针对性CPU；\n只有成功完成并确认发布的调用能单次交接，真实执行仍由原生权限所有者负责。','[MCP参数流与交接20项CPU](evidence/serve-realtime-mcp-output-cpu-20261120/README.md)\n完成：首轮19通过/1失败，容量夹具修正后暴露别名校验缺口，补精确\n映射后12项MCP通过，原8项复用。两次失败保留；后续原生结果、审批\n回填和历史关联继续，不能把生成完成当成工具完成。');p.write_text(s)
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n本组[20项CPU完成](evidence/serve-realtime-mcp-output-cpu-20261120/README.md)，\n累计33次执行/0.055秒。初始19通过/1失败，修正容量夹具后仍失败；\n补充内部别名必须等于实际适配器映射的校验，12项MCP重验通过，\n8项未改普通/语音分支复用。两次失败及错误初诊保留，3次构建零警告。\n接着实现原生结果/审批回填、history审批身份成熟和整体会话接线；\n公开运行时与默认保持，不将组件结果宣称为完整MCP闭环。\n''')
p=R/'docs/log/2026-11-20.md';s=p.read_text();at=s.index('\n\n')+2;s=s[:at]+'''## Realtime MCP参数流与交接CPU通过，别名校验缺口修复

日期：2026-11-20。

做了什么：[20项不同CPU用例](../evidence/serve-realtime-mcp-output-cpu-20261120/README.md)
累计33次执行/0.055秒，3次构建零警告。首轮19通过/1失败，最初仅归因
容量夹具的诊断不完整；修正copy丢reserve后仍失败。核实通用名字校验
允许空格，补MCP内部别名与公开服务器/工具的精确映射，12项MCP通过，
空MCP表的原8项函数/语音证据复用。原失败及各源码SHA保留。

为什么：真实parser参数流必须准确投影，模型最终消息和公开调用
身份必须一致；response.done不能伪造远端终态，取消/截断/删除或
发布失败不能交接执行。交接只发生一次，不自动生成下一轮回答。

下一步：补原生结果/审批和历史身份关联，串联公开会话并完成SDK/
GPU业务及恢复交付；本组尚未接通公开MCP，默认rev396 STOPPED、
0GPU/0LLM，总目标继续。

'''+s[at:];p.write_text(s)
p=R/'docs/README.md';s=p.read_text();at=s.index('\n\n')+2;s=s[:at]+'- [Realtime MCP参数流与执行交接CPU](evidence/serve-realtime-mcp-output-cpu-20261120/README.md)\n\n'+s[at:];p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p);m=j['realtime_progress']['mcp_20261120'];m['state']='definitions_catalog_import_ownership_and_argument_handoff_cpu_accepted_native_execution_integration_next';m['output_cpu']=accepted;m['output_evidence']='evidence/serve-realtime-mcp-output-cpu-20261120/README.md';save(p,j)
print(json.dumps(accepted))

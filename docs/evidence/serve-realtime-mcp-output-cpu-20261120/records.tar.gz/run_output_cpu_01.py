from pathlib import Path
import json,hashlib,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'output-cpu-01';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(W/'output-plan.json');build=read(W/'output-build-01/result.json');protection=read(W/'output-build-01/plan.json')['protected'];B=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests'
assert build['status']=='BUILD_PASS' and sha(B)==build['binary_sha256']
assert all(sha(R/p)==h for p,h in plan['sources'].items())
assert all(sha(Path(p))==h for p,h in protection.items())
cmd=[str(B),'--required-list',str(W/'output-required.txt')]
start=time.monotonic()
with (O/'stdout.txt').open('w') as out,(O/'stderr.txt').open('w') as err:
 try:code=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=plan['cpu_deadline_seconds']).returncode
 except subprocess.TimeoutExpired:code=124
seconds=time.monotonic()-start;unchanged=all(sha(Path(p))==h for p,h in protection.items())
text=(O/'stdout.txt').read_text();passed=code==0 and '20 tests, 20 passed, 0 failed, 0 skipped' in text and unchanged
result=dict(status='PASS' if passed else 'FAIL',command=cmd,tests=20,seconds=seconds,exit_code=code,binary_sha256=sha(B),default_unchanged=unchanged,runtime_connected=False,gpu_actions=0,llm_requests=0,sources=plan['sources'])
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if not passed:print(text[-9000:]);print((O/'stderr.txt').read_text()[-6000:])
raise SystemExit(0 if passed else 1)

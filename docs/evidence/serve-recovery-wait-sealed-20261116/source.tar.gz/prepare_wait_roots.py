"""Sealed successor roots; same engine/ingress, CPU-qualified wait projection."""
import copy,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent
ALLOWED={'tools/serve_recovery/deployment.py','tools/serve_host/native.py'}
def replace(path,raw,mode=0o400):
 if path.exists():path.chmod(0o600)
 path.write_bytes(raw);path.chmod(mode)
def main():
 os.umask(0o077);p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'commit source')
 oldroots=p.read(W/'roots.json');result={};guardian=W/'guardian-build/q4t-guardian'
 cpu=p.read(R/'docs/evidence/serve-recovery-wait-cpu-20261116/acceptance.json')
 p.require(p.sha(guardian)==cpu['guardian_sha256'],'CPU-qualified Guardian changed')
 for name,desc in oldroots.items():
  old=Path(desc['package']);manifest=bundle.verify(old,desc['manifest_sha256'])
  out=W/(name+'-02');p.require(not out.exists(),'preserve immutable root');out.mkdir(mode=0o700)
  target=out/'bundle';shutil.copytree(old,target,symlinks=True);manifest=copy.deepcopy(manifest)
  for n in ALLOWED:
   replace(target/'source'/n,(R/n).read_bytes());manifest['files']['source/'+n]=p.sha(target/'source'/n)
  replace(target/'bin/q4t-guardian',guardian.read_bytes(),0o500);manifest['files']['bin/q4t-guardian']=p.sha(guardian)
  receipt=p.read(old/'native-build.json');changed={n:p.sha(R/n) for n,h in receipt['source_files'].items() if p.sha(R/n)!=h}
  p.require(set(changed)=={'src/service/guardian_main.cpp'},'unreviewed native delta')
  receipt['source_files'].update(changed);receipt['guardian_sha256']=p.sha(guardian)
  receipt['reuse_review']=dict(previous=str(old/'native-build.json'),sha256=p.sha(old/'native-build.json'),changed_sources=changed,
   executable_hashes_identical={n:manifest['files']['bin/'+n]==p.sha(old/'bin'/n) for n in ('q4t-guardian','q4t-cuda-probe','q4t-ingress','q4t-device-control')},
   rationale='Only typed recovery wait projection and checked delay reason validation changed in Guardian. Exact new Guardian passed targeted CPU role budget and gateway recovery checks. Engine, device/ingress helpers and profile qualification are unchanged; source build and first configure failure retained.',
   build=str(W/'wait-build-01.json'),build_sha256=p.sha(W/'wait-build-01.json'),cpu=str(R/'docs/evidence/serve-recovery-wait-cpu-20261116/acceptance.json'),cpu_sha256=p.sha(R/'docs/evidence/serve-recovery-wait-cpu-20261116/acceptance.json'))
  replace(target/'native-build.json',json.dumps(receipt,indent=2).encode()+b'\n');manifest['files']['native-build.json']=p.sha(target/'native-build.json')
  replace(target/'manifest.json',json.dumps(manifest,indent=2).encode()+b'\n');digest=p.sha(target/'manifest.json')
  replace(target/'bin/q4t',bundle.launcher(digest,manifest['python']['path']),0o500)
  p.require(bundle.verify(target,digest)==manifest,'sealed successor differs')
  delta={n for n,h in manifest['files'].items() if p.sha(old/n)!=h}
  p.require(delta=={'source/'+n for n in ALLOWED}|{'bin/q4t-guardian','native-build.json'},'unexpected runtime delta')
  result[name]=dict(package=str(target),manifest_sha256=digest)
  p.save(out/'receipt.json',result[name]);p.save(out/'review.json',dict(state='SEALED_CPU_ACCEPTED_BUSINESS_PENDING',previous=desc,delta=sorted(delta),new=result[name],cpu_guardian_sha256=p.sha(guardian),engine_unchanged=True,profiles_unchanged=True,default_unchanged=True))
 p.save(W/'wait-roots.json',result);print(json.dumps(result))
if __name__=='__main__':main()

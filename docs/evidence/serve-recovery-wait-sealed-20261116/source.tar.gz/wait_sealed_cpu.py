import json,subprocess,sys,unittest
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1]
SCRIPT='''import json,runpy,sys
from pathlib import Path
r=Path(sys.argv[1]);plan=json.loads(sys.argv[2]);m=runpy.run_path(str(r/'tools/serve_recovery/acceptance.py'))
b,_,_,_,_,p=m['load_modules'](dict(package=plan));v=b.verify(plan['package'],plan['manifest_sha256'])
from tools.serve_recovery import deployment
from tools.serve_host import native
import inspect
assert 'migration' in inspect.signature(deployment.preserve_outer).parameters
assert native.project_wait(dict(role='gateway',reason='budget_exhausted',retry_after_ms=900000)) is not None
assert native.project_wait(dict(role='gateway',reason='private',retry_after_ms=900000)) is None
cpu=p.read(r/'docs/evidence/serve-recovery-wait-cpu-20261116/acceptance.json')
assert v['files']['bin/q4t-guardian']==cpu['guardian_sha256']
for module in (b,deployment,native):assert Path(module.__file__).is_relative_to(Path(plan['package'])/'source')
print(json.dumps(dict(status='PASS_EXACT_SEALED_CPU',manifest=plan['manifest_sha256'],guardian=v['files']['bin/q4t-guardian'],no_model=True)))
'''
class SealedTests(unittest.TestCase):
 def check(self,name):
  plan=json.loads((W/'wait-roots.json').read_text())[name]
  r=subprocess.run([sys.executable,'-I','-B','-c',SCRIPT,str(R),json.dumps(plan)],capture_output=True,text=True,timeout=20)
  (W/('wait-sealed-'+name+'.json')).write_text(json.dumps(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n')
  self.assertEqual(r.returncode,0,r.stderr)
 def test_exact_candidate(self):self.check('candidate')
 def test_exact_retained(self):self.check('retained')
if __name__=='__main__':unittest.main()

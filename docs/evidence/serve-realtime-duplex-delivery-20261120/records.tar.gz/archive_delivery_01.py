"""Preserve the completed native duplex publication and reversible maintenance."""
import hashlib,json,re,sys,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_service.package import read,sha,require
D=W/'delivery-01';M=W/'publication-maintenance-01'
v=read(D/'result.json');c=read(W/'publication-composition.json');m=read(M/'result.json')
current=v['publication']['current'];O=R/'docs/evidence/serve-realtime-duplex-delivery-20261120'
require(not O.exists() and v['status']=='PASS_NATIVE_REALTIME_DUPLEX_DELIVERED'
    and v['publication']['revision']==386 and v['state']=='STOPPED','delivery incomplete')
require(len(v['commands'])==19 and all(r['returncode']==0 for r in v['commands'])
    and v['outer']['enabled'] and v['outer']['charged_total']==0,'CLI or outer differs')
require(sha(R/'build/q4t')==c['binary_sha256'] and
    sha(R/'build/service/manifest.json')==c['candidate']['manifest_sha256'] and
    sha(R/'build/service.release.json')==current['service_release_sha256'],'default differs')
require(all(sha(R/'build/service-native-state'/n)==h for n,h in v['preserved'].items()),
    'client/core/outer history differs')
require(m['status']=='PASS_REVERSIBLE_RETIRED_METADATA_ARCHIVE'
    and m['live_state_unchanged'] and m['deleted_files']==0,'archive incomplete')
clients=read(R/'build/service-native-state/client-limits/policy.json')['state']['policy']['clients']
limits={r['id']:{k:r[k] for k in ('requests_per_minute','tokens_per_minute','max_output_tokens')} for r in clients}
require(limits==dict(alpha=dict(requests_per_minute=30,tokens_per_minute=6000,max_output_tokens=3457),
    beta=dict(requests_per_minute=1,tokens_per_minute=6000,max_output_tokens=256)),'live quota differs')
files={str(p.relative_to(W)):p for p in D.iterdir() if p.is_file()}
for p in M.rglob('*'):
    if p.is_file() and len(p.relative_to(M).parts)<=2:files[str(p.relative_to(W))]=p
for n in ('deliver_duplex_01.py','maintain_publication_01.py','publication-composition.json','archive_delivery_01.py'):
    files[n]=W/n
secrets=[]
def collect(value):
    if isinstance(value,dict):
        for key,item in value.items():
            if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(item,str) and len(item)>=24:
                secrets.append(item.encode())
            else:collect(item)
    elif isinstance(value,list):
        for item in value:collect(item)
for p in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(p))
for name,p in files.items():
    raw=p.read_bytes();require(not any(s in raw for s in secrets) and not re.search(
        rb'-----BEGIN [A-Z ]*PRIVATE KEY-----\s+[A-Za-z0-9+/=]{10,}',raw),'private authority: '+name)
O.mkdir();rows={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as t:
    for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
    seen=set()
    for item in t:
        require(item.isfile() and item.name in rows and item.name not in seen,'archive member differs')
        raw=t.extractfile(item).read();require(hashlib.sha256(raw).hexdigest()==rows[item.name]['sha256']
            and len(raw)==rows[item.name]['bytes'],'archive bytes differ');seen.add(item.name)
    require(seen==rows.keys(),'missing archive record')
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
save(O/'index.json',dict(records=rows,archive_sha256=sha(O/'records.tar.gz')))
summary=dict(status=v['status'],revision=386,state='STOPPED',current=current,
    binary_sha256=c['binary_sha256'],protocol_sha256=c['protocol_sha256'],
    successful_commands=19,seconds=v['seconds'],new_gpu_starts=0,
    outer_enabled=True,outer_charged_total=0,persistent_client_limits=limits,
    usage_reset=False,profile_history_and_cooldown_preserved=True,version_cycles_preserved=True,
    manual_root=c['automatic_fallback'],automatic_payload=c['automatic_fallback'],
    candidate_to_retained_automatic_fault_actually_tested=True,
    reciprocal_automatic_fault_additionally_injected=False,
    reciprocal_registration_and_stopped_rollback_verified=True,
    previous_rev376_preserved=True,retired_records_archived_per_pool=4,deleted_files=0,
    maintenance_seconds=m['seconds'],model_quality_status='FAIL',model_quality_separate=True,
    original_model_quality_failures_preserved=True,original_driver_failure_preserved=True,
    listening_deferred_by_owner=True,main_integration_pending=True,full_model_quality=False,
    performance_claim=False,long_stability_run=False,full_openai_compatibility=False,
    all_master_tasks_active=True,secret_scan_matches=0,
    evidence='evidence/serve-realtime-duplex-delivery-20261120/README.md')
save(O/'acceptance.json',summary)
print(json.dumps(dict(status=summary['status'],revision=386,seconds=v['seconds'],
    archive_bytes=(O/'records.tar.gz').stat().st_size)))

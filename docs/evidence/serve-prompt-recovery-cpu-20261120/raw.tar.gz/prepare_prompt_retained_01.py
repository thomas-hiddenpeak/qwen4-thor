"""Exact retained controller with current qualified native Realtime Chat engine and readers."""
import copy
import os
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as p
WORK=Path(__file__).resolve().parent
PRIMARY=WORK/'service-package-01/bundle'
OUT=WORK/'retained-01'
PREVIOUS=ROOT/'.q4t-work/serve-semantic-vad-20261119/retained-01/bundle'
PREVIOUS_SHA='101d0cf1406a083b6d69bf37ec737eca42270cd1e34dc65c33282dbeab42b7ca'

def main():
    os.umask(0o077)
    p.require(not OUT.exists(),'preserve preparation')
    protected={n:p.sha(ROOT/n) for n in ('build/q4t','build/q4t.release.json',
        'build/service/manifest.json','build/service.release.json',
        'build/service-native-state/ledger.json')}
    current=bundle.verify(PRIMARY,p.sha(PRIMARY/'manifest.json'))
    old=bundle.verify(PREVIOUS,PREVIOUS_SHA)
    rel='source/tools/serve_recovery/controller.py'
    p.require(current['version']==22 and old['version']==20 and
        current['files'][rel]!=old['files'][rel], 'distinct retained controller required')
    OUT.mkdir(mode=0o700);target=OUT/'bundle'
    def copy_file(source,destination):
        source=Path(source)
        if source.relative_to(PRIMARY).as_posix() not in ('manifest.json','bin/q4t','source/tools/serve_recovery/controller.py') and source.stat().st_mode & 0o222 == 0:
            p.require(source.stat().st_mode & 0o222==0,'shared payload must be immutable')
            os.link(source,destination)
        else:shutil.copy2(source,destination)
        return destination
    shutil.copytree(PRIMARY,target,symlinks=True,copy_function=copy_file)
    manifest=copy.deepcopy(current)
    path=target/rel;path.chmod(0o600);shutil.copyfile(PREVIOUS/rel,path);path.chmod(0o400)
    manifest['files'][rel]=p.sha(path)
    path=target/'manifest.json';path.chmod(0o600);p.save(path,manifest);path.chmod(0o400)
    digest=p.sha(path)
    path=target/'bin/q4t';path.chmod(0o700)
    path.write_bytes(bundle.launcher(digest,manifest['python']['path']));path.chmod(0o500)
    p.require(bundle.verify(target,digest)==manifest,'retained verification failed')
    difference={n for n,h in manifest['files'].items() if current['files'].get(n)!=h}
    p.require(difference=={rel},'unreviewed retained changes')
    root=dict(package=str(PRIMARY),manifest_sha256=p.sha(PRIMARY/'manifest.json'))
    fallback=dict(package=str(target),manifest_sha256=digest)
    permit=version_contract.compatible(version_contract.payload(root),version_contract.payload(fallback))
    p.require(permit['automatic'],'retained compatibility failed')
    p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
    p.save(OUT/'receipt.json',fallback)
    p.save(OUT/'review.json',dict(status='NEW_COMPOSITION_ACTUAL_BUSINESS_PENDING',
        previous=dict(package=str(PREVIOUS),manifest_sha256=PREVIOUS_SHA),
        candidate=root,fallback=fallback,changed_from_candidate=sorted(difference),
        exact_retained_controller_sha256=old['files'][rel],compatibility=permit,
        rationale='The same modern retained root will undergo actual standalone business and actual automatic payload recovery, then stopped root rollback. No need for a second legacy controller composition to prove these same two roles.',
        same_qualified_engine=True,older_engine_fallback=False,
        original_acceptance_not_relabelled=True,shared_immutable_engine=str(PRIMARY/'engine/q4t'),
        default_unchanged=True,model_actions=0,driver_sha256=p.sha(Path(__file__))))
    print(digest,flush=True)

if __name__=='__main__':main()

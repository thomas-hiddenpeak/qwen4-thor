from pathlib import Path
import fcntl,hashlib,json,re,shutil,tarfile
from tools.serve_audit import check_inventory as audit
from tools.native_tts.acceptance import defaults
from tools.serve_grammar_reap import acceptance as lifecycle
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=R/'docs/evidence/serve-voice-chat-fix-20261119';O.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def save(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
phase=V/'voice-http-06';result=read(phase/'run/result.json');assert result['status']=='PASS_CHAT_REGISTERED_VOICE_PERSISTENCE_SCOPE_REVOKE' and result['counts']['posts']==7
prior=read(V/'voice-http-05/run/result.json');assert prior['status']=='FAILED' and prior['counts']['posts']==11
cpu=read(V/'chat-voice-fix-cpu-01/result.json');assert cpu['status']=='PASS' and cpu['cases']==5
plan=read(phase/'plan.json');assert defaults()==plan['http']['defaults']
for n,h in plan['http']['production_sources'].items():assert sha(R/n)==h
leases={}
for name,status in [('voice-aiden-diagnostic-01','COMPLETED'),('voice-http-05','COMMAND_FAILED'),('voice-http-06','COMPLETED')]:
 d=V/name;ex=read(d/'lease/exit.json');assert ex['status']==status
 qs=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(q['status']=='OK' for q in qs) and qs[-1]['pids']==[]
 clean=read(d/'run/cleanup.json');assert not clean['remaining'] and clean['ports_released'] and clean['model_exit']==0
 for pid in clean['owned']:assert not Path('/proc',pid).exists()
 leases[name]=dict(status=status,nvml_queries=len(qs),all_nvml_ok=True,owned_cleanup=True)
with lifecycle.guard.common_lock().open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
log=(V/'voice-http-05/run/model.log').read_text()
labels={code:bool(re.search(r'event=end .*outcome=error reason='+code+r' ',log)) for code in ('voice_consent_mismatch','voice_speaker_mismatch','client_tpm_exhausted')}
assert all(labels.values())
log=(phase/'run/model.log').read_text();assert len(re.findall(r'id=chatcmpl-[^ ]+ event=end .*outcome=error reason=object_not_found ',log))==2
snapshot=read(phase/'run/registered-state.json')
assert all(sha(phase/'run/registered-state'/p)==h for p,h in snapshot['files'].items())
actual=audit.current_surface(R);inv=read(audit.INVENTORY)
changed={p for p in actual['sources_sha256'] if actual['sources_sha256'][p]!=inv['sources_sha256'].get(p)}
assert changed=={'src/server/chat_generation.cpp'},changed
for p in changed:inv['sources_sha256'][p]=actual['sources_sha256'][p]
save(audit.INVENTORY,inv);errors=audit.check(inv,actual);mutations=audit.mutation_checks(inv,actual);assert not errors and mutations==17
save(O/'audit.json',dict(anchors=len(actual['sources_sha256']),mutations=mutations,errors=errors,reviewed=sorted(changed)))
# Preserve the incorrect build helper archive hint; the pointed archive holds
# an older host binary, not the pre-build SHA. No rollback relies on that hint.
save(V/'chat-voice-fix-build-01/prior-host-correction.json',dict(original=read(V/'chat-voice-fix-build-01/prior-host.json'),archive_reused_is_not_same_binary=True,prior_host_preservation_not_claimed=True,affected_tests_executed_on_new_known_binary=True,production_candidate_C04_preserved=True))
save(phase/'prepare-invocation-note.json',dict(initial_cli_error='python -m rejects a relative module path',model_loads=0,http=0,corrected='PYTHONPATH=. python3 -B prepare_voice_chat_continue_06.py',no_test_outcome_rewritten=True))
summary=dict(status='PASS_REGISTERED_VOICE_SPEECH_CHAT_SCOPE_RESTART_REVOKE',complete_voice_api_qualification=False,engine_sha256=sha(V/'voice-service-candidate-05/q4t'),original_chat_failure_retained=True,original_ryan_identity_failure_retained=True,actual_http_reused='voice-http-05 registration/Speech unaffected by Chat-only fix',cpu_cases=5,cpu_seconds=cpu['seconds'],continuation_posts=7,continuation_seconds=result['seconds'],leases=leases,terminal_dynamic_labels=labels,threshold_unchanged=.65,listening='PENDING',human_identity='NOT_CLAIMED',sdk_tls_profiles_managed_recovery='PENDING',default_replaced=False)
save(O/'result.json',summary);save(O/'default-unchanged.json',defaults())
files=[]
for name in ('voice-aiden-diagnostic-01','voice-aiden-diagnostic-build-01','voice-http-05','voice-http-06','chat-voice-fix-build-01','chat-voice-fix-cpu-01'):
 for p in (V/name).rglob('*'):
  if p.is_file() and p.suffix not in ('.o','.wav','.f32') and p.name not in ('q4t_voice_aiden_diagnostic','pcm.f32'):
   # Full private states are explicitly retained below for reproducible reader checks.
   files.append(p)
for n in ('fix_chat_registered_voice_01.py','build_chat_voice_fix_01.py','chat-voice-fix-plan-01.json','prepare_voice_http_continue_05.py','voice_http_continue_05.py','prepare_voice_chat_continue_06.py','voice_chat_continue_06.py','build_voice_aiden_diagnostic_01.py','voice_aiden_diagnostic_01.py','freeze_voice_aiden_diagnostic_01.py','freeze_voice_aiden_diagnostic_02.py','archive_voice_chat_fix_01.py','archive_voice_chat_fix_02.py'):files.append(V/n)
files+=[R/'src/server/chat_generation.cpp',V/'voice-service-candidate-05/chat_protocol_sources.json',V/'voice-service-candidate-05/identity.json']
assert shutil.disk_usage(R).free>(256<<20)+sum(p.stat().st_size for p in files)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files},original_audio_retained_at_same_local_paths=True))
write(O/'README.md','''# 已注册音色Chat入口修复与真实持久闭环

原aiden固定一次合成（2 Speech/67.786秒）两录音单声纹检查通过，
跨录音0.805486，aiden+原vivian混声被拒绝；窗口/跨录音门保持0.65。
这只说明固定输入适于本次业务，原ryan失败与正常播放听感待验均保留。

HTTP05（1启动/11POST/78.854秒）的完整授权ASR、否定授权拒绝、
真实注册、跨客户/异声/配额反例以及新文本Base Speech和独立ASR通过，
但旧Chat入口无条件拒绝voice.id，404失败原样保留。终态动态错误标签
也在真实授权、异声、配额错误中确认稳定，没有继续借用释放后的字符串。

修复只影响Chat入口：内置音色原校验保持，自定义音色在主模型生成前
按当前客户和截止时间解析实时授权，生成后每个合成choice再次检查。
没有长期缓存授权，也没有降低声纹门槛。5项直接CPU通过（0.070秒），
host/engine构建23.008/25.507秒，零警告；940来源锚点/17遗漏负控。

HTTP06复用原持久对象精确副本（1启动/7POST/69.279秒），不重做注册
或合成夹具。Chat独立ASR完整识别“Please close the window.”，
元数据及存储Chat音频ID相符，跨客户Chat 404，撤销后Speech和Chat均
404，核心问答前后42，注册状态在进程重启后可读。未撤销状态另存
快照供后续兼容回退，原始状态和失败wire不覆盖。

两HTTP轮与aiden诊断各自持续持有严格GPU租约，NVML分别75、66、65次
均正常，末次无GPU进程，自有进程/端口清理与锁释放确认。轮询边界
保持，不能排除小于采样间隔的外界干扰。GPU测试不主张性能收益。

当前候选943964c4208b1b802ca04562155e203e797d891196978881031e36e588e71ab9，
默认rev316保持。SDK/TLS、主/轻profile、受监护恢复、Base-only已有
音色消费资格与完整有状态回退继续；参考音频ICL、提示词音色、Live、
听感/真人身份质量尚未全部闭合，不将本短验当作完整语音API资格。
''')
p=R/'docs/serve-master-goals-v2.json';data=read(p);row=data['native_tts_progress']['custom_voice']['service'];row.update(engine_sha256=summary['engine_sha256'],latest_evidence='evidence/serve-voice-chat-fix-20261119/README.md',runtime_http_qualified=False,registered_sample_http_qualified=True,registered_sample_scope_restart_revoke=True,chat_entry_fix=True,original_failures_preserved=True)
row['remaining']=['SDK/TLS and primary/light profiles','managed package and preserved-state compatible rollback','Base-only existing registered voice qualification','reference audio ICL, prompt voices and Live','listening and speaker similarity']
row['speaker_diagnosis']['synthetic_recording_consistency_pending']=True
row['second_voice_diagnosis']=dict(voice='aiden',single_shot=True,same_voice_cosine=.80548604298,mixed_voice_rejected=True,threshold=.65,original_ryan_failure_retained=True)
save(p,data)
text='''[已注册音色Speech/Chat持久闭环通过](evidence/serve-voice-chat-fix-20261119/README.md)：
修复Chat旧入口无条件拒绝ID，5 CPU通过；续验1启动/7POST/69.279秒，
独立ASR、跨客户/撤销、历史及核心42通过，原11POST失败保留。复用
成功注册与Speech证据，940来源锚点/17负控。默认rev316不变，继续
SDK/TLS、profile、受监护恢复和保存状态回退；听感与完整音色质量待验。
'''
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 已注册音色Chat缺口修复，真实持久闭环通过\n\n'+text+'\n为什么：真实入口与撤销必须闭环，不能用底层解析通过替代；\n下一步：SDK/TLS与主轻恢复资格，保留听感待验、原失败和默认身份。\n\n')]:
 p=R/n;s=p.read_text();assert m in s;write(p,s.replace(m,m+c,1))
print(json.dumps(dict(summary=summary,files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size)))

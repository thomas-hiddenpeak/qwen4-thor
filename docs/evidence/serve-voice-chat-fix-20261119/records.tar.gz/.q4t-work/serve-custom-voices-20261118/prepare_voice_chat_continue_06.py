from pathlib import Path
import copy,hashlib,json,shutil
from tools.native_tts.acceptance import defaults
from tools.native_tts.voice_service_acceptance import LIMITS
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-http-06';C=V/'voice-service-candidate-05'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
prior=V/'voice-http-05';observed=read(prior/'run/result.json');lease=read(prior/'lease/exit.json')
assert observed['status']=='FAILED' and observed['counts']['posts']==11 and lease['status']=='COMMAND_FAILED'
assert read(prior/'run/base-speech-asr.quality.json')['response']['text']=='The blue train arrives at noon.'
cleanup=read(prior/'run/cleanup.json');assert not cleanup['remaining'] and cleanup['model_exit']==0 and cleanup['ports_released']
for pid in cleanup['owned']:assert not Path('/proc',pid).exists()
prod=read(C/'chat_protocol_sources.json');assert all(sha(R/n)==v for n,v in prod.items())
assert read(V/'chat-voice-fix-cpu-01/result.json')['status']=='PASS'
base=copy.deepcopy(read(prior/'plan.json')['http']);base.update(output=str(O/'run'),port=19188,operations_port=19189,production_sources=prod)
base['sources']={p:sha(R/p) for p in base['sources']}
base['binaries']['engine']=dict(path=str(C/'q4t'),sha256=sha(C/'q4t'));assert defaults()==base['defaults']
base['acceptance'].update(reused_registered_objects=True,no_registration_or_synthesis_fixture_repeated=True,prior_partial_http='voice-http-05',normal_listening='PENDING',complete_voice_api_qualification=False)
state=prior/'run/objects';files={str(p.relative_to(state)):sha(p) for p in state.rglob('*') if p.is_file()}
assert 0<len(files)<=512 and sum((state/p).stat().st_size for p in files)<=16<<20
source=[Path(__file__),V/'voice_chat_continue_06.py',prior/'run/result.json',prior/'lease/exit.json',prior/'run/cleanup.json',prior/'run/base-speech-asr.quality.json',V/'chat-voice-fix-plan-01.json',V/'chat-voice-fix-cpu-01/result.json']
plan=dict(format='q4t-chat-registered-voice-resume-v1',http=base,bounds=dict(LIMITS,posts=7,seconds=600),state=dict(path=str(state),files=files,consent=read(prior/'run/consent.wire')['id'],voice=read(prior/'run/voice.wire')['id']),sources={str(p.relative_to(R)):sha(p) for p in source},reuse='original registered state exact copy; registration and Speech evidence from http-05 unchanged')
assert shutil.disk_usage(R).free>256<<20
O.mkdir(exist_ok=False);(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(dict(plan=str(O/'plan.json'),bounds=plan['bounds'],state_files=len(files))))

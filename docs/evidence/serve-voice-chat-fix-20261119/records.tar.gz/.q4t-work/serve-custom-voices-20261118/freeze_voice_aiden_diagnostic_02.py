from pathlib import Path
import copy,hashlib,json,shutil,subprocess
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-aiden-diagnostic-01';O.mkdir(exist_ok=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
from tools.native_tts.voice_service_acceptance import requests,validate_plan
from tools.native_tts.acceptance import defaults
base=read(V/'voice-http-04/run/plan.json');base['output']=str(O/'run');base['port']=19186;base['operations_port']=19187
engine=V/'voice-service-candidate-04/q4t';base['binaries']['engine']=dict(path=str(engine),sha256=sha(engine))
base['production_sources']=read(engine.parent/'chat_protocol_sources.json')
for p,h in base['production_sources'].items():assert sha(R/p)==h
base['sources']={p:sha(R/p) for p in base['sources']}
base['source_commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base['defaults']=defaults()
base['requests']=requests();validate_plan(base)
script=V/'voice_aiden_diagnostic_01.py';build=V/'voice-aiden-diagnostic-build-01';binary=build/'q4t_voice_aiden_diagnostic'
assert read(build/'result.json')['status']=='PASS_BUILD_ONLY' and read(build/'result.json')['warnings']==0
old=read(V/'voice-human-diagnostic-01/plan.json')
inputs=[script,Path(__file__),V/'build_voice_aiden_diagnostic_01.py',build/'replay.cpp',build/'plan.json',build/'result.json',R/'src/server/voice_verification.cpp',R/'include/q4t/server/voice_verification.h']
different=V/'voice-http-04/run/fixture-different.wav';inputs.append(different)
plan=dict(schema='q4t-second-voice-diagnostic-v1',output=str(O/'run'),http=base,
 limits=dict(seconds=600,starts=1,posts=2,controls=2000,speaker_loads=1,vad_loads=1,max_embeddings=99,artifact_mib=32,disk_headroom_mib=256),
 requests={k:dict(requests()['clips'][k],voice='aiden') for k in ('consent','sample')},
 binaries=dict(decoder=old['binaries']['decoder'],speaker=dict(path=str(binary),sha256=sha(binary))),
 speaker_assets=old['speaker_assets'],vad=old['vad'],different=dict(path=str(different),sha256=sha(different)),
 sources={str(p.relative_to(R)):sha(p) for p in inputs},
 rationale='One fixed second builtin English-text voice; reuse original Ryan failure, no seed/text/budget search. Two complete utterances and one mixed negative. ASR and full consent API remain subsequent requirements.',
 reused_numeric_evidence=['docs/evidence/serve-voice-identity-diagnostic-20261119/README.md','docs/evidence/serve-voice-human-diagnostic-20261119/README.md'])
assert shutil.disk_usage(R).free>256<<20
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
text='''冻结第二内置音色对照：aiden原授权/样本文字各合成一次，保留原seed/\n200帧预算；1主模型、2 Speech POST、1 speaker/1CPU VAD、600秒，\n原生检查两录音及aiden+既有vivian混声，0.65门不变。复用已对齐\n声纹算术，不重新生成ryan失败、不搜索seed；ASR和完整注册另须通过。\n'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 第二内置音色有界对照冻结\n\n'+text+'\n为什么：判断原合成录音不匹配是否跨内置音色出现，保持全部失败；\n下一步：依据完整对照推进注册录音与真实profile，默认不替换。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;write(p,s.replace(marker,marker+content,1))
print(json.dumps(dict(plan=str(O/'plan.json'),limits=plan['limits'],binary_sha256=sha(engine))))

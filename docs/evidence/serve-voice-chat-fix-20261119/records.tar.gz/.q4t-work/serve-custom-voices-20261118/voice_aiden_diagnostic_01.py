from pathlib import Path
import copy,io,json,math,os,signal,struct,subprocess,sys,time,traceback,wave
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts import voice_service_acceptance as voice
from tools.native_tts.acceptance import defaults
from tools.serve_service.package import read,save,sha,require

LIMITS=dict(seconds=600,starts=1,posts=2,controls=2000,speaker_loads=1,vad_loads=1,
            max_embeddings=99,artifact_mib=32,disk_headroom_mib=256)

class Stage(voice.Stage):
 def __init__(self,phase):
  self.phase=phase
  require(phase['limits']==LIMITS,'fixed diagnostic budget differs')
  wanted={k:dict(voice.requests()['clips'][k],voice='aiden') for k in ('consent','sample')}
  require(phase['requests']==wanted,'fixed second-voice requests differ')
  super().__init__(phase['http'])
 def artifacts(self):
  super().artifacts()
  require(sum(p.stat().st_size for p in self.out.rglob("*") if p.is_file()) <= LIMITS["artifact_mib"] << 20,"phase artifact byte bound")
 def budget(self,kind):
  require(time.monotonic()-self.started<LIMITS['seconds']-40,'phase deadline')
  require(self.counts[kind]<LIMITS[kind],'diagnostic attempt budget '+kind)
  self.artifacts();self.counts[kind]+=1;save(self.out/'counts.json',self.counts)
 def business(self):
  for name,request in self.phase['requests'].items():
   status,raw=self.post('aiden-'+name,'/v1/audio/speech',request)
   require(status==200,'second voice synthesis failed: '+name)
   audio,usage=voice.speech.sse(raw)
   save(self.out/('aiden-'+name+'.audio.json'),dict(**voice.check_wave(audio),**usage))
   (self.out/('aiden-'+name+'.wav')).write_bytes(audio)
  require(self.counts['posts']==2,'missing fixed diagnostic request')


def main(phase):
 started=time.monotonic();out=Path(phase['output']);out.mkdir(exist_ok=False)
 result=dict(status='FAILED');stage=None
 def expired(*_):raise TimeoutError('fixed second-voice diagnostic deadline')
 previous=signal.signal(signal.SIGALRM,expired);signal.alarm(560)
 try:
  for row in phase['binaries'].values():require(sha(row['path'])==row['sha256'],'diagnostic binary drift')
  for path,digest in phase['sources'].items():require(sha(R/path)==digest,'source drift '+path)
  stage=Stage(phase);stage.start();stage.business();stage.cleanup()
  require(stage.model.returncode==0,'owned HTTP server did not stop gracefully')
  require(sha(Path(phase['different']['path']))==phase['different']['sha256'],'different recording drift')
  raw=[]
  for p in [out/'aiden-sample.wav',Path(phase['different']['path'])]:
   with wave.open(str(p),'rb') as wav:
    require(wav.getnchannels()==1 and wav.getsampwidth()==2 and wav.getframerate()==24000,'mixed fixture rate')
    raw.append(wav.readframes(wav.getnframes()))
  mixed=out/'mixed-aiden-vivian.wav'
  with wave.open(str(mixed),'wb') as wav:
   wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(24000)
   wav.writeframes(raw[0]+bytes(2*9600)+raw[1])
  clips=[out/'aiden-consent.wav',out/'aiden-sample.wav',mixed]
  save(out/'decode-plan.json',dict(schema='q4t-speech-http-decode-v1',cases=[dict(path=str(p),sha256=sha(p),format='wav') for p in clips]))
  def command(name,args):
   before=time.monotonic()
   with (out/(name+'.log')).open('xb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,pass_fds=(stage.lease,),timeout=min(120,max(1,550-(time.monotonic()-started))))
   save(out/(name+'.execution.json'),dict(command=args,returncode=r.returncode,seconds=time.monotonic()-before));require(r.returncode==0,'diagnostic child failed: '+name)
  command('decode',[phase['binaries']['decoder']['path'],'--speech-http-decode',str(out/'decode-plan.json'),str(out/'decoded')])
  cases=[]
  for i in range(3):
   p=out/f'decoded/case-{i}/pcm.f32';receipt=read(p.parent/'result.json')
   require(receipt['worker_starts']==receipt['worker_reaped']==1 and receipt['sample_rate']==16000 and receipt['decoded_sha256']==sha(p),'decode identity/cleanup')
   cases.append(dict(pcm=str(p),pcm_sha256=sha(p)))
  save(out/'native-plan.json',dict(cases=cases,vad=phase['vad']))
  command('speaker',[phase['binaries']['speaker']['path'],phase['speaker_assets'],str(out/'native-plan.json'),str(out/'native')])
  rows=read(out/'native/windows.json');require(3<len(rows)<=99,'native embedding bound');vectors=[]
  for row in rows:
   values=struct.unpack('<192f',(out/f"native/embedding-{row['row']}.f32").read_bytes());norm=math.sqrt(sum(x*x for x in values));vectors.append([x/norm for x in values])
  def cosine(a,b):return sum(x*y for x,y in zip(a,b,strict=True))
  means=[];observations=[]
  for clip,name in enumerate(('aiden-consent','aiden-sample','aiden-vivian-mixed')):
   ids=[i for i,r in enumerate(rows) if r['clip']==clip and not r['whole']]
   pairs=[cosine(vectors[i],vectors[j]) for pos,i in enumerate(ids) for j in ids[pos+1:]]
   mean=[sum(vectors[i][d]*(rows[i]['core_end']-rows[i]['core_begin']) for i in ids) for d in range(192)];norm=math.sqrt(sum(x*x for x in mean));means.append([x/norm for x in mean])
   observations.append(dict(name=name,windows=len(ids),minimum_window_pair=min(pairs) if pairs else None))
  gates=read(out/'native/gates.json')
  result.update(status='SECOND_VOICE_DIAGNOSTIC_OBSERVED_NOT_REGISTRATION_ACCEPTANCE',
   gates=gates,observations=observations,same_voice_cosine=cosine(means[0],means[1]),
   expected_gates=[True,True,False],matches_expected_gates=[r['accepted'] for r in gates]==[True,True,False],
   same_voice_gate_passed=cosine(means[0],means[1])>=.65,threshold_unchanged=.65,
   speaker_embeddings=len(rows),asr_content='PENDING',listening='PENDING')
 except BaseException:result['error']=traceback.format_exc();raise
 finally:
  signal.alarm(0);signal.signal(signal.SIGALRM,previous)
  try:
   if stage is not None:stage.cleanup();stage.artifacts()
   require(defaults()==phase['http']['defaults'],'default changed')
  except BaseException:result['cleanup_error']=traceback.format_exc();result['status']='FAILED';raise
  finally:
   result.update(seconds=time.monotonic()-started,counts=stage.counts if stage else {},defaults_unchanged=defaults()==phase['http']['defaults'])
   save(out/'result.json',result)
 print(json.dumps(result),flush=True)

if __name__=='__main__':
 with voice.lifecycle.child_subreaper():main(read(Path(sys.argv[1])))

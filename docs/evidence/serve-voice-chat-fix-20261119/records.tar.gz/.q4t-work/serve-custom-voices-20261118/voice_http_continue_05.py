from pathlib import Path
import json,os,sys,time
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts.voice_service_acceptance import (
    Stage as Original, requests, LIMITS as ORIGINAL_LIMITS, CONSENTS, VOICES,
    checked_error, checked_metadata, BASE, TARGETS, check_wave, chat, speech,
    normalize, base64, lifecycle, read, save, sha, require)
LIMITS = dict(ORIGINAL_LIMITS, posts=14)
class Stage(Original):
    def __init__(self, phase):
        self.phase = phase
        require(phase['bounds'] == LIMITS, 'frozen continuation bound')
        require(set(phase['clips']) == {'consent','sample','different','negated'},
                'missing actual recording')
        super().__init__(phase['http'])
        for path, digest in phase['sources'].items():
            require(sha(R/path) == digest, 'continuation source drift: '+path)
    def budget(self, kind):
        require(time.monotonic()-self.started < LIMITS['seconds']-40,
                'continuation deadline')
        require(self.counts[kind] < LIMITS[kind], 'continuation attempt bound: '+kind)
        self.artifacts(); self.counts[kind] += 1
        save(self.out/'counts.json', self.counts)
    def business(self):
        self.core('core-before')
        clips = {}
        for name, row in self.phase['clips'].items():
            path = Path(row['path'])
            require(sha(path) == row['sha256'], 'reused recording identity differs')
            raw = path.read_bytes()
            check_wave(raw)
            clips[name] = raw
        fields = self.plan['requests']['consent']
        status, raw = self.form('negated-consent', CONSENTS, fields, 'recording', clips['negated'])
        checked_error(status, raw, 400, 'voice_consent_mismatch')
        status, raw = self.form('consent', CONSENTS, fields, 'recording', clips['consent'])
        consent = checked_metadata(status, raw, 'voice_consent')['id']
        status, raw = self.http(CONSENTS+'/'+consent, self.plan['requests']['rename'], label='rename')
        require(checked_metadata(status, raw, 'voice_consent')['name'] == 'local-consent-renamed',
                'rename did not persist')
        status, raw = self.http(CONSENTS+'/'+consent, label='consent-other', client='other')
        checked_error(status, raw, 404)
        status, raw = self.http(CONSENTS+'?limit=1', label='consent-list')
        require(status == 200 and json.loads(raw)['data'][0]['id'] == consent,
                'registered consent missing from list')
        voice_fields = dict(self.plan['requests']['voice'], consent=consent)
        status, raw = self.form('voice-other', VOICES, voice_fields, 'audio_sample',
                                clips['sample'], client='other')
        checked_error(status, raw, 404)
        status, raw = self.form('voice-mismatch', VOICES, voice_fields, 'audio_sample', clips['different'])
        checked_error(status, raw, 400, 'voice_speaker_mismatch')
        status, raw = self.form('voice', VOICES, voice_fields, 'audio_sample', clips['sample'])
        voice = checked_metadata(status, raw, 'voice')['id']
        status, raw = self.form('quota', CONSENTS, fields, 'recording', clips['consent'], client='tiny')
        checked_error(status, raw, 429, 'client_tpm_exhausted')
        request = dict(model=BASE, input=TARGETS[0], voice=dict(id=voice),
                       response_format='wav', stream_format='sse')
        status, raw = self.post('speech-other', '/v1/audio/speech', request, client='other')
        checked_error(status, raw, 404)
        status, raw = self.post('base-speech', '/v1/audio/speech', request)
        require(status == 200, 'registered Base Speech HTTP failed')
        audio, usage = speech.sse(raw)
        save(self.out/'base-speech.audio.json', dict(**check_wave(audio), **usage))
        (self.out/'base-speech.wav').write_bytes(audio)
        self.transcribe('base-speech-asr', audio, TARGETS[0])
        body = chat.request('Repeat exactly without adding any words: '+TARGETS[1], 'wav')
        body['audio']['voice'] = dict(id=voice)
        body['store'] = True
        status, raw = self.post('base-chat', '/v1/chat/completions', body)
        require(status == 200, 'registered Base Chat HTTP failed')
        result = json.loads(raw)
        require(len(result['choices']) == 1 and result['choices'][0]['finish_reason'] == 'stop',
                'partial Chat synthesis')
        sound = result['choices'][0]['message']['audio']
        chat.check_usage(result['usage'], 1)
        require(normalize(sound['transcript']) == normalize(TARGETS[1]), 'Chat text differs')
        audio = base64.b64decode(sound['data'], validate=True)
        save(self.out/'base-chat.audio.json', check_wave(audio))
        (self.out/'base-chat.wav').write_bytes(audio)
        self.transcribe('base-chat-asr', audio, TARGETS[1])
        self.snapshot(consent, voice, result['id'])
        status, raw = self.http(CONSENTS+'/'+consent, method='DELETE', label='revoke')
        require(status == 200 and json.loads(raw).get('deleted') is True, 'consent not revoked')
        status, raw = self.post('revoked-speech', '/v1/audio/speech', request)
        checked_error(status, raw, 404)
        status, raw = self.http(CONSENTS+'/'+consent, label='revoked-consent')
        checked_error(status, raw, 404)
        status, raw = self.http(VOICES+'/'+voice, method='DELETE', label='delete-voice')
        require(status == 200 and json.loads(raw).get('deleted') is True, 'voice not deleted')
        self.core('core-after')
        require(self.counts['posts'] == LIMITS['posts'], 'business checklist incomplete')

if __name__ == '__main__':
    plan = read(Path(sys.argv[1]))
    Path(plan['http']['output']).mkdir(exist_ok=False)
    with lifecycle.child_subreaper():Stage(plan).run()

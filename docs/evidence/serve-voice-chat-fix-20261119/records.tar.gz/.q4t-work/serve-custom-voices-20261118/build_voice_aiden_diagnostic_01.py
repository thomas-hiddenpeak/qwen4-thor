from pathlib import Path
import hashlib,json,shutil,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';A=V/'voice-human-diagnostic-build-01';B=V/'voice-aiden-diagnostic-build-01';B.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
plan=json.loads((A/'plan.json').read_text());source=(A/'replay.cpp').read_text()
source=source.replace('cases->array.size() == 6','cases->array.size() == 3').replace('six recorded clips required','three recorded clips required').replace('clip < 6','clip < 3')
(B/'replay.cpp').write_text(source)
for row in plan['provenance']:assert sha(Path(row['object']))==row['sha256'] and sha(R/row['source'])==row['source_sha256']
for p,h in plan['sources'].items():assert sha(R/p)==h
commands=[[arg.replace(str(A),str(B)).replace('q4t_voice_human_diagnostic','q4t_voice_aiden_diagnostic') for arg in cmd] for cmd in plan['commands']]
plan.update(commands=commands,derived_source_sha256=sha(B/'replay.cpp'),input_source_sha256=sha(A/'replay.cpp'))
(B/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');assert shutil.disk_usage(R).free>256<<20
start=time.monotonic()
for i,cmd in enumerate(commands):
 with (B/f'{i}.log').open('xb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 if r.returncode:break
result=dict(status='PASS_BUILD_ONLY' if r.returncode==0 else 'FAILED_BUILD',seconds=time.monotonic()-start,returncode=r.returncode,warnings=sum(p.read_text().count('warning:') for p in B.glob('*.log')))
if r.returncode==0:result['binary_sha256']=sha(B/'q4t_voice_aiden_diagnostic')
(B/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)

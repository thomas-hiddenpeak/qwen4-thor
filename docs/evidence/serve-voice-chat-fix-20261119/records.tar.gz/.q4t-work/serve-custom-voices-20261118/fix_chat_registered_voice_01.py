from pathlib import Path
import hashlib,json
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
p=R/'src/server/chat_generation.cpp';s=p.read_text();before=sha(p)
old='''  if (audio_output.enabled &&
      (audio_output.speech.voice_id ||
       audio::TtsBuiltinVoiceId(audio_output.speech.voice) < 0)) {
    SendError(fd, audio_output.speech.voice_id ? 404 : 400,
              "Requested voice is not available for native Chat speech", {},
              audio_output.speech.voice_id ? "voice_not_found"
                                           : "invalid_speech_voice",
              audio_output.speech.voice_id ? "audio.voice.id" : "audio.voice");
    return;
  }
'''
new='''  if (audio_output.enabled && !audio_output.speech.voice_id &&
      audio::TtsBuiltinVoiceId(audio_output.speech.voice) < 0) {
    SendError(fd, 400,
              "Requested voice is not available for native Chat speech", {},
              "invalid_speech_voice", "audio.voice");
    return;
  }
'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('#include "q4t/server/text_stop.h"','#include "q4t/server/text_stop.h"\n#include "q4t/server/voice_registry.h"')
needle='''  if (chat_storage.store) {
    RequestDiagnostics::Scope waiting(diagnostic, Wait::kStorage);
'''
extra='''  if (audio_output.enabled && audio_output.speech.voice_id) {
    RequestDiagnostics::Scope waiting(diagnostic, Wait::kStorage);
    VoiceSynthesisBinding voice;
    const auto resolved = VoiceRegistry(*objects_).Resolve(
        audio_output.speech.voice,
        {chat_state_access.scope, deadline, cancelled}, &voice);
    if (!resolved.ok()) {
      diagnostic.Outcome("error", resolved.ClientCode());
      SendError(fd, resolved.http_status, resolved.ClientMessage(), {},
                resolved.ClientCode(), "audio.voice.id");
      return;
    }
    // Admission does not authorize a later synthesis. PlanNativeSpeech checks
    // the live consent again after text generation, for every output choice.
  }
'''
assert s.count(needle)==1;s=s.replace(needle,extra+needle);write(p,s)
required=['chat_audio_output_options_keep_all_formats_and_actual_voice_identity','chat_audio_output_invalid_contract_is_atomic_and_has_original_paths','voice_registry_every_lookup_mutation_and_list_is_owner_scoped','voice_registry_revocation_blocks_new_resolution_keeps_owned_snapshot','chat_audio_output_history_survives_restart_and_is_client_private']
plan=dict(format='q4t-chat-registered-voice-fix-v1',changed={'src/server/chat_generation.cpp':dict(before=before,after=sha(p))},required=required,cpu_seconds=60,gpu_actions=0,http_followup=dict(starts=1,posts=7,seconds=600,preserved_state=True,no_recording_regeneration=True),defaults=json.loads((V/'voice-http-05/plan.json').read_text())['http']['defaults'],original_failure=str(V/'voice-http-05/run/result.json'))
(V/'chat-voice-fix-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
text='''Voice HTTP第5轮完成授权/注册和Base Speech独立ASR，但Chat旧入口\n无条件拒绝voice.id，11POST/78.854秒后失败，原记录和状态保留。\n已修复为同客户实时授权校验，合成前再次检查撤销；内置音色保护保持。\n冻结5项直接CPU/60秒，再复用已注册状态做1启动/7POST/600秒续验，\n覆盖Chat正向/跨客户/撤销及独立ASR、历史和核心；不重新合成录音。\n'''
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 修复Chat入口遗漏的已注册音色接入\n\n'+text+'\n为什么：真实业务暴露出旧入口仍拒绝合法ID，不能只让底层支持；\n下一步：针对CPU与保留状态HTTP续验，原失败不覆盖，默认不替换。\n\n')]:
 p=R/n;s=p.read_text();assert m in s;write(p,s.replace(m,m+c,1))
print(json.dumps(plan))

from pathlib import Path
import base64,json,os,shutil,signal,sys,time,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts.voice_service_acceptance import (
    Stage as Original, LIMITS as ORIGINAL_LIMITS, CONSENTS, VOICES,
    checked_error, checked_metadata, BASE, TARGETS, check_wave, chat,
    normalize, lifecycle, read, save, sha, require, defaults)
LIMITS=dict(ORIGINAL_LIMITS,posts=7,seconds=600)
class Stage(Original):
    def __init__(self,phase):
        self.phase=phase
        require(phase['bounds']==LIMITS,'frozen continuation bounds')
        super().__init__(phase['http'])
        for path,digest in phase['sources'].items():
            require(sha(R/path)==digest,'source drift: '+path)
        source=Path(phase['state']['path'])
        require({str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}==phase['state']['files'],'original state changed')
        shutil.copytree(source,self.out/'objects')
        require({str(p.relative_to(self.out/'objects')):sha(p) for p in (self.out/'objects').rglob('*') if p.is_file()}==phase['state']['files'],'state copy differs')
        save(self.out/'input-state.json',phase['state'])
    def budget(self,kind):
        require(time.monotonic()-self.started<LIMITS['seconds']-40,'stage deadline')
        require(self.counts[kind]<LIMITS[kind],'attempt budget: '+kind)
        self.artifacts();self.counts[kind]+=1
        save(self.out/'counts.json',self.counts)
    def business(self):
        consent,voice=self.phase['state']['consent'],self.phase['state']['voice']
        self.core('core-before')
        status,raw=self.http(CONSENTS+'/'+consent,label='persisted-consent')
        require(checked_metadata(status,raw,'voice_consent')['id']==consent,'persisted consent differs')
        body=chat.request('Repeat exactly without adding any words: '+TARGETS[1],'wav')
        body['audio']['voice']=dict(id=voice);body['store']=True
        status,raw=self.post('chat-other','/v1/chat/completions',body,client='other')
        checked_error(status,raw,404,'object_not_found')
        status,raw=self.post('base-chat','/v1/chat/completions',body)
        require(status==200,'registered Base Chat HTTP failed')
        result=json.loads(raw)
        require(len(result['choices'])==1 and result['choices'][0]['finish_reason']=='stop','partial Chat synthesis')
        sound=result['choices'][0]['message']['audio'];chat.check_usage(result['usage'],1)
        require(normalize(sound['transcript'])==normalize(TARGETS[1]),'Chat text differs')
        audio=base64.b64decode(sound['data'],validate=True)
        save(self.out/'base-chat.audio.json',check_wave(audio));(self.out/'base-chat.wav').write_bytes(audio)
        self.transcribe('base-chat-asr',audio,TARGETS[1])
        status,raw=self.http('/v1/chat/completions/'+result['id'],label='stored-chat')
        require(status==200 and json.loads(raw)['id']==result['id'] and
                json.loads(raw)['choices'][0]['message']['audio']['id']==sound['id'],
                'stored Chat audio reference differs')
        self.snapshot(consent,voice,result['id'])
        status,raw=self.http(CONSENTS+'/'+consent,method='DELETE',label='revoke')
        require(status==200 and json.loads(raw).get('deleted') is True,'consent not revoked')
        request=dict(model=BASE,input=TARGETS[0],voice=dict(id=voice),response_format='wav',stream_format='sse')
        status,raw=self.post('revoked-speech','/v1/audio/speech',request)
        checked_error(status,raw,404)
        status,raw=self.post('revoked-chat','/v1/chat/completions',body)
        checked_error(status,raw,404,'object_not_found')
        status,raw=self.http(CONSENTS+'/'+consent,label='revoked-consent');checked_error(status,raw,404)
        status,raw=self.http(VOICES+'/'+voice,method='DELETE',label='delete-voice')
        require(status==200 and json.loads(raw).get('deleted') is True,'voice not deleted')
        self.core('core-after')
        require(self.counts['posts']==LIMITS['posts'],'continuation checklist incomplete')
    def run(self):
        result=dict(status='FAILED');previous=signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('continuation deadline')))
        signal.alarm(LIMITS['seconds']-40)
        try:
            self.start();self.business()
            result['status']='PASS_CHAT_REGISTERED_VOICE_PERSISTENCE_SCOPE_REVOKE'
        except BaseException:
            result['error']=traceback.format_exc();raise
        finally:
            signal.alarm(0);signal.signal(signal.SIGALRM,previous)
            try:
                self.cleanup();require(defaults()==self.plan['defaults'],'default drift');self.artifacts()
            except BaseException:
                result['status']='FAILED';result['cleanup_error']=traceback.format_exc();raise
            finally:
                result.update(counts=self.counts,seconds=time.monotonic()-self.started,
                    defaults_unchanged=defaults()==self.plan['defaults'],acceptance=self.plan['acceptance'])
                save(self.out/'result.json',result)
if __name__=='__main__':
    phase=read(Path(sys.argv[1]));Path(phase['http']['output']).mkdir(exist_ok=False)
    with lifecycle.child_subreaper():Stage(phase).run()

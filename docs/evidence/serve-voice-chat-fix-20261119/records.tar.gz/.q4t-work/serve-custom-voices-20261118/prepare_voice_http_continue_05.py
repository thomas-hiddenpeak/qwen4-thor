from pathlib import Path
import copy,hashlib,inspect,json,shutil,subprocess
from tools.native_tts import voice_service_acceptance as voice
from tools.native_tts.acceptance import defaults
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-http-05';O.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
phase=read(V/'voice-aiden-diagnostic-01/plan.json');observed=read(V/'voice-aiden-diagnostic-01/run/result.json');lease=read(V/'voice-aiden-diagnostic-01/lease/exit.json')
assert observed['matches_expected_gates'] and observed['same_voice_gate_passed'] and observed['counts']['posts']==2 and lease['status']=='COMPLETED'
base=copy.deepcopy(phase['http']);base['output']=str(O/'run');base['port']=19188;base['operations_port']=19189
base['sources']={p:sha(R/p) for p in base['sources']};base['defaults']=defaults()
clips={name:(V/'voice-aiden-diagnostic-01/run'/('aiden-'+name+'.wav') if name in ('consent','sample') else V/'voice-http-04/run'/('fixture-'+name+'.wav')) for name in ('consent','sample','different','negated')}
# Only the generation loop is replaced. All original consent, owner, quota,
# ASR, Base Speech/Chat, snapshot, revocation and core checks remain literal.
method=inspect.getsource(voice.Stage.business)
a=method.index('        clips = {}\n');b=method.index("        fields = self.plan['requests']['consent']",a)
replacement='''        clips = {}
        for name, row in self.phase['clips'].items():
            path = Path(row['path'])
            require(sha(path) == row['sha256'], 'reused recording identity differs')
            raw = path.read_bytes()
            check_wave(raw)
            clips[name] = raw
'''
method=method[:a]+replacement+method[b:]
script=V/'voice_http_continue_05.py'
prefix='''from pathlib import Path
import json,os,sys,time
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.native_tts.voice_service_acceptance import (
    Stage as Original, requests, LIMITS as ORIGINAL_LIMITS, CONSENTS, VOICES,
    checked_error, checked_metadata, BASE, TARGETS, check_wave, chat, speech,
    normalize, base64, lifecycle, read, save, sha, require)
LIMITS = dict(ORIGINAL_LIMITS, posts=14)
class Stage(Original):
    def __init__(self, phase):
        self.phase = phase
        require(phase['bounds'] == LIMITS, 'frozen continuation bound')
        require(set(phase['clips']) == {'consent','sample','different','negated'},
                'missing actual recording')
        super().__init__(phase['http'])
        for path, digest in phase['sources'].items():
            require(sha(R/path) == digest, 'continuation source drift: '+path)
    def budget(self, kind):
        require(time.monotonic()-self.started < LIMITS['seconds']-40,
                'continuation deadline')
        require(self.counts[kind] < LIMITS[kind], 'continuation attempt bound: '+kind)
        self.artifacts(); self.counts[kind] += 1
        save(self.out/'counts.json', self.counts)
'''
script.write_text(prefix+method+'''
if __name__ == '__main__':
    plan = read(Path(sys.argv[1]))
    Path(plan['http']['output']).mkdir(exist_ok=False)
    with lifecycle.child_subreaper():Stage(plan).run()
''')
source=[script,Path(__file__),Path(voice.__file__),V/'voice-aiden-diagnostic-01/plan.json',V/'voice-aiden-diagnostic-01/run/result.json',V/'voice-aiden-diagnostic-01/lease/exit.json',V/'voice-aiden-diagnostic-01/run/native/gates.json',V/'voice-http-04/run/plan.json',*clips.values()]
base['acceptance'].update(fixture_generation_executed=False,
    fixture_positive_voice='aiden',original_ryan_failure_preserved=True,
    independent_english_consent_asr_required=True,diagnostic_log_lifetime_http_required=True)
plan=dict(schema='q4t-voice-http-continuation-v1',http=base,bounds=dict(voice.LIMITS,posts=14),
 clips={name:dict(path=str(p),sha256=sha(p)) for name,p in clips.items()},
 sources={str(p.relative_to(R)):sha(p) for p in source},
 derivation=dict(original=Path(voice.__file__).relative_to(R).as_posix(),original_sha256=sha(Path(voice.__file__)),replacement='only four synthesis requests replaced by exact retained WAV reads; all original business checks preserved',original_posts=18,continued_posts=14),
 expectations=dict(new_model_starts=1,positive_source='aiden_once_default_sampling',core_before_after=True,registered_state_snapshot=True,all_original_negatives=True,original_failure_retained=True,not_general_voice_quality_acceptance=True))
assert shutil.disk_usage(R).free>256<<20
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
text='''aiden固定一次对照两段自然EOS，生产单声纹均通过，跨录音0.805486，\n混声拒绝；67.786秒/2 Speech，原ryan失败保留。冻结复用原WAV完整\nVoice HTTP续验：1主模型/14业务POST/1200秒；原授权ASR、跨客户/异声/\n配额、Base新文本Speech/Chat独立ASR、持久快照、撤销和核心42全部保持。\n同时检查C04动态错误日志；不重新生成录音，不更改0.65门。\n'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 固定aiden对照通过，冻结完整注册续验\n\n'+text+'\n为什么：独立输入满足声纹后继续完整业务，不能把诊断当API通过；\n下一步：真实授权/新文本/撤销与日志验收，保留快照供兼容回退。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;write(p,s.replace(marker,marker+content,1))
print(json.dumps(dict(plan=str(O/'plan.json'),bounds=plan['bounds'],production_unchanged=True)))

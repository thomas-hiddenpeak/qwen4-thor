import hashlib,io,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];T=Path(__file__).parent
O=R/'docs/evidence/serve-realtime-tracing-idle-recovery-20261121';O.mkdir()
files=[]
for name in ['idle-recovery-cpu-01','idle-recovery-cpu-02','idle-recovery-cpu-03','sdk-cpu-05','sdk-cpu-06','native-runtime-05','native-runtime-06']:
 base=T/name
 files += [p for p in base.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(base).parts and 'fixtures' not in p.relative_to(base).parts]
for name in ['result.json','primary-tracing.sdk.json','primary-tracing.events.jsonl','primary-tracing-observed.json','primary-tracing.stderr','cleanup.json','lease/exit.json','lease/nvml-queries.jsonl']:
 files.append(T/'sdk-business-05'/name)
files += [T/'idle-exporter-inventory.json',T/'retired-previous-06/result.json',T/'retired-previous-06/plan.json',T/'retired-previous-06/restore.py',T/'recovery-prior-binaries-01/plan.json',T/'recovery-prior-binaries-01/restore.py',Path(__file__).resolve()]
rows=[]
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for p in sorted(files):
  raw=p.read_bytes();name=str(p.relative_to(T));info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644
  archive.addfile(info,io.BytesIO(raw));rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(O/'index.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256((O/'records.tar.gz').read_bytes()).hexdigest(),files=rows),indent=2)+'\n')
b=json.loads((T/'native-runtime-06/result.json').read_text())
accept=dict(status='CPU_AND_NATIVE_BUILD_PASS_GPU_REVALIDATION_PENDING',native_build=b,native_cpu_distinct=24,original_cpu=dict(pass_count=21,fixture_failures=2),targeted_repairs=2,idle_exporter_cases=4,read_poll_cases=3,reused_driver_checker_cases=22,original_failure=dict(model_starts=1,actual_generations=3,settled_tokens=1746,model_quality='PASS',seconds=56.453239758033305,retained=True),default_revision=416,default_unchanged=True,master_active=True)
(O/'acceptance.json').write_text(json.dumps(accept,indent=2)+'\n')
(O/'README.md').write_text("""# 追踪空闲恢复修复（2026-11-21）

主档TLS SDK实际完成3次生成：普通问答、MCP审批读取和引用回答均正确，
1746 tokens结算。追踪查询遇到ObjectStore恢复退避503，整轮验收失败，
1模型/3生成/56.453秒及原失败、正常清理保留，未到达轻档。

补齐异步写入失败后同一版本不再提交的缺口：会话按失败版本每秒
有界重提最新快照，未知提交先GET核对，已持久版本不重复PUT。
旧版本和已删除生产者不能复活。首次辅助线程创建失败也可由空闲
会话触发原有有界Launch；未退出线程继续占唯一槽，不连累核心。

存储/会话24项不同CPU场景闭合。首轮21过/2夹具失败：恢复目录须
遵守0700合同，未知提交用例应检查重提后的持久版本不增加。仅两项
修正后重验通过，1.416秒；补充线程恢复4项通过，0.514秒。原失败
保留；3项JS只读轮询边界通过，沿用22项驱动/判据场景，另重验2项
驱动初始化边界。所有原生构建零警告，最终候选94df51e5，22.743秒。

[完整索引](index.json)及[原始记录](records.tar.gz)保留失败、源码和
修复过程。不是GPU验收通过；新候选补验最多2启动/6生成/900秒，
含先前两轮累计最多4启动/9实际生成。默认rev416仍STOPPED，主轻资格、
可回退交付和main尚待完成，Serve总目标继续active。
""")
print(json.dumps(dict(files=len(rows),archive_bytes=(O/'records.tar.gz').stat().st_size)))

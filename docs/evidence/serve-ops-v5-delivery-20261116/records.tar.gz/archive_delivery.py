import hashlib,json,re,shutil,tarfile
from pathlib import Path
root=Path.cwd();work=root/'.q4t-work/serve-ops-v5-20261116';out=root/'docs/evidence/serve-ops-v5-delivery-20261116';run=work/'delivery-01'
result=json.loads((run/'result.json').read_text());assert result['status']=='PASS_NATIVE_OPS_V5_DELIVERED' and result['publication']['revision']==188
current=result['publication']['current'];day=json.loads((work/'day-01/plan.json').read_text());assert day['package']['manifest_sha256']==current['manifest_sha256'] and not (work/'day-01/execution').exists()
files=[(p,'delivery-01/'+p.name) for p in run.iterdir() if p.is_file() and not p.is_symlink()]
for stem in ('delivery-prepare-01','delivery-prepare-02','delivery-run-01','publication-archive-01','publication-archive-02','prepare-day-01','check-day-01'):
 for ext in ('json','stdout','stderr'):files.append((work/(stem+'.'+ext),stem+'.'+ext))
for n in ('day-01/plan.json','day-01/handoff.json','publication-archive-prepared.json','publication-archive-applied.json','archive_generations.py','deliver_ops.py','run_delivery.py','archive_delivery.py'):files.append((work/n,n))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for n in ('gateway-policy.json','engine/client-policy.json'):collect(json.loads((root/'build/service'/n).read_text()))
for p,n in files:
 data=p.read_bytes();assert not any(s in data for s in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',data),n
out.mkdir()
with tarfile.open(out/'records.tar.gz','w:gz') as archive:
 for p,n in files:archive.add(p,arcname=n,recursive=False)
for n in ('result.json','recovery-anchor.json'):shutil.copy2(run/n,out/n)
summary=dict(status='ACCEPT_NATIVE_OPS_V5_DELIVERY_AND_DAY_HANDOFF',revision=188,manifest_sha256=current['manifest_sha256'],generation_sha256=current['generation_sha256'],state='STOPPED',commands=len(result['commands']),seconds=result['seconds'],new_gpu_starts=0,engine_sha256=current['engine_binary_sha256'],core_client_outer_profile_bytes_preserved=True,original_root_cycles_preserved=True,automatic_fallback_unchanged=True,prior_rev182_preserved=True,retired_generations_archived=1,deleted_files=0,day_plan=str(work/'day-01/plan.json'),day_service_id=day['service_id'],day_automatically_started=False,secret_scan_matches=0,main_integration_pending=True,all_master_tasks_active=True)
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text(f'''# 当前运营指标修复交付 rev188 与原生长稳交接

新包`{current['manifest_sha256']}`进入实际默认，generation
`{current['generation_sha256']}`。{len(result['commands'])}项STOPPED发布、实际回退至rev182原根、
再前进及入口检查完成，{result['seconds']:.3f}秒、0新增GPU。
核心/client/outer/profile字节保持，原根周期只递增revision；恢复预算
未返还。原生outer启用且累计0启动，最终STOPPED。

主模型程序0851dab3及发布元数据、所有原生辅助程序、容量与资质保持。
只更新root/engine两处同一Python指标解析源。当前人工整根回退保留
430e7985及完整状态备份；更早7230ac61仍保留，自动payload c789291b
保持。一个已退休发布副本经可恢复归档腾位，0删除；首次父目录权限
预检拒绝及受其影响的准备拒绝保留，修正本任务目录权限后继续。

当前精确包的day prepare/check通过，未启动模型；计划、原UUID、
status/stop命令及记录复核入口见[交接](../../SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)。
真实短验3组/60秒已通过，含两失败累计3启动/28Chat/209.112秒；
194项NVML均OK，原失败另保留。24小时由用户执行，不能称长期已验。

后续需实际合main；R07/R08/协议/媒体/后端及全部master继续。
''')
p=root/'docs/SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md';p.write_text(f'''# 当前默认原生长稳交接

rev188包`{current['manifest_sha256']}`已完成连续60秒/3组真实短验，
原生outer/Guardian和JSON/SSE/schema/实际文档工具/SHA续答、指标排空、
原始wire复核及清理通过。[完整证据](evidence/serve-native-soak-business-20261116/README.md)。
24小时未运行，由用户选择维护窗口显式开展。

## 当前已准备的入口

私有验证服务UUID `{day['service_id']}`，生产默认状态保持STOPPED。
执行前在仓库根目录核对冻结源/默认/包身份：

```bash
python3 -I -B tools/serve_soak/native_stage.py check \\
  --plan .q4t-work/serve-ops-v5-20261116/day-01/plan.json
```

准备好连续使用GPU后，由你执行：

```bash
python3 -I -B tools/serve_soak/native_stage.py run \\
  --plan .q4t-work/serve-ops-v5-20261116/day-01/plan.json
python3 -B tools/serve_soak/native_report.py \\
  --output .q4t-work/serve-ops-v5-20261116/day-01
```

run自己持有严格GPU租约，整个验证不需要systemd或nginx，不安装后台
恢复任务。固定24小时1440周期/7200业务生成加1自检，每分钟一组，
保持当前配额；第一小时60周期/300业务请求单独记录。最多1模型启动，
0探测，总期限87900秒；不重放请求或重复工具，不把short称作长稳。

入口前台运行。中断/监控或证据故障只停止本次自有服务，保留失败；
终端丢失时，day-01/handoff.json中的status/stop命令绑定原包和私有状态：

```bash
.q4t-work/serve-ops-v5-20261116/candidate-01/bundle/bin/q4t service status \\
  --state .q4t-work/serve-ops-v5-20261116/day-01/state
.q4t-work/serve-ops-v5-20261116/candidate-01/bundle/bin/q4t service stop \\
  --state .q4t-work/serve-ops-v5-20261116/day-01/state
```

每周期progress只表示已写进度，须结合实时status。完整通过还要求
原始wire、真实工具历史/来源、持续监控、同一模型身份、资源/配额与
STOPPED清理全部复核。进程RSS/RssAnon相互重叠，不能推导统一DRAM
硬上限；相关R08任务继续。

## 后续代码或发行变化

旧plan按原源和默认身份冻结。若check因后续开发改变身份而拒绝，
保留此计划/证据，通过通用[prepare流程](../tools/serve_soak/README.md)
为当时实际版本准备新目录；不要改旧plan散列、清空execution或冒称旧
证据适用于新包。本次既有short证据仅绑定上方精确发行身份。
''')
p=root/'docs/STATUS.md';s=p.read_text();s=s.replace('rev182；服务包 `430e7985f278ce84a25c99475a315e236fe0eb62201dd4b503a8cc2069805784`','rev188；服务包 `'+current['manifest_sha256']+'`',1).replace('`a262b60ea0efcab3c6ae09f1620e7092a1aa2a754951d974e7c998f5c8067020`','`'+current['generation_sha256']+'`',1).replace('现代保留根 `7230ac61be71a95bddd142bce982dd8b8d09eb485c57214aaa92666dc4f48964`，保留outer及原版本周期迁移','前驱rev182根 `430e7985f278ce84a25c99475a315e236fe0eb62201dd4b503a8cc2069805784`；原outer/周期完整，更早7230ac61也保留',1)
s=s.replace('[原生整根回退交付](evidence/serve-root-delivery-20261116/README.md)完成18项',f'''[rev188运营指标交付](evidence/serve-ops-v5-delivery-20261116/README.md)完成13项
STOPPED发布/实际回退/再前进和入口检查，{result['seconds']:.3f}秒，0新增GPU。
只更新Python对当前上传/tunnel计数的解析；核心/client/outer/profile及
所有本机程序和容量保持。原生60秒/3组/15业务加自检与完整清理通过；
[24小时交接已准备](SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)，实际day由用户执行。
后续实际合main继续；R07执行前按当前默认刷新冻结包，维护交接未答
不干预相机/监控。R08及全部协议/媒体/后端master任务继续。

前驱rev182[原生整根回退交付](evidence/serve-root-delivery-20261116/README.md)完成18项''',1)
m='## 最近完成的实现和验证\n\n';s=s.replace(m,m+'''[rev188交付与day交接](evidence/serve-ops-v5-delivery-20261116/README.md)完成，13项
发布/实际回退/再前进与健康检查通过、0新增GPU；默认STOPPED、原预算
保持。day只读prepare/check通过，未执行。继续实际合main和全部master。

''',1);p.write_text(s)
p=root/'docs/log/2026-11-16.md';s=p.read_text();head,rest=s.split('\n\n',1);p.write_text(head+f'''\n\n## rev188 运营指标修复发布与长稳交接

- 日期：2026-11-16。13项STOPPED发布、原根回退及再前进/入口检查
  通过，{result['seconds']:.3f}秒、0新增GPU。默认509c3bcb，原程序/容量保持。
- 为什么：实际观测缺口需进入发行，不能停在CPU或只绕过验证。
- core/client/outer/profile字节及原根周期保持；退休副本归档1份，
  0删除。初次私有父目录预检拒绝与准备拒绝原记录保留。
- 新默认day prepare/check完成，未启动；提供原身份status/stop及
  原始记录复核命令，24小时由用户执行。
- 下一步：实际合main，按当前默认续冷启动维护及其他全部master。
- 证据：[交付](../evidence/serve-ops-v5-delivery-20261116/README.md)、
  [长稳交接](../SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)。

'''+rest)
p=root/'docs/serve-master-goals-v2.json';v=json.loads(p.read_text())
for t in v['tasks']:
 if t['id']=='Q03':
  t['native_soak_20261116'].update(state='short_delivered_day_handoff_prepared_main_pending',revision=188,manifest_sha256=current['manifest_sha256'],delivery_evidence='evidence/serve-ops-v5-delivery-20261116/README.md',handoff='SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md',day_executed=False)
  t['remaining_required']=['Finish every remaining task before final closure','Integrate native soak delivery into main; user executes the prepared long-stability run']
 if t['id']=='R04':t['metric_v5_compatibility_20261116'].update(state='delivered_main_pending',revision=188,delivery_evidence='evidence/serve-ops-v5-delivery-20261116/README.md')
 if t['id']=='R07':t['current_execution_prerequisite']='Before controlled cold business, refresh exact preparation/check against rev188 or the then-current default; no camera/jtop stop or device-fence action without the pending maintenance handoff.'
 if t['id']=='Q02':t['native_soak_ops_20261116']=dict(state='delivered_main_pending',revision=188,manifest_sha256=current['manifest_sha256'],delivery_evidence='evidence/serve-ops-v5-delivery-20261116/README.md')
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=root/'docs/README.md';s=p.read_text();s+='\n- [当前默认原生长稳交接](SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md)：rev188精确入口、用户24小时运行及停止/复核。\n';p.write_text(s)
print(json.dumps({'revision':188,'files':len(files),'day_executed':False,'secrets':0}))

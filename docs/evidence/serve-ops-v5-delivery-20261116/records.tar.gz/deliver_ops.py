"""Reversible STOPPED publication of the accepted auxiliary parser fix."""
import copy,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle,publication,profile_manager,version_contract
from tools.serve_service import package as p
WORK=Path(__file__).resolve().parent;OUT=WORK/'delivery-01';DEFAULT=ROOT/'build';STATE=DEFAULT/'service-native-state'
OLD='430e7985f278ce84a25c99475a315e236fe0eb62201dd4b503a8cc2069805784'

def preserved():
 return {str(f.relative_to(STATE)):p.sha(f) for f in STATE.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(STATE).parts[0].startswith(('client-','outer-','profile-selection')))}

def version():return p.read(STATE/'version-selection/policy.json')['state']['policy']

def exact(before,after):
 p.require({k:v for k,v in before.items() if k!='revision'}=={k:v for k,v in after.items() if k!='revision'} and after['revision']>before['revision'],'original version state changed')

def prepare():
 p.require(not OUT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'clean committed delivery required')
 current=publication.status(STATE);target=p.read(WORK/'candidate-01/receipt.json');accept=p.read(ROOT/'docs/evidence/serve-native-soak-business-20261116/acceptance.json')
 p.require(current['ready'] and current['revision']==182 and current['current']['manifest_sha256']==OLD,'default predecessor differs')
 p.require(accept['status']=='ACCEPT_NATIVE_SHORT_SOAK_AND_V5_METRICS' and accept['manifest_sha256']==target['manifest_sha256'],'actual new package not accepted')
 p.require(len(list((DEFAULT/'.q4t-publication/generations').iterdir()))<=31 and len(list((STATE/'version-registrations').glob('*.json')))<=15,'retired pool capacity required')
 old=bundle.verify(current['current']['package'],OLD);new=bundle.verify(target['package'],target['manifest_sha256'])
 for name,digest in new['files'].items():
  if name.startswith('source/'):p.require(p.sha(ROOT/name[7:])==digest,'source changed')
 p.require(profile_manager.compatible(old,new,current['current']['package'],target['package']) is None,'profile migration differs')
 prior=version();p.require(prior['registry']['root_manifest_sha256']==OLD and prior['switch'] is None and prior['terminal_fault'] is None,'original cycle is not quiescent')
 oldreg=p.read(STATE/'version-registrations'/(prior['registry']['cycle_id']+'.json'))['registration']
 registration=version_contract.prepare(target,target,oldreg['payloads']['fallback']['descriptor'],str(uuid.uuid4()),fallback_acceptance=oldreg['fallback_acceptance'])
 OUT.mkdir(mode=0o700);shutil.copytree(STATE,OUT/'previous-state',symlinks=True)
 generation=(DEFAULT/'q4t').resolve().parent;(OUT/'previous').mkdir(mode=0o700)
 for name in ('q4t','q4t.release.json','service.release.json','service.acceptance.json'):shutil.copyfile(generation/name,OUT/'previous'/name)
 original=p.read(OUT/'previous/service.release.json')
 review=dict(previous=current,target=target,previous_version=prior,preserved=preserved(),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),actual_business=accept,changed_sources=['tools/serve_ops/contracts.py'],reused_control_recovery='exact source/native identity from accepted rev182; auxiliary parser only',new_gpu_starts=0)
 p.save(OUT/'review.json',review);p.save(OUT/'registration.json',registration)
 decision=dict(status='PASS_NATIVE_OPS_V5_DELIVERY',acceptance='ACCEPT_NATIVE_OPS_V5_DELIVERY',manifest_sha256=target['manifest_sha256'],engine_binary_sha256=accept['engine_binary_sha256'],actual_business=accept['actual_business'],original_decision=dict(path=str(ROOT/'docs/evidence/serve-native-soak-business-20261116/acceptance.json'),sha256=p.sha(ROOT/'docs/evidence/serve-native-soak-business-20261116/acceptance.json')),control_review=str(OUT/'review.json'),new_gpu_starts=0,remaining_master_tasks_open=True,performance_acceptance=False,long_stability_accepted=False)
 p.save(OUT/'decision.json',decision)
 anchor=dict(package=current['current']['package'],manifest_sha256=OLD,generation_sha256=current['current']['generation_sha256'],service_release=str(OUT/'previous/service.release.json'),service_release_sha256=p.sha(OUT/'previous/service.release.json'),manual_root_rollback_requires_stopped=True,retains_native_outer_and_cycle_migration=True)
 p.save(OUT/'recovery-anchor.json',anchor)
 release=copy.deepcopy(original);package=Path(target['package'])
 release.update(acceptance=decision['acceptance'],acceptance_record=str(OUT/'decision.json'),acceptance_sha256=p.sha(OUT/'decision.json'),package=target['package'],manifest_sha256=target['manifest_sha256'],recovery_accepted=True,engine_binary_sha256=p.sha(package/'engine/q4t'),engine_release_sha256=p.sha(package/'engine/q4t.release.json'),control_review=str(OUT/'review.json'),control_source_commit=review['source_commit'],previous_acceptance_record=original['acceptance_record'],version_recovery_registration=str(OUT/'registration.json'),version_recovery_registration_sha256=p.sha(OUT/'registration.json'),version_recovery_cycle_id=registration['registry']['cycle_id'],unaffected_control_recovery_reused_by_exact_source_identity=True,gpu_starts_for_install=0,rollback_receipt=str(OUT/'recovery-anchor.json'),rollback_sha256=p.sha(OUT/'recovery-anchor.json'),native_soak_short_evidence=decision['original_decision']['path'],scope='Exact additive v5 upload/tunnel metric compatibility and native short-soak handoff. One accepted 60-second/three-cycle run, 15 business generations plus self-check; original two failed validation drivers retained. Native/model/profile/control recovery identities unchanged and reused. No long-stability or physical-DRAM hard-cap claim; all remaining Serve master tasks continue.')
 p.save(OUT/'service.release.json',release);p.save(OUT/'requests.json',{name:str(uuid.uuid4()) for name in ('publish','rollback','forward')})
 print(json.dumps(dict(status='PREPARED_OPS_V5_DELIVERY',target=target,new_gpu_starts=0)))

def run():
 review=p.read(OUT/'review.json');target=review['target'];ids=p.read(OUT/'requests.json');cli=Path(target['package'])/'bin/q4t';rows=[];started=time.monotonic()
 def call(label,args):
  argv=list(map(str,args));r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
  (OUT/(label+'.stdout')).write_text(r.stdout);(OUT/(label+'.stderr')).write_text(r.stderr);rows.append(dict(label=label,argv=argv,returncode=r.returncode))
  p.require(r.returncode==0,'delivery command failed: '+label);p.require(preserved()==review['preserved'],'core/client/outer/profile changed');return json.loads(r.stdout)
 def publish(label,prior,revision):
  return call(label,[cli,'service','publish','--state',STATE,'--default-root',DEFAULT,'--package',target['package'],'--manifest-sha256',target['manifest_sha256'],'--service-release',OUT/'service.release.json','--expected-manifest-sha256',prior,'--expected-revision',revision,'--request-id',ids[label]])
 try:
  p.require(call('previous-check',[cli,'service','check','--state',STATE,'--package',review['previous']['current']['package'],'--manifest-sha256',OLD])['desired']=='STOPPED','previous not stopped')
  p.require(call('candidate-check',[cli,'service','check','--package',target['package'],'--manifest-sha256',target['manifest_sha256']])['status']=='PASS','candidate check failed')
  result=publish('publish',OLD,182);p.require(result['durable'] and result['revision']==184,'initial publication')
  reg=call('register',[DEFAULT/'q4t','service','version-register','--state',STATE,'--registration',OUT/'registration.json','--expected-cycle',review['previous_version']['registry']['cycle_id']]);p.require(reg['registered'] and not reg['fallback_consumed'],'registration failed')
  candidate_cycle=version();p.save(OUT/'candidate-cycle.json',candidate_cycle)
  result=call('rollback',[cli,'service','publish-rollback','--state',STATE,'--default-root',DEFAULT,'--package',target['package'],'--manifest-sha256',target['manifest_sha256'],'--generation-sha256',review['previous']['current']['generation_sha256'],'--expected-manifest-sha256',target['manifest_sha256'],'--expected-revision',184,'--request-id',ids['rollback']]);p.require(result['durable'] and result['revision']==186,'rollback publication');exact(review['previous_version'],version())
  p.require(call('rollback-check',[DEFAULT/'q4t','service','check','--state',STATE])['desired']=='STOPPED','rollback entry failed')
  result=publish('forward',OLD,186);p.require(result['durable'] and result['revision']==188,'forward publication');exact(candidate_cycle,version())
  for action in ('check','status','observe'):
   value=call('default-'+action,[DEFAULT/'q4t','service',action,'--state',STATE]);p.require(value['status']=='PASS' if action=='check' else value['state']=='STOPPED','default health')
  profiles=call('profiles',[DEFAULT/'q4t','service','profiles-status','--state',STATE]);p.require(profiles['selected']=='primary','profile changed')
  outer=call('outer',[DEFAULT/'q4t','service','outer-status','--state',STATE]);p.require(outer['enabled'] and outer['charged_total']==0,'outer budget changed')
  final=call('publication',[DEFAULT/'q4t','service','publish-status','--state',STATE]);p.require(final['ready'] and final['revision']==188 and final['current']['manifest_sha256']==target['manifest_sha256'],'final publication differs')
  p.save(OUT/'result.json',dict(status='PASS_NATIVE_OPS_V5_DELIVERED',seconds=time.monotonic()-started,commands=rows,publication=final,profiles=profiles,outer=outer,original_cycle=review['previous_version'],candidate_cycle=candidate_cycle,final_cycle=version(),preserved=review['preserved'],state='STOPPED',new_gpu_starts=0,all_master_tasks_active=True));print(json.dumps(dict(status='PASS_NATIVE_OPS_V5_DELIVERED',revision=188,commands=len(rows))))
 except BaseException as error:
  p.save(OUT/'result.json',dict(status='FAILED',commands=rows,error=repr(error),seconds=time.monotonic()-started));raise
if __name__=='__main__':
 os.umask(0o077);{'prepare':prepare,'run':run}[sys.argv[1]]()

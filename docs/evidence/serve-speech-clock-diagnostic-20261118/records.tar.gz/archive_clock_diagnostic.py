from pathlib import Path
import json,hashlib,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-speech-clock-diagnostic-20261118';assert not O.exists()
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
r=read(W/'tempo-clock-diagnostic-01/run/result.json');guard=read(W/'tempo-clock-diagnostic-01/lease/exit.json');cpu=read(W/'tempo-clock-cpu-01/result.json');assert r['status']=='CLOCK_DIAGNOSTIC_COMPLETED_NOT_ACCEPTANCE' and r['defaults_unchanged'] and r['asr_loads']==1 and all(c['passed'] for c in r['comparisons']) and guard['status']=='COMPLETED' and guard['child_returncode']==0 and cpu['status']=='PASS'
queries=[json.loads(l) for l in (W/'tempo-clock-diagnostic-01/lease/nvml-queries.jsonl').read_text().splitlines()];assert all(x['status']=='OK' and x['returncode']==0 for x in queries)
files={}
for name in ['tempo-clock-build-01','tempo-clock-build-02','tempo-clock-cpu-01','tempo-clock-diagnostic-01','tempo-acoustic-review-01','rebuildable-cache-retirement-09']:
 for p in (W/name).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.suffix not in ['.o','.bf16'] and not p.name.startswith('q4t_asr_'):files[str(p.relative_to(W))]=p
for name in ['review_tempo_acoustics.py','build_clock_diagnostic.py','build_clock_diagnostic_02.py','run_clock_diagnostic.py','tempo-clock-plan-01.json','archive_clock_diagnostic.py','retire_tempo_diagnostic_cache.py']:files[name]=W/name
for p in files.values():assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in p.read_bytes()
O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz',compresslevel=9) as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz') as archive:
 for item in archive.getmembers():assert hashlib.sha256(archive.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
result=dict(status='DIAGNOSTIC_SUPPORTS_ASR_TIME_SCALE_CONTRIBUTION',cpu_cases=4,cpu_seconds=cpu['seconds'],asr_loads=1,cases=4,seconds=r['seconds'],comparisons=r['comparisons'],nvml_queries=len(queries),lease_completed=True,defaults_unchanged=True,production_acceptance=False,normal_speed_listening_acceptance=False,original_failures_preserved=True,negative_control_pending=True,owner_acceptance_decision_pending=True,archive_sha256=sha(O/'records.tar.gz'),full_logits_encoder_dumps_retained_locally=True,master_complete=False)
put(O/'result.json',json.dumps(result,ensure_ascii=False,indent=2)+'\n');put(O/'index.json',json.dumps(index,indent=2)+'\n')
put(O/'README.md','''# 高速语音内容诊断：ASR时间尺度影响已有实证

原两级WSOLA和相位锁定原型各自的中英文4倍音频，保持原PCM、
原声学前端与无原文提示，只将计算后的log-mel时间轴固定4倍线性
展开，再交给同一个原生ASR。四例均恢复完整原句和EOS：英文
“Hello, this is a native speech test.”，中文“你好，会议下午三点开始。”。
音频token由10恢复为42/41。这支持识别器时间尺度参与失败，不能
再只根据原速ASR错词断言波形必然丢词；也不证明正常播放听感。

4针对CPU/0.034秒，必要构建2.533秒零警告。1次ASR加载/四例/
3.144秒，0TTS/主LLM/HTTP。原PCM和原生特征逐值核对仍在变换前
执行，变换只在独立诊断程序，生产特征/程序未改。首轮编译成功、
链接因历史对象与新头文件ABI不一致失败；匹配原已验头文件后通过，
原失败保留。GPU租约完成，NVML查询全正常，默认rev316身份保持。

这不是4倍语音生产验收：原直接ASR失败与相位原型NO_GO保持。
已向用户提出是否采用速度归一化复核、补反例并保留听感待验项的
口径问题，答案未到，不将等待视为同意。其余voice与全部master继续。
只读频谱比较图、源码/构建身份、原始输出和租约见归档；巨量可重用
BF16中间值和诊断ELF保留本地，原始结果中的全部摘要保持。

[结果](result.json)、[逐文件摘要](index.json)、[原件](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();put(p,s.replace('## 正在推进\n\n','## 正在推进\n\n[ASR时间尺度诊断四例恢复原句](evidence/serve-speech-clock-diagnostic-20261118/README.md)：\n4 CPU/0.034秒、1 ASR/3.144秒，原音频特征仅作时间轴展开，未提供\n原文。支持高速ASR限制参与失败，不能替代正常播放听感；生产未改，\n原失败保持。归一化复核/反例的验收口径待用户决定，其余任务继续。\n\n',1))
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);put(p,h+'\n\n## ASR时间尺度单变量诊断完成（2026-11-18）\n\n两级WSOLA与相位原型的两句4倍音频，原生PCM/特征核对后只展开\nlog-mel时间，四例完整恢复原句/EOS，无原文提示。4 CPU/0.034秒，\n1 ASR/3.144秒，租约/NVML正常，默认rev316保持。证明识别器时间\n尺度参与，未证明主观可懂度，原直接失败不追改。下一步待用户\n决定归一化复核口径，同时推进voices等独立能力；全部master继续。\n[证据](../evidence/serve-speech-clock-diagnostic-20261118/README.md)。\n'+b)
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['native_tts_progress']['tempo'].update(clock_diagnostic_evidence='evidence/serve-speech-clock-diagnostic-20261118/README.md',clock_diagnostic_matches=4,production_acceptance=False,acceptance_rule_decision_pending=True);put(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size,nvml_queries=len(queries))))

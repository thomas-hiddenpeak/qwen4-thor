"""One ASR load, fixed four existing waveforms, diagnostic clock only."""
import os,sys,json,hashlib,fcntl,stat,time,subprocess
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(R/'tools/native_tts'))
from acceptance import CASES,defaults,digest
from tempo_diagnosis import diagnostic_check
PLAN=W/'tempo-clock-plan-01.json';O=W/'tempo-clock-diagnostic-01/run'
def main():
 lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);assert stat.S_ISREG(os.fstat(lease).st_mode);fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 p=json.loads(PLAN.read_bytes());assert p['limits']==dict(seconds=600,asr_seconds=180,asr_loads=1,cases=4,max_tokens=64,tts_loads=0,main_llm_loads=0,http_requests=0,artifact_mib=16,minimum_free_mib=256)
 assert not os.environ.get('PYTHONOPTIMIZE') and not any(k.startswith('Q4T_ABLATE_') for k in os.environ)
 assert all(digest(Path(n))==h for n,h in p['sources'].items());assert defaults()==p['defaults'];assert os.statvfs(W).f_bavail*os.statvfs(W).f_frsize>=256*1024**2
 assert not O.exists();O.mkdir(parents=True);started=time.monotonic();result=dict(status='RUNNING',comparisons=[],asr_loads=0,main_llm_loads=0,http_requests=0,production_acceptance=False,plan_sha256=digest(PLAN),defaults_before=defaults())
 try:
  rows=[]
  for item in p['cases']:
   row=dict(item['input']);assert all(digest(Path(row[n]))==row[n+'_sha256'] for n in ['pcm','mel']);rows.append(row)
  asr=O/'asr-plan.json';asr.write_text(json.dumps(dict(purpose='ASR_CLOCK_DIAGNOSTIC_NOT_PCM_ACCEPTANCE',cases=rows),indent=2)+'\n')
  command=[p['asr_binary'],p['asr_assets'],str(asr),str(O/'asr')];result.update(command=command,asr_loads=1)
  with (O/'asr.log').open('wb') as log:r=subprocess.run(command,cwd=R,pass_fds=(lease,),stdout=log,stderr=subprocess.STDOUT,timeout=180)
  result['asr_returncode']=r.returncode;assert r.returncode==0
  for i,item in enumerate(p['cases']):
   d=O/'asr'/f'case-{i}';receipt=json.loads((d/'result.json').read_bytes());assert receipt['frames']==item['input']['frames']*4
   result['comparisons'].append(dict(method=item['method'],utterance=item['utterance'],input_frames=item['input']['frames'],diagnostic_frames=receipt['frames'],diagnostic_audio_tokens=receipt['audio_tokens'],**diagnostic_check((d/'text.txt').read_text(),receipt,CASES[item['utterance']])))
  result['status']='CLOCK_DIAGNOSTIC_COMPLETED_NOT_ACCEPTANCE'
 except BaseException as e:result.update(status='CLOCK_DIAGNOSTIC_EXECUTION_FAILED',error=repr(e))
 finally:
  result.update(seconds=time.monotonic()-started,defaults_unchanged=defaults()==result['defaults_before'],artifacts={str(q.relative_to(O)):digest(q) for q in O.rglob('*') if q.is_file()})
  result['artifact_bytes']=sum(q.stat().st_size for q in O.rglob('*') if q.is_file());assert result['artifact_bytes']<16*1024**2
  if not result['defaults_unchanged']:result['status']='FAILED_PROTECTED_DEFAULT_CHANGED'
  (O/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','seconds','asr_loads','defaults_unchanged','comparisons']},ensure_ascii=False))
 return 0 if result['status']=='CLOCK_DIAGNOSTIC_COMPLETED_NOT_ACCEPTANCE' else 1
if __name__=='__main__':raise SystemExit(main())

"""Build an isolated ASR feature-clock diagnostic; production is unchanged."""
from pathlib import Path
import hashlib,json,shlex,subprocess,time
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.q4t-work/serve-audio-native-20261117/compute-build';O=W/'tempo-clock-build-02';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=R/'tools/native_asr/model_replay.cpp';s=source.read_text().replace('#include <bit>','#include <algorithm>\n#include <bit>')
start=s.index('void Check(const Status& status)')
helper='''// Diagnostic-only: expand measured log-mel time, never change PCM or text.
std::vector<float> ExpandLogMel(const std::vector<float>& source, int frames) {
  Require(frames > 0 && frames <= 750 &&
              source.size() == static_cast<size_t>(frames) * 128,
          "diagnostic feature shape differs");
  for (const auto value : source)
    Require(std::isfinite(value), "diagnostic nonfinite input");
  std::vector<float> output(source.size() * 4);
  for (int band = 0; band < 128; ++band) {
    for (int t = 0; t < frames * 4; ++t) {
      const double position = std::clamp((t + 0.5) / 4.0 - 0.5,
                                         0.0, double(frames - 1));
      const int lower = static_cast<int>(position);
      const int upper = std::min(lower + 1, frames - 1);
      const double weight = position - lower;
      output[band * frames * 4 + t] = static_cast<float>(
          source[band * frames + lower] * (1 - weight) +
          source[band * frames + upper] * weight);
    }
  }
  return output;
}
int ClockContracts() {
  auto constant = ExpandLogMel(std::vector<float>(256, 0.5f), 2);
  Require(constant.size() == 1024 &&
              std::all_of(constant.begin(), constant.end(),
                          [](float value) { return value == 0.5f; }),
          "constant log-mel changed");
  std::vector<float> ramp(128 * 4);
  for (int band = 0; band < 128; ++band)
    for (int t = 0; t < 4; ++t) ramp[band * 4 + t] = t;
  auto stretched = ExpandLogMel(ramp, 4);
  Require(stretched[0] == 0 && stretched[1] == 0 &&
              stretched[2] == 0.125f && stretched[3] == 0.375f &&
              stretched[14] == 3 && stretched[15] == 3,
          "time-cell interpolation or endpoint changed");
  std::vector<float> bands(128 * 3);
  for (int band = 0; band < 128; ++band)
    for (int t = 0; t < 3; ++t) bands[band * 3 + t] = band;
  auto odd = ExpandLogMel(bands, 3);
  for (int band = 0; band < 128; ++band)
    for (int t = 0; t < 12; ++t)
      Require(odd[band * 12 + t] == band, "frequency band mixed");
  int rejected = 0;
  try { (void)ExpandLogMel({}, 0); } catch (...) { ++rejected; }
  try { (void)ExpandLogMel({1}, 3); } catch (...) { ++rejected; }
  try { (void)ExpandLogMel({}, 751); } catch (...) { ++rejected; }
  bands[1] = std::numeric_limits<float>::quiet_NaN();
  try { (void)ExpandLogMel(bands, 3); } catch (...) { ++rejected; }
  Require(rejected == 4, "invalid diagnostic input accepted");
  std::cout << "4 clock diagnostic CPU contracts passed\\n";
  return 0;
}
'''
s=s[:start]+helper+s[start:]
s=s.replace('cases->array.size() >= 1 && cases->array.size() <= 3','cases->array.size() == 4')
s=s.replace('  const auto* cases = plan.GetArray("cases");','  Require(plan.GetString("purpose") ==\n              "ASR_CLOCK_DIAGNOSTIC_NOT_PCM_ACCEPTANCE",\n          "requires explicit diagnostic plan");\n  const auto* cases = plan.GetArray("cases");')
s=s.replace('const int frames = static_cast<int>(raw_frames);','int frames = static_cast<int>(raw_frames);')
needle='    Save<float>(case_output / "native-mel.f32", mel);';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    mel = ExpandLogMel(mel, frames);\n    frames *= 4;\n    Save<float>(case_output / "diagnostic-stretched-mel.f32", mel);')
s=s.replace('int main(int argc, char** argv) {','int main(int argc, char** argv) {\n  if (argc == 2 && std::string(argv[1]) == "--cpu-contracts")\n    return ClockContracts();')
s=s.replace('NATIVE_EXECUTION_COMPLETED_NOT_YET_COMPARED','DIAGNOSTIC_CLOCK_EXECUTED_NOT_PCM_ACCEPTANCE')
cpp=O/'asr_clock_diagnostic.cpp';cpp.write_text(s)
compile=['/usr/bin/g++-14','-O3','-DNDEBUG','-std=c++23','-Wall','-Wextra','-Werror','-I'+str(R/'.q4t-work/serve-audio-native-20261117/validation-src/include'),'-I'+str(R/'third_party'),'-isystem','/usr/local/cuda-13.3/targets/sbsa-linux/include','-isystem','/usr/local/cuda-13.3/targets/sbsa-linux/include/cccl','-c',str(cpp),'-o',str(O/'driver.o')]
args=shlex.split((B/'CMakeFiles/q4t_asr_replay.dir/link.txt').read_text());link=[];objects={}
for arg in args:
 if arg.startswith('-Wl,--dependency-file='):continue
 if arg.endswith('/model_replay.cpp.o'):arg=str(O/'driver.o')
 elif arg.endswith('.o'):
  p=B/arg;objects[str(p)]=sha(p);arg=str(p)
 elif arg=='q4t_asr_replay':arg=str(O/'q4t_asr_clock_diagnostic')
 link.append(arg)
plan=dict(purpose='ASR feature clock diagnostic only',original_source_sha256=sha(source),frozen_headers={str(p):sha(p) for p in (R/'.q4t-work/serve-audio-native-20261117/validation-src/include').rglob('*.h')},source_sha256=sha(cpp),reused_objects=objects,original_accepted_binary_sha256=sha(B/'q4t_asr_replay'),commands=[compile,link],production_changed=False,cpu_checks=4,cpu_seconds=60,asr_loads=1,asr_cases=4,asr_seconds=180,gpu_stage_seconds=600,generated_tokens_per_case=64)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');started=time.monotonic();results=[]
for i,command in enumerate([compile,link]):
 with (O/f'command-{i}.log').open('wb') as log:r=subprocess.run(command,cwd=B,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 results.append(dict(returncode=r.returncode));assert r.returncode==0
logs=''.join((O/f'command-{i}.log').read_text() for i in range(2));assert 'warning:' not in logs
result=dict(status='BUILD_PASS',seconds=time.monotonic()-started,warnings=0,binary_sha256=sha(O/'q4t_asr_clock_diagnostic'),commands=results,production_changed=False)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

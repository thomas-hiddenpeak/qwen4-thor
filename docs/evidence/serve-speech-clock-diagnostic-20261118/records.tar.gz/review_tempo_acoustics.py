"""Read-only analysis of existing acoustic artifacts, not acceptance tests."""
from pathlib import Path
import hashlib,json,os,time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
W=Path(__file__).resolve().parent
O=W/'tempo-acoustic-review-01'
assert not O.exists()
O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=dict(kind='existing_artifact_analysis',utterances=2,methods=['original','native_two_stage','phase_locked','soundtouch'],max_seconds=120,max_artifact_mib=4,minimum_free_mib=256,gpu_loads=0,http_requests=0,production_changes=0,acceptance_granted=False)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
assert os.statvfs(W).f_bavail*os.statvfs(W).f_frsize>=256*1024**2
started=time.monotonic();records=[];sources={}
for i in range(2):
 roots=[W/f'utterance-01/run/asr-input/case-{i}-mel.f32',W/f'tempo-02/run/asr-input/case-{i}-mel.f32',W/f'phase-tempo-content-02/run/case-{i}/mel.f32',W/f'tempo-diagnosis-0{i+1}/run/case-{i}-0/mel.f32']
 mels=[np.fromfile(p,'<f4').reshape(128,-1) for p in roots]
 sources.update({str(p):sha(p) for p in roots})
 fig,axes=plt.subplots(4,1,figsize=(10,9),sharex=True,constrained_layout=True)
 reference=mels[0];times=np.arange(reference.shape[1])/100
 rows=[]
 for method,p,mel,axis in zip(plan['methods'],roots,mels,axes):
  # This aligns normalized duration for descriptive comparison only. It does
  # not undo phase/transient loss and is never sent to the recognizer.
  mapped=np.stack([np.interp(np.linspace(0,mel.shape[1]-1,reference.shape[1]),np.arange(mel.shape[1]),band) for band in mel])
  a=reference-reference.mean(axis=0);b=mapped-mapped.mean(axis=0)
  cosine=(a*b).sum(axis=0)/np.maximum(1e-20,np.sqrt((a*a).sum(axis=0)*(b*b).sum(axis=0)))
  active=reference.max(axis=0)>reference.max()-0.75
  flux=np.maximum(np.diff(mel,axis=1),0).mean(axis=0)
  rows.append(dict(method=method,frames=mel.shape[1],duration_seconds=mel.shape[1]/100,normalised_duration_centered_spectral_cosine=float(cosine[active].mean()),positive_logmel_flux_mean=float(flux.mean()),positive_logmel_flux_max=float(flux.max()),causal_proof=False))
  axis.imshow(mel,origin='lower',aspect='auto',extent=[0,reference.shape[1]/100,0,128],vmin=float(reference.max()-2),vmax=float(reference.max()),interpolation='nearest',cmap='magma')
  axis.set_ylabel('Mel bin');axis.set_title(f'{method}: {mel.shape[1]} frames, aligned by normalized duration')
 axes[-1].set_xlabel('Original duration coordinate (seconds); fast waveforms stretched for viewing only')
 fig.savefig(O/f'utterance-{i}.png',dpi=120);plt.close(fig)
 records.append(dict(utterance=i,metrics=rows))
result=dict(status='ANALYSIS_ONLY',sources=sources,records=records,seconds=time.monotonic()-started,notes=['Spectral similarity is descriptive, not intelligibility or content acceptance.','A 25 ms ASR window covers 100 ms of original-time speech after 4x scaling; stride8 maps approximately 320 ms of original-time information into one audio token.','The phase prototype uses a 42.67 ms synthesis window versus a 10.67 ms scaled analysis-window duration, so full input coverage does not prove preservation of short events.','Cannot separate ASR temporal resolution from acoustic distortion with these measurements alone.'],next='Use evidence to choose a diagnostic; no further parameter search.')
assert result['seconds']<120
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
assert sum(p.stat().st_size for p in O.iterdir())<4*1024**2
print(json.dumps(dict(status=result['status'],seconds=result['seconds'],records=records),indent=2))

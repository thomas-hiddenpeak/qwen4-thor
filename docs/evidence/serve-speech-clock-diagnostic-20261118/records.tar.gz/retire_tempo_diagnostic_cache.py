"""Retire only obsolete, reproducible CMake object caches from this serve work."""
import os,json,hashlib,time,stat
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'rebuildable-cache-retirement-09';roots=[R/'.q4t-work/structured-control-20261102'];os.umask(0o077);assert not O.exists();O.mkdir(mode=0o700);start=time.monotonic();rows=[]
for root in roots:
 assert root.is_dir() and not root.is_symlink()
 for p in root.rglob('*.o'):
  if p.is_symlink() or not p.is_file() or 'CMakeFiles' not in p.relative_to(root).parts:continue
  anchor=p
  while anchor!=root and not (anchor/'CMakeCache.txt').is_file():anchor=anchor.parent
  assert (anchor/'CMakeCache.txt').is_file(),p
  cache=(anchor/'CMakeCache.txt').read_text();source=next(v.split('=',1)[1] for v in cache.splitlines() if v.startswith('CMAKE_HOME_DIRECTORY:INTERNAL='));assert Path(source).is_dir() and (Path(source)/'CMakeLists.txt').is_file()
  info=p.stat();assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid();rows.append(dict(path=str(p),bytes=info.st_size,allocated_bytes=info.st_blocks*512,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),cmake_cache=str(anchor/'CMakeCache.txt'),source=source))
assert len(rows)<=600 and sum(r['bytes'] for r in rows)<=160*1024**2
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:raw=(proc/'cmdline').read_bytes()
 except OSError:continue
 # Only active compiler/build processes using these exact build directories block retirement.
 if any(str(root).encode() in raw for root in roots) and any(n in raw.split(b'\0')[0] for n in (b'cc1',b'cmake',b'make',b'ninja',b'nvcc')):raise RuntimeError('selected cache has active build process')
plan=dict(scope='Generated .o files only; old serve stages, all source/ELF/vendor/model/evidence/default preserved',files=rows,model_actions=0,started=time.time(),before_available=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for row in rows:
 assert time.monotonic()-start<180;p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
result=dict(status='REBUILDABLE_OBJECT_CACHE_RETIRED',files=len(rows),logical_bytes=sum(r['bytes'] for r in rows),seconds=time.monotonic()-start,after_available=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,plan_sha256=hashlib.sha256((O/'plan.json').read_bytes()).hexdigest(),source_binary_model_evidence_unchanged=True,new_gpu_starts=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

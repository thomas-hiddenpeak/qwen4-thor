from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;OLD=ROOT/'.q4t-work/serve-video-geometry-20261116'
s=(OLD/'prepare_package.py').read_text()
s=s.replace('Seal accepted display engine','Seal accepted Chat style engine')
s=s.replace("OUT=W/'package-02'", "OUT=W/'package-01'")
s=s.replace('docs/evidence/serve-video-geometry-business-20261116/acceptance.json','docs/evidence/serve-chat-style-business-20261116/acceptance.json')
s=s.replace('ACCEPT_NATIVE_VIDEO_GEOMETRY_BUSINESS','ACCEPT_CHAT_STYLE_STREAM_BUSINESS')
a=s.index('    expected={');b=s.index('\n',a)
s=s[:a]+"    expected={'cmake/ChatProtocolIdentity.cmake','include/q4t/server/generation_style.h','include/q4t/server/http_response.h','src/server/chat_capabilities.cpp','src/server/chat_contract.cpp','src/server/chat_generation.cpp','src/server/chat_template.cpp','src/server/completion_response.cpp','src/server/http_response.cpp','src/server/output_constraints.cpp','src/server/responses_plan.cpp'}"+s[b:]
s=s.replace('rev142','rev150').replace('display HTTP accepted','Chat style HTTP accepted')
s=s.replace('PASS_NATIVE_VIDEO_GEOMETRY','PASS_CHAT_STYLE_STREAM').replace('ACCEPT_NATIVE_VIDEO_GEOMETRY','ACCEPT_CHAT_STYLE_STREAM_BUSINESS')
s=s.replace('actual_display_business=actual','actual_chat_style_business=actual')
s=s.replace("cpu_contracts=['docs/evidence/serve-video-geometry-cpu-20261116/README.md','docs/evidence/serve-video-display-source-cpu-20261116/README.md']", "cpu_contracts=['docs/evidence/serve-chat-style-cpu-20261116/README.md','docs/evidence/serve-chat-style-grammar-cpu-20261116/README.md']")
s=s.replace("version='serve-native-video-geometry-20261116'", "version='serve-chat-style-stream-20261116'")
a=s.index("source_note='");b=s.index("')",a)
s=s[:a]+"source_note='Chat default/null medium, full native effort guidance/verbosity, SSE padding/opt-out, multi-choice and real document tool closure accepted. Initial none template/grammar mismatch retained and fixed with shared resolution. Exact primary/light schema/tool/embedding/video qualification; native/control sources and helpers identical to rev150. Python client stream option validator updated with direct CPU proof. Exact new payload version composition and reversible publication pending; no full quality, performance or complete compatibility claim"+s[b:]
s=s.replace("metadata['geometry_acceptance']=decision", "metadata['chat_style_acceptance']=decision")
s=s.replace('Actual exact display and primary/light observations;', 'Actual exact Chat style and primary/light observations;')
a="    for n in clients['files']:p.require(p.sha(ROOT/n)==clients['files'][n],'client source changed');copy_file(ROOT/n,OUT/'clients'/n)"
b="""    client_delta={n for n,h in clients['files'].items() if p.sha(ROOT/n)!=h}
    p.require(client_delta=={'tools/examples/chat_client.py'},'unreviewed client delta')
    for n in clients['files']:
        clients['files'][n]=p.sha(ROOT/n);copy_file(ROOT/n,OUT/'clients'/n)
    decision['client_delta']=sorted(client_delta)
    p.save(OUT/'decision.json',decision)
    metadata['acceptance_decision_sha256']=p.sha(OUT/'decision.json')"""
assert a in s;s=s.replace(a,b);(W/'prepare_package.py').write_text(s)
s=(OLD/'prepare_retained.py').read_text().replace("PRIMARY=W/'package-02/bundle'", "PRIMARY=W/'package-01/bundle'").replace("W/'package-02/receipt.json'", "W/'package-01/receipt.json'")
(W/'prepare_retained.py').write_text(s)
s=(OLD/'media_version.py').read_text();needle="        check_mcp_capabilities(caps)"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n        self.engine.require(caps['template']['reasoning_effort_default']=='medium' and\n            caps['chat']['stream_include_obfuscation'] and\n            caps['chat']['stream_obfuscation_default'],\n            'accepted Chat style contract lost in exact payload')")
(W/'media_version.py').write_text(s)
s=(OLD/'test_media_version.py').read_text().replace("self.sealed('package-02')", "self.sealed('package-01')")
s=s.replace("str(WORK/'business-02/reflection.sdk.json')", "str(WORK.parent/'serve-video-geometry-20261116/business-02/reflection.sdk.json')")
(W/'test_media_version.py').write_text(s)
print('Prepared delivery drivers; no execution or default mutation')

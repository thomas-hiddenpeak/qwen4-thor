"""CPU verification of exact sealed payloads and media recovery driver."""
import copy
import json
import runpy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

FILE = Path(__file__).with_name('media_version.py')
DRIVER = runpy.run_path(str(FILE))
WORK = FILE.parent


class DriverTests(unittest.TestCase):
    def sealed(self, name):
        script = '''import copy,json,runpy,sys
from pathlib import Path
v=runpy.run_path(sys.argv[1]);pkg=Path(sys.argv[2])
v['LEGACY']['load_modules'](dict(package=dict(package=str(pkg))))
from tools.serve_recovery import bundle,controller,profile_runtime,profile_evidence
from tools.serve_service import package,capacity,supervisor
from tools.serve_ops import contracts
m=bundle.verify(pkg,package.sha(pkg/'manifest.json'))
engine=package.verify(pkg/'engine',m['engine_manifest_sha256'])
for module in [controller,profile_runtime,profile_evidence,package,capacity,supervisor,contracts]:
 assert Path(module.__file__).resolve().is_relative_to(pkg/'source'),module.__file__
argv=package.command(pkg/'engine',engine,state_directory=pkg.parent/'CPU_ONLY')
assert argv.count('--allow-media')==1 and '--mtp' in argv
assert '--allow-media'==argv[argv.index('--allow-media')]
assert m['recovery_profiles']['profiles']['primary']['allow_media'] is True
assert m['recovery_profiles']['profiles']['light']['allow_media'] is True
for f in [v['VERSION']['launcher'],v['VERSION']['Stage'].fatal_gateway,v['MANAGED']['launcher']]:
 assert Path(f.__globals__['__file__']).resolve()==Path(sys.argv[1]).resolve()
actual=json.loads(Path(sys.argv[3]).read_text())['result']
assert v['parse_response'](json.dumps(actual).encode(),False)==actual
v['check_media'](actual)
invalid=copy.deepcopy(actual)
for item in invalid['output']:
 if item['type']=='message':
  item['content']=[dict(type='output_text',text='{"start":"blue","end":"red"}',annotations=[],logprobs=[])]
try:v['check_media'](invalid)
except RuntimeError:pass
else:raise AssertionError('wrong actual colors accepted')
print('PASS_SEALED_MEDIA_VERSION')
'''
        result = subprocess.run([sys.executable, '-I', '-B', '-c', script,
            str(FILE), str(WORK/name/'bundle'),
            str(WORK.parent/'serve-video-geometry-20261116/business-02/reflection.sdk.json')],
            capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, 'PASS_SEALED_MEDIA_VERSION\n')

    def test_actual_primary_sealed_media_payload(self):
        self.sealed('package-01')

    def test_actual_retained_sealed_media_payload(self):
        self.sealed('retained-01')

    def test_each_action_is_bounded_before_dispatch(self):
        for name, limits in DRIVER['LIMITS'].items():
            with tempfile.TemporaryDirectory(dir=WORK) as directory:
                budget = DRIVER['LEGACY']['Budget'](Path(directory),
                    initialize=True, limits=limits)
                for kind in ('starts', 'chats', 'probes'):
                    for _ in range(limits[kind]):
                        budget.reserve(kind, 'CPU_ONLY')
                    with self.assertRaises(RuntimeError, msg=name+kind):
                        budget.reserve(kind, 'MUST_NOT_DISPATCH')

    def test_incomplete_or_environment_failure_cannot_be_accepted(self):
        for name, limits in DRIVER['LIMITS'].items():
            plan = dict(scenario=name, limits=limits,
                package={'cpu_fixture': True}, command=['CPU_ONLY'])
            counts = {k: v for k, v in limits.items() if k != 'seconds'}
            result = dict(status='PASS_BOUNDED_FEATURE_SERVICE', failure=None,
                cleanup_failure=None, package=plan['package'], scenario=name,
                seconds=1, budget=dict(counts=counts))
            guard = dict(status='COMPLETED', child_returncode=0,
                compute_backend='nvml', lease_inherited_by_child=True,
                external_lease=False, command=plan['command'])
            queries = [dict(status='OK', returncode=0)]
            events = [dict(event='lease_acquired', pid=1, monotonic=1),
                dict(event='lease_released', pid=1, monotonic=2, status='COMPLETED')]
            check = DRIVER['accepted_run']
            self.assertFalse(check(plan, result, guard, queries, events)['env_abort'])
            for bad in [dict(guard, status='ENV_ABORT'),
                        dict(guard, compute_backend='none')]:
                with self.assertRaises(RuntimeError):
                    check(plan, result, bad, queries, events)
            with self.assertRaises(RuntimeError):
                check(plan, dict(result, cleanup_failure='failure'), guard, queries, events)
            with self.assertRaises(RuntimeError):
                check(plan, result, guard, [], events)
            incomplete = copy.deepcopy(result)
            incomplete['budget']['counts']['chats'] -= 1
            with self.assertRaises(RuntimeError):
                check(plan, incomplete, guard, queries, events)


if __name__ == '__main__':
    unittest.main()

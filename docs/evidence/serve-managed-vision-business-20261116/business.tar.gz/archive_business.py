import fcntl,hashlib,json,sys,tarfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_responses import background_acceptance as b
from tools.serve_recovery import bundle
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;work=W/'business-01'
plan,result,cleanup,exit_record=[read(work/name) for name in ['plan.json','result.json','cleanup.json','lease/exit.json']]
require(result['status']=='PASS_MANAGED_JOINT_VISION_BUSINESS' and result['counts']['starts']==1 and result['counts']['chats']==4 and result['seconds']<600,'business incomplete')
require(exit_record['status']=='COMPLETED' and exit_record['child_returncode']==0 and exit_record['compute_backend']=='nvml' and exit_record['lease_inherited_by_child'],'strict environment failed')
queries=[json.loads(x) for x in (work/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and q['returncode']==0 for q in queries),'NVML failure')
require(cleanup['remaining']==[] and cleanup['model_exit']==0 and cleanup['ports_released'] and cleanup['lease_continuously_held'],'cleanup incomplete')
for n,h in {**plan['sources'],**plan['protected']}.items():require(sha(ROOT/n)==h,'source/default drift: '+n)
require(sha(plan['binary'])==plan['binary_sha256'],'binary changed')
bundle.check_assets(plan['model'],plan['model_assets'])
guard=b.base.lifecycle.guard;processes=guard.processes()
require(not any(processes.get(int(p),{}).get('start_ticks')==v['start_ticks'] for p,v in cleanup['owned'].items()),'owned process still live')
b.probe_ports((plan['port'],plan['operations_port']))
with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
compiled=read(W/'candidate-01/chat_protocol_sources.json')
require(all(sha(ROOT/n)==h for n,h in compiled.items()),'compiled source differs')
out=ROOT/'docs/evidence/serve-managed-vision-business-20261116';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
    for p in sorted(work.rglob('*')):
        if p.is_file() and 'objects' not in p.relative_to(work).parts:
            require(b'PRIVATE KEY-----' not in p.read_bytes(),'unexpected private key')
            tar.add(p,arcname='business-01/'+str(p.relative_to(work)))
    for name in ['accept.py','archive_business.py','gpu-business-01.json','gpu-business-01.stdout','gpu-business-01.stderr','identity.json']:
        tar.add(W/name,arcname=name)
receipt=dict(status='ACCEPT_MANAGED_JOINT_VISION_BUSINESS',binary_sha256=plan['binary_sha256'],protocol_sha256=read(W/'identity.json')['protocol_sha256'],counts=result['counts'],seconds=result['seconds'],nvml_queries=len(queries),environment='strict_completed_all_nvml_ok',cleanup_complete=True,default_unchanged=True,actual_business=read(work/'business-summary.json'),mtp_before=read(work/'before-mtp.json')['draft_counts'],mtp_after=read(work/'after-mtp.json')['draft_counts'],compiled_source_identity=compiled,raw_archive_sha256=sha(out/'business.tar.gz'),managed_recovery_pending=True,performance_claim=False)
save(out/'acceptance.json',receipt)
(out/'README.md').write_text(f'''# 同一服务文本MTP与视觉普通解码业务通过

2026-11-16，1启动/4创建/{result['seconds']:.3f}秒，{len(queries)}次NVML正常。
使用实际version2托管容量生成argv并核对运行观测；MTP/视觉共同加载。
普通文本前后均返回1..12的正确数组，实际MTP各10步，draft_counts均为
0,0,1,9。中间无grammar的视频正确读出首红末蓝，计数一致；PDF正确
读出42/绿色；两个媒体执行均没有进入文本MTP，前后同PID保持。

全部源/编译清单/二进制/模型资产/默认身份核对；自有PID/端口/锁已
清理，rev134保持。归档未包含对象库，不新增云账户业务或性能结论。
继续主轻媒体资格、显式升级及真实恢复/可回退发行，全部master仍active。
''')
print(json.dumps({k:v for k,v in receipt.items() if k!='compiled_source_identity'}))

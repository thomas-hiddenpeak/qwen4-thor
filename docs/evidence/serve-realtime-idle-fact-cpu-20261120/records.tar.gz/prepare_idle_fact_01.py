from pathlib import Path
import json,hashlib,subprocess,re
W=Path(__file__).parent;R=W.resolve().parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tests=['realtime_idle_fact_never_replaces_received_speech_or_finite_empty','realtime_chat_idle_fact_preserves_response_policy_and_roles','realtime_idle_cue_requires_native_provenance_and_never_becomes_transcript','realtime_session_idle_empty_turn_reaches_actual_chat_planner','realtime_session_idle_uses_actual_output_playback_duration','realtime_chat_defaults_and_per_response_override_are_effective','realtime_composed_input_private_transcript_still_drives_context','realtime_session_native_input_wait_uses_original_deadline']
assert all(n in ''.join(p.read_text() for p in Path('tests').glob('server_realtime*test.cpp')) for n in tests)
plan=dict(scope='Remove response-policy injection from native zero-sample idle fact; preserve caller instructions, real ASR and public history. Reconstruct exact production planner inputs from original business events, no hardcoded answer or sampling changes.',tests=tests,limits=dict(cpu_tests=8,source_counterexamples=20,cpu_seconds=120,gpu_starts=1,websocket_sessions=1,responses=2,audio_inputs=1,chats=6,gpu_seconds=900),gpu_contract=dict(diagnostic_seeds=[41,42],diagnostic_temperature=1,old_and_new_inputs_only_differ_in_native_idle_fact=True,default_sampling_unchanged=True,no_replay=True,original_failure_preserved=True,manual_business_reused=True),state='development_targeted_validation_pending')
(W/'idle-fact-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
p=Path('tools/release/required_host_tests.txt');s=p.read_text();p.write_text(s+''.join(n+'\n' for n in tests[:2] if n not in s))
p=Path('tools/serve_audit/inventory.json');v=json.loads(p.read_text());v['duplex_idle_fact_20261120']=plan
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
def refresh(x):
 if isinstance(x,dict):
  for k,z in list(x.items()):
   if k in changed and isinstance(z,str) and len(z)==64 and Path(k).is_file():x[k]=sha(Path(k))
   else:refresh(z)
 elif isinstance(x,list):
  for z in x:refresh(z)
refresh(v);p.write_text(json.dumps(v,indent=2)+'\n')
p=Path('docs/STATUS.md');s=p.read_text();at=s.index('\n## 当前实际默认');s=s[:at]+'''
空闲输入修复已开发：执行快照只提供“未检测到语音”的原生事实，
不再额外指挥模型邀请用户；应用/单次回答指令保持。先前实际会话
已通过生产history/planner/template重建（0GPU），保存原prompt。
冻结8项CPU/20来源反例/120秒，随后最多1模型/1WSS/2回答/1音频/6Chat/
900秒：两个固定seed的新旧提示对照及真实空闲短验。原失败和已通过
手动业务复用，不修改默认采样；受影响恢复/交付及全部master继续。
''' +s[at:];p.write_text(s)
p=Path('docs/log/2026-11-20.md');s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 空闲输入只报告事实，保留应用回复策略

日期：2026-11-20。

做了什么：从真实VAD事件经生产history/planner/template重建原请求，
确认额外“Invite the user to continue.”进入最后user文本；现只保留
空闲事实。补实际规划角色/应用与响应覆盖保护、非空ASR/有限空输入
保护；冻结8 CPU/20来源反例，后续1模型/1WSS/2回答/1音频/6Chat/900秒，
固定seed41/42对照原/新输入并验证真实空闲；当前未追加GPU。

为什么：服务端不应把自己的回复策略注入用户输入。该缺陷与原模型
错误分开记录，尚未据此认定因果；不硬编码READY、不修改采样默认。

下一步：针对CPU与必要构建、受影响业务短验，继续主轻/恢复/发行
和全部master；原失败与未受影响通过的证据均保留。
''' +s[i:])
for name,old,new in [('host','idle-build-01','idle-fact-build-01'),('runtime','mixed-entry-runtime-01','idle-fact-runtime-01')]:
 src='build_idle_01.py' if name=='host' else 'build_mixed_entry_runtime_01.py'
 content=(W/src).read_text().replace(old,new)
 if name=='host':content=content.replace('eaab2e88bf334640fcc4540d5a67a23e46d830ce86cf3ce48ad6b46f7cc41942','83f8fe997fc00f08ea319f178c5bc43a624c69b8249865d5b45dad4e389be3e6')
 else:content=content.replace('1f01ec621cd7a79ca037e3f5308325c0b3e10d9f00c66da04896ea03f6c5e577','fe4a47d4a663786c05b3bb4ba4e42effa0fd1b3d268e49a187f8c370f8ffaa11')
 (W/('build_idle_fact_'+name+'_01.py')).write_text(content)
s=(W/'run_mixed_entry_cpu_01.py').read_text().replace('mixed-entry','idle-fact').replace('==36','==8').replace('tests=36','tests=8');(W/'run_idle_fact_cpu_01.py').write_text(s)

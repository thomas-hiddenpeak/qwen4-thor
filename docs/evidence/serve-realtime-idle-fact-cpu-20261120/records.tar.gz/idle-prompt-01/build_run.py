from pathlib import Path
import json,shlex,subprocess,hashlib,sys,time
W=Path(__file__).parent.resolve();R=W.parents[2];B=R/'.q4t-work/serve-file-search-20261112/host';variant=sys.argv[1]
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
link=shlex.split((B/'CMakeFiles/q4t_host_tests.dir/link.txt').read_text());sources=[str((B/n).resolve()) for n in link if n.endswith('.o') and '/src/' in n];tail=link[link.index('-o')+2:]
cmd=['g++-14','-std=c++23','-O2','-Wall','-Wextra','-Werror','-DQ4T_ENABLE_XGRAMMAR=1','-I'+str(R),' -I'+str(R/'include')]
cmd[-1]=cmd[-1].strip();cmd +=[str(W/'probe.cpp'),*sources,*tail,'-o',str(W/(variant+'-probe'))]
plan=dict(command=cmd,objects={n:sha(n) for n in sources},probe_source_sha256=sha(W/'probe.cpp'),code_sha256=sha(R/'src/server/realtime_conversation.cpp'),gpu_actions=0)
(W/(variant+'-build-plan.json')).write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic()
run=subprocess.run(cmd,cwd=B,capture_output=True,timeout=120);(W/(variant+'-build.stdout')).write_bytes(run.stdout);(W/(variant+'-build.stderr')).write_bytes(run.stderr)
assert run.returncode==0,(run.returncode,run.stderr.decode()[-4000:]);assert b'warning:' not in run.stderr
fixture=W/'fixture.json'
if not fixture.exists():
 raw=json.loads((W.parent/'business-02/run/vad.sdk.json').read_text());events=raw['events'];idle=next(e for e in events if e['type']=='input_audio_buffer.timeout_triggered');at=events.index(idle)
 settings=[e['session'] for e in events[:at] if e['type']=='session.updated'][-1];items=[e['item'] for e in events[:at] if e['type']=='conversation.item.done']
 asr=next(e for e in events[:at] if e['type']=='conversation.item.input_audio_transcription.completed');items[0]['content'][0]['transcript']=asr['transcript']
 original=next(e['item'] for e in events[at:] if e['type']=='conversation.item.done');original['native_idle']=True;items.append(original)
 fixture.write_text(json.dumps(dict(settings=settings,items=items),ensure_ascii=False)+'\n')
run=subprocess.run([str(W/(variant+'-probe'))],input=fixture.read_bytes(),capture_output=True,timeout=30);(W/(variant+'.json')).write_bytes(run.stdout);(W/(variant+'.stderr')).write_bytes(run.stderr);assert run.returncode==0,(run.returncode,run.stderr)
v=json.loads(run.stdout);(W/(variant+'.prompt')).write_text(v['prompt']);print(json.dumps(dict(status='PASS',variant=variant,seconds=time.monotonic()-start,source=plan['code_sha256'],prompt_sha256=sha(W/(variant+'.prompt')),fixture_sha256=sha(fixture),gpu_actions=0)))

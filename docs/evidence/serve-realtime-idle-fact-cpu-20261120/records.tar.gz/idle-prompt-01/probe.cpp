// CPU reconstruction through production history/planner/template, no inference.
#include <iostream>
#include "src/server/object_protocol.h"
#include "q4t/server/realtime_conversation.h"
#include "q4t/server/realtime_chat_plan.h"
#include "q4t/server/chat_prompt.h"
using namespace q4t::server;
using namespace q4t::server::object_detail;
int main() {
  std::string line;
  if (!std::getline(std::cin, line)) return 2;
  Json fixture;
  if (!q4t::io::ParseJson(line, &fixture, true)) return 2;
  RealtimeConversation history("reconstructed");
  for (const auto& item : fixture.Find("items")->array) {
    RealtimeItemTicket ticket;
    const bool native = item.GetString("role") == "user";
    if (native) {
      const auto& part = item.GetArray("content")->array.at(0);
      if (!history.BeginAudioInput(item.GetString("id"), {}, true, 8192,
                                   &ticket) ||
          !history.CompleteAudioInput(ticket, part.GetString("transcript"),
                                      item.GetBool("native_idle"))) return 3;
    } else if (!history.Create(item, "unused", {}, &ticket)) return 3;
  }
  RealtimeConversationSnapshot snapshot;
  if (!history.Snapshot(nullptr, &snapshot)) return 4;
  ChatPlanConfig config;
  config.model = "qwen3.8-flash-next";
  config.structured = true;
  config.max_len = 8192;
  config.max_prefill = 2048;
  RealtimeChatPlan plan;
  ChatPlanError error;
  auto status = PlanRealtimeChat(*fixture.Find("settings"), Object(),
                                snapshot.items, config, &plan, &error,
                                nullptr, true);
  if (!status) { std::cerr << status.message(); return 5; }
  const auto& request = plan.generation.generation_request;
  std::string prompt;
  std::vector<VisionItem> media;
  status = PrepareChatPrompt(request, plan.generation.chat.constraints,
                            &prompt, &media, &error.param);
  if (!status) { std::cerr << status.message(); return 6; }
  std::cout << OutputJson(Object({{"request", request},
      {"prompt", String(prompt)}, {"snapshot", snapshot.items}})) << '\n';
}

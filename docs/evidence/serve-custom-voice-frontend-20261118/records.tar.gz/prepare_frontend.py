from pathlib import Path
import urllib.request,json,hashlib,time,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'frontend-reference-source-01';assert not O.exists();O.mkdir();start=time.monotonic()
source=R/'.q4t-work/serve-native-tts-20261118/source-01/official/qwen_tts/core/models/modeling_qwen3_tts.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=dict(component='24kHz native TTS speaker frontend',cpu_contract_cases=8,cpu_reference_cases=6,max_seconds=180,gpu_loads=0,model_loads=0,max_artifact_mib=8,minimum_free_mib=256,sample_rate=24000,fft=1024,hop=256,mel_bins=128,reflect_padding=384,magnitude_epsilon=1e-9,log_floor=1e-5,maximum_absolute_logmel_error=1e-4,numerical_scope='FP32 frontend only; tolerance covers rounded FFT/filter accumulation before BF16 conditioning, no model quality claim',source_sha256=sha(source),reference='Exact official Qwen mel function with official librosa 0.11.0 filter body and existing CPU-only torch 2.14.0; memoization decorators excluded, computations unchanged',production_dependency_added=False)
(W/'frontend-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
with urllib.request.urlopen('https://pypi.org/pypi/librosa/0.11.0/json',timeout=30) as response:raw=response.read(512*1024+1)
assert len(raw)<=512*1024;(O/'pypi.json').write_bytes(raw);meta=json.loads(raw);wheel=next(x for x in meta['urls'] if x['packagetype']=='bdist_wheel');assert wheel['size']<=1024*1024 and wheel['url'].startswith('https://files.pythonhosted.org/')
with urllib.request.urlopen(wheel['url'],timeout=30) as response:data=response.read(wheel['size']+1)
assert len(data)==wheel['size'] and hashlib.sha256(data).hexdigest()==wheel['digests']['sha256'];path=O/wheel['filename'];path.write_bytes(data)
with zipfile.ZipFile(path) as archive:
 for name in ['librosa/filters.py','librosa/core/convert.py','librosa-0.11.0.dist-info/licenses/LICENSE.md']:
  if name not in archive.namelist():
   if 'LICENSE' in name:name=next(n for n in archive.namelist() if n.endswith('LICENSE.md'))
   else:raise RuntimeError(name)
  dest=O/Path(name).name;dest.write_bytes(archive.read(name))
result=dict(status='REFERENCE_SOURCE_ONLY',seconds=time.monotonic()-start,files={p.name:sha(p) for p in O.iterdir() if p.is_file()},new_production_dependencies=0,models_loaded=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

#include "../../src/audio/tts_speaker_features.cpp"
#include <fstream>
#include <string>
#include <vector>
template<class T> void Write(const std::string& path,const T& value) {
 std::ofstream f(path,std::ios::binary);
 f.write(reinterpret_cast<const char*>(value.data()),value.size()*sizeof(value[0]));
 if(!f)throw std::runtime_error("write");
}
int main(int argc,char** argv) {
 if(argc!=3)return 2;
 static const q4t::audio::Tables tables;
 Write(std::string(argv[2])+"/window.f32",tables.window);
 Write(std::string(argv[2])+"/filters.f32",tables.filters);
 for(const auto* name:{"tone","mixture","tail"}) {
  std::ifstream f(std::string(argv[1])+"/"+name+"-pcm.f32",std::ios::binary|std::ios::ate);
  auto size=f.tellg();if(size<=0||size%4)return 3;
  std::vector<float> input(static_cast<size_t>(size)/4);
  f.seekg(0);f.read(reinterpret_cast<char*>(input.data()),size);if(!f)return 4;
  q4t::audio::TtsSpeakerFeatures features;
  if(!q4t::audio::ComputeTtsSpeakerFeatures(input,24000,{},&features))return 5;
  Write(std::string(argv[2])+"/"+name+"-native.f32",features.mel);
 }
}

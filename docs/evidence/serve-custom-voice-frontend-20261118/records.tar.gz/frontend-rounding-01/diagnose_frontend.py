from pathlib import Path
import importlib.util, json, os, shutil, subprocess, time
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'frontend-rounding-01'
O.mkdir(exist_ok=False);assert shutil.disk_usage(W).free>256*1024*1024
os.environ['CUDA_VISIBLE_DEVICES']=''
import numpy as np
import torch
assert torch.__version__=='2.14.0+cpu'
torch.set_num_threads(1)
start=time.monotonic()
cmd=['g++-14','-std=c++23','-O2','-Wall','-Wextra','-Werror','-I'+str(R/'include'),str(W/'frontend_inspect.cpp'),'-o',str(O/'inspect')]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
(O/'build.log').write_text(p.stdout+p.stderr);assert p.returncode==0
subprocess.run([str(O/'inspect'),str(R/'tests/fixtures/tts/speaker_features'),str(O)],check=True,timeout=20)
native_window=np.fromfile(O/'window.f32',dtype='<f4');window=torch.hann_window(1024)
filters=np.fromfile(O/'filters.f32',dtype='<f4').reshape(128,513)
spec=importlib.util.spec_from_file_location('ref',R/'tools/native_tts/speaker_feature_reference.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
scope=dict(np=np,torch=torch)
ref.definitions(W/'frontend-reference-source-01/convert.py','3f0679eeb5706771797ddacc4174bfacd1146abae78e8a583d97d6aa4391985f',['hz_to_mel','mel_to_hz','fft_frequencies','mel_frequencies'],scope)
ref.definitions(W/'frontend-reference-source-01/filters.py','df2914ab2262a5b72e59dba320e35fb934a0825c314c48a2542ade8c23116c4e',['mel'],scope)
official_filters=scope['mel'](sr=24000,n_fft=1024,n_mels=128,fmin=0,fmax=12000)
def mel(c, f):
 c=c.astype(np.complex64)
 mag=np.sqrt(c.real*c.real+c.imag*c.imag+np.float32(1e-9))
 return np.log(np.maximum((f.astype(np.float64)@mag.astype(np.float64)).astype(np.float32),np.float32(1e-5)))
rows=[]
for name in ['tone','mixture','tail']:
 pcm=np.fromfile(R/'tests/fixtures/tts/speaker_features'/(name+'-pcm.f32'),dtype='<f4')
 expected=np.fromfile(R/'tests/fixtures/tts/speaker_features'/(name+'-mel.f32'),dtype='<f4').reshape(128,-1)
 actual=np.fromfile(O/(name+'-native.f32'),dtype='<f4').reshape(128,-1)
 padded=np.pad(pcm,(384,384),mode='reflect')
 frames=np.lib.stride_tricks.sliding_window_view(padded,1024)[::256]
 def fft(w):return np.fft.rfft((frames*w).astype(np.float64),axis=1).T
 same=mel(fft(native_window),filters)
 swapped=mel(fft(window.numpy()),official_filters)
 torch_fft=torch.stft(torch.from_numpy(padded)[None,:],1024,hop_length=256,win_length=1024,window=window,center=False,return_complex=True)[0].numpy()
 torch_with_double_reduction=mel(torch_fft,official_filters)
 loc=np.unravel_index(np.argmax(np.abs(actual-expected)),actual.shape)
 rows.append(dict(name=name,maximum_logmel_error=float(np.max(np.abs(actual-expected))),
  native_vs_numpy_same_inputs=float(np.max(np.abs(actual-same))),
  official_window_with_double_fft_vs_reference=float(np.max(np.abs(swapped-expected))),
  torch_fft_double_mel_reduction_vs_reference=float(np.max(np.abs(torch_with_double_reduction-expected))),
  fft_complex_max_difference=float(np.max(np.abs(fft(window.numpy())-torch_fft))),
  worst=dict(bin=int(loc[0]),frame=int(loc[1]),native=float(actual[loc]),reference=float(expected[loc]),linear_magnitude_error=float(abs(np.exp(actual[loc])-np.exp(expected[loc]))),
  official_window_changes=float(np.max(np.abs(same-swapped))))))
v=dict(status='DIAGNOSED_NOT_QUALIFIED',rows=rows,window_max_difference=float(np.max(np.abs(native_window-window.numpy()))),window_differing_coefficients=int(np.sum(native_window!=window.numpy())),filters_max_difference=float(np.max(np.abs(filters-official_filters))),seconds=time.monotonic()-start,gpu_loads=0,model_loads=0)
(O/'result.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
assert not torch.cuda.is_initialized()

from pathlib import Path
import hashlib,json,shutil,subprocess,time
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'frontend-cpu-02'
O.mkdir(exist_ok=False)
plan=json.loads((W/'frontend-case-contract-01.json').read_text())
plan['cases']=[n for n in plan['cases'] if '_reference_' in n or n.endswith('_scratch') or n.endswith('_partial_hop')]
assert shutil.disk_usage(W).free>=256*1024*1024
binary=W/'frontend-build-02/q4t_tts_speaker_frontend'
build=json.loads((W/'frontend-build-02/result.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert build['warnings']==0 and sha(binary)==build['binary_sha256']
for n,h in build['sources'].items():assert sha(R/n)==h
(O/'required.txt').write_text('\n'.join(plan['cases'])+'\n')
cmd=[str(binary),'--required-list',str(O/'required.txt')]
start=time.monotonic()
with (O/'tests.log').open('w') as f:
 p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=180)
value=dict(status='PASS' if p.returncode==0 else 'FAIL',returncode=p.returncode,
 seconds=time.monotonic()-start,command=cmd,requested_cases=8,
 binary_sha256=sha(binary),gpu_loads=0,model_loads=0)
(O/'result.json').write_text(json.dumps(value,indent=2)+'\n')
print((O/'tests.log').read_text());print(json.dumps(value))
raise SystemExit(p.returncode)

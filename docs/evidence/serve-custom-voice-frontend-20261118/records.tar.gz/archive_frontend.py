from pathlib import Path
import hashlib,json,tarfile,shutil
W=Path(__file__).resolve().parent;R=W.parents[1]
O=R/'docs/evidence/serve-custom-voice-frontend-20261118';assert not O.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def put(p,s):
 t=p.with_name(p.name+'.tmp');t.write_text(s);t.replace(p)
cpu=read(W/'frontend-cpu-02/result.json');build=read(W/'frontend-build-02/result.json')
first=read(W/'frontend-cpu-01/result.json');inv=read(W/'frontend-cpu-02/inventory.json')
assert cpu['status']=='PASS' and first['status']=='FAIL' and build['warnings']==0 and inv['inventory_current']
assert '8 tests, 8 passed, 0 failed, 0 skipped' in (W/'frontend-cpu-02/tests.log').read_text()
assert '14 tests, 11 passed, 3 failed, 0 skipped' in (W/'frontend-cpu-01/tests.log').read_text()
default=read(R/'docs/evidence/serve-tts-mainline-20261118/result.json')['default_sha256']
for n,h in default.items():assert sha(R/n)==h
for n in build['sources']:
 p=W/'frontend-build-02/source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
files={}
for name in ['frontend-build-01','frontend-build-02','frontend-cpu-01','frontend-cpu-02',
             'frontend-reference-01','frontend-reference-02','frontend-rounding-01','frontend-rounding-02',
             'frontend-reference-source-01']:
 for p in (W/name).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.name not in ['inspect','q4t_tts_speaker_frontend'] and p.suffix!='.whl':
   files[str(p.relative_to(W))]=p
for p in W.iterdir():
 if p.is_file() and ('frontend' in p.name or p.name=='archive_frontend.py'):
  files[p.name]=p
for n in ['tools/native_tts/speaker_feature_reference.py','tests/fixtures/tts/speaker_features/README.md']:
 files['current/'+n]=R/n
q=R/'.q4t-work/serve-native-tts-20261118/source-01/official'
files['official/qwen_tts/core/models/modeling_qwen3_tts.py']=q/'qwen_tts/core/models/modeling_qwen3_tts.py'
files['official/QWEN-LICENSE']=q/'LICENSE'
assert sum(p.stat().st_size for p in files.values())<8*1024*1024
for p in files.values():assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in p.read_bytes()
O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz',compresslevel=9) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz') as t:
 for f in t.getmembers():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==index[f.name]['sha256']
v=dict(status='FRONTEND_EQUATIONS_CPU_QUALIFIED_MODEL_PENDING',unique_cases=14,
 fresh_after_repair=8,unaffected_reused=6,total_case_executions=22,
 seconds=cpu['seconds']+first['seconds'],latest_build_seconds=build['seconds'],warnings=0,
 original_fp32_logmel_gate='FAIL_RETAINED_3_CASES',canonical_maximum_absolute_error=0,
 original_fp32_maximum_absolute_difference=0.004363059997558594,
 maximum_bfloat16_ulp=1,bfloat16_metric_is_not_runtime_precision_or_quality_acceptance=True,
 source_anchors=inv['reviewed_source_anchors'],negative_controls=inv['mutation_checks'],
 gpu_loads=0,model_loads=0,default_sha256=default,default_changed=False,
 full_asset_verified=False,model_numerical_qualified=False,runtime_api_qualified=False,
 archive_sha256=sha(O/'records.tar.gz'),master_complete=False)
put(O/'index.json',json.dumps(index,indent=2)+'\n');put(O/'result.json',json.dumps(v,indent=2)+'\n')
put(O/'README.md','''# 原生自定义音色前端计算验证

实现24kHz、FFT1024/hop256、128 Slaney mel、反射384及原幅值/log
方程，原生中间值使用FP64，输出FP32。无需Python/librosa运行依赖。
14个独立CPU合同已覆盖：首次14执行11通过3失败；原因诊断并修改
计算精度后，只重验6矩阵和2个受影响合同，8通过，其余6边界复用。
合计22执行/0.227秒、最新构建2.972秒零警告，919来源/13负控。

原先针对官方CPU FP32实现的log-mel绝对误差1e-4门有3例失败，
原失败保留。逐阶段对照确认滤波器完全相同，低能量FFT舍入被log
放大。诊断工具首次因8.4MB自动表导致栈溢出（0样本）保留，改为
与生产一致的静态表后完成；语法预检错误也保留，均非模型运行。

新增独立高精度参考仍执行固定官方Qwen方程，只把CPU计算/显式
mel类型转成float64；滤波器保持原float32值。六份全矩阵最终FP32
与原生结果相同，仍守1e-4方程门。与原官方FP32最大差0.00436306，
全部值舍入BF16后≤1 ULP。这个量尺反映官方BF16加载下的输入接近
程度，**不说明原生网络已改成BF16，更不能代替FP32网络或真实业务
验收**。完整2048维声纹、实际Base条件合成、注册和恢复继续。

公开原始官方FP32和高精度夹具、原函数/许可、生成器、首次失败、
逐阶段诊断和全部计划/结果。0GPU/模型，默认rev316五份身份不变。
[结果](result.json)、[逐文件摘要](index.json)、[原件](records.tar.gz)。
''')
entry='[自定义音色前端CPU计算通过](evidence/serve-custom-voice-frontend-20261118/README.md)：\n14独立合同、22执行/0.227秒，0GPU；原FP32 log门3失败保留。\n原生FP64中间值与独立高精度全矩阵一致，官方FP32差异及≤1 BF16\nULP另记，不能替代完整声纹/业务验收。默认rev316保持，继续后端。\n\n'
p=R/'docs/STATUS.md';s=p.read_text();put(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+entry,1))
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);put(p,h+'\n\n## 原生音色前端方程与精度边界验证（2026-11-18）\n\n'+entry.replace('(evidence/','(../evidence/')+'为区分低能量FFT舍入与方程错误，保留首次失败并独立验证高精度\n方程，未以BF16输入接近代替网络/实际音色。下一步2048维声纹\n计算与持久注册；总目标active，未改默认/未追加GPU。\n'+b)
p=R/'docs/SERVE_CUSTOM_VOICES_2026-11-18.md';put(p,p.read_text()+'\n前端阶段证据见[原生计算与舍入诊断](evidence/serve-custom-voice-frontend-20261118/README.md)。\n原FP32 log门失败原样保留；高精度方程通过，模型数值与音色业务仍\n待实际后端验证。checkpoint BF16存储不代表原生激活采用BF16。\n')
p=R/'docs/serve-master-goals-v2.json';m=read(p);m['native_tts_progress']['custom_voice']['frontend']=dict(state=v['status'],evidence='evidence/serve-custom-voice-frontend-20261118/README.md',unique_cases=14,total_case_executions=22,gpu_loads=0,original_fp32_logmel_gate=v['original_fp32_logmel_gate'],model_numerical_qualified=False);put(p,json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=v['status'],files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size)))

from pathlib import Path
import hashlib, json, shutil, subprocess, time
W=Path(__file__).resolve().parent; R=W.parents[1]
O=W/'frontend-build-01'; O.mkdir(exist_ok=False)
assert shutil.disk_usage(W).free >= 256*1024*1024
sources=['tests/test_main.cpp','tests/tts_speaker_features_test.cpp',
         'src/audio/tts_speaker_features.cpp']
cmd=['g++-14','-std=c++23','-O2','-Wall','-Wextra','-Werror','-I'+str(R/'include'),
     *[str(R/p) for p in sources],'-o',str(O/'q4t_tts_speaker_frontend')]
start=time.monotonic()
with (O/'build.log').open('w') as log:
 p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
value=dict(status='PASS' if p.returncode==0 else 'FAIL',returncode=p.returncode,
 seconds=time.monotonic()-start,command=cmd,
 warnings=(O/'build.log').read_text().count('warning:'),
 sources={n:sha(R/n) for n in sources+['include/q4t/audio/tts_speaker_features.h']})
if p.returncode==0:value['binary_sha256']=sha(O/'q4t_tts_speaker_frontend')
(O/'result.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value));raise SystemExit(p.returncode)

from pathlib import Path
import json, os, shutil, subprocess, time
W=Path(__file__).resolve().parent;R=W.parents[1]
O=W/'frontend-reference-02';O.mkdir(exist_ok=False)
assert shutil.disk_usage(W).free >= 256*1024*1024
cmd=[str(R/'.q4t-work/refenv/bin/python'),'-B',
 str(R/'tools/native_tts/speaker_feature_reference.py'),
 '--qwen-source',str(R/'.q4t-work/serve-native-tts-20261118/source-01/official/qwen_tts/core/models/modeling_qwen3_tts.py'),
 '--librosa-source',str(W/'frontend-reference-source-01'),
 '--output',str(O/'fixtures'),'--float64-equations']
start=time.monotonic()
with (O/'generation.log').open('w') as f:
 p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,
   env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1'),timeout=180)
v=dict(status='PASS' if p.returncode==0 else 'FAIL',returncode=p.returncode,
 seconds=time.monotonic()-start,command=cmd,gpu_loads=0,model_loads=0)
(O/'result.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v));raise SystemExit(p.returncode)

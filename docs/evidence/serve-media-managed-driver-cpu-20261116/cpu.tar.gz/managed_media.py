"""Actual primary/light/primary visual service recovery, <=3 starts/12 creates/900s."""
import argparse,copy,io,json,os,runpy,signal,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
BASE=runpy.run_path(str(ROOT/'tools/serve_recovery/profile_managed_acceptance.py'))
BASE['launcher'].__globals__['__file__']=__file__
LEGACY=BASE['LEGACY'];LIMITS=BASE['LIMITS'];save=LEGACY['save']
W=Path(__file__).resolve().parent

def requests():
    from tools.serve_recovery import profile_acceptance,profile_evidence
    rows=profile_acceptance.requests(True)
    follow=copy.deepcopy(rows['media']);follow['input']='For the same earlier video, inspect the actual start and end colors and return them as JSON.'
    rows['media_follow']=follow
    return rows

def prepare(args):
    from tools.serve_recovery import bundle,profile_policy
    from tools.serve_service import package as engine
    engine.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit reviewed source first')
    original=W/'package-01/bundle';old=bundle.verify(original,engine.sha(original/'manifest.json'))
    base=engine.read(original/'engine/manifest.json');out=args.output.resolve()
    engine.require(not out.exists() and out.is_relative_to(W),'preserve previous run');out.mkdir(mode=0o700)
    policy=engine.read(original/'gateway-policy.json');backend=engine.read(original/'engine/client-policy.json')
    engine.require([c['id'] for c in backend['clients']]==['alpha','beta'] and backend['clients'][1]['requests_per_minute']==1,'client policy differs')
    policy.update(listen_port=args.port,upstream_port=args.port+1,upstream_operations_port=args.port+2)
    for c in policy['clients']:c['api_key']='qualified-'+c['id']+'-'+'c'*48
    backend['gateway_token']='d'*64
    engine.save(out/'gateway-policy.json',policy);engine.save(out/'client-policy.json',backend)
    adaptive=dict(profile_policy.DEFAULTS,degrade_below_mib=24576,recover_above_mib=28672,pressure_seconds=2,recovery_seconds=30,minimum_light_seconds=60,cooldown_seconds=60)
    kwargs={key:original/'engine'/name for key,name in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json')] if (original/'engine'/name).is_file()}
    receipt=bundle.prepare(original/'engine/q4t',original/'engine/q4t.release.json',base['model_dir'],original/'bin/q4t-guardian',original/'bin/q4t-cuda-probe',None,out/'gateway-policy.json',out/'client-policy.json',out/'bundle',native_receipt=original/'native-build.json',native_ingress=original/'bin/q4t-ingress',device_control=original/'bin/q4t-device-control',capacity_config=engine.read(W/'media-capacity.json'),application_state={k:v for k,v in base['settings']['application_state'].items() if k!='profile'},embedding_model_dir=Path(base['settings']['native_embedding']['directory']),recovery_profiles=W/'profiles-01/qualified/registry.json',recovery_profile_policy=adaptive,**kwargs)
    engine.save(out/'receipt.json',receipt)
    names=subprocess.check_output(['git','ls-files','tools/serve_recovery','tools/serve_service','tools/serve_ops','tools/serve_gateway','tools/evalscope','tools/examples','tools/serve_responses','src/service','include/q4t/service'],cwd=ROOT,text=True).splitlines()
    names += [str(Path(__file__).resolve().relative_to(ROOT)),'docs/SERVE_MEMORY_STOP_2026-11-03.md','tests/fixtures/file_video/transition-vp8.webm']
    plan=dict(version=1,scenario='adaptive_profiles',limits=LIMITS,package=receipt,output=str(out),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),sources={n:engine.sha(ROOT/n) for n in names},protected=[dict(path=str(ROOT/n),sha256=engine.sha(ROOT/n)) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json']],pressure=BASE['PRESSURE'],profile_policy=adaptive,requests=requests(),planned=dict(starts=3,self_checks=3,max_requests=12,media_requests=3,tool_executions=1),default_replacement=False,sequence=['primary actual video and stored tool call, beta quota', 'actual bounded RAM pressure, preserve control tree and durable quota', 'light frozen-video continuation, actual tool result once', 'automatic primary restoration, same-video SSE and ordinary Chat', 'durable stop, own tree/ports/flock cleanup'],automatic_request_or_tool_replay=False,command=[sys.executable,'-B',str(Path(__file__).resolve()),'run','--plan',str(out/'plan.json')])
    save(out/'plan.json',plan);print(json.dumps(dict(package=receipt['manifest_sha256'],plan=str(out/'plan.json'),limits=LIMITS)))

class Stage(BASE['Stage']):
    def media(self,label,body):
        from tools.serve_responses import video_acceptance as video
        raw=self.request(label,body,path='/v1/responses',model_work=True,raw_result=True)
        if body.get('stream'):
            events=[json.loads(line[6:]) for line in raw.decode().splitlines() if line.startswith('data: {')]
            self.engine.require(events and events[-1]['type']=='response.completed' and [e['sequence_number'] for e in events]==list(range(len(events))),'media stream order/terminal differs')
            for event in events:self.engine.require(not video.background.wire_errors(event,'response_event'),'media event schema')
            value=events[-1]['response']
        else:value=json.loads(raw)
        video.color_answer(value);return value
    def capabilities(self,label,mtp):
        caps=self.request(label,path='/v1/capabilities')
        self.engine.require(caps['runtime']['mtp_enabled'] is mtp and caps['runtime']['media_enabled'] and caps['file_inputs']['native_video']['model_media_enabled'] and caps['embeddings']['native_backend']['enabled'],'media/embedding capability lost')
        return caps
    def exercise(self):
        from tools.serve_recovery import profile_evidence,profile_contract
        first=self.ready(1,'primary');caps=self.capabilities('primary-caps',True)
        clip=self.media('primary-video',self.plan['requests']['media'])
        saved=self.request('stored-video',path='/v1/responses/'+clip['id'])
        call=self.chat('primary-tool',dict(self.plan['requests']['tool'],store=True))
        message=profile_evidence.message(call,'tool_calls');calls=message['tool_calls']
        document='docs/SERVE_MEMORY_STOP_2026-11-03.md'
        self.engine.require(len(calls)==1 and calls[0]['function']['name']=='project_document' and json.loads(calls[0]['function']['arguments'])==dict(path=document),'tool request differs')
        source=dict(path=document,content=(ROOT/document).read_text());digest=self.engine.sha(ROOT/document)
        self.engine.require(digest==self.plan['sources'][document],'source changed')
        reply=dict(role='tool',tool_call_id=calls[0]['id'],content=json.dumps(dict(path=document,sha256=digest,answer=digest[:12])))
        save(self.output/'tool-execution.json',dict(executions=1,source=source,reply=reply))
        beta=copy.deepcopy(self.plan['requests']['schema']);answer=self.chat('beta-before',beta,client='beta')
        self.engine.require(json.loads(profile_evidence.message(answer,'stop')['content'])==dict(answer=42),'beta business failed')
        self.chat('beta-limit-before',beta,client='beta',expected=429);beta_at=time.monotonic()
        self.start_pressure()
        closed=self.wait(lambda s:not s['business_ready'] and (s['controller_health'].get('reason')=='qualified_profile_switch' or s['model_generation']>1 or s['model_pid'] is None),seconds=90)
        save(self.output/'pressure-transition.json',closed);self.request('recovering-models',expected=503);self.release_pressure()
        light=self.ready(2,'light')
        self.engine.require(all(first[k]==light[k] for k in ['guardian_pid','controller_pid','gateway_pid']),'control tree replaced')
        light_caps=self.capabilities('light-caps',False);profile_contract.capability_pair(caps,light_caps)
        elapsed=time.monotonic()-beta_at
        if elapsed<59:self.chat('beta-limit-after',beta,client='beta',expected=429)
        save(self.output/'quota-window.json',dict(elapsed_seconds=elapsed,denial_checked=elapsed<59,exact_durable_handoff=True))
        usage=self.family('usage');inherited=next(c for c in usage['snapshot']['clients'] if c['id']=='beta')
        self.engine.require(int(inherited['admitted'])>=1 and int(inherited['rpm_rejected'])>=1,'quota lost')
        self.engine.require(self.request('restored-video',path='/v1/responses/'+clip['id'])['output']==saved['output'],'stored visual output lost')
        stored=self.request('restored-tool',path='/v1/chat/completions/'+call['id'])
        self.engine.require(stored['choices']==call['choices'],'stored tool call lost')
        follow=copy.deepcopy(self.plan['requests']['media_follow']);follow['previous_response_id']=clip['id']
        second=self.media('light-video',follow)
        tool=copy.deepcopy(self.plan['requests']['tool']);tool['tool_choice']='none';tool['messages'] += [message,reply]
        result=self.chat('light-tool-result',tool)
        self.engine.require(digest[:12] in profile_evidence.message(result,'stop')['content'],'actual tool result not consumed')
        primary=self.ready(3,'primary')
        self.engine.require(all(first[k]==primary[k] for k in ['guardian_pid','controller_pid','gateway_pid']),'promotion replaced control tree')
        self.engine.require(self.capabilities('promoted-caps',True)==caps,'promoted capabilities differ')
        final=copy.deepcopy(self.plan['requests']['media_follow']);final.update(previous_response_id=second['id'],stream=True,stream_options=dict(include_obfuscation=False))
        self.media('promoted-video-sse',final)
        ordinary=dict(model='qwen3.8-flash-next',temperature=0,enable_thinking=False,max_completion_tokens=32,messages=[dict(role='user',content='What is 17+25? Reply with the number only.')])
        value=self.chat('promoted-ordinary',ordinary)
        self.engine.require(profile_evidence.message(value,'stop')['content'].strip()=='42','ordinary business not recovered')
        profiles=self.family('profiles');save(self.output/'final-profiles.json',profiles)
        self.engine.require(profiles['selected']=='primary' and profiles['pending'] is None and [h['reason'] for h in profiles['history']]==['sustained_memory_pressure','sustained_memory_recovery'] and profiles['completed_generation']==3,'automatic transition history differs')
        save(self.output/'business-final.json',dict(status='PASS',profiles=profiles,actual_visual_stages=3,frozen_media_preserved=True,media_sse_after_promotion=True,actual_tool_executions=1,no_tool_or_request_replay=True,stored_call_preserved=True,quota_preserved=True,control_tree_unchanged=True))

def main():
    os.umask(0o077);p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run','launcher','controller','pressure']);p.add_argument('--plan',type=Path);p.add_argument('--config',type=Path);p.add_argument('--output',type=Path);p.add_argument('--port',type=int,default=18190);p.add_argument('--release-fd',type=int);p.add_argument('--pressure-config');args=p.parse_args()
    if args.mode=='prepare':prepare(args);return 0
    if args.mode=='pressure':return BASE['pressure'](args.output,args.release_fd,json.loads(args.pressure_config))
    plan=json.loads(args.plan.read_text())
    if args.mode=='launcher':return BASE['launcher'](plan,args.plan)
    if args.mode=='controller':BASE['controller_actor'](plan,args.config);return 0
    from tools.release.release import child_subreaper
    with child_subreaper():return Stage(plan,args.plan).run()
if __name__=='__main__':raise SystemExit(main())

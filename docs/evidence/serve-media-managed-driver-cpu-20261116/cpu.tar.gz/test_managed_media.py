"""Validation wrapper CPU negatives; no real model action."""
import copy,json,os,runpy,subprocess,sys,tempfile,unittest
from pathlib import Path
FILE=Path(__file__).with_name('managed_media.py');STAGE=runpy.run_path(str(FILE));W=FILE.parent;ROOT=W.parents[1]
class DriverTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=W);self.addCleanup(self.temp.cleanup);self.path=Path(self.temp.name)
    def helper(self,closed):
        reader,writer=os.pipe2(os.O_CLOEXEC)
        if closed:os.close(writer)
        try:
            result=subprocess.run([sys.executable,'-I','-B',str(FILE),'pressure','--output',str(self.path/'pressure.json'),'--release-fd',str(reader),'--pressure-config',json.dumps(dict(target_mib=2,floor_mib=1,max_mib=8,chunk_mib=1,seconds=3))],pass_fds=(reader,),capture_output=True,text=True,timeout=7)
        finally:
            os.close(reader)
            if not closed:os.close(writer)
        self.assertEqual(result.stderr,'');return result.returncode,json.loads((self.path/'pressure.json').read_text())
    def test_actual_owner_eof_releases_pressure(self):
        code,row=self.helper(True);self.assertEqual(code,0);self.assertEqual(row['allocated_bytes'],0);self.assertTrue(row['all_owned_pages_released'])
    def test_actual_pressure_has_allocation_bound(self):
        code,row=self.helper(False);self.assertEqual(code,2);self.assertEqual(row['allocated_bytes'],8*1024**2);self.assertTrue(row['all_owned_pages_released'])
    def test_predispatch_budget_refuses_each_exhausted_action(self):
        limits=STAGE['LIMITS'];self.assertEqual(limits,dict(starts=3,chats=12,probes=0,controls=4000,seconds=900))
        budget=STAGE['LEGACY']['Budget'](self.path,initialize=True,limits=limits)
        for kind in ['starts','chats','probes']:
            for _ in range(limits[kind]):budget.reserve(kind,'CPU_ONLY')
            with self.assertRaises(RuntimeError):budget.reserve(kind,'MUST_NOT_DISPATCH')
    def test_sealed_media_package_and_controller_wrappers_are_actually_used(self):
        script='''import runpy,sys
from pathlib import Path
v=runpy.run_path(sys.argv[1]);pkg=Path(sys.argv[2])
v['LEGACY']['load_modules'](dict(package=dict(package=str(pkg))))
from tools.serve_recovery import bundle,controller,profile_runtime,profile_evidence
from tools.serve_service import package,capacity
m=bundle.verify(pkg,package.sha(pkg/'manifest.json'))
assert m['recovery_profiles']['profiles']['primary']['allow_media'] is True
for module in [controller,profile_runtime,profile_evidence,capacity]:
 assert Path(module.__file__).resolve().is_relative_to(pkg/'source')
for f in [v['BASE']['launcher'],v['BASE']['controller_actor'],v['BASE']['Stage'].start_pressure,v['BASE']['Stage'].run]:
 assert Path(f.__globals__['__file__']).resolve()==Path(sys.argv[1]).resolve()
print('PASS_SEALED_MEDIA_CONTROL')
'''
        result=subprocess.run([sys.executable,'-I','-B','-c',script,str(FILE),str(W/'package-01/bundle')],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr);self.assertEqual(result.stdout,'PASS_SEALED_MEDIA_CONTROL\n')
if __name__=='__main__':unittest.main()

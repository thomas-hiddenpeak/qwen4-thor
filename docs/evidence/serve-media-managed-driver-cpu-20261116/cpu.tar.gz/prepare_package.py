"""Seal accepted joint media engine and actual profiles; managed recovery pending."""
import copy,hashlib,os,runpy,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'package-01'
B=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD=(ROOT/'build/service').resolve(strict=True)
P=W/'profiles-01'
helpers=runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))

def copy_file(src,dst):
    dst.parent.mkdir(mode=0o700,parents=True,exist_ok=True);shutil.copyfile(src,dst)

def main():
    os.umask(0o077)
    p.require(not OUT.exists(),'preserve previous package')
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'reviewed sources need commit')
    protected={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json']}
    original=bundle.verify(OLD,p.sha(OLD/'manifest.json'));old_metadata=p.read(OLD/'engine/q4t.release.json')
    base=p.read(OLD/'engine/manifest.json');plan=p.read(P/'plan.json');qualification=p.read(P/'acceptance.json')
    actual=p.read(ROOT/'docs/evidence/serve-managed-vision-business-20261116/acceptance.json')
    p.require(qualification['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and qualification['environment']['cleanup_complete'],'qualification absent')
    p.require(actual['status']=='ACCEPT_MANAGED_JOINT_VISION_BUSINESS' and actual['cleanup_complete'],'joint business absent')
    runtime=helpers['source_hashes']();compiled=p.read(B/'generated/q4t/server/chat_protocol_sources.json');runtime.update(compiled)
    p.require(all(p.sha(ROOT/n)==h for n,h in runtime.items()),'runtime changed')
    p.require(all(plan['sources'].get(n,compiled.get(n))==h for n,h in runtime.items()),'qualified runtime differs')
    p.require(p.sha(B/'q4t')==actual['binary_sha256']==plan['binary_sha256'],'accepted engine differs')
    previous=p.read(old_metadata['tested_source_manifest']);delta={n for n,h in runtime.items() if previous.get(n)!=h}
    allowed={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','cmake/HostTestSources.cmake','cmake/NativeDocuments.cmake','cmake/NativeVideo.cmake','src/main.cpp'}
    p.require(all(n.startswith(('src/server/','include/q4t/server/')) or n in allowed for n in delta),'unreviewed numerical/runtime delta')
    control={n for n in bundle.SOURCES if p.sha(ROOT/n)!=p.sha(OLD/'source'/n)}
    p.require(control=={'tools/serve_ops/contracts.py','tools/serve_recovery/profile_contract.py','tools/serve_recovery/profile_evidence.py','tools/serve_recovery/profile_migration.py','tools/serve_service/capacity.py','tools/serve_service/package.py','tools/serve_service/supervisor.py'},'control delta differs')
    old_native=p.read(OLD/'native-build.json');native_delta={n for n,h in old_native['source_files'].items() if p.sha(ROOT/n)!=h}
    p.require(native_delta=={'CMakeLists.txt'},'unexpected native source delta')
    built=p.read(W/'native-build-01.json')
    p.require(built['exit_code']==0 and built['default_unchanged'] and 'warning:' not in (W/'native-build-01.stderr').read_text()+(W/'native-build-01.stdout').read_text(),'native build failed/warned')
    native=dict(version=1,source_repository=str(ROOT),source_files={n:p.sha(ROOT/n) for n in sorted(bundle.NATIVE_SOURCES)})
    same={}
    for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),('ingress','q4t-ingress'),('device_control','q4t-device-control')]:
        native[field+'_sha256']=p.sha(B/name);same[name]=p.sha(B/name)==p.sha(OLD/'bin'/name)
    p.require(all(same.values()),'native helper bytes changed')
    native['reuse_review']=dict(previous=str(OLD/'native-build.json'),sha256=p.sha(OLD/'native-build.json'),changed_sources=sorted(native_delta),executable_hashes_identical=same,current_build_result=str(W/'native-build-01.json'),current_build_result_sha256=p.sha(W/'native-build-01.json'),rationale='CMake adds isolated native software-video worker to model/host targets; all four native service executables byte-identical. Reuse actual native ingress/guardian/device acceptance.')
    OUT.mkdir(mode=0o700);engine=OUT/'engine'
    for n in ['q4t','CMakeCache.txt']:copy_file(B/n,engine/n)
    (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
    protocol=hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
    caps=p.read(P/'primary-capabilities.json');config=p.read(P/'primary-config.json')
    p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,'actual declaration differs')
    decision=dict(status='PASS_NATIVE_MANAGED_MEDIA',acceptance='ACCEPT_NATIVE_MANAGED_MEDIA',binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,source_commit=plan['source_commit'],actual_joint_business=actual,profile_qualification=qualification,source_delta=sorted(delta),control_delta=sorted(control),full_model_quality=False,performance_acceptance=False,managed_recovery_pending=True,default_changed=False,remaining_master_tasks_open=True,external_provider_accounts_accepted=False,reused_video_business='docs/evidence/serve-video-business-20261116/acceptance.json',cpu_contracts=['docs/evidence/serve-managed-vision-cpu-20261116/README.md','docs/evidence/serve-media-profile-contract-cpu-20261116/README.md'])
    p.save(OUT/'decision.json',decision)
    metadata=copy.deepcopy(old_metadata)
    metadata.update(version='serve-native-managed-media-20261116',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],acceptance=decision['acceptance'],acceptance_decision=str(OUT/'decision.json'),acceptance_decision_sha256=p.sha(OUT/'decision.json'),build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),tested_source_manifest=str(engine/'runtime-source.json'),tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),previous_release=str(OLD/'engine/q4t.release.json'),inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),sha256=p.sha(OLD/'engine/q4t.release.json')),source_note='Actual primary/light native visual and text/tool/embedding business accepted. Joint text MTP with per-visual-request target decoding. Real MP4/WebM resources, original frame intervals and frozen prepared-source adapters verified; provider adapters have CPU contracts, actual cloud-account business remains pending. Native service executables byte-identical. Managed recovery and release pending; no full quality/performance claim.')
    metadata.pop('mcp_acceptance',None);metadata['media_acceptance']=decision
    declarations=engine/'declarations';declarations.mkdir(mode=0o700)
    p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
    metadata['chat_protocol'].update(caps,protocol_sha256=protocol,declaration_evidence='Actual exact joint media/text business and media primary/light qualification; cloud-account and managed recovery acceptance not inferred.')
    for name,stem in helpers['SCHEMAS'].items():
        source=ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'));target=declarations/'schemas'/(name+'.json');copy_file(source,target)
        metadata['chat_protocol'][name+'_schema']=str(target);metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
    metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,directory=str(declarations),binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,files={n:p.sha(declarations/n) for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
    for src in (ROOT/'third_party/licenses').rglob('*'):
        if src.is_file():copy_file(src,engine/'licenses'/src.relative_to(ROOT/'third_party/licenses'))
    metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output');metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
    notices=metadata['file_input_system_dependencies']
    for name in ['libgstreamer1.0-0','libgstreamer-plugins-base1.0-0','gstreamer1.0-plugins-base','gstreamer1.0-plugins-good','gstreamer1.0-plugins-bad','libopenh264-7','libvpx9']:
        path=Path('/usr/share/doc')/name/'copyright';p.require(path.is_file(),'missing actual system notice: '+name)
        notices[name]=dict(path=str(path),sha256=p.sha(path),artifact=str(path),redistributed_binary=False,scope='optional isolated CPU video worker; no core startup dependency')
    for name,record in notices.items():
        source=Path(record['artifact']);p.require(p.sha(source)==record['sha256'],'notice changed');target=engine/'licenses/system'/name;copy_file(source,target);record['artifact']=str(target)
    clients=metadata['client_artifacts']
    for n in clients['files']:copy_file(ROOT/n,OUT/'clients'/n);clients['files'][n]=p.sha(ROOT/n)
    clients['directory']=str(OUT/'clients')
    p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True);p.save(OUT/'native-build.json',native)
    kwargs={key:OLD/'engine'/n for key,n in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json')] if (OLD/'engine'/n).is_file()}
    settings=base['settings'];selected=p.read(W/'media-capacity.json')
    receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',base['model_dir'],B/'q4t-guardian',B/'q4t-cuda-probe',None,OLD/'gateway-policy.json',OLD/'engine/client-policy.json',OUT/'bundle',native_receipt=OUT/'native-build.json',native_ingress=B/'q4t-ingress',device_control=B/'q4t-device-control',capacity_config=selected,application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},embedding_model_dir=Path(settings['native_embedding']['directory']),recovery_profiles=P/'qualified/registry.json',recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
    p.save(OUT/'receipt.json',receipt)
    expected=copy.deepcopy(settings);expected['profile']=plan['profiles']['primary']
    p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==expected,'unrelated settings changed')
    p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
    p.save(OUT/'prepare-review.json',dict(previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),package_sha256=receipt['manifest_sha256'],runtime_source_sha256=runtime,runtime_delta=sorted(delta),control_source_sha256={n:p.sha(ROOT/n) for n in sorted(control)},native_source_delta=sorted(native_delta),native_executables_identical=same,capacity_change=plan['explicit_capacity'],new_gpu_starts=0,default_changed=False,managed_recovery_pending=True))
    print(receipt['manifest_sha256'])
if __name__=='__main__':main()

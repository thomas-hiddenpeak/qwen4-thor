"""Offline actual-command audit. Original finalizer failure remains immutable."""
import copy,json,runpy,shutil,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_service.package import read,save,sha,require
B=W/'recovery-retained-02';plan=read(B/'plan.json');guard=read(B/'lease/exit.json')
actual=['python3','-B','tools/serve_realtime/duplex_service_acceptance.py','run','--plan',str((B/'plan.json').relative_to(R))]
planned=[sys.executable,'-I','-B',str(R/'tools/serve_realtime/duplex_service_acceptance.py'),'run','--plan',str(B/'plan.json')]
require(guard['command']==actual and plan['command']==planned and read(B/'finalize-original.json')['returncode']==1,'unexpected command or original failure')
manifest=read(Path(plan['package']['package'])/'manifest.json');require(sha(shutil.which('python3'))==manifest['python']['sha256'] and sha(sys.executable)==manifest['python']['sha256'],'current interpreter does not match sealed identity')
queries=[json.loads(l) for l in (B/'lease/nvml-queries.jsonl').read_text().splitlines()];require(all(not q['observed_errors'] for q in queries),'NVML error')
review=dict(original_planned_command=planned,actual_guard_command=actual,original_finalize_failed=True,original_plan_sha256=sha(B/'plan.json'),guard_sha256=sha(B/'lease/exit.json'),same_explicit_driver_and_plan=True,current_interpreter_matches_sealed_identity=True,isolated_python_flag_used=False,claim='Actual native service, driver source hashes, strict NVML lease, process identity and cleanup are checked. This does not claim the planned isolated Python flag was used.',new_gpu_starts=0)
save(B/'command-variant-review.json',review)
p=runpy.run_path(str(R/'tools/serve_realtime/duplex_service_acceptance.py'));g=p['BASE']['main'].__globals__;original=g['accepted_run']
def accepted(current,result,observed,queries,events):
 require(current==plan and observed==guard,'offline actual source changed')
 value=original(dict(current,command=actual),result,observed,queries,events)
 value.update(actual_command_review=dict(path=str(B/'command-variant-review.json'),sha256=sha(B/'command-variant-review.json')),planned_command_used=False,model_quality_status=read(B/'execution/media-usage.json')['model_quality_status'],actual_duplex_receipt_sha256=sha(B/'execution/media-usage.json'))
 return value
g['accepted_run']=accepted
g['finalize'](B/'plan.json')

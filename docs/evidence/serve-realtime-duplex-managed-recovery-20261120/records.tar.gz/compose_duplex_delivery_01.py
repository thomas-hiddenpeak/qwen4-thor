"""Compose actual duplex recovery while retaining every original failure."""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from tools.serve_service.package import read, save, sha, require
from tools.serve_recovery import bundle, version_contract, profile_record, profile_evidence
from tools.serve_realtime import duplex_managed
from tools.serve_responses import encryption_acceptance as encrypted

require(not (W/'publication-composition.json').exists(), 'preserve composition')
roots = {k:read(W/n/'receipt.json') for k,n in
         [('candidate','service-package-01'),('retained','retained-01')]}
roots = {k:{n:v[n] for n in ('package','manifest_sha256')} for k,v in roots.items()}
qualification = read(W/'composed-profiles-01/acceptance.json')
require(qualification['status'] == 'ACCEPT_COMPOSED_DUPLEX_PRIMARY_LIGHT',
        'actual qualification missing')
for root in roots.values():
    manifest = bundle.verify(root['package'],root['manifest_sha256'])
    for name in ('primary','light'):
        path = Path(root['package'])/('profile-'+name+'.json')
        profile_evidence.validate(profile_record.read(path),
                                  manifest['recovery_profiles'],name,sha(path))
accepted = {k:read(W/n/'decision.json') for k,n in
            [('candidate','recovery-version-01'),('retained','recovery-retained-02')]}
for key,name in [('candidate','recovery-version-01'),('retained','recovery-retained-02')]:
    receipt = {k:dict(path=str(W/name/f),sha256=sha(W/name/f)) for k,f in
               [('release','service-release.json'),('decision','decision.json')]}
    version_contract.accepted_fallback(receipt,version_contract.payload(roots[key]))
    require(accepted[key]['engine_binary_sha256'] ==
            'ecd6cc23bd768a81e3fbd3fd1e59543176dc329e2ae7c8378956f09ffafe5580',
            'actual accepted engine differs')
processes = encrypted.foreground.base.lifecycle.guard.processes()
rows = []
for name in ('recovery-retained-01','recovery-retained-02',
             'recovery-tls-01','recovery-version-01'):
    path = W/name
    result = read(path/'execution/result.json')
    guard = read(path/'lease/exit.json')
    events = [json.loads(s) for s in (path/'lease/events.jsonl').read_text().splitlines()]
    queries = [json.loads(s) for s in (path/'lease/nvml-queries.jsonl').read_text().splitlines()]
    original = name == 'recovery-retained-01'
    require(result['status'] == ('FAILED' if original else 'PASS_BOUNDED_FEATURE_SERVICE')
            and guard['status'] == ('COMMAND_FAILED' if original else 'COMPLETED')
            and guard['compute_backend'] == 'nvml' and guard['lease_inherited_by_child']
            and queries and all(q['status']=='OK' and q['returncode']==0 and
                not q['observed_errors'] for q in queries)
            and not any(e.get('conflicts') for e in events)
            and events[-1]['event']=='lease_released', 'actual environment differs: '+name)
    require(result['cleanup_failure'] is None,'managed cleanup failed')
    stop = read(path/'execution/stopped-ledger.json')
    require(stop['desired']=='STOPPED' and stop['active']==dict(
        controller=None,gateway=None,model=None), 'managed roles remain')
    require(not any(processes.get(v['pid'],{}).get('start_ticks')==v['start_ticks']
                    for v in result['models'].values()), 'owned process remains')
    if original:
        observed = duplex_managed.check_session(
            read(path/'execution/primary-duplex.sdk.json'), 'complete', 'ws-loopback',
            duplex_managed.journal(path/'execution','primary-duplex'))
        quality = dict(model_quality_status=observed['model_quality_status'],
                       original_final_metrics_missing=True,
                       quality=observed['quality'])
        require(quality['model_quality_status']=='FAIL','original wrong answer lost')
        finalizer = None
    else:
        quality = read(path/'execution/media-usage.json')
        finalizer = dict(path=str(path/'decision.json'),sha256=sha(path/'decision.json'))
        require(read(path/'decision.json')['actual_business']['result_sha256']==
                sha(path/'execution/result.json'), 'finalizer result drift')
    rows.append(dict(name=name,raw_status=result['status'],guard_status=guard['status'],
        result_sha256=sha(path/'execution/result.json'),
        guard_sha256=sha(path/'lease/exit.json'),
        counts={k:result['budget']['counts'][k] for k in
                ('starts','chats','websocket_sessions','probes')},
        nvml_queries=len(queries),strict_lease_seconds=events[-1]['monotonic']-events[0]['monotonic'],
        model_quality=quality,finalizer=finalizer))
totals = {k:sum(v['counts'][k] for v in rows) for k in
          ('starts','chats','websocket_sessions','probes')}
seconds = sum(v['strict_lease_seconds'] for v in rows)
require(totals == dict(starts=6,chats=21,websocket_sessions=7,probes=1)
        and seconds < 1200, 'cumulative frozen scope exceeded')
require(rows[2]['model_quality']['model_quality_status']=='FAIL',
        'original TLS model quality failure lost')
review = W/'recovery-retained-02/command-variant-review.json'
require(read(review)['isolated_python_flag_used'] is False,
        'must not claim planned isolated argv was used')
prior = R/'.q4t-work/serve-realtime-audio-20261120/publication-composition.json'
value = dict(status='ACCEPT_NATIVE_REALTIME_DUPLEX_SERVICE_COMPOSITION',
    binary_sha256=accepted['candidate']['engine_binary_sha256'],
    protocol_sha256='f0c82ef97660964b63fb5a245a151af98d667b43478f1c367364db7df8ac5f11',
    candidate=roots['candidate'],automatic_fallback=roots['retained'],
    modern_retained_root=roots['retained'],stages=rows,
    actual_model_starts=totals['starts'],service_work_items=totals['chats'],
    websocket_sessions=totals['websocket_sessions'],device_probes=totals['probes'],
    service_seconds=seconds,nvml_queries=sum(v['nvml_queries'] for v in rows),
    nvml_all_ok=True,cleanup_complete=True,original_driver_failure_preserved=True,
    original_final_metrics_missing=True,model_quality_status='FAIL',
    original_model_quality_failures_preserved=True,model_quality_repaired=False,
    retained_actual_command_review=dict(path=str(review),sha256=sha(review)),
    tls_composition=dict(path=str(W/'recovery-tls-01/decision.json'),
        sha256=sha(W/'recovery-tls-01/decision.json'),
        media_usage_sha256=sha(W/'recovery-tls-01/execution/media-usage.json'),
        model_quality_status='FAIL',planned_command_used=True),
    candidate_service_acceptance=accepted['candidate'],
    modern_service_acceptance=accepted['retained'],
    primary_light_evidence=dict(path=str(W/'composed-profiles-01/acceptance.json'),
        sha256=sha(W/'composed-profiles-01/acceptance.json')),
    unchanged_backend_recovery_source=dict(path=str(prior),sha256=sha(prior),
        scope='Exact source-reviewed unchanged backend and speech recovery; newly affected duplex ownership and accounting verified separately'),
    candidate_whole_package_gpu_run=True,default_unchanged=True,publication_pending=True,
    older_engine_fallback=False,full_model_quality=False,performance_claim=False,
    all_master_tasks_complete=False,listening_deferred=True)
save(W/'publication-composition.json',value)
print(json.dumps(dict(status=value['status'],counts=totals,seconds=seconds,
    nvml_queries=value['nvml_queries'],model_quality_status=value['model_quality_status'])))

"""Publish immutable raw recovery receipts and explicit quality failures."""
import json
import subprocess
import sys
import tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_service.package import read,sha,require
O=R/'docs/evidence/serve-realtime-duplex-managed-recovery-20261120'
require(not O.exists(),'preserve published evidence'); O.mkdir()
save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
value=read(W/'publication-composition.json')
require(value['status']=='ACCEPT_NATIVE_REALTIME_DUPLEX_SERVICE_COMPOSITION'
        and value['model_quality_status']=='FAIL','wrong composition')
paths=[W/'publication-composition.json',W/'duplex-recovery-scope-01.json',
       W/'duplex-recovery-scope-02.json',W/'compose_duplex_delivery_01.py',
       W/'finalize_retained_02_command_review.py',
       W/'finalize_retained_02_command_review_original.py',Path(__file__)]
for name in ('recovery-retained-01','recovery-retained-02','recovery-tls-01',
             'recovery-version-01'):
    d=W/name
    paths += [p for p in d.iterdir() if p.is_file()]
    paths += [p for p in (d/'lease').iterdir() if p.is_file()]
    paths += [p for p in (d/'execution').iterdir() if p.is_file()
              and p.name not in ('initialized.json','wrapper.json','wrappers.json','budget.lock')]
for name in ('service-package-01','retained-01','tls-package-01'):
    paths += [p for p in (W/name).iterdir() if p.is_file() and p.suffix=='.json']
rows=[]
with tarfile.open(O/'records.tar.gz','w:gz') as t:
    for p in sorted(set(paths)):
        name=str(p.relative_to(W));t.add(p,arcname=name,recursive=False)
        rows.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
save(O/'index.json',dict(records=rows,archive_sha256=sha(O/'records.tar.gz')))
save(O/'acceptance.json',dict(value,source_commit_before_snapshot=
    subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()))
(O/'README.md').write_text('''# 原生双向音频恢复：协议通过，模型质量失败独立保留

2026-11-20。保留包、TLS入口/控制器和整包回退均已使用真实ASR与
同会话回答验收。累计包含原失败在内6次模型启动、21项原生工作、
7次连接、1次设备探测，严格租约353.339秒，332次NVML查询正常；
各组所属进程、端口及GPU锁均已清理。默认rev376此时仍STOPPED且未变。

| 组 | 实际范围 | 恢复/协议 | 模型回答质量 |
|---|---|---|---|
| 原保留包 | 1模型/3工作/1连接 | 原字段检查失败；缺少最终metrics，不追认结算 | FAIL，原无关拒答完整保留 |
| 保留包补验 | 1模型/3工作/1连接 | 268 tokens结算及清理通过 | PASS |
| TLS/控制器 | 2模型/9工作/3连接 | 入口恢复保留健康核心；控制器恢复等满配额窗口 | 三次回答PASS/FAIL/PASS |
| 整包回退 | 2模型/6工作/2连接/1探测 | 真正切换已验控制包，输入能力与profile历史保留 | 两次回答PASS/FAIL |

TLS在公开ASR增量出现、输入尚未commit时中断；已结算386 tokens并
记录一次abort。恢复连接的287 tokens和控制器恢复后的271 tokens
均独立核对。整包回退使用同一已修复引擎及双向能力、已验旧控制器；
不是回退到不支持音频输入的旧引擎。新连接由客户端明确发起，没有
自动重放请求、工具结果或中断音频。

所有错误回答与原CPU/驱动失败继续保留。用户允许将模型指令不遵循
单列质量；本次接受的是音频实际处理、历史、终态、所有权与结算，
不声称模型质量已修复。实际ASR内容检查仍然严格，未改服务采样和
默认值，也未反复抽样寻找正确回答。

保留包补验的首次离线finalizer因实际命令与计划argv不同而失败：
实际使用同一python/驱动/plan，但没有计划中的-I。原计划与guard
未改，另有明确命令审查，不能声称使用了隔离Python。审查脚本初版
又因提前导入本地包被封包加载器拒绝，原脚本保留；修正只改变离线
加载顺序，未重跑GPU。TLS和整包组使用计划的精确argv，标准finalizer
通过。各次实际来源、解释器身份、严格NVML与清理单独核对。

受影响恢复已通过，继续可回退STOPPED交付、主线合入与全部master。
无完整模型质量、性能或长稳通过主张；听感待验项保留。

[接受记录](acceptance.json)、[原件索引](index.json)、[全部原件](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认')
p.write_text(s[:i]+'''
[双向原生恢复已验](evidence/serve-realtime-duplex-managed-recovery-20261120/README.md)：
包含原失败累计6模型/21工作/7连接/1探测/353.339秒，332NVML正常、
清理通过。TLS故障保留健康核心，控制器恢复等满配额窗口，整包回退
保留双向输入与profile历史。原模型质量FAIL、缺失最终metrics和命令
不一致均明确保留；实际命令另审查，不追认计划argv。接着可回退
STOPPED发布与main合入，当前默认rev376未变，全部master继续。
''' + s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1
p.write_text(s[:i]+'''
## 双向输入真实恢复完成，独立保留模型错答

日期：2026-11-20。

做了什么：保留包、TLS/控制器与整包回退完成；累计含失败6模型、
21工作、7连接、1探测、353.339秒，332NVML正常并清理。记录入口恢复
不重启核心、控制器恢复配额等待及整包能力保留；真实错答仍FAIL。

为什么：按用户允许将模型质量与服务恢复分开核对，避免错误答案
被成功终态掩盖；原检查器、命令格式与离线加载失败全部保留。

下一步：可回退STOPPED交付及主线合入，继续全部master。

''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p)
v['realtime_progress']['duplex_input_20261120'].update(
    state='actual_managed_recovery_accepted_model_quality_failures_retained_delivery_pending',
    managed_recovery=dict(evidence=str(O.relative_to(R)/'README.md'),
        starts=6,native_work_items=21,connections=7,device_probes=1,
        strict_lease_seconds=value['service_seconds'],nvml_queries=332,
        cleanup_complete=True,model_quality_status='FAIL',
        original_failure_preserved=True,default_revision=376,master_active=True))
save(p,v)
print(json.dumps(dict(evidence=str(O),archive_bytes=(O/'records.tar.gz').stat().st_size)))

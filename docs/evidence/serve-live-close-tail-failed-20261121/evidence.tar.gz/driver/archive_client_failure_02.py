import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'client-business-02';O=R/'docs/evidence/serve-live-close-tail-failed-20261121';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
result=read(P/'result.json');cleanup=read(P/'cleanup.json');plan=read(P/'plan.json');sdk=read(P/'client.sdk.json');assert result['status']=='FAIL' and cleanup['remaining']==[] and cleanup['model_exit']==0
queries=[json.loads(v) for v in (P/'lease/nvml-queries.jsonl').read_text().splitlines()];assert all(q['status']=='OK' and q['returncode']==0 for q in queries)
actual=read(P/'live-drained.json');texts=[e for e in sdk['events'] if e['type'].endswith('transcript.delta')];assert ''.join(e['delta'] for e in texts if e['type']=='session.input_transcript.delta')=='请查询当前项目版本号。';assert any(e.get('client_event_id')=='project_answer' and e.get('delta')=='rev426' for e in texts)
files={}
for n in ['counts.json','result.json','cleanup.json','before.json','live-drained.json','fixture-before.json','fixture-drained.json','query-speech.request.json','query-speech.http.json','query-fixture.json','query.pcm','client.events.jsonl','client.sdk.json','client.stderr','model.log','lease/exit.json','lease/nvml-queries.jsonl']:
 files['original/'+n]=(P/n).read_bytes()
for n in ['include/q4t/server/live_audio_input.h','src/server/live_audio_input.cpp','include/q4t/server/realtime_conversation_input.h','include/q4t/server/realtime_transcription_session.h','src/server/realtime_transcription_session.cpp','include/q4t/server/realtime_vad.h','src/server/realtime_vad.cpp','tests/server_live_audio_input_test.cpp']:
 files['failed-source/'+n]=(R/n).read_bytes()
for p in sorted((R/'tools/serve_live').glob('*')):
 if p.is_file():files['failed-source/'+str(p.relative_to(R))]=p.read_bytes()
files['driver/archive_client_failure_02.py']=Path(__file__).read_bytes();idx={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o600;i.mtime=0;t.addfile(i,io.BytesIO(b));idx[n]=dict(sha256=sha(b),bytes=len(b))
summary=dict(status='FAIL_LIVE_CLOSE_TAIL_EXTRA_ASR',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],plan_sha256=sha((P/'plan.json').read_bytes()),actual_model_starts=1,actual_admitted_work=4,alpha_asr_frontend_admitted=3,beta_fixture_admitted=1,extra_tail_asr_rejected=True,seconds=result['seconds'],quality='ASR_QUERY_AND_PROJECT_VERSION_PASS',client_delegation=True,real_record_read_and_returned=sdk['record'],default_unchanged=True,environment_abort=False,nvml_queries=len(queries),all_nvml_queries_ok=True,cleanup_confirmed=True,main_not_delivered=True,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
(O/'index.json').write_text(json.dumps(idx,indent=2)+'\n');(O/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))

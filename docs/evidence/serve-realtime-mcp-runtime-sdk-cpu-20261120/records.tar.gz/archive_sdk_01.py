from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-mcp-runtime-sdk-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
r=read(W/'sdk-cpu-01/result.json');b=read(W/'session-runtime-01/result.json');assert r['status']=='PASS' and b['status']=='BUILD_PASS' and b['warnings']==0
for n,h in {**r['sources'],**read(W/'session-runtime-01/plan.json')['sources']}.items():assert sha(R/n)==h
files={n:W/n for n in ['archive_sdk_01.py','build_session_runtime_01.py','session-runtime-01/plan.json','session-runtime-01/result.json','session-runtime-01/build.log','sdk-cpu-01/plan.json','sdk-cpu-01/result.json','sdk-cpu-01/stdout.txt','sdk-cpu-01/stderr.txt']}
files.update({'source/'+n:R/n for n in r['sources']});O.mkdir();rows={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_MCP_RUNTIME_AND_SDK_VERIFIER_CPU',build=b,verifier_cases=10,cpu_seconds=r['seconds'],runtime_connected=True,gpu_actions=0,actual_sdk_business_pending=True,master_goal_active=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP原生运行时与SDK验收器

2026-11-20。实际运行时152.376秒构建通过、零警告。候选SHA为
`a84fda9519bdc19d20a725e9c259a74bea89c8c6e70d133876b3e2007c1ebf7b`。
构建前后的默认及旧引擎逐字节相同，GPU启动0；原生模型业务待验。

官方OpenAI 7.47.0 / ws 8.21.0驱动准备完成；独立证据校验器10项
针对性CPU通过，覆盖真实来源、单次dispatch、审批身份与顺序、
生成/工具不同终态、实际事件增量、逐token结算及资源释放。模型
质量错误独立保留，不能伪装成通过；这些CPU夹具不是真实SDK执行。

下一组冻结同一严格租约内主/轻各一次启动、共8次模型生成、2个
WSS/TLS连接、900秒。只读实际项目资料；审批通过/拒绝、导入失败、
实际读取后丢失回执及普通对话继续；不自动重试或改默认采样。
随后继续恢复与可回退交付，默认rev396保持，总目标active。

[结果](acceptance.json) · [索引](index.json) · [原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text().replace('主轻各一次启动、共8次生成/900秒业务，先冻结10项验收器CPU反例。','主轻各一次启动、共8次生成/900秒业务；[10项验收器CPU通过](evidence/serve-realtime-mcp-runtime-sdk-cpu-20261120/README.md)。');p.write_text(s)
p=R/'docs/log/2026-11-20.md';p.write_text('''## SDK证据校验10项CPU完成

日期：2026-11-20。

做了什么：[10项CPU及实际runtime构建](../evidence/serve-realtime-mcp-runtime-sdk-cpu-20261120/README.md)
原件归档，默认/旧引擎保持。校验器反例确认重放、伪造工具来源、
提前成功、错序审批、用量或资源缺失不能通过，质量失败独立记录。
官方SDK实际模型驱动尚待限定业务短验；本组0GPU。

为什么：固定客户端和验收器后再占用GPU，保留逐事件证据和实际
MCP端读取记录，避免把生成结束错误当作工具执行结束。

下一步：同一严格GPU租约推进2启动/8生成/900秒真实业务，再恢复与
发行。默认rev396 STOPPED保持，总目标active。

'''+p.read_text())
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n### 实际运行时及SDK业务冻结

[原生构建与10项CPU反例](evidence/serve-realtime-mcp-runtime-sdk-cpu-20261120/README.md)
已通过，运行时零警告。下一组同一严格GPU租约最多2次模型启动、
8次生成、2个WSS/TLS、900秒：主档直接调用/拒绝审批/导入故障，
轻档审批通过/已读后回执丢失；各自检查实际文档回答及故障后普通
对话、精确用量与清理。官方SDK，不自动重试，不扩全性能/质量矩阵。
''')
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m.update(state='native_runtime_built_sdk_verifier_cpu_accepted_bounded_business_next',runtime_build=b,sdk_verifier_cpu=dict(tests=10,status='PASS',evidence='evidence/serve-realtime-mcp-runtime-sdk-cpu-20261120/README.md'),business_budget=dict(starts=2,model_jobs=8,seconds=900,websocket_sessions=2,ingress_starts=2));save(p,d)
print(json.dumps(dict(status=a['status'],runtime_sha256=b['binary_sha256'],tests=10,gpu_actions=0)))

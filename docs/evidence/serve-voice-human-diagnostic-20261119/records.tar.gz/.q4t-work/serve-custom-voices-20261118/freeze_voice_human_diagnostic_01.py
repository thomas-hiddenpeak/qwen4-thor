from pathlib import Path
import copy,hashlib,json,shutil,wave
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-human-diagnostic-01';O.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
fixture=R/'.q4t-work/serve-diarization-20261118/voice-fixtures-01';receipt=json.loads((fixture/'receipt.json').read_text())
clips=[];pcm=[]
for row in receipt['files']:
 p=fixture/row['name'];assert sha(p)==row['sha256']
 with wave.open(str(p),'rb') as f:
  assert f.getnchannels()==1 and f.getsampwidth()==2 and f.getframerate()==16000
  data=f.readframes(f.getnframes());assert len(data)==row['samples']*2
 pcm.append(data);clips.append(dict(path=str(p),sha256=sha(p),format='wav'))
# The order is explicitly A1,A2,B1; neither original record is cropped, sped
# up, filtered, re-synthesized, or discarded. Only labelled concatenation.
names=['speaker_A_recording_1','speaker_A_recording_2','speaker_B_recording_1']
for name,a,b in [('same_A1_A2',0,1),('mixed_A1_B1',0,2),('mixed_B1_A1',2,0)]:
 p=O/(name+'.wav')
 with wave.open(str(p),'wb') as f:
  f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000)
  f.writeframes(pcm[a]+bytes(2*6400)+pcm[b])
 names.append(name);clips.append(dict(path=str(p),sha256=sha(p),format='wav'))
reference=(V/'voice-reference-diagnostic-01/reference.py').read_text()
reference=reference.replace('cases=18, seconds=180','cases=99, seconds=180').replace('assert len(rows) == 18','assert 6 < len(rows) <= 99')
ref=O/'reference.py';ref.write_text(reference)
refplan=json.loads((V/'voice-reference-diagnostic-01/plan.json').read_text())
refplan['limits']['cases']=99
refplan['identities']={p:h for p,h in refplan['identities'].items() if '/serve-custom-voices-' not in p}
refplan['identities'][str(ref)]=sha(ref);save(O/'reference-template.json',refplan)
oldcommand=json.loads((V/'voice-reference-diagnostic-01/command.json').read_text());refcommand=list(oldcommand)
refcommand[3]=str(ref)
for flag,path in [('--plan',O/'run/reference-plan.json'),('--native',O/'run'),('--output',O/'run/reference')]:refcommand[refcommand.index(flag)+1]=str(path)
old=V/'voice_identity_diagnostic_01.py';driver=old.read_text()
driver=driver.replace('clips=3,max_embeddings=99','clips=6,max_embeddings=99').replace('range(3)','range(6)').replace('require(3<len(rows)<=99','require(6<len(rows)<=99')
driver=driver.replace("  rows=read(out/'native/windows.json');", """  reference=read(Path(plan['reference_template']))
  for path in [*out.glob('decoded/case-*/pcm.f32'), *out.glob('native/embedding-*.f32'), out/'native/windows.json']:
   reference['identities'][str(path)]=sha(path)
  save(out/'reference-plan.json',reference)
  command('official-cpu',plan['reference_command'])
  reference_result=read(out/'reference/result.json')
  require(reference_result['status']=='PASS_REFERENCE_COMPUTATION' and reference_result['cuda_initialized'] is False,'official CPU numerical comparison')
  rows=read(out/'native/windows.json');""")
a="  result.update(status='DIAGNOSTIC_OBSERVED_THRESHOLD_UNCHANGED',observations=observations,aggregate_similarity=[[cosine(a,b) for b in means] for a in means],verification_threshold=.65)"
b=a+"""
  gates=read(out/'native/gates.json')
  result['actual_production_gates']=gates
  result['expected_gates']=[True,True,True,True,False,False]
  result['window_classification_matches']=all(row['accepted']==expected for row,expected in zip(gates,result['expected_gates'],strict=True))
  result['recording_pair_expectations']=[dict(first=0,second=1,same=True,cosine=cosine(means[0],means[1])),dict(first=0,second=2,same=False,cosine=cosine(means[0],means[2])),dict(first=1,second=2,same=False,cosine=cosine(means[1],means[2]))]
  result['recording_pair_matches']=all((row['cosine']>=.65)==row['same'] for row in result['recording_pair_expectations'])
  result['reference_comparisons']=len(reference_result['checks'])
  result['reference_max_relative_l2']=max(row['relative_l2'] for row in reference_result['checks'])
  result['reference_minimum_cosine']=min(row['cosine'] for row in reference_result['checks'])
  result['interpretation']='Fixed small real-speaker diagnostic, not a calibrated general verification threshold or consent acceptance'
"""
assert driver.count(a)==1;driver=driver.replace(a,b)
script=V/'voice_human_diagnostic_01.py';script.write_text(driver)
plan=json.loads((V/'voice-identity-diagnostic-01/plan.json').read_text());plan.update(schema='q4t-voice-human-identity-observation-v1',output=str(O/'run'),names=names,clips=clips,reference_template=str(O/'reference-template.json'),reference_command=refcommand)
plan['limits']['clips']=6
binary=V/'voice-human-diagnostic-build-01/q4t_voice_human_diagnostic'
build=json.loads((binary.parent/'result.json').read_text());assert build['status']=='PASS_BUILD_ONLY' and build['warnings']==0 and sha(binary)==build['binary_sha256']
plan['binaries']['speaker']=dict(path=str(binary),sha256=sha(binary))
for p in [script,old,Path(__file__),V/'prepare_voice_human_diagnostic_01.py',binary.parent/'replay.cpp',binary.parent/'plan.json',binary.parent/'result.json',ref,O/'reference-template.json',fixture/'plan.json',fixture/'receipt.json',R/'src/server/voice_verification.cpp',R/'include/q4t/server/voice_verification.h']+[Path(c['path']) for c in clips]:
 plan['sources'][str(p.relative_to(R))]=sha(p)
plan['human_diagnostic']=dict(cpu_reference_loads=1,gpu_speaker_loads=1,production_threshold_unchanged=.65,expected_gates=[True,True,True,True,False,False],same_recording_pairs=[[0,1]],different_recording_pairs=[[0,2],[1,2]],silence_between_records_samples=6400,clip_original_pcm_preserved=True)
assert shutil.disk_usage(R).free>256<<20
save(O/'plan.json',plan)
text='''冻结真人声纹诊断：复用上游已校验3录音（A两条、B一条）及完整原PCM\n构造同人拼接、两种顺序异声拼接，共6例；直接调用生产BuildVoiceIdentity，\n1GPU speaker/1CPU VAD/1官方CPU对照、≤99向量/600秒/16MiB，0主LLM/\nTTS/ASR/HTTP，0.65门不变。用于区分音色质量与核验策略，不当作授权验收。\n'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 真人同人/异声诊断冻结\n\n'+text+'\n为什么：先用独立实际录音检查现有门是否误拒绝，再决定实现方向；\n下一步：保留完整正反例结果，不根据单个合成失败放宽保护。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;write(p,s.replace(marker,marker+content,1))
print(json.dumps(dict(plan=str(O/'plan.json'),clips=len(clips),limits=plan['limits'],cpu_reference_loads=1)))

from pathlib import Path
import hashlib,json,shutil,subprocess,time,wave
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';B=V/'voice-human-diagnostic-build-01';B.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
old=V/'voice-identity-diagnostic-build-01';build=json.loads((old/'plan.json').read_text());source=(old/'replay.cpp').read_text()
source=source.replace('#include <iostream>','#include <iostream>\n#include <iomanip>\n#include "q4t/server/voice_verification.h"')
source=source.replace('cases->array.size() == 3','cases->array.size() == 6').replace('three recorded clips required','six recorded clips required').replace('clip < 3','clip < 6')
source=source.replace('  size_t row = 0;', '  std::ofstream gates(output / "gates.json");\n  gates << "[";\n  size_t row = 0;')
source=source.replace('    windows.push_back({0, pcm.size(), 0, pcm.size()});', '    windows.push_back({0, pcm.size(), 0, pcm.size()});\n    std::vector<audio::SpeakerEmbedding> clip_embeddings;')
source=source.replace('      Check(run.Finish(embedding));', '      Check(run.Finish(embedding));\n      if (index+1 < windows.size()) clip_embeddings.push_back(embedding);')
a='''    }
  }
  report << "]\\n";'''
b='''    }
    windows.pop_back();
    std::vector<float> identity{123};
    const auto status = server::BuildVoiceIdentity(windows, clip_embeddings,
                                                  pcm.size(), &identity);
    Require(status.ok() || identity == std::vector<float>{123},
            "failed identity was not atomic");
    if (status.ok()) Save<float>(output / ("identity-"+std::to_string(clip)+".f32"), identity);
    if (clip) gates << ",";
    gates << "{\\"clip\\":" << clip << ",\\"accepted\\":"
          << (status.ok() ? "true" : "false") << ",\\"reason\\":"
          << std::quoted(std::string(status.message())) << "}";
  }
  gates << "]\\n"; gates.close(); Require(gates.good(), "gate receipt");
  report << "]\\n";'''
assert source.count(a)==1;source=source.replace(a,b)
(B/'replay.cpp').write_text(source)
objects=[]
for row in build['provenance']:
 assert sha(Path(row['object']))==row['sha256'] and sha(R/row['source'])==row['source_sha256']
 objects.append(row['object'])
nv='/usr/local/cuda-13.3/bin/nvcc';binary=B/'q4t_voice_human_diagnostic'
commands=[['g++-14','-std=c++23','-O3','-Wall','-Wextra','-Werror','-ffunction-sections','-Iinclude','-c','src/server/voice_verification.cpp','-o',str(B/'gate.o')],
 [nv,'-std=c++23','-O3','-arch=sm_110a','-ccbin','g++-14','-Iinclude','-Ithird_party','-Xcompiler=-Wall,-Wextra,-Werror','-c',str(B/'replay.cpp'),'-o',str(B/'replay.o')],
 [nv,'-arch=sm_110a','-ccbin','g++-14',str(B/'replay.o'),str(B/'gate.o'),*objects,'-lcublasLt','-lpthread','-Xlinker=--gc-sections','-o',str(binary)]]
assert shutil.disk_usage(R).free>256<<20
save(B/'plan.json',dict(commands=commands,provenance=build['provenance'],sources={n:sha(R/n) for n in ('src/server/voice_verification.cpp','include/q4t/server/voice_verification.h')},derived_source_sha256=sha(B/'replay.cpp')))
start=time.monotonic()
for i,cmd in enumerate(commands):
 with (B/f'{i}.log').open('xb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 if r.returncode:break
result=dict(status='PASS_BUILD_ONLY' if r.returncode==0 else 'FAILED_BUILD',seconds=time.monotonic()-start,returncode=r.returncode,warnings=sum(p.read_text().count('warning:') for p in B.glob('*.log')))
if r.returncode==0:result['binary_sha256']=sha(binary)
save(B/'result.json',result);print(json.dumps(result));raise SystemExit(r.returncode)

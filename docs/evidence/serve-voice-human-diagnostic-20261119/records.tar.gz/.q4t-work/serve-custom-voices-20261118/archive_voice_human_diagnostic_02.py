from pathlib import Path
import fcntl,hashlib,json,shutil,tarfile
from tools.native_tts.acceptance import defaults
from tools.serve_grammar_reap import acceptance as lifecycle
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';N=V/'voice-human-diagnostic-01';C=V/'voice-human-cpu-reference-02';B=V/'voice-human-diagnostic-build-01';O=R/'docs/evidence/serve-voice-human-diagnostic-20261119';O.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def save(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
result=read(C/'result.json');plan=read(N/'plan.json');lease=read(N/'lease/exit.json');native=read(N/'run/native/result.json');original=read(N/'run/result.json')
assert result['status']=='DIAGNOSTIC_OBSERVATIONS_REFERENCE_ALIGNED' and result['window_classification_matches'] and result['recording_pair_matches']
assert lease['status']=='COMMAND_FAILED' and original['steps'][0]['returncode']==original['steps'][1]['returncode']==0 and original['steps'][2]['returncode']==1
queries=[json.loads(x) for x in (N/'lease/nvml-queries.jsonl').read_text().splitlines()];assert len(queries)==4 and all(x['status']=='OK' for x in queries) and queries[-1]['pids']==[]
events=[json.loads(x) for x in (N/'lease/events.jsonl').read_text().splitlines()];owned=[x['child_pid'] for x in events if x['event']=='child_started']+sorted({p for q in queries for p in q['pids']})
assert all(not Path('/proc',str(p)).exists() for p in owned)
with lifecycle.guard.common_lock().open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert defaults()==plan['defaults']
result.update(lease_status='COMMAND_FAILED_ORIGINAL_CPU_GUARD_RETAINED',nvml_queries=4,nvml_all_ok=True,native_seconds=native['seconds'],initial_attempt_seconds=original['seconds'],native_gpu_speaker_loads=1,cpu_reference_successful_loads=1,cpu_reference_initial_loads=0,owned_cleanup_confirmed=True,default_unchanged=True,voice_registration_http_qualified=False)
save(O/'result.json',result)
files=[V/n for n in ('prepare_voice_human_diagnostic_01.py','freeze_voice_human_diagnostic_01.py','voice_human_diagnostic_01.py','complete_voice_human_cpu_02.py','archive_voice_human_diagnostic_02.py')]
for d in (N,C,B):
 files.extend(p for p in d.rglob('*') if p.is_file() and p.suffix not in ('.o','.wav') and p.name!='pcm.f32' and not p.name.startswith('q4t_voice_'))
assert shutil.disk_usage(R).free> (256<<20)+sum(p.stat().st_size for p in files)
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files},audio_retained_locally=True,audio_sources=plan['clips']))
write(O/'README.md',f'''# 真人单说话人与异声拼接的独立诊断

复用已校验SpeechBrain固定源码c0241278f93ef02cd5191f03caf4e5f8e1292bf6
的tests/samples/ASR三条录音（A两条、B一条），完整PCM不裁剪、不变速，
另构造A1+A2、A1+B1、B1+A1，连接处固定0.4秒静音。源git blob/SHA
与构造脚本入索引；录音/解码PCM保留本机原路径，没有重新生成夹具。

实际原生VAD/ECAPA后直接调用生产BuildVoiceIdentity：三条原录音及
同人拼接通过，两份异声拼接拒绝。A两条独立录音聚合余弦0.727384，
A/B分别0.076198、-0.000257；同人拼接最低窗口对0.715105，异声拼接
分别0.071809、0.075710。当前窗口和跨录音0.65门完全保持。

1 GPU speaker/1 CPU VAD、18向量、原生{native['seconds']:.3f}秒，0主LLM/TTS/
ASR/HTTP。官方CPU从同PCM独立计算18项均对齐，最大relativeL2
{result['reference_max_relative_l2']:.9g}、最小cosine {result['reference_minimum_cosine']:.12f}。
初轮CPU因驱动未设CUDA_VISIBLE_DEVICES空值，在import torch及加载
权重前拒绝；严格租约的原COMMAND_FAILED和4次正常NVML记录保留。
仅设CPU环境并复用原GPU输出补验，{result['seconds']:.3f}秒、0新增GPU。
自有进程退出、GPU末次空闲、flock释放及默认身份确认。

结论限于这组真人正反例，不能据此声称通用阈值已校准；原ryan合成
录音低相似度及完整注册HTTP失败保持，可能涉及合成音色或核验模型
对合成音的适用性，尚无正常播放听感结论。不会用降低门槛追认成功。
总目标active，接着实际profile驱动、合适的注册业务录音与保存状态回退。
''')
p=R/'docs/serve-master-goals-v2.json';data=read(p);data['native_tts_progress']['custom_voice']['service']['human_speaker_diagnosis']=dict(evidence='evidence/serve-voice-human-diagnostic-20261119/README.md',cases=6,expected_classifications=True,numerical_comparisons=18,threshold_unchanged=.65,original_synthetic_failure_retained=True,runtime_http_qualified=False);save(p,data)
text='''[真人声纹6正反例符合预期](evidence/serve-voice-human-diagnostic-20261119/README.md)：
4单人/同人通过、2异声拒绝；独立A/A余弦0.727，A/B≤0.0762。
18原生/官方CPU向量一致，最大relativeL2 2.288e-6；门保持0.65。
初轮CPU环境检查中止保留，仅补CPU9.277秒，0重复GPU；默认保持。
原合成夹具与核验的不匹配继续待解，未将注册API或通用阈值宣布通过。
'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 真人声纹正反例及官方计算核对\n\n'+text+'\n做了什么：保留真实原录音，检查生产窗口门及跨录音同人/异声；\n为什么：合成音色失败不能直接成为放宽保护的依据；\n下一步：实际profile与保存状态闭环，合成音色适配/听感继续待验。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;write(p,s.replace(marker,marker+content,1))
print(json.dumps(dict(files=len(files),archive_bytes=(O/'records.tar.gz').stat().st_size,classification='6/6',numeric='18/18',threshold=.65)))

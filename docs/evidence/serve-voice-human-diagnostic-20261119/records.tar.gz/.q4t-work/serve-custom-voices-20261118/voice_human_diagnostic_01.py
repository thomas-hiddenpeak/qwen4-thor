from pathlib import Path
import json,math,os,struct,subprocess,sys,time,shutil,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_service.package import read,save,sha,require
from tools.native_tts.acceptance import defaults
from tools.serve_grammar_reap import acceptance as lifecycle

def run(plan):
 out=Path(plan['output']);out.mkdir(exist_ok=False);started=time.monotonic();result={'status':'FAILED','steps':[]}
 lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);lifecycle.verify_lease(lease,lifecycle.guard.common_lock())
 require(plan['limits']==dict(seconds=600,clips=6,max_embeddings=99,speaker_loads=1,vad_loads=1,main_loads=0,tts_loads=0,asr_loads=0,http_posts=0,artifact_mib=16,disk_reserve_mib=256),'frozen limits')
 require(defaults()==plan['defaults'],'default drift')
 for name,h in plan['sources'].items():require(sha(R/name)==h,'source drift '+name)
 for row in plan['binaries'].values():require(sha(row['path'])==row['sha256'],'binary drift')
 def command(name,args):
  require(time.monotonic()-started<560 and shutil.disk_usage(R).free>=256<<20,'time/disk bound')
  begin=time.monotonic()
  with (out/(name+'.log')).open('xb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,pass_fds=(lease,),timeout=min(240,max(1,560-(time.monotonic()-started))))
  result['steps'].append(dict(name=name,command=args,returncode=r.returncode,seconds=time.monotonic()-begin));save(out/'progress.json',result)
  require(r.returncode==0,'subprocess failed: '+name)
 try:
  decode=dict(schema='q4t-speech-http-decode-v1',cases=plan['clips']);save(out/'decode-plan.json',decode)
  command('decode',[plan['binaries']['decoder']['path'],'--speech-http-decode',str(out/'decode-plan.json'),str(out/'decoded')])
  cases=[]
  for i in range(6):
   p=out/f'decoded/case-{i}/pcm.f32';receipt=read(p.parent/'result.json')
   require(receipt['worker_starts']==receipt['worker_reaped']==1 and receipt['sample_rate']==16000 and receipt['decoded_sha256']==sha(p),'native decoder identity or cleanup')
   cases.append(dict(pcm=str(p),pcm_sha256=sha(p)))
  native=dict(cases=cases,vad=plan['vad']);save(out/'native-plan.json',native)
  command('native',[plan['binaries']['speaker']['path'],plan['speaker_assets'],str(out/'native-plan.json'),str(out/'native')])
  reference=read(Path(plan['reference_template']))
  for path in [*out.glob('decoded/case-*/pcm.f32'), *out.glob('native/embedding-*.f32'), out/'native/windows.json']:
   reference['identities'][str(path)]=sha(path)
  save(out/'reference-plan.json',reference)
  command('official-cpu',plan['reference_command'])
  reference_result=read(out/'reference/result.json')
  require(reference_result['status']=='PASS_REFERENCE_COMPUTATION' and reference_result['cuda_initialized'] is False,'official CPU numerical comparison')
  rows=read(out/'native/windows.json');require(6<len(rows)<=99,'embedding count')
  vectors=[]
  for row in rows:
   raw=(out/f"native/embedding-{row['row']}.f32").read_bytes();require(len(raw)==192*4,'embedding extent')
   values=struct.unpack('<192f',raw);require(all(math.isfinite(v) for v in values),'nonfinite vector')
   norm=math.sqrt(sum(v*v for v in values));require(norm>0,'empty vector');vectors.append([v/norm for v in values])
  def cosine(a,b):return sum(x*y for x,y in zip(a,b,strict=True))
  matrix=[[cosine(a,b) for b in vectors] for a in vectors];save(out/'cosines.json',matrix)
  observations=[];means=[]
  for clip in range(6):
   ids=[i for i,r in enumerate(rows) if r['clip']==clip and not r['whole']];whole=next(i for i,r in enumerate(rows) if r['clip']==clip and r['whole'])
   pairs=sorted((matrix[i][j],i,j) for pos,i in enumerate(ids) for j in ids[pos+1:])
   sums=[sum(vectors[i][d]*(rows[i]['core_end']-rows[i]['core_begin']) for i in ids) for d in range(192)];norm=math.sqrt(sum(v*v for v in sums));mean=[v/norm for v in sums];means.append(mean)
   observations.append(dict(name=plan['names'][clip],windows=len(ids),whole=whole,
    worst_pairs=[dict(cosine=c,first=rows[i],second=rows[j]) for c,i,j in pairs[:5]],
    window_to_mean=[dict(row=i,cosine=cosine(vectors[i],mean),seconds=(rows[i]['end']-rows[i]['begin'])/16000) for i in ids],
    window_to_whole=[dict(row=i,cosine=matrix[i][whole]) for i in ids]))
  result.update(status='DIAGNOSTIC_OBSERVED_THRESHOLD_UNCHANGED',observations=observations,aggregate_similarity=[[cosine(a,b) for b in means] for a in means],verification_threshold=.65)
  gates=read(out/'native/gates.json')
  result['actual_production_gates']=gates
  result['expected_gates']=[True,True,True,True,False,False]
  result['window_classification_matches']=all(row['accepted']==expected for row,expected in zip(gates,result['expected_gates'],strict=True))
  result['recording_pair_expectations']=[dict(first=0,second=1,same=True,cosine=cosine(means[0],means[1])),dict(first=0,second=2,same=False,cosine=cosine(means[0],means[2])),dict(first=1,second=2,same=False,cosine=cosine(means[1],means[2]))]
  result['recording_pair_matches']=all((row['cosine']>=.65)==row['same'] for row in result['recording_pair_expectations'])
  result['reference_comparisons']=len(reference_result['checks'])
  result['reference_max_relative_l2']=max(row['relative_l2'] for row in reference_result['checks'])
  result['reference_minimum_cosine']=min(row['cosine'] for row in reference_result['checks'])
  result['interpretation']='Fixed small real-speaker diagnostic, not a calibrated general verification threshold or consent acceptance'

  require(sum(p.stat().st_size for p in out.rglob('*') if p.is_file())<=16<<20,'artifact bound')
 except BaseException:result['error']=traceback.format_exc();raise
 finally:
  result.update(seconds=time.monotonic()-started,defaults_unchanged=defaults()==plan['defaults']);save(out/'result.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in ('observations','steps')},ensure_ascii=False),flush=True)

if __name__=='__main__':
 with lifecycle.child_subreaper():run(read(Path(sys.argv[1])))

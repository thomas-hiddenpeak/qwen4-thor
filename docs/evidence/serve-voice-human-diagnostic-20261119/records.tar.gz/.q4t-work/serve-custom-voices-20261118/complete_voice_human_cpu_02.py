from pathlib import Path
import hashlib,json,math,os,shutil,struct,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';N=V/'voice-human-diagnostic-01';O=V/'voice-human-cpu-reference-02';O.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(N/'plan.json');command=list(plan['reference_command']);command[command.index('--output')+1]=str(O/'run')
freeze=dict(reason='Original CPU reference refused missing CUDA_VISIBLE_DEVICES empty setting before loading torch; reuse actual native data, zero new GPU work',max_seconds=180,cpu_loads=1,gpu_loads=0,command=command,environment=dict(CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1'),original_failure_sha256=sha(N/'run/result.json'),native_windows_sha256=sha(N/'run/native/windows.json'),reference_plan_sha256=sha(N/'run/reference-plan.json'))
save(O/'plan.json',freeze);assert shutil.disk_usage(R).free>256<<20
started=time.monotonic()
with (O/'reference.log').open('xb') as f:run=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=180,env=dict(os.environ,**freeze['environment']))
result=dict(returncode=run.returncode,seconds=time.monotonic()-started,gpu_loads=0)
save(O/'execution.json',result);assert run.returncode==0
reference=read(O/'run/result.json');assert reference['status']=='PASS_REFERENCE_COMPUTATION' and reference['cuda_initialized'] is False
rows=read(N/'run/native/windows.json');vectors=[]
for row in rows:
 a=struct.unpack('<192f',(N/f"run/native/embedding-{row['row']}.f32").read_bytes());norm=math.sqrt(sum(x*x for x in a));vectors.append([x/norm for x in a])
def cos(a,b):return sum(x*y for x,y in zip(a,b,strict=True))
observations=[];means=[];whole=[]
for clip,name in enumerate(plan['names']):
 ids=[i for i,row in enumerate(rows) if row['clip']==clip and not row['whole']]
 w=next(i for i,row in enumerate(rows) if row['clip']==clip and row['whole']);whole.append(vectors[w])
 pairs=[cos(vectors[i],vectors[j]) for pos,i in enumerate(ids) for j in ids[pos+1:]]
 a=[sum(vectors[i][d]*(rows[i]['core_end']-rows[i]['core_begin']) for i in ids) for d in range(192)];norm=math.sqrt(sum(x*x for x in a));means.append([x/norm for x in a])
 observations.append(dict(clip=clip,name=name,windows=len(ids),minimum_window_pair=min(pairs) if pairs else None,whole_row=w))
gates=read(N/'run/native/gates.json');expected=[True,True,True,True,False,False]
pairs=[dict(first=a,second=b,same=same,aggregate_cosine=cos(means[a],means[b]),whole_cosine=cos(whole[a],whole[b])) for a,b,same in [(0,1,True),(0,2,False),(1,2,False)]]
result.update(status='DIAGNOSTIC_OBSERVATIONS_REFERENCE_ALIGNED',production_gates=gates,expected_gates=expected,window_classification_matches=all(r['accepted']==e for r,e in zip(gates,expected,strict=True)),recording_pairs=pairs,recording_pair_matches=all((p['aggregate_cosine']>=.65)==p['same'] for p in pairs),observations=observations,reference_comparisons=len(reference['checks']),reference_max_relative_l2=max(r['relative_l2'] for r in reference['checks']),reference_minimum_cosine=min(r['cosine'] for r in reference['checks']),production_threshold_unchanged=.65,general_threshold_calibrated=False)
save(O/'result.json',result);print(json.dumps(result,indent=2))

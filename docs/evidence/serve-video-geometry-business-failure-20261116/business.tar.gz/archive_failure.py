import base64,fcntl,hashlib,json,re,struct,tarfile
from pathlib import Path
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_responses import background_acceptance as b
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;work=W/'business-01';objects=work/'objects'
result,cleanup,plan,env=[read(work/n) for n in ['result.json','cleanup.json','plan.json','lease/exit.json']]
require(result['status']=='FAILED' and result['counts']['starts']==1 and result['counts']['chats']==2,'unexpected business state')
require(env['child_returncode']==1 and env['compute_backend']=='nvml' and env['lease_inherited_by_child'],'environment differs')
queries=[json.loads(s) for s in (work/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(queries and all(x['status']=='OK' and x['returncode']==0 for x in queries),'NVML failure')
require(cleanup['remaining']==[] and cleanup['ports_released'] and cleanup['model_exit']==0 and cleanup['lease_continuously_held'],'cleanup failed')
for n,h in {**plan['sources'],**plan['protected']}.items():require(sha(ROOT/n)==h,'source/default differs')
processes=b.base.lifecycle.guard.processes()
require(not any(processes.get(int(p),{}).get('start_ticks')==v['start_ticks'] for p,v in cleanup['owned'].items()),'owned process live')
b.probe_ports((plan['port'],plan['operations_port']))
with b.base.lifecycle.guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
diag=W/'diagnostic-frames-01';diag.mkdir();frames=[]
for f in objects.glob('*input_snapshot*'):
 record=read(f)['record'];record=json.loads(record) if isinstance(record,str) else record
 parts=[]
 for chunk in record['data']['blob']['chunks']:
  paths=list(objects.glob('*.'+chunk['id']+'.json'));require(len(paths)==1,'missing original chunk')
  r=read(paths[0])['record'];r=json.loads(r) if isinstance(r,str) else r
  content=base64.b64decode(r['data']['base64'],validate=True);require(len(content)==chunk['bytes'] and hashlib.sha256(content).hexdigest()==chunk['sha256'],'chunk drift');parts.append(content)
 metadata=json.loads(parts[0]);name=metadata['source']['filename'];video=metadata['videos'][0];rows=[]
 for index,raw in enumerate(parts[2:]):
  require(raw[:8]==b'\x89PNG\r\n\x1a\n','not PNG');shape=struct.unpack('>II',raw[16:24]);p=diag/(name+f'.{index}.png');p.write_bytes(raw);rows.append(dict(width=shape[0],height=shape[1],sha256=sha(p)))
 save(diag/(name+'.metadata.json'),metadata)
 frames.append(dict(filename=name,source_sha256=metadata['source']['sha256'],conversion=video['conversion'],pngs=rows))
save(diag/'geometry.json',frames)
out=ROOT/'docs/evidence/serve-video-geometry-business-failure-20261116';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p in sorted(work.rglob('*')):
  if p.is_file() and 'objects' not in p.relative_to(work).parts:
   require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),'private key')
   tar.add(p,arcname='business-01/'+str(p.relative_to(work)))
 tar.add(diag,arcname=diag.name)
 for name in ['archive_failure.py','gpu-business-01.json','gpu-business-01.stdout','gpu-business-01.stderr','identity.json']:
  tar.add(W/name,arcname=name)
save(out/'failure.json',dict(status='NOT_ACCEPTED_DISPLAY_LAYOUT_ANSWER',binary_sha256=plan['binary_sha256'],counts=result['counts'],seconds=result['seconds'],nvml_queries=len(queries),cleanup_complete=True,default_unchanged=True,failure='All mirror corner colors correct, layout answered square instead of landscape.',actual_frozen_frames=frames,raw_archive_sha256=sha(out/'business.tar.gz'),next='Verify actual preprocessor shape; expose actual validated display dimensions in prepared video source metadata. Keep question/oracle unchanged.'))
(out/'README.md').write_text(f'''# 显示几何首次实际业务未通过

2026-11-16，1启动/2创建/{result['seconds']:.3f}秒，{len(queries)}次NVML正常。
上传90度旋转的全部角点/portrait和输入计数通过；镜像SSE四个角点
全部正确，但layout答square而非landscape，故未验收。其余两条未发送。

从实际持久快照逐块核对SHA并提取原始PNG：镜像始终128×64，旋转
64×128，与冻结转换来源完全一致。原件保留；接着核对最终视频
预处理并补齐实际尺寸来源。问题、角点/布局判定、原始视频不放宽。
自有PID/端口/锁释放，rev142保持。没有性能或完整质量结论。
''')
print(json.dumps(dict(status='failure preserved',nvml_queries=len(queries),frames=[(x['filename'],x['pngs'][0]['width'],x['pngs'][0]['height']) for x in frames])))

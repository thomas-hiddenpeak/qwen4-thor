"""Archive actual auxiliary service business without rewriting failed attempts."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OUT = ROOT/'docs/evidence/serve-audio-auxiliary-service-20261118'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not OUT.exists() and not (W/'publication-composition.json').exists()
def descriptor(name):
    value=read(W/name/'receipt.json')
    return {k:value[k] for k in ('package','manifest_sha256')}
candidate,legacy,modern,tls = [descriptor(n) for n in
    ['service-package-03','retained-03','modern-retained-03','tls-package-03']]
binary=sha(Path(candidate['package'])/'engine/q4t')
assert binary=='bcf1c0f7beef47d21bb29539b498796714fea5d8d209910b9d09d516f5c018d2'
files={};stages=[];decisions={}
for name,package,scenario in [('legacy-business-03',legacy,'tool_retained'),
                             ('modern-business-03',modern,'tool_retained'),
                             ('native-tls-03',tls,'tls'),
                             ('version-business-03',candidate,'tool_version')]:
    folder=W/name;execution=folder/'execution'
    plan,decision,result,guard=[read(folder/p) for p in
        ['plan.json','decision.json','execution/result.json','lease/exit.json']]
    assert plan['scenario']==scenario and plan['package']==package
    assert decision['manifest_sha256']==package['manifest_sha256'] and decision['engine_binary_sha256']==binary
    assert all(decision['actual_business']['postflight'].values())
    assert result['status']=='PASS_BOUNDED_FEATURE_SERVICE' and result['failure'] is None and result['cleanup_failure'] is None
    assert guard['status']=='COMPLETED' and guard['child_returncode']==0
    assert guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease']
    for field,path in [('plan_sha256','plan.json'),('result_sha256','execution/result.json'),('lease_result_sha256','lease/exit.json')]:
        assert decision['actual_business'][field]==sha(folder/path)
    if name=='legacy-business-03':
        review=read(folder/'command-path-review.json')
        binding=decision['actual_business']['command_path_review']
        assert binding['sha256']==sha(folder/'command-path-review.json')
        assert review['observed_command']==guard['command'] and review['planned_command']==plan['command']
        assert not binding['original_strict_finalizer_passed'] and binding['manual_session_path_equivalence_review']
    else:assert guard['command']==plan['command']
    queries=[json.loads(line) for line in (folder/'lease/nvml-queries.jsonl').read_text().splitlines()]
    assert queries and all(v['status']=='OK' and v['returncode']==0 for v in queries)
    stages.append(dict(name=name,counts=result['budget']['counts'],actual_model_execs=len(result['models']),seconds=result['seconds'],nvml_queries=len(queries),strict_lease_seconds=decision['actual_business']['strict_lease_seconds']))
    decisions[name]=decision
    for directory,prefix in [(folder,name),(folder/'lease',name+'/lease'),(execution,name+'/execution')]:
        for p in directory.iterdir():
            if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.jsonl','.wire','.log'):
                files[prefix+'/'+p.name]=p
    files[name+'/execution/state/ledger.json']=execution/'state/ledger.json'
for name in ['prepare_package-03.py','prepare_retained-03.py','prepare_modern_root-03.py','prepare_tls-03.py',
    'service-package-03/prepare-review.json','service-package-03/native-build.json','service-package-03/receipt.json',
    'service-package-03/decision.json','retained-03/review.json','modern-retained-03/review.json',
    'modern-retained-03/receipt.json','archive_service_composition.py']:
    files[name]=W/name
secrets=[]
def collect(v):
    if isinstance(v,dict):
        for k,item in v.items():
            if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(item,str) and len(item)>=24:
                secrets.append(item.encode())
            else:collect(item)
    elif isinstance(v,list):
        for item in v:collect(item)
for pack in [candidate,legacy,modern,tls]:
    for name in ['gateway-policy.json','engine/client-policy.json']:collect(read(Path(pack['package'])/name))
for name,path in files.items():
    raw=path.read_bytes();assert not any(s in raw for s in secrets),name
    assert b'-----BEGIN '+b'PRIVATE KEY-----\n' not in raw,name
original=read(ROOT/'docs/evidence/serve-audio-exec-bound-20261118/review.json')
assert sum(v['actual_model_execs'] for v in stages)==5
assert sum(v['counts']['starts'] for v in stages)+original['original_counted_spawn_attempts']==6
assert sum(v['counts']['chats'] for v in stages)==19
assert sum(v['counts']['probes'] for v in stages)==1
seconds=sum(v['seconds'] for v in stages)+original['original_seconds'];assert seconds<1800
OUT.mkdir()
with tarfile.open(OUT/'records.tar.gz','w:gz') as archive:
    for name,path in sorted(files.items()):archive.add(path,arcname=name,recursive=False)
accepted=dict(status='ACCEPT_NATIVE_AUDIO_AUXILIARY_SERVICE_COMPOSITION',binary_sha256=binary,
    candidate=candidate,automatic_fallback=legacy,modern_retained_root=modern,tls_package=tls,stages=stages,
    counted_spawn_attempts=6,actual_model_starts=5,service_requests=19,service_probes=1,service_seconds=seconds,
    nvml_queries=sum(v['nvml_queries'] for v in stages)+original['nvml_queries'],nvml_all_ok=True,cleanup_complete=True,
    original_failed_preexec='docs/evidence/serve-audio-exec-bound-20261118/README.md',
    original_legacy_finalizer_passed=False,legacy_command_path_review=decisions['legacy-business-03']['actual_business']['command_path_review'],
    primary_light_evidence='docs/evidence/serve-audio-auxiliary-profiles-20261117/README.md',
    direct_http_evidence='docs/evidence/serve-vad-http-20261117/README.md',
    tls_composition=decisions['native-tls-03'],candidate_service_acceptance=decisions['version-business-03'],
    modern_service_acceptance=decisions['modern-business-03'],candidate_whole_package_gpu_run=True,
    default_unchanged=True,publication_pending=True,older_engine_fallback=False,
    full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,
    archive_sha256=sha(OUT/'records.tar.gz'),secret_scan_matches=0)
for p in [W/'publication-composition.json',OUT/'acceptance.json']:p.write_text(json.dumps(accepted,indent=2)+'\n')
(OUT/'README.md').write_text(f'''# 原生对齐/VAD接入和恢复组合通过

两种保留控制及候选整包恢复均执行实际两段语音的词时间戳和完整segment。
TLS双SDK、实际VAD流式/分块、客户端上传配额、断流取消及网关恢复保持核心PID通过。
整包回退替换控制器/模型/入口后，对齐/ASR/VAD、存储Chat和profile历史保持。
全部自有进程、端口和锁已清理；默认rev276未变，继续可回退发布及全部master。

合计6次计费启动尝试（含原exec参数拒绝）、5次实际模型加载、19条请求、1次CUDA探针，
{seconds:.3f}秒，{accepted['nvml_queries']}次NVML查询正常。原FAILED完整保留。
旧控制成功轮的最初finalize命令字符串核对失败：相对路径与冻结绝对路径不相等。
该轮按会话工具调用的cwd、解释器和脚本身份作一次显式路径等价审查；guard没有cwd字段，
不将该事实说成guard新观察，也不将原自动finalizer改称通过。原件不改，其余全部门禁重验通过；
其他三个阶段直接使用计划中的精确argv，自动finalize通过，未为路径整理重跑GPU。

独立旧引擎fallback、完整模型质量、性能与长稳均不在本项接受内；当前回退使用新引擎与旧控制。
说话人/Chat音频/合成/Realtime及全部master剩余任务仍必须完成。档案已扫描实际私有密钥/令牌，0匹配。
''')
print(json.dumps({k:accepted[k] for k in ['status','counted_spawn_attempts','actual_model_starts','service_requests','service_seconds','nvml_queries']}))

from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'duplex-driver-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tools/serve_realtime/'+n for n in ['duplex_acceptance.py','duplex_checks.py','duplex_sdk.mjs','test_duplex_acceptance.py']]+['.github/workflows/host-checks.yml']
commands=[['python3','-B','-m','unittest','-v','tools.serve_realtime.test_duplex_acceptance'],['node','--check','tools/serve_realtime/duplex_sdk.mjs']]
plan=dict(scope=json.loads((W/'duplex-driver-plan-01.json').read_text()),sources={n:sha(R/n) for n in files},commands=commands,protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']})
save('plan.json',plan);start=time.monotonic();runs=[]
for i,cmd in enumerate(commands):
 p=subprocess.run(cmd,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,timeout=max(.1,120-(time.monotonic()-start)));(O/f'command-{i}.stdout').write_bytes(p.stdout);(O/f'command-{i}.stderr').write_bytes(p.stderr);runs.append(dict(command=cmd,returncode=p.returncode))
 if p.returncode:break
unchanged=all(sha(n)==v for n,v in plan['protected'].items());ok=unchanged and len(runs)==2 and all(x['returncode']==0 for x in runs)
r=dict(status='PASS' if ok else 'FAIL',commands=runs,seconds=time.monotonic()-start,default_unchanged=unchanged,gpu_starts=0);save('result.json',r);print(json.dumps(r));raise SystemExit(not ok)

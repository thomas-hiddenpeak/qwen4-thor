"""Publish modern native roots without changing engine or durable budgets."""
import copy,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle,publication,profile_manager,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'delivery-01';DEFAULT=R/'build';STATE=DEFAULT/'service-native-state'
OLD='78d6bd7b89be7e1325c6c5f76d12bc2458291e79a386b5343f4274e55164fa0d'
def preserved():
 return {str(f.relative_to(STATE)):p.sha(f) for f in STATE.rglob('*') if f.is_file() and (f.name=='ledger.json' or f.relative_to(STATE).parts[0].startswith(('client-','outer-','profile-selection')))}
def version():return p.read(STATE/'version-selection/policy.json')['state']['policy']
def exact(before,after):p.require({k:v for k,v in before.items() if k!='revision'}=={k:v for k,v in after.items() if k!='revision'} and after['revision']>before['revision'],'root switch lost original cycle state')
def prepare():
 p.require(not OUT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=R),'clean committed delivery required')
 current=publication.status(STATE);roots=p.read(W/'wait-roots.json');accept=p.read(W/'accepted-cases/acceptance.json')
 p.require(current['ready'] and current['revision']==174 and current['current']['manifest_sha256']==OLD,'default predecessor differs')
 p.require(len(list((DEFAULT/'.q4t-publication/generations').iterdir()))<=30 and len(list((STATE/'version-registrations').glob('*.json')))<=14,'bounded pools need retired archive')
 old=bundle.verify(current['current']['package'],OLD)
 manifests={name:bundle.verify(v['package'],v['manifest_sha256']) for name,v in roots.items()}
 for n,h in manifests['candidate']['files'].items():
  if n.startswith('source/'):p.require(p.sha(R/n[7:])==h,'runtime source drift')
 for n,h in p.read(Path(roots['candidate']['package'])/'native-build.json')['source_files'].items():p.require(p.sha(R/n)==h,'native source drift')
 for name,t in roots.items():
  p.require(profile_manager.compatible(old,manifests[name],current['current']['package'],t['package']) is None,'unexpected profile migration')
  version_contract.accepted_fallback(accept[name]['acceptance'],version_contract.payload(t))
 previous_version=version();p.require(previous_version['registry']['root_manifest_sha256']==OLD and previous_version['switch'] is None and previous_version['terminal_fault'] is None,'unexpected original version consumption')
 OUT.mkdir(mode=0o700);shutil.copytree(STATE,OUT/'previous-state',symlinks=True)
 generation=(DEFAULT/'q4t').resolve().parent;(OUT/'previous').mkdir(mode=0o700)
 for n in ('q4t','q4t.release.json','service.release.json','service.acceptance.json'):shutil.copyfile(generation/n,OUT/'previous'/n)
 original=p.read(OUT/'previous/service.release.json');prior=p.read(W/'business-01/plan.json')['registrations']['retained']
 legacy=prior['payloads']['fallback']['descriptor'];old_accept_dir=R/'.q4t-work/serve-chat-cache-20261116/retained-business-01'
 legacy_acceptance={k:dict(path=str(old_accept_dir/n),sha256=p.sha(old_accept_dir/n)) for k,n in [('release','service-release.json'),('decision','decision.json')]}
 registrations={name:version_contract.prepare(root,root,legacy,str(uuid.uuid4()),fallback_acceptance=legacy_acceptance) for name,root in roots.items()}
 for name,reg in registrations.items():p.save(OUT/(name+'-registration.json'),reg)
 review=dict(previous=current,previous_version=previous_version,preserved=preserved(),roots=roots,registrations=registrations,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),acceptance=accept,engine_unchanged=True,automatic_payload_fallback=legacy,manual_modern_root_fallback=roots['retained'],new_gpu_starts=0)
 p.save(OUT/'review.json',review)
 for name,t in roots.items():
  source=p.read(accept[name]['acceptance']['decision']['path']);kind='NATIVE_ROOT_'+name.upper()+'_DELIVERY'
  decision=dict(status='PASS_'+kind,acceptance='ACCEPT_'+kind,manifest_sha256=t['manifest_sha256'],engine_binary_sha256=source['engine_binary_sha256'],actual_business=source['actual_business'],original_decision=accept[name]['acceptance']['decision'],control_review=str(OUT/'review.json'),new_gpu_starts=0,remaining_master_tasks_open=True,performance_acceptance=False,long_stability_accepted=False)
  p.save(OUT/(name+'-decision.json'),decision);package=Path(t['package']);reg=registrations[name]
  release=copy.deepcopy(original);release.update(acceptance=decision['acceptance'],acceptance_record=str(OUT/(name+'-decision.json')),acceptance_sha256=p.sha(OUT/(name+'-decision.json')),package=t['package'],manifest_sha256=t['manifest_sha256'],recovery_accepted=True,
   engine_binary_sha256=p.sha(package/'engine/q4t'),engine_release_sha256=p.sha(package/'engine/q4t.release.json'),guardian_sha256=p.sha(package/'bin/q4t-guardian'),cuda_probe_sha256=p.sha(package/'bin/q4t-cuda-probe'),ingress_sha256=p.sha(package/'bin/q4t-ingress'),recovery_bundle_profile=manifests[name]['profile'],control_review=str(OUT/'review.json'),control_source_commit=review['source_commit'],engine_metadata_unchanged=True,engine_default_replaced=False,engine_qualification_receipt_immutable=True,previous_acceptance_record=original['acceptance_record'],state=str(STATE),service_id=current['current']['service_id'] if 'service_id' in current['current'] else p.read(STATE/'service.json')['service_id'],initial_desired='STOPPED',automatically_started=False,
   version_recovery_targeted_accepted=True,version_recovery_registration=str(OUT/(name+'-registration.json')),version_recovery_registration_sha256=p.sha(OUT/(name+'-registration.json')),version_recovery_cycle_id=reg['registry']['cycle_id'],native_outer_recovery_targeted_accepted=True,native_outer_enabled=True,
   unaffected_control_recovery_reused_by_exact_source_identity=False,root_cycle_migration_targeted_accepted=True,recovery_wait_cpu_evidence=str(R/'docs/evidence/serve-recovery-wait-cpu-20261116/acceptance.json'),root_rollback_business_evidence=str(R/'docs/evidence/serve-root-rollback-business-20261116/acceptance.json'),gpu_starts_for_install=0,
   scope='Native whole-root rollback preserves original recovery cycles, consumed faults and outer supervision. Exact new roots qualified with JSON/SSE and actual Guardian recovery; original tool/cycle facts and targeted CPU evidence compose acceptance. Original failed continuous drivers preserved. Engine, ingress, device helpers, profiles and clients unchanged. Automatic payload fallback remains accepted c789291b; modern retained root is the manual whole-root target. Remaining cold/resource/host and complete Serve master tasks continue; no full performance, quality or long-stability claim.')
  if name=='retained':
   release.pop('rollback_receipt',None);release.pop('rollback_sha256',None)
  p.save(OUT/(name+'-service.release.json'),release)
 anchor=dict(package=roots['retained']['package'],manifest_sha256=roots['retained']['manifest_sha256'],service_release=str(OUT/'retained-service.release.json'),service_release_sha256=p.sha(OUT/'retained-service.release.json'),manual_root_rollback_requires_stopped=True,retains_native_outer_and_cycle_migration=True)
 p.save(OUT/'recovery-anchor.json',anchor);release=p.read(OUT/'candidate-service.release.json');release.update(rollback_receipt=str(OUT/'recovery-anchor.json'),rollback_sha256=p.sha(OUT/'recovery-anchor.json'));p.save(OUT/'candidate-service.release.json',release)
 p.save(OUT/'requests.json',{k:str(uuid.uuid4()) for k in ('anchor','candidate','rollback','forward')});print(json.dumps(dict(status='PREPARED_NATIVE_ROOT_DELIVERY',roots=roots,models_started=0)))
def run():
 review=p.read(OUT/'review.json');roots=review['roots'];ids=p.read(OUT/'requests.json');cli=Path(roots['candidate']['package'])/'bin/q4t';rows=[];started=time.monotonic();anchor_state=None;main_state=None
 def call(label,args):
  raw=[str(v) for v in args];r=subprocess.run(raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
  (OUT/(label+'.stdout')).write_text(r.stdout);(OUT/(label+'.stderr')).write_text(r.stderr);rows.append(dict(label=label,argv=raw,returncode=r.returncode))
  p.require(r.returncode==0,'delivery command failed: '+label);p.require(preserved()==review['preserved'],'durable core/client/outer/profile changed');return json.loads(r.stdout)
 def publish(label,name,previous,revision,key):
  t=roots[name];return call(label,[cli,'service','publish','--state',STATE,'--default-root',DEFAULT,'--package',t['package'],'--manifest-sha256',t['manifest_sha256'],'--service-release',OUT/(name+'-service.release.json'),'--expected-manifest-sha256',previous,'--expected-revision',revision,'--request-id',ids[key]])
 def register(name,previous):
  value=call(name+'-register',[DEFAULT/'q4t','service','version-register','--state',STATE,'--registration',OUT/(name+'-registration.json'),'--expected-cycle',previous]);p.require(value['registered'] and not value['fallback_consumed'],'version registration failed');return version()
 try:
  p.require(call('previous-check',[cli,'service','check','--state',STATE,'--package',review['previous']['current']['package'],'--manifest-sha256',OLD])['desired']=='STOPPED','default not stopped')
  for n,t in roots.items():p.require(call(n+'-check',[cli,'service','check','--package',t['package'],'--manifest-sha256',t['manifest_sha256']])['status']=='PASS','package check')
  result=publish('anchor-publish','retained',OLD,174,'anchor');p.require(result['durable'] and result['revision']==176,'anchor publication')
  generation=result['current']['generation_sha256'];p.save(OUT/'anchor-generation.json',dict(generation=generation))
  anchor_state=register('retained',review['previous_version']['registry']['cycle_id']);p.save(OUT/'anchor-cycle.json',anchor_state)
  result=publish('candidate-publish','candidate',roots['retained']['manifest_sha256'],176,'candidate');p.require(result['durable'] and result['revision']==178,'candidate publication')
  main_state=register('candidate',anchor_state['registry']['cycle_id']);p.save(OUT/'candidate-cycle.json',main_state)
  result=call('root-rollback',[cli,'service','publish-rollback','--state',STATE,'--default-root',DEFAULT,'--package',roots['candidate']['package'],'--manifest-sha256',roots['candidate']['manifest_sha256'],'--generation-sha256',generation,'--expected-manifest-sha256',roots['candidate']['manifest_sha256'],'--expected-revision',178,'--request-id',ids['rollback']]);p.require(result['durable'] and result['revision']==180,'rollback publication');exact(anchor_state,version())
  p.require(call('retained-root-check',[DEFAULT/'q4t','service','check','--state',STATE])['desired']=='STOPPED','modern retained root not operable')
  p.require(call('retained-outer',[DEFAULT/'q4t','service','outer-status','--state',STATE])['enabled'],'retained root lost outer')
  result=publish('root-forward','candidate',roots['retained']['manifest_sha256'],180,'forward');p.require(result['durable'] and result['revision']==182,'forward publication');exact(main_state,version())
  for action in ('check','status','observe'):
   v=call('default-'+action,[DEFAULT/'q4t','service',action,'--state',STATE]);p.require(v['status']=='PASS' if action=='check' else v['state']=='STOPPED','default health')
  profile=call('profiles',[DEFAULT/'q4t','service','profiles-status','--state',STATE]);p.require(profile['selected']=='primary','profile changed')
  ver=call('version',[DEFAULT/'q4t','service','version-status','--state',STATE]);p.require(ver['cycle_id']==main_state['registry']['cycle_id'] and not ver['fallback_consumed'],'candidate original cycle not restored')
  outer=call('outer',[DEFAULT/'q4t','service','outer-status','--state',STATE]);p.require(outer['enabled'] and outer['charged_total']==0,'outer budget changed')
  final=call('publication',[DEFAULT/'q4t','service','publish-status','--state',STATE]);p.require(final['ready'] and final['revision']==182 and final['current']['manifest_sha256']==roots['candidate']['manifest_sha256'],'default publication differs')
  p.save(OUT/'result.json',dict(status='PASS_NATIVE_ROOT_DELIVERED',seconds=time.monotonic()-started,commands=rows,publication=final,retained_anchor_generation=generation,profiles=profile,versions=ver,outer=outer,anchor_cycle=anchor_state,candidate_cycle=main_state,final_cycle=version(),preserved=review['preserved'],state='STOPPED',new_gpu_starts=0,remaining_master_tasks_open=True));print(json.dumps(dict(status='PASS_NATIVE_ROOT_DELIVERED',revision=182,commands=len(rows))))
 except BaseException as error:
  p.save(OUT/'result.json',dict(status='FAILED',commands=rows,category=type(error).__name__,detail=str(error),seconds=time.monotonic()-started));raise
if __name__=='__main__':
 os.umask(0o077);{'prepare':prepare,'run':run}[sys.argv[1]]()

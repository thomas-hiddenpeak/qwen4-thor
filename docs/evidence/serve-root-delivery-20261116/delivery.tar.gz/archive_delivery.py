"""Archive only public root-delivery records, never private state/payloads."""
import json
import re
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.serve_service.package import read, require, save, sha

work = Path(__file__).resolve().parent
out = root / 'docs/evidence/serve-root-delivery-20261116'
result = read(work / 'delivery-01/result.json')
current = result['publication']['current']
require(result['status'] == 'PASS_NATIVE_ROOT_DELIVERED' and
        result['publication']['revision'] == 182 and
        result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0,
        'delivery not accepted')
for name, key in [('q4t', 'engine_binary_sha256'),
                  ('q4t.release.json', 'engine_release_sha256'),
                  ('service.release.json', 'service_release_sha256'),
                  ('service.acceptance.json', 'service_acceptance_sha256')]:
    require(sha(root / 'build/.q4t-publication/current' / name) == current[key],
            'default identity drift')
secrets = []


def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'shared_secret', 'private_key', 'token') \
                    and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)


for policy in ('build/service/engine/client-policy.json',
               'build/service/gateway-policy.json'):
    collect(read(root / policy))
files = [(p, 'delivery-01/' + p.name)
         for p in (work / 'delivery-01').iterdir()
         if p.is_file() and not p.is_symlink()]
for name in ('archive_delivery.py', 'deliver_root.py', 'run_delivery.py'):
    files.append((work / name, name))
for stem in ('delivery-prepare-01', 'delivery-run-01'):
    for ext in ('json', 'stdout', 'stderr'):
        files.append((work / (stem + '.' + ext), stem + '.' + ext))
for path, _ in files:
    data = path.read_bytes()
    require(not any(secret in data for secret in secrets),
            'secret in public evidence')
    require(not re.search(
        rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', data),
        'private key in evidence')
out.mkdir()
with tarfile.open(out / 'delivery.tar.gz', 'w:gz') as archive:
    for path, name in sorted(files, key=lambda item: item[1]):
        archive.add(path, arcname=name, recursive=False)
(out / 'delivery-01').mkdir()
for name in ('result.json', 'recovery-anchor.json'):
    (out / 'delivery-01' / name).write_bytes(
        (work / 'delivery-01' / name).read_bytes())
save(out / 'acceptance.json', dict(
    status='ACCEPT_NATIVE_ROOT_DELIVERY', revision=182, current=current,
    commands=len(result['commands']), seconds=result['seconds'],
    new_gpu_starts=0, state='STOPPED',
    core_client_outer_profile_bytes_preserved=True,
    original_root_cycles_restored=True,
    retained_anchor_generation=result['retained_anchor_generation'],
    files=len(files), archive_sha256=sha(out / 'delivery.tar.gz'),
    secret_scan_matches=0, remaining_master_tasks_active=True))
(out / 'README.md').write_text(f'''# 原生整根回退交付 rev182

正式服务包430e7985、Guardian e8290fa1已进入实际默认，generation
{current['generation_sha256']}。
{len(result['commands'])}项STOPPED发布、原根回退及再前进检查通过，
{result['seconds']:.3f}秒、0新增GPU。现代保留根7230ac61也提供outer及
原周期迁移；不再把缺少outer的v12根作为人工整包回退入口。

回退恢复该根最后持久化的周期，保留消费、故障、selected、terminal
及预算，仅全局revision递增；core/client/outer/profile字节保持。
引擎0851dab3、原生入口、设备辅助程序、容量及客户端政策均保持。
自动payload回退仍为已验c789291b，与人工现代整根回退分开；两者
均不是独立旧引擎回退。最后STOPPED，outer启用且累计0启动。

接受依据为32项根策略/持久化CPU、10项恢复等待CPU及受影响补验、
封包/驱动检查和[针对性真实业务](../serve-root-rollback-business-20261116/README.md)：
9启动/18Chat含自检/1探测、938.526秒、871次NVML正常，所有清理通过。
三个原失败驱动保留；组合证据不声称原连续链完整通过。

rev174默认与状态备份、现代保留根及退休周期/发布副本归档保持。
公开证据不包含私有状态、密钥或模型；扫描0命中。实际合main待完成；
R07/R08冷启动/资源和宿主组合、其余协议及全部33项master继续。
不宣称完整OpenAI兼容、完整性能/质量或长稳通过。
''')
print(json.dumps(dict(status='ACCEPT_NATIVE_ROOT_DELIVERY', revision=182,
                      files=len(files), secret_scan_matches=0)))

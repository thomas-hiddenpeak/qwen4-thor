import copy,hashlib,json,tarfile
from pathlib import Path
from jsonschema import Draft202012Validator
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent;C=D/'http-01'
O=R/'docs/evidence/serve-speaker-http-20261118'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(C/'plan.json');r=read(C/'result.json');g=read(C/'lease/exit.json');c=read(C/'cleanup.json')
assert r['status']=='PASS_NATIVE_DIARIZED_HTTP_SDK_REFERENCES_SCOPED_RECOVERY'
assert r['counts']['starts']==1 and r['counts']['chats']==10 and r['seconds']<=600
assert read(C/'launch.json')['returncode']==0 and r['default_unchanged']
assert g['status']=='COMPLETED' and g['child_returncode']==0 and g['command']==p['command']
assert g['compute_backend']=='nvml' and g['lease_inherited_by_child'] and not g['external_lease']
assert c['model_exit']==0 and not c['remaining'] and c['ports_released'] and c['lease_continuously_held']
for name,digest in p['sources'].items():assert sha(R/name)==digest,name
for name,digest in p['protected'].items():assert sha(Path(name))==digest,name
assert sha(Path(p['binary']))==p['binary_sha256']==r['binary_sha256']
q=[json.loads(l) for l in (C/'lease/nvml-queries.jsonl').read_text().splitlines()]
assert q and all(x['status']=='OK' for x in q)
events=[json.loads(l) for l in (C/'lease/events.jsonl').read_text().splitlines()]
assert events[0]['event']=='lease_acquired' and events[-1]['event']=='lease_released'
assert all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events)
for e in events:
 if e['event']=='child_started':assert not Path('/proc',str(e['child_pid'])).exists()
for pid in c['owned']:assert not Path('/proc',pid).exists()
schema=read(R/'docs/serve-application-v1.schema.json');checked=[]
def check(v,kind,label):
 errs=list(Draft202012Validator({'$ref':'#/$defs/'+kind,'$defs':schema['$defs']}).iter_errors(v));assert not errs,(label,[e.message for e in errs]);checked.append(label)
for name in ['python-same','js-returning','python-known','python-silence']:
 check(read(C/(name+'.wire')),'transcription_diarized_response',name)
for i,line in enumerate((C/'js-stream.wire').read_text().splitlines()):
 if line.startswith('data: {'):check(json.loads(line[6:]),'transcription_event','stream:'+str(i))
config_validator=Draft202012Validator(read(R/'docs/serve-config-v1.schema.json'))
for name in ['initial-config.wire','missing-config.wire','recovered-config.wire','final-config.wire']:
 errors=list(config_validator.iter_errors(read(C/name)));assert not errors,(name,[e.message for e in errors]);checked.append(name)
quality=read(C/'quality.json');assert quality['python-same']['labels']==['A','A'] and quality['js-returning']['labels']==['A','B','A'] and quality['python-known']['labels']==['first','second','first'] and quality['stream']['labels']==['A','B','A'] and quality['silence']['silence']
for n in ['asr','alignment','speaker']:
 health=read(C/'final-config.wire')['native_'+n+'_health'];assert health['state']=='ready' and health['compute_failures']==0
assert read(C/'final-config.wire')['native_speaker_health']['load_attempts']==3
# Plan/request originals with reference data URLs remain intact locally. Public
# review copies identify those bytes without embedding official audio assets.
O.mkdir();publication=[];redacted=[]
def redact(v):
 if isinstance(v,dict):return {k:redact(x) for k,x in v.items()}
 if isinstance(v,list):return [redact(x) for x in v]
 if isinstance(v,str) and v.startswith('data:audio/'):
  return {'retained_audio_data_url_sha256':hashlib.sha256(v.encode()).hexdigest(),'bytes':len(v)}
 return v
for path in sorted(C.glob('*')):
 if not path.is_file() or path.suffix=='.wav':continue
 if path.name=='plan.json' or path.name.endswith('.request.json'):
  name=path.stem+'.reviewed.json';(O/name).write_text(json.dumps(redact(read(path)),ensure_ascii=False,indent=2)+'\n');redacted.append(dict(source=str(path),source_sha256=sha(path),reviewed=name,reviewed_sha256=sha(O/name)))
 else:(O/path.name).write_bytes(path.read_bytes())
(O/'offline-schema-review.json').write_text(json.dumps({'status':'PASS','actual_observations':checked,'gpu_loads':0},indent=2)+'\n')
(O/'redaction-receipt.json').write_text(json.dumps(redacted,indent=2)+'\n')
archive=[Path(__file__).resolve()]
archive += [f for f in (C/'lease').glob('*') if f.is_file()]
archive += [f for f in (D/'http-driver-cpu-01').glob('*') if f.is_file()]
archive += [D/'voice-fixtures-01/plan.json',D/'voice-fixtures-01/receipt.json']
with tarfile.open(O/'lease-driver-records.tar.gz','w:gz') as t:
 for f in sorted(archive):t.add(f,arcname=str(f.relative_to(D)),recursive=False)
a=dict(status='ACCEPT_NATIVE_DIARIZATION_DIRECT_HTTP',counts=r['counts'],seconds=r['seconds'],lease_seconds=read(C/'launch.json')['seconds'],nvml_ok=len(q),cleanup_complete=True,binary_sha256=p['binary_sha256'],source_commit=p['source_commit'],default_revision=286,defaults_unchanged=True,actual_labels={k:v.get('labels') for k,v in quality.items() if 'labels' in v},known_references=True,python_sdk=True,javascript_sdk=True,json_and_sse=True,request_local_recovery_without_model_restart=True,capacity_silence_cancellation=True,offline_schema_observations=len(checked),driver_cpu_tests=3,raw_plan_retained=str(C/'plan.json'),raw_plan_sha256=sha(C/'plan.json'),archive_sha256=sha(O/'lease-driver-records.tar.gz'),service_delivery_pending=True,overlap_implemented=False,full_language_quality=False,performance_claim=False,long_stability_run=False,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 真实说话人HTTP与双SDK通过（2026-11-18）

1启动/10创建/{r['seconds']:.3f}秒；严格租约{len(q)}次NVML正常，模型退出0、
自有进程/端口/租约清理完成，默认rev286未变。官方固定3段语音的
同人A/A、异人回访A/B/A、已知参考first/second/first全部通过，
Python/JS、JSON/SSE、segment ID/文本/实际usage闭合。窗口上限
拒绝、自然静音零输出/零token、真实断流取消通过；私有speaker
配置缺失只降级自身，健康核心两次42，同PID恢复后无compute失败。

{len(checked)}份实际JSON/流事件/健康配置另经已生成schema离线检查通过，
0追加GPU。3项验收器正负控复用。原计划/请求留本地，公开reviewed
副本只将参考音频data URL换为长度/SHA；redaction receipt可核验，
实际wire和SDK响应原样保留，不把review副本当原始计划。

候选尚未替换默认。接着服务包/主轻/原生接入与恢复交付、重叠声音
真实检测分离及全部master。未宣称人工字错率/时间标注准确率、完整
性能/模型质量或长稳；本次成功不结束总目标。
''')
ledger=R/'docs/serve-master-goals-v2.json';data=read(ledger);task=next(t for t in data['tasks'] if t['id']=='A10');task['speaker_http_20261118']=dict(a,evidence='evidence/serve-speaker-http-20261118/README.md');ledger.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
status=R/'docs/STATUS.md';status.write_text(status.read_text().replace('## 正在推进\n\n',f'''## 正在推进

[真实说话人HTTP通过](evidence/serve-speaker-http-20261118/README.md)：
1启动/10创建/{r['seconds']:.3f}秒，A/A、A/B/A与参考first/second/first，
双SDK/JSON/SSE、局部故障同PID恢复、容量/取消/静音和核心保护
通过；{len(q)}次NVML正常、自有资源清理。默认rev286未变，继续服务
恢复交付、重叠检测分离及全部master；阶段不结束总目标。

''',1))
log=R/'docs/log/2026-11-18.md';h,b=log.read_text().split('\n',1);log.write_text(h+f'''

## 真实说话人双SDK与隔离短验通过（2026-11-18）

1启动/10创建/{r['seconds']:.3f}秒，实际A/A、A/B/A、参考命名及JSON/SSE
全部通过；配置失能隔离、同PID恢复、窗口上限/取消/静音及两次
核心42通过。{len(q)}次NVML正常，自有模型/端口/租约清理；{len(checked)}份实际
wire/config通过schema离线核对。原因：补实际说话人闭环证据。
下一步服务/恢复交付、真实重叠路径及全部master，默认rev286保持。
[证据](../evidence/serve-speaker-http-20261118/README.md)。
'''+b)
print(json.dumps(a))

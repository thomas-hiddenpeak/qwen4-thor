#include "q4t/server/server_options.h"
#include "q4t/server/object_store_options.h"
#include "q4t/test.h"

#include <initializer_list>
#include <limits>
#include <string_view>

namespace {
using q4t::server::CapabilitiesFor;
using q4t::server::ServerOptions;
using q4t::server::StartupPlanMode;
ServerOptions Defaults() {
  ServerOptions options;
  options.model_dir = "/read-only-model";
  return options;
}
bool Parse(std::initializer_list<std::string_view> args, ServerOptions* out) {
  return q4t::server::ParseServerOptions({args.begin(), args.size()}, out).ok();
}
}  // namespace

Q4T_TEST(serve_embedding_options_bind_distinct_model_and_absolute_assets) {
  auto options = Defaults();
  Q4T_CHECK(Parse({"--embedding-model-dir", "/absent/optional-assets"}, &options));
  Q4T_CHECK(options.embedding_model_dir == "/absent/optional-assets");
  for (const auto* path : {"relative", "/", "/a/", "/a//b", "/a/../b", "/a/."}) {
    Q4T_CHECK(!Parse({"--embedding-model-dir", path}, &options));
    Q4T_CHECK(options.embedding_model_dir == "/absent/optional-assets");
  }
  Q4T_CHECK(!Parse({"--embedding-model-dir"}, &options));
  Q4T_CHECK(!Parse({"--served-model-name", "qwen3-embedding-0.6b"}, &options));
  Q4T_CHECK(!Parse({"--model-alias", "qwen3-embedding-0.6b"}, &options));
  Q4T_CHECK(options.served_model_name == Defaults().served_model_name &&
            options.model_aliases.empty());
  return true;
}

Q4T_TEST(serve_tts_options_bind_absolute_assets_and_transactional_budgets) {
  ServerOptions options;
  Q4T_CHECK(Parse({"--model-dir", "/model", "--tts-model-dir", "/assets/tts",
                   "--tts-max-text-tokens", "512", "--tts-max-prefill-tokens",
                   "512", "--tts-max-frames", "160", "--tts-workspace-mib",
                   "2048", "--tts-max-output-mib", "16"},
                  &options));
  Q4T_CHECK(options.tts_model_dir == "/assets/tts" &&
            options.tts_limits.max_text_tokens == 512 &&
            options.tts_limits.max_prefill_tokens == 512 &&
            options.tts_limits.max_frames == 160 &&
            options.tts_limits.workspace_mib == 2048 &&
            options.tts_limits.max_output_mib == 16);
  for (auto pair : {std::pair{"--tts-model-dir", "relative"},
                    std::pair{"--tts-max-text-tokens", "3"},
                    std::pair{"--tts-max-prefill-tokens", "32768"},
                    std::pair{"--tts-max-frames", "4097"},
                    std::pair{"--tts-workspace-mib", "127"},
                    std::pair{"--tts-max-output-mib", "129"}}) {
    Q4T_CHECK(
        !Parse({"--model-dir", "/model", pair.first, pair.second}, &options));
    Q4T_CHECK(options.tts_model_dir == "/assets/tts" &&
              options.tts_limits.max_frames == 160);
  }
  Q4T_CHECK(!Parse({"--model-dir", "/model", "--tts-model-dir", "/assets/tts",
                    "--served-model-name", "qwen3-tts-12hz-1.7b-customvoice"},
                   &options));
  return true;
}

Q4T_TEST(serve_access_program_option_requires_trusted_client_policy) {
  auto options = Defaults();
  Q4T_CHECK(!Parse({"--access-program-policy-file", "/private/access.json"},
                   &options));
  Q4T_CHECK(options.access_program_policy_file.empty());
  Q4T_CHECK(Parse({"--client-policy-file", "/private/clients.json",
                  "--access-program-policy-file", "/private/access.json"},
                 &options));
  Q4T_CHECK(options.access_program_policy_file == "/private/access.json");
  Q4T_CHECK(!Parse({"--access-program-policy-file"}, &options));
  Q4T_CHECK(options.access_program_policy_file == "/private/access.json");
  return true;
}

Q4T_TEST(serve_object_store_options_transactional_bounds) {
  auto options = Defaults();
  Q4T_CHECK(Parse(
      {"--object-store-dir", "/private/objects", "--object-max-object-mib", "8",
       "--object-max-client-mib", "16", "--object-max-total-mib", "32",
       "--object-max-client-objects", "20", "--object-max-total-objects", "40",
       "--object-io-timeout-ms", "900"},
      &options));
  for (const auto path : {"relative", "/", "/a/../b", "/a/./b", "/a/."}) {
    Q4T_CHECK(!Parse({"--object-store-dir", path}, &options));
    Q4T_CHECK(options.object_store_dir == "/private/objects");
  }
  for (const auto flag :
       {"--object-max-object-mib", "--object-max-client-mib",
        "--object-max-total-mib", "--object-max-client-objects",
        "--object-max-total-objects", "--object-io-timeout-ms"}) {
    for (const auto value : {"0", "-1", "2147483647", "1.5", "1x"})
      Q4T_CHECK(!Parse({flag, value}, &options));
    Q4T_CHECK(!Parse({flag}, &options));
  }
  Q4T_CHECK(!Parse({"--object-max-object-mib", "17"}, &options));
  Q4T_CHECK(!Parse({"--object-max-client-mib", "7"}, &options));
  Q4T_CHECK(!Parse({"--object-max-total-mib", "15"}, &options));
  Q4T_CHECK(!Parse({"--object-max-client-objects", "41"}, &options));
  Q4T_CHECK(!Parse({"--object-max-total-objects", "19"}, &options));
  Q4T_CHECK(options.object_max_object_mib == 8 &&
            options.object_max_client_mib == 16 &&
            options.object_max_total_mib == 32 &&
            options.object_max_client_objects == 20 &&
            options.object_max_total_objects == 40 &&
            options.object_io_timeout_ms == 900);
  const auto resolved = q4t::server::ResolveObjectStoreOptions(options, "", "");
  Q4T_CHECK(resolved.directory == "/private/objects" &&
            resolved.max_object_bytes == 8ULL << 20 &&
            resolved.max_client_bytes == 16ULL << 20 &&
            resolved.max_total_bytes == 32ULL << 20 &&
            resolved.max_client_objects == 20 &&
            resolved.max_total_objects == 40 && resolved.io_timeout_ms == 900);
  return true;
}

Q4T_TEST(serve_background_input_budget_is_configurable_and_transactional) {
  auto options = Defaults();
  Q4T_CHECK(options.background_max_input_mib == 512);
  Q4T_CHECK(Parse({"--background-max-input-mib", "2048"}, &options));
  for (const auto* value : {"0", "-1", "2049", "1.5", "1x"}) {
    Q4T_CHECK(!Parse({"--background-max-input-mib", value}, &options));
    Q4T_CHECK(options.background_max_input_mib == 2048);
  }
  Q4T_CHECK(!Parse({"--background-max-input-mib"}, &options));
  Q4T_CHECK(Parse({"--background-max-input-mib", "1"}, &options));
  Q4T_CHECK(options.background_max_input_mib == 1);
  return true;
}

Q4T_TEST(serve_object_store_directory_resolution_never_touches_filesystem) {
  using q4t::server::ResolveObjectStoreOptions;
  auto options = Defaults();
  Q4T_CHECK(ResolveObjectStoreOptions(options, "/not-created", "/home/user")
                .directory == "/not-created/q4t/objects");
  Q4T_CHECK(
      ResolveObjectStoreOptions(options, "relative", "/home/user").directory ==
      "/home/user/.local/state/q4t/objects");
  Q4T_CHECK(ResolveObjectStoreOptions(options, "/a/../b", "relative")
                .directory.empty());
  Q4T_CHECK(ResolveObjectStoreOptions(options, "", "").directory.empty());
  options.object_store_dir = "/explicit";
  Q4T_CHECK(
      ResolveObjectStoreOptions(options, "/other", "/home/user").directory ==
      "/explicit");
  options.object_store_dir = std::string("/private\0suffix", 15);
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options));
  return true;
}

Q4T_TEST(serve_agent_slot_capacity_and_admission) {
  auto options = Defaults();
  Q4T_CHECK(Parse({"--max-seq", "4", "--max-len", "208896", "--seq-capacities",
                   "208896,65536,65536,65536"},
                  &options));
  Q4T_CHECK(options.seq_capacities.size() == 4);
  for (auto value : {"", "208896,65536", "208896,65536,65536,65535",
                     "208896,65536,65536,65536,", "208896,0,65536,65536"}) {
    Q4T_CHECK(!Parse({"--seq-capacities", value}, &options));
    Q4T_CHECK(options.seq_capacities[1] == 65536);
  }
  Q4T_CHECK(!Parse({"--allow-media"}, &options));
  Q4T_CHECK(!Parse({"--no-budget"}, &options));
  std::vector<bool> free(4, true);
  const auto choose = [&](size_t tokens) {
    return q4t::runtime::SelectSequenceSlot(options.seq_capacities,
                                            options.max_len, free, tokens);
  };
  Q4T_CHECK(choose(65536) == 1);
  free[1] = false;
  Q4T_CHECK(choose(32768) == 2);
  Q4T_CHECK(choose(65537) == 0);
  free[0] = false;
  Q4T_CHECK(choose(65537) == -1);
  free[1] = true;  // cancelled short request releases its own slot
  Q4T_CHECK(choose(65536) == 1);
  Q4T_CHECK(choose(208897) == -1);
  Q4T_CHECK(q4t::server::TextAdmissionLimit(4) == 32);
  return true;
}

Q4T_TEST(serve_admission_options_and_transactional_bounds) {
  auto options = Defaults();
  Q4T_CHECK(
      Parse({"--max-inflight-requests", "4", "--max-queued-requests", "0"},
            &options));
  Q4T_CHECK(options.max_inflight_requests == 4 &&
            options.max_queued_requests == 0);
  for (auto value : {"0", "-1", "4097", "2147483647", "1.5", "1x"}) {
    Q4T_CHECK(!Parse({"--max-inflight-requests", value}, &options));
    Q4T_CHECK(options.max_inflight_requests == 4);
  }
  for (auto value : {"-1", "4097", "5", "1.5", "1x"}) {
    Q4T_CHECK(!Parse({"--max-queued-requests", value}, &options));
    Q4T_CHECK(options.max_queued_requests == 0);
  }
  Q4T_CHECK(Parse(
      {"--max-inflight-requests", "4096", "--max-queued-requests", "4096"},
      &options));
  return true;
}

Q4T_TEST(serve_admission_resolves_after_budget_without_silent_clamp) {
  auto options = Defaults();
  options.max_seq = 32;
  q4t::server::AdmissionLimits limits;
  Q4T_CHECK(ResolveAdmissionLimits(options, 32, &limits));
  Q4T_CHECK(limits.inflight == 64 && limits.queued == 32);
  Q4T_CHECK(ResolveAdmissionLimits(options, 2, &limits));
  Q4T_CHECK(limits.inflight == 32 && limits.queued == 30);
  options.max_queued_requests = 40;
  Q4T_CHECK(ResolveAdmissionLimits(options, 32, &limits));
  Q4T_CHECK(limits.queued == 40);
  Q4T_CHECK(!ResolveAdmissionLimits(options, 2, &limits));
  Q4T_CHECK(limits.inflight == 64 && limits.queued == 40);
  options.max_inflight_requests = 1;
  options.max_queued_requests = -1;
  Q4T_CHECK(ResolveAdmissionLimits(options, 2, &limits));
  Q4T_CHECK(limits.inflight == 1 && limits.queued == 0);
  for (int slots : {0, -1, 8193})
    Q4T_CHECK(!ResolveAdmissionLimits(options, slots, &limits));
  options.max_inflight_requests = -1;
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options));
  Q4T_CHECK(!ResolveAdmissionLimits(options, 1, &limits));
  return true;
}

Q4T_TEST(serve_default_is_single_text_greedy) {
  auto options = Defaults();
  Q4T_CHECK(Parse({}, &options));
  const auto capabilities = CapabilitiesFor(options);
  Q4T_CHECK(options.max_seq == 1 && !options.no_mtp && !options.allow_media);
  Q4T_CHECK(!options.mtp_suffix);
  Q4T_CHECK(capabilities.Experimental());
  Q4T_CHECK(Parse({"--max-seq", "1", "--max-prefill", "8192", "--max-len",
                   "208896", "--no-mtp"},
                  &options));
  Q4T_CHECK(!CapabilitiesFor(options).Experimental());
  return true;
}

Q4T_TEST(serve_capabilities_allow_explicit_combinations) {
  for (int mask = 0; mask < 8; ++mask) {
    auto options = Defaults();
    options.no_mtp = mask & 1;
    options.allow_media = mask & 2;
    options.max_seq = mask & 4 ? 2 : 1;
    const bool supported = !(mask & 2) || !(mask & 4);
    Q4T_CHECK(q4t::server::ValidateServerOptions(options).ok() == supported);
    const auto c = CapabilitiesFor(options);
    Q4T_CHECK(c.mtp == !(mask & 1));
    Q4T_CHECK(c.media == bool(mask & 2));
    Q4T_CHECK(c.multiple_sequences == bool(mask & 4));
    Q4T_CHECK(c.Experimental() == (c.mtp || c.media || c.multiple_sequences));
  }
  auto options = Defaults();
  Q4T_CHECK(Parse({"--mtp", "--no-mtp"}, &options));
  Q4T_CHECK(!CapabilitiesFor(options).mtp);
  Q4T_CHECK(Parse({"--no-mtp", "--mtp"}, &options));
  Q4T_CHECK(CapabilitiesFor(options).mtp);
  return true;
}

Q4T_TEST(serve_rejects_malformed_numeric_options) {
  for (const auto flag :
       {"--port", "--operations-port", "--max-seq", "--max-len",
        "--max-prefill", "--max-tokens", "--mem-fraction"}) {
    for (const auto value : {"", "junk", "1tail", " 1", "1 ", "--mtp",
                             "9999999999999999999999999999999999999999"}) {
      auto options = Defaults();
      Q4T_CHECK(!Parse({flag, value}, &options));
      Q4T_CHECK(options.max_seq == 1 && !options.no_mtp);
    }
    auto options = Defaults();
    Q4T_CHECK(!Parse({flag}, &options));
  }
  for (const auto value : {"0", "-1", "1.5", "2147483647"}) {
    auto options = Defaults();
    Q4T_CHECK(!Parse({"--max-seq", value}, &options));
  }
  for (const auto value : {"nan", "inf", "-inf", "0", "-0.1", "1.01"}) {
    auto options = Defaults();
    Q4T_CHECK(!Parse({"--mem-fraction", value}, &options));
  }
  return true;
}

Q4T_TEST(serve_mtp_k_is_explicit_and_bounded) {
  auto options = Defaults();
  Q4T_CHECK(Parse({}, &options));
  Q4T_CHECK(options.mtp_k == 3);  // serve default (measured optimum)
  Q4T_CHECK(Parse({"--mtp", "--mtp-k", "4"}, &options));
  Q4T_CHECK(options.mtp_k == 4);
  Q4T_CHECK(Parse({"--mtp-k", "1"}, &options));
  Q4T_CHECK(options.mtp_k == 1);
  Q4T_CHECK(Parse({"--mtp-k", "16"}, &options));
  Q4T_CHECK(options.mtp_k == 16);
  for (const auto value : {"0", "-1", "17", "1.5", "junk"}) {
    auto rejected = Defaults();
    Q4T_CHECK(!Parse({"--mtp-k", value}, &rejected));
    Q4T_CHECK(rejected.mtp_k == 3);
  }
  return true;
}

Q4T_TEST(serve_validates_before_load_and_preserves_failed_parse) {
  auto options = Defaults();
  Q4T_CHECK(!Parse({"--mtp", "--port", "65536"}, &options));
  Q4T_CHECK(!options.no_mtp && options.port == 8000);
  Q4T_CHECK(!Parse({"--host", "not-an-address"}, &options));
  Q4T_CHECK(!Parse({"--model-dir", ""}, &options));
  Q4T_CHECK(!Parse({"--unknown"}, &options));
  Q4T_CHECK(!Parse({"--max-tokens", "0"}, &options));
  Q4T_CHECK(!Parse({"--max-len", "-1"}, &options));
  Q4T_CHECK(!Parse({"--max-prefill", "-1"}, &options));
  Q4T_CHECK(Parse({"--port", "65535", "--max-prefill", "0", "--max-len", "0",
                   "--mem-fraction", "1", "--no-budget"},
                  &options));
  options.max_seq = 0;
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
  options = Defaults();
  options.mem_fraction = std::numeric_limits<double>::quiet_NaN();
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
  return true;
}

Q4T_TEST(serve_prefill_bound_precedes_workspace_sizing) {
  for (const auto value : {"0", "8192"}) {
    auto options = Defaults();
    Q4T_CHECK(Parse({"--max-prefill", value}, &options));
    Q4T_CHECK(q4t::server::ValidateServerOptions(options).ok());
  }
  for (const auto value : {"8193", "214748365", "2147483647"}) {
    auto options = Defaults();
    options.max_prefill = 8192;
    Q4T_CHECK(!Parse({"--mtp", "--max-prefill", value}, &options));
    Q4T_CHECK(options.max_prefill == 8192 && !options.no_mtp);
  }
  // ChatServer::Start also calls validation for programmatic options before
  // loading the tokenizer or invoking any workspace sizing function.
  for (int value : {8193, 214748365, std::numeric_limits<int>::max()}) {
    auto options = Defaults();
    options.max_prefill = value;
    Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
    options.no_budget = true;
    Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
  }
  return true;
}

Q4T_TEST(serve_decode_batch_fits_effective_forward_rows) {
  for (bool no_budget : {false, true}) {
    for (auto mode : {StartupPlanMode::kAuto, StartupPlanMode::kOff,
                      StartupPlanMode::kRequired}) {
      auto options = Defaults();
      options.no_mtp = true;
      options.no_budget = no_budget;
      options.startup_plan = mode;
      options.max_prefill = 1;
      options.max_seq = 2;
      Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
      options.max_seq = 1;
      Q4T_CHECK(q4t::server::ValidateServerOptions(options).ok());
      options.max_prefill = 0;
      options.max_seq = q4t::runtime::kDefaultMaxPrefill;
      Q4T_CHECK(q4t::server::ValidateServerOptions(options).ok());
      ++options.max_seq;
      Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
    }
  }
  auto options = Defaults();
  Q4T_CHECK(
      !Parse({"--no-mtp", "--max-seq", "2", "--max-prefill", "1"}, &options));
  Q4T_CHECK(options.max_seq == 1 && options.max_prefill == 0 &&
            !options.no_mtp);
  Q4T_CHECK(
      Parse({"--no-mtp", "--max-seq", "2", "--max-prefill", "2"}, &options));
  return true;
}

Q4T_TEST(serve_trace_options_are_explicit_and_bounded) {
  auto options = Defaults();
  Q4T_CHECK(options.moe_trace_dir.empty());
  Q4T_CHECK(!Parse({"--moe-trace-dir", ".q4t-work/trace"}, &options));
  Q4T_CHECK(options.moe_trace_dir.empty());
  Q4T_CHECK(Parse({"--moe-trace-dir", ".q4t-work/trace", "--moe-trace-workload",
                   ".q4t-work/workload.json", "--moe-trace-max-mib", "128"},
                  &options));
  Q4T_CHECK(options.moe_trace_max_mib == 128);
  for (const auto value : {"0", "4097", "1.5", "-1", "nan"}) {
    Q4T_CHECK(!Parse({"--moe-trace-max-mib", value}, &options));
    Q4T_CHECK(options.moe_trace_max_mib == 128);
  }
  return true;
}

Q4T_TEST(serve_startup_plan_modes_are_explicit_and_transactional) {
  auto options = Defaults();
  Q4T_CHECK(Parse({}, &options));
  Q4T_CHECK(options.startup_plan == StartupPlanMode::kAuto);
  Q4T_CHECK(Parse({"--startup-plan", "required"}, &options));
  Q4T_CHECK(options.startup_plan == StartupPlanMode::kRequired);
  for (const auto value : {"", "on", "true", "AUTO", "--no-mtp"}) {
    Q4T_CHECK(!Parse({"--startup-plan", value}, &options));
    Q4T_CHECK(options.startup_plan == StartupPlanMode::kRequired);
  }
  Q4T_CHECK(!Parse({"--startup-plan"}, &options));
  Q4T_CHECK(Parse({"--startup-plan", "off", "--allow-media", "--no-mtp"},
                  &options));
  Q4T_CHECK(options.startup_plan == StartupPlanMode::kOff);
  Q4T_CHECK(Parse({"--startup-plan", "auto"}, &options));
  Q4T_CHECK(options.startup_plan == StartupPlanMode::kAuto);
  options.startup_plan = static_cast<StartupPlanMode>(99);
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options).ok());
  return true;
}

Q4T_TEST(serve_media_supported_profile_and_client_policy) {
  auto options = Defaults();
  Q4T_CHECK(Parse({"--allow-media"}, &options));
  Q4T_CHECK(options.allow_media && !options.no_mtp);
  Q4T_CHECK(Parse({"--allow-media", "--no-mtp", "--max-seq", "1",
                   "--client-policy-file", "/explicit-policy"}, &options));
  Q4T_CHECK(options.allow_media && options.no_mtp);
  Q4T_CHECK(Parse({"--mtp"}, &options));
  Q4T_CHECK(options.allow_media && !options.no_mtp);
  for (const auto rejected :
       {std::initializer_list<std::string_view>{"--max-seq", "2"},
        {"--no-budget"},
        {"--host", "0.0.0.0"},
        {"--moe-resident-slots", "1"},
        {"--moe-trace-dir", "/trace"}}) {
    Q4T_CHECK(!Parse(rejected, &options));
    Q4T_CHECK(options.allow_media && !options.no_mtp && options.max_seq == 1);
  }
  return true;
}

Q4T_TEST(serve_media_state_cache_keeps_slot_and_execution_guards) {
  auto options = Defaults();
  Q4T_CHECK(Parse(
      {"--allow-media", "--no-mtp", "--max-len", "8192", "--session-cache-dir",
       ".q4t-work/unused", "--prefix-cache-dir", ".q4t-work/unused-prefix"},
      &options));
  options.no_mtp = false;
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options));
  options.seq_capacities = {options.max_len};
  Q4T_CHECK(q4t::server::ValidateServerOptions(options));
  options.max_seq = 2;
  options.seq_capacities.push_back(options.max_len);
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options));
  options.max_seq = 1;
  options.seq_capacities.resize(1);
  options.no_budget = true;
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options));
  options.no_budget = false;
  options.moe_trace_dir = ".q4t-work/unused-trace";
  Q4T_CHECK(!q4t::server::ValidateServerOptions(options));
  return true;
}

Q4T_TEST(serve_suffix_requires_text_fixed_k3) {
  auto options = Defaults();
  Q4T_CHECK(Parse({"--mtp-suffix", "--max-len", "262144"}, &options));
  Q4T_CHECK(options.mtp_suffix && options.mtp_subset_head.empty());
  Q4T_CHECK(Parse({"--mtp-subset-head", "/explicit-artifact"}, &options));
  for (const auto concurrency : {"1", "2", "4", "16", "32"})
    Q4T_CHECK(Parse({"--max-seq", concurrency}, &options));
  for (const auto args :
       {std::initializer_list<std::string_view>{"--mtp-suffix", "--no-mtp"},
        {"--mtp-suffix", "--mtp-k", "2"},
        {"--mtp-suffix", "--allow-media"},
        {"--mtp-suffix", "--max-len", "262145"}}) {
    auto rejected = Defaults();
    Q4T_CHECK(!Parse(args, &rejected));
    Q4T_CHECK(!rejected.mtp_suffix);
  }
  return true;
}

Q4T_TEST(serve_operations_port_is_explicit_distinct_and_transactional) {
  auto options = Defaults();
  Q4T_CHECK(options.operations_port == 0);
  Q4T_CHECK(Parse({"--operations-port", "18108"}, &options));
  Q4T_CHECK(options.operations_port == 18108);
  for (const auto value : {"-1", "65536", "8000"}) {
    auto rejected = Defaults();
    Q4T_CHECK(!Parse({"--operations-port", value}, &rejected));
    Q4T_CHECK(rejected.operations_port == 0);
  }
  Q4T_CHECK(Parse({"--operations-port", "0"}, &options));
  Q4T_CHECK(options.operations_port == 0);
  return true;
}

Q4T_TEST(serve_base_tts_assets_are_independent_and_name_conflicts_are_atomic) {
  ServerOptions options;
  Q4T_CHECK(
      Parse({"--model-dir", "/model", "--tts-base-model-dir", "/assets/base"},
            &options));
  Q4T_CHECK(options.tts_base_model_dir == "/assets/base" &&
            options.tts_model_dir.empty());
  Q4T_CHECK(!Parse(
      {"--model-dir", "/model", "--tts-base-model-dir", "relative"}, &options));
  Q4T_CHECK(!Parse({"--model-dir", "/model", "--tts-base-model-dir", "/base",
                    "--model-alias", "qwen3-tts-12hz-1.7b-base"},
                   &options));
  Q4T_CHECK(options.tts_base_model_dir == "/assets/base");
  Q4T_CHECK(Parse({"--model-dir", "/model", "--tts-base-model-dir", "/base",
                   "--tts-model-dir", "/custom"},
                  &options));
  Q4T_CHECK(options.tts_base_model_dir == "/base" &&
            options.tts_model_dir == "/custom");
  return true;
}

#include "q4t/server/http_request.h"
#include "q4t/server/application_routes.h"
#include "q4t/test.h"

#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <barrier>
#include <string>
#include <thread>
#include <vector>

#include "q4t/server/file_input.h"
#include "q4t/server/voice_request.h"
#include "q4t/server/request_json.h"
#include "q4t/server/request_limits.h"
#include "q4t/trace/sha256.h"

namespace {

bool Read(const std::string& wire, std::string* body) {
  int fd[2];
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) != 0) return false;
  // A separate writer also exercises partial reads and requests > socket buf.
  std::thread writer([&] {
    size_t offset = 0;
    while (offset < wire.size()) {
      const ssize_t n = send(fd[0], wire.data() + offset,
                             wire.size() - offset, MSG_NOSIGNAL);
      if (n <= 0) break;
      offset += static_cast<size_t>(n);
    }
    shutdown(fd[0], SHUT_WR);
  });
  std::string method, path;
  const bool ok = q4t::server::ReadHttpRequest(fd[1], &method, &path, body);
  shutdown(fd[1], SHUT_RDWR);
  writer.join();
  close(fd[0]);
  close(fd[1]);
  return ok;
}

}  // namespace

Q4T_TEST(http_transcription_large_fixed_and_chunked_binary_bodies) {
  using namespace q4t::server;
  std::string payload(128 * 1024, 'x');
  payload[127] = '\0';
  payload.back() = static_cast<char>(0xff);
  for (const auto target : {"/v1/audio/transcriptions",
                            "/v1/audio/transcriptions?invalid=1"}) {
    Q4T_CHECK(IsTranscriptionTarget(target));
    const auto prefix = "POST " + std::string(target) +
                        " HTTP/1.1\r\nHost: local\r\n";
    std::string body;
    Q4T_CHECK(Read(prefix + "Content-Length: 131072\r\n\r\n" + payload,
                    &body));
    Q4T_CHECK(body == payload);
    Q4T_CHECK(Read(prefix + "Transfer-Encoding: chunked\r\n\r\n20000\r\n" +
                      payload + "\r\n0\r\n\r\n", &body));
    Q4T_CHECK(body == payload);
  }
  Q4T_CHECK(!IsTranscriptionTarget("/v1/audio/transcriptions-extra"));
  Q4T_CHECK(!IsTranscriptionTarget("/v1/audio/transcriptions/"));
  return true;
}

Q4T_TEST(http_transcription_limits_reject_before_body_read) {
  using namespace q4t::server;
  struct Case {
    const char* path;
    const char* frame;
    size_t admitted_limit;
    int status;
    size_t occupied;
  };
  const Case cases[] = {
      {"/v1/audio/transcriptions", "Content-Length: 33554433\r\n\r\n",
       kChatBodyBytes, 413, 0},
      {"/v1/audio/transcriptions", "Content-Length: 8193\r\n\r\n",
       8192, 413, 0},
      {"/v1/audio/transcriptions", "Transfer-Encoding: chunked\r\n\r\n"
                                     "2000001\r\n",
       kChatBodyBytes, 413, 0},
      {"/v1/audio/transcriptions", "Transfer-Encoding: chunked\r\n\r\n"
                                     "2001\r\n",
       8192, 413, 0},
      {"/v1/audio/transcriptions-extra", "Content-Length: 4097\r\n\r\n",
       kChatBodyBytes, 413, 0},
      {"/v1/audio/transcriptions", "Content-Length: 8192\r\n\r\n",
       kChatBodyBytes, 503, 1}};
  for (const auto& c : cases) {
    int fd[2];
    Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
    const auto wire = "POST " + std::string(c.path) +
                      " HTTP/1.1\r\nHost: local\r\n" + c.frame;
    Q4T_CHECK(send(fd[0], wire.data(), wire.size(), MSG_NOSIGNAL) ==
                static_cast<ssize_t>(wire.size()));
    HttpBodyBudget budget(8192);
    HttpBodyLease occupied(budget), lease(budget);
    if (c.occupied) Q4T_CHECK(occupied.Acquire(c.occupied));
    HttpRequestHeaders headers;
    std::string method, target, body;
    int status = 0;
    const bool ok = ReadHttpRequest(
        fd[1], &method, &target, &body, 500, &lease, &status, &headers, [&] {
          headers.body_limit = c.admitted_limit;
          return true;
        });
    close(fd[0]);
    close(fd[1]);
    Q4T_CHECK(!ok && status == c.status && body.empty());
    Q4T_CHECK(budget.Used() == c.occupied);
    Q4T_CHECK(headers.failure ==
                (c.status == 413 ? HttpReceiveFailure::kBodyTooLarge
                                 : HttpReceiveFailure::kBodyCapacity));
  }
  return true;
}

Q4T_TEST(http_conversation_routes_are_scoped_business_operations) {
  using namespace q4t::server;
  for (const auto path : {"/v1/conversations", "/v1/conversations/conv_1",
                          "/v1/conversations/conv_1/items",
                          "/v1/conversations/conv_1/items/item_1"}) {
    for (const auto method : {"GET", "POST", "DELETE"}) {
      Q4T_CHECK(ClassifyHttpConnection(method, path) ==
                HttpConnectionClass::kBusiness);
      const bool allowed = std::string_view(path) == "/v1/conversations"
                               ? std::string_view(method) == "POST"
                           : std::string_view(path).ends_with("/items")
                               ? std::string_view(method) != "DELETE"
                           : std::string_view(path).ends_with("/item_1")
                               ? std::string_view(method) != "POST"
                               : true;
      Q4T_CHECK(ConversationMethodAllowed(method, path) == allowed);
      Q4T_CHECK(
          ConversationMethodAllowed(
              method, std::string(path) +
                          "?include%5B%5D=message.output_text.logprobs") ==
          allowed);
    }
  }
  for (const auto path : {"/v1/conversations/", "/v1/conversationsx",
                          "/v1/conversations/../items", "/v1/conversations/a#b",
                          "/v1/conversations/a/items/", "/v1/conversations/a/b",
                          "/v1/conversations/a/items/b/c"})
    Q4T_CHECK(!ConversationMethodAllowed("GET", path));
  return true;
}

Q4T_TEST(http_conversation_body_uses_shared_budget_before_reading) {
  using namespace q4t::server;
  for (const auto path : {"/v1/conversations", "/v1/conversations/conv_1",
                          "/v1/conversations/conv_1/items?include%5B%5D=x"}) {
    const auto prefix =
        "POST " + std::string(path) +
        " HTTP/1.1\r\nHost: local\r\nContent-Length: 8192\r\n\r\n";
    std::string body;
    Q4T_CHECK(Read(prefix + std::string(8192, 'x'), &body));
    Q4T_CHECK(body.size() == 8192);
    int fd[2];
    Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
    Q4T_CHECK(send(fd[0], prefix.data(), prefix.size(), MSG_NOSIGNAL) > 0);
    HttpBodyBudget budget(8192);
    HttpBodyLease occupied(budget), lease(budget);
    Q4T_CHECK(occupied.Acquire(1));
    HttpRequestHeaders headers;
    std::string method, target;
    int status = 0;
    const bool ok = ReadHttpRequest(fd[1], &method, &target, &body, 500, &lease,
                                    &status, &headers);
    close(fd[0]);
    close(fd[1]);
    Q4T_CHECK(!ok && status == 503 && budget.Used() == 1);
    Q4T_CHECK(headers.failure == HttpReceiveFailure::kBodyCapacity);
  }
  return true;
}

Q4T_TEST(http_stored_chat_routes_and_body_budget) {
  using namespace q4t::server;
  for (const auto path : {"/v1/chat/completions?metadata%5Btag%5D=x",
                          "/v1/chat/completions/chat_1",
                          "/v1/chat/completions/chat_1/messages?limit=1"}) {
    Q4T_CHECK(StoredChatMethodAllowed("GET", path));
    Q4T_CHECK(ClassifyHttpConnection("GET", path) == HttpConnectionClass::kObservation);
  }
  Q4T_CHECK(ClassifyHttpConnection("POST", "/v1/chat/completions") == HttpConnectionClass::kBusiness);
  Q4T_CHECK(ClassifyHttpConnection("POST", "/v1/chat/completions/chat_1") == HttpConnectionClass::kObservation);
  for (const auto path : {"/v1/chat/completions/", "/v1/chat/completions/../messages",
                          "/v1/chat/completions/a#b", "/v1/chat/completions/a/messages/b"})
    Q4T_CHECK(!StoredChatMethodAllowed("GET", path));
  const std::string prefix = "POST /v1/chat/completions/chat_1 HTTP/1.1\r\nHost: local\r\nContent-Length: 8192\r\n\r\n";
  std::string body;
  Q4T_CHECK(Read(prefix + std::string(8192, 'x'), &body));
  int fd[2]; Q4T_CHECK(!socketpair(AF_UNIX, SOCK_STREAM, 0, fd));
  Q4T_CHECK(send(fd[0], prefix.data(), prefix.size(), MSG_NOSIGNAL) > 0);
  HttpBodyBudget budget(8192); HttpBodyLease held(budget), incoming(budget);
  Q4T_CHECK(held.Acquire(1));
  HttpRequestHeaders headers; std::string method, path; int status = 0;
  const bool ok = ReadHttpRequest(fd[1], &method, &path, &body, 500, &incoming, &status, &headers);
  close(fd[0]); close(fd[1]);
  Q4T_CHECK(!ok && status == 503 && budget.Used() == 1 && headers.failure == HttpReceiveFailure::kBodyCapacity);
  return true;
}

Q4T_TEST(http_connection_classification_exact_route_and_method) {
  using namespace q4t::server;
  for (const auto path : {"/metrics", "/v1/config", "/v1/capabilities",
                           "/v1/models"}) {
    Q4T_CHECK(ClassifyHttpConnection("GET", path) ==
              HttpConnectionClass::kObservation);
    for (const auto method : {"POST", "HEAD", "get"})
      Q4T_CHECK(ClassifyHttpConnection(method, path) ==
                HttpConnectionClass::kBusiness);
    for (const auto suffix : {"?x=1", "/", "/anything"})
      Q4T_CHECK(ClassifyHttpConnection("GET", std::string(path) + suffix) ==
                (std::string_view(path) == "/v1/models" &&
                         std::string_view(suffix) != "?x=1"
                     ? HttpConnectionClass::kObservation
                     : HttpConnectionClass::kBusiness));
  }
  for (const auto path : {"/healthz", "/livez", "/readyz"})
    Q4T_CHECK(ClassifyHttpConnection("GET", path) ==
              HttpConnectionClass::kControl);
  Q4T_CHECK(ClassifyHttpConnection("POST", "/v1/requests/cancel") ==
            HttpConnectionClass::kControl);
  Q4T_CHECK(ClassifyHttpConnection("GET", "/v1/requests/cancel") ==
            HttpConnectionClass::kBusiness);
  Q4T_CHECK(ClassifyHttpConnection("POST", "/v1/completions") ==
            HttpConnectionClass::kBusiness);
  Q4T_CHECK(ClassifyHttpConnection("DELETE", "/v1/models/org%2Falias") ==
            HttpConnectionClass::kControl);
  return true;
}

Q4T_TEST(http_connection_atomic_limit_and_reuse) {
  using q4t::server::AcquireHttpConnection;
  std::atomic<int> count{0}, successes{0};
  std::barrier start(16), acquired(16);
  std::vector<std::thread> callers;
  for (int i = 0; i < 16; ++i) {
    callers.emplace_back([&] {
      start.arrive_and_wait();
      const bool admitted = AcquireHttpConnection(count, 4);
      if (admitted) successes.fetch_add(1);
      acquired.arrive_and_wait();  // No release until every attempt finished.
      if (admitted) count.fetch_sub(1);
    });
  }
  for (auto& caller : callers) caller.join();
  Q4T_CHECK(successes.load() == 4 && count.load() == 0);
  for (int i = 0; i < 4; ++i) Q4T_CHECK(AcquireHttpConnection(count, 4));
  Q4T_CHECK(!AcquireHttpConnection(count, 4) && count.load() == 4);
  return true;
}

Q4T_TEST(http_valid_length_and_header_names) {
  std::string body;
  Q4T_CHECK(Read("POST /v1/chat/completions HTTP/1.1\r\nHost: local\r\n"
                 "cOnTeNt-LeNgTh: \t2 \r\nX-Content-Length: 99\r\n\r\n{}",
                 &body));
  Q4T_CHECK(body == "{}");
  Q4T_CHECK(Read("GET /healthz HTTP/1.0\r\n\r\n", &body));
  Q4T_CHECK(body.empty());
  Q4T_CHECK(Read("POST / HTTP/1.1\r\nHost: local\r\n"
                 "X-Content-Length: 2\r\n\r\n{}", &body));
  Q4T_CHECK(body.empty());  // Unknown field must not become framing.
  return true;
}

Q4T_TEST(http_rejects_duplicate_or_empty_authorization) {
  std::string body;
  for (const char* fields : {
           "Authorization:\r\n",
           "Authorization: Bearer first\r\naUtHoRiZaTiOn: Bearer second\r\n"}) {
    Q4T_CHECK(!Read(std::string("GET /v1/models HTTP/1.1\r\nHost: local\r\n") +
                     fields + "\r\n", &body));
  }
  return true;
}

Q4T_TEST(http_rejects_ambiguous_framing) {
  std::string body;
  for (const char* fields : {
           "Content-Length: 2junk", "Content-Length: +2",
           "Content-Length: -2", "Content-Length: 2,2",
           "Content-Length: 99999999999999999999999999999999",
           "Content-Length: 16777217", "Content-Length:",
           "Content-Length: 2\r\nContent-Length: 99",
           "Content-Length: 2\r\nContent-Length: 2",
           "Transfer-Encoding: chunked",
           "Content-Length: 2\r\nTransfer-Encoding: chunked",
           "Expect: unsupported", " Content-Length: 2",
           "Content-Length : 2", "BrokenHeader", "Host: second"}) {
    Q4T_CHECK(!Read(std::string("POST / HTTP/1.1\r\nHost: local\r\n") +
                       fields + "\r\n\r\n{}", &body));
  }
  Q4T_CHECK(!Read("POST / HTTP/1.1\r\nHost: local\r\n"
                  "Content-Length: 3\r\n\r\n{}", &body));
  return true;
}

Q4T_TEST(http_request_line_and_header_budget) {
  std::string body;
  for (const char* line : {"POST / HTTP/9", "POST  / HTTP/1.1",
                           "POST http://local/ HTTP/1.1", "POST /#x HTTP/1.1"})
    Q4T_CHECK(!Read(std::string(line) + "\r\nHost: local\r\n\r\n", &body));
  Q4T_CHECK(!Read("GET / HTTP/1.1\r\n\r\n", &body));
  const std::string prefix = "GET / HTTP/1.1\r\nHost: local\r\nX: ";
  Q4T_CHECK(Read(prefix + std::string(65536 - prefix.size() - 4, 'x') +
                    "\r\n\r\n", &body));
  Q4T_CHECK(!Read(prefix + std::string(65537 - prefix.size() - 4, 'x') +
                     "\r\n\r\n", &body));
  return true;
}

Q4T_TEST(http_body_capacity_and_trailing_bytes) {
  std::string body;
  const std::string data(16 * 1024 * 1024, 'x');
  Q4T_CHECK(Read("POST /v1/chat/completions HTTP/1.1\r\nHost: local\r\n"
                 "Content-Length: 16777216\r\n\r\n" + data, &body));
  Q4T_CHECK(body == data);
  Q4T_CHECK(Read("POST / HTTP/1.1\r\nHost: local\r\n"
                 "Content-Length: 2\r\n\r\n{}trailing", &body));
  Q4T_CHECK(body == "{}");  // Caller closes without dispatching another request.
  return true;
}

Q4T_TEST(http_application_inline_50m_preserves_original_decoded_bytes) {
  using namespace q4t::server;
  // Real 50,000,000-byte binary source; the document decoder is deliberately
  // outside this transport/acquisition test. Two source bytes need one pad.
  std::string encoded(4 * ((kFileInputBytes + 2) / 3), 'A');
  encoded.back() = '=';
  std::string payload =
      R"({"input":[{"role":"user","content":[{"type":"input_file",)"
      R"("filename":"capacity.bin","file_data":")" +
      encoded + R"("}]}]})";
  std::string body;
  Q4T_CHECK(
      Read("POST /v1/responses HTTP/1.1\r\nHost: local\r\n"
           "Content-Length: " +
               std::to_string(payload.size()) + "\r\n\r\n" + payload,
           &body));
  Q4T_CHECK(body == payload && body.size() < kChatBodyBytes);
  q4t::io::Json request;
  Q4T_CHECK(q4t::io::ParseJson(body, &request, true, kApplicationJsonLimits));
  const auto& part =
      request.GetArray("input")->array[0].GetArray("content")->array[0];
  FileInputSource source;
  Q4T_CHECK(
      ParseFileInputSource(part, FileInputProfile::kResponses, "input", &source)
          .ok());
  FileInputBudget budget;
  FileInputContent content;
  BinaryAccess access{
      "capacity",
      std::chrono::steady_clock::now() + std::chrono::seconds(30),
      {}};
  Q4T_CHECK(
      ReadLocalFileInput(nullptr, access, source, &budget, &content).ok());
  Q4T_CHECK(content.bytes == std::string(kFileInputBytes, '\0'));
  Q4T_CHECK(budget.used_bytes == kFileInputBytes && budget.used_files == 1);
  const auto bytes =
      std::span(reinterpret_cast<const uint8_t*>(content.bytes.data()),
                content.bytes.size());
  Q4T_CHECK(content.sha256 == q4t::trace::HexDigest(q4t::trace::Sha256(bytes)));
  // The nested tool-argument/schema JSON parser keeps its own 16 MiB bound.
  q4t::io::Json arguments;
  Q4T_CHECK(!q4t::io::ParseJson(body, &arguments, true, kSchemaJsonLimits));
  budget = {};
  budget.max_bytes = kFileInputBytes - 1;
  Q4T_CHECK(ReadLocalFileInput(nullptr, access, source, &budget, &content)
                .http_status == 413);
  Q4T_CHECK(content.bytes.empty());
  return true;
}

Q4T_TEST(http_application_ceiling_and_aggregate_keep_control_independent) {
  using namespace q4t::server;
  HttpBodyBudget budget(kAggregateChatBodyBytes),
      control(kCancelBodyBudgetBytes);
  {
    HttpBodyLease first(budget), second(budget), cancellation(control);
    Q4T_CHECK(first.Acquire(kChatBodyBytes) && second.Acquire(kChatBodyBytes));
    Q4T_CHECK(cancellation.Acquire(4096));
    for (const auto* route :
         {"/v1/chat/completions", "/v1/chat/preflight", "/v1/responses",
          "/v1/moderations",
          "/v1/responses/input_tokens", "/v1/responses/compact",
          "/v1/conversations", "/v1/conversations/conv_1/items"}) {
      for (const size_t size : {size_t{1}, kChatBodyBytes + 1}) {
        int fd[2];
        Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
        const auto wire = "POST " + std::string(route) +
                          " HTTP/1.1\r\nHost: local\r\nContent-Length: " +
                          std::to_string(size) + "\r\n\r\n";
        send(fd[0], wire.data(), wire.size(), MSG_NOSIGNAL);
        HttpBodyLease lease(budget);
        HttpRequestHeaders headers;
        std::string method, path, body;
        int status = 0;
        const bool ok = ReadHttpRequest(fd[1], &method, &path, &body, 100,
                                        &lease, &status, &headers);
        close(fd[0]);
        close(fd[1]);
        Q4T_CHECK(!ok && status == (size == 1 ? 503 : 413));
        Q4T_CHECK(body.empty() && budget.Used() == kAggregateChatBodyBytes);
      }
    }
    Q4T_CHECK(control.Used() == 4096);
  }
  Q4T_CHECK(budget.Used() == 0 && control.Used() == 0);
  return true;
}

Q4T_TEST(http_preflight_body_uses_shared_chat_reservation) {
  using namespace q4t::server;
  std::string body;
  Q4T_CHECK(Read("POST /v1/chat/preflight HTTP/1.1\r\nHost: local\r\n"
                 "Content-Length: 5000\r\n\r\n" + std::string(5000, 'x'), &body));
  Q4T_CHECK(body.size() == 5000);
  HttpBodyBudget budget(8);
  HttpBodyLease chat(budget);
  Q4T_CHECK(chat.Acquire(8));
  int fd[2];
  Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
  const std::string wire = "POST /v1/chat/preflight HTTP/1.1\r\nHost: local\r\n"
                           "Content-Length: 1\r\n\r\n";
  Q4T_CHECK(send(fd[0], wire.data(), wire.size(), MSG_NOSIGNAL) > 0);
  std::string method, path;
  HttpBodyLease preflight(budget);
  int status = 400;
  const bool ok = ReadHttpRequest(fd[1], &method, &path, &body, 100,
                                   &preflight, &status);
  close(fd[0]);
  close(fd[1]);
  Q4T_CHECK(!ok && status == 503 && budget.Used() == 8);
  return true;
}

Q4T_TEST(http_absolute_deadline_and_body_budget) {
  using namespace q4t::server;
  HttpBodyBudget budget(8);
  {
    HttpBodyLease a(budget), b(budget);
    Q4T_CHECK(a.Acquire(8));
    Q4T_CHECK(!b.Acquire(1));
    Q4T_CHECK(budget.Used() == 8);
  }
  Q4T_CHECK(budget.Used() == 0);
  for (bool body_phase : {false, true}) {
    int fd[2];
    Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
    std::thread writer([&] {
      const std::string prefix = body_phase ?
          "POST /v1/chat/completions HTTP/1.1\r\nHost: local\r\n"
          "Content-Length: 8\r\n\r\n" : "GET / HTTP/1.1\r\nX: ";
      send(fd[0], prefix.data(), prefix.size(), MSG_NOSIGNAL);
      for (int i = 0; i < 5; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        if (send(fd[0], "x", 1, MSG_NOSIGNAL) < 0) break;
      }
    });
    std::string method, path, body;
    int status = 0;
    bool ok;
    {
      HttpBodyLease lease(budget);
      ok = ReadHttpRequest(fd[1], &method, &path, &body, 90, &lease, &status);
    }
    shutdown(fd[1], SHUT_RDWR);
    writer.join();
    close(fd[0]);
    close(fd[1]);
    Q4T_CHECK(!ok && status == 408 && budget.Used() == 0);
  }
  int fd[2];
  Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
  const std::string wire = "POST /v1/chat/completions HTTP/1.1\r\n"
                           "Host: local\r\nContent-Length: 9\r\n\r\n";
  send(fd[0], wire.data(), wire.size(), MSG_NOSIGNAL);
  std::string method, path, body;
  HttpBodyLease lease(budget);
  int status = 0;
  const bool ok = ReadHttpRequest(fd[1], &method, &path, &body, 1000,
                                   &lease, &status);
  close(fd[0]);
  close(fd[1]);
  Q4T_CHECK(!ok && status == 503 && budget.Used() == 0);
  return true;
}

Q4T_TEST(http_header_identity_and_pre_body_admission) {
  using namespace q4t::server;
  for (const auto& extra :
       {std::string("X-Request-Id: abc.1:trace\r\n"),
        std::string("X-Request-Id: abc\r\nx-request-id: abc\r\n"),
        std::string("X-Request-Id: bad id\r\n"),
        std::string("X-Request-Id: ") + std::string(129, 'x') + "\r\n",
        std::string("Content-Type: application/json\r\n")}) {
    int fd[2];
    Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
    const std::string wire =
        "POST /v1/chat/completions HTTP/1.1\r\nHost: t\r\n"
        "Content-Length: 8\r\nContent-Type: application/json\r\n" +
        extra + "\r\n";
    Q4T_CHECK(send(fd[0], wire.data(), wire.size(), MSG_NOSIGNAL) > 0);
    std::string method, path, body;
    HttpRequestHeaders headers;
    HttpBodyBudget budget(8);
    HttpBodyLease lease(budget);
    bool called = false;
    int status = 400;
    const bool ok = ReadHttpRequest(fd[1], &method, &path, &body, 200, &lease,
                                    &status, &headers, [&] {
                                      called = true;
                                      status = 503;
                                      return false;
                                    });
    close(fd[0]);
    close(fd[1]);
    Q4T_CHECK(!ok && body.empty() && budget.Used() == 0);
    if (extra.starts_with("X-Request-Id: abc.1")) {
      Q4T_CHECK(called && status == 503);
      Q4T_CHECK(headers.request_id == "abc.1:trace");
      Q4T_CHECK(headers.content_length == 8);
    } else {
      Q4T_CHECK(!called && status == 400 && !headers.error_param.empty());
    }
  }
  return true;
}

Q4T_TEST(http_moderations_uses_business_lane_and_normal_json_body_capacity) {
  using namespace q4t::server;
  Q4T_CHECK(ClassifyHttpConnection("POST", "/v1/moderations") ==
            HttpConnectionClass::kBusiness);
  const std::string payload = "{\"input\":\"" + std::string(8192, 'x') + "\"}";
  const std::string wire = "POST /v1/moderations HTTP/1.1\r\nHost: local\r\n"
                           "Content-Type: application/json\r\nContent-Length: " +
                           std::to_string(payload.size()) + "\r\n\r\n" + payload;
  std::string body;
  Q4T_CHECK(Read(wire, &body) && body == payload);
  return true;
}

Q4T_TEST(http_embeddings_uses_business_lane_and_normal_json_body_capacity) {
  using namespace q4t::server;
  Q4T_CHECK(ClassifyHttpConnection("POST", "/v1/embeddings") ==
            HttpConnectionClass::kBusiness);
  const std::string payload = "{\"model\":\"served\",\"input\":\"" +
                              std::string(8192, 'x') + "\"}";
  const std::string wire = "POST /v1/embeddings HTTP/1.1\r\nHost: local\r\n"
                           "Content-Type: application/json\r\nContent-Length: " +
                           std::to_string(payload.size()) + "\r\n\r\n" + payload;
  std::string body;
  Q4T_CHECK(Read(wire, &body) && body == payload);
  return true;
}

Q4T_TEST(http_voice_uploads_preserve_binary_fixed_and_chunked_bodies) {
  using namespace q4t::server;
  std::string payload(128 * 1024, 'x');
  payload[100] = '\0';
  for (auto path : {"/v1/audio/voices", "/v1/audio/voice_consents",
                    "/v1/audio/voice_consents/cons_a"}) {
    const auto prefix =
        "POST " + std::string(path) + " HTTP/1.1\r\nHost: local\r\n";
    std::string body;
    Q4T_CHECK(Read(prefix + "Content-Length: 131072\r\n\r\n" + payload, &body));
    Q4T_CHECK(body == payload);
    Q4T_CHECK(Read(prefix + "Transfer-Encoding: chunked\r\n\r\n20000\r\n" +
                       payload + "\r\n0\r\n\r\n",
                   &body));
    Q4T_CHECK(body == payload);
  }
  // Speech permits 4096 Unicode characters, not only 4096 wire bytes.
  std::string body;
  Q4T_CHECK(
      Read("POST /v1/audio/speech HTTP/1.1\r\nHost: local\r\nContent-Length: "
           "8192\r\n\r\n" +
               std::string(8192, 's'),
           &body));
  Q4T_CHECK(body.size() == 8192);
  return true;
}
Q4T_TEST(http_voice_body_limits_and_shared_admission_precede_upload) {
  using namespace q4t::server;
  for (auto path : {"/v1/audio/voices", "/v1/audio/voice_consents"}) {
    for (int mode : {0, 1, 2}) {
      int fd[2];
      Q4T_CHECK(socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == 0);
      const auto frame =
          mode == 0 ? "Content-Length: " + std::to_string(kVoiceFormBytes + 1) +
                          "\r\n\r\n"
          : mode == 1 ? "Transfer-Encoding: chunked\r\n\r\na10001\r\n"
                      : "Content-Length: 8192\r\n\r\n";
      const auto wire =
          "POST " + std::string(path) + " HTTP/1.1\r\nHost: local\r\n" + frame;
      Q4T_CHECK(send(fd[0], wire.data(), wire.size(), MSG_NOSIGNAL) ==
                static_cast<ssize_t>(wire.size()));
      HttpBodyBudget budget(8192);
      HttpBodyLease held(budget), incoming(budget);
      if (mode == 2) Q4T_CHECK(held.Acquire(1));
      HttpRequestHeaders headers;
      std::string method, target, body;
      int status = 0;
      const bool ok = ReadHttpRequest(fd[1], &method, &target, &body, 500,
                                      &incoming, &status, &headers);
      close(fd[0]);
      close(fd[1]);
      Q4T_CHECK(!ok && status == (mode == 2 ? 503 : 413) && body.empty());
      Q4T_CHECK(budget.Used() == (mode == 2 ? 1U : 0U));
    }
  }
  return true;
}

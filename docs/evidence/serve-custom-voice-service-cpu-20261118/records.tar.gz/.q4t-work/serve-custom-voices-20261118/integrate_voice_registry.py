from pathlib import Path
R=Path.cwd()
def edit(name,old,new):
 p=R/name;s=p.read_text();assert s.count(old)==1,(name,old,s.count(old));t=p.with_suffix(p.suffix+'.edit');t.write_text(s.replace(old,new));t.replace(p)
edit('include/q4t/server/object_store.h','  kAudio\n','  kAudio,\n  kVoiceConsent,\n  kVoice\n')
edit('src/server/object_protocol.h','    case ObjectKind::kAudio:\n      return "audio";','    case ObjectKind::kAudio:\n      return "audio";\n    case ObjectKind::kVoiceConsent:\n      return "voice_consent";\n    case ObjectKind::kVoice:\n      return "voice";')
edit('src/server/object_protocol.h','static_cast<int>(ObjectKind::kAudio)','static_cast<int>(ObjectKind::kVoice)')
edit('src/server/object_store.cpp','  if (kind == ObjectKind::kChat) prefix = "chatcmpl";','  if (kind == ObjectKind::kChat) prefix = "chatcmpl";\n  if (kind == ObjectKind::kVoiceConsent) prefix = "cons";')
edit('src/server/binary_store.cpp','  return (root.kind == ObjectKind::kFile && format == "q4t.file.v1") ||','  return (root.kind == ObjectKind::kVoiceConsent &&\n          format == "q4t.voice_consent.v1") ||\n         (root.kind == ObjectKind::kVoice && format == "q4t.voice.v1") ||\n         (root.kind == ObjectKind::kFile && format == "q4t.file.v1") ||')
edit('src/server/binary_store.cpp','       kind != ObjectKind::kInputSnapshot))','       kind != ObjectKind::kInputSnapshot &&\n       kind != ObjectKind::kVoiceConsent && kind != ObjectKind::kVoice))')
edit('src/server/object_retention.cpp','  } else if (kind == "chat") {','  } else if (kind == "voice_consent" &&\n             data.GetString("format") == "q4t.voice_consent.v1") {\n    inspector.Blob(data);\n  } else if (kind == "voice" &&\n             data.GetString("format") == "q4t.voice.v1") {\n    inspector.Blob(data);\n    inspector.Reference(data.Find("consent"));\n  } else if (kind == "chat") {')
for n,a,addition in [
 ('CMakeLists.txt','  src/server/speech_request.cpp','  src/server/voice_request.cpp\n  src/server/voice_language.cpp\n  src/server/voice_registry.cpp'),
 ('cmake/HostTestSources.cmake','  ${CMAKE_CURRENT_LIST_DIR}/../src/server/speech_request.cpp','  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_request.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_language.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_registry.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_voice_request_test.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_voice_registry_test.cpp'),
 ('cmake/ChatProtocolIdentity.cmake','  src/server/speech_request.cpp','  include/q4t/server/voice_request.h\n  include/q4t/server/voice_registry.h\n  src/server/voice_request.cpp\n  src/server/voice_language.cpp\n  src/server/voice_registry.cpp')]:edit(n,a,a+'\n'+addition)
edit('src/server/voice_registry.cpp','  for (const auto x : vector) value.array.push_back(Number(x));','  for (const auto x : vector) {\n    Json number;\n    number.type = Json::Type::kNumber;\n    number.number = x;\n    value.array.push_back(std::move(number));\n  }')
edit('src/server/voice_registry.cpp','  const auto id = root.id;','  const auto id = root.id;\n  const auto kind = root.kind;')
edit('src/server/voice_registry.cpp','  auto stored = Read(root.kind, id, access);','  auto stored = Read(kind, id, access);')
edit('src/server/voice_registry.cpp','  stored.value = Metadata(stored.value, root.kind);','  stored.value = Metadata(stored.value, kind);')
edit('src/server/voice_request.cpp','(!error || error->code.empty())','(!error || error->param.empty())')

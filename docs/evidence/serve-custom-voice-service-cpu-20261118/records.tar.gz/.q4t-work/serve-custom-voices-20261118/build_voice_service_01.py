from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,tarfile,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';T=R/'.q4t-work/serve-native-tts-20261118'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
modified=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
for n in modified+new:
 p=R/n
 if p.suffix not in ['.cpp','.h']:continue
 cmd=['clang-format',str(p)]
 if n not in new:
  diff=subprocess.check_output(['git','diff','-U0','--',n],text=True)
  lines=[]
  for start,count in re.findall(r'^@@ .*? \+(\d+)(?:,(\d+))? @@',diff,re.M):
   if count=='0':continue
   a=int(start);lines.append(f'--lines={a}:{a+int(count or 1)-1}')
  if not lines:continue
  cmd.extend(lines)
 out=subprocess.check_output(cmd);tmp=p.with_suffix(p.suffix+'.edit');tmp.write_bytes(out);tmp.replace(p)
new_tests=['tests/server_voice_verification_test.cpp','tests/server_voice_api_test.cpp']
required=[]
for n in new_tests:required+=re.findall(r'Q4T_TEST\(\s*([a-z0-9_]+)\s*\)',(R/n).read_text())
required+=['serve_base_tts_assets_are_independent_and_name_conflicts_are_atomic','http_voice_uploads_preserve_binary_fixed_and_chunked_bodies','http_voice_body_limits_and_shared_admission_precede_upload']
assert len(required)==15
required+=['serve_tts_options_bind_absolute_assets_and_transactional_budgets','tts_capability_pins_the_actual_talker_and_codec_independently_of_health','http_transcription_large_fixed_and_chunked_binary_bodies','http_transcription_limits_reject_before_body_read','http_header_identity_and_pre_body_admission','http_connection_classification_exact_route_and_method','voice_registry_revocation_blocks_new_resolution_keeps_owned_snapshot','voice_registry_concurrent_creates_commit_only_one_matched_revision','voice_registry_quota_failure_does_not_publish_voice_or_touch_consent','voice_registry_uncertain_staging_keeps_ids_without_replaying','voice_creation_rejects_conflicting_types_and_untrusted_evidence','voice_consent_update_can_only_change_name']
assert len(required)==27
paths=['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']
plan={'scope':'Native sample Voice/Consent service ingress, independent verification and Base synthesis; targeted CPU then separately frozen real HTTP gate','required':required,'cases':len(required),'new_cases':15,'direct_existing_cases':12,'cpu_seconds':180,'model_loads':0,'gpu_actions':0,'disk_reserve_bytes':256<<20,'max_cpu_artifact_bytes':16<<20,'defaults':{n:sha(R/n) for n in paths},'source_sha256':{n:sha(R/n) for n in modified+new if n.endswith(('.cpp','.h','.cmake','CMakeLists.txt'))},'pending':['actual same/different-speaker HTTP and new target text','SDK/native TLS and managed package','compatible preserved-state rollback','reference audio ICL','prompt voice and Live','listening/speaker similarity']}
save(V/'voice-service-cpu-plan-01.json',plan)
note='''真实音色API与Base合成链路已成组实现，冻结27项CPU/180秒、0模型/GPU：\n15新增和12直接受影响合同，含二进制上传上限、权限/撤销竞态、\n完整授权短语与多说话人反例。发现Speech仍用4096字节路由上限，\n已改为现有Chat有界输入预算，避免4096字符合同被UTF-8字节数截断。\n真实HTTP、SDK/包恢复与旧存储回退仍待验，默认保持。\n\n'''
p=R/'docs/STATUS.md';write(p,p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：音色服务成组开发与27项CPU冻结\n\n'+note+'登记复用独立ASR/192维说话人/原始24kHz条件，默认不加载Base。\n元数据管理不要求模型健康；GPU仅后续真实业务短验，不扩性能矩阵。\n\n'+s.split('\n',1)[1].lstrip('\n'))
O=V/'voice-service-build-01';O.mkdir(exist_ok=False)
# Retain the exact already-qualified CPU binary before relinking its path.
h=R/'.q4t-work/serve-file-search-20261112/host';old=h/'q4t_host_tests';assert old.is_file()
archive=O/'prior-host.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(old,arcname='q4t_host_tests',recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 with tar.extractfile('q4t_host_tests') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==sha(old)
save(O/'prior-host.json',{'path':str(old),'sha256':sha(old),'archive_sha256':sha(archive)})
# Restore only missing exact-SHA retained engine cache files. Never overwrite
# current objects or a default/qualified binary.
d=json.loads((T/'capacity-build-04/engine-cache.json').read_text());entries={**d['reused_archives'],**{n:dict(v,archive='capacity-build-04/engine-cache.tar.gz') for n,v in d['new_files'].items()}}
required_bytes=sum(v['bytes'] for n,v in entries.items() if not (R/n).exists());assert shutil.disk_usage(R).free>required_bytes+(512<<20)
restored=[]
for archive_name in sorted({v['archive'] for v in entries.values()}):
 archive=T/archive_name if archive_name.endswith('.tar.gz') else T/archive_name/'files.tar.gz'
 with tarfile.open(archive,'r:gz') as tar:
  for m in tar:
   if m.name not in entries or entries[m.name]['archive']!=archive_name:continue
   p=R/m.name
   if p.exists():continue
   assert m.isfile() and '..' not in Path(m.name).parts and p.is_relative_to(R/'.q4t-work')
   p.parent.mkdir(parents=True,exist_ok=True)
   with tar.extractfile(m) as f,p.open('xb') as dst:shutil.copyfileobj(f,dst)
   os.chmod(p,m.mode);os.utime(p,(m.mtime,m.mtime));assert sha(p)==entries[m.name]['sha256'];restored.append(m.name)
save(O/'restored-engine-cache.json',{'files':restored,'bytes':required_bytes})
print('plan 27 CPU, engine cache restored, no tests/model starts',flush=True)
for name,build,target,seconds in [('host',h,'q4t_host_tests',600),('engine',R/'.q4t-work/serve-custom-tools-20261108/engine-build','q4t',1200)]:
 assert shutil.disk_usage(R).free>256<<20
 start=time.monotonic();cmd=['cmake','--build',str(build),'--target',target,'--parallel','4']
 with (O/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=seconds)
 log=(O/(name+'.log')).read_text(errors='replace');warnings=[x for x in log.splitlines() if 'warning:' in x]
 result={'command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'warnings':warnings,'defaults_unchanged':all(sha(R/n)==v for n,v in plan['defaults'].items())}
 if r.returncode==0:result['binary_sha256']=sha(build/target)
 save(O/(name+'-result.json'),result);print(name,json.dumps(result),flush=True)
 if r.returncode or warnings:print(log[-6000:],flush=True);raise SystemExit(1)

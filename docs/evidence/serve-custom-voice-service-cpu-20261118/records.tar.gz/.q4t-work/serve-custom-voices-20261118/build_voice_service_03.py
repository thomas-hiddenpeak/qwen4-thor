from pathlib import Path
import hashlib,json,os,re,shutil,signal,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-service-build-03';O.mkdir(exist_ok=False);plan=json.loads((V/'voice-service-cpu-plan-02.json').read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,build,targets,seconds in [('engine',R/'.q4t-work/serve-custom-tools-20261108/engine-build',['q4t'],3600)]:
 assert shutil.disk_usage(R).free>256<<20
 start=time.monotonic();cmd=['cmake','--build',str(build),'--target',*targets,'--parallel','4'];reason=None;minimum=shutil.disk_usage(R).free
 with (O/(name+'.log')).open('wb') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   minimum=min(minimum,shutil.disk_usage(R).free)
   if minimum<256<<20 or time.monotonic()-start>seconds:
    reason='DISK_RESERVE_ABORT' if minimum<256<<20 else 'BUILD_TIMEOUT';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
 log=(O/(name+'.log')).read_text(errors='replace');warnings=[x for x in log.splitlines() if 'warning:' in x]
 result={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'warnings':warnings,'abort':reason,'minimum_free_bytes':minimum,'defaults_unchanged':all(sha(R/n)==v for n,v in plan['defaults'].items())}
 if p.returncode==0:result['binary_sha256']={target:sha(build/('q4t-ingress' if target=='q4t_ingress' else target)) for target in targets}
 (O/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,json.dumps(result),flush=True)
 if p.returncode or warnings:print(log[-6000:],flush=True);raise SystemExit(1)

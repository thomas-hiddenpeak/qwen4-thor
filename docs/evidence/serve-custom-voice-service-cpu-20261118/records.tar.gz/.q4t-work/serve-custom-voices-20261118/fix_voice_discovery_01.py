from pathlib import Path
import json,hashlib,subprocess,time,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';p=R/'src/server/chat_capabilities.cpp';s=p.read_text()
for a,b in [('R"(,"revision":)" + Quote(kNativeTtsRevision) +','R"(,"revision":)" + Quote(native_tts || !native_tts_base ? kNativeTtsRevision : kNativeTtsBaseRevision) +'),('R"(,"weight_sha256":)" + Quote(kNativeTtsWeightSha256) +','R"(,"weight_sha256":)" + Quote(native_tts || !native_tts_base ? kNativeTtsWeightSha256 : kNativeTtsBaseWeightSha256) +')]:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
t=p.with_suffix('.cpp.edit');t.write_text(s);t.replace(p)
# Format this changed region without rewriting unrelated history/source.
r=subprocess.run(['clang-format','--lines=740:751',str(p)],capture_output=True,check=True);t=p.with_suffix('.cpp.edit');t.write_bytes(r.stdout);t.replace(p)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
required=['voice_capabilities_distinguish_synthesis_from_registration_assets','tts_capability_pins_the_actual_talker_and_codec_independently_of_health']
plan={'scope':'Correct Base-only discovery revision and SHA, preserve builtin declarations','required':required,'cases':2,'cpu_seconds':60,'model_loads':0,'gpu_actions':0,'reuse':{'result':'voice-service-cpu-01/result.json','passed_cases':26,'failed_case_retained':True},'source_sha256':{str(p.relative_to(R)):sha(p)},'disk_reserve_bytes':256<<20}
(V/'voice-discovery-fix-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
O=V/'voice-discovery-fix-build-01';O.mkdir(exist_ok=False);B=R/'.q4t-work/serve-file-search-20261112/host'
start=time.monotonic();cmd=['cmake','--build',str(B),'--target','q4t_host_tests','--parallel','4'];assert shutil.disk_usage(R).free>256<<20
with (O/'build.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=180)
result={'command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'warnings':(O/'build.log').read_text().count('warning:')};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if r.returncode or result['warnings']:raise SystemExit(1)
O=V/'voice-discovery-fix-cpu-01';O.mkdir(exist_ok=False);(O/'required.txt').write_text('\n'.join(required)+'\n');start=time.monotonic();cmd=[str(B/'q4t_host_tests'),'--required-list',str(O/'required.txt')]
with (O/'test.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=60)
result={'status':'PASS' if r.returncode==0 else 'FAIL','command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'cases':2,'binary_sha256':sha(B/'q4t_host_tests'),'gpu_actions':0,'model_loads':0,'plan_sha256':sha(V/'voice-discovery-fix-plan-01.json')};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);print((O/'test.log').read_text(),flush=True);raise SystemExit(r.returncode)

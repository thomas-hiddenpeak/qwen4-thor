from pathlib import Path
R=Path.cwd()
def write(n,s):
 p=R/n;t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def change(n,a,b):
 s=(R/n).read_text();assert s.count(a)==1,(n,a,s.count(a));write(n,s.replace(a,b))
change('include/q4t/server/chat_server.h','#include "q4t/server/tts_upload.h"','#include "q4t/server/tts_upload.h"\n#include "q4t/audio/tts_speaker_model.h"\n#include "q4t/server/voice_registry.h"')
change('include/q4t/server/chat_server.h','  ObjectReply EnsureNativeAsr(bool weights, const BinaryAccess& access,','''  ObjectReply EnsureNativeVoice(const BinaryAccess& access,
                                RequestDiagnostics& diagnostic);
  std::string NativeVoiceHealthJson() const;
  ObjectReply RunNativeVoiceCondition(
      int fd, std::span<const float> pcm,
      const std::shared_ptr<RequestControl>& control,
      RequestDiagnostics& diagnostic, std::vector<float>* condition);
  ObjectReply PrepareVoiceEvidence(
      int fd, const VoiceAudio& audio, std::string_view consent_language,
      const std::shared_ptr<RequestControl>& control,
      RequestDiagnostics& diagnostic, ClientRateLease& rate,
      VoiceSampleEvidence* evidence, std::string* verified_phrase);
  void HandleVoices(int fd, std::string_view method, std::string_view target,
                    std::string_view content_type, std::string_view body);
  ObjectReply EnsureNativeAsr(bool weights, const BinaryAccess& access,''')
change('include/q4t/server/chat_server.h','  TtsBoundWeights tts_weights_;','''  TtsBoundWeights tts_weights_;
  // Registration belongs to the input family; it does not load the talker.
  std::mutex voice_mu_;
  AsrHealth voice_health_;
  uint8_t* d_voice_weights_ = nullptr;
  audio::TtsSpeakerDeviceWeights voice_weights_;''')
change('src/server/chat_server.cpp','  tts_base_health_.Released();','''  tts_base_health_.Released();
  release(d_voice_weights_, "shutdown.native_voice_weights");
  voice_health_.Released();''')
change('src/server/chat_server.cpp','  tts_base_health_.Configure(!tts_base_model_dir_.empty());','''  tts_base_health_.Configure(!tts_base_model_dir_.empty());
  voice_health_.Configure(!tts_base_model_dir_.empty());''')
change('src/server/chat_tts_backend.cpp','''  return speech(separator_mu_, d_separator_weights_, separator_weights_,
                separator_health_, "native_separator.family_release");''','''  reply = speech(separator_mu_, d_separator_weights_, separator_weights_,
                 separator_health_, "native_separator.family_release");
  if (!reply.ok()) return reply;
  return speech(voice_mu_, d_voice_weights_, voice_weights_, voice_health_,
                "native_voice.family_release");''')
change('src/server/chat_preflight.cpp','      R"(,"native_tts_limits":)" + TtsServiceLimitsJson(tts_limits_) +','''      R"(,"native_voice_health":)" + NativeVoiceHealthJson() +
      R"(,"native_tts_limits":)" + TtsServiceLimitsJson(tts_limits_) +''')
# Full 60s original inputs, decoded twice at native rates. The decoder worker
# survives until reap; charge its whole address-space ceiling independently.
change('src/server/chat_server.cpp','      if (!opts.asr_model_dir.empty()) {','''      if (!opts.tts_base_model_dir.empty()) {
        TtsVoiceResourcePlan voice;
        s = PlanTtsVoiceResources(60 * 24000,
                                  uint64_t(opts.tts_limits.workspace_mib) << 20,
                                  &voice);
        if (!s) return s;
        AdmissionLimits admission;
        s = ResolveAdmissionLimits(opts, opts.max_seq, &admission);
        if (!s) return s;
        input_weights += voice.device_weight_bytes;
        s = auxiliary.Add(
            voice.device_weight_bytes + (512ULL << 20) + (2ULL << 30),
            uint64_t(admission.inflight) *
                ((24ULL << 20) + 60 * (16000 + 24000) * sizeof(float) +
                 voice.host_feature_bytes),
            voice.source_staging_bytes + (6ULL << 20),
            voice.device_workspace_bytes);
        if (!s) return s;
      }
      if (!opts.asr_model_dir.empty()) {''')
s=(R/'src/server/chat_speaker_backend.cpp').read_text();s=s.replace('#include "q4t/server/speaker_assets.h"','#include "q4t/server/tts_assets.h"');s=s.replace('NativeSpeakerHealthJson','NativeVoiceHealthJson').replace('SpeakerHealthJson(speaker_health_.Snapshot(), gpu_healthy_.load())','SpeechHealthJson(voice_health_.Snapshot(), gpu_healthy_.load(),\n                       "qwen3-tts-12hz-1.7b-base-speaker", TtsFailureCode)');s=s.replace('ObjectReply ChatServer::EnsureNativeSpeaker(bool weights,','ObjectReply ChatServer::EnsureNativeVoice(').replace('RequestDiagnostics* diagnostic)','RequestDiagnostics& diagnostic)');s=s.replace('speaker_model_dir_','tts_base_model_dir_').replace('speaker_mu_','voice_mu_').replace('speaker_health_','voice_health_').replace('SpeakerFailureCode','TtsFailureCode');s=s.replace('BeginLoad(weights,','BeginLoad(true,');s=s.replace('kHostMargin + (weights ? 2 * audio::SpeakerConfig::kFileBytes : 0)','kHostMargin + kNativeTtsBaseFileBytes +\n        audio::TtsSpeakerConfig::kDeviceBytes + (6ULL << 20)');s=s.replace('SpeakerHostAssets assets;','TtsHostAssets assets;').replace('LoadSpeakerAssets(tts_base_model_dir_, &assets, control,\n                                          &cause, weights)','LoadTtsAssets(tts_base_model_dir_, &assets, control, &cause, true,\n                      kTtsAssetStagingBytes, {audio::TtsVariant::kBase17B, false})');s=s.replace('    if (weights) {','    {');s=s.replace('assets.WeightBytes().size()','audio::TtsSpeakerConfig::kDeviceBytes');s=s.replace('      std::unique_ptr<RequestDiagnostics::ExecutionScope> execution;\n      if (diagnostic)\n        execution = std::make_unique<RequestDiagnostics::ExecutionScope>(\n            *diagnostic, ProgressStage::kCache);','      RequestDiagnostics::ExecutionScope execution(diagnostic,\n                                                   ProgressStage::kCache);');a=s.index('      auto copied = cudaMemcpyAsync');b=s.index('      if (cancelled()) return interrupted();',a);s=s[:a]+'''      audio::TtsSpeakerDeviceWeights bound;
      const auto upload = UploadTtsSpeakerWeights(
          assets, {pending, audio::TtsSpeakerConfig::kDeviceBytes}, &bound,
          cancelled);
      if (!upload.ok()) {
        if (upload.device_error != cudaSuccess) {
          AbortBackendExecution();
          return fail(AsrFailure::kDevice, "Voice weight upload failed");
        }
        if (cancelled()) return interrupted();
        return fail(AsrFailure::kAssets, "Voice weight binding failed");
      }
      execution.Completed();
'''+s[b:];s=s.replace('d_speaker_weights_','d_voice_weights_').replace('speaker_weights_','voice_weights_');s=s.replace('Loaded(weights, weights ? audio::TtsSpeakerConfig::kDeviceBytes : 0)','Loaded(true, audio::TtsSpeakerConfig::kDeviceBytes)');s=s.replace('native_speaker.','native_voice.').replace('"speaker_','"voice_').replace('Speaker ', 'Voice ');write('src/server/chat_voice_backend.cpp',s)
# Executor follows the shared sequence/auxiliary/model ownership discipline.
s=(R/'src/server/chat_speaker_execution.cpp').read_text().replace('"q4t/audio/speaker_features.h"','"q4t/audio/tts_speaker_features.h"')
a=s.index('ObjectReply ChatServer::RunNativeSpeaker(');b=s.index('  using Clock =',a);s=s[:a]+'''ObjectReply ChatServer::RunNativeVoiceCondition(
    int fd, std::span<const float> pcm,
    const std::shared_ptr<RequestControl>& control,
    RequestDiagnostics& diagnostic, std::vector<float>* condition) {
'''+s[b:]
a=s.index('  if (!embeddings');b=s.index('  const auto cancelled =',a);s=s[:a]+'''  TtsVoiceResourcePlan resources;
  if (!condition ||
      !PlanTtsVoiceResources(pcm.size(), uint64_t(tts_limits_.workspace_mib) << 20,
                             &resources))
    return Error(400, "voice_input_limit", "Voice condition input exceeds capacity");
'''+s[b:]
a=s.index('  size_t max_samples =');b=s.index('  std::unique_lock<std::mutex> auxiliary;',a);s=s[:a]+'  if (cancelled()) return interrupted();\n'+s[b:]
s=s.replace('EnsureNativeSpeaker(true, {{}, control->deadline(), cancelled},\n                                     &diagnostic)','EnsureNativeVoice({{}, control->deadline(), cancelled}, diagnostic)')
a=s.index('  audio::SpeakerWorkspaceLayout layout;');b=s.index('  uint8_t* memory =',a);s=s[:a]+s[b:];s=s.replace('layout.bytes','resources.device_workspace_bytes');s=s.replace('(512ULL << 20)','(512ULL << 20) + resources.host_feature_bytes');a=s.index('    std::vector<audio::SpeakerEmbedding> output;');b=s.index('    release.Run();',a);s=s[:a]+'''    if (cancelled()) return interrupted();
    diagnostic.Stage("voice_condition_features");
    audio::TtsSpeakerFeatures features;
    const auto status = audio::ComputeTtsSpeakerFeatures(
        pcm, 24000, {}, &features, cancelled);
    if (!status) {
      if (cancelled()) return interrupted();
      return Error(400, "voice_features_invalid", status.message());
    }
    audio::TtsSpeakerRun run;
    diagnostic.Stage("voice_condition_embedding");
    auto reply = perform([&] {
      return run.Begin(voice_weights_, features.mel, features.frames,
                       memory, resources.device_workspace_bytes);
    });
    if (!reply.ok()) return reply;
    for (int stage = 0; stage < audio::TtsSpeakerRun::kStages; ++stage) {
      reply = perform([&] { return run.NextStage(); });
      if (!reply.ok()) return reply;
    }
    std::vector<float> output(2048);
    reply = perform([&] { return run.Finish(output); });
    if (!reply.ok()) return reply;
'''+s[b:];s=s.replace('*embeddings =','*condition =');s=s.replace('speaker_health_','voice_health_').replace('SpeakerFailureCode','TtsFailureCode').replace('native_speaker.','native_voice.').replace('"speaker_','"voice_').replace('Speaker ', 'Voice ').replace('Native speaker','Native voice');write('src/server/chat_voice_execution.cpp',s)
for n in ['CMakeLists.txt','cmake/ChatProtocolIdentity.cmake']:
 change(n,'  src/server/chat_speech_prompt.cpp','  src/server/chat_speech_prompt.cpp\n  src/server/chat_voice_backend.cpp\n  src/server/chat_voice_execution.cpp')
print('Voice condition service backend written, not tested')

from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'voice-service-cpu-plan-04.json';plan=json.loads(P.read_text());B=R/'.q4t-work/serve-file-search-20261112/host';O=V/'voice-service-host-review-build-01';O.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert shutil.disk_usage(R).free>256<<20
start=time.monotonic();cmd=['cmake','--build',str(B),'--target','q4t_host_tests','--parallel','4']
with (O/'build.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=180)
result={'command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'warnings':(O/'build.log').read_text().count('warning:')};save(O/'result.json',result);print(json.dumps(result),flush=True)
if r.returncode or result['warnings']:print((O/'build.log').read_text()[-5000:]);raise SystemExit(1)
O=V/'voice-service-cpu-01';O.mkdir(exist_ok=False);(O/'fixtures').mkdir();(O/'required.txt').write_text('\n'.join(plan['required'])+'\n')
assert all(sha(R/n)==v for n,v in plan['source_sha256'].items()),'source drift before test'
start=time.monotonic();cmd=[str(B/'q4t_host_tests'),'--required-list',str(O/'required.txt')]
env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O/'fixtures'));assert shutil.disk_usage(R).free>256<<20
with (O/'test.log').open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=plan['cpu_seconds'])
result={'status':'PASS' if r.returncode==0 else 'FAIL','command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'cases':len(plan['required']),'plan_sha256':sha(P),'binary_sha256':sha(B/'q4t_host_tests'),'defaults_unchanged':all(sha(R/n)==v for n,v in plan['defaults'].items()),'gpu_actions':0,'model_loads':0,'source_unchanged':all(sha(R/n)==v for n,v in plan['source_sha256'].items())};save(O/'result.json',result);print(json.dumps(result),flush=True);print((O/'test.log').read_text()[-6000:],flush=True);raise SystemExit(r.returncode)

from pathlib import Path
R=Path.cwd()
def write(n,s):
 p=R/n;t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def change(n,a,b):
 s=(R/n).read_text();assert s.count(a)==1,(n,a,s.count(a));write(n,s.replace(a,b))
change('include/q4t/server/server_options.h','  std::string tts_model_dir;','  std::string tts_model_dir;\n  // Independent optional Base assets for registered voice conditioning.\n  std::string tts_base_model_dir;')
change('src/server/server_options.cpp','  if (!options.asr_limits.Valid())','''  if (!options.tts_base_model_dir.empty()) {
    if (!model::ValidEmbeddingAssetDirectory(options.tts_base_model_dir))
      return Status::Fail("tts-base-model-dir must be an absolute asset path");
    if (IsServedModel(kNativeTtsBaseModel, options.served_model_name,
                      options.model_aliases))
      return Status::Fail("Base TTS model name conflicts with Chat model names");
  }
  if (!options.asr_limits.Valid())''')
change('src/server/server_options.cpp','    } else if (key == "--asr-model-dir") {','''    } else if (key == "--tts-base-model-dir") {
      parsed.tts_base_model_dir = value;
    } else if (key == "--asr-model-dir") {''')
change('src/main.cpp','      "[--tts-model-dir DIR] [--tts-max-text-tokens N] "','      "[--tts-model-dir DIR] [--tts-base-model-dir DIR] "\n      "[--tts-max-text-tokens N] "')
change('include/q4t/server/chat_server.h','''  ObjectReply EnsureNativeTts(bool weights, const BinaryAccess& access,
                              RequestDiagnostics* diagnostic = nullptr);
  std::string NativeTtsHealthJson() const;''','''  ObjectReply EnsureNativeTts(
      bool weights, const BinaryAccess& access,
      RequestDiagnostics* diagnostic = nullptr,
      audio::TtsVariant variant = audio::TtsVariant::kCustomVoice17B);
  AsrHealth& TtsHealth(audio::TtsVariant variant);
  // Caller owns auxiliary_mu_ and tts_mu_; pair retirement ignores mid-free
  // cancellation and never overwrites an allocation whose release failed.
  ObjectReply ReleaseNativeTts(const std::function<bool()>& cancelled);
  std::string NativeTtsHealthJson(
      audio::TtsVariant variant = audio::TtsVariant::kCustomVoice17B) const;
  ObjectReply PlanNativeSpeech(const SpeechRequest& request,
                               const BinaryAccess& access,
                               RequestDiagnostics& diagnostic,
                               audio::TtsPrompt* prompt);''')
change('include/q4t/server/chat_server.h','''  ModelCatalog tts_catalog_;
  std::string tts_model_dir_;''','''  ModelCatalog tts_catalog_, tts_base_catalog_;
  std::string tts_model_dir_, tts_base_model_dir_;''')
change('include/q4t/server/chat_server.h','  AsrHealth tts_health_;','  AsrHealth tts_health_, tts_base_health_;')
change('include/q4t/server/chat_server.h','  std::unique_ptr<text::Tokenizer> tts_tok_;','''  // Metadata/tokenizers are immutable once published. Both variants have
  // separate ownership; they share a cancellable tokenizer execution mutex.
  std::unique_ptr<text::Tokenizer> tts_tok_, tts_base_tok_;''')
# Share one physical synthesis pair, with independent variant health.
p='src/server/chat_tts_backend.cpp';s=(R/p).read_text();s=s.replace('''std::string ChatServer::NativeTtsHealthJson() const {
  auto result = TtsHealthJson(tts_health_.Snapshot(), gpu_healthy_.load());''','''AsrHealth& ChatServer::TtsHealth(audio::TtsVariant variant) {
  return variant == audio::TtsVariant::kBase17B ? tts_base_health_ : tts_health_;
}

std::string ChatServer::NativeTtsHealthJson(audio::TtsVariant variant) const {
  const bool base = variant == audio::TtsVariant::kBase17B;
  auto result = SpeechHealthJson(
      (base ? tts_base_health_ : tts_health_).Snapshot(), gpu_healthy_.load(),
      base ? kNativeTtsBaseModel : kNativeTtsModel, TtsFailureCode);''')
a=s.index('    if (!d_tts_talker_ && !d_tts_codec_) return {};');b=s.index('\n  }\n  auto reply = release',a)
old=s[a:b];s=s[:a]+'    return ReleaseNativeTts(cancelled);'+s[b:]
release='''ObjectReply ChatServer::ReleaseNativeTts(
    const std::function<bool()>& cancelled) {
  if (!d_tts_talker_ && !d_tts_codec_) return {};
  auto gpu = LockUnlessCancelled(model_mu_, cancelled);
  if (!gpu.owns_lock() || cancelled())
    return Error(409, "tts_cancelled", "TTS model switch cancelled");
  auto& health = TtsHealth(tts_weights_.talker.variant);
  bool clean = true;
  for (auto** pointer : {&d_tts_talker_, &d_tts_codec_}) {
    const auto freed =
        detail::ReleaseCudaMemory(*pointer, "native_tts.family_release");
    RecordDeviceMemoryFailure(freed, "native_tts.family_release");
    clean &= freed.ok();
  }
  tts_weights_ = {};
  health.Released();
  if (!clean) {
    health.ComputeFailed(AsrFailure::kDevice, Clock::now());
    AbortBackendExecution();
    return Error(503, "gpu_unhealthy", "Optional weight release failed");
  }
  return {};
}

'''
s=s.replace('ObjectReply ChatServer::EnsureNativeTts(',release+'ObjectReply ChatServer::EnsureNativeTts(',1)
s=s.replace('RequestDiagnostics* diagnostic) {','RequestDiagnostics* diagnostic,\n                                        audio::TtsVariant variant) {',1)
a=s.index('ObjectReply ChatServer::EnsureNativeTts(');before=s[:a];s=s[a:]
s=s.replace('  const auto cancelled = [&] {','''  if (variant != audio::TtsVariant::kCustomVoice17B &&
      variant != audio::TtsVariant::kBase17B)
    return Error(400, "tts_variant_invalid", "TTS variant is unavailable");
  const bool base = variant == audio::TtsVariant::kBase17B;
  auto& health = TtsHealth(variant);
  auto& tokenizer = base ? tts_base_tok_ : tts_tok_;
  const auto& directory = base ? tts_base_model_dir_ : tts_model_dir_;
  const auto cancelled = [&] {''',1)
s=s.replace('tts_model_dir_.empty()', 'directory.empty()').replace('tts_health_.','health.')
s=s.replace('  switch (health.BeginLoad(weights, Clock::now())) {','''  // Every device caller owns auxiliary_mu_. A metadata request cannot evict
  // a model. Switching retires the old pair before allocating the new one.
  if (weights && (d_tts_talker_ || d_tts_codec_) &&
      tts_weights_.talker.variant != variant) {
    auto retired = ReleaseNativeTts(cancelled);
    if (!retired.ok()) return retired;
  }
  switch (health.BeginLoad(weights, Clock::now())) {''')
s=s.replace('(kNativeTtsFileBytes + kNativeTtsCodecFileBytes)', '((base ? kNativeTtsBaseFileBytes : kNativeTtsFileBytes) +\n                       kNativeTtsCodecFileBytes)')
s=s.replace('LoadTtsAssets(tts_model_dir_, &assets, control, &cause, weights)', 'LoadTtsAssets(directory, &assets, control, &cause, weights,\n                       kTtsAssetStagingBytes, {variant, true})')
s=s.replace('if (!tts_tok_) tts_tok_ = std::move(assets.tokenizer);','if (!tokenizer) tokenizer = std::move(assets.tokenizer);')
write(p,before+s)
# Runtime variant derives from already validated owned prompt.
p='src/server/chat_tts_execution.cpp';s=(R/p).read_text();s=s.replace('  auto* http = detail::HttpResponseContext::Current(fd);','''  const auto variant = prompt.speaker_embedding.empty()
                           ? audio::TtsVariant::kCustomVoice17B
                           : audio::TtsVariant::kBase17B;
  auto& health = TtsHealth(variant);
  auto* http = detail::HttpResponseContext::Current(fd);''',1);s=s.replace('&diagnostic);','&diagnostic, variant);',1);s=s.replace('max_frames, &resources))','max_frames, &resources, variant))');s=s.replace('tts_health_.','health.');write(p,s)
# Centralize prompt construction and owner-scoped resolution for both routes.
write('src/server/chat_speech_prompt.cpp','''#include "chat_server_internal.h"

#include "object_protocol.h"
#include "q4t/server/request_diagnostics.h"
#include "q4t/server/voice_registry.h"

namespace q4t::server {
ObjectReply ChatServer::PlanNativeSpeech(const SpeechRequest& request,
                                         const BinaryAccess& access,
                                         RequestDiagnostics& diagnostic,
                                         audio::TtsPrompt* prompt) {
  using object_detail::Error;
  if (!prompt) return Error(500, "tts_prompt_invalid", "Speech owner missing");
  const bool base = request.voice_id;
  const auto variant = base ? audio::TtsVariant::kBase17B
                             : audio::TtsVariant::kCustomVoice17B;
  if ((base ? tts_base_model_dir_ : tts_model_dir_).empty() ||
      !(base ? tts_base_catalog_ : tts_catalog_).Contains(request.model))
    return Error(404, "model_not_found", "Speech model is not configured");
  const auto cancelled = [&] {
    return stop_requested_.load() ||
           std::chrono::steady_clock::now() >= access.deadline ||
           (access.cancelled && access.cancelled());
  };
  VoiceSynthesisBinding voice;
  {
    RequestDiagnostics::Scope wait(diagnostic,
                                   RequestDiagnostics::Wait::kStorage);
    // Every invocation checks the live same-owner consent. The returned
    // immutable condition belongs only to this bounded request.
    if (base) {
      if (!objects_)
        return Error(503, "object_store_unavailable", "Voice store unavailable");
      auto reply = VoiceRegistry(*objects_).Resolve(request.voice, access, &voice);
      if (!reply.ok()) return reply;
    } else if (audio::TtsBuiltinVoiceId(request.voice) < 0) {
      return Error(400, "invalid_speech_voice", "Voice is unavailable");
    }
    auto loaded = EnsureNativeTts(false, access, &diagnostic, variant);
    if (!loaded.ok()) return loaded;
  }
  std::vector<uint32_t> text, instruction;
  {
    RequestDiagnostics::Scope wait(diagnostic,
                                   RequestDiagnostics::Wait::kTokenizer);
    auto lock = LockUnlessCancelled(tts_tok_mu_, cancelled);
    if (!lock.owns_lock() || cancelled())
      return Error(409, "tts_cancelled", "Speech tokenization cancelled");
    auto& tokenizer = base ? tts_base_tok_ : tts_tok_;
    auto status = tokenizer->Encode(
        request.input, &text,
        {.cancelled = cancelled, .recognize_special_tokens = false});
    if (status && !request.instructions.empty())
      status = tokenizer->Encode(
          request.instructions, &instruction,
          {.cancelled = cancelled, .recognize_special_tokens = false});
    if (!status)
      return Error(cancelled() ? 409 : 400,
                   cancelled() ? "tts_cancelled" : "invalid_speech_text",
                   "Speech tokenization failed");
  }
  const std::vector<int32_t> ids(text.begin(), text.end());
  const std::vector<int32_t> instructions(instruction.begin(), instruction.end());
  audio::TtsPrompt next;
  const auto status = base
      ? audio::PlanTtsBasePrompt(ids, instructions, voice.condition, "auto",
                                true, tts_limits_.max_prefill_tokens, &next)
      : audio::PlanTtsPrompt(variant, ids, instructions, request.voice, "auto",
                            true, tts_limits_.max_prefill_tokens, &next);
  if (!status || next.text_ids.size() > size_t(tts_limits_.max_text_tokens))
    return Error(400, "invalid_speech_prompt",
                 status ? "Speech prompt exceeds capacity" : status.message());
  if (cancelled()) return Error(409, "tts_cancelled", "Speech preparation cancelled");
  *prompt = std::move(next);
  return {};
}
}  // namespace q4t::server
''')
p='src/server/chat_speech.cpp';s=(R/p).read_text();a=s.index('    if (tts_model_dir_.empty()');b=s.index('    const auto id =',a);s=s[:a]+s[b:];a=s.index('    ObjectReply loaded;');b=s.index('    size_t max_frames =',a);s=s[:a]+'''    const BinaryAccess access{
        http->Client().Scoped() ? "client:" + std::string(http->Client().Id())
                                : "local:anonymous",
        control->deadline(), cancelled};
    audio::TtsPrompt prompt;
    auto planned = PlanNativeSpeech(request, access, diagnostic, &prompt);
    if (!planned.ok()) {
      fail(planned);
      return;
    }
'''+s[b:];write(p,s)
p='src/server/chat_audio_synthesis.cpp';s=(R/p).read_text();s=s.replace('    request.model = kNativeTtsModel;','    request.model = request.voice_id ? kNativeTtsBaseModel : kNativeTtsModel;');a=s.index('    if (request.voice_id)\n');b=s.index('    // One per-choice',a);s=s[:a]+'''    audio::TtsPrompt prompt;
    auto planned = PlanNativeSpeech(request, access, diagnostic, &prompt);
    if (!planned.ok()) return planned;
'''+s[b:];write(p,s)
# Configuration and model discovery, separate health, no false Voice API claim.
change('src/server/chat_server.cpp','  tts_health_.Released();','  tts_health_.Released();\n  tts_base_health_.Released();')
change('src/server/chat_server.cpp','  tts_model_dir_ = opts.tts_model_dir;','''  tts_base_model_dir_ = opts.tts_base_model_dir;
  tts_base_health_.Configure(!tts_base_model_dir_.empty());
  if (!tts_base_model_dir_.empty()) {
    s = tts_base_catalog_.Configure(kNativeTtsBaseModel, {},
                                    static_cast<int64_t>(std::time(nullptr)));
    if (!s) return s;
  }
  tts_model_dir_ = opts.tts_model_dir;''')
# For synthesis take max of the shared execution graph; metadata of each
# configured variant persists, but only one decoder child/pair exists.
change('src/server/chat_server.cpp','      if (!opts.tts_model_dir.empty()) {','      if (!opts.tts_model_dir.empty() || !opts.tts_base_model_dir.empty()) {')
change('src/server/chat_server.cpp','                                    opts.tts_limits.max_frames, &tts);','''                                    opts.tts_limits.max_frames, &tts,
                                    opts.tts_base_model_dir.empty()
                                        ? audio::TtsVariant::kCustomVoice17B
                                        : audio::TtsVariant::kBase17B);''')
change('src/server/chat_server.cpp','            tts.resident_weight_bytes + tts.resident_host_bytes +','''            tts.resident_weight_bytes + tts.resident_host_bytes +
                (!opts.tts_model_dir.empty() && !opts.tts_base_model_dir.empty()
                     ? tts.resident_host_bytes : 0) +''')
change('src/server/chat_metrics.cpp','''  if (!asr_model_dir_.empty()) {
    body.resize''','''  if (!tts_base_model_dir_.empty()) {
    body.resize(body.size() - 2);
    body += ',' + tts_base_catalog_.RetrieveJson(kNativeTtsBaseModel) + "]}";
  }
  if (!asr_model_dir_.empty()) {
    body.resize''')
change('src/server/chat_metrics.cpp','             (tts_model_dir_.empty() || !tts_catalog_.Contains(model))) {','''             (tts_model_dir_.empty() || !tts_catalog_.Contains(model)) &&
             (tts_base_model_dir_.empty() || !tts_base_catalog_.Contains(model))) {''')
change('src/server/chat_metrics.cpp','                          : tts_catalog_.Contains(model) ? tts_catalog_','''                          : tts_base_catalog_.Contains(model) ? tts_base_catalog_
                          : tts_catalog_.Contains(model) ? tts_catalog_''')
change('src/server/chat_preflight.cpp','      R"(,"native_tts_limits":)" + TtsServiceLimitsJson(tts_limits_) +','''      R"(,"native_tts_base_health":)" +
      NativeTtsHealthJson(audio::TtsVariant::kBase17B) +
      R"(,"native_tts_limits":)" + TtsServiceLimitsJson(tts_limits_) +''')
for n in ['CMakeLists.txt','cmake/ChatProtocolIdentity.cmake']:
 change(n,'  src/server/chat_speech.cpp','  src/server/chat_speech.cpp\n  src/server/chat_speech_prompt.cpp')
# Record implementation boundary; acceptance remains pending.
note='''自定义音色服务接入开发中：Base独立配置/健康/元数据，Speech与Chat\n共同按客户域解析实时授权，使用真实2048条件；内置与Base只保有\n一组talker/codec，取消和设备释放故障保持原保护。尚未编译/HTTP\n验收，不改变默认；接着真实录音登记、配额、发现及包恢复接入。\n\n'''
p='docs/STATUS.md';s=(R/p).read_text();write(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p='docs/log/2026-11-18.md';s=(R/p).read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：Base语音接入服务的模型选择与授权绑定\n\n'+note+'此阶段成组修改后针对验证；已有组件证据复用，不做完整性能矩阵。\n\n'+s.split('\n',1)[1].lstrip('\n'))
print('Base service integration written; not built/tested')

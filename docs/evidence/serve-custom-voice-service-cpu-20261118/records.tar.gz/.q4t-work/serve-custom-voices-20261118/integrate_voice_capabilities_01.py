from pathlib import Path
R=Path.cwd()
def edit(n,a,b):
 p=R/n;s=p.read_text();assert s.count(a)==1,(n,a,s.count(a));t=p.with_suffix(p.suffix+'.edit');t.write_text(s.replace(a,b));t.replace(p)
edit('include/q4t/server/chat_capabilities.h','    bool native_tts = false);','    bool native_tts = false, bool native_tts_base = false);')
edit('src/server/chat_capabilities.cpp','                                 bool native_separator, bool native_tts) {','''                                 bool native_separator, bool native_tts,
                                 bool native_tts_base) {''')
edit('src/server/chat_metrics.cpp','          !separator_model_dir_.empty(), !tts_model_dir_.empty()),','''          !separator_model_dir_.empty(), !tts_model_dir_.empty(),
          !tts_base_model_dir_.empty()),''')
edit('src/server/chat_capabilities.cpp','''         R"("core_health_dependency":false,"registered_custom_voices":false},)"
         R"("chat_audio_output":{"enabled":)" +
         (native_tts ? "true" : "false") +''','''         R"("core_health_dependency":false,"registered_custom_voices":)" +
         (native_tts_base ? "true" : "false") + R"(,"registered_voice_model":)" +
         Quote(kNativeTtsBaseModel) + R"(,"base_revision":)" +
         Quote(kNativeTtsBaseRevision) + R"(,"base_weight_sha256":)" +
         Quote(kNativeTtsBaseWeightSha256) +
         R"(,"builtin_enabled":)" + (native_tts ? "true" : "false") + "}," +
         R"("voice_registration":{"enabled":)" +
         (native_tts_base && native_asr && native_speaker && native_vad
              ? "true" : "false") +
         R"(,"voices":"/v1/audio/voices",)"
         R"("consents":"/v1/audio/voice_consents",)"
         R"("sample_audio_bytes":10485760,"sample_seconds":60,)"
         R"("types":["audio_sample"],"prompt_voice_design":false,)"
         R"("independent_transcription":true,"same_speaker_verification":true,)"
         R"("owner_scoped":true,"recheck_consent_per_synthesis":true,)"
         R"("metadata_requires_healthy_model":false,)"
         R"("core_health_dependency":false},)"
         R"("chat_audio_output":{"enabled":)" +
         (native_tts || native_tts_base ? "true" : "false") +''')
edit('src/server/chat_capabilities.cpp','         (native_tts ? "true" : "false") + R"(,"model":)" +','         (native_tts || native_tts_base ? "true" : "false") + R"(,"model":)" +')

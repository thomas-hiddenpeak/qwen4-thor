from pathlib import Path
import json,hashlib,sys,subprocess
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
sys.path.insert(0,str(R));from tools.serve_audit.check_inventory import current_surface,check,mutation_checks
surface=current_surface(R);p=R/'tools/serve_audit/inventory.json';inv=json.loads(p.read_text());changes={n:{'old':inv['sources_sha256'].get(n),'new':h} for n,h in surface['sources_sha256'].items() if inv['sources_sha256'].get(n)!=h}
dirty=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines());assert set(changes)<=dirty
new_routes={k:sorted(set(surface[k])-set(inv[k])) for k in ['routes','native_routes']};assert all(len(v)==7 for v in new_routes.values()),new_routes
assert all(set(inv[k])<=set(surface[k]) for k in ['routes','native_routes'])
whitelists={k:{'old':inv['whitelists'].get(k),'new':v} for k,v in surface['whitelists'].items() if inv['whitelists'].get(k)!=v};assert all(k.startswith('voice_api.cpp:') for k in whitelists),whitelists
review={'source_changes':changes,'new_routes':new_routes,'whitelists':whitelists,'cpu':'27 distinct contracts qualified by 26/27 plus 2/2 targeted discovery fix; original failure retained','runtime':'not yet qualified; no default replacement','reviewed_boundaries':['one physical TTS pair and independent variant metadata/health','registration input-family weights and scoped ASR usage','full phrase never injected into recognizer; independent 192 vs 2048 models','owner from authenticated client; CAS after verification; per-request consent resolution','metadata control lane without healthy model; binary quotas and same native gateway route','old reader compatibility package remains required before deployment']}
(V/'voice-service-source-review-01.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
for k,keys in new_routes.items():
 for route in keys:
  inv[k][route]={'semantics':'原生样本音色/consent生命周期，鉴权客户域、独立音频核验、原子同人关联及撤销。','boundary':'源码与针对CPU已验证，真实音频/HTTP及有状态回退仍待验。提示词音色另有后端任务；不能由样本路径替代。','evidence':['src/server/voice_api.cpp','src/server/chat_voices.cpp','src/server/chat_voice_evidence.cpp','src/server/voice_registry.cpp','tests/server_voice_api_test.cpp','docs/SERVE_CUSTOM_VOICES_2026-11-18.md']}
inv['sources_sha256'].update(surface['sources_sha256']);inv['whitelists'].update(surface['whitelists']);inv['native_custom_voice_service_2026_11_18']={'state':'CPU_QUALIFIED_HTTP_PENDING','reviewed_sources':sorted(changes),'source_review':'.q4t-work/serve-custom-voices-20261118/voice-service-source-review-01.json','defaults_unchanged':True,'master_complete':False}
assert not check(inv,surface),check(inv,surface);mutations=mutation_checks(inv,surface);write(p,json.dumps(inv,indent=2,ensure_ascii=False)+'\n')
result={'inventory_current':True,'source_anchors':len(surface['sources_sha256']),'routes':len(surface['routes']),'native_routes':len(surface['native_routes']),'mutation_checks':mutations,'semantics_certified':False};(V/'voice-service-inventory-01.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

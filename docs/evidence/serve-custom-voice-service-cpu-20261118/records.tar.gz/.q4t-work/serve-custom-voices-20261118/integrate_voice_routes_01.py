from pathlib import Path
R=Path.cwd()
def write(n,s):
 p=R/n;t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def change(n,a,b):
 s=(R/n).read_text();assert s.count(a)==1,(n,a,s.count(a));write(n,s.replace(a,b))
change('include/q4t/server/application_routes.h','inline bool IsTranscriptionTarget(std::string_view target) {','''inline bool IsVoiceTarget(std::string_view target) {
  const auto path = target.substr(0, target.find('?'));
  return path == "/v1/audio/voices" || path.starts_with("/v1/audio/voices/") ||
         path == "/v1/audio/voice_consents" ||
         path.starts_with("/v1/audio/voice_consents/");
}
inline bool VoiceMethodAllowed(std::string_view method, std::string_view target) {
  if (!IsVoiceTarget(target) || target.find('#') != target.npos) return false;
  const auto path = target.substr(0, target.find('?'));
  const bool consent = path.starts_with("/v1/audio/voice_consents");
  const std::string_view root = consent ? "/v1/audio/voice_consents"
                                        : "/v1/audio/voices";
  if (path == root) return method == "POST" || (consent && method == "GET");
  if (!ValidApplicationId(path.substr(root.size() + 1))) return false;
  return method == "DELETE" || (consent && (method == "POST" || method == "GET"));
}
inline bool IsVoiceCreation(std::string_view method, std::string_view target) {
  const auto path = target.substr(0, target.find('?'));
  return method == "POST" && (path == "/v1/audio/voices" ||
                              path == "/v1/audio/voice_consents");
}
inline bool IsVoiceMetadata(std::string_view method, std::string_view target) {
  return VoiceMethodAllowed(method, target) && !IsVoiceCreation(method, target);
}
inline bool IsTranscriptionTarget(std::string_view target) {''')
change('include/q4t/server/application_routes.h','(path == "/v1/files" || IsTranscriptionTarget(target)))','(path == "/v1/files" || IsTranscriptionTarget(target) ||\n           IsVoiceCreation(method, target)))')
change('src/server/http_request.cpp','#include "q4t/server/application_routes.h"','#include "q4t/server/application_routes.h"\n#include "q4t/server/voice_request.h"')
change('src/server/http_request.cpp','      : IsTranscriptionTarget(*path) ? kTranscriptionBodyBytes','      : IsVoiceTarget(*path) ? kVoiceFormBytes\n      : IsTranscriptionTarget(*path) ? kTranscriptionBodyBytes')
change('src/server/chat_http.cpp','            path == "/v1/audio/transcriptions" || IsResponsesTarget(path) ||','            path == "/v1/audio/transcriptions" || IsVoiceCreation(method, path) ||\n            IsResponsesTarget(path) ||')
change('src/server/chat_http.cpp','    else if (IsTranscriptionTarget(path)) {','''    else if (IsVoiceTarget(path)) {
      HandleVoices(fd, method, path, headers.content_type, body);
    }
    else if (IsTranscriptionTarget(path)) {''')
for n in ['include/q4t/server/http_connection.h','src/server/client_request.cpp']:
 change(n,'IsPromptObservation(method, path) ||','IsVoiceMetadata(method, path) || IsPromptObservation(method, path) ||')
change('src/service/ingress_main.cpp','#include "q4t/server/application_routes.h"','#include "q4t/server/application_routes.h"\n#include "q4t/server/voice_request.h"')
change('src/service/ingress_main.cpp','  if (server::ConversationMethodAllowed(method, path) ||','  if (server::VoiceMethodAllowed(method, path) ||\n      server::ConversationMethodAllowed(method, path) ||')
change('src/service/ingress_main.cpp','    *control = server::IsMcpTunnelMetadata(method, path) ||','    *control = server::IsVoiceMetadata(method, path) ||\n               server::IsMcpTunnelMetadata(method, path) ||')
change('src/service/ingress_main.cpp','    if (headers.content_length > headers.body_limit)','''    if (server::IsVoiceTarget(path))
      headers.body_limit = std::min(headers.body_limit, server::kVoiceFormBytes);
    if (headers.content_length > headers.body_limit)''')
for n in ['CMakeLists.txt','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake']:
 if n.endswith('HostTestSources.cmake'):
  change(n,'  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_verification.cpp','  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_verification.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_api.cpp')
 else:change(n,'  src/server/voice_verification.cpp','  src/server/voice_verification.cpp\n  src/server/voice_api.cpp')
change('cmake/ChatProtocolIdentity.cmake','  include/q4t/server/voice_verification.h','  include/q4t/server/voice_verification.h\n  include/q4t/server/voice_api.h')

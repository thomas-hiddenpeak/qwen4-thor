from pathlib import Path
import re
R=Path.cwd()
def write(n,s):
 p=R/n;t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def change(n,a,b):
 s=(R/n).read_text();assert s.count(a)==1,(n,a,s.count(a));write(n,s.replace(a,b))
write('include/q4t/server/voice_verification.h','''// Evidence from independently decoded audio, never caller-provided vectors.
#pragma once

#include <string_view>

#include "q4t/audio/diarization.h"

namespace q4t::server {
// Fixed interoperable consent phrases; language subtags select the same
// primary-language wording. The phrase is never supplied to the recognizer.
// Matching is a recorded protocol check, not proof of a person's legal identity.
std::string_view VoiceConsentPhrase(std::string_view language);
// Normalize each window, require pairwise single-speaker consistency, and
// average by the non-overlapping speech cores. Invalid/multi-speaker input
// fails atomically, without forcing unrelated speakers into one identity.
Status BuildVoiceIdentity(std::span<const audio::SpeakerWindow> windows,
                          std::span<const audio::SpeakerEmbedding> embeddings,
                          size_t total_samples, std::vector<float>* identity,
                          const std::function<bool()>& cancelled = {});
}  // namespace q4t::server
''')
phrases=re.findall(r'^\| [^|]+\(`([a-z]{2})`\)\s*\| ([^|]+)\|', (R/'.q4t-work/serve-custom-voices-20261118/api-source-02/doc-2.md').read_text(),re.M);assert len(phrases)==16
s='''#include "q4t/server/voice_verification.h"

#include <cmath>

#include "q4t/server/voice_request.h"

namespace q4t::server {
std::string_view VoiceConsentPhrase(std::string_view language) {
  if (!WellFormedVoiceLanguage(language)) return {};
  std::string primary(language.substr(0, language.find('-')));
  for (char& c : primary) if (c >= 'A' && c <= 'Z') c += 'a' - 'A';
  // Protocol wording pinned from the official custom-voices guide. Audio is
  // processed locally; the organization named in the phrase is not contacted.
  constexpr std::pair<std::string_view, std::string_view> phrases[] = {
'''
for lang,phrase in phrases:s+='      {"'+lang+'", R"('+phrase.strip()+')"},\n'
s+='''  };
  for (const auto& [tag, phrase] : phrases)
    if (tag == primary) return phrase;
  return {};
}

Status BuildVoiceIdentity(std::span<const audio::SpeakerWindow> windows,
                          std::span<const audio::SpeakerEmbedding> embeddings,
                          size_t total_samples, std::vector<float>* identity,
                          const std::function<bool()>& cancelled) {
  if (!identity || windows.empty() || windows.size() > 1024 ||
      windows.size() != embeddings.size() || total_samples > 60 * 16000)
    return Status::Fail("Voice speaker windows exceed verification capacity");
  std::vector<audio::SpeakerEmbedding> normalized(embeddings.size());
  std::array<double, 192> sum{};
  size_t previous_end = 0;
  for (size_t row = 0; row < windows.size(); ++row) {
    if (cancelled && cancelled()) return Status::Fail("Voice verification cancelled");
    const auto& window = windows[row];
    if (window.begin_sample > window.core_begin_sample ||
        window.core_begin_sample >= window.core_end_sample ||
        window.core_end_sample > window.end_sample ||
        window.end_sample > total_samples ||
        window.core_begin_sample < previous_end)
      return Status::Fail("Voice speech core boundaries are inconsistent");
    previous_end = window.core_end_sample;
    double norm = 0;
    for (const auto value : embeddings[row]) {
      if (!std::isfinite(value)) return Status::Fail("Voice identity is nonfinite");
      norm += double(value) * value;
    }
    if (!(norm > 0) || !std::isfinite(norm))
      return Status::Fail("Voice identity is empty");
    norm = std::sqrt(norm);
    const auto weight = window.core_end_sample - window.core_begin_sample;
    for (size_t i = 0; i < sum.size(); ++i) {
      normalized[row][i] = embeddings[row][i] / norm;
      sum[i] += double(normalized[row][i]) * weight;
    }
    // Reuse the qualified native speaker reference cosine threshold. Unlike
    // an average-link cluster, one strong speaker cannot mask another voice.
    for (size_t other = 0; other < row; ++other) {
      double cosine = 0;
      for (size_t i = 0; i < sum.size(); ++i)
        cosine += double(normalized[row][i]) * normalized[other][i];
      if (cosine < .65)
        return Status::Fail("Recording contains inconsistent speaker identities");
    }
  }
  double norm = 0;
  for (const auto value : sum) norm += value * value;
  if (!(norm > 0) || !std::isfinite(norm))
    return Status::Fail("Voice aggregate identity is invalid");
  norm = std::sqrt(norm);
  std::vector<float> next(sum.size());
  for (size_t i = 0; i < next.size(); ++i) next[i] = sum[i] / norm;
  if (cancelled && cancelled()) return Status::Fail("Voice verification cancelled");
  *identity = std::move(next);
  return {};
}
}  // namespace q4t::server
'''
write('src/server/voice_verification.cpp',s)
for n in ['CMakeLists.txt','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake']:
 if n.endswith('HostTestSources.cmake'):
  change(n,'  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_language.cpp','  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_language.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../src/server/voice_verification.cpp')
 else:change(n,'  src/server/voice_language.cpp','  src/server/voice_language.cpp\n  src/server/voice_verification.cpp')
change('cmake/ChatProtocolIdentity.cmake','  include/q4t/server/voice_request.h','  include/q4t/server/voice_request.h\n  include/q4t/server/voice_verification.h')

from pathlib import Path
import json,hashlib,subprocess,tarfile,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';E=R/'docs/evidence/serve-custom-voice-service-cpu-20261118'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';engine=read(V/'voice-service-build-03/engine-result.json');assert engine['returncode']==0 and not engine['warnings']
assert sha(B/'q4t')==engine['binary_sha256']['q4t']
manifest=read(B/'generated/q4t/server/chat_protocol_sources.json');assert all(sha(R/n)==h for n,h in manifest.items())
C=V/'voice-service-candidate-01';C.mkdir(exist_ok=False);shutil.copy2(B/'q4t',C/'q4t');shutil.copy2(B/'generated/q4t/server/chat_protocol_sources.json',C/'chat_protocol_sources.json');shutil.copy2(B/'CMakeCache.txt',C/'CMakeCache.txt');save(C/'identity.json',{'engine_sha256':sha(C/'q4t'),'production_source_count':len(manifest),'production_source_drift':[],'runtime_http_qualified':False,'default_replaced':False})
first=read(V/'voice-service-cpu-01/result.json');fix=read(V/'voice-discovery-fix-cpu-01/result.json');assert first['status']=='FAIL' and fix['status']=='PASS'
log=(V/'voice-service-cpu-01/test.log').read_text();assert '[FAIL] voice_capabilities_distinguish_synthesis_from_registration_assets' in log and log.count('[FAIL]')==1 and log.count('[PASS]')==26
files=set()
for n in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines():
 if n.startswith(('src/','include/','tests/','cmake/','tools/serve_audit/')) or n=='CMakeLists.txt':files.add(R/n)
for folder in ['voice-service-build-01','voice-service-build-02','voice-service-build-03','voice-service-host-review-build-01','voice-service-cpu-01','voice-discovery-fix-build-01','voice-discovery-fix-cpu-01']:
 files|={p for p in (V/folder).rglob('*') if p.is_file() and p.suffix in ['.json','.log','.txt']}
for pattern in ['*voice*service*.py','*voice*service*.json','integrate_base_service*.py','integrate_voice*.py','develop_voice_verification*.py','add_voice_http*.py','voice-discovery-fix-plan*.json','fix_voice_discovery*.py']:
 files|=set(V.glob(pattern))
files|={C/'identity.json',C/'chat_protocol_sources.json'}
assert sum(p.stat().st_size for p in files)<16<<20
E.mkdir(exist_ok=False);index={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}
with tarfile.open(E/'records.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
with tarfile.open(E/'records.tar.gz','r:gz') as tar:
 for member in tar:
  with tar.extractfile(member) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==index[member.name]['sha256']
save(E/'index.json',index)
before=read(V/'voice-service-cpu-plan-04.json')['defaults'];after={n:sha(R/n) for n in before};assert before==after
result={'state':'NATIVE_SAMPLE_VOICE_SERVICE_CPU_QUALIFIED_HTTP_PENDING','cpu_first':first,'cpu_discovery_fix':fix,'distinct_contracts_qualified':27,'total_cpu_seconds':first['seconds']+fix['seconds'],'engine_build':engine,'ingress_build':read(V/'voice-service-build-02/host-result.json'),'candidate':read(C/'identity.json'),'archive_files':len(index),'archive_sha256':sha(E/'records.tar.gz'),'audit':read(V/'voice-service-inventory-01.json'),'default_before':before,'default_after':after,'default_unchanged':True,'gpu_actions':0,'full_task_complete':False,'pending':['real consent and sample HTTP, different speaker and wrong phrase negatives','new target text Speech/Chat plus independent ASR','scoped restart/revocation, SDK and TLS','managed package and preserved-state compatible rollback','reference audio ICL, prompt voices and Live','listening and speaker similarity']};save(E/'result.json',result)
(E/'README.md').write_text('''# 原生样本音色服务：针对CPU通过，HTTP待验

27项受影响合同最终通过：首轮26/27、0.415秒，Base-only能力声明
仍使用内置音色revision/SHA的失败保留；修复后只重验2项，2/2通过、
0.008秒。没有重跑已通过26项。引擎构建176.056秒零警告，原生入口
构建零警告；早期缓存准备中止与两处编译类型错误保留并修复。
0模型/GPU，默认rev316五份身份保持。

[结果](result.json)、[源码/记录索引](index.json)、[完整记录](records.tar.gz)。

- Base独立配置/健康/元数据，Speech与Chat使用同一客户域授权解析。
  每次解析检查实时consent，2048维条件由请求拥有，不替换成内置音色。
- 内置/Base共用一组talker/codec，受辅助模型锁和序列准入保护；设备
  真故障维持核心保护，资产/资源失败只影响相应可选后端。
- 原生录音核验接上独立ASR、192维说话人和原始24kHz条件。ASR不接收
  预期语句/语言提示；16语言完整固定短语和单说话人一致性有反例。
  固定语句是协议核对，不等于现实人物身份或法律授权的证明。
- 注册、查询、列表、改名、撤销、删除和客户隔离通过真实ObjectStore
  CPU检查；登记后CAS复核授权，撤销后的新解析拒绝。元数据走独立
  管理通道，无须模型健康。HTTP上传二进制/分块、10MiB预算和共享
  内存准入通过。Speech原4096字节路由上限已修复为现有有界输入预算。
- 原生网关新增7操作/4 CORS入口；939源码锚点与17遗漏负控通过。

CPU verifier使用明确标注的合成记录夹具，不代替真实模型核验。
引擎候选714源码身份一致，尚未HTTP验收、未替换默认。下一步真实
授权录音/不同说话人负例、ID合成新文本、Speech/Chat内容、SDK/TLS、
持久状态重启及兼容旧包回退。参考音频ICL、提示词音色/Live和听感/
相似度继续；不把一个样本路径或阶段当作总计划完成。
''')
note='''[真实样本音色服务CPU补齐](evidence/serve-custom-voice-service-cpu-20261118/README.md)：\n首轮26/27，修复Base-only发现SHA后2/2；27项合同最终通过。\n引擎176.056秒零警告、714源码身份一致；939审计锚点/17负控。\n0GPU，默认保持。Base真实HTTP新文本、SDK/TLS、包恢复及有状态\n回退继续；不把夹具或可编译入口当作业务验收。\n\n'''
p=R/'docs/STATUS.md';write(p,p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：样本音色服务27项CPU闭合，引擎构建完成\n\n'+note+'保留缓存恢复入口失效、编译类型错误和发现身份失败。只修复实际\n失败项并重验两个受影响发现合同。候选SHA `'+sha(C/'q4t')+'`；\n下一步冻结真实HTTP短验，继续总计划而非停止在组件/CPU。\n\n'+s.split('\n',1)[1].lstrip('\n'))
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['native_tts_progress']['custom_voice']['service']={'state':result['state'],'evidence':str((E/'README.md').relative_to(R/'docs')),'cpu_contracts':27,'gpu_loads':0,'engine_sha256':sha(C/'q4t'),'runtime_http_qualified':False,'remaining':result['pending']};write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/SERVE_CUSTOM_VOICES_2026-11-18.md';s=p.read_text();s=s.replace('当前Speech与Chat能解析`voice.id`，但\n真实注册/条件后端缺失；本项要实际合成注册音色，不能用换成内置','当前Speech与Chat已接入`voice.id`的真实\nBase条件路径，注册/核验源码与针对CPU完成、HTTP验收待推进。不能用换成内置');s=s.replace('完整源SHA通过后仅保留声纹前缀；全Base合成资产仍未保留。','早期源SHA通过后仅留声纹前缀；随后完整Base资产已取得并通过全SHA。');s+='''
服务源码与27项针对CPU已完成，见[服务CPU证据](evidence/serve-custom-voice-service-cpu-20261118/README.md)。
`--tts-base-model-dir`独立选择固定Base资产；启用登记还需已有ASR、
VAD和说话人资产。元数据/撤销不依赖模型健康；合成与注册分别按
真实统一RAM预算准入。候选未发布，真实HTTP与有状态兼容回退继续。
''';write(p,s)
print(json.dumps({'state':result['state'],'archive_files':len(index),'candidate_sha256':sha(C/'q4t'),'default_unchanged':True}))

"""Keep exact qualification and targeted control repair evidence separate."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_service.package import read, save, sha, require

W = Path(__file__).resolve().parent
OUT = ROOT/'docs/evidence/serve-mcp-recovery-contract-20261116'
require(not OUT.exists(), 'preserve existing evidence')
plan = read(W/'profiles-01/plan.json')
changed = {n for n,h in plan['sources'].items() if sha(ROOT/n) != h}
require(changed == {'tools/serve_recovery/profile_migration.py',
                    'tools/serve_recovery/version_contract.py'}, 'unexpected source delta')
for name in ('recovery-contract-cpu-01', 'recovery-contract-source-03',
             'release-native-build-01', 'profiles-prepare-01',
             'profiles-run-01', 'profiles-finalize-01'):
    require(read(W/(name+'.json'))['exit_code'] == 0, name+' failed')
require(read(W/'profiles-01/acceptance.json')['status'] ==
        'ACCEPT_PRIMARY_LIGHT_QUALIFICATION', 'profiles not accepted')
require(sha(plan['binary']) == plan['binary_sha256'], 'engine changed')
compiled = read(ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build/generated/q4t/server/chat_protocol_sources.json')
require(all(sha(ROOT/n) == h for n,h in compiled.items()), 'compiled source changed')
files = []
for prefix in ('recovery-contract-cpu-01', 'recovery-contract-source-01',
               'recovery-contract-source-02', 'recovery-contract-source-03',
               'release-native-build-01', 'profiles-prepare-01',
               'profiles-run-01', 'profiles-finalize-01'):
    files += [p for p in W.glob(prefix+'.*') if p.is_file()]
P = W/'profiles-01'
files += [p for p in P.iterdir() if p.is_file() and p.name != 'client-policy.json']
for child in ('qualified', 'lease'):
    files += [p for p in (P/child).iterdir() if p.is_file()]
policy = read(P/'client-policy.json')
tokens = [policy['gateway_token'].encode()]
require(all(not any(s in p.read_bytes() for s in tokens) and
            b'PRIVATE KEY-----' not in p.read_bytes() for p in files), 'private data in archive')
OUT.mkdir()
with tarfile.open(OUT/'qualification-and-cpu.tar.gz', 'w:gz') as archive:
    for path in files+[Path(__file__)]:
        archive.add(path, arcname=str(path.relative_to(W)), recursive=False)
decision = dict(status='PASS_MCP_RECOVERY_CONTRACT_CPU', cpu_tests=7,
    source_negative_checks=7, source_anchors=688, binary_sha256=plan['binary_sha256'],
    sources={n:sha(ROOT/n) for n in sorted(changed)},
    qualification=read(P/'acceptance.json'),
    qualification_source_commit=plan['source_commit'],
    qualification_reuse='Exact engine and all compiled sources unchanged; only the two management contract validators changed after qualification. Managed acceptance still required.',
    source_check_initial_failures=2, default_unchanged=True,
    remaining_master_tasks_open=True)
save(OUT/'decision.json', decision)
save(OUT/'raw-sha256.json', {str(p.relative_to(W)):sha(p) for p in files})
(OUT/'README.md').write_text('''# MCP恢复合同与主轻资格（2026-11-16）

精确引擎a49b5777在主/轻配置2启动8业务、88.606秒通过；84次
NVML正常，结构化/真实工具结果/embedding及状态连续性通过；本机
进程、端口、锁清理。资格仅代表精确引擎与配置，不冒充整树恢复。

随后修复两处控制合同：MCP输出三项及审批/隔离能力进入明确升级，
自动恢复保持完整能力；MCP、文件、程序私有策略的绑定与文件摘要
在版本恢复时必须一致。7项针对性CPU首过，覆盖旧入口、失败证据、
配额历史和新增权限丢失负控；来源7项负控/688锚点最终通过。前两次
来源检查因未更新审阅摘要而拒绝（第二次更新脚本类型检查错误），
原件保留。未移除字段/路由/allowlist或放松来源门禁。

两处Python修改不改变引擎/编译来源；明确复用刚通过的业务和配置
证据，不重复GPU。4个原生helper已零警告构建；仅ingress因MCP路由
接入改变，另外3个字节一致。继续封包、受控恢复及可回退发行/main，
默认rev126未变，全部master继续。当前累计3启动/16业务（含2次
embedding）；没有完整性能/全模型质量或长稳结论。
''')
save(OUT/'sha256.json', {p.name:sha(p) for p in OUT.iterdir() if p.is_file()})
print(json.dumps(dict(status=decision['status'], archived=len(files), cpu_tests=7)))

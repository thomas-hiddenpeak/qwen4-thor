import copy,json,os,runpy,tempfile,unittest,uuid
from pathlib import Path
W=Path(__file__).resolve().parent
m=runpy.run_path(str(W/'root_completion.py'))
class CompletionTests(unittest.TestCase):
 def test_real_original_budget_eligibility_requires_monotonic_expiry(self):
  state=W/'business-01/execution/state';c=json.loads((state/'ledger.json').read_text())['state'];o=json.loads((state/'outer-recovery/policy.json').read_text())['state']['policy']
  before=copy.deepcopy((c,o));now=max(c['clock']['monotonic_ns'],o['clock']['monotonic_ns']);boot=c['clock']['boot_id'];delay=m['budget_delay'](c,o,now,boot)
  self.assertGreater(delay,0);at=now+int(delay*1e9)
  self.assertGreater(m['budget_delay'](c,o,at-1000,boot),0)
  self.assertEqual(m['budget_delay'](c,o,at+1000,boot),0)
  with self.assertRaises(ValueError):m['budget_delay'](c,o,at+1000,str(uuid.uuid4()))
  self.assertEqual((c,o),before)
 def test_completion_counter_carries_all_prior_real_consumption(self):
  old=json.loads((W/'business-01/execution/result.json').read_text())['budget']['counts']
  with tempfile.TemporaryDirectory(dir=W) as d:
   b=m['LEGACY']['Budget'](Path(d),initialize=True,baseline=old,limits=m['LIMITS'])
   for k,n in [('starts',3),('chats',6)]:
    for _ in range(n):b.reserve(k,'CPU supplemental bound')
    with self.assertRaises(RuntimeError):b.reserve(k,'CPU must reject')
   with self.assertRaises(RuntimeError):b.reserve('probes','CPU no new probe')
if __name__=='__main__':unittest.main()

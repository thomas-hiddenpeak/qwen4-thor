"""Real root rollback, exact consumed cycles and bounded outer recovery."""
import argparse,copy,io,json,os,runpy,signal,subprocess,sys,time,traceback,uuid
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
VERSION=runpy.run_path(str(ROOT/'tools/serve_recovery/version_acceptance.py'))
MANAGED,LEGACY=VERSION['MANAGED'],VERSION['LEGACY']
LIMITS=dict(starts=7,chats=14,probes=1,controls=4000,seconds=900)
OLD_LIMITS=LEGACY['verify'].__globals__['limits_for']
LEGACY['verify'].__globals__['limits_for']=lambda name: LIMITS if name=='root_rollback' else OLD_LIMITS(name)
VERSION['actor'].__globals__['LIMITS']=LIMITS
VERSION['probe'].__globals__['LIMITS']=LIMITS
VERSION['Stage'].fatal_gateway.__globals__['__file__']=__file__
save=LEGACY['save'];WORK=Path(__file__).resolve().parent


def check_usage(usage,state,deadline,now):
    generation=state['model_generation']
    if (usage['phase']!='active' or usage['generation']!=generation or
        usage['owner']['pid']!=state['model_pid'] or
        usage['owner']['start_ticks']!=state['model_start_ticks']):
        raise ValueError('actual usage ownership differs')
    if usage['source'] is not None:
        if usage['source']['generation']!=generation-1 or usage['snapshot'] is None:
            raise ValueError('sealed predecessor differs')
    elif generation>1:
        if usage['snapshot'] is not None or deadline is None or now<deadline or state['quota_wait_ms']!=0:
            raise ValueError('unknown usage bypassed original conservative gate')


def exact_restoration(before,after):
    if {k:v for k,v in before.items() if k!='revision'}!={k:v for k,v in after.items() if k!='revision'}:
        raise ValueError('root switch erased or changed original recovery state')
    if after['revision']<=before['revision']:raise ValueError('version revision did not advance')


def budget_delay(core,outer,now,boot):
    from tools.serve_recovery import ledger,outer_policy
    ledger.validate(core,core['service_id']);outer_policy.validate(outer)
    if core['clock']['boot_id']!=boot or outer['clock']['boot_id']!=boot:
        raise ValueError('boot changed; original real cooldown cannot be inferred')
    if core['desired']!='STOPPED' or any(core['active'].values()) or core['quarantine'] is not None:
        raise ValueError('original scope must be durably stopped and unprotected')
    if outer['pending'] is not None or outer['protected'] or not outer['enabled']:
        raise ValueError('original outer not reusable')
    c=core['clock'];logical=c['logical_ns']+now-c['monotonic_ns']
    o=outer['clock'];outer_now=o['logical_ns']+now-o['monotonic_ns']
    if now<c['monotonic_ns'] or now<o['monotonic_ns']:
        raise ValueError('monotonic clock regressed')
    waits=[0,*(v-logical for v in core['circuit_until'].values()),
        *(v-logical for v in core['not_before'].values())]
    for role,attempts in core['attempts'].items():
        window=(30 if role=='model' else 15)*ledger.MINUTE
        waits += [at+window-logical for at in attempts]
    # Three new attempts must also fit the original daily model budget.
    recent=[at for at in core['attempts']['model'] if logical-at<ledger.DAY]
    if len(recent)>3:waits += [recent[-4]+ledger.DAY-logical]
    waits += [v['at']+outer_policy.WINDOW-outer_now for v in outer['starts']]
    return max(waits)/1e9


def prepare():
    from tools.serve_service import package as p
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit reviewed source')
    previous=WORK/'business-01';old=p.read(previous/'plan.json');result=p.read(previous/'execution/result.json')
    scope=previous/'execution/state';core=p.read(scope/'ledger.json')['state']
    outer=p.read(scope/'outer-recovery/policy.json')['state']['policy']
    delay=budget_delay(core,outer,time.monotonic_ns(),Path('/proc/sys/kernel/random/boot_id').read_text().strip())
    p.require(result['status']=='FAILED' and result['cleanup_failure'] is None and result['budget']['counts']==dict(starts=4,chats=8,probes=1,controls=2100),'original failure differs')
    out=WORK/'business-02';p.require(not out.exists(),'preserve completion evidence');out.mkdir(mode=0o700)
    names=set(old['sources'])|{str(Path(__file__).resolve().relative_to(ROOT))}
    names |= set(subprocess.check_output(['git','ls-files','tools/serve_recovery','tools/serve_host','src/service'],cwd=ROOT,text=True).splitlines())
    plan=dict(old,output=str(out),limits=LIMITS,prior_counts=result['budget']['counts'],
        prior_seconds=p.read(WORK/'gpu-business-01.json')['seconds'],resume_state=str(scope),
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        sources={n:p.sha(ROOT/n) for n in sorted(names)},
        state_before={n:p.sha(scope/n) for n in ('ledger.json','service.json','outer-recovery/policy.json','version-selection/policy.json')},
        prior_evidence=[dict(path=str(q),sha256=p.sha(q)) for q in [
            previous/'plan.json',previous/'execution/result.json',previous/'execution/stopped-2.json',
            previous/'execution/stopped-3.json',previous/'execution/rollback-tool-result-sse.wire',
            previous/'execution/tool-execution.json',previous/'lease/exit.json']],
        planned=dict(additional_starts=3,additional_chats=6,additional_probes=0,
                     total_starts=7,total_chats=14,outer_additional_starts=3),
        original_cycle_continuation=True,seconds_to_real_budget_availability=delay,
        sequence=['original retained consumed cycle, resume JSON',
                  'owned Guardian failure then actual outer-recovered JSON',
                  'forward original candidate cycle then structured SSE'],
        accepted_original_business_reused=True,new_guardian_diagnostics_in_original_roots=False)
    save(out/'plan.json',plan);print(json.dumps(dict(plan=str(out/'plan.json'),delay=delay,limits=LIMITS)))


def launcher(plan,path):
    _,_,_,_,service,p=LEGACY['load_modules'](plan);LEGACY['verify'](plan)
    from tools.serve_recovery import outer_runtime
    guardian=str(Path(plan['package']['package'])/'bin/q4t-guardian')
    original=subprocess.Popen
    def spawn(argv,**options):
        if argv[0]==guardian:
            config=Path(argv[argv.index('--config')+1]);value=p.read(config)
            recovery=value['version_recovery']
            p.require(recovery['registry']==plan['registration']['registry'],'root registry changed')
            evidence=copy.deepcopy(recovery)
            for name,commands in recovery['payloads'].items():
                for role in ('controller','gateway'):
                    commands[role]=[sys.executable,'-I','-B',str(Path(__file__).resolve()),role,
                        '--plan',str(path),'--payload',name,'--config',commands[role][-1]]
            helper=plan['probe_wrapper'];p.require(p.sha(helper['path'])==helper['sha256'],'probe changed')
            recovery['cuda_probe']=helper['path'];p.save(config,value)
            save(Path(plan['output'])/'execution'/('wrapper-'+config.parent.name+'.json'),
                 dict(production=evidence,validation=recovery))
        return original(argv,**options)
    subprocess.Popen=spawn
    try:
        state=Path(plan['resume_state'])
        if plan['outer']:
            result=outer_runtime.run(state,Path(plan['package']['package']),
                                     plan['package']['manifest_sha256'],activate=True)
            code=int(result['state']!='STOPPED' or not result['cleanup_confirmed'])
        else:
            result=service.launch(plan['package']['package'],plan['package']['manifest_sha256'],state)
            code=int(result['guardian_exit_code']!=0)
        save(Path(plan['output'])/'execution'/('launcher-'+str(plan['ordinal'])+'-result.json'),result)
        return code
    finally:subprocess.Popen=original


class Stage(MANAGED['Stage']):
    def __init__(self,plan,path):
        super().__init__(plan,path);self.ordinal=0;self.is_outer=False
        self.scope=Path(plan['resume_state']);self.active_registration=None
        self.service_id=self.engine.read(self.scope/'service.json')['service_id']

    def start(self,name,*,outer=False):
        self.ordinal+=1;self.is_outer=outer
        self.active_registration=self.plan['registrations'][name]
        plan=dict(self.plan,package=self.plan['roots'][name],registration=self.active_registration,
                  outer=outer,ordinal=self.ordinal)
        path=self.output/('launch-'+str(self.ordinal)+'.json');save(path,plan)
        with (self.output/('launcher-'+str(self.ordinal)+'.log')).open('xb') as log:
            self.process=subprocess.Popen([sys.executable,'-I','-B',str(Path(__file__).resolve()),
                'launcher','--plan',str(path)],stdin=subprocess.DEVNULL,stdout=log,stderr=log,
                pass_fds=(self.lease,),start_new_session=True,
                env={k:v for k,v in os.environ.items() if k not in
                     ('DBUS_SESSION_BUS_ADDRESS','NOTIFY_SOCKET','WATCHDOG_USEC')})

    def ready_payload(self,generation,name):
        state=self.wait(lambda s:s['model_generation']==generation and s['business_ready'])
        selected=state['version_recovery'];target=self.active_registration['payloads'][name]
        self.engine.require(selected['selected']==name and not selected['pending'] and
            selected['payload_manifest_sha256']==target['descriptor']['manifest_sha256'] and
            not selected['protected'],'runtime recovery payload differs')
        usage=self.family('usage');check_usage(usage,state,self.quota_deadlines.get(generation),time.monotonic())
        save(self.output/f'ready-{generation}.json',state);save(self.output/f'usage-{generation}.json',usage)
        return state

    def state_version(self):
        from tools.serve_recovery import access_store,version_store
        with version_store.open_bound(access_store.binding(self.scope,self.service_id)) as writer:
            return copy.deepcopy(writer.head['state']['policy'])

    def preserved(self):
        from tools.serve_recovery import deployment
        names=['ledger.json',*(w.directory_name+'/policy.json' for w in deployment.FAMILIES.values())]
        if (self.scope/'outer-recovery/policy.json').exists():names+=['outer-recovery/policy.json']
        return {n:self.engine.sha(self.scope/n) for n in names}

    def deploy(self,name,*,restore=None):
        from tools.serve_recovery import deployment
        desc=deployment.read_descriptor(self.scope);target=self.plan['roots'][name]
        before=self.preserved();version_before=self.state_version()
        result=deployment.switch(self.scope,target['package'],target['manifest_sha256'],
            expected=desc['manifest_sha256'],request_id=str(uuid.uuid4()),rollback=restore is not None)
        self.engine.require(self.preserved()==before,'deployment reset core/client/outer state')
        following=self.state_version()
        if restore is not None:
            exact_restoration(restore,following)
            self.engine.require(following['revision']==version_before['revision']+1,'global revision differs')
        save(self.output/('deployment-'+str(result['revision'])+'.json'),
             dict(result=result,protected=before,version_before=version_before,version_after=following))

    def schema(self,label,stream=False):
        body=copy.deepcopy(self.plan['requests']['schema'])
        if stream:
            from tools.examples.chat_client import read_sse
            body.update(stream=True,stream_options=dict(include_usage=True))
            response=read_sse(io.BytesIO(self.chat(label,body,raw_result=True)))
            content,finish=response.message['content'],response.finish_reason
        else:
            value=self.chat(label,body);choice=value['choices'][0]
            content,finish=choice['message']['content'],choice['finish_reason']
        self.engine.require(finish=='stop' and json.loads(content)=={'answer':42},'actual structured answer differs')

    def stop(self):
        if self.process is None:return
        if self.is_outer and self.process.poll() is None:
            from tools.serve_recovery import outer_control
            result=outer_control.request(self.service_id,'stop',timeout=2)
            save(self.output/('outer-stop-'+str(self.ordinal)+'.json'),result)
            self.process.wait(timeout=65)
        LEGACY['Stage'].stop(self)
        save(self.output/('stopped-'+str(self.ordinal)+'.json'),
             dict(preserved=self.preserved(),version=self.state_version()))
        self.process=None

    def family(self,name):
        from tools.serve_recovery import lifecycle,profile_store,usage_store
        writer=profile_store.Store if name=='profiles' else usage_store.Store
        end=time.monotonic()+5
        while True:
            try:return lifecycle.read_family(self.scope,dict(service_id=self.service_id),writer)
            except BlockingIOError:
                if time.monotonic()>=end:raise
                time.sleep(.025)

    def exercise(self):
        for n,digest in self.plan['state_before'].items():
            self.engine.require(self.engine.sha(self.scope/n)==digest,'original state changed: '+n)
        core=self.engine.read(self.scope/'ledger.json')['state']
        outer=self.engine.read(self.scope/'outer-recovery/policy.json')['state']['policy']
        delay=budget_delay(core,outer,time.monotonic_ns(),Path('/proc/sys/kernel/random/boot_id').read_text().strip())
        self.engine.require(delay==0,'real original cooldown still active')
        save(self.output/'original-state.json',dict(core=core,outer=outer,delay=delay))
        old=WORK/'business-01/execution'
        fresh=self.engine.read(old/'stopped-2.json')['version']
        spent=self.engine.read(old/'stopped-3.json')['version']
        self.engine.require(self.state_version()==spent,'original consumed cycle changed')
        self.start('retained',outer=True)
        first=self.ready_payload(5,'fallback');self.schema('retained-resume-json')
        self.kill(first,'guardian','owned-retained-completion')
        recovered=self.ready_payload(6,'fallback');self.schema('outer-recovered-json')
        self.engine.require(recovered['guardian_pid']!=first['guardian_pid'],'outer did not recover root')
        self.stop();self.deploy('candidate',restore=fresh);self.start('candidate',outer=True)
        self.ready_payload(7,'primary');self.schema('forward-candidate-sse',True)
        outer=self.engine.read(self.scope/'outer-recovery/policy.json')['state']['policy']
        counts=self.engine.read(self.output/'counts.json')['counts']
        self.engine.require(outer['total']==5 and all(counts[k]==n for k,n in
            [('starts',7),('chats',14),('probes',1)]),'actual cumulative dispatch differs')
        save(self.output/'business-final.json',dict(status='PASS',outer=outer,counts=counts,
            roots=self.plan['roots'],consumed_cycle_preserved=True,forward_cycle_restored=True,
            original_tool_executions=1,additional_tool_executions=0,automatic_tool_replay=False))

    def run(self):
        failure=cleanup=None
        def expire(*_):raise TimeoutError('bounded root business deadline; cleanup only')
        previous=signal.signal(signal.SIGALRM,expire);term=signal.signal(signal.SIGTERM,expire)
        signal.setitimer(signal.ITIMER_REAL,LIMITS['seconds']-self.plan['prior_seconds']-30)
        try:self.exercise();LEGACY['verify'](self.plan)
        except BaseException:failure=traceback.format_exc()
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            try:self.stop()
            except BaseException:cleanup=traceback.format_exc()
            signal.signal(signal.SIGALRM,previous);signal.signal(signal.SIGTERM,term)
            result=dict(status='PASS_BOUNDED_ROOT_ROLLBACK_BUSINESS' if not failure and not cleanup else 'FAILED',
                failure=failure,cleanup_failure=cleanup,seconds=time.monotonic()-self.started,
                budget=self.engine.read(self.output/'counts.json'),models=self.models,quota_deadlines=self.quota_deadlines,
                source_commit=self.plan['source_commit'],roots=self.plan['roots'],default_replaced=False,performance_acceptance=False)
            save(self.output/'result.json',result);print(json.dumps(result),flush=True)
        return int(failure is not None or cleanup is not None)


def main():
    os.umask(0o077);parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','run','launcher','controller','gateway','probe'))
    parser.add_argument('--plan',type=Path);parser.add_argument('--payload');parser.add_argument('--config',type=Path)
    args=parser.parse_args()
    if args.mode=='prepare':prepare();return 0
    plan=json.loads(args.plan.read_text())
    if args.mode=='launcher':return launcher(plan,args.plan)
    if args.mode in ('controller','gateway'):VERSION['actor'](plan,args.payload,args.mode,args.config);return 0
    if args.mode=='probe':VERSION['probe'](plan);return 0
    from tools.release.release import child_subreaper
    with child_subreaper():return Stage(plan,args.plan).run()
if __name__=='__main__':raise SystemExit(main())

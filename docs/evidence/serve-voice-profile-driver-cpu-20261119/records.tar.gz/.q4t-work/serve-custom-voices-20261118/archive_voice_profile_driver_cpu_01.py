from pathlib import Path
import hashlib,json,shutil,tarfile
from tools.serve_audit import check_inventory as audit
from tools.native_tts.acceptance import defaults
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';C=V/'voice-profile-driver-cpu-01';O=R/'docs/evidence/serve-voice-profile-driver-cpu-20261119';O.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
def save(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
result=read(C/'result.json');assert result['status']=='PASS' and result['cases']==12
for p,h in read(C/'sources.json').items():assert sha(R/p)==h
actual=audit.current_surface(R);inv=read(audit.INVENTORY)
changed={p for p in actual['sources_sha256'] if actual['sources_sha256'][p]!=inv['sources_sha256'].get(p)}
assert changed=={'tools/serve_recovery/profile_acceptance.py','tools/serve_recovery/profile_voice.py'},changed
for p in changed:inv['sources_sha256'][p]=actual['sources_sha256'][p]
save(audit.INVENTORY,inv)
errors=audit.check(inv,actual);mutations=audit.mutation_checks(inv,actual);assert not errors and mutations==17
save(O/'audit.json',dict(anchors=len(actual['sources_sha256']),mutations=mutations,errors=errors,reviewed=sorted(changed),semantics_certified=False))
protected=read(V/'voice-human-diagnostic-01/plan.json')['defaults'];assert defaults()==protected
save(O/'default-unchanged.json',protected)
files=[p for p in C.iterdir() if p.is_file()]+[V/n for n in ('implement_voice_profile_driver_01.py','run_voice_profile_driver_cpu_01.py','archive_voice_profile_driver_cpu_01.py')]+[R/n for n in ('tools/serve_recovery/profile_voice.py','tools/serve_recovery/profile_acceptance.py','tools/serve_recovery/test_profile_voice.py')]
assert shutil.disk_usage(R).free>(256<<20)+sum(p.stat().st_size for p in files)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}))
summary=dict(status='PASS_TARGETED_DRIVER_CPU_PENDING_REAL_VOICE_PROFILES',cases=12,seconds=result['seconds'],gpu_loads=0,model_loads=0,real_voice_primary_light_pending=True,default_replaced=False)
save(O/'result.json',summary)
write(O/'README.md',f'''# Base音色主/轻profile实际HTTP驱动CPU验证

新增8项及4项直接受影响合同全部通过，12项/{result['seconds']:.3f}秒，
0GPU/模型加载。固定输入SHA/完整PCM/独立反例、启动前3客户公平
容量、24业务POST预算、两profile命令Base依赖、CLI、返回ID与
无提示ASR、错误成功/错转录/缺历史拒绝和请求上限均有针对性检查。
CPU响应脚本只测试验证器与协议执行，不能作为真实业务或恢复资格。

profile_acceptance prepare增加--tts-base-config和--voice-fixtures，
前者同服务包native_tts_base结构，后者format为
q4t-profile-voice-inputs-v1、clips含consent/sample/different/negated，
各条为绝对WAV path及sha256。四条完整原始输入不同、总量≤8MiB，
仅作为测试输入，不预先假定它们符合授权或同声要求。当前英语请求
使用固定授权语言en，真实ASR由服务执行，调用不传原文/语言提示。

每个profile实际执行12个业务POST和5个元数据请求：先验证授权、
跨客户、异声/配额反例，获取本次真实ID后合成两句新文本，独立ASR
检查两份音频并GET存储Chat历史，再撤销并确认不可继续使用。健康、
实际usage和自然EOS一起生成voice证据；任何中途失败保留原始wire。
配置不足3队列槽时在启动前拒绝，须显式选择被验profile容量，驱动
不会静默扩大包或部署的预算。Base与ASR/VAD/speaker固定身份一起绑定。

来源审计{len(actual['sources_sha256'])}锚点/17负控通过，新增helper也自动入表。
默认rev316保持。实际两profile完整业务、Base-only已有音色消费资格、
保存状态回退及原合成音色不匹配仍待闭合，总目标继续active。
''')
p=R/'docs/serve-master-goals-v2.json';data=read(p);row=data['native_tts_progress']['custom_voice']['service']['package_recovery'];row.update(real_profile_driver_pending=False,real_profile_execution_pending=True,profile_driver_evidence='evidence/serve-voice-profile-driver-cpu-20261119/README.md',profile_driver_cpu_cases=12);save(p,data)
text='''[Base实际profile驱动12项CPU通过](evidence/serve-voice-profile-driver-cpu-20261119/README.md)：
2.517秒/0GPU，真实ID和无提示ASR路径、错误成功/错转录/缺历史拒绝，
固定录音与3客户准入及请求边界通过；940来源锚点/17负控。驱动具备，
真实两profile、原合成音色不匹配和保存状态回退继续；默认rev316保持。
'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — Base实际profile驱动CPU验证通过\n\n'+text+'\n做了什么：可执行的每profile注册/合成/ASR/历史/反例/撤销链；\n为什么：只有真实完整业务证据才能启用相应恢复资格；\n下一步：合适注册录音、真实两profile及保存状态回退，不停止总目标。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;write(p,s.replace(marker,marker+content,1))
print(json.dumps(summary));print(json.dumps(dict(anchors=len(actual['sources_sha256']),archive_bytes=(O/'records.tar.gz').stat().st_size)))

from pathlib import Path
p=Path('tools/serve_recovery/profile_acceptance.py');s=p.read_text()
def edit(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
edit('from tools.serve_recovery import bundle, profile_contract, profile_evidence','from tools.serve_recovery import bundle, profile_contract, profile_evidence, profile_voice')
edit('def limits_for(profile, native_asr=None, chat_audio=False, native_tts=None):','def limits_for(profile, native_asr=None, chat_audio=False, native_tts=None,\n               native_tts_base=None):')
edit("    return dict(LIMITS, chats=(10 if profile.get('allow_media', False) else 8) +", """    if native_tts_base is not None:
        package.tts_settings(native_tts_base, base=True)
        require(native_asr is not None and {'speaker', 'vad'} <= native_asr.keys(),
                'voice registration qualification requires ASR, speaker and VAD')
        package.asr_settings(native_asr, voice_registration=True)
        require(native_tts is None or package.same_json(native_tts['limits'],
                native_tts_base['limits']), 'TTS profile families must share effective limits')
    return dict(LIMITS, chats=(10 if profile.get('allow_media', False) else 8) +
                (2*profile_voice.POSTS_PER_PROFILE if native_tts_base is not None else 0) +""")
edit("    asr_path = getattr(args, 'asr_config', None)\n    asr = package.asr_settings(read(asr_path)) if asr_path else \\\n        base['settings'].get('native_asr')", """    voice_path = getattr(args, 'tts_base_config', None)
    voice = (package.tts_settings(read(voice_path), base=True) if voice_path else
             base['settings'].get('native_tts_base'))
    if voice is not None:base['settings']['native_tts_base'] = voice
    asr_path = getattr(args, 'asr_config', None)
    asr = package.asr_settings(read(asr_path), voice_registration=voice is not None) if asr_path else \\
        base['settings'].get('native_asr')""")
edit('    limits = limits_for(selected, asr, chat_audio, tts)','''    limits = limits_for(selected, asr, chat_audio, tts, voice)
    fixture_path = getattr(args, 'voice_fixtures', None)
    require((voice is not None) == (fixture_path is not None),
            'Base registration qualification needs its explicit voice fixture manifest')
    clips = profile_voice.fixtures(fixture_path) if voice is not None else None
    if voice is not None:
        # Validate the three real client identities before any model startup.
        profile_voice.client_policy(Stage.client_policy_base(), selected, voice)''')
edit("    if chat_audio: plan['chat_audio'] = True", """    if chat_audio: plan['chat_audio'] = True
    if voice is not None:
        plan['voice_clips'] = clips
        for p in (voice_path, fixture_path):
            if p is not None:
                p = p.resolve(strict=True);plan['sources'][str(p)] = sha(p)
        for row in clips.values():plan['sources'][row['path']] = row['sha256']
        source = Path(profile_voice.__file__).resolve()
        plan['sources'][str(source)] = sha(source)""")
edit('            asr, tts))','            asr, tts, voice))')
a=s.index('    if tts is not None:\n        speech_assets =');b=s.index('    if asr is not None:\n',a)
part=s[a:b]
part=part.replace('    if tts is not None:\n        speech_assets = Path(tts[\'directory\'])', "    for speech_model, fixed in ((tts, package.NATIVE_TTS),\n                                (voice, package.NATIVE_TTS_BASE)):\n        if speech_model is None:continue\n        speech_assets = Path(speech_model['directory'])")
part=part.replace("package.NATIVE_TTS['weight_sha256']", "fixed['weight_sha256']").replace("package.NATIVE_TTS['codec_weight_sha256']", "fixed['codec_weight_sha256']")
s=s[:a]+part+s[b:]
edit("                           chats=6 + 2 * chat_audio + (2 if tts is not None else 0),", "                           chats=6 + 2 * chat_audio + (2 if tts is not None else 0) +\n                                 (2 if voice is not None else 0),")
edit("    if tts is not None:\n        plan['planned']['native_speech_requests']", """    if voice is not None:
        plan['planned']['native_voice_business_requests'] = 2*profile_voice.POSTS_PER_PROFILE
        plan['planned']['native_voice_registrations'] = 4
        plan['planned']['registered_voice_synthesis_requests'] = 4
        plan['planned']['registered_voice_transcriptions'] = 4
    if tts is not None:
        plan['planned']['native_speech_requests']""")
a="plan.get('chat_audio', False), plan['base']['settings'].get('native_tts'))"
assert s.count(a)==2;s=s.replace(a,"plan.get('chat_audio', False), plan['base']['settings'].get('native_tts'),\n                                 plan['base']['settings'].get('native_tts_base'))")
# The two callers above are Stage construction and finalization.
edit('    def client_policy(self):\n        value = super().client_policy()', '''    @staticmethod
    def client_policy_base():
        # Reuse the existing private qualification policy, without an engine.
        stage = object.__new__(Stage)
        return encrypted.Stage.client_policy(stage)

    def client_policy(self):
        value = super().client_policy()
        base = self.plan['base']['settings'].get('native_tts_base')
        if base is not None:
            return profile_voice.client_policy(value, self.plan['profiles']['primary'], base)''')
edit("        save(self.out/'client-policy.json', self.client_policy())", "        policy = self.client_policy()\n        capacity.check_clients(self.plan['profiles'][name], policy)\n        save(self.out/'client-policy.json', policy)")
edit("        if profile_evidence.has_speaker(self.plan['identity']):\n            early['speaker']", "        if self.plan['identity'].get('native_tts_base') is not None:\n            early['voice'] = profile_voice.Lifecycle(self).run()\n        if profile_evidence.has_speaker(self.plan['identity']):\n            early['speaker']")
edit("    p.add_argument('--asr-config', type=Path,", "    p.add_argument('--tts-base-config', type=Path,\n                   help='explicit Base identity, asset directory and shared TTS budgets')\n    p.add_argument('--voice-fixtures', type=Path,\n                   help='pinned consent/sample/different/negated WAV manifest; never success evidence')\n    p.add_argument('--asr-config', type=Path,")
t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
p=Path('tools/serve_recovery/profile_voice.py');s=p.read_text()
a="    require(len({row['sha256'] for row in result.values()}) == len(NAMES),"
b="    require(sum(Path(row['path']).stat().st_size for row in result.values()) <= 8 << 20,\n            'voice fixture aggregate byte bound')\n"+a
assert s.count(a)==1;s=s.replace(a,b)
a="        message = evidence.message(chat, 'stop')\n        raw = base64.b64decode"
b="""        message = evidence.message(chat, 'stop')
        stored = self.accepted(self.http('stored-chat',
            '/v1/chat/completions/'+chat['id']))
        saved = evidence.message(stored, 'stop')
        require(stored.get('id') == chat['id'] and saved.get('audio', {}).get('id') ==
                message['audio']['id'] and saved['audio'].get('transcript') ==
                message['audio']['transcript'], 'registered Chat audio history not retained')
        raw = base64.b64decode"""
assert s.count(a)==1;s=s.replace(a,b);t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
print('Base primary/light driver implemented; CPU and real HTTP not yet executed')

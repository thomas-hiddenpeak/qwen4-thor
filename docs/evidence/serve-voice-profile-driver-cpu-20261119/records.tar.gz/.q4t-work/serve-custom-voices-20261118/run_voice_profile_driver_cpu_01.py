from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,sys,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-profile-driver-cpu-01';O.mkdir(exist_ok=False)
module='tools.serve_recovery.test_profile_voice.VoiceDriver.'
tree=ast.parse((R/'tools/serve_recovery/test_profile_voice.py').read_text())
names=[module+n.name for c in tree.body if isinstance(c,ast.ClassDef) and c.name=='VoiceDriver' for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
names+=['tools.serve_recovery.test_tts_profiles.TtsProfiles.'+n for n in ('test_driver_audio_budget_covers_full_frames_without_changing_text_fixture','test_reload_budget_includes_one_final_speech_per_profile','test_native_cli_and_both_profile_commands_keep_tts')]
names+=['tools.serve_recovery.test_voice_profiles.VoiceProfiles.test_voice_receipt_requires_ids_audio_asr_usage_negatives_and_revocation']
assert len(names)==12
plan=dict(scope='Base primary/light actual HTTP driver and early failure gates; synthetic CPU wire is never business qualification',cases=12,required=names,seconds=120,gpu_loads=0,model_loads=0,real_voice_http_pending=True,disk_reserve_bytes=256<<20)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
paths=['tools/serve_recovery/profile_acceptance.py','tools/serve_recovery/profile_voice.py','tools/serve_recovery/test_profile_voice.py','tools/serve_recovery/profile_evidence.py']
(O/'sources.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
text='''Base主/轻profile真实验收驱动已补：显式Base配置和4份固定录音，\n每profile 12业务POST及5控制请求，真实注册ID→Speech/Chat→独立ASR、\n存储历史、跨客户/配额/错误授权/异声反例和撤销；启动前核对3客户\n公平容量，不能复用旧内置音色证据。冻结12 CPU/120秒/0GPU；\n真实HTTP仍待合适录音和完整流程通过，默认不变。\n'''
for name,marker,content in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — Base实际profile驱动成组冻结\n\n'+text+'\n为什么：证据合同须有真正执行的业务驱动，拒绝凭声明启用恢复；\n下一步：针对性CPU反例、真实音色及保存状态验收。\n\n')]:
 p=R/name;s=p.read_text();assert marker in s;t=p.with_name(p.name+'.edit');t.write_text(s.replace(marker,marker+content,1));t.replace(p)
assert shutil.disk_usage(R).free>=plan['disk_reserve_bytes']
start=time.monotonic();cmd=[sys.executable,'-B','-m','unittest','-v',*names]
with (O/'tests.log').open('x') as f:run=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
result=dict(status='PASS' if run.returncode==0 else 'FAILED',seconds=time.monotonic()-start,returncode=run.returncode,cases=12,command=cmd,gpu_loads=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((O/'tests.log').read_text()[-4500:]);sys.exit(run.returncode)

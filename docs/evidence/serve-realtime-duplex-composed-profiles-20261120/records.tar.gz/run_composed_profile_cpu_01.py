from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'profile-composition-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
names=['test_default_package_has_native_binary_and_no_nginx_dependency','test_v23_seals_speech_dependencies_and_preserves_v22','test_v24_duplex_validator_closure_is_sealed','test_relocated_v24_imports_actual_duplex_validators_without_repository','test_historical_source_inventory_versions_remain_verifiable','test_relocated_v23_can_import_speech_evidence_without_repository']
commands=[['python3','-B','-m','unittest','-v','tools.serve_recovery.test_profile_duplex_composed'],['python3','-B','-m','unittest','-v',*['tools.serve_recovery.test_native_bundle.BundleTests.'+n for n in names]],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
files=['tools/serve_recovery/'+n+'.py' for n in ['bundle','profile_record','profile_evidence','profile_duplex_evidence','profile_duplex_composed','profile_duplex_composed_reuse','profile_duplex_composed_source','test_profile_duplex_composed','test_native_bundle']]+['tools/serve_audit/inventory.json','.github/workflows/host-checks.yml']
plan=dict(scope='Fixed actual source composition and native v24 packaging; no runtime changes or new GPU work.',limits=dict(new_cpu=12,packaging=6,source_counterexamples=20,seconds=120,gpu_starts=0),commands=commands,sources={n:sha(R/n) for n in files},protected={n:sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')});save('plan.json',plan)
started=time.monotonic();rows=[];counts=[];status='PASS'
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=max(1,120-(time.monotonic()-started)),env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O)))
 (O/f'{i}.stdout').write_bytes(r.stdout);(O/f'{i}.stderr').write_bytes(r.stderr);rows.append(dict(command=cmd,exit_code=r.returncode))
 if i<2:
  m=re.search(rb'Ran (\d+) tests?',r.stderr);counts.append(int(m[1]) if m else 0)
 if r.returncode:status='FAIL'
if counts!=[12,6]:status='FAIL'
assert all(sha(R/n)==h for n,h in plan['protected'].items())
result=dict(status=status,test_counts=counts,commands=rows,seconds=time.monotonic()-started,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

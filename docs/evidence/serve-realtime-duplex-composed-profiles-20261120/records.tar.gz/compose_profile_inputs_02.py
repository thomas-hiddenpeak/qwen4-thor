"""Read-only offline composition input audit; no qualification or GPU work."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_recovery import ledger,profile_realtime,profile_duplex_evidence as d,profile_evidence as e
from tools.serve_realtime import duplex_task_checks as c
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
O=W/'profile-composition-inputs-02';O.mkdir(mode=0o700)
def journal(stage,mode):return [json.loads(l) for l in (W/stage/('light-duplex-'+mode+'.events.jsonl')).read_text().splitlines()]
def state(stage,mode,suffix):
 p=W/stage/('light-duplex-'+mode+'-'+suffix)
 assert read(Path(str(p)+'.http.json'))['status']==200
 return profile_realtime.state(profile_realtime.encrypted.foreground.base.lifecycle.parse_metrics(Path(str(p)+'.wire').read_bytes()),profile_realtime.encrypted.CLIENT)
primary=read(W/'audio-boundary-business-01/primary-duplex-observed.json');d.original_business(primary)
stage='audio-boundary-business-01';manual=read(W/stage/'light-duplex-manual.sdk.json');source=read(W/stage/'plan.json')['duplex']['source']
manual_observed=d.duplex_checks.observe(manual,d.PHRASE,source);d.duplex_checks.journal_matches(journal(stage,'manual'),manual)
manual_w=dict(session=manual,before=state(stage,'manual','before'),after=state(stage,'manual','after-0'))
for key in ('before','after'):d.state(manual_w[key])
assert manual_w['after']['admitted']-manual_w['before']['admitted']==manual_observed['admitted']==11
assert manual_w['after']['settled']-manual_w['before']['settled']>manual_observed['visible_tokens']
vad=read(W/stage/'light-duplex-vad.sdk.json');d.duplex_checks.journal_matches(journal(stage,'vad'),vad)
assert vad['status']=='FAIL' and vad['error']=='response status: completed'
stage='task-scoped-business-01';tasks=read(W/stage/'light-duplex-speech_tool.sdk.json');task_source=read(W/stage/'plan.json')['duplex']['source'];task_journal=journal(stage,'speech_tool');task_observed=c.observe(tasks,d.PHRASE,task_source,task_journal);assert all(q['status']=='PASS' for q in task_observed['quality'])
task_review=read(W/stage/'speech-tool-reviewed.json');assert task_review['observed']==task_observed
stage='cancel-usage-business-01';cancel=read(W/stage/'light-duplex-sessions-observed.json')['barge_in'];cancel_journal=journal(stage,'barge_in');cancel_source=read(W/stage/'plan.json')['duplex']['source'];cancel_observed=c.observe(cancel['session'],d.PHRASE,cancel_source,cancel_journal);assert all(q['status']=='PASS' for q in cancel_observed['quality'])
light=dict(original_source=source,original_manual=manual_w,original_vad=vad,
 tasks=dict(source=task_source,session=tasks,before=task_review['before'],after=task_review['after'],journal=task_journal),
 cancel=dict(source=cancel_source,**cancel,journal=cancel_journal))
input_fields={}
for name,stage in [('primary','profiles-01'),('light','profiles-03')]:
 input_fields[name]={k:read(W/stage/(name+'-'+stem+'-business.json')) for k,stem in [('realtime','realtime'),('semantic_vad','semantic')]}
 e.realtime_business(input_fields[name]['realtime'])
 e.semantic_business(input_fields[name]['semantic_vad'],read(W/stage/'plan.json')['identity'])

previous=Path('.q4t-work/serve-realtime-audio-20261120/cancel-profiles-01/qualified')
summary={}
for name,new in [('primary',primary),('light',light)]:
 original=read(previous/(name+'.json'));value=dict(original['business'],**input_fields[name],realtime_duplex=new)
 (O/(name+'-input.json')).write_bytes(ledger.canonical(dict(duplex=new,inputs=input_fields[name]))+b'\n')
 summary[name]=dict(input_sha256=sha(O/(name+'-input.json')),duplex_digest=ledger.digest(new),input_digests={k:ledger.digest(v) for k,v in input_fields[name].items()},estimated_profile_bytes=len(ledger.canonical(dict(original,business=value))),manual_quality_failures=[q for q in manual_observed['quality'] if q['status']=='FAIL'] if name=='light' else [])
summary['qualification_issued']=False
(O/'review.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n');print(json.dumps(summary,ensure_ascii=False))

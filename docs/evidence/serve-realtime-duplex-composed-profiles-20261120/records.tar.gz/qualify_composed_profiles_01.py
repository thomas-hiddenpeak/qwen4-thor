"""Issue source-reviewed composition only from immutable actual observations."""
import copy,fcntl,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_recovery import ledger,profile_contract,profile_evidence,profile_record,bundle
from tools.serve_recovery import profile_duplex_composed as c,profile_duplex_composed_reuse as reuse
from tools.serve_recovery.profile_duplex_composed_source import OBSERVED,REVIEW
from tools.serve_ops import contracts
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import profile_acceptance as full
O=W/'composed-profiles-01';O.mkdir(mode=0o700)
# The committed raw indexes are independent of this new composition driver.
archives={};records={}
for p in (R/'docs/evidence').glob('serve-realtime-duplex*/index.json'):
 index=read(p)
 for row in index.get('records',[]):
  records.setdefault(row['path'],[]).append((p,row['sha256']))
def original(path):
 key=str(path.relative_to(W));digest=sha(path)
 matches=[p for p,h in records.get(key,[]) if h==digest]
 require(matches,'raw observation not in committed archive: '+key)
 index=matches[0]
 if str(index) not in archives:
  require(sha(index.parent/'records.tar.gz')==read(index)['archive_sha256'],'archived bytes drift')
  archives[str(index)]=sha(index)
 return digest

cpu=W/'profile-composition-cpu-01';require(read(cpu/'result.json')['status']=='PASS','CPU prerequisites')
for n,h in read(cpu/'plan.json')['sources'].items():require(sha(R/n)==h,'CPU source drift: '+n)
latest=read(W/'cancel-usage-business-01/plan.json')
for n,h in {**latest['reviewed_sources'],**latest['native_assets'],**latest['protected']}.items():require(sha(R/n)==h,'runtime/assets/default drift: '+n)
require(sha(latest['binary'])==REVIEW['candidate_binary'] and latest['identity']['protocol_sha256']==REVIEW['candidate_protocol'],'candidate differs')
require(ledger.digest(latest['repair_source_review'])==REVIEW['cancel_usage_source_review'] and
 sha(W/'cancel-usage-business-01/acceptance.json')==REVIEW['cancel_usage_acceptance'],'cancel source proof drift')
for p,key in [(W/'profile-source-04/review.json','original_duplex_source_review'),(W/'audio-boundary-business-01/source-review.json','audio_boundary_source_review')]:
 require(sha(p)==REVIEW[key],'source review drift')
bundle.check_assets(latest['model'],latest['model_assets'])
base_path=Path(latest['previous_registry']);require(sha(base_path)==REVIEW['previous_registry_sha256'],'previous qualified registry')
oldregistry=read(base_path)
rows=[];queries_total=0;allclean=[];raw_files={}
for stage in ('profiles-01','profiles-03','audio-boundary-business-01','task-scoped-business-01','cancel-usage-business-01'):
 path=W/stage;result=read(path/'result.json');guard=read(path/'lease/exit.json')
 require(guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] is True and
 guard['status']==('COMPLETED' if stage=='cancel-usage-business-01' else 'COMMAND_FAILED') and
 guard['child_returncode']==(0 if stage=='cancel-usage-business-01' else 1),'unexpected strict guard status')
 queries=[json.loads(l) for l in (path/'lease/nvml-queries.jsonl').read_text().splitlines()]
 require(queries and all(q['status']=='OK' and q['returncode']==0 and not q['observed_errors'] for q in queries),'invalid monitor evidence')
 queries_total+=len(queries)
 lease_events=[json.loads(l) for l in (path/'lease/events.jsonl').read_text().splitlines()]
 require(lease_events[-1]['event']=='lease_released' and not any(e.get('conflicts') for e in lease_events),'lease not cleanly released')
 cleanpaths=[path/'cleanup.json']+([path/'primary-cleanup.json'] if stage=='audio-boundary-business-01' else [])
 for p in cleanpaths:
  v=read(p);require(v['remaining']==[] and v['model_exit']==0 and v['ports_released'] is True and v['lease_continuously_held'] is True,'owned model cleanup failed');allclean.append(v)
 require(len(cleanpaths)==result['counts']['starts'],'exact actual model count')
 for p in path.glob('*-entry-cleanup.json'):
  v=read(p);require(v['exit_code']==0 and v['port_released'] is True,'entry cleanup failed')
 selected=[path/'plan.json',path/'result.json',*cleanpaths,*path.glob('*-entry-cleanup.json'),path/'lease/exit.json',path/'lease/events.jsonl',path/'lease/nvml-queries.jsonl']
 for p in selected:raw_files[str(p.relative_to(W))]=original(p)
 rows.append(dict(stage=stage,original_status=result['status'],guard_status=guard['status'],nvml_queries=len(queries),model_starts=result['counts']['starts'],cleanup_complete=True,model_quality_repaired=False))
process_guard=full.encrypted.foreground.base.lifecycle.guard if hasattr(full,'encrypted') else __import__('tools.serve_responses.encryption_acceptance',fromlist=['foreground']).foreground.base.lifecycle.guard
processes=process_guard.processes()
require(not any(processes.get(int(pid),{}).get('start_ticks')==v['start_ticks'] for cl in allclean for pid,v in cl['owned'].items()),'owned process remains')
with process_guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
save(O/'environment-composition.json',dict(stages=rows,raw_files=raw_files,archives=archives,original_failures_preserved=True,new_gpu_starts=0))
environment=dict(status='PASS',env_abort=False,all_queries_ok=True,nvml_queries=queries_total,lease_result_sha256=sha(O/'environment-composition.json'),cleanup_complete=True)
plan=copy.deepcopy(latest);plan.update(output=str(O),targeted_format='q4t-reviewed-duplex-composition-v1',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),scope='Fixed original actual tasks composed by source dependency; no new GPU or model quality repair',sources={n:sha(R/n) for n in bundle.SOURCES},observed_source_review=copy.deepcopy(REVIEW))
plan['sources'].update(latest['reviewed_sources']);plan['sources'].update({str(cpu/n):sha(cpu/n) for n in ('plan.json','result.json')});plan['sources'][str(Path(__file__))]=sha(Path(__file__))
save(O/'plan.json',plan)
qualified=O/'qualified';qualified.mkdir(mode=0o700)
registry=dict(format=profile_contract.FORMAT,identity=plan['identity'],profiles=plan['profiles'],qualifications={});projection={}
for name in profile_contract.NAMES:
 previous=base_path.parent/(name+'.json');require(sha(previous)==reuse.prior.SOURCES[name]['record_sha256'],'old record changed')
 old=profile_record.read(previous);profile_evidence.validate(old,oldregistry,name,sha(previous))
 inputpath=W/'profile-composition-inputs-02'/(name+'-input.json');require(sha(inputpath)==OBSERVED[name]['input_sha256'],'input receipt changed')
 data=json.loads(inputpath.read_text());business=copy.deepcopy(old['business']);business.update(data['inputs']);business['realtime_duplex']=dict(format=c.FORMAT,profile=name,source_review=copy.deepcopy(REVIEW),data=data['duplex']);c.business(business['realtime_duplex'])
 stage='audio-boundary-business-01' if name=='primary' else 'cancel-usage-business-01'
 cappath=W/stage/(name+'-capabilities.json');configpath=W/stage/(name+'-config.json')
 raw_files[str(cappath.relative_to(W))]=original(cappath);raw_files[str(configpath.relative_to(W))]=original(configpath)
 caps=read(cappath);config=read(configpath);old_protocol=caps['protocol_source_sha256'];require(config['protocol_source_sha256']==old_protocol,'observed config identity differs')
 # Primary observed on the boundary build, light on the category observer build.
 # Only the protocol identity is projected through the reviewed five-file delta.
 # Original config/caps bytes and their actual binary remain in the source proof.
 caps['protocol_source_sha256']=REVIEW['candidate_protocol'];config['protocol_source_sha256']=REVIEW['candidate_protocol']
 projection[name]=dict(actual_stage=stage,actual_binary=read(W/stage/'plan.json')['binary_sha256'],actual_protocol=old_protocol,qualified_protocol=REVIEW['candidate_protocol'],startup_memory_observed_on_candidate=(name=='light'),configuration_projection='protocol_source_sha256 only; unchanged backend/settings/startup planner',capabilities_sha256=sha(cappath),configuration_sha256=sha(configpath))
 save(O/(name+'-capabilities.json'),caps);save(O/(name+'-config.json'),config)
 value=reuse.attach(dict(format=profile_evidence.DUPLEX_FORMAT,profile=name,identity=plan['identity'],capacity=plan['profiles'][name],capabilities=caps,configuration=contracts.configuration(config,version=5),startup_memory=config['startup_memory']['checks']['before_allocations'],business=business,environment=environment))
 p=qualified/(name+'.json');profile_record.save(p,value)
 registry['qualifications'][name]=profile_contract.qualification(name,value['capacity'],value['identity'],value['capabilities'],value['configuration'],value['startup_memory'],sha(p))
profile_contract.validate(registry)
for name in profile_contract.NAMES:
 p=qualified/(name+'.json');profile_evidence.validate(profile_record.read(p),registry,name,sha(p))
profile_contract.capability_pair(read(O/'primary-capabilities.json'),read(O/'light-capabilities.json'))
save(O/'source-composition.json',dict(review=REVIEW,observed=OBSERVED,configuration_projection=projection,raw_files=raw_files,archives=archives))
save(qualified/'registry.json',registry)
save(O/'acceptance.json',dict(status='ACCEPT_COMPOSED_DUPLEX_PRIMARY_LIGHT',registry_sha256=sha(qualified/'registry.json'),source_composition_sha256=sha(O/'source-composition.json'),environment=environment,new_gpu_starts=0,original_failures_preserved=True,original_model_quality_status='FAIL',model_quality_repaired=False,default_unchanged=True,managed_recovery_accepted=False,full_matrix=False,master_active=True,profile_bytes={n:(qualified/(n+'.json')).stat().st_size for n in profile_contract.NAMES}))
print(json.dumps(read(O/'acceptance.json')))

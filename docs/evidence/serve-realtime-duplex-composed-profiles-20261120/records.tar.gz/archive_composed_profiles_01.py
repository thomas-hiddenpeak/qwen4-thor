from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-duplex-composed-profiles-20261120';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
B=W/'composed-profiles-01';a=read(B/'acceptance.json');cpu=read(W/'profile-composition-cpu-01/result.json');assert a['status']=='ACCEPT_COMPOSED_DUPLEX_PRIMARY_LIGHT' and cpu['status']=='PASS'
for n,h in read(W/'profile-composition-cpu-01/plan.json')['sources'].items():assert sha(R/n)==h
review=dict(acceptance=a,cpu=cpu,source=read(B/'source-composition.json'),master_active=True,managed_recovery_pending=True);save(O/'review.json',review)
secrets=[read(W/stage/'client-policy.json')['gateway_token'].encode() for stage in ('profiles-01','profiles-03','audio-boundary-business-01','task-scoped-business-01','cancel-usage-business-01')]
paths=[p for directory in (B,W/'profile-composition-cpu-01') for p in directory.rglob('*') if p.is_file()]+[W/'qualify_composed_profiles_01.py',W/'run_composed_profile_cpu_01.py',W/'profile-composition-scope-01.json',W/'compose_profile_inputs_02.py',Path(__file__)]
rows=[];omitted=[]
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for f in paths:
  n=str(f.relative_to(W));entry=dict(path=n,bytes=f.stat().st_size,sha256=sha(f))
  if any(s in f.read_bytes() for s in secrets):omitted.append(entry);continue
  tar.add(f,arcname=n,recursive=False);rows.append(entry)
save(O/'index.json',dict(records=rows,omitted=omitted,archive_sha256=sha(O/'records.tar.gz')))
(O/'README.md').write_text('''# 双向输入主轻资格与独立恢复包校验

2026-11-20，候选ecd6cc23，协议f0c82ef9。12项资格校验、6项封包
检查和20来源反例通过，2.000秒，新增GPU为0。v24封装双向校验模块，
隔离目录可独立导入，v1—v23旧源清单仍可验证；没有新增外部依赖。

主轻资格以确切来源组合既有实测：独立ASR/语义输入、主档完整双向、
轻量手动/混合输入、VAD自动/零样本空闲、后续明确任务的语音往返与
真实工具回填，以及新候选的真实音频取消分类。参与的5阶段共6模型，
526次NVML正常、所属资源清理；其中4阶段的原整体失败保持。组合
没有新增推理，没有将原错误回答、迟到的打断或不完整SDK当成通过。

轻量原语音错误、Ready往返和工具错答逐字保留；旧VAD回答已在语音
到来前完成，该次没有打断成功，也没有完整末尾metrics，均不追认。
实际取消资格来自后来默认会话的真实音频VAD及737 tokens结算。
明确任务/显式工具引用后的成功不代表原模型质量已经修复。

主档startup/capabilities由485a38a3的真实观察通过5文件用量分类修复
依赖审查复用，只投影协议身份；轻量为ecd6cc23实际观察。不是两档
在新二进制上完整重跑。原始身份、记录及每个叶子摘要见审查文件。

资格注册表3c1e823a…；主档5,618,996字节、轻量8,325,651字节，均
在原8MiB上限内。普通元数据2MiB限制保持。默认rev376仍STOPPED；
本资格不等同恢复验收或默认交付。下一步封装实际恢复包，执行已
冻结的Guardian/入口/整包恢复短验、可回退发布并继续全部master。

[审查](review.json)、[索引](index.json)、[原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();i=s.index('\n## 当前实际默认');p.write_text(s[:i]+'''
[双向主轻资格与v24校验](evidence/serve-realtime-duplex-composed-profiles-20261120/README.md)：
12资格/6封包/20来源反例通过；现有6模型、526NVML正常的确切来源
离线组合，新增GPU0。原失败/错误回答完整保留，不宣称模型质量修复。
主轻记录均在8MiB内，v24校验可离仓导入且保留v1—v23。候选ecd6cc23
具备主轻资格，实际恢复/交付仍待完成，默认rev376 STOPPED保持。
''' +s[i:])
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 双向主轻资格与可独立封装校验

日期：2026-11-20。

做了什么：新增精确来源组合校验，保留原模型错误和未完成打断；既有
通过任务按依赖组合为ecd6cc23主轻资格。12CPU/6封包/20来源反例、
2.000秒通过，新增GPU0；v24模块封装和隔离导入、历史版本校验通过。

为什么：未变后端复用实测，受影响取消分类使用真实补验；不能把一次
成功覆盖原失败，也不能把校验器依赖仓库工作区的包发给部署环境。

下一步：实际原生恢复包和冻结的Guardian/入口/整包恢复短验，然后
可回退交付并继续全部master；当前默认rev376保持STOPPED。
''' +s[i:])
p=R/'docs/serve-master-goals-v2.json';v=read(p);v['realtime_progress']['duplex_input_20261120'].update(state='primary_light_source_qualified_native_recovery_pending',composed_profiles=dict(evidence=str(O.relative_to(R)/'README.md'),acceptance=a,cpu=cpu));save(p,v)
print(json.dumps(dict(evidence=str(O),archive_bytes=(O/'records.tar.gz').stat().st_size,omitted=len(omitted))))

"""Reversibly archive retired metadata through the deployed STOPPED CLI."""
import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent
O=W/'maintenance-01';S=R/'build/service-native-state'
read=lambda p:json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):
    assert not p.exists(),'preserve '+str(p)
    p.write_text(json.dumps(v,indent=2)+'\n')
def protected():
    return {str(p.relative_to(R)):sha(p) for p in
        [R/'build/q4t',R/'build/q4t.release.json',R/'build/service.release.json',
         R/'build/service/manifest.json']+
        [p for p in S.rglob('*') if p.is_file() and
         (p.name=='ledger.json' or p.relative_to(S).parts[0].startswith(
             ('client-','outer-','profile-selection','version-selection')))]}
os.umask(0o077)
prior=read(O/'status-before.json')
assert prior['publication_revision']==416 and prior['desired']=='STOPPED'
assert not (O/'review.json').exists()
pools=prior['pools'];selected={}
selected['intents']=sorted(pools['intents']['candidate_ids'],key=lambda v:
    read(S/'service-publication-intents'/(v+'.json'))['base']['revision'])[:4]
assert all(len(v)==4 for v in selected.values())
before=protected()
save(O/'review.json',dict(selected=selected,protected=before,
    deleted_files=0,model_actions=False,restore='use maintenance-restore with each original plan and SHA'))
rows=[];start=time.monotonic()
def call(label,args):
    assert len(rows)<8 and time.monotonic()-start<720
    command=[str(R/'build/q4t'),'service',*map(str,args)]
    r=subprocess.run(command,cwd=R,text=True,capture_output=True,timeout=180)
    (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
    rows.append(dict(label=label,argv=command,returncode=r.returncode))
    print(json.dumps(rows[-1]),flush=True)
    assert r.returncode==0,label
    assert protected()==before,'live state changed'
    return json.loads(r.stdout)
try:
    for kind,ids in selected.items():
        args=['maintenance-plan','--state',S,'--kind',kind,'--output',O/(kind+'-archive')]
        for v in ids:args+=['--select',v]
        plan=call(kind+'-plan',args)
        path=Path(plan['plan']);assert sha(path)==plan['sha256']
        value=read(path);key={'intents':'requests','generations':'generations','versions':'cycles'}[kind]
        assert len(value[key])==4 and value['state']==str(S)
        call(kind+'-apply',['maintenance-apply','--state',S,'--kind',kind,
             '--plan',path,'--plan-sha256',plan['sha256']])
    after=call('status-after',['maintenance-status','--state',S])
    assert after['publication_revision']==416 and after['desired']=='STOPPED'
    assert all(after['pools'][k]['used']==pools[k]['used']-4 for k in selected)
    save(O/'result.json',dict(status='PASS_REVERSIBLE_RETIRED_METADATA_ARCHIVE',
        before=prior,after=after,selected=selected,commands=rows,
        seconds=time.monotonic()-start,live_state_unchanged=True,deleted_files=0,
        model_actions=False,original_paths_and_hashes_in_plans=True))
except BaseException as error:
    save(O/'result.json',dict(status='FAILED',error=repr(error),commands=rows,
        seconds=time.monotonic()-start));raise

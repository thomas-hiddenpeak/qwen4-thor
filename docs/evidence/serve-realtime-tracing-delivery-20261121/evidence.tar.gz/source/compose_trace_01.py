"""Exact allocation fix and original managed recovery, without relabelling runs."""
import copy,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service import package as p
from tools.serve_recovery import bundle,version_contract,profile_migration,profile_manager,profile_record,profile_evidence
from tools.serve_recovery.profile_trace_source import REVIEW
BINDING_GUARD=dict(binary_sha256=REVIEW['candidate_binary'],protocol_sha256=REVIEW['candidate_protocol'],runtime_delta=REVIEW['runtime_delta'])
M=R/'.q4t-work/serve-realtime-mcp-20261120'
O=W/'composition-01';p.require(not O.exists(),'preserve composition');O.mkdir(mode=0o700)
actual=p.read(W/'sdk-business-06/acceptance.json');q=p.read(W/'qualified-profiles-01/acceptance.json');prior=p.read(M/'binding-publication-composition-03.json')
p.require(actual['status']=='PASS_REALTIME_TRACING_PRIMARY_LIGHT_PROTOCOL' and actual['environment']['status']=='PASS' and q['status']=='ACCEPT_TRACING_PRIMARY_LIGHT','targeted qualification missing')
roots={n:{k:v[k] for k in ('package','manifest_sha256')} for n,v in [('candidate',p.read(W/'service-package-01/receipt.json')),('retained',p.read(W/'retained-01/receipt.json'))]}
proof={};decisions={}
for n,original in [('candidate','binding-package-01'),('retained','binding-retained-01')]:
 stage=M/'binding-composition-03'
 target=Path(roots[n]['package']);old=M/original/'bundle'
 first=bundle.verify(old,p.sha(old/'manifest.json'));second=bundle.verify(target,roots[n]['manifest_sha256'])
 oldengine=p.read(old/'engine/manifest.json');newengine=p.read(target/'engine/manifest.json')
 p.require(oldengine['settings']==newengine['settings'] and oldengine['model_files']==newengine['model_files'] and first['recovery_profiles']['identity']['model_assets']==second['recovery_profiles']['identity']['model_assets'],'backend settings or assets changed')
 delta={k for k in set(first['files']) | set(second['files']) if first['files'].get(k)!=second['files'].get(k)}
 allowed={'profile-primary.json','profile-light.json','native-build.json','bin/q4t-ingress',
  'source/tools/serve_realtime/tracing_checks.py',
  *('source/tools/serve_recovery/'+x+'.py' for x in
   ('bundle','profile_evidence','profile_record','profile_trace_reuse','profile_trace_source','profile_trace_evidence'))}
 p.require(delta==allowed,'unreviewed service source delta')
 oldnative=p.read(old/'native-build.json');newnative=p.read(target/'native-build.json')
 nativedelta={k for k,v in oldnative['source_files'].items() if newnative['source_files'].get(k)!=v}
 p.require(nativedelta=={'CMakeLists.txt','include/q4t/server/application_routes.h','include/q4t/server/http_connection.h','src/service/ingress_main.cpp'} and oldnative['source_files'].keys()==newnative['source_files'].keys(),'native source delta differs')
 p.require(all(oldnative[k]==newnative[k] for k in ('guardian_sha256','cuda_probe_sha256','device_control_sha256')) and newnative['ingress_sha256']=='8bd79b7a2c998138934541e6e2813d1d778d908cc84c86abec65ba843f954935','helper binary differs')
 for name in ('primary','light'):
  path=target/('profile-'+name+'.json');profile_evidence.validate(profile_record.read(path),second['recovery_profiles'],name,p.sha(path))
 olddecision=p.read(stage/(n+'-decision.json'));oldrelease=p.read(stage/(n+'-service-release.json'))
 original_receipt={k:dict(path=str(stage/f),sha256=p.sha(stage/f)) for k,f in [('release',n+'-service-release.json'),('decision',n+'-decision.json')]}
 version_contract.accepted_fallback(original_receipt,version_contract.payload(dict(package=str(old),manifest_sha256=p.sha(old/'manifest.json'))))
 proof[n]=dict(previous=dict(package=str(old),manifest_sha256=p.sha(old/'manifest.json')),target=roots[n],service_delta=sorted(delta),native_helpers_except_ingress_unchanged=True,controller_and_recovery_sources_unchanged=True,ingress_delta='Only trace route and observation classification; exact new ingress has targeted CPU and primary/light real TLS business',native_source_delta=sorted(nativedelta),application_settings_and_assets_unchanged=True,original_service_acceptance=original_receipt,original_service_business=olddecision['actual_business'],fresh_engine_business=dict(path=str(W/'sdk-business-06/acceptance.json'),sha256=p.sha(W/'sdk-business-06/acceptance.json')),runtime_delta=BINDING_GUARD['runtime_delta'],new_managed_fault_runs=0)
 business=dict(status='PASS_REALTIME_TRACING_WITH_REUSED_SERVICE_RECOVERY',env_abort=False,postflight=dict(sources_unchanged=True,owned_processes_gone=True,ports_free=True,lock_released=True,default_unchanged=True),fresh_engine=copy.deepcopy(actual),source_composition=proof[n],new_managed_fault_runs=0,original_quality_failures_preserved=True)
 accepted='ACCEPT_REALTIME_TRACING_'+n.upper()+'_COMPOSITION'
 decision=dict(status='PASS_REALTIME_TRACING_'+n.upper()+'_COMPOSITION',acceptance=accepted,manifest_sha256=roots[n]['manifest_sha256'],engine_binary_sha256=BINDING_GUARD['binary_sha256'],actual_business=business,default_replaced=False,performance_acceptance=False,long_stability_accepted=False)
 p.save(O/(n+'-decision.json'),decision)
 release=copy.deepcopy(oldrelease);release.update(acceptance=accepted,manifest_sha256=roots[n]['manifest_sha256'],package=str(target),engine_binary_sha256=BINDING_GUARD['binary_sha256'],engine_release_sha256=p.sha(target/'engine/q4t.release.json'),automatically_started=False,acceptance_record=str(O/(n+'-decision.json')),acceptance_sha256=p.sha(O/(n+'-decision.json')),source_composed_recovery=True,new_managed_fault_runs=0,source_composition=proof[n],scope='Exact new trace engine/ingress business plus source-identical prior managed controller recovery; old package identities preserved; no new full managed fault or full model quality claim')
 release.pop('state',None);release.pop('service_id',None)
 p.save(O/(n+'-service-release.json'),release)
 receipt={k:dict(path=str(O/(n+f)),sha256=p.sha(O/(n+f))) for k,f in [('release','-service-release.json'),('decision','-decision.json')]}
 version_contract.accepted_fallback(receipt,version_contract.payload(roots[n]));decisions[n]=decision
p.require(version_contract.compatible(version_contract.payload(roots['candidate']),version_contract.payload(roots['retained']))['automatic'],'fallback compatibility')
value=dict(status='ACCEPT_REALTIME_TRACING_SERVICE_COMPOSITION',candidate=roots['candidate'],automatic_fallback=roots['retained'],modern_retained_root=roots['retained'],candidate_service_acceptance=decisions['candidate'],modern_service_acceptance=decisions['retained'],binary_sha256=BINDING_GUARD['binary_sha256'],protocol_sha256=BINDING_GUARD['protocol_sha256'],counts=dict(starts=4,actual_generations=9,websocket_sessions=4,probes=0),service_seconds=260.146755577065,nvml_queries=149,nvml_all_ok=True,cleanup_complete=True,actual_reads=2,model_quality_status='FAIL',targeted_model_quality_status=actual['model_quality'],original_profile_model_quality_failures_preserved=True,full_model_quality=False,performance_claim=False,older_engine_fallback=False,default_unchanged=True,publication_pending=True,all_master_tasks_complete=False,primary_light_evidence=dict(path=str(W/'qualified-profiles-01/acceptance.json'),sha256=p.sha(W/'qualified-profiles-01/acceptance.json')),tls_composition=prior['tls_composition'],guardian_repair=prior['guardian_repair'],unchanged_backend_recovery_source=dict(path=str(M/'binding-publication-composition-03.json'),sha256=p.sha(M/'binding-publication-composition-03.json'),scope='Exact original package identities retained. Trace capture/qualification and ingress observation routes change, with exact primary/light TLS/SDK and auxiliary recovery evidence. Controller, Guardian, probe, device helper, TLS implementation, settings and backend assets are unchanged. No new full managed fault run.'),candidate_whole_package_gpu_run=False,new_managed_fault_runs=0,default_policy_unchanged=True,private_test_policy_shipped=False,automatic_request_or_tool_replay=False,proof=proof)
p.save(W/'publication-composition.json',value)
print(json.dumps(dict(status=value['status'],roots=roots,new_managed_fault_runs=0)))

"""Explicit public receipt list; policies, private plans/state and TLS keys excluded."""
import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];D=W/'delivery-01';O=R/'docs/evidence/serve-realtime-tracing-delivery-20261121'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');q=read(W/'qualified-profiles-01/acceptance.json');m=read(W/'maintenance-01/result.json')
assert v['status']=='PASS_REALTIME_TRACING_DELIVERED' and v['publication']['revision']==426 and v['state']=='STOPPED'
assert len(v['commands'])==19 and all(c['returncode']==0 for c in v['commands']) and v['new_gpu_starts']==0
assert q['status']=='ACCEPT_TRACING_PRIMARY_LIGHT' and m['live_state_unchanged'];assert not O.exists()
files={}
for n in ('result.json','candidate-decision.json','retained-decision.json','candidate-service.release.json','retained-service.release.json','candidate-registration.json','retained-registration.json','recovery-anchor.json','candidate-cycle.json','anchor-cycle.json'):files['delivery/'+n]=D/n
for row in v['commands']:
 for suffix in ('stdout','stderr'):
  n=row['label']+'.'+suffix;files['delivery/commands/'+n]=D/n
for n in ('acceptance.json','primary-config.json','light-config.json','primary-capabilities.json','light-capabilities.json','qualified/registry.json','qualified/primary.json','qualified/light.json'):files['qualification/'+n]=W/'qualified-profiles-01'/n
for n in ('decision.json','receipt.json','native-build.json'):files['candidate/'+n]=W/'service-package-01'/n
for n in ('review.json','receipt.json'):files['retained/'+n]=W/'retained-01'/n
for n in ('publication-composition.json','package-preflight-01.json','composition-01/candidate-decision.json','composition-01/retained-decision.json','composition-01/candidate-service-release.json','composition-01/retained-service-release.json','maintenance-01/result.json','qualification-inventory-01.json','qualification-inventory-02.json','retired-previous-08/plan.json','retired-previous-08/result.json','retired-previous-08/restore.py'):files['composition/'+n]=W/n
for n in ('deliver_trace_01.py','maintain_trace_01.py','qualify_trace_01.py','compose_trace_01.py','prepare_trace_package_01.py','prepare_trace_package_02.py','prepare_trace_retained_01.py','archive_delivery_01.py'):files['source/'+n]=W/n
index={};O.mkdir()
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,p in sorted(files.items()):
  raw=p.read_bytes();index[n]=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw));info=tarfile.TarInfo(n);info.size=len(raw);info.mode=0o600;info.mtime=0;t.addfile(info,io.BytesIO(raw))
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n')
result=dict(status=v['status'],revision=426,state='STOPPED',seconds=v['seconds'],commands=len(v['commands']),new_gpu_starts=0,new_managed_fault_runs=0,candidate_manifest_sha256='41760222c76714a23e5753e53ef9e86b3b91e9c0a4f42373f04bf845d3b34afe',retained_manifest_sha256='20871e8a81691446dda42b49429fffff44b12322088f290c5f92333f27870015',binary_sha256=sha(R/'build/q4t'),engine_release_sha256=sha(R/'build/q4t.release.json'),protocol_sha256='03b227b161b55f1ea4e310745226f47aaaca41853b3bb222e95a7b0718cd37ae',ingress_sha256=sha(R/'build/service/bin/q4t-ingress'),registry_sha256=q['registry_sha256'],customers_quotas_usage_core_outer_preserved=True,profile_history_clock_and_budgets_preserved=True,actual_stopped_root_rollback_and_forward=True,old_recovery_receipts_preserve_original_identities=True,original_model_quality_failures_preserved=True,original_model_quality_status='FAIL',targeted_model_quality_status='PASS',performance_acceptance=False,full_model_quality_accepted=False,long_stability_accepted=False,master_goal_active=True,reversible_metadata_maintenance=dict(commands=len(m['commands']),archived_intents=4,deleted_files=0,old_revision=416,live_state_unchanged=True),archive_sha256=sha(O/'evidence.tar.gz'))
(O/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','revision','seconds','commands')}))

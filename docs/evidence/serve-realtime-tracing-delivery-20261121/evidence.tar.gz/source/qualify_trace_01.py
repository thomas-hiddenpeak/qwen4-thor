"""Compose exact prior records with accepted native trace observations, no GPU."""
import copy,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import bundle,ledger,profile_contract,profile_evidence,profile_record
from tools.serve_recovery import profile_trace_reuse as reuse,profile_trace_evidence as evidence
from tools.serve_recovery.profile_trace_source import REVIEW,SOURCES
from tools.serve_ops import contracts
proposal='--proposal' in sys.argv
O=W/('qualification-proposal-01' if proposal else 'qualified-profiles-01');S=W/'sdk-business-06';OLD=R/'.q4t-work/serve-realtime-mcp-20261120/binding-qualified-01/qualified'
require(not O.exists(),'preserve qualification')
if not proposal:require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'commit reviewed source before qualification')
O.mkdir(mode=0o700)
try:
 accepted=read(S/'acceptance.json');require(sha(S/'acceptance.json')==REVIEW['actual_acceptance_sha256'] and accepted['status']=='PASS_REALTIME_TRACING_PRIMARY_LIGHT_PROTOCOL','actual business missing')
 cpu=read(W/'qualification-cpu-01/result.json');fixed=read(W/'qualification-cpu-03/result.json')
 require(cpu['returncode']==1 and fixed['status']=='PASS','expected original and repaired CPU records')
 for n,h in read(W/'qualification-cpu-03/plan.json')['sources'].items():require(sha(R/n)==h,'CPU source drift')
 plan=read(S/'plan.json')
 for n,h in {**plan['reviewed_sources'],**plan['native_assets'],**plan['protected']}.items():require(sha(R/n)==h,'runtime/assets/default drift')
 bundle.check_assets(plan['model'],plan['model_assets']);require(sha(plan['binary'])==REVIEW['candidate_binary'],'engine drift')
 previous=read(OLD/'registry.json');require(sha(OLD/'registry.json')==REVIEW['prior_registry_sha256'],'prior qualification drift')
 registry=dict(format=profile_contract.FORMAT,identity=plan['identity'],profiles=plan['profiles'],qualifications={});q=O/'qualified';q.mkdir(mode=0o700)
 environment=dict(accepted['environment'],lease_result_sha256=sha(S/'lease/exit.json'))
 for name in ('primary','light'):
  p=OLD/(name+'.json');require(sha(p)==SOURCES[name]['record_sha256'],'prior record drift')
  prior=profile_record.read(p);profile_evidence.validate(prior,previous,name,sha(p));value=copy.deepcopy(prior)
  caps=read(S/(name+'-capabilities.json'));config=read(S/(name+'-config.json'))
  value.update(format=profile_evidence.TRACING_FORMAT,identity=plan['identity'],capabilities=caps,configuration=contracts.configuration(config,version=5),startup_memory=config['startup_memory']['checks']['before_allocations'],environment=environment)
  value['business']['realtime_tracing']=evidence.attach(name,read(S/(name+'-tracing-observed.json')))
  value=reuse.attach(value,prior);require(reuse.previous_record(value)==prior,'old record changed')
  p=q/(name+'.json');profile_record.save(p,value)
  registry['qualifications'][name]=profile_contract.qualification(name,value['capacity'],value['identity'],value['capabilities'],value['configuration'],value['startup_memory'],sha(p))
  save(O/(name+'-capabilities.json'),caps);save(O/(name+'-config.json'),config)
 profile_contract.validate(registry)
 for name in ('primary','light'):
  p=q/(name+'.json');profile_evidence.validate(profile_record.read(p),registry,name,sha(p))
 profile_contract.capability_pair(read(O/'primary-capabilities.json'),read(O/'light-capabilities.json'));save(q/'registry.json',registry)
 plan.update(output=str(O),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),targeted_format='q4t-native-tracing-qualification-v1',scope='Exact prior complete profile records and original failures retained; new two-profile native trace SDK business and auxiliary recovery; no repeated managed fault matrix',observed_source_review=REVIEW,sources={n:sha(R/n) for n in bundle.SOURCES})
 plan['sources'].update(plan['reviewed_sources'])
 for p in (Path(__file__).resolve(),S/'plan.json',S/'acceptance.json',W/'qualification-cpu-01/result.json',W/'qualification-cpu-03/result.json'):plan['sources'][str(p)]=sha(p)
 save(O/'plan.json',plan)
 result=dict(status='PROPOSAL_VALIDATED' if proposal else 'ACCEPT_TRACING_PRIMARY_LIGHT',registry_sha256=sha(q/'registry.json'),environment=environment,new_gpu_starts=0,actual_model_starts=4,actual_jobs=9,original_failures_preserved=True,original_model_quality_status='FAIL',model_quality_repaired=False,targeted_model_quality_status=accepted['model_quality'],default_unchanged=True,managed_recovery_repeated=False,full_matrix=False,master_active=True,source_review_sha256=ledger.digest(REVIEW),profile_bytes={n:(q/(n+'.json')).stat().st_size for n in ('primary','light')})
 save(O/('result.json' if proposal else 'acceptance.json'),result);print(json.dumps(result))
except Exception as error:
 save(O/'failure.json',dict(status='FAIL',error=str(error),new_gpu_starts=0));raise

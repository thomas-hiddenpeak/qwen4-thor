"""Seal reviewed native MCP profiles for focused native recovery; default unchanged."""
import copy
import hashlib
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
WORK = Path(__file__).resolve().parent
OUT = WORK/'service-package-01'
PROFILE = WORK/'qualified-profiles-01'
CANDIDATE = ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
BUILD = ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD = (ROOT/'build/service').resolve(strict=True)
INGRESS = ROOT/'.q4t-work/serve-file-search-20261112/host/q4t-ingress'
from tools.serve_recovery.profile_trace_source import REVIEW
CONTROL = {'tools/serve_realtime/tracing_checks.py', *('tools/serve_recovery/'+n+'.py' for n in ('bundle','profile_evidence','profile_record','profile_trace_evidence','profile_trace_reuse','profile_trace_source'))}
NATIVE = {'CMakeLists.txt','include/q4t/server/application_routes.h','include/q4t/server/http_connection.h','src/service/ingress_main.cpp'}
ADDED_NATIVE = {'CMakeLists.txt','include/q4t/server/application_routes.h','include/q4t/server/http_connection.h','src/service/ingress_main.cpp'}
_original_copy = shutil.copyfile

def copy_file(source, target, *args, **kwargs):
    if Path(source) == OUT/'engine/q4t' and Path(target) == OUT/'bundle/engine/q4t':
        p.require(Path(source).stat().st_mode & 0o777 == 0o500 and not Path(target).exists(),
                  'only immutable new candidate may be shared')
        os.link(source,target)
        return target
    return _original_copy(source,target,*args,**kwargs)

def cp(source, target):
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    copy_file(source,target)


def main():
    os.umask(0o077)
    shutil.copyfile = copy_file
    p.require(not OUT.exists(), 'preserve previous preparation')
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),
              'commit reviewed source first')
    before = {n:p.sha(ROOT/n) for n in ('build/q4t','build/q4t.release.json',
        'build/service/manifest.json','build/service.release.json',
        'build/service-native-state/ledger.json')}
    original = bundle.verify(OLD,p.sha(OLD/'manifest.json'))
    oldmeta = p.read(OLD/'engine/q4t.release.json')
    plan = p.read(PROFILE/'plan.json')
    qualification = p.read(PROFILE/'acceptance.json')
    p.require(qualification['status']=='ACCEPT_TRACING_PRIMARY_LIGHT' and
        qualification['environment']['status']=='PASS' and
        qualification['environment']['cleanup_complete'], 'actual qualification missing')
    from tools.serve_recovery import profile_record, profile_evidence
    registry=p.read(PROFILE/'qualified/registry.json')
    p.require(qualification['registry_sha256']==p.sha(PROFILE/'qualified/registry.json'),
              'reviewed registry digest changed')
    for name in ('primary','light'):
        record=PROFILE/'qualified'/(name+'.json')
        profile_evidence.validate(profile_record.read(record),registry,name,p.sha(record))
    helpers = runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))
    compiled = p.read(BUILD/'generated/q4t/server/chat_protocol_sources.json')
    p.require(p.sha(BUILD/'generated/q4t/server/chat_protocol_sources.json') == plan['candidate_identity']['compiled_sources']['sha256'] and p.sha(BUILD/'CMakeCache.txt') == plan['candidate_identity']['build_cache']['sha256'], 'qualified compilation identity drift')
    runtime = helpers['source_hashes']();runtime.update(compiled)
    p.require(all(p.sha(ROOT/n)==h and plan['sources'].get(n,compiled.get(n))==h
                  for n,h in runtime.items()), 'qualified runtime drift')
    p.require(p.sha(CANDIDATE/'q4t')==p.sha(BUILD/'q4t')==plan['binary_sha256'],
              'qualified engine drift')
    previous = p.read(oldmeta['tested_source_manifest'])
    delta = sorted(n for n,h in runtime.items() if previous.get(n)!=h)
    control = {n for n in bundle.SOURCES if not (OLD/'source'/n).exists() or p.sha(ROOT/n)!=p.sha(OLD/'source'/n)}
    p.require(control==CONTROL,'unreviewed control changes')
    oldnative = p.read(OLD/'native-build.json')
    nativedelta = {n for n,h in oldnative['source_files'].items() if p.sha(ROOT/n)!=h}
    p.require(nativedelta==NATIVE and bundle.NATIVE_SOURCES-set(oldnative['source_files'])==ADDED_NATIVE, 'unreviewed native helper changes')
    native = copy.deepcopy(oldnative)
    for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),
                       ('device_control','q4t-device-control')]:
        p.require(p.sha(BUILD/name)==oldnative[field+'_sha256'],
                  'unchanged helper binary drift')
    p.require(p.sha(INGRESS)=='8bd79b7a2c998138934541e6e2813d1d778d908cc84c86abec65ba843f954935',
              'actual accepted TLS ingress drift')
    native['source_files']={n:p.sha(ROOT/n) for n in bundle.NATIVE_SOURCES}
    native['ingress_sha256']=p.sha(INGRESS)
    p.require(set(delta)==set(REVIEW['runtime_delta']) | {
        'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake',
        'cmake/HostTestSources.cmake','src/service/ingress_main.cpp'},
        'unreviewed runtime delta')
    evidence = ['serve-realtime-tracing-cpu-20261120',
        'serve-realtime-tracing-build-driver-20261121',
        'serve-realtime-session-identity-20261121',
        'serve-realtime-tracing-idle-recovery-20261121',
        'serve-realtime-tracing-http-20261121',
        'serve-realtime-tracing-qualification-cpu-20261121']
    evidence = {n:p.sha(ROOT/'docs/evidence'/n/'README.md') for n in evidence}
    OUT.mkdir(mode=0o700);engine=OUT/'engine'
    for n in ('q4t','CMakeCache.txt'):cp(CANDIDATE/n,engine/n)
    (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
    caps = p.read(PROFILE/'primary-capabilities.json')
    config = p.read(PROFILE/'primary-config.json')
    protocol = hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
    p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,
              'actual declaration mismatch')
    scope = ('Native bounded Realtime trace capture, scope-bound TLS queries, persistence and deletion. Exact primary/light SDK tools and auxiliary-failure recovery passed; idle retry and session identity failures/fixes retained. No prompts, tool results or audio captured. The new ingress differs only in trace observation routing, covered by native CPU and actual TLS business. Guardian, probe, device helper, controllers, backend identities and settings are unchanged. Prior full profile records and original model quality FAILs remain byte-exact recoverable. Managed recovery uses explicit source composition; no repeated whole-package fault, performance or full-model-quality matrix is claimed. Default remains STOPPED until reversible publication.')
    decision = dict(status='PASS_NATIVE_REALTIME_TRACING_ENGINE_PROFILE_BUSINESS',
        acceptance='ACCEPT_NATIVE_REALTIME_TRACING_ENGINE_PROFILE_BUSINESS',
        binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,
        source_commit=plan['source_commit'],source_bound_primary_light=qualification,
        source_delta=delta,control_delta=sorted(control),native_delta=sorted(nativedelta),native_added=sorted(ADDED_NATIVE),
        evidence=evidence,scope=scope,managed_composition_pending=True,
        full_model_quality=False,performance_acceptance=False,default_changed=False,
        remaining_master_tasks_open=True)
    metadata = copy.deepcopy(oldmeta)
    metadata.update(version='serve-realtime-tracing-20261121',
        source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],
        acceptance=decision['acceptance'],acceptance_decision=str(OUT/'decision.json'),
        build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),
        tested_source_manifest=str(engine/'runtime-source.json'),
        tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),
        observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),
        previous_release=str(OLD/'engine/q4t.release.json'),
        inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),
                               sha256=p.sha(OLD/'engine/q4t.release.json')),source_note=scope)
    metadata['native_realtime_tracing_engine_acceptance']=decision
    declarations=engine/'declarations';declarations.mkdir(mode=0o700)
    p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
    metadata['chat_protocol'].update(caps,protocol_sha256=protocol,
        declaration_evidence=scope)
    for name,stem in helpers['SCHEMAS'].items():
        source=ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'))
        target=declarations/'schemas'/(name+'.json');cp(source,target)
        metadata['chat_protocol'][name+'_schema']=str(target)
        metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
    metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,
        directory=str(declarations),binary_sha256=plan['binary_sha256'],
        protocol_sha256=protocol,files={n:p.sha(declarations/n)
            for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
    for source in (ROOT/'third_party/licenses').rglob('*'):
        if source.is_file():cp(source,engine/'licenses'/source.relative_to(ROOT/'third_party/licenses'))
    metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output')
    metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
    for name,row in metadata['file_input_system_dependencies'].items():
        source=Path(row['artifact']);p.require(p.sha(source)==row['sha256'],'notice drift')
        target=engine/'licenses/system'/name;cp(source,target);row['artifact']=str(target)
    clients=metadata['client_artifacts']
    p.require(all(p.sha(ROOT/n)==h for n,h in clients['files'].items()),'client source changed')
    for n in clients['files']:cp(ROOT/n,OUT/'clients'/n)
    clients['directory']=str(OUT/'clients')
    p.save(OUT/'decision.json',decision)
    metadata['acceptance_decision_sha256']=p.sha(OUT/'decision.json')
    p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True)
    p.save(OUT/'native-build.json',native)
    settings=copy.deepcopy(plan['base']['settings'])
    policy=p.read(OLD/'engine/client-policy.json');prior=copy.deepcopy(policy)
    p.save(OUT/'clients.json',policy)
    kwargs={key:OLD/'engine'/n for key,n in [
        ('access_program_policy','access-program-policy.json'),
        ('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json'),
        ('web_policy','web-policy.json')] if (OLD/'engine'/n).is_file()}
    receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',plan['model'],
        BUILD/'q4t-guardian',BUILD/'q4t-cuda-probe',None,OLD/'gateway-policy.json',
        OUT/'clients.json',OUT/'bundle',native_receipt=OUT/'native-build.json',
        native_ingress=INGRESS,device_control=BUILD/'q4t-device-control',
        capacity_config=dict(version=2,**{k:v for k,v in settings['profile'].items()
                                          if k not in ('name','host')}),
        application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},
        embedding_model_dir=Path(settings['native_embedding']['directory']),
        asr_model_dir=Path(settings['native_asr']['directory']),
        asr_limits=settings['native_asr']['limits'],
        asr_auxiliary={k:v for k,v in settings['native_asr'].items() if k in p.ASR_AUXILIARY},
        tts_model_dir=Path(settings['native_tts']['directory']),
        tts_limits=settings['native_tts']['limits'],
        tts_base_model_dir=Path(settings['native_tts_base']['directory']),
        recovery_profiles=PROFILE/'qualified/registry.json',
        recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
    p.save(OUT/'receipt.json',receipt)
    p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,
              'unrelated settings changed')
    p.require(all(p.sha(ROOT/n)==h for n,h in before.items()),'default changed')
    p.save(OUT/'prepare-review.json',dict(status='TRACING_SOURCE_COMPOSITION_PENDING',
        previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),
        package_sha256=receipt['manifest_sha256'],source_delta=delta,
        control_delta=sorted(control),native_delta=sorted(nativedelta),native_added=sorted(ADDED_NATIVE),
        client_policy_before=prior,client_policy_after=policy,
        private_quota_changes='none; preserve exact current default policy',
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        default_unchanged=True,model_actions=0,driver_sha256=p.sha(Path(__file__))))
    print(receipt['manifest_sha256'],flush=True)

if __name__=='__main__':main()

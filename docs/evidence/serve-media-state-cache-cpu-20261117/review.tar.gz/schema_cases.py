import json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_protocol.build_contract import vision_schema
from tools.serve_protocol.check_contract import Validator
schema=vision_schema();validator=Validator(schema)
url='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGPYoiECAAKEAPFkHeRLAAAAAElFTkSuQmCC'
cases=[dict(messages=[dict(role='user',content=[dict(type='image_url',image_url=dict(url=url))])],session_id='a'*64),dict(messages=[dict(role='user',content=[dict(type='video_frames',video_frames=[url,url],video_timestamps=[0,1])])],prefix_cache_scope='b'*64,prefix_cache_write_tokens=1024)]
for case in cases:
 errors=list(validator.iter_errors(case))
 assert not errors,[(list(e.path),e.message) for e in errors]
 invalid=dict(case,stop='end')
 assert not validator.is_valid(invalid),'private cache stop restriction drift'
print(json.dumps(dict(cases=2,passed=2,image_session=True,video_prefix=True,unaffected_stop_guard=True)))

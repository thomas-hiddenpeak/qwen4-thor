from pathlib import Path
import os,hashlib,json,subprocess,sys,time,unittest
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_audit.check_inventory import current_surface,check
W=Path(__file__).resolve().parent;OUT=W/'semantic-cpu-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  b=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(b);p.chmod(m)
selected=['tools.serve_realtime.test_semantic_observation',
 'tools.serve_recovery.test_profile_semantic.SemanticEvidence.test_unknown_timeout_or_unbilled_classifier_rejects']
prefix='tools.serve_realtime.test_semantic_sdk.SemanticSdk.'
selected += [prefix+x for x in ['test_explicit_observation_keeps_fallback_and_completes_lifecycle','test_explicit_observation_still_rejects_protocol_failure','test_transcript_without_actual_classifier_is_not_acceptance','test_complete_turn_requires_classifier_and_orderly_close']]
if sys.argv[1:]==['prepare']:
 OUT.mkdir()
 p=ROOT/'tools/serve_audit/inventory.json';detach(p);v=json.loads(p.read_text());now=current_surface(ROOT);v['sources_sha256'].update(now['sources_sha256']);v['semantic_lifecycle_observation_20261120']=dict(strict_profile_unchanged=True,policy='record_bounded_semantic_fallback_v1',cpu_checks_pending=11);save(p,v);assert not check(v,now),check(v,now)
 suite=unittest.defaultTestLoader.loadTestsFromNames(selected)
 def ids(s):
  for x in s:
   if isinstance(x,unittest.TestSuite):yield from ids(x)
   else:yield x.id()
 tests=list(ids(suite));assert len(tests)==11 and not any('_FailedTest' in n for n in tests),tests
 old=json.loads((W/'consumers-01/plan.json').read_text())
 env=dict(Q4T_TEST_OUTPUT_DIR=str(OUT/'fixtures'),Q4T_INGRESS=old['realtime']['ingress'],Q4T_NODE_SDK_DIR=old['sdk']['sdk_directory'])
 files=['tools/serve_realtime/semantic_sdk.mjs','tools/serve_realtime/semantic_observation.py','tools/serve_realtime/test_semantic_sdk.py','tools/serve_realtime/test_semantic_observation.py','tools/serve_recovery/profile_evidence.py','tools/serve_audit/inventory.json','.github/workflows/host-checks.yml']
 for n in files:
  dst=OUT/'source'/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((ROOT/n).read_bytes())
 commands=[['python3','-B','-m','unittest',*selected,'-v'],[old['sdk']['node']['path'],'--check',str(ROOT/'tools/serve_realtime/semantic_sdk.mjs')],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
 save(OUT/'plan.json',dict(scope='Observation-only lifecycle, immutable failed classifier state, explicit status rejected by strict qualification, actual TLS SDK CPU peer',maximum_tests=11,tests=tests,source_counterexamples=20,maximum_seconds=120,new_gpu_starts=0,commands=commands,env=env,sources={n:sha(ROOT/n) for n in files}))
 intro='冷态语义观察器已实现，显式OBSERVED_NOT_QUALIFIED状态与原严格资格隔离；\n不改运行时、采样或默认。冻结11项CPU（含原生TLS/官方SDK的CPU对端）\n与20来源反例/120秒/0GPU，之后按已冻结1模型/4请求补完整生命周期。\n原格式及语义FAIL保留，全部master继续。\n\n'
 p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
 p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 冷态语义观察器与资格隔离\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：先前严格断言在评分过期后提前退出，遗失了应当检查的历史/关闭/结算；观察器不改写过期结果，也不能替代成功分类资格。\n\n下一步：对应CPU反例和一次有界实跑，继续恢复及总计划。\n'+t)
 print(json.dumps(dict(status='PREPARED',tests=11,gpu=0)))
else:
 assert sys.argv[1:]==['run'];p=json.loads((OUT/'plan.json').read_text());assert all(sha(ROOT/n)==h for n,h in p['sources'].items())
 start=time.monotonic();results=[];env=dict(os.environ,**p['env'],PYTHONDONTWRITEBYTECODE='1')
 for i,cmd in enumerate(p['commands']):
  result=subprocess.run(cmd,cwd=ROOT,env=env,text=True,capture_output=True,timeout=max(1,p['maximum_seconds']-(time.monotonic()-start)))
  (OUT/f'command-{i}.stdout').write_text(result.stdout);(OUT/f'command-{i}.stderr').write_text(result.stderr)
  results.append(dict(command=cmd,exit_code=result.returncode));print(json.dumps(results[-1]),flush=True)
  if result.returncode:break
 save(OUT/'result.json',dict(status='PASS' if len(results)==3 and all(x['exit_code']==0 for x in results) else 'FAIL',seconds=time.monotonic()-start,commands=results,sources_unchanged=all(sha(ROOT/n)==h for n,h in p['sources'].items()),new_gpu_starts=0))

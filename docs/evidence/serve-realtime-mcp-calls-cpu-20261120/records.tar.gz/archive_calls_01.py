from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-mcp-calls-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
r=read(W/'calls-cpu-01/result.json');assert r['status']=='PASS' and r['tests']==20
assert all(sha(R/p)==h for p,h in r['sources'].items())
files={n:W/n for n in ['calls-plan.json','calls-revised-plan.json','calls-required.txt','calls-revised-required.txt','archive_calls_01.py','run_calls_cpu_01.py','run_calls_cpu_02.py','calls-cpu-01/result.json','calls-cpu-01/stdout.txt','calls-cpu-01/stderr.txt']}
for i in (1,2):
 for n in [f'build_calls_0{i}.py',f'calls-build-0{i}/plan.json',f'calls-build-0{i}/result.json',f'calls-build-0{i}/build.log']:files[n]=W/n
 assert read(W/f'calls-build-0{i}/result.json')['warnings']==0
for p,h in read(W/'calls-plan.json')['sources'].items():
 f=W/'calls-original-source'/p;assert sha(f)==h;files['original-source/'+p]=f
files.update({'source/'+p:R/p for p in r['sources']});O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a=dict(status='PASS_REALTIME_MCP_ASYNC_CALL_OWNER_CPU',distinct_cases=20,case_executions=20,cpu_seconds=r['seconds'],native_http_compositions=3,builds_zero_warnings=2,original_18_case_build_not_executed=True,binary_sha256=r['binary_sha256'],runtime_connected=False,gpu_actions=0,llm_requests=0,default_revision=396,default_unchanged=True,service_state='STOPPED',master_goal_active=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP异步调用所有者：CPU

2026-11-20。20项针对性CPU全部通过，0.314秒，含3项实际本机原生
MCP HTTP组合。两次必要构建均零警告。原18项计划的首构建没有运行
CPU；审查发现尚未发布审批的取消关联缺口后，修复并补2项回归，
首次成组执行20项通过。原计划、原源码和首构建原件均保留。

生成完成后独立管理Propose、审批、Execute和原worker退出后清理。
默认1个worker、上限4个；64条/64MiB私有存储硬上限，非终态预留
两个4MiB结果副本。阻塞worker持续占槽，排队期限不续期，审批等待
最多300秒，原生操作最多30秒。Join在全部worker退出后共用2秒清理
期限；失败可查询且不增殖线程，不自动续模型或重放远端调用。

覆盖审批单次决定、拒绝、ID代际、删除、取消、事件失败、容量、
超时及辅助会话维护错误。取消已落盘但尚未发事件的审批时，精确
保留原审批ID和原生拒绝终态；不创建新审批、不发工具。已知迟到
结果保持，删除历史不会复活；真实完成才发布工具终态。

组件还没有接入公开Realtime会话；本组不代替真实模型工具闭环、
SDK和恢复交付。默认rev396 STOPPED，0模型/GPU。继续配置快照、
模型/历史映射和公开会话接线，总目标仍active。

[结果](acceptance.json) · [索引](index.json) · [计划、源码与记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();old='异步调用所有者首构建零警告，CPU尚未运行；审查补尚未发布审批的\n取消关联后，冻结20项CPU/120秒，含3项实际原生MCP HTTP组合。\n原18项计划/源码/构建保留，审批、取消和资源边界待成组验证。';new='[异步调用所有者20项CPU](evidence/serve-realtime-mcp-calls-cpu-20261120/README.md)\n全部通过，含3项实际原生MCP HTTP组合。两次构建零警告；首构建\n未运行CPU，审查修复未发布审批的取消关联后首次20项通过。';assert old in s;p.write_text(s.replace(old,new))
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[异步调用20项CPU全部通过](evidence/serve-realtime-mcp-calls-cpu-20261120/README.md)，\n0.314秒，含3项实际原生HTTP组合。两次构建零警告，原18项首构建\n未运行CPU，源码审查修复后首次成组通过。继续配置/模型映射与公开\n会话接线，不能把组件通过当成模型业务交付；默认保持、0GPU。\n''')
p=R/'docs/log/2026-11-20.md';p.write_text('''## 异步MCP调用所有者20项CPU完成

日期：2026-11-20。

做了什么：[20项CPU](../evidence/serve-realtime-mcp-calls-cpu-20261120/README.md)
全部通过/0.314秒，含3项实际本机MCP HTTP组合；两次构建零警告。
审查修复取消尚未发布审批时的关联，首次20项成组通过。原18项
计划/源码/构建保留，原二进制未运行CPU，不追认具备后续修复。

为什么：工具执行生命周期独立于生成终态；取消/删除/事件失败不能
失去原生已知结果或发起重复调用，线程/私有存储须明确有界。

下一步：公开会话配置、工具与历史映射、SDK真实业务及恢复；默认
rev396 STOPPED，0模型/GPU。总目标active，不在组件边界停止。

'''+p.read_text())
p=R/'docs/serve-master-goals-v2.json';d=read(p);m=d['realtime_progress']['mcp_20261120'];m['state']='async_call_owner_cpu_accepted_public_session_integration_next';m['async_calls_cpu']=a;m['async_calls_evidence']='evidence/serve-realtime-mcp-calls-cpu-20261120/README.md';save(p,d)
print(json.dumps(a))

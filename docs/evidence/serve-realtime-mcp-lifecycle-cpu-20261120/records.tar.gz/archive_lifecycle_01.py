from pathlib import Path
import hashlib,json,subprocess,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent
O=R/'docs/evidence/serve-realtime-mcp-lifecycle-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
a=read(W/'sdk-cpu-03/result.json');b=read(W/'lifecycle-cpu-01/result.json');assert a['status']==b['status']=='PASS'
files={'archive_lifecycle_01.py':Path(__file__)}
for folder,names in {'sdk-cpu-03':['plan.json','result.json','stdout.txt','stderr.txt','node-check.txt'],'lifecycle-build-01':['plan.json','result.json','build.log'],'lifecycle-cpu-01':['result.json','stdout.txt','stderr.txt'],'lifecycle-inspection-01':['result.json']}.items():
 for n in names:files[folder+'/'+n]=W/folder/n
for n in ['lifecycle-plan.json','lifecycle-required.txt','build_lifecycle_01.py','run_lifecycle_cpu_01.py']:files[n]=W/n
for n,h in {**a['sources'],**b['sources']}.items():assert sha(R/n)==h;files['source/'+n]=R/n
S=W/'sdk-business-03'
for n in ['plan.json','result.json','counts.json','cleanup.json','primary-cleanup.json','observations.json','lease/exit.json','lease/events.jsonl','lease/nvml-queries.jsonl']:
 files['sdk-business-03/'+n]=S/n
for profile in ('primary','light'):
 for stem in ('-mcp.sdk.json','-mcp.events.jsonl','-mcp.stderr','-mcp-observed.json','-peer-results.json','-config.json','-capabilities.json'):
  files['sdk-business-03/'+profile+stem]=S/(profile+stem)
old=W/'sdk-second-source';old.mkdir()
for n,h in read(W/'sdk-cpu-02/result.json')['sources'].items():
 p=old/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','b69ccfaf4:'+n],cwd=R));assert sha(p)==h;files['original-source/'+n]=p
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 assert set(archive.getnames())==set(rows)
 for m in archive:assert hashlib.sha256(archive.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
result=dict(status='PASS_TARGETED_CPU_REMAINING_BUSINESS_PENDING',native_tests=5,verifier_tests=21,native_seconds=b['seconds'],verifier_seconds=a['seconds'],build_seconds=read(W/'lifecycle-build-01/result.json')['seconds'],build_warnings=0,original_business_status='FAILED',original_starts=2,original_actual_model_jobs=4,original_reserved_model_jobs=5,original_seconds=read(S/'result.json')['seconds'],nvml_ok_samples=101,primary_settled_tokens=816,light_settled_tokens=3048,cumulative_actual_starts=3,cumulative_actual_model_jobs=8,model_refusal_preserved=True,remote_session_initial_diagnosis_corrected=True,runtime_changed=False,master_goal_active=True)
save(O/'acceptance.json',result)
(O/'README.md').write_text('''# MCP恢复会话合同与剩余业务补验

2026-11-20。5项原生CPU/0.665秒及21项验收器CPU/0.264秒通过，
host构建36.440秒/零警告。新增原生检查从真实MCP导入取得密封会话，
重建对象与transport所有者后继续使用同一远端会话，绝对期限不延长，
跨scope读取被拒绝，显式释放才发送DELETE。既有期限、容量、审批
重启合同一并验证；运行时代码和实际引擎保持。

第二轮原业务仍为FAIL：2启动/4次实际生成/106.497秒（原驱动预留5次）。
主档故障后回答42通过；轻档审批/真实资料读取/标题引用通过。第三次
轻档生成无关拒答，尚未调用工具，回执丢失与普通问答未执行；原回答
完整保留。主/轻分别结算816/3048 tokens，全部本地槽位/会话/预算释放，
两模型正常退出，101次NVML正常。不能把拒答记录为已执行工具。

原“远端会话必须为零”的验收断言不符合既有恢复设计。实际两个
会话各有同scope、有限一小时的密封目录，原生CPU证明内部期限/恢复
合同；离线检查确认实际目录及公开完成事件一一对应，不解密或公开
私有会话，也不声称远端服务器按q4t时钟删除。进程/端口清理独立验证。

冻结剩余1轻档启动/2生成/900秒：明确新user请求，实际远端读取后
丢回执，再新user普通问答。已通过部分复用；原拒答不追认为正确。
累计当前3模型/8次实际生成，默认rev396 STOPPED保持；资格、恢复和
发行继续，总目标active。公共归档采用显式清单，不包含私有入口配置、
证书私钥、MCP策略或对象存储；本机原完整现场保留。

[结果](acceptance.json) · [索引](index.json) · [源码、CPU和原失败](records.tar.gz)。
''')
p=R/'docs/serve-master-goals-v2.json';d=read(p);v=d['realtime_progress']['mcp_20261120'];v.update(state='primary_repair_and_light_approved_read_observed_unknown_receipt_remaining',lifecycle_cpu=result,lifecycle_evidence='evidence/serve-realtime-mcp-lifecycle-cpu-20261120/README.md');save(p,d)
p=R/'docs/STATUS.md';s=p.read_text().replace('准备5项原生CPU与21项验收器\nCPU，随后一次轻档启动/2生成只补未执行的回执丢失/普通问答。','[5项原生CPU与21项验收器CPU通过](evidence/serve-realtime-mcp-lifecycle-cpu-20261120/README.md)，\n随后一次轻档启动/2生成只补未执行的回执丢失/普通问答。');p.write_text(s)
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'\n[生命周期5项与验收器21项CPU通过](evidence/serve-realtime-mcp-lifecycle-cpu-20261120/README.md)，\n实际原目录有限期/同scope对应检查通过；原业务失败保留，剩余两条\n业务在独立严格租约补验，运行时和默认保持。\n')
p=R/'docs/log/2026-11-20.md';p.write_text('''## MCP生命周期与剩余业务验收器通过

日期：2026-11-20。

做了什么：[5项原生及21项验收器CPU通过](../evidence/serve-realtime-mcp-lifecycle-cpu-20261120/README.md)，
分别0.665/0.264秒；host构建36.440秒零警告。原始失败及源码明确归档，
实际已完成目录均有同scope、固定一小时期限的密封记录；不披露私有
会话、不声称远端已到期删除。运行时代码及默认保持。

为什么：保留持久恢复能力，同时验证本地资源已释放和未知结果不能
重放；原轻档拒答继续作为模型质量失败，不当成工具执行通过。

下一步：一次轻档启动/两生成补实际回执丢失及普通问答，之后继续
资格、恢复、可回退发行与main，总目标active。

'''+p.read_text())
print(json.dumps(result))

"""Exact retained controller/current engine Chat review and stored response acceptance.
One start, one selfcheck plus three reviewed business requests, no injected fault.
Original strict lease, ownership, cleanup and postflight contracts are reused.
"""
import argparse
import base64
import copy
import fcntl
import io
import json
import os
from pathlib import Path
import runpy
import signal
import socket
import subprocess
import sys
import time
import traceback
import uuid

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
VERSION = runpy.run_path(str(ROOT/'tools/serve_recovery/version_acceptance.py'))
MANAGED, LEGACY = VERSION['MANAGED'], VERSION['LEGACY']
LIMITS = {'tool_retained': dict(starts=1, chats=4, probes=0, controls=1500, seconds=180)}
PREVIOUS_LIMITS = LEGACY['verify'].__globals__['limits_for']
LEGACY['verify'].__globals__['limits_for'] = lambda name: (
    LIMITS[name] if name in LIMITS else PREVIOUS_LIMITS(name))
for function in (VERSION['launcher'], MANAGED['launcher']):
    function.__globals__['__file__'] = __file__
save = LEGACY['save']
def requests():
    base = dict(model='qwen3.8-flash-next', temperature=0,
        enable_thinking=False, max_completion_tokens=32, store=True)
    schema = dict(type='object', properties=dict(answer=dict(type='integer', const=42)),
                  required=['answer'], additionalProperties=False)
    review = dict(model=base['model'], policy=dict(input=dict(mode='score'),
                  output=dict(mode='block')))
    approved = dict(base, messages=[dict(role='user', content='Compute 17+25 as JSON.')],
        response_format=dict(type='json_schema', json_schema=dict(name='arithmetic',
            strict=True, schema=schema)), moderation=review, stream=True,
        stream_options=dict(include_usage=True))
    blocked = dict(base, n=2, messages=[dict(role='user', content='I will kill you tonight.')],
        moderation=dict(model=base['model'], policy=dict(input=dict(mode='block'),
            output=dict(mode='block'))))
    scored = copy.deepcopy(approved)
    scored.pop('stream_options');scored['stream']=False;scored['n']=2
    scored['moderation']['policy']['output']['mode']='score'
    return dict(approved=approved, blocked=blocked, scored=scored)


def require(ok, message):
    if not ok: raise RuntimeError(message)


def reviewed(value):
    reports = value['moderation']
    require(set(reports) == {'input', 'output'}, 'missing review directions')
    for direction, wrapper in reports.items():
        require(wrapper['type'] == 'moderation_results' and
            wrapper['model'] == value['model'] and len(wrapper['results']) == 1,
            'actual classification unavailable: ' + direction)
        report = wrapper['results'][0]
        require(report['type'] == 'moderation_result' and
            report['model'] == value['model'] and
            type(report['flagged']) is bool and
            len(report['categories']) == 13 and
            set(report['categories']) == set(report['category_scores']) ==
                set(report['category_applied_input_types']),
            'classification shape differs')
        require(all(type(x) is bool for x in report['categories'].values()) and
            all(type(x) in (int, float) and 0 <= x <= 1
                for x in report['category_scores'].values()),
            'invalid model category values')
    require(not reports['output']['results'][0]['flagged'],
            'benign structured answer was blocked')
    usage = value['q4t_moderation_usage']
    require(usage['model_steps'] == 2 and usage['input_tokens'] > 0 and
        0 < usage['output_tokens'] <= 1024, 'missing actual classifier work')
    return copy.deepcopy(usage)


def check_sse(raw):
    from tools.examples.chat_client import read_sse
    value=read_sse(io.BytesIO(raw))
    if value.finish_reason!='stop' or json.loads(value.message['content'])!={'answer':42}:
        raise RuntimeError('approved SSE answer differs')
    reviewed(dict(model=value.model,moderation=value.moderation,
        q4t_moderation_usage=value.q4t_moderation_usage))
    return value


def check_blocked(value):
    if len(value['choices'])!=2 or any(c['finish_reason']!='content_filter' or
        c['message']!={'role':'assistant','content':None} for c in value['choices']):
        raise RuntimeError('blocked input leaked generation')
    usage=value['q4t_moderation_usage']
    if usage['model_steps']!=1 or usage['input_tokens']<=0 or not 0<usage['output_tokens']<=512:
        raise RuntimeError('blocked input classifier work absent')
    if any(value['usage'][k]!=0 for k in ('prompt_tokens','completion_tokens','total_tokens')):
        raise RuntimeError('blocked input executed primary model')
    reports=value['moderation']
    if reports['input']['type']!='moderation_results' or not reports['input']['results'][0]['flagged'] or reports['output']['type']!='error' or reports['output']['code']!='moderation_not_executed':
        raise RuntimeError('actual flagged input or unexecuted output differs')


def check_scored(value):
    reviewed(value)
    if len(value['choices'])!=2 or any(c['finish_reason']!='stop' or
        json.loads(c['message']['content'])!={'answer':42} for c in value['choices']):
        raise RuntimeError('scored choices differ')


def check_business(execution):
    approved=check_sse((execution/'approved-sse.wire').read_bytes())
    blocked=json.loads((execution/'blocked-input.wire').read_bytes());check_blocked(blocked)
    scored=json.loads((execution/'scored-choices.wire').read_bytes());check_scored(scored)
    stored=json.loads((execution/'stored-approved.wire').read_bytes())
    if stored['id']!=approved.id or stored['moderation']!=approved.moderation or stored['q4t_moderation_usage']!=approved.q4t_moderation_usage or stored['choices'][0]['message']!=approved.message:
        raise RuntimeError('stored approved response or classification changed')
    if json.loads((execution/'other-client-http.json').read_text())['status']!=404:
        raise RuntimeError('stored response client isolation absent')
    expected=requests()
    for label,key in [('approved-sse','approved'),('blocked-input','blocked'),('scored-choices','scored')]:
        if json.loads((execution/(label+'-request.json')).read_text())!=expected[key]:
            raise RuntimeError('submitted moderation request drift')
    return dict(approved=approved.q4t_moderation_usage,
        blocked=blocked['q4t_moderation_usage'],scored=scored['q4t_moderation_usage'])


def prepare(args):
    bundle, _, _, _, _, engine = LEGACY['load_modules']()
    engine.require(not subprocess.check_output(['git','status','--porcelain'], cwd=ROOT),
                   'commit reviewed source before freezing')
    out = args.output.resolve()
    engine.require(out.is_relative_to(ROOT/'.q4t-work'), 'private output required')
    out.mkdir(mode=0o700, parents=True, exist_ok=False)
    package = args.package.resolve(strict=True)
    digest = engine.sha(package/'manifest.json'); manifest = bundle.verify(package, digest)
    policy = engine.read(package/'gateway-policy.json')
    engine.require(manifest['ingress_mode'] == 'native' and not manifest['tls'] and
        policy['listen_host'] == '127.0.0.1' and manifest.get('recovery_profiles'),
        'exact native loopback qualified payload required')
    names = subprocess.check_output(['git','ls-files','tools/serve_recovery','tools/serve_host',
        'tools/serve_service','tools/serve_ops','tools/serve_gateway','tools/evalscope',
        'tools/examples','tools/release','src/service','include/q4t/service'], cwd=ROOT,text=True).splitlines()
    plan = dict(version=1, scenario=args.scenario, limits=LIMITS[args.scenario],
        package=dict(package=str(package), manifest_sha256=digest), output=str(out),
        sources={n:engine.sha(ROOT/n) for n in sorted(set(names)|bundle.NATIVE_SOURCES)},
        protected=[dict(path=str(ROOT/n),sha256=engine.sha(ROOT/n)) for n in
            ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json')],
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        command=[sys.executable,'-I','-B',str(Path(__file__).resolve()),'run','--plan',str(out/'plan.json')],
        requests=requests(), default_replacement=False, automatic_request_replay=False,
        planned=dict(starts=LIMITS[args.scenario]['starts'],
            self_checks=LIMITS[args.scenario]['starts'], user_generations=3),
        scope='Exact retained-controller/current-engine Chat moderation: approved SSE, actual flagged input block, all-choice score and reviewed storage isolation. No injected fault, model replay, independent older-engine rollback or performance claim.')
    if args.scenario == 'tool_version':
        from tools.serve_recovery import version_contract
        engine.require(args.retained and args.release and args.decision,
                       'finalized exact retained acceptance required')
        retained = args.retained.resolve(strict=True)
        acceptance = {name:dict(path=str(path.resolve(strict=True)),sha256=engine.sha(path))
            for name,path in [('release',args.release),('decision',args.decision)]}
        registration = version_contract.prepare(plan['package'], plan['package'],
            dict(package=str(retained), manifest_sha256=engine.sha(retained/'manifest.json')),
            str(uuid.uuid4()), fallback_acceptance=acceptance)
        plan['registration'] = registration
        helper = out/'counted-cuda-probe'
        helper.write_text('#!'+sys.executable+'\nimport runpy,sys\nsys.argv='+repr([
            str(Path(__file__).resolve()),'probe','--plan',str(out/'plan.json')])+
            '\nrunpy.run_path(sys.argv[0],run_name="__main__")\n')
        helper.chmod(0o500)
        plan['probe_wrapper'] = dict(path=str(helper),sha256=engine.sha(helper))
    for name in [str(Path(__file__).resolve().relative_to(ROOT)), 'tools/serve_protocol/chat_moderation_acceptance.py', *subprocess.check_output(['git','ls-files','tools/serve_responses'], cwd=ROOT,text=True).splitlines()]:
        plan['sources'][name] = engine.sha(ROOT/name)
    save(out/'plan.json',plan)
    print(json.dumps(dict(plan=str(out/'plan.json'),limits=plan['limits'])))


class Stage(VERSION['Stage']):
    def initialize_state(self):
        if self.plan['scenario'] == 'tool_retained':
            return LEGACY['Stage'].initialize_state(self)
        return super().initialize_state()

    def request(self, label, body=None, *, client='alpha', path='/v1/models',
                method=None, expected=200, model_work=False, raw_result=False):
        import http.client
        time.sleep(.22)
        self.budget.reserve('chats' if model_work else 'controls', label)
        raw = None if body is None else json.dumps(body).encode()
        if body is not None:
            save(self.output/(label+'-request.json'),body)
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=120)
        try:
            connection.request(method or ('GET' if body is None else 'POST'),path,raw,
                {'Authorization':'Bearer '+self.keys[client], 'Content-Type':'application/json'})
            response = connection.getresponse(); wire = response.read(4*1024**2+1)
            self.engine.require(len(wire) <= 4*1024**2, 'response byte bound')
            (self.output/(label+'.wire')).write_bytes(wire)
            save(self.output/(label+'-http.json'), dict(status=response.status))
            self.engine.require(response.status == expected, 'HTTP status differs: '+label)
            return wire if raw_result else json.loads(wire)
        finally:
            connection.close()

    def exercise(self):
        self.engine.require(self.plan['scenario']=='tool_retained','bounded retained only')
        self.ready(1,'primary')
        raw=self.request('approved-sse',self.plan['requests']['approved'],
            path='/v1/chat/completions',model_work=True,raw_result=True)
        value=check_sse(raw)
        self.request('stored-approved',path='/v1/chat/completions/'+value.id)
        self.request('other-client',client='beta',expected=404,
            path='/v1/chat/completions/'+value.id)
        blocked=self.request('blocked-input',self.plan['requests']['blocked'],client='beta',
            path='/v1/chat/completions',model_work=True)
        check_blocked(blocked)
        scored=self.request('scored-choices',self.plan['requests']['scored'],
            path='/v1/chat/completions',model_work=True)
        check_scored(scored)
        usage=check_business(self.output)
        save(self.output/'classifier-usage.json',usage)
        save(self.output/'business-final.json',business_record(False))

    def run(self):
        failure = cleanup_failure = None
        def expired(*_): raise TimeoutError('bounded feature service deadline')
        old_alarm = signal.signal(signal.SIGALRM,expired)
        old_term = signal.signal(signal.SIGTERM,expired)
        signal.setitimer(signal.ITIMER_REAL,self.plan['limits']['seconds']-70)
        try:
            initialized = self.initialize_state(); self.service_id=initialized['service_id']
            save(self.output/'initialized.json',initialized)
            with (self.output/'launcher.log').open('xb') as log:
                self.process = subprocess.Popen([sys.executable,'-I','-B',str(Path(__file__).resolve()),
                    'launcher','--plan',str(self.plan_path)],stdin=subprocess.DEVNULL,
                    stdout=log,stderr=log,pass_fds=(self.lease,),start_new_session=True)
            self.exercise(); LEGACY['verify'](self.plan)
        except BaseException:
            failure=traceback.format_exc()
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            try:self.stop()
            except BaseException:cleanup_failure=traceback.format_exc()
            signal.signal(signal.SIGALRM,old_alarm); signal.signal(signal.SIGTERM,old_term)
            result=dict(status='PASS_BOUNDED_FEATURE_SERVICE' if not failure and not cleanup_failure
                else 'FAILED',failure=failure,cleanup_failure=cleanup_failure,
                seconds=time.monotonic()-self.started,budget=self.engine.read(self.output/'counts.json'),
                models=self.models,package=self.plan['package'],scenario=self.plan['scenario'],
                default_replaced=False,performance_acceptance=False)
            save(self.output/'result.json',result)
            print(json.dumps(result),flush=True)
        return int(failure is not None or cleanup_failure is not None)


def accepted_run(plan, result, guard, queries, events):
    """No acceptance for partial business, monitoring gaps or overspent bounds."""
    def require(condition, reason):
        if not condition:raise RuntimeError(reason)
    limits=LIMITS[plan['scenario']]
    require(plan['limits']==limits,'frozen bounds differ')
    require(result['status']=='PASS_BOUNDED_FEATURE_SERVICE' and
        result['failure'] is None and result['cleanup_failure'] is None and
        result['package']==plan['package'] and result['scenario']==plan['scenario'] and
        0 < result['seconds'] < limits['seconds'],'managed business not accepted')
    counts=result['budget']['counts']
    require(set(counts)==set(limits)-{'seconds'} and all(type(v) is int and
        0 <= v <= limits[k] for k,v in counts.items()) and
        all(counts[k]==limits[k] for k in ('starts','chats','probes')),
        'actual managed work incomplete or exceeds frozen bounds')
    require(guard.get('status')=='COMPLETED' and guard.get('child_returncode')==0 and
        guard.get('compute_backend')=='nvml' and guard.get('lease_inherited_by_child') is True and
        guard.get('external_lease') is False and guard.get('command')==plan['command'],
        'strict managed environment not accepted')
    require(queries and all(q.get('status')=='OK' and q.get('returncode')==0 for q in queries),
        'missing or failed NVML observation')
    acquired=[e for e in events if e.get('event')=='lease_acquired']
    released=[e for e in events if e.get('event')=='lease_released']
    require(len(acquired)==len(released)==1 and released[0].get('status')=='COMPLETED' and
        acquired[0]['pid']==released[0]['pid'],'strict lease not completed')
    seconds=released[0]['monotonic']-acquired[0]['monotonic']
    require(0 < seconds < limits['seconds'],'strict lease duration exceeds frozen bound')
    return dict(strict_lease_seconds=seconds,nvml_queries=len(queries),env_abort=False)


def finalize(path):
    path=path.resolve(strict=True);plan=json.loads(path.read_bytes())
    bundle,_,_,journal,_,engine=LEGACY['load_modules'](plan)
    manifest=LEGACY['verify'](plan)
    out=Path(plan['output']);execution=out/'execution';lease=out/'lease'
    result=engine.read(execution/'result.json')
    environment=accepted_run(plan,result,engine.read(lease/'exit.json'),
        [json.loads(line) for line in (lease/'nvml-queries.jsonl').read_text().splitlines()],
        [json.loads(line) for line in (lease/'events.jsonl').read_text().splitlines()])
    engine.require(result['budget']==engine.read(execution/'counts.json'),'count receipt changed')
    stopped=engine.read(execution/'stop.json')
    ledger=engine.read(execution/'state/ledger.json')['state']
    initialized=engine.read(execution/'initialized.json')
    engine.require(stopped['cleanup_confirmed'] and stopped['stop_durable'] and
        ledger['desired']=='STOPPED' and all(v is None for v in ledger['active'].values()) and
        ledger['service_id']==initialized['service_id'],'durable stop not confirmed')
    identities={(int(v['pid']),int(v['start_ticks'])) for v in result['models'].values()}
    for line in (execution/'status.jsonl').read_text().splitlines():
        value=json.loads(line)
        for role in ('guardian','controller','model','gateway'):
            if value.get(role+'_pid') is not None:
                identities.add((value[role+'_pid'],value[role+'_start_ticks']))
    for pid,ticks in identities:
        try:engine.require(journal.process_start(pid)!=ticks,'owned process survived cleanup')
        except (FileNotFoundError,ProcessLookupError):pass
    policy=engine.read(Path(plan['package']['package'])/'gateway-policy.json')
    for port in (policy['listen_port'],policy['upstream_port'],policy['upstream_operations_port']):
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            sock.bind(('127.0.0.1',port))
    with Path(manifest['lock_path']).open('r+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if 'registration' in plan:
        from tools.serve_recovery import version_contract
        version_contract.verify(plan['registration'])
    engine.require(check_business(execution)==engine.read(execution/'classifier-usage.json'),'classifier accounting drift')
    business=engine.read(execution/'business-final.json')
    engine.require(business == business_record(plan['scenario'] == 'tool_version'),
        'business completion record differs')
    acceptance='ACCEPT_CHAT_MODERATION_SERVICE_'+('VERSION' if plan['scenario']=='tool_version' else 'RETAINED')
    package=Path(plan['package']['package'])
    binary_sha=engine.sha(package/'engine/q4t')
    release_sha=engine.sha(package/'engine/q4t.release.json')
    decision=dict(status='PASS_'+acceptance.removeprefix('ACCEPT_'),acceptance=acceptance,
        manifest_sha256=plan['package']['manifest_sha256'],
        engine_binary_sha256=binary_sha,
        actual_business=dict(status=acceptance,**environment,counts=result['budget']['counts'],
            source_commit=plan['source_commit'],plan_sha256=engine.sha(path),
            result_sha256=engine.sha(execution/'result.json'),lease_result_sha256=engine.sha(lease/'exit.json'),
            postflight=dict(sources_unchanged=True,owned_processes_gone=True,ports_free=True,
                            lock_released=True,default_unchanged=True)),
        default_replaced=False,performance_acceptance=False,long_stability_accepted=False)
    engine.require(not (out/'decision.json').exists() and not (out/'service-release.json').exists(),
                   'preserve existing acceptance record')
    save(out/'decision.json',decision)
    save(out/'service-release.json',dict(version=4,profile='q4t-service-recovery-v4',
        acceptance=acceptance,recovery_accepted=True,acceptance_record=str(out/'decision.json'),
        acceptance_sha256=engine.sha(out/'decision.json'),**plan['package'],
        engine_binary_sha256=binary_sha,
        engine_release_sha256=release_sha,ingress_mode='native',
        state=str(execution/'state'),service_id=initialized['service_id'],
        initial_desired='STOPPED',automatically_started=False,
        scope=plan['scope'],default_replaced=False))
    print(json.dumps(dict(acceptance=acceptance,**environment,counts=result['budget']['counts'])))


def business_record(version):
    if version:
        raise RuntimeError('unplanned version switch')
    return dict(status='PASS',approved_sse=True,actual_input_block=True,
        all_choices_score=True,reviewed_storage=True,client_isolation=True,
        default_replaced=False,automatic_request_or_tool_replay=False)



def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','run','finalize','launcher','controller','gateway','probe'))
    parser.add_argument('--scenario',choices=tuple(LIMITS),default='tool_retained')
    for name in ('package','output','plan','config','retained','release','decision'):
        parser.add_argument('--'+name,type=Path)
    parser.add_argument('--payload',choices=('primary','fallback'))
    args=parser.parse_args()
    if args.mode == 'prepare':
        prepare(args); return
    if args.mode == 'finalize':
        finalize(args.plan); return
    plan=json.loads(args.plan.read_text())
    if args.mode == 'run':
        LEGACY['load_modules'](plan)
        from tools.release.release import child_subreaper
        with child_subreaper():
            raise SystemExit(Stage(plan,args.plan.resolve()).run())
    for function in (VERSION['actor'],VERSION['probe'],MANAGED['controller_actor']):
        function.__globals__['LIMITS']=plan['limits']
    if args.mode == 'launcher':
        function=VERSION['launcher'] if plan['scenario']=='tool_version' else MANAGED['launcher']
        raise SystemExit(function(plan,args.plan.resolve()))
    if args.mode == 'probe': VERSION['probe'](plan)
    elif plan['scenario']=='tool_version': VERSION['actor'](plan,args.payload,args.mode,args.config)
    else: MANAGED['controller_actor'](plan,args.config)


if __name__ == "__main__":
    main()

from pathlib import Path
import ast
W=Path(__file__).resolve().parent
old=W.parent/'serve-chat-annotations-20261116'
s=(old/'modern_citations.py').read_text()
s=s.replace('Exact modern retained controller/current engine citation SSE and stored Chat acceptance.', 'Exact retained controller/current engine Chat review and stored response acceptance.')
s=s.replace('One start, one selfcheck plus one business generation, no injected fault.', 'One start, one selfcheck plus three reviewed business requests, no injected fault.')
s=s.replace('chats=2', 'chats=4')
start=s.index('def requests():');end=s.index('\ndef prepare(args):',start)
s=s[:start]+'''def requests():
    base = dict(model='qwen3.8-flash-next', temperature=0,
        enable_thinking=False, max_completion_tokens=32, store=True)
    schema = dict(type='object', properties=dict(answer=dict(type='integer', const=42)),
                  required=['answer'], additionalProperties=False)
    review = dict(model=base['model'], policy=dict(input=dict(mode='score'),
                  output=dict(mode='block')))
    approved = dict(base, messages=[dict(role='user', content='Compute 17+25 as JSON.')],
        response_format=dict(type='json_schema', json_schema=dict(name='arithmetic',
            strict=True, schema=schema)), moderation=review, stream=True,
        stream_options=dict(include_usage=True))
    blocked = dict(base, n=2, messages=[dict(role='user', content='I will kill you tonight.')],
        moderation=dict(model=base['model'], policy=dict(input=dict(mode='block'),
            output=dict(mode='block'))))
    scored = copy.deepcopy(approved)
    scored.pop('stream_options');scored['stream']=False;scored['n']=2
    scored['moderation']['policy']['output']['mode']='score'
    return dict(approved=approved, blocked=blocked, scored=scored)


def check_sse(raw):
    from tools.examples.chat_client import read_sse
    from tools.serve_protocol.chat_moderation_acceptance import reviewed
    value=read_sse(io.BytesIO(raw))
    if value.finish_reason!='stop' or json.loads(value.message['content'])!={'answer':42}:
        raise RuntimeError('approved SSE answer differs')
    reviewed(dict(model=value.model,moderation=value.moderation,
        q4t_moderation_usage=value.q4t_moderation_usage))
    return value


def check_blocked(value):
    if len(value['choices'])!=2 or any(c['finish_reason']!='content_filter' or
        c['message']!={'role':'assistant','content':None} for c in value['choices']):
        raise RuntimeError('blocked input leaked generation')
    usage=value['q4t_moderation_usage']
    if usage['model_steps']!=1 or usage['input_tokens']<=0 or not 0<usage['output_tokens']<=512:
        raise RuntimeError('blocked input classifier work absent')
    if any(value['usage'][k]!=0 for k in ('prompt_tokens','completion_tokens','total_tokens')):
        raise RuntimeError('blocked input executed primary model')
    reports=value['moderation']
    if reports['input']['type']!='moderation_results' or not reports['input']['results'][0]['flagged'] or reports['output']['type']!='error' or reports['output']['code']!='moderation_not_executed':
        raise RuntimeError('actual flagged input or unexecuted output differs')


def check_scored(value):
    from tools.serve_protocol.chat_moderation_acceptance import reviewed
    reviewed(value)
    if len(value['choices'])!=2 or any(c['finish_reason']!='stop' or
        json.loads(c['message']['content'])!={'answer':42} for c in value['choices']):
        raise RuntimeError('scored choices differ')


def check_business(execution):
    approved=check_sse((execution/'approved-sse.wire').read_bytes())
    blocked=json.loads((execution/'blocked-input.wire').read_bytes());check_blocked(blocked)
    scored=json.loads((execution/'scored-choices.wire').read_bytes());check_scored(scored)
    stored=json.loads((execution/'stored-approved.wire').read_bytes())
    if stored['id']!=approved.id or stored['moderation']!=approved.moderation or stored['q4t_moderation_usage']!=approved.q4t_moderation_usage or stored['choices'][0]['message']!=approved.message:
        raise RuntimeError('stored approved response or classification changed')
    if json.loads((execution/'other-client-http.json').read_text())['status']!=404:
        raise RuntimeError('stored response client isolation absent')
    expected=requests()
    for label,key in [('approved-sse','approved'),('blocked-input','blocked'),('scored-choices','scored')]:
        if json.loads((execution/(label+'-request.json')).read_text())!=expected[key]:
            raise RuntimeError('submitted moderation request drift')
    return dict(approved=approved.q4t_moderation_usage,
        blocked=blocked['q4t_moderation_usage'],scored=scored['q4t_moderation_usage'])

''' + s[end:]
s=s.replace("user_generations=LIMITS[args.scenario]['starts']", "user_generations=3")
s=s.replace('Exact modern retained-controller/current-engine citation history SSE, actual title consumption and stored Chat isolation.', 'Exact retained-controller/current-engine Chat moderation: approved SSE, actual flagged input block, all-choice score and reviewed storage isolation.')
s=s.replace("'docs/SERVE_MEMORY_STOP_2026-11-03.md', *subprocess", "'tools/serve_protocol/chat_moderation_acceptance.py', *subprocess")
start=s.index('    def exercise(self):');end=s.index('\n    def run(self):',start)
s=s[:start]+'''    def exercise(self):
        self.engine.require(self.plan['scenario']=='tool_retained','bounded retained only')
        self.ready(1,'primary')
        raw=self.request('approved-sse',self.plan['requests']['approved'],
            path='/v1/chat/completions',model_work=True,raw_result=True)
        value=check_sse(raw)
        self.request('stored-approved',path='/v1/chat/completions/'+value.id)
        self.request('other-client',client='beta',expected=404,
            path='/v1/chat/completions/'+value.id)
        blocked=self.request('blocked-input',self.plan['requests']['blocked'],client='beta',
            path='/v1/chat/completions',model_work=True)
        check_blocked(blocked)
        scored=self.request('scored-choices',self.plan['requests']['scored'],
            path='/v1/chat/completions',model_work=True)
        check_scored(scored)
        usage=check_business(self.output)
        save(self.output/'classifier-usage.json',usage)
        save(self.output/'business-final.json',business_record(False))
''' + s[end:]
start=s.index('    read_citation((execution/');end=s.index("    business=engine.read",start)
s=s[:start]+"    engine.require(check_business(execution)==engine.read(execution/'classifier-usage.json'),'classifier accounting drift')\n"+s[end:]
s=s.replace('ACCEPT_CHAT_ANNOTATIONS_MODERN_SERVICE_', 'ACCEPT_CHAT_MODERATION_SERVICE_')
start=s.index("    return dict(status='PASS', citation_history_sse=True");end=s.index('\n\n\ndef main():',start)
s=s[:start]+'''    return dict(status='PASS',approved_sse=True,actual_input_block=True,
        all_choices_score=True,reviewed_storage=True,client_isolation=True,
        default_replaced=False,automatic_request_or_tool_replay=False)
'''+s[end:]
assert 'read_citation' not in s and 'check_saved' not in s
ast.parse(s);(W/'native_moderation.py').write_text(s)
print('prepared native moderation driver with original lease/cleanup verification')

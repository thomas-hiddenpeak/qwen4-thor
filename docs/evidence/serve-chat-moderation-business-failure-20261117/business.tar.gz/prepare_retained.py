"""Retained v12 control with explicit media contract adapters; fresh acceptance required."""
import copy,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle,cold_compat,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'retained-01'
OLD=ROOT/'.q4t-work/serve-refusal-20261112/selfcheck-repair-01/fallback'
OLD_SHA='c93e9714786643a76a933039bff0843df1d40030f2669085f6041af8db0e1ae7'
PRIMARY=W/'package-01/bundle';PRIMARY_SHA=p.read(W/'package-01/receipt.json')['manifest_sha256']
ADAPTERS=['tools/serve_ops/contracts.py','tools/serve_service/package.py','tools/serve_service/supervisor.py','tools/serve_service/capacity.py','tools/serve_recovery/profile_contract.py','tools/serve_recovery/profile_evidence.py']

def main():
    os.umask(0o077);before={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json']}
    old=bundle.verify(OLD,OLD_SHA);current=bundle.verify(PRIMARY,PRIMARY_SHA)
    p.require(not OUT.exists(),'preserve original preparation')
    p.require(old['recovery_profile_policy']==current['recovery_profile_policy'],'policy changed')
    OUT.mkdir(mode=0o700);target=OUT/'bundle'
    shutil.copytree(OLD,target,symlinks=True,ignore=lambda directory,_:{'engine'} if Path(directory)==OLD else set())
    shutil.copytree(PRIMARY/'engine',target/'engine',symlinks=True)
    changed=copy.deepcopy(old);changed['engine_manifest_sha256']=current['engine_manifest_sha256'];changed['recovery_profiles']=current['recovery_profiles']
    names=['profile-primary.json','profile-light.json','native-build.json','bin/q4t-guardian','bin/q4t-cuda-probe','bin/q4t-ingress',*('source/'+n for n in ADAPTERS)]
    for name in names:
        path=target/name;p.require(name in changed['files'],'unexpected legacy module')
        path.chmod(0o600);shutil.copyfile(PRIMARY/name,path);path.chmod(0o500 if name.startswith('bin/') else 0o400);changed['files'][name]=p.sha(path)
    p.save(target/'manifest.json',changed);digest=p.sha(target/'manifest.json')
    launch=target/'bin/q4t';launch.chmod(0o700);launch.write_bytes(bundle.launcher(digest,changed['python']['path']));launch.chmod(0o500)
    p.require(bundle.verify(target,digest)==changed,'payload verification failed')
    difference={n for n,h in old['files'].items() if changed['files'][n]!=h}
    p.require(difference<=set(names) and all(changed['files']['source/'+n]==current['files']['source/'+n] for n in ADAPTERS),'unreviewed legacy changes')
    p.require(cold_compat.aware(target),'cold custody awareness missing')
    control='source/tools/serve_recovery/controller.py';p.require(changed['files'][control]==old['files'][control]!=current['files'][control],'retained controller must differ')
    root=dict(package=str(PRIMARY),manifest_sha256=PRIMARY_SHA);fallback=dict(package=str(target),manifest_sha256=digest)
    permit=version_contract.compatible(version_contract.payload(root),version_contract.payload(fallback));p.require(permit['automatic'],'compatibility absent')
    p.require(all(p.sha(ROOT/n)==h for n,h in before.items()),'default changed');bundle.verify(OLD,OLD_SHA)
    p.save(OUT/'review.json',dict(status='NEW_PAYLOAD_ACTUAL_ACCEPTANCE_PENDING',original=dict(package=str(OLD),manifest_sha256=OLD_SHA),primary=root,fallback=fallback,changed_files=sorted(difference),media_adapters=ADAPTERS,compatibility=permit,control_implementation='Accepted v12 controller and unchanged legacy state machine; six current media capacity/declaration/observation/evidence adapters; current accepted engine and byte-identical helpers. Fresh complete payload needs actual acceptance. Not independent older-engine rollback.',original_acceptance_not_relabelled=True,default_unchanged=True,driver_sha256=p.sha(Path(__file__))))
    print(digest)
if __name__=='__main__':main()

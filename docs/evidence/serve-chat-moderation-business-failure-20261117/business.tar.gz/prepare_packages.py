from pathlib import Path
import ast
W=Path(__file__).resolve().parent;old=W.parent/'serve-chat-annotations-20261116'
s=(old/'prepare_package.py').read_text().replace('annotation','moderation').replace('ANNOTATION','MODERATION').replace('citation history','input/output moderation').replace('profiles-01','profiles-02').replace('rev188','rev196')
s=s.replace("expected={'include/q4t/server/chat_template.h','src/server/chat_contract.cpp','src/server/chat_template.cpp','src/server/chat_capabilities.cpp','src/service/guardian_main.cpp'}", "expected={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','cmake/HostTestSources.cmake','include/q4t/server/chat_moderation.h','include/q4t/server/chat_plan.h','include/q4t/server/moderation.h','include/q4t/server/moderation_options.h','src/server/batch_budget.cpp','src/server/chat_capabilities.cpp','src/server/chat_contract.cpp','src/server/chat_generation.cpp','src/server/chat_model_step.h','src/server/chat_moderation.cpp','src/server/chat_plan.cpp','src/server/moderation.cpp'}")
s=s.replace("p.require(not native_delta,'unexpected native source delta')", """p.require(native_delta=={'CMakeLists.txt'},'unexpected native source delta')
    previous_cmake=subprocess.check_output(['git','show','a8238ce4:CMakeLists.txt'],cwd=ROOT)
    p.require(hashlib.sha256(previous_cmake).hexdigest()==old_native['source_files']['CMakeLists.txt'],'accepted CMake source identity differs')
    current_cmake=(ROOT/'CMakeLists.txt').read_bytes()
    p.require(current_cmake.replace(b'  src/server/chat_moderation.cpp\\n',b'').replace(b'    tests/server_chat_moderation_test.cpp\\n',b'')==previous_cmake,'native target CMake contract changed')""")
s=s.replace("native=copy.deepcopy(old_native);same={}", "native=copy.deepcopy(old_native);native['source_files']['CMakeLists.txt']=p.sha(ROOT/'CMakeLists.txt');same={}")
s=s.replace('changed_sources=[],executable_hashes_identical=same', "changed_sources=['CMakeLists.txt'],cmake_changes='Only q4t_server and host-test source entries; removing exactly the three reviewed additions reproduces accepted CMake bytes. Native target source and link contracts unchanged; no helper rebuild.',executable_hashes_identical=same")
start=s.index("rationale='All native");end=s.index("')\n    OUT.mkdir",start)
s=s[:start]+"rationale='Native target sources/link contracts, bundled recovery/control source and helper executables are unchanged from rev196. CMake changes only add server and test entries. Reuse accepted native ingress/recovery evidence; new exact engine and primary/light Chat classification, actual document tool and reviewed storage/restart business accepted. Fresh full payload acceptance follows separately."+s[end:]
start=s.index("source_note='Assistant");end=s.index("')\n    metadata[",start)
s=s[:start]+"source_note='Chat input/output moderation reuses the actual served classifier, atomically gates all-choice block output and reviewed storage, and accounts actual auxiliary work in the same quota. Twenty-six C++ and eight schema/native/client cases accepted; exact primary/light classification, existing document tool/media/embedding and reviewed storage/restart accepted. Python/JS clients preserve standard reports and content_filter. Native helper target source and link contracts are unchanged. Fresh retained-controller business and reversible publication pending; no full correctness/performance or complete compatibility claim"+s[end:]
s=s.replace("p.require(not client_delta,'unreviewed client delta')", "p.require(client_delta=={'tools/examples/chat_client.py','tools/examples/js/chat_client.mjs'},'unreviewed client delta')")
s=s.replace('native_source_delta=[],native_executables_identical=same', "native_source_delta=['CMakeLists.txt'],native_executables_identical=same")
ast.parse(s);(W/'prepare_package.py').write_text(s)
(W/'prepare_retained.py').write_text((old/'prepare_retained.py').read_text())
s=(old/'prepare_modern_root.py').read_text().replace("serve-root-rollback-20261116/retained-02/bundle", "serve-chat-annotations-20261116/modern-retained-01/bundle").replace('7230ac61be71a95bddd142bce982dd8b8d09eb485c57214aaa92666dc4f48964','42c34068b6a588746d74fc646f27d8994d131bef79f159d154b88e1bfbbcbc2e').replace("differences=={rel,'source/tools/serve_ops/contracts.py'}",'differences=={rel}')
ast.parse(s);(W/'prepare_modern_root.py').write_text(s)
print('package scripts prepared; native CMake changes require exact three-line equivalence')

import hashlib
import json
from pathlib import Path
import re
import tarfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
stems = ['build-host-01', 'build-host-02', 'build-engine-01',
         'build-engine-02', 'host-cpu-01', 'frontend-cpu-01',
         'frontend-cpu-02', 'source-gate-01', 'source-gate-02',
         'generated-check-01', 'generated-check-02']
files = []
for name in stems:
    receipt = json.loads((W / (name + '.json')).read_text())
    expected = 2 if name in ('build-host-01', 'build-engine-01') else (
        1 if name == 'frontend-cpu-01' else 0)
    assert receipt['exit_code'] == expected, (name, receipt['exit_code'])
    assert receipt['default_unchanged']
    for ext in ('json', 'stdout', 'stderr'):
        files.append((W / (name + '.' + ext), name + '.' + ext))
    if name in ('build-host-02', 'build-engine-02'):
        text = (W / (name + '.stdout')).read_text() + (
            W / (name + '.stderr')).read_text()
        assert not re.search(r'\bwarning:|\berror:', text)
assert '26 tests, 26 passed, 0 failed, 0 skipped' in (
    W / 'host-cpu-01.stdout').read_text()
assert 'Ran 8 tests' in (W / 'frontend-cpu-01.stderr').read_text()
assert 'Ran 5 tests' in (W / 'frontend-cpu-02.stderr').read_text()
for directory in ('frontend-01', 'frontend-02', 'build-failure-source-01'):
    for path in (W / directory).rglob('*'):
        if path.is_file():
            files.append((path, str(path.relative_to(W))))
for path in (W / 'cpu-01').iterdir():
    if path.is_file():
        files.append((path, str(path.relative_to(W))))
for name in ('required-cpu.txt', 'run.py', 'archive_cpu.py',
             'frontend-before-repair.py', 'js-client-before-repair.mjs'):
    files.append((W / name, name))
for name in ('tools/serve_protocol/test_chat_moderation.py',
             'tools/examples/js/chat_client.mjs',
             'include/q4t/server/chat_moderation.h',
             'include/q4t/server/moderation_options.h',
             'src/server/chat_moderation.cpp', 'src/server/chat_generation.cpp'):
    files.append((R / name, name))
for path, name in files:
    assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',
                         path.read_bytes()), name
out = R / 'docs/evidence/serve-chat-moderation-cpu-20261117'
out.mkdir()
with tarfile.open(out / 'cpu.tar.gz', 'w:gz') as archive:
    for path, name in sorted(files, key=lambda x: x[1]):
        archive.add(path, arcname=name)
build = R / '.q4t-work/serve-custom-tools-20261108/engine-build'
result = dict(status='PASS_TARGETED_CPU', cpp_unique_tests=26,
    frontend_unique_cases=8, first_frontend_passed=3, repeated_frontend=5,
    original_build_and_frontend_failures_preserved=True,
    zero_warning_final_builds=True, source_anchors=726, source_negative_controls=7,
    engine_binary_sha256=sha(build / 'q4t'),
    preflight_probe_sha256=sha(build / 'q4t_preflight_probe'),
    contract_probe_sha256=sha(build / 'q4t_contract_probe'),
    archive_sha256=sha(out / 'cpu.tar.gz'), files=len(files),
    default_revision=196, default_unchanged=True, gpu_starts=0,
    runtime_accepted=False, full_model_quality=False, performance_claim=False,
    master_complete=False)
(out / 'acceptance.json').write_text(json.dumps(result, indent=2) + '\n')
(out / 'README.md').write_text('''# Chat审核针对性CPU接受

2026-11-17，26项C++和8种schema/native预检/双客户端病例最终通过。
原生预检读取只读checkpoint tokenizer并逐字节比较既有模板和token
IDs；没有加载模型。审核状态用显式分类夹具验证，不冒充真实分类。

覆盖输入/全choice输出score/block、分类错误策略、流式缓冲和重复
终态、过滤输出持久化、同一Batch预算、普通Chat/null兼容及受影响
独立Moderations合同。首轮构建两处API使用错误已修复，原输出保留。
首轮前端3/8通过；四个预期补回既有refusal模板头，一项修复JS对
合法缺省logprobs的误拒绝，仅补五个失败病例，最终全部通过。

726来源/7负控、生成物一致性及隔离host/engine零警告构建通过。
默认rev196及程序未修改，0GPU。继续最多4启动/18个外部生成请求/
900秒真实业务，内部分类另计实际token/步骤；尚未声明运行时通过。
全Serve任务仍active，不以本阶段CPU接受替代剩余实现和交付。
''')
print(json.dumps(result))

import hashlib,json,re,tarfile,runpy,sys,fcntl,socket
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Validate original postflight before the pending classifier repair changes source.
m=runpy.run_path(str(W/'native_moderation_repaired.py'));p=read(W/'modern-business-02/plan.json')
bundle,_,_,journal,_,engine=m['LEGACY']['load_modules'](p);manifest=m['LEGACY']['verify'](p)
e=W/'modern-business-02/execution';result=read(e/'result.json');assert result['status']=='FAILED' and result['cleanup_failure'] is None
assert read(e/'blocked-input-http.json')['status']==503
assert read(e/'blocked-input.wire')['error']['code']=='moderation_unavailable'
assert read(e/'other-client-http.json')['status']==404
approved=m['check_sse']((e/'approved-sse.wire').read_bytes());saved=read(e/'stored-approved.wire')
assert saved['id']==approved.id and saved['moderation']==approved.moderation and saved['q4t_moderation_usage']==approved.q4t_moderation_usage
state=read(e/'state/ledger.json')['state'];stopped=read(e/'stop.json');assert state['desired']=='STOPPED' and all(v is None for v in state['active'].values()) and stopped['cleanup_confirmed']
ids={(v['pid'],v['start_ticks']) for v in result['models'].values()}
for line in (e/'status.jsonl').read_text().splitlines():
 row=json.loads(line)
 for role in ['guardian','controller','model','gateway']:
  if row.get(role+'_pid') is not None:ids.add((row[role+'_pid'],row[role+'_start_ticks']))
for pid,tick in ids:
 try:assert journal.process_start(pid)!=tick
 except (FileNotFoundError,ProcessLookupError):pass
policy=read(Path(p['package']['package'])/'gateway-policy.json')
for port in [policy[k] for k in ['listen_port','upstream_port','upstream_operations_port']]:
 with socket.socket() as sock:sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);sock.bind(('127.0.0.1',port))
with Path(manifest['lock_path']).open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
files=[];queries=[]
for name in ['profiles-01','profiles-02','retained-business-01','modern-business-01','modern-business-02']:
 base=W/name
 for p in base.iterdir():
  if p.is_file() and p.name!='client-policy.json':files.append((p,name+'/'+p.name))
 for sub in ['lease','qualified','execution']:
  if not (base/sub).exists():continue
  for p in (base/sub).iterdir():
   if p.is_file() and p.name!='budget.lock':files.append((p,name+'/'+sub+'/'+p.name))
 for p in (base/'execution').rglob('model.log'):files.append((p,str(p.relative_to(W))))
 p=base/'lease/nvml-queries.jsonl'
 if p.exists():queries += [json.loads(l) for l in p.read_text().splitlines()]
for p in W.iterdir():
 if p.is_file() and p.suffix in ['.json','.stdout','.stderr','.py'] and p.name not in ['frontend-before-repair.py','js-client-before-repair.mjs']:
  files.append((p,p.name))
for parent in ['package-01','retained-01','modern-retained-01']:
 for p in (W/parent).iterdir():
  if p.is_file() and p.suffix=='.json':files.append((p,str(p.relative_to(W))))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ['api_key','gateway_token','shared_secret','private_key','token'] and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json',W/'profiles-02/client-policy.json']:collect(read(p))
for p,n in files:
 raw=p.read_bytes();assert not any(x in raw for x in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),n
runs=['profiles-gpu-01','profiles-gpu-02','retained-gpu-01','modern-gpu-02'];seconds=sum(read(W/(x+'.json'))['seconds'] for x in runs)
assert seconds<900 and all(q['status']=='OK' and q['returncode']==0 for q in queries)
out=R/'docs/evidence/serve-chat-moderation-business-failure-20261117';out.mkdir()
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n,recursive=False)
result=dict(status='HOLD_CLASSIFIER_REFUSAL_REPAIR',starts=4,external_requests=15,seconds=seconds,nvml_queries=len(queries),nvml_all_ok=True,cleanup_complete=True,default_revision=196,default_unchanged=True,profile_business_accepted=True,legacy_complete_sse_independently_reviewed=True,modern_approved_sse_storage_isolation_observed=True,input_block_classification_accepted=False,score_multi_choice_not_run=True,original_failures_preserved=True,first_missing_lease_inheritance_before_model=True,legacy_checker_import_failure=True,actual_failure='native classifier refused assessment; required block returned 503 moderation_unavailable',no_unreviewed_output_leak=True,checker_cpu_cases=2,whole_phase_accepted=False,master_complete=False,files=len(files),archive_sha256=sha(out/'business.tar.gz'),secret_scan_matches=0)
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'README.md').write_text(f'''# Chat审核原始业务失败与定点补验

2026-11-17，累计4启动/15外部请求/{seconds:.3f}秒；{len(queries)}项NVML均正常，
模型/自有服务/端口/锁已清理，默认rev196未改。原始失败均保留。

主/轻配置10请求通过：真实分类、schema、资料工具、媒体、embedding
和存储重启。旧控制包自检及完整审核SSE已返回，但后置校验导入冲突；
修复校验器隔离依赖，两项CPU正负控后独立复核原响应，没有重放业务。
只接受原SSE这一事实，原驱动/guard仍失败，未声称其后未执行病例通过。

现代控制包审核SSE、存储回读及客户隔离已观察到。相同威胁输入的
内部分类器却返回input_preparation_refused，外层按block合同503，
没有运行原回答或发布待审内容。503不等于分类成功，输入命中及
多choice评分未接受，整阶段不交付；不能把模型拒绝填成高分/安全值。
首次驱动漏租约继承在加载前退出，0模型/0请求；该失败亦保留。

下一步改进分类任务与待审数据的表达，保留拒绝/错误保护，使用原
失败输入补验；其余无变化CPU和既有运行证据按身份保留，不做全矩阵。
只为必要精确包资格/组合冻结下一组有界短验，不把候选换成默认。
''')
print(json.dumps(result))

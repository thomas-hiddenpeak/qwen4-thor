"""Accept only original complete SSE; preserve the interrupted suite as failed."""
import fcntl
import hashlib
import json
from pathlib import Path
import runpy
import socket
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path, value):
    assert not path.exists(), 'preserve previous receipt'
    path.write_text(json.dumps(value, indent=2) + '\n')
def require(ok, message):
    if not ok:
        raise RuntimeError(message)

out = W / 'retained-business-01'
execution = out / 'execution'
plan_path = out / 'plan.json'
plan = read(plan_path)
original = W / 'native_moderation.py'
require(plan['sources'][str(original.relative_to(ROOT))] == sha(original),
        'original driver changed')
module = runpy.run_path(str(W / 'native_moderation_repaired.py'))
bundle, _, _, journal, _, engine = module['LEGACY']['load_modules'](plan)
manifest = module['LEGACY']['verify'](plan)
result = read(execution / 'result.json')
guard = read(out / 'lease/exit.json')
queries = [json.loads(x) for x in
           (out / 'lease/nvml-queries.jsonl').read_text().splitlines()]
events = [json.loads(x) for x in
          (out / 'lease/events.jsonl').read_text().splitlines()]
require(result['status'] == 'FAILED' and result['cleanup_failure'] is None and
        "ImportError: cannot import name 'profile_acceptance'" in result['failure']
        and 'value=check_sse(raw)' in result['failure'],
        'not the reviewed post-response import failure')
require(guard['status'] == 'COMMAND_FAILED' and guard['child_returncode'] == 1
        and guard['compute_backend'] == 'nvml' and
        guard['lease_inherited_by_child'] is True and
        guard['external_lease'] is False and guard['command'] == plan['command'],
        'original lease outcome or command differs')
require(queries and all(x['status'] == 'OK' and x['returncode'] == 0
                        for x in queries), 'monitor gap')
acquired = [x for x in events if x['event'] == 'lease_acquired']
released = [x for x in events if x['event'] == 'lease_released']
require(len(acquired) == len(released) == 1 and
        acquired[0]['pid'] == released[0]['pid'] and
        released[0]['status'] == 'COMMAND_FAILED', 'lease not released')
seconds = released[0]['monotonic'] - acquired[0]['monotonic']
require(0 < seconds < plan['limits']['seconds'], 'original time bound exceeded')
counts = result['budget']['counts']
require(counts['starts'] == 1 and counts['chats'] == 2 and counts['probes'] == 0
        and 0 < counts['controls'] <= plan['limits']['controls'] and
        result['budget'] == read(execution / 'counts.json'), 'work differs')
raw_path = execution / 'approved-sse.wire'
require(read(execution / 'approved-sse-http.json')['status'] == 200 and
        read(execution / 'approved-sse-request.json') == plan['requests']['approved'],
        'actual request/response differs')
value = module['check_sse'](raw_path.read_bytes())
repair = read(W / 'checker-repair-cpu.json')
require(repair['exact_original_wire_sha256'] == sha(raw_path) and
        repair['new_driver_sha256'] == sha(W / 'native_moderation_repaired.py')
        and repair['usage'] == value.q4t_moderation_usage,
        'repaired checker evidence identity differs')
require(not (execution / 'blocked-input.wire').exists() and
        not (execution / 'scored-choices.wire').exists(),
        'unexpected unreviewed model work')
stopped = read(execution / 'stop.json')
state = read(execution / 'state/ledger.json')['state']
initialized = read(execution / 'initialized.json')
require(stopped['cleanup_confirmed'] and stopped['stop_durable'] and
        state['desired'] == 'STOPPED' and
        all(v is None for v in state['active'].values()) and
        state['service_id'] == initialized['service_id'], 'stop not confirmed')
identities = {(int(x['pid']), int(x['start_ticks']))
              for x in result['models'].values()}
statuses = [json.loads(x) for x in
            (execution / 'status.jsonl').read_text().splitlines()]
require(any(x.get('state') == 'READY' for x in statuses), 'selfcheck not ready')
for value in statuses:
    for role in ('guardian', 'controller', 'model', 'gateway'):
        if value.get(role + '_pid') is not None:
            identities.add((value[role + '_pid'], value[role + '_start_ticks']))
for pid, ticks in identities:
    try:
        require(journal.process_start(pid) != ticks, 'owned process survives')
    except (FileNotFoundError, ProcessLookupError):
        pass
policy = read(Path(plan['package']['package']) / 'gateway-policy.json')
for port in (policy['listen_port'], policy['upstream_port'],
             policy['upstream_operations_port']):
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', port))
with Path(manifest['lock_path']).open('r+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
acceptance = 'ACCEPT_CHAT_MODERATION_RETAINED_SSE_REVIEW'
package = Path(plan['package']['package'])
decision = dict(status='PASS_CHAT_MODERATION_RETAINED_SSE_REVIEW',
    acceptance=acceptance, manifest_sha256=plan['package']['manifest_sha256'],
    engine_binary_sha256=sha(package / 'engine/q4t'),
    actual_business=dict(status=acceptance, env_abort=False, counts=counts,
        strict_lease_seconds=seconds, nvml_queries=len(queries),
        original_driver_status='FAILED', original_guard_status='COMMAND_FAILED',
        original_suite_accepted=False, accepted_scope='selfcheck and complete approved SSE only',
        input_block_score_storage_isolation_on_this_payload=False,
        actual_response_sha256=sha(raw_path), classifier_usage=read(W / 'checker-repair-cpu.json')['usage'],
        checker_repair_sha256=sha(W / 'checker-repair-cpu.json'),
        reviewer_sha256=sha(Path(__file__)), source_commit=plan['source_commit'],
        plan_sha256=sha(plan_path), result_sha256=sha(execution / 'result.json'),
        lease_result_sha256=sha(out / 'lease/exit.json'),
        postflight=dict(sources_unchanged=True, owned_processes_gone=True,
            ports_free=True, lock_released=True, default_unchanged=True)),
    default_replaced=False, performance_acceptance=False, long_stability_accepted=False)
save(out / 'decision.json', decision)
save(out / 'service-release.json', dict(version=4, profile='q4t-service-recovery-v4',
    acceptance=acceptance, recovery_accepted=True,
    acceptance_record=str(out / 'decision.json'), acceptance_sha256=sha(out / 'decision.json'),
    **plan['package'], engine_binary_sha256=sha(package / 'engine/q4t'),
    engine_release_sha256=sha(package / 'engine/q4t.release.json'), ingress_mode='native',
    state=str(execution / 'state'), service_id=initialized['service_id'],
    initial_desired='STOPPED', automatically_started=False,
    scope='Original selfcheck and approved moderated SSE independently verified. The interrupted driver remains failed; input block, score and storage isolation were not executed on this payload. Exact shared engine has primary/light acceptance; remaining compositions need separate real evidence.',
    default_replaced=False))
print(json.dumps(dict(acceptance=acceptance, counts=counts, seconds=seconds)))

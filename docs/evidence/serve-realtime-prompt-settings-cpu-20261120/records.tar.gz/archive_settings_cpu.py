from pathlib import Path
import json,hashlib,tarfile,os,re
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-prompt-settings-cpu-20261120'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(mode)
plan=read(W/'settings-plan-02.json');result=read(W/'settings-cpu-01/result.json');source=read(W/'settings-cpu-01/source-check.stdout');build=read(W/'settings-build-02/result.json')
assert result['status']=='PASS' and result['passed']==34 and source['inventory_current'] and source['mutation_checks']==20 and build['exit_code']==0
assert not re.search(r'\bwarning:',(W/'settings-build-02/build.log').read_text())
assert read(W/'private-header-restored-verification.json')['status']=='PASS_SHARED_ORIGINAL_RESTORED'
files={}
for prefix in ('settings-cpu-01','settings-build-01','settings-build-02'):
 for p in (W/prefix).rglob('*'):
  if p.is_file() and 'fixtures' not in p.relative_to(W/prefix).parts:files[str(p.relative_to(W))]=p
for name in ('settings-plan-01.json','settings-plan-02.json','settings-required-tests.txt','prepare_settings_cpu.py','private-header-detach-review.json','private-header-restored-verification.json','archive_settings_cpu.py'):files[name]=W/name
for f,h in plan['sources'].items():
 assert sha(R/f)==h,f
 files['source/'+f]=R/f
assert not O.exists();O.mkdir()
index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 for member in archive:assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==index[member.name]['sha256']
a=dict(status='PASS_REALTIME_PROMPT_SETTINGS_CPU',tests=34,settings_tests=10,registry_tests=24,seconds=result['seconds'],source_mutations=20,build_seconds=build['seconds'],build_warnings=0,original_build_failure_preserved=True,shared_original_restored=True,maximum_expansion_bytes=16<<20,maximum_retained_bytes=64<<20,new_gpu_starts=0,actual_realtime_session_accepted=False,default_revision=356,default_unchanged=True,files=len(files),archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a)
(O/'README.md').write_text(f'''# Realtime Prompt 设置事务 CPU

34 项针对性 CPU 用例通过，{a['seconds']:.3f} 秒、0GPU；其中10项
设置事务与24项真实对象工作线程的注册表合同。来源20反例通过。
最终必要构建 {a['build_seconds']:.3f} 秒、零警告；首轮测试文件缺少
匿名命名空间结束括号的编译失败保留，修正后再构建，未改运行时源码。

默认值、模板值与显式覆盖分别保存；普通更新保持已固定版本，
单轮选择/清除不改变会话，失败不提交设置或输出快照。嵌套音频设置
按类型合并，模型和已启用追踪保持不可变。模板前缀仅在私有快照，
尚未接实际执行。调用方可约束展开，Realtime组件为16MiB，保留
设置/模板/覆盖为64MiB；旧Responses默认192MiB未改。

发现私有header仍共享旧证据inode后，已恢复原SHA并分离当前路径；
原工作区文件SHA复核通过，没有构建或发布瞬时错误版本。全部原件
与修复记录在归档内。本阶段未进行模型、GPU、真实WebSocket验收，
默认rev356与PR #52冻结交付不变。继续有界会话解析、取消、实际执行
和前缀安全截断，再完成真实SDK业务与全部master任务。
''')
intro=f'[Prompt设置34项CPU通过](evidence/serve-realtime-prompt-settings-cpu-20261120/README.md)：\n{a["seconds"]:.3f}秒/0GPU，版本固定/覆盖/null/失败事务与展开预算通过，\n20来源反例通过；构建8.686秒零警告，首轮测试语法失败保留。\n继续真实会话/权限/取消/前缀截断接线，尚无Prompt业务资格；\n默认rev356及PR #52交付不变，全部master保持active。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);head,body=p.read_text().split('\n',1);p.write_text(head+'\n\n## Prompt设置事务34项CPU通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：会话默认值不能掩盖模板，查库失败不能破坏已有设置；\n展开预算需要在构造时限制。私有header历史原SHA已复核恢复。\n\n下一步：会话有界解析和实际执行，前缀计量与历史截断；继续\nPR #52最终检查与全部master。\n'+body)
p=R/'docs/SERVE_REALTIME_PROMPT_2026-11-20.md';detach(p);s=p.read_text();s=s.replace('## 已核实的依据','设置组件另通过[34项CPU](evidence/serve-realtime-prompt-settings-cpu-20261120/README.md)：\n默认/模板/显式覆盖、固定版本与单轮选择、失败事务和展开资源预算\n已具备；实际会话和执行仍待接线。\n\n## 已核实的依据',1);p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['realtime_progress']['prompt_settings_20261120']=a|dict(evidence='evidence/serve-realtime-prompt-settings-cpu-20261120/README.md',next='Connect actual session ownership, bounded lookup/cancel, execution and prefix-safe truncation.');save(p,g)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [Realtime Prompt设置CPU](evidence/serve-realtime-prompt-settings-cpu-20261120/README.md)：覆盖与不可变选择事务；实际会话继续。\n')
b=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';assert sha(b)==result['binary_sha256'];os.link(b,W/'settings-cpu-01/qualified-contracts')
print(json.dumps(a))

from pathlib import Path
import json,hashlib,re,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from tools.serve_audit.check_inventory import current_surface,check
files=['include/q4t/server/prompt_registry.h','src/server/prompt_internal.h','src/server/prompt_registry.cpp','src/server/prompt_template.cpp','include/q4t/server/realtime_prompt_settings.h','src/server/realtime_prompt_settings.cpp','tests/server_realtime_prompt_settings_test.cpp','tests/server_prompt_registry_test.cpp','CMakeLists.txt','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake']
p=R/'tools/serve_audit/inventory.json';v=json.loads(p.read_text());a=current_surface(R)
changed={n:h for n,h in a['sources_sha256'].items() if v['sources_sha256'].get(n)!=h};assert set(changed)<=set(files),set(changed)-set(files)
v['sources_sha256'].update(changed);assert not check(v,a),check(v,a);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
tests=[n for f in files if f.startswith('tests/') for n in re.findall(r'Q4T_TEST\(\s*(\w+)\s*\)',(R/f).read_text())];assert len(tests)==34 and len(set(tests))==34
plan=dict(scope='Prompt session precedence and immutable per-response selection; real registry object worker, expansion budget, prior registry regression. Runtime session/planner integration remains pending.',tests=tests,maximum_tests=34,maximum_test_seconds=120,new_gpu_starts=0,maximum_lookup_expansion_bytes=16<<20,maximum_settings_retained_bytes=64<<20,sources={f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files},default_revision=356,default_unchanged=True,source_review_initial_error='Initial allowed-anchor set omitted the two intentionally edited CMake source entries; corrected before tests.')
p=W/'settings-plan-01.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2)+'\n');(W/'settings-required-tests.txt').write_text('\n'.join(tests)+'\n')
intro='Prompt 会话设置组件已编写：服务默认值、模板与显式覆盖分别保存，\n普通更新复用固定版本，单轮 Prompt/null 不改会话，失败不提交；\n展开由调用方限16MiB、保留状态限64MiB。冻结34项针对性CPU/\n120秒/0GPU（注册表24+设置10），随后继续实际会话/取消/上下文\n接线；尚无 Prompt 业务资格，默认rev356保持，PR #52未混入此开发。\n\n'
p=R/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';head,body=p.read_text().split('\n',1);p.write_text(head+'\n\n## Prompt默认/模板/显式覆盖事务与展开预算\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：默认值不能覆盖模板；切模板必须重新组合显式设置而非沿用\n上个模板的默认字段。大变量重复展开在生成期间就受调用方预算约束，\n不能先分配全局192MiB再当作64MiB计划接受。旧Responses默认保持。\n\n私有header编辑时发现仍有硬链接，立即把HEAD原字节恢复到旧inode，\n再分离工作区改动，身份和处置记录保留；没有构建/发布该瞬时版本。\n来源登记首轮漏列已编辑的两个CMake来源，测试前已补审查并记录。\n\n下一步：34项CPU后完成会话有界解析、真实执行和前缀安全截断；\nPR #52继续最终检查，全部master保持active。\n'+body)
print('frozen',len(tests),'tests; updated anchors',sorted(changed))

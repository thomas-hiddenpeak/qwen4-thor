"""Archive the explicitly selected import-contract evidence, never state files."""
import hashlib
import json
import tarfile
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / 'docs/evidence/serve-realtime-mcp-catalog-cpu-20261120'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = read(W / 'catalog-cpu-01/result.json')
build = read(W / 'catalog-build-02/result.json')
assert result['status'] == 'PASS' and result['tests'] == 12
assert build['status'] == 'BUILD_PASS' and build['warnings'] == 0
assert '12 tests, 12 passed, 0 failed, 0 skipped' in (W / 'catalog-cpu-01/stdout.txt').read_text()
assert all(sha(R / p) == h for p, h in result['sources'].items())
assert all(sha(Path(p)) == h for p, h in read(W / 'catalog-build-02/plan.json')['protected'].items())
files = {n: W / n for n in [
    'catalog-plan-initial.json', 'catalog-plan.json', 'catalog-required.txt',
    'build_catalog_01.py', 'build_catalog_02.py', 'archive_catalog_01.py']}
for phase in ['catalog-build-01', 'catalog-build-02']:
    for name in ['plan.json', 'result.json', 'build.log']:
        files[phase + '/' + name] = W / phase / name
for name in ['result.json', 'stdout.txt', 'stderr.txt']:
    files['catalog-cpu-01/' + name] = W / 'catalog-cpu-01' / name
for name in result['sources']:
    files['source/' + name] = R / name
secrets = set()


def collect(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {'api_key', 'gateway_token', 'authorization', 'token'} and isinstance(child, str) and len(child) >= 24:
                secrets.add(child.encode())
            else:
                collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)


D = R / '.q4t-work/serve-realtime-duplex-20261120'
for p in [D / 'service-package-01/clients.json',
          R / 'build/service/engine/client-policy.json',
          R / 'build/service/gateway-policy.json',
          D / 'credential-remediation-01/retained/bundle/engine/client-policy.json']:
    collect(read(p))
for name, path in files.items():
    assert not any(secret in path.read_bytes() for secret in secrets), name
O.mkdir()
rows = {n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}
with tarfile.open(O / 'records.tar.gz', 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(O / 'records.tar.gz', 'r:gz') as archive:
    assert set(archive.getnames()) == set(rows)
    for member in archive:
        data = archive.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == rows[member.name]['sha256']
        assert not any(secret in data for secret in secrets)
save = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
save(O / 'index.json', dict(files=rows, archive_sha256=sha(O / 'records.tar.gz')))
accepted = dict(status='PASS_REALTIME_MCP_NATIVE_CATALOG_CPU', tests=12,
    executions=12, failed=0, skipped=0, seconds=result['seconds'],
    native_http_fixture_cases=4, projection_boundary_cases=8,
    native_tools_called=0, model_requests=0, gpu_starts=0,
    runtime_connected=False, full_realtime_mcp_accepted=False,
    default_revision=396, default_unchanged=True, service_state='STOPPED',
    binary_sha256=result['binary_sha256'], warnings=0,
    initial_incomplete_type_build_failure_preserved=True,
    client_credentials_never_in_public_item=True,
    failed_catalog_never_grants_callables=True,
    cancellation_scope_and_id_preflight_no_io=True,
    in_flight_import_cancel_session_publication_pending=True,
    all_master_tasks_active=True, public_secret_scan_matches=0)
save(O / 'acceptance.json', accepted)
(O / 'README.md').write_text(f'''# Realtime MCP真实目录导入与SDK投影：CPU

2026-11-20。12项通过，{result['seconds']:.3f}秒，0跳过：8项投影/边界，
4项实际本机HTTP MCP夹具。原生worker完成初始化、分页tools/list、
请求凭据和过滤，私有目录保留完整schema/会话，公开投影不含凭据或
私有session。另一客户不能读取该目录，未调用远端业务工具或模型。

成功空目录、远端RPC失败及坏schema分别处理。失败持久目录只保留
空可调用集及安全错误分类；Realtime目录item严格符合SDK，失败由
后续会话事件所有者报告，不能混入Responses额外error字段。取消、
过期、坏ID及无权限路由在准入前拒绝且无网络I/O；这不代替后续进行中
取消和异步事件所有权验收。无效投影保留调用方旧输出，公开私有字段
反例拒绝，工具schema中的普通同名用户数据保持。

首次构建缺少FileExpansionOptions完整声明而失败，已保留记录；补
include后22.877秒构建零警告，随后一次成组完成12项检查。没有更改
Responses执行实现或已有合同，定义事务的18项证据继续复用。

默认rev396、runtime和STOPPED保持，0GPU/0LLM请求。网络夹具通过
不等于模型驱动资料查询通过，Realtime公开请求尚未连接本组件。
下一步连接异步目录、审批/调用和响应所有权，完成实际SDK业务及
恢复后可回退交付，所有master任务继续。

[计划](../../SERVE_REALTIME_MCP_2026-11-20.md)、[结果](acceptance.json)、
[索引](index.json)、[原始记录](records.tar.gz)。
''')
print(json.dumps(accepted))

"""One strict lease, three missing facts, existing production budgets unchanged."""
import argparse,copy,json,os,runpy,signal,subprocess,sys,time,traceback,uuid
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(R))
CASES=['root_forward','root_wait_outer','root_wait_candidate']
LIMITS={'starts':4,'chats':8,'probes':0,'seconds':225}
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def prepare():
 from tools.serve_recovery import bundle,version_contract
 from tools.serve_service import package as p
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
 old=read(W/'business-01/plan.json');second=read(W/'business-02/execution/result.json');roots=read(W/'wait-roots.json')
 assert second['status']=='FAILED' and second['cleanup_failure'] is None
 assert second['budget']['counts']==dict(starts=5,chats=10,probes=1,controls=2364)
 group=W/'business-03';group.mkdir(mode=0o700)
 names=set(old['sources'])|set(subprocess.check_output(['git','ls-files','tools/serve_recovery','tools/serve_host','src/service'],cwd=R,text=True).splitlines())
 names|={str(Path(__file__).resolve().relative_to(R)),str((W/'root_remaining_cases.py').relative_to(R))}
 sources={n:p.sha(R/n) for n in sorted(names)}
 receipt_root=R/'.q4t-work/serve-chat-cache-20261116/retained-business-01'
 acceptance={k:dict(path=str(receipt_root/n),sha256=p.sha(receipt_root/n)) for k,n in [('release','service-release.json'),('decision','decision.json')]}
 fallback=old['registrations']['retained']['payloads']['fallback']['descriptor']
 limits=runpy.run_path(str(W/'root_remaining_cases.py'))['CASE_LIMITS'];plans=[]
 prior=[W/'business-01/execution/result.json',W/'business-02/execution/result.json',W/'business-01/execution/stopped-2.json',W/'business-01/lease/exit.json',W/'business-02/lease/exit.json']
 for case in CASES:
  out=group/case;out.mkdir(mode=0o700)
  selected=old['roots']['candidate'] if case=='root_forward' else roots['retained' if case=='root_wait_outer' else 'candidate']
  if case=='root_forward':
   case_roots=old['roots'];regs=old['registrations'];scope=W/'business-01/execution/state'
  else:
   case_roots={'candidate':selected};regs={'candidate':version_contract.prepare(selected,selected,fallback,str(uuid.uuid4()),fallback_acceptance=acceptance)};scope=out/'execution/state'
  plan=dict(old,scenario=case,limits=limits[case],package=selected,roots=case_roots,registration=regs['candidate'],registrations=regs,output=str(out),resume_state=str(scope),sources=sources,
    prior_evidence=[dict(path=str(q),sha256=p.sha(q)) for q in prior],
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    prior_seconds=0,planned=dict(starts=limits[case]['starts'],chats=limits[case]['chats'],probes=0),
    state_before=({n:p.sha(scope/n) for n in ('ledger.json','service.json','outer-recovery/policy.json','version-selection/policy.json')} if case=='root_forward' else {}),
    sequence=[case],old_continuous_scenario_passed=False,evidence_composition=True)
  helper=out/'counted-cuda-probe'
  helper.write_text('#!'+sys.executable+'\nimport runpy,sys\nsys.argv='+repr([str(W/'root_remaining_cases.py'),'probe','--plan',str(out/'plan.json')])+'\nrunpy.run_path(sys.argv[0],run_name="__main__")\n');helper.chmod(0o500)
  plan['probe_wrapper']=dict(path=str(helper),sha256=p.sha(helper));save(out/'plan.json',plan);plans.append(str(out/'plan.json'))
 prior_seconds=sum(read(W/(n+'.json'))['seconds'] for n in ('gpu-business-01','gpu-business-02'))
 assert prior_seconds+LIMITS['seconds']<900
 group_plan=dict(plans=plans,limits=LIMITS,prior_counts=second['budget']['counts'],prior_seconds=prior_seconds,
   original_failures_preserved=True,automatic_tool_replay=False,all_master_complete=False,
   sources=sources,source_commit=plan['source_commit'])
 save(group/'plan.json',group_plan);print(json.dumps({'group':str(group/'plan.json'),'limits':LIMITS,'prior_seconds':prior_seconds}))
def review(results):
 if len(results)!=3:raise ValueError('missing actual case')
 totals=dict(starts=0,chats=0,probes=0)
 for case,r in zip(CASES,results):
  if r.get('scenario')!=case or r.get('status')!='PASS_BOUNDED_ROOT_ROLLBACK_BUSINESS' or r.get('failure') is not None or r.get('cleanup_failure') is not None:raise ValueError('case not accepted')
  expected=(1,2,0) if case!='root_wait_outer' else (2,4,0)
  for (k,n) in zip(totals,expected):
   v=r['budget']['counts'][k]
   if type(v) is not int or v!=n:raise ValueError('case dispatch differs')
   totals[k]+=v
 if any(totals[k]!=LIMITS[k] for k in totals):raise ValueError('group exceeded frozen work')
 return totals
def run(path):
 plan=read(path);root=Path(path).parent;started=time.monotonic();process=None;failure=None;results=[]
 def stop(*_):raise TimeoutError('bounded remaining group deadline')
 alarm=signal.signal(signal.SIGALRM,stop);term=signal.signal(signal.SIGTERM,stop);signal.setitimer(signal.ITIMER_REAL,213)
 try:
  if plan['limits']!=LIMITS:raise ValueError('group limits changed')
  for entry in plan['plans']:
   case=read(entry)['scenario']
   with (root/(case+'.log')).open('xb') as log:
    process=subprocess.Popen([sys.executable,'-B',str(W/'root_remaining_cases.py'),'run','--plan',entry],stdout=log,stderr=log,pass_fds=(int(os.environ['Q4T_MANAGED_LEASE_FD']),))
    if process.wait()!=0:raise RuntimeError('actual case failed: '+case)
   results.append(read(Path(entry).parent/'execution/result.json'));process=None
  totals=review(results)
 except BaseException:failure=traceback.format_exc()
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  if process is not None and process.poll() is None:
   process.send_signal(signal.SIGTERM)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:failure=(failure or '')+'\nchild cleanup did not finish within remaining bound'
  signal.signal(signal.SIGALRM,alarm);signal.signal(signal.SIGTERM,term)
  save(root/'result.json',dict(status='PASS_BOUNDED_REMAINING_ROOT_CASES' if failure is None else 'FAILED',failure=failure,seconds=time.monotonic()-started,results=results,
      group_counts=review(results) if failure is None else None,default_replaced=False,original_continuous_scenario_passed=False))
 return int(failure is not None)
if __name__=='__main__':
 os.umask(0o077);a=argparse.ArgumentParser();a.add_argument('mode',choices=['prepare','run']);a.add_argument('--plan',type=Path);args=a.parse_args()
 if args.mode=='prepare':prepare()
 else:raise SystemExit(run(args.plan))

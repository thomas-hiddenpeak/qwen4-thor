import copy,runpy,unittest
from pathlib import Path
W=Path(__file__).resolve().parent;m=runpy.run_path(str(W/'root_remaining_group.py'))
class AggregateTests(unittest.TestCase):
 def valid(self):return [dict(scenario=c,status='PASS_BOUNDED_ROOT_ROLLBACK_BUSINESS',failure=None,cleanup_failure=None,budget=dict(counts=dict(starts=n,chats=n*2,probes=0))) for c,n in zip(m['CASES'],(1,2,1))]
 def test_case_counts_aggregate_without_refunding_original_work(self):
  self.assertEqual(m['review'](self.valid()),dict(starts=4,chats=8,probes=0))
  for key in ('starts','chats','probes'):
   v=self.valid();v[1]['budget']['counts'][key]+=1
   with self.assertRaises(ValueError):m['review'](v)
 def test_partial_wrong_case_or_failed_cleanup_cannot_be_accepted(self):
  for v in [self.valid()[:-1],self.valid()[::-1]]:
   with self.assertRaises(ValueError):m['review'](v)
  for field,wrong in [('status','FAILED'),('failure','failure'),('cleanup_failure','failure')]:
   v=self.valid();v[1][field]=wrong
   with self.assertRaises(ValueError):m['review'](v)
if __name__=='__main__':unittest.main()

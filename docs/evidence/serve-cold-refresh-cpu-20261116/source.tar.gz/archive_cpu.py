import hashlib,json,shutil,tarfile
from pathlib import Path
r=Path(__file__).resolve().parents[2];w=Path(__file__).resolve().parent;o=r/'docs/evidence/serve-cold-refresh-cpu-20261116';o.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for stem in ('package-cpu-01','package-cpu-02','source-gate-01'):
 for ext in ('json','stdout','stderr'):shutil.copyfile(w/(stem+'.'+ext),o/(stem+'.'+ext))
for n in ('host-observation-01.json','device-holders-01.stdout','device-holders-01.stderr','test_cold_package_before_assertion_fix.py'):
 shutil.copyfile(w/n,o/n)
names=['tools/serve_recovery/cold_acceptance.py','tools/serve_recovery/test_cold_package.py','.github/workflows/host-checks.yml','docs/SERVE_COLD_REFRESH_2026-11-16.md']
with tarfile.open(o/'source.tar.gz','w:gz') as t:
 for n in names:t.add(r/n,arcname=n,recursive=False)
 t.add(w/'archive_cpu.py',arcname='archive_cpu.py',recursive=False)
 t.add(w/'run.py',arcname='run.py',recursive=False)
a=json.loads((w/'package-cpu-01.json').read_text());b=json.loads((w/'package-cpu-02.json').read_text());assert a['exit_code']==1 and b['exit_code']==0 and a['default_unchanged'] and b['default_unchanged']
d=dict(status='ACCEPT_TARGETED_COLD_PACKAGE_CPU',unique_tests=5,initial_passed=2,repaired_assertion_tests=3,executions=8,seconds=a['seconds']+b['seconds'],original_failure_preserved=True,source_gate=json.loads((w/'source-gate-01.stdout').read_text()),sources={n:sha(r/n) for n in names},archive_sha256=sha(o/'source.tar.gz'),gpu_starts=0,default_unchanged=True,actual_package_preflight_pending=True,host_observation='BUSY',foreign_services_modified=False,master_active=True)
(o/'acceptance.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(o/'README.md').write_text('''# 当前精确包冷启动准备：CPU接受

5项不同CPU闭合，8次调用；首次2项通过，3项因测试错误断言ValueError
失败，实际生产校验正确抛RuntimeError。仅修断言后重验这3项，全过；
原源码/输出保留。来源720锚点/7负控通过，0模型/0探测，默认rev182保持。

准备器不再引用过时构建和旧证据路径，直接校验精确sealed包、所有
控制/native来源及四原生程序的三方身份，不能混入构建目录产物。
业务仍需实际包prepare/管理员只读check及原冻结真实短验。

独立宿主只读观察BUSY：nvargus-daemon与jtop持有GPU设备句柄。没有
安装设备围栏、停止服务、运行NVML或启动模型。此观察不是独占授权，
也不是冷启动业务通过；在明确维护交接前继续不依赖该条件的总任务。
''')
p=r/'docs/STATUS.md';s=p.read_text();h='## 最近完成的实现和验证\n\n';s=s.replace(h,h+'''[R07当前包CPU接受](evidence/serve-cold-refresh-cpu-20261116/README.md)：
5项不同用例通过，原3项异常类型断言错误保留，仅重验受影响项。
宿主只读观察BUSY：nvargus-daemon/jtop持设备句柄；未安装围栏或
干预其他服务，0GPU。继续精确包准备/只读核验及其他独立master任务。

''',1);p.write_text(s)
p=r/'docs/log/2026-11-16.md';s=p.read_text();h='# 开发日志（2026-11-16）\n\n';p.write_text(h+'''## R07当前包身份CPU验证通过

- 日期：2026-11-16。5项不同CPU闭合，8次调用；首次2通过，3项错误
  异常类型断言定点修复再过，原失败保留。720来源锚点/7负控通过。
- 为什么：复用当前封包必须拒绝过时/缺失来源及构建回执/程序漂移。
- 宿主只读观察BUSY，nvargus-daemon/jtop持GPU句柄；未安装围栏或
  干预进程，0GPU/默认保持。不能把观察或CPU当真实冷启动通过。
- 下一步：精确包prepare/管理员只读check，维护条件未满足时继续
  其他独立协议/媒体工作，全部master持续。
- 证据：[CPU接受](../evidence/serve-cold-refresh-cpu-20261116/README.md)。

'''+s[len(h):])
p=r/'docs/serve-master-goals-v2.json';d=json.loads(p.read_text())
for t in d['tasks']:
 if t['id']=='R07':t['cold_refresh_20261116'].update(state='targeted_cpu_accepted_preflight_pending',evidence='evidence/serve-cold-refresh-cpu-20261116/README.md',host_observation='BUSY',actual_cold_business_accepted=False)
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('CPU archive complete; cold business remains pending')

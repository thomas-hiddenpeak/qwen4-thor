from pathlib import Path
import copy,hashlib,json,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'input-review-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
old=R/'.q4t-work/serve-realtime-prompt-20261120/answer-input-review-01'
source=(old/'probe.cpp').read_text()
source=source.replace('ChatRequestPlan executed;','auto native = planned.generation.chat;\n      native.audio_output = planned.speech.chat;\n      const auto native_prompt = Render(planned.generation.generation_request, native);\n      ChatRequestPlan executed;')
source=source.replace('{"measured_prompt", String(', '{"native_prompt", String(native_prompt)},\n          {"measured_prompt", String(')
(O/'probe.cpp').write_text(source)
value=json.loads((W/'business-01/run/main.sdk.json').read_text());settings={};history=[];cases=[]
response_templates={
 'tool_audio':dict(output_modalities=['audio'],max_output_tokens=3457,tools=[],tool_choice='none',instructions='Reply only with the exact version field in the actual tool result.'),
 'pcm':dict(output_modalities=['audio'],max_output_tokens=3457,tools=[],tool_choice='none',audio=dict(output=dict(format=dict(type='audio/pcm',rate=24000))),instructions='Ignore earlier questions. Repeat exactly without adding words: Hello, this is a native speech test.')}
for e in value['events']:
 if e['type'] in ['session.created','session.updated']:settings=e['session']
 if e['type']=='conversation.item.done':history.append(e['item'])
 if e['type']=='response.created':
  label=e['response']['metadata']['acceptance_case']
  if label not in response_templates:continue
  request=response_templates[label]
  for mode in ['audio','text','new_user']:
   row=dict(label=label+'-'+mode,settings=copy.deepcopy(settings),response=copy.deepcopy(request),items=copy.deepcopy(history))
   if mode=='text':row['response']['output_modalities']=['text'];row['response'].pop('audio',None)
   if mode=='new_user':
    task=('What is the version in the preceding tool result? Reply only with the version.' if label=='tool_audio' else 'Repeat exactly without adding words: Hello, this is a native speech test.')
    row['items'].append(dict(type='message',role='user',content=[dict(type='input_text',text=task)]))
   cases.append(row)
assert len(cases)==6
save(O/'inputs.json',cases)
command=json.loads((old/'plan.json').read_text())['command']
command=[str(O/'probe.cpp') if a==str(old/'probe.cpp') else str(O/'probe') if a==str(old/'probe') else a for a in command]
prefix=R/'.q4t-work/serve-file-search-20261112/host/CMakeFiles/q4t_host_tests.dir/home/rm01/models/dev/qwen4-thor/src/server'
for name in ['realtime_speech_encoder','realtime_speech_history','realtime_speech_execution']:
 path=prefix/(name+'.cpp.o');assert path.exists();command.insert(command.index('-L/usr/lib/gcc/aarch64-linux-gnu/13'),str(path))
tokenizer=Path.home()/'models/dev/llm/garnermccloud/Qwen3.8-Flash-Next-NVFP4-SSD-Stream/tokenizer.json'
save(O/'plan.json',dict(scope='Six offline reconstructions from actual first two failed answers: compare text/audio/native prompt bytes and actual tokenizer lengths; explicit new-user counterexamples. No GPU or new answer.',maximum_cases=6,maximum_seconds=120,gpu_starts=0,command=command,sources={p:sha(Path(p)) for p in command if p.endswith(('.o','.a','.cpp'))},sdk_receipt_sha256=sha(W/'business-01/run/main.sdk.json'),inputs_sha256=sha(O/'inputs.json'),tokenizer_sha256=sha(tokenizer)))
start=time.monotonic()
with (O/'build.log').open('w') as log:code=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
save(O/'build-result.json',dict(exit_code=code,seconds=time.monotonic()-start,warnings=(O/'build.log').read_text().count('warning:')));assert code==0
with (O/'inputs.json').open() as src,(O/'observed.json').open('w') as out,(O/'stderr').open('w') as err:
 run=subprocess.run([str(O/'probe'),str(tokenizer)],cwd=R,stdin=src,stdout=out,stderr=err,timeout=120)
assert run.returncode==0
observed=json.loads((O/'observed.json').read_text());pairs=[]
for i in [0,3]:
 a,b,c=observed[i:i+3]
 assert a['generation_request']==b['generation_request']
 assert a['measured_prompt']==a['executed_prompt']==a['native_prompt']==b['measured_prompt']==b['native_prompt']
 assert c['measured_prompt']==c['native_prompt'] and c['measured_prompt']!=a['measured_prompt']
 assert c['generation_request']['messages'][-1]['role']=='user'
 pairs.append(dict(label=a['label'],audio_text_identical=True,native_text_identical=True,actual_tokens=a['tokens'],new_user_tokens=c['tokens'],last_actual_role=a['generation_request']['messages'][-1]['role'],prompt_sha256=hashlib.sha256(a['measured_prompt'].encode()).hexdigest(),temperature=a['temperature'],seed_set=a['seed_set']))
result=dict(status='PASS_OFFLINE_INPUT_IDENTITY',cases=6,gpu_starts=0,observations=pairs,original_quality_unchanged=True)
save(O/'result.json',result);print(json.dumps(result))

from pathlib import Path
import ast,hashlib,json,os,subprocess,time,traceback
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'content-cpu-01';assert not O.exists();O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
names=['tools/serve_realtime/speech_followup.py','tools/serve_realtime/test_speech_followup.py','tools/serve_realtime/speech_sdk.mjs']
for n in names:
 if n.endswith('.py'):ast.parse((R/n).read_text())
commands=[['python3','-B','-m','unittest','tools.serve_realtime.test_speech_followup','-v'],['node','--check','tools/serve_realtime/speech_sdk.mjs']]
plan=dict(scope='Six new negative checks for real new-user turns, immutable failed prompts and fixed-seed comparison; one JS syntax check. Reuse unchanged 17 verifier/20 source cases and original successful waveform/quota/cancel business. No GPU.',seconds=120,gpu_starts=0,sources={n:sha(R/n) for n in names},commands=commands,next_gpu=dict(starts=1,response_creates=5,websocket_sessions=1,completions=2,transcriptions=3,seconds=600));save(O/'plan.json',plan)
start=time.monotonic();runs=[]
try:
 for i,cmd in enumerate(commands):
  with (O/f'{i}.stdout').open('w') as out,(O/f'{i}.stderr').open('w') as err:
   run=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=120-(time.monotonic()-start),env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O/'fixtures')))
  runs.append(dict(command=cmd,exit_code=run.returncode));assert run.returncode==0,cmd
 assert 'Ran 6 tests' in (O/'0.stderr').read_text()
 result=dict(status='PASS',tests=6,seconds=time.monotonic()-start,commands=runs,gpu_starts=0,original_quality_failure_preserved=True)
except BaseException:
 result=dict(status='FAILED',seconds=time.monotonic()-start,commands=runs,error=traceback.format_exc(),gpu_starts=0);save(O/'result.json',result);raise
save(O/'result.json',result);print(json.dumps(result))

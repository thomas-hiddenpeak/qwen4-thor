from pathlib import Path
import json,hashlib
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-generation-diagnostic-01';O.mkdir(exist_ok=False)
source=R/'tools/native_tts/model_reference.py';s=source.read_text();s=s[:s.index('    plan = json.loads(args.plan.read_text())')]
s+=r'''
    plan = json.loads(args.plan.read_text())
    assert plan['limits']['frames'] == 47 and len(plan['cases']) == 1
    args.output.mkdir(parents=True,exist_ok=False)
    item=plan['cases'][0];native=args.native/'case-0'
    codes=np.fromfile(native/'codes.i32','<i4').reshape(47,16)
    assert ((codes>=0)&(codes<2048)).all()
    comparisons=[];forwards=dict(talker=0,predictor=0);captured={}
    class Captured(Exception):pass
    def capture(**kwargs):
        captured.update(kwargs);raise Captured()
    def tokens(value):return torch.tensor([tokenizer.encode(value,add_special_tokens=False)])
    def compare(name,frame,group,tensor):
        value=tensor.detach().float().contiguous().numpy().reshape(-1).astype('<f4')
        path=native/f'{name}-{frame}-{group}.f32';a=value.astype(np.float64);b=np.fromfile(path,'<f4').astype(np.float64)
        assert a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all()
        an,bn=np.linalg.norm(a),np.linalg.norm(b);assert an>0 and bn>0
        relative=float(np.linalg.norm(a-b)/an);cosine=float(a@b/an/bn)
        comparisons.append(dict(name=name,frame=frame,group=group,elements=a.size,relative_l2=relative,cosine=cosine,passed=relative<=.0001 and cosine>=.99999999))
        (args.output/path.name).write_bytes(value.tobytes())
    with torch.inference_mode(),mock.patch.object(talker,'generate',capture):
        try:
            holder.generate(input_ids=[tokens('<|im_start|>assistant\n'+item['text']+'<|im_end|>\n<|im_start|>assistant\n')],instruct_ids=[None],languages=[item['language']],speakers=[item['voice']],non_streaming_mode=item['non_streaming'])
        except Captured:pass
        else:raise AssertionError('prompt preparation bypassed')
        prepared=captured['inputs_embeds'];compare('prefill',0,0,prepared)
        text_ids=np.fromfile(native/'text-ids.i32','<i4').astype(np.int64)
        compare('text-projected',0,0,talker.text_projection(talker.get_text_embeddings()(torch.tensor(text_ids))))
        cache=None
        for frame in range(48):
            checkpoint();past=cache.get_seq_length() if cache is not None else 0
            output=talker.model(inputs_embeds=prepared,attention_mask=torch.ones(1,past+prepared.shape[1],dtype=torch.long),use_cache=True,past_key_values=cache)
            cache=output.past_key_values;hidden=output.last_hidden_state[:,-1:];logits=talker.codec_head(hidden);forwards['talker']+=1
            compare('talker-hidden',frame,0,hidden);compare('talker-logits',frame,0,logits)
            if frame==47:break
            known=torch.tensor(codes[frame].astype(np.int64)).reshape(1,16)
            if frame in (0,1,16,32,46):
                predictor_input=torch.cat((hidden,talker.get_input_embeddings()(known[:,:1])),dim=1);predictor_cache=None
                for group in range(1,16):
                    checkpoint()
                    if group==1:output=talker.code_predictor(inputs_embeds=predictor_input,use_cache=True,output_hidden_states=True)
                    else:output=talker.code_predictor(input_ids=known[:,group-1:group],generation_steps=group-1,past_key_values=predictor_cache,use_cache=True,output_hidden_states=True)
                    predictor_cache=output.past_key_values;forwards['predictor']+=1
                    if group in (1,15):
                        compare('predictor-hidden',frame,group,output.hidden_states[-1][:,-1:]);compare('predictor-logits',frame,group,output.logits[:,-1:])
            embeddings=[talker.get_input_embeddings()(known[:,:1])]+[talker.code_predictor.get_input_embeddings()[g-1](known[:,g:g+1]) for g in range(1,16)]
            prepared=torch.cat(embeddings,dim=1).sum(1,keepdim=True)
            trailing=captured['trailing_text_hidden'];prepared=prepared+(trailing[:,frame:frame+1] if frame<trailing.shape[1] else captured['tts_pad_embed'])
    assert forwards==dict(talker=48,predictor=75) and len(comparisons)==118
    assert not torch.cuda.is_initialized()
    result=dict(status='PASS_LONG_TRAJECTORY_COMPUTATION' if all(r['passed'] for r in comparisons) else 'FAILED_LONG_TRAJECTORY_COMPUTATION',comparisons=comparisons,seconds=time.monotonic()-started,cpu_model_loads=1,cuda_initialized=False,forwards=forwards,torch=torch.__version__,transformers=transformers.__version__)
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','seconds','forwards')}),flush=True)
    assert all(r['passed'] for r in comparisons),'actual trajectory arithmetic differs'
if __name__=='__main__':main()
'''
(O/'reference.py').write_text(s)
print(O/'reference.py')

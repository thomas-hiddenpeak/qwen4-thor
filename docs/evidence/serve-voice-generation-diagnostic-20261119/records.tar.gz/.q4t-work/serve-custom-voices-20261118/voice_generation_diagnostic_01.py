from pathlib import Path
import json,os,subprocess,time,sys,shutil,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_service.package import read,save,sha,require
from tools.native_tts.acceptance import defaults
from tools.serve_grammar_reap import acceptance as lifecycle
LIMITS=dict(seconds=900,native_seconds=120,reference_seconds=600,gpu_talker_loads=1,cpu_talker_loads=1,codec_loads=0,asr_loads=0,main_loads=0,http_posts=0,frames=47,reference_talker_forwards=48,reference_predictor_forwards=75,native_advances=6000,comparisons=118,artifact_mib=32,disk_reserve_mib=256)
def main(plan):
 require(plan['limits']==LIMITS,'frozen limits drift');out=Path(plan['output']);out.mkdir(exist_ok=False);start=time.monotonic();result=dict(status='FAILED',steps=[])
 lease=int(os.environ['Q4T_MANAGED_LEASE_FD']);lifecycle.verify_lease(lease,lifecycle.guard.common_lock())
 require(defaults()==plan['defaults'],'default drift')
 for n,h in plan['identities'].items():require(sha(n)==h,'identity drift '+n)
 try:
  for name,args in plan['commands']:
   require(shutil.disk_usage(R).free>=256<<20,'disk reserve')
   env=dict(os.environ,PYTHONPATH=plan['reference_deps'],CUDA_VISIBLE_DEVICES='' if name=='reference' else os.environ.get('CUDA_VISIBLE_DEVICES','0'),PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='8')
   t=time.monotonic()
   with (out/(name+'.log')).open('xb') as f:p=subprocess.run(args,env=env,pass_fds=(lease,),stdout=f,stderr=subprocess.STDOUT,timeout=min(LIMITS[name+'_seconds'],max(1,850-(time.monotonic()-start))))
   result['steps'].append(dict(name=name,command=args,returncode=p.returncode,seconds=time.monotonic()-t));save(out/'progress.json',result);require(p.returncode==0,name+' failed')
  n=read(out/'native/result.json');r=read(out/'reference/result.json')
  require(n['gpu_model_loads']==1 and n['frames']==47 and n['generation_advances']<=6000,'native bounds')
  require(r['status']=='PASS_LONG_TRAJECTORY_COMPUTATION' and len(r['comparisons'])==118 and all(c['passed'] for c in r['comparisons']),'numeric comparison failed')
  result.update(status='PASS_FIXED_TRAJECTORY_COMPUTATION_PENDING_VOICE_QUALITY',comparisons=118,max_relative_l2=max(c['relative_l2'] for c in r['comparisons']),minimum_cosine=min(c['cosine'] for c in r['comparisons']))
  require(sum(p.stat().st_size for p in out.rglob('*') if p.is_file())<=32<<20,'artifact bound')
 except BaseException:result['error']=traceback.format_exc();raise
 finally:
  result.update(seconds=time.monotonic()-start,defaults_unchanged=defaults()==plan['defaults']);save(out/'result.json',result)
 print(json.dumps({k:v for k,v in result.items() if k!='steps'}),flush=True)
if __name__=='__main__':
 with lifecycle.child_subreaper():main(read(Path(sys.argv[1])))

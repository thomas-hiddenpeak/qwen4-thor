from pathlib import Path
import json,hashlib,shutil,subprocess,time
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-generation-diagnostic-build-01';O.mkdir(exist_ok=False);sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
original=V/'voice-eos-diagnostic-build-01/replay.cpp';s=original.read_text();s=s.replace('using namespace q4t;','using namespace q4t;\nfs::path trace_directory;')
s=s.replace('cases->array.size() == 2','cases->array.size() == 1').replace('exactly two TTS cases required','exactly one fixed TTS case required')
a=s.index('  const auto codec_dir = directory / "speech_tokenizer";');b=s.index('  size_t total_advances =',a);s=s[:a]+s[b:];s=s.replace('total_frames = 0, codec_advances = 0','total_frames = 0');s=s.replace('index < 2','index < 1')
s=s.replace('    Require(fs::create_directory(case_output), "case directory exists");','    Require(fs::create_directory(case_output), "case directory exists");\n    trace_directory = case_output;')
s=s.replace('    Check(audio::ValidateTtsPrompt(prompt));','    Check(audio::ValidateTtsPrompt(prompt));\n    Save<int32_t>(case_output / "text-ids.i32", prompt.text_ids);')
s=s.replace('Require(++total_advances <= 60000','Require(++total_advances <= 6000')
a=s.index('    // Diagnosis preserves partial audio');b=s.index('  Cuda(cudaDeviceSynchronize());',a)
s=s[:a]+'''    Require(generation.ended() && codes.size() == 47,
            "fixed prior sample trajectory changed");
    const auto bytes = ReadFile(item.GetString("prior_codes"), 47 * 16 * 4);
    Require(bytes.size() == codes.size_bytes() &&
                !std::memcmp(bytes.data(), codes.data(), bytes.size()),
            "original failed-identity sample codes changed");
    total_frames += codes.size();
  }
'''+s[b:]
s=s.replace('\\"gpu_model_loads\\":2,\\"cases\\":2','\\"gpu_model_loads\\":1,\\"cases\\":1')
s=s.replace('         << ",\\"codec_advances\\":" << codec_advances << ",\\"seconds\\":"','         << ",\\"seconds\\":"')
a=s.index('void TraceTtsOperand(const char*, size_t, size_t, std::span<const float>) {}');b=a+len('void TraceTtsOperand(const char*, size_t, size_t, std::span<const float>) {}')
s=s[:a]+r'''void TraceTtsOperand(const char* name, size_t frame, size_t group,
                     std::span<const float> device_values) {
  const std::string_view kind(name);
  if (kind.starts_with("predictor-") &&
      !((frame == 0 || frame == 1 || frame == 16 || frame == 32 || frame == 46)
        && (group == 1 || group == 15))) return;
  Require(!trace_directory.empty() && frame <= 47 &&
              device_values.size() <= 512 * 2048, "trace budget");
  std::vector<float> host(device_values.size());
  Cuda(cudaMemcpy(host.data(), device_values.data(), device_values.size_bytes(),
                   cudaMemcpyDeviceToHost));
  Save<float>(trace_directory / (std::string(name) + "-" +
      std::to_string(frame) + "-" + std::to_string(group) + ".f32"), host);
}'''+s[b:]
source=O/'replay.cpp';source.write_text(s);prior=json.loads((V/'voice-eos-diagnostic-build-01/plan.json').read_text())
for n,h in prior['runtime_sources'].items():assert sha(R/n)==h,n
objects=[x['path'] for x in prior['reused_objects']]
for x in prior['reused_objects']:assert sha(Path(x['path']))==x['sha256']
cmds=prior['commands'];binary=O/'q4t_voice_generation_diagnostic'
cmds=[[a.replace(str(V/'voice-eos-diagnostic-build-01'),str(O)).replace('q4t_tts_eos_diagnostic',binary.name) for a in cmd] for cmd in cmds]
plan=dict(original_source=str(original),original_sha256=sha(original),derived_sha256=sha(source),runtime_sources=prior['runtime_sources'],objects=prior['reused_objects'],commands=cmds,gpu=0)
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic();results=[]
for i,cmd in enumerate(cmds):
 assert shutil.disk_usage(R).free>256<<20
 with (O/f'{i}.log').open('xb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 results.append(dict(command=cmd,returncode=r.returncode))
 if r.returncode:break
value=dict(status='PASS_BUILD_ONLY' if not r.returncode else 'FAILED',seconds=time.monotonic()-start,steps=results,warnings=sum(p.read_text().count('warning:') for p in O.glob('*.log')))
if not r.returncode:value['binary_sha256']=sha(binary)
(O/'result.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));raise SystemExit(r.returncode)

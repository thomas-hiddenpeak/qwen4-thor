from pathlib import Path
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import version_archive as archive
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;STATE=ROOT/'build/service-native-state'
with archive.locked(STATE) as (state,desc,manifest,current,selected,binding):
 assert current['revision']==234 and current['current']['manifest_sha256']=='6c222213fa40dcf77abc9035e17e3f14c93e1146ff272e810cb2cf26ff5b252d'
 records=archive.entries(state,binding,selected)
 assert len(records)==16
 keep=archive.protected(state,desc,current,selected,records)
 chosen=[]
 for cycle,(path,value) in sorted(records.items(),key=lambda pair:pair[1][1]['candidate']['revision']):
  if cycle in keep:continue
  try:archive.unreferenced(state,current,path)
  except ValueError:continue
  chosen.append(cycle)
  if len(chosen)==2:break
 assert len(chosen)==2
plan=archive.prepare(STATE,W/'version-archive-01',chosen)
p.save(W/'version-archive-prepared.json',plan)
receipt=archive.apply(plan['plan'],plan['sha256'])
p.save(W/'version-archive-applied.json',receipt)
assert len(list((STATE/'version-registrations').glob('*.json')))==14
print({'status':'ARCHIVED_TWO_RETIRED_REGISTRATIONS','selected':chosen,'new_gpu_starts':0,'packages_deleted':False})

"""Archive actual reversible web publication and reconcile current documentation."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-01'
O=R/'docs/evidence/serve-video-affine-delivery-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');assert v['status']=='PASS_NATIVE_VIDEO_AFFINE_DETAIL_DELIVERED' and v['publication']['revision']==244
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands']) and v['state']=='STOPPED' and v['new_gpu_starts']==0
c=v['publication']['current'];composition=read(W/'publication-composition.json')
assert c['manifest_sha256']==composition['candidate']['manifest_sha256'] and sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
files=[(p,'delivery-01/'+p.name) for p in D.iterdir() if p.is_file() and not p.is_symlink()]
for pattern in ('delivery-prepare-*.*','delivery-run-*.*','publication-archive-*.*','version-archive-*.*'):
 files.extend((p,p.name) for p in W.glob(pattern) if p.is_file())
for n in ['archive_delivery.py','deliver.py','run_delivery.py','archive_generations.py','archive_versions.py','prepare_package.py','publication-composition.json','package-01/prepare-review.json']:
 files.append((W/n,n))
files=sorted({n:p for p,n in files}.items());secrets=[]
def collect(value):
 if isinstance(value,dict):
  for key,x in value.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(value,list):
  for x in value:collect(x)
for p in (R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json'):collect(read(p))
for n,p in files:assert not any(x in p.read_bytes() for x in secrets),n
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
a=dict(status='ACCEPT_NATIVE_VIDEO_AFFINE_DETAIL_DELIVERY',revision=244,current=c,commands=len(v['commands']),seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],candidate_whole_package_gpu_run=False,composed_change='Exact-engine affine video/high-detail, primary/light and retained controls; controller/client/native helpers unchanged; explicit extension preserves budgets and forbids capability loss; STOPPED publication and actual root rollback verified',older_engine_fallback=False,prior_rev234_preserved=True,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生仿射与视频细节默认交付 rev244

实际包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`；引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU，outer保持enabled且累计启动0次。

合法仿射显示、v4冻结重放及显式视频detail=high实际可用；每帧
65536像素下限与准入/处理/缓存/历史一致，预算不足拒绝而非静默
降级。auto/low保留checkpoint参考处理。实际JSON/SSE、主轻及
保留控制包见[发行组合](../serve-video-affine-composition-20261117/README.md)。
含原失败累计7启动24请求（含自检及embedding）、323.503秒严格
租约、308项NVML正常，完整清理。原默认小尺寸和含答案Chat题
质量失败单列；新模式/中性题通过不追认旧题，也不声明根因解决。

core/client/outer预算字节保持；profile仅扩展已验视频合同，原历史、
pending、selected、deadline和周期保持。实际回退恢复各根原周期，
只递增revision。人工保留根`{a['manual_root']}`和
自动旧控制payload`{a['automatic_payload']}`均使用
当前引擎；未声称独立旧引擎回退。控制器/native helper/client未变。

退休generation及登记各两份可恢复归档，0删除，原234包和day入口
保留。继续刷新用户day独立交接、PR41实际合main及全部master。
一般透视、多轨、其余格式和后端仍需实际实现，阶段不是总终点。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev244；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；原生outer/周期及仿射视频/细节能力完整，前驱234另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退'}
for label,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(label)+r' \| .* \|$',lambda _:f'| {label} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev244仿射与视频细节交付](evidence/serve-video-affine-delivery-20261117/README.md)
完成19项STOPPED发布、实际整根回退与再前进，{v['seconds']:.3f}秒、0新增
GPU。原预算和周期保持，控制器/native helper/client不变；真实视频、
主轻及保留组合已验，原质量失败不追认，原234包及长稳计划保留。
继续刷新用户day独立交接、PR41实际合main及全部master。

'''
s=s.replace('[rev234原生网页交付]',intro+'前驱[rev234原生网页交付]',1)
s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro,1)
p.write_text(s)
p=R/'docs/log/2026-11-17.md';h,t=p.read_text().split('\n',1);p.write_text(h+f'''

## rev244仿射视频与显式细节可回退交付

2026-11-17：19项STOPPED升级/整根回退/再前进通过，{v['seconds']:.3f}秒，
0新增GPU。core/client/outer预算字节与各根原周期保持，profile仅
增加已验能力；旧包/长稳入口及失败原件保留。为什么：功能必须
进入可用发行，回退不能丢失能力或返还预算。退休副本/登记各两份
可恢复归档，无删除。下一步独立day交接、PR41真实合并及全部
master任务；未关闭透视/多轨/其余后端或模型质量问题。
'''+t)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 if 'video_affine_detail_20261117' in task:
  task['video_affine_detail_20261117'].update(state='delivered_main_pending',revision=244,manifest_sha256=c['manifest_sha256'],delivery_evidence='evidence/serve-video-affine-delivery-20261117/README.md')
 if task['id']=='Q02':
  task['latest_release']=a|dict(evidence='evidence/serve-video-affine-delivery-20261117/README.md')
  task['remaining_required']=['PR41 final-head checks and actual main merge','Delivery of every remaining implementation']
 if task['id']=='A01':task['remaining_required']=[x for x in task['remaining_required'] if x!='Actual main integration of native web field delivery']
 if task['id']=='A05':task['remaining_required']=[]
 if task['id']=='A11':task['remaining_required']=[x.replace('Native web rev234 actual main integration and required broader web-provider coverage','Required broader native web-provider coverage; configured-site implementation merged in PR40') for x in task['remaining_required']]
 if task['id']=='A10':
  task['remaining_required']=['Non-unit homogeneous/perspective video transforms, multiple tracks and remaining format combinations','Audio/Realtime/image-generation/video-generation model assets and actual backend execution','Recorded model quality failures remain unresolved; never relabelled by other input/mode successes']
  for finding in task['findings'][:2]:
   finding.update(state='resolved_delivered_main_merged',resolution='Actual media fingerprint, multimodal state/chunk continuation and private restore delivered rev214, merged PR38; original failures retained.',evidence='evidence/serve-media-state-cache-delivery-20261117/README.md')
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev244 or then-current default; do not stop camera/jtop without pending maintenance handoff.'
j['next_task']='Q02';j['next']='Freeze rev244 native day handoff, complete PR41 final-head checks and actual main merge; continue every remaining master task.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev244仿射与视频细节交付](evidence/serve-video-affine-delivery-20261117/README.md)：原生像素变换、显式细节和实际保留包业务，可回退发布。\n')
p=R/'README.md';s=p.read_text().replace('JSON/SSE与恢复后的冻结视频验收。任意仿射等其余格式继续实现。','JSON/SSE与恢复后的冻结视频验收。rev244补齐有界缩放、斜切及非直角\n旋转和v4冻结历史。视频文件或帧入口可显式选择`detail=high`，每帧\n至少65536像素，预算不足拒绝；auto/low保持原参考数值。原小尺寸\n默认模式的质量失败仍保留，不能保证所有视频都能正确回答。\n[本次交付](docs/evidence/serve-video-affine-delivery-20261117/README.md)\n覆盖真实JSON/SSE、主轻及保留控制组合；一般透视、多轨和其余格式继续实现。')
s=s.replace('正交旋转/镜像与像素比例已校正，真实显示宽高随来源传递；其余\n  格式和缓存组合继续补齐，硬解码和视觉并发未扩展。','正交旋转/镜像、像素比例及有界仿射已校正，显式视频high细节可用；\n  图像/视频私有缓存已交付，其余格式/后端继续补齐，硬解码和视觉并发未扩展。')
s=s.replace('[当前交付与回退](docs/evidence/serve-video-geometry-delivery-20261116/README.md)','[当前交付与回退](docs/evidence/serve-video-affine-delivery-20261117/README.md)');p.write_text(s)
p=R/'docs/SERVE_VIDEO_AFFINE_2026-11-17.md';p.write_text(p.read_text()+f'''
## 实际默认交付

rev244完成19项STOPPED升级、实际整根回退和再前进，{v['seconds']:.3f}秒、
0新增GPU；预算/周期保持，原234及长稳入口保留。原质量失败不
追认。见[交付记录](evidence/serve-video-affine-delivery-20261117/README.md)。
继续独立day交接、PR41实际合main及全部master。
''')
print(json.dumps(dict(revision=244,files=len(files),seconds=v['seconds'],secret_scan_matches=0)))

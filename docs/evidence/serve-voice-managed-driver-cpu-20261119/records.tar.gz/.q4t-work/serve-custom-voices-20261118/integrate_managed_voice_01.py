from pathlib import Path
R=Path.cwd()
def edit(name,changes):
 p=R/name;s=p.read_text()
 for old,new in changes:
  assert s.count(old)==1,(name,old[:75],s.count(old));s=s.replace(old,new,1)
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
edit('tools/native_tts/managed_voice.py',[("        config=json_response(out,prefix+'-config')","        require(read(out/(prefix+'-config-http.json'))['http_status']==200,\n                'managed voice configuration unavailable')\n        config=read(out/(prefix+'-config.wire'))")])
edit('tools/native_asr/service_acceptance.py',[
("def limits_for(scenario, chat_audio=False, native_tts=False, retained_tts=False):\n    require(all(type(v) is bool for v in (chat_audio, native_tts, retained_tts)),", "def limits_for(scenario, chat_audio=False, native_tts=False, retained_tts=False,\n               native_voice=False):\n    require(all(type(v) is bool for v in (chat_audio, native_tts, retained_tts, native_voice)),"),
("    limits = dict(LIMITS[scenario])\n    if retained_tts:","    limits = dict(LIMITS[scenario])\n    if native_voice:\n        require(scenario != 'tls_remaining' and not retained_tts,\n                'registered voice needs its complete recovery phases')\n        limits['chats'] += 8 if scenario == 'tool_retained' else 12\n    if retained_tts:"),
("                          plan.get('reused_tls', {}).get('tts_complete', False))", "                          plan.get('reused_tls', {}).get('tts_complete', False),\n                          plan.get('native_voice') is not None)"),
("    profile_contract.tts_capability_binding(native_tts, qualified['capabilities'])", "    native_voice = manifest['recovery_profiles']['identity'].get('native_tts_base')\n    profile_contract.tts_capability_binding(native_tts, qualified['capabilities'],\n        native_voice, manifest['recovery_profiles']['identity'].get('native_asr'))"),
("        args.retained is not None)\n    names =", "        args.retained is not None, native_voice is not None)\n    names ="),
("    if chat_audio: plan['chat_audio'] = True", "    if chat_audio: plan['chat_audio'] = True\n    if native_voice is not None:\n        from tools.serve_recovery import profile_voice\n        fixture = getattr(args, 'voice_fixtures', None)\n        require(fixture is not None, 'managed registered voice needs fixed recordings')\n        fixture = fixture.resolve(strict=True)\n        plan['native_voice'] = native_voice\n        plan['voice_clips'] = profile_voice.fixtures(fixture)\n        plan['sources'][str(fixture)] = engine.sha(fixture)\n        for row in plan['voice_clips'].values():plan['sources'][row['path']] = row['sha256']"),
("    continuity = read('core-continuity.json')", "    from tools.native_tts import managed_voice\n    results.update(managed_voice.check(out, plan,\n                                       expected['settings'].get('native_tts_base')))\n    continuity = read('core-continuity.json')"),
("    def exercise(self):\n        from tools.native_tts import managed_service", "    def exercise(self):\n        from tools.native_tts import managed_service, managed_voice\n        voice = managed_voice.Actor(self) if self.plan.get('native_voice') is not None else None"),
("                managed_service.observe(self, 'tls-before')", "                if voice:voice.observe('tls-before')\n                managed_service.observe(self, 'tls-before')"),
("                managed_service.observe(self, 'tls-after')", "                if voice:voice.observe('tls-after')\n                managed_service.observe(self, 'tls-after')"),
("            managed_service.observe(self, 'primary')", "            if voice:voice.observe('primary')\n            managed_service.observe(self, 'primary')"),
("            managed_service.observe(self, 'fallback')", "            if voice:voice.observe('fallback')\n            managed_service.observe(self, 'fallback')"),
("        self.request('core-after', self.plan['requests']['chat'], path='/v1/chat/completions',", "        if voice:voice.finish()\n        self.request('core-after', self.plan['requests']['chat'], path='/v1/chat/completions',"),
("               PREPARE_PATH_ARGUMENTS=('separator-audio',),", "               PREPARE_PATH_ARGUMENTS=('separator-audio', 'voice-fixtures'),")])
print('integrated voice actor into existing owned managed lifecycle, no model action')

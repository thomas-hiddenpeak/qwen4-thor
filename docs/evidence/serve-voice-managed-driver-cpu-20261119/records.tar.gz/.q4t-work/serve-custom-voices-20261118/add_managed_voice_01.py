from pathlib import Path
R=Path.cwd()
def write(p,s):
 t=p.with_name(p.name+'.edit');t.write_text(s);t.replace(p)
p=R/'tools/serve_recovery/profile_evidence.py';s=p.read_text();start=s.index("    speech = value['speech']",s.index('def voice_business'));end=s.index('    negatives = ',start)
body=s[start:end];assert "for name, target in zip" in body or "speech_transcript" in body
head="def voice_synthesis(value, fixed):\n    \"\"\"Shared complete output/content checks; callers bind IDs and requests.\"\"\"\n    profile_contract.tts_configuration(fixed, base=True)\n    ledger.require(ledger.canonical(value['limits']) == ledger.canonical(fixed['limits']),\n                   'qualified voice effective capacity differs')\n"
s=s[:start]+'    voice_synthesis(value, fixed)\n'+s[end:];point=s.index('def voice_business');s=s[:point]+head+body+'\n\n'+s[point:];write(p,s)
print('extracted unchanged complete output checks for profile and recovery')

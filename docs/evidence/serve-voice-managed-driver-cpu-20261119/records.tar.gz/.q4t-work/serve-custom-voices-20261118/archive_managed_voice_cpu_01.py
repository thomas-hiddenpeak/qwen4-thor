from pathlib import Path
import json,subprocess,tarfile,shutil
from tools.native_tts.voice_service_acceptance import read,save,sha,defaults
from tools.serve_audit import check_inventory as audit
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';P=V/'voice-profiles-01';O=R/'docs/evidence/serve-voice-managed-driver-cpu-20261119'
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
first=read(V/'managed-voice-cpu-01/result.json');last=read(V/'managed-voice-cpu-02/result.json');assert first['status']==last['status']=='PASS' and first['cases']==14 and last['cases']==1
assert read(P/'lease/exit.json')['status']=='ENV_ABORT' and read(P/'env-postflight-01.json')['default_unchanged']
assert defaults()==read(V/'voice-profiles-inputs-02/review.json')['defaults']
plan=read(P/'plan.json');changed=[]
# Preserve the exact original tracked sources; current development began only
# after the aborted lease completed. Never update the failed plan's identities.
for name,h in plan['sources'].items():
 p=R/name
 if sha(p)!=h:
  assert not Path(name).is_absolute() and name.startswith('tools/'),name
  raw=subprocess.check_output(['git','show',plan['source_commit']+':'+name]);import hashlib
  assert hashlib.sha256(raw).hexdigest()==h
  out=P/'original-sources'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw);changed.append(name)
assert set(changed)=={'tools/serve_recovery/profile_evidence.py','tools/native_asr/service_acceptance.py'},changed
save(P/'postflight-source-notes.json',dict(original_sources_retained=changed,original_commit=plan['source_commit'],later_cpu_development=True,environment_abort_not_qualification=True))
actual=audit.current_surface(R);inv=read(audit.INVENTORY);delta={n for n,h in actual['sources_sha256'].items() if inv['sources_sha256'].get(n)!=h};assert delta=={'tools/serve_recovery/profile_evidence.py'}
for n in delta:inv['sources_sha256'][n]=actual['sources_sha256'][n]
write(audit.INVENTORY,json.dumps(inv,ensure_ascii=False,indent=2)+'\n');errors=audit.check(inv,actual);mutations=audit.mutation_checks(inv,actual);assert not errors and mutations==17
O.mkdir();save(O/'audit.json',dict(anchors=len(actual['sources_sha256']),reviewed=sorted(delta),mutations=mutations,errors=errors))
sources={n:sha(R/n) for n in ['tools/native_tts/managed_voice.py','tools/native_tts/test_managed_voice.py','tools/native_asr/service_acceptance.py','tools/serve_recovery/profile_evidence.py']}
summary=dict(status='PASS_REGISTERED_VOICE_MANAGED_RECOVERY_DRIVER_CPU_ONLY',cpu_first=first,cpu_metadata_review=last,distinct_cpu_cases=14,cpu_executions=15,sources=sources,actual_profiles=dict(status='ENV_ABORT',counts=read(P/'result.json')['counts'],seconds=read(P/'result.json')['seconds'],postflight=read(P/'env-postflight-01.json')),actual_managed_recovery=False,default_replaced=False,full_task_complete=False)
save(O/'result.json',summary)
files=[]
for root in [P,V/'voice-profiles-inputs-01',V/'voice-profiles-inputs-02',V/'managed-voice-cpu-01',V/'managed-voice-cpu-02',V/'managed-voice-metadata-review-01']:
 for p in root.rglob('*'):
  if p.is_file() and p.suffix not in ('.wav','.f32','.pyc') and '__pycache__' not in p.parts:files.append(p)
for n in ['prepare_voice_profiles_01.py','prepare_voice_profiles_02.py','prepare_voice_profiles_03.py','voice-profile-prepare-failure-01.json','voice-profile-prepare-failure-02.json','add_managed_voice_01.py','integrate_managed_voice_01.py','managed-voice-plan-01.json','run_managed_voice_cpu_01.py','archive_managed_voice_cpu_01.py']:files.append(V/n)
files += [R/n for n in sources]
assert shutil.disk_usage(R).free>(256<<20)+sum(p.stat().st_size for p in files)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
save(O/'index.json',dict(archive_sha256=sha(O/'records.tar.gz'),files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}))
(O/'README.md').write_text('''# 注册音色恢复驱动与主轻环境中止记录

同一Consent/Voice通过真实API创建，后续入口/整包恢复沿用原ID。
每阶段完整Speech/Chat与无提示ASR、同客户完整存储音频、跨客户
404都必须通过；最终撤销后Speech/Chat同时404，原对象删除成功。
各请求保留原body/wire，验证登记元数据与原请求一致、实际用量、
自然EOS、完整音频和隔离健康。失败阶段不自动重放或重新登记。

现有受监护驱动已接入该actor、配置与预算。完整旧接口检查不变，
新音色只增加8（单阶段）或12（两阶段）业务POST，不增加模型重启
预算。共享原注册音色完整输出校验；旧profile/内置音色记录继续可读。
14项不同CPU通过（首轮2.717秒，元数据补核0.564秒；15次执行），
940来源锚点/17遗漏负控。CPU双端记录均为明确测试替身，不是实际
服务资格。主/轻、受监护恢复及可回退发行仍待真实环境完成。

此前C05两profile计划2启动/50 POST/900秒，实际在1启动/10 POST/
108.844秒由测试租约NVML查询中止：worker CLEANUP_FAILED、无法
及时回收。原租约ENV_ABORT与业务FAILED、原wire/日志完整保留，
不计业务资格通过。第10条Chat随测试中止取消；自有模型退出0，
端口/锁释放，随后只读检查NVML worker也已退出，默认rev316未改。
原始执行源码与之后CPU开发分开保留；两次准备阶段输入错误也保留，
均为0GPU/0模型。没有扩大监控故障到生产停服逻辑或自动重启模型。

下一步继续实际两profile、Guardian/回退与保存状态验证。没有将
环境中止作为候选质量失败，也没有把驱动完成标作总目标完成。
''')
p=R/'docs/serve-master-goals-v2.json';g=read(p);row=g['native_tts_progress']['custom_voice']['service'];row['managed_voice_cpu']=dict(evidence='evidence/serve-voice-managed-driver-cpu-20261119/README.md',distinct_cases=14,actual_recovery=False);row['primary_light_attempt']=dict(status='ENV_ABORT',starts=1,posts=10,reason='NVML query worker CLEANUP_FAILED',owned_cleanup=True,actual_qualification=False)
write(p,json.dumps(g,ensure_ascii=False,indent=2)+'\n')
text='''[音色跨恢复驱动14项CPU通过](evidence/serve-voice-managed-driver-cpu-20261119/README.md)：
同一ID、全音频/ASR、历史/隔离及撤销双路拒绝；15次CPU执行通过，
940锚点/17负控。主轻108.844秒/10POST因NVML查询ENV_ABORT保留，
原执行源码/现场完整，自有模型/监控worker/端口/锁已清理；默认保持。
真实两profile与Guardian/回退仍待验，CPU驱动不冒充恢复资格。
'''
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 音色恢复驱动CPU通过，环境中止原件归档\n\n'+text+'\n为什么：持久音色与撤销需覆盖实际恢复路径；下一步：确认监控后有界续验，保留全部未验项。\n\n')]:
 p=R/n;s=p.read_text();write(p,s.replace(m,m+c,1))
print(json.dumps(dict(status=summary['status'],files=len(files),bytes=(O/'records.tar.gz').stat().st_size,anchors=len(actual['sources_sha256']))))

from pathlib import Path
import argparse,copy,json,shutil,subprocess
from tools.serve_service import package,capacity
from tools.serve_recovery import profile_acceptance as driver,profile_voice
from tools.native_tts.acceptance import defaults
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';T=R/'.q4t-work/serve-native-tts-20261118';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';I=V/'voice-profiles-inputs-01';O=V/'voice-profiles-01'
assert not subprocess.check_output(['git','status','--porcelain'])
assert package.sha(B/'q4t')==package.sha(V/'voice-service-candidate-05/q4t')=='943964c4208b1b802ca04562155e203e797d891196978881031e36e588e71ab9'
assert package.read(V/'tts-checkpoint-cpu-01/result.json')['status']=='PASS'
assert shutil.disk_usage(R).free>(256<<20)+(64<<20)
release=package.read((R/'build/service.release.json').resolve(strict=True));pack=Path(release['package']);original=package.read(pack/'engine/manifest.json')['settings'];prior=package.read(T/'managed-profiles-04/plan.json')
I.mkdir();selected=copy.deepcopy(original['profile']);selected['max_queued_requests']=3;capacity.validate(selected)
builtin=copy.deepcopy(original['native_tts']);builtin['limits']['max_frames']=200
base=dict(package.NATIVE_TTS_BASE,directory=str(V/'base-service-assets-01'),limits=copy.deepcopy(builtin['limits']))
clips=package.read(V/'voice-sdk-tls-02/plan.json')['clips'];profile_voice.fixtures # source is already CPU-qualified
for name,value in [('capacity.json',selected),('tts.json',builtin),('tts-base.json',base),('voices.json',dict(format=profile_voice.FORMAT,clips=clips))]:package.save(I/name,value)
expected=driver.limits_for(selected,original['native_asr'],True,builtin,base);assert expected==dict(starts=2,chats=50,controls=2000,seconds=900),expected
review=dict(scope='C05 actual primary/light retains every accepted configured family and adds Base voice lifecycle; no release/default replacement',binary_sha256=package.sha(B/'q4t'),retained_package=release['package'],retained_manifest_sha256=release['manifest_sha256'],bounds=expected,config_changes=dict(max_queued_requests=[original['profile']['max_queued_requests'],3],tts_max_frames=[original['native_tts']['limits']['max_frames'],200],new_base=base),speaker_limits_preserved=original['native_asr']['speaker']['limits'],fixtures=clips,defaults=defaults(),no_new_fixture_synthesis=True,checkpoint_audio_witness='docs/evidence/serve-tts-checkpoint-witness-20261119/witness.json')
package.save(I/'review.json',review)
args=argparse.Namespace(package=pack,binary=B/'q4t',output=O,candidate_build=B,candidate_release=None,capacity_config=I/'capacity.json',tts_config=I/'tts.json',tts_base_config=I/'tts-base.json',voice_fixtures=I/'voices.json',tts_checkpoint_sampling=True,asr_config=None,asr_audio=Path(prior['asr_audio']['path']),chat_audio=True,speaker_audio=Path(prior['speaker_audio']['path']),separator_audio=Path(prior['separator_audio']['path']),port=19192)
driver.prepare(args)
p=package.read(O/'plan.json');p['sources'][str(I/'review.json')]=package.sha(I/'review.json');p['sources'][str(Path(__file__).resolve())]=package.sha(Path(__file__).resolve());package.save(O/'plan.json',p)
text='冻结C05主/轻profile真实业务：同一严格租约2启动/50业务POST/900秒，\n保留已有全部配置能力，加入真实音色注册、跨客户/配额/撤销及新文本\n独立ASR；原完整采样见证、输入输出家族重载、资料工具/结构化/媒体\n一起验证。仅私有队列2→3、共享TTS帧160→200，默认rev316保持。\n'
for n,m,c in [('docs/STATUS.md','## 正在推进\n\n',text+'\n'),('docs/log/2026-11-19.md','# 2026-11-19 开发日志\n\n','## 2026-11-19 — 冻结含Base的真实主/轻profile\n\n'+text+'\n为什么：不能用仅内置音色资格覆盖新增注册业务。下一步：通过后受监护恢复与有状态回退。\n\n')]:
 q=R/n;s=q.read_text();f=q.with_suffix('.edit');f.write_text(s.replace(m,m+c,1));f.replace(q)
print(json.dumps(dict(plan=str(O/'plan.json'),limits=p['limits'],source_files=len(p['sources']))))

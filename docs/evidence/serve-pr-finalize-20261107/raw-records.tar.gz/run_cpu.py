from pathlib import Path
import importlib
import json
import os
import sys
import unittest

os.umask(0o077)
PHASE = Path(__file__).resolve().parent
ROOT = PHASE.parent/'serve-closeout-20261107/source'
sys.path[:0] = [str(ROOT), str(ROOT/'tools/evalscope')]
unique = {}

def flatten(suite):
    for entry in suite:
        if isinstance(entry, unittest.TestSuite):
            yield from flatten(entry)
        else:
            yield entry

for name in ('tools.serve_service.test_auxiliary',
             'tools.serve_service.test_service',
             'tools.serve_service.test_deadlines'):
    suite = unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name))
    for test in flatten(suite):
        unique.setdefault(test.id(), test)
with (PHASE/'targeted-cpu.log').open('x') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(
        unittest.TestSuite(unique.values()))
record = dict(ids=list(unique), tests=result.testsRun, failures=len(result.failures),
              errors=len(result.errors), skipped=len(result.skipped), gpu_tests=0)
(PHASE/'targeted-cpu.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key: value for key, value in record.items() if key != 'ids'}))
raise SystemExit(not result.wasSuccessful())

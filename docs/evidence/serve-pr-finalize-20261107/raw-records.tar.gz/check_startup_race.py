"""Reproduce and verify the CI fixture race with one CPU child, no GPU."""
from pathlib import Path
import json
import subprocess
import sys
import time
import unittest
from unittest import mock

PHASE = Path(__file__).resolve().parent
ROOT = PHASE.parent/'serve-closeout-20261107/source'
sys.path.insert(0, str(ROOT))
from tools.serve_service import supervisor as sup
from tools.serve_service.test_auxiliary import IsolationTests

mode = sys.argv[1]
assert mode in ('before', 'after')
launch = subprocess.Popen
children = []

def slow_launch(*args, **kwargs):
    child = launch(*args, **kwargs)
    children.append(child)
    # Reproduce scheduler/fsync startup overhead exceeding the fixture's 100 ms.
    time.sleep(.15)
    return child

case = 'test_isolated_supervisor_stops_unhealthy_without_metrics_or_restart'
with (PHASE/(mode+'-startup-race.log')).open('x') as stream:
    with mock.patch.object(sup.subprocess, 'Popen', side_effect=slow_launch):
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
            unittest.TestSuite([IsolationTests(case)]))
success = result.wasSuccessful()
reaped = all(child.poll() is not None for child in children)
record = dict(mode=mode, tests=result.testsRun, failures=len(result.failures),
              errors=len(result.errors), children=len(children), reaped=reaped,
              success=success, gpu_tests=0)
(PHASE/(mode+'-startup-race.json')).write_text(json.dumps(record, indent=2)+'\n')
assert len(children) == 1 and reaped and not result.errors, record
if mode == 'before':
    assert len(result.failures) == 1, record
    assert "'startup deadline exceeded' != 'Backend unhealthy'" in result.failures[0][1]
else:
    assert success, record
print(json.dumps(record))

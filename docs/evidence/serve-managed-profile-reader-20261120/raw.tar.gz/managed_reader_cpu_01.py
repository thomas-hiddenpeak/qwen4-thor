from pathlib import Path
import hashlib,json,os,subprocess,sys,time,unittest
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
from tools.serve_audit.check_inventory import current_surface,check
W=Path(__file__).resolve().parent;OUT=W/'managed-reader-cpu-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  b=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(b);p.chmod(m)
selected=['tools.serve_recovery.test_profile_refusal.ManagedSource',
 'tools.serve_realtime.test_conversation_managed.Evidence.test_wrong_answer_is_preserved_and_cannot_qualify_primary_light',
 'tools.serve_realtime.test_conversation_managed.Evidence.test_pinned_production_namespace_contains_only_pure_shared_verifier',
 'tools.serve_recovery.test_native_bundle.BundleTests.test_default_package_has_native_binary_and_no_nginx_dependency']
selected += ['tools.serve_recovery.test_profile_prompt_targeted.Targeted.'+n for n in ['test_qualification_large_source_roundtrip_does_not_expand_general_metadata','test_reader_rejects_oversize_legacy_duplicate_nonfinite_and_symlink','test_packaging_and_migration_use_profile_reader_and_keep_digest_gate']]
if sys.argv[1:]==['prepare']:
 OUT.mkdir()
 suite=unittest.defaultTestLoader.loadTestsFromNames(selected)
 def ids(s):
  for x in s:
   if isinstance(x,unittest.TestSuite):yield from ids(x)
   else:yield x.id()
 tests=list(ids(suite));assert len(tests)==12 and not any('_FailedTest' in n for n in tests),tests
 p=ROOT/'tools/serve_audit/inventory.json';detach(p);v=json.loads(p.read_text());surface=current_surface(ROOT);v['sources_sha256'].update(surface['sources_sha256']);v['managed_profile_reader_20261120']=dict(scope='New accepted-source reader with full validation and exact payload/registry identity; legacy sealed actors keep old reader',cpu_checks_pending=12);save(p,v);assert not check(v,surface),check(v,surface)
 names=['tools/serve_recovery/profile_record.py','tools/serve_recovery/test_profile_refusal.py','tools/serve_realtime/managed.py','tools/serve_realtime/conversation_managed.py','tools/native_asr/service_acceptance.py','tools/serve_audit/inventory.json']
 for n in names:
  p=OUT/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
 commands=[['python3','-B','-m','unittest',*selected,'-v'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
 save(OUT/'plan.json',dict(scope='Managed qualification identity, bounded specialized I/O, old sealed readers and raw errors; no model execution',maximum_tests=12,tests=tests,actual_profile_reader_checks=2,source_counterexamples=20,maximum_seconds=120,new_gpu_starts=0,commands=commands,sources={n:sha(ROOT/n) for n in names}))
 intro='恢复工具的资格读取已适配显式新来源，普通元数据仍2MiB；新路径\n必须逐份完整校验并绑定registry/实际包，旧封包沿用原入口。冻结12项\nCPU、两份真实记录读取与20来源反例/120秒/0GPU。原生helper零警告\n构建20.700秒，模型/cache/protocol/default保持；随后准备受影响恢复。\n\n'
 p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
 p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 恢复入口的大资格记录读取与必要helper构建\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：新来源记录大于普通元数据上限，应走专用有界读取且不能破坏旧封包；helper按当前构建身份重新链接。相同不可变Rust安装/展开副本共享保留路径与摘要，额外释放148309839字节，附还原脚本。\n\n下一步：对应CPU与真实记录读取、封包和Prompt恢复短验，继续交付及总计划。\n'+t)
 print(json.dumps(dict(status='PREPARED',tests=12,gpu=0)))
else:
 assert sys.argv[1:]==['run'];p=json.loads((OUT/'plan.json').read_text());assert all(sha(ROOT/n)==h for n,h in p['sources'].items());start=time.monotonic();rows=[]
 for i,cmd in enumerate(p['commands']):
  run=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=max(1,120-(time.monotonic()-start)))
  (OUT/f'command-{i}.stdout').write_text(run.stdout);(OUT/f'command-{i}.stderr').write_text(run.stderr);rows.append(dict(command=cmd,exit_code=run.returncode));print(json.dumps(rows[-1]),flush=True)
  if run.returncode:break
 result=dict(status='PASS' if len(rows)==2 and all(x['exit_code']==0 for x in rows) else 'FAIL',seconds=time.monotonic()-start,commands=rows,sources_unchanged=all(sha(ROOT/n)==h for n,h in p['sources'].items()),new_gpu_starts=0)
 if result['status']=='PASS':
  from tools.serve_recovery import profile_record
  from tools.serve_service import package
  source=W/'profiles-reviewed-01';payload=OUT/'actual-payload';payload.mkdir()
  (payload/'profile-light.json').write_bytes((source/'qualified/light.json').read_bytes())
  registry=package.read(source/'qualified/registry.json');primary=profile_record.read(source/'qualified/primary.json')
  actual=profile_record.accepted_source(source/'plan.json',dict(recovery_profiles=registry),primary,payload)
  assert actual==package.read(source/'plan.json')
  result.update(actual_profile_reader_checks=2,registry_sha256=sha(source/'qualified/registry.json'),seconds=time.monotonic()-start)
 save(OUT/'result.json',result);print(json.dumps(result))

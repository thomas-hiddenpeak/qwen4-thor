from pathlib import Path
import os,hashlib,json,subprocess,shutil
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'dependency-sharing-02';O.mkdir()
root=ROOT/'.q4t-work/serve-custom-tools-20261108/deps';installed=root/'rust-1.90.0';rows=[]
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
for tree in [root/'rustc-1.90.0-aarch64-unknown-linux-gnu/rustc',root/'rust-std-1.90.0-aarch64-unknown-linux-gnu/rust-std-aarch64-unknown-linux-gnu']:
 for n in subprocess.check_output(['rg','--files','--hidden',str(tree)],text=True).splitlines():
  p=Path(n);q=installed/p.relative_to(tree)
  if p.is_symlink() or p.stat().st_size<1<<20 or not q.is_file() or q.is_symlink():continue
  s=p.stat();r=q.stat()
  if s.st_ino==r.st_ino or s.st_size!=r.st_size or s.st_mode!=r.st_mode or sha(p)!=sha(q):continue
  rows.append(dict(shared=str(p.relative_to(ROOT)),retained=str(q.relative_to(ROOT)),bytes=s.st_size,sha256=sha(p),mode=s.st_mode&0o777,atime_ns=s.st_atime_ns,mtime_ns=s.st_mtime_ns,original_links=s.st_nlink))
assert len(rows)==22 and sum(x['bytes'] for x in rows)==148309839
(O/'plan.json').write_text(json.dumps(dict(scope='Identical immutable Rust installation/extraction copies; preserve paths, bytes and modes; detach before any future mutation. No model, reference, runtime default or evidence removed.',items=rows),indent=2)+'\n')
for x in rows:
 p=ROOT/x['shared'];q=ROOT/x['retained'];tmp=p.with_name(p.name+'.share-tmp');assert not tmp.exists() and sha(p)==sha(q)==x['sha256'];os.link(q,tmp);os.replace(tmp,p);assert sha(p)==x['sha256'] and p.stat().st_mode&0o777==x['mode']
shutil.copyfile(W/'dependency-sharing-01/restore.py',O/'restore.py')
(O/'result.json').write_text(json.dumps(dict(status='PASS',released_bytes=sum(x['bytes'] for x in rows),paths_and_hashes_preserved=True,available_bytes=shutil.disk_usage(ROOT).free,gpu_actions=0),indent=2)+'\n')
print((O/'result.json').read_text())

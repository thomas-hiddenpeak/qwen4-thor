from pathlib import Path
import hashlib,json,os,shutil
here=Path(__file__).resolve().parent; root=here.parents[2]
for item in json.loads((here/'plan.json').read_text())['items']:
 p=root/item['shared']; tmp=p.with_name(p.name+'.restore-tmp'); assert not tmp.exists()
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==item['sha256']
 shutil.copy2(p,tmp)
 assert hashlib.file_digest(tmp.open('rb'),'sha256').hexdigest()==item['sha256']
 os.utime(tmp,ns=(item['atime_ns'],item['mtime_ns'])); os.replace(tmp,p)

from pathlib import Path
import json,os,subprocess,sys,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service import package as p
from tools.serve_audit.check_inventory import current_surface,check
W=Path(__file__).resolve().parent;OUT=W/'managed-reader-cpu-02'
names=['tools/serve_recovery/profile_record.py','tools/serve_recovery/test_profile_refusal.py','tools/serve_realtime/managed.py','tools/serve_realtime/conversation_managed.py','tools/native_asr/service_acceptance.py','tools/serve_audit/inventory.json']
tests=['tools.serve_realtime.test_conversation_managed.Evidence.'+n for n in ['test_wrong_answer_is_preserved_and_cannot_qualify_primary_light','test_pinned_production_namespace_contains_only_pure_shared_verifier']]
if sys.argv[1:]==['prepare']:
 OUT.mkdir(mode=0o700);(OUT/'fixtures').mkdir()
 path=ROOT/'tools/serve_audit/inventory.json';v=p.read(path)
 surface=current_surface(ROOT);v['sources_sha256'].update(surface['sources_sha256']);p.save(path,v)
 assert not check(v,surface)
 for n in names:
  dst=OUT/'source'/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((ROOT/n).read_bytes())
 p.save(OUT/'plan.json',dict(scope='Only two unexecuted tests after missing Q4T_TEST_OUTPUT_DIR; preserve first 10 passes and original two fixture errors. Specialized ASR light reader uses same validated path.',tests=tests,prior_result_sha256=p.sha(W/'managed-reader-cpu-01/result.json'),maximum_seconds=120,new_gpu_starts=0,actual_profile_reader_checks=2,source_counterexamples=20,sources={n:p.sha(ROOT/n) for n in names},commands=[['python3','-B','-m','unittest',*tests,'-v'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]))
 print('PREPARED two failed-fixture checks, two real records, zero GPU')
else:
 assert sys.argv[1:]==['run'];plan=p.read(OUT/'plan.json');start=time.monotonic();rows=[]
 assert all(p.sha(ROOT/n)==h for n,h in plan['sources'].items())
 for i,command in enumerate(plan['commands']):
  result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=100,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(OUT/'fixtures')))
  (OUT/f'command-{i}.stdout').write_text(result.stdout);(OUT/f'command-{i}.stderr').write_text(result.stderr);rows.append(dict(command=command,exit_code=result.returncode))
  if result.returncode:break
 result=dict(status='PASS' if len(rows)==2 and all(r['exit_code']==0 for r in rows) else 'FAIL',commands=rows,new_gpu_starts=0)
 if result['status']=='PASS':
  from tools.serve_recovery import profile_record
  source=W/'profiles-reviewed-01';payload=OUT/'actual-payload';payload.mkdir()
  (payload/'profile-light.json').write_bytes((source/'qualified/light.json').read_bytes())
  registry=p.read(source/'qualified/registry.json');primary=profile_record.read(source/'qualified/primary.json')
  actual=profile_record.accepted_source(source/'plan.json',dict(recovery_profiles=registry),primary,payload)
  assert actual==p.read(source/'plan.json')
  result.update(actual_profile_reader_checks=2,registry_sha256=p.sha(source/'qualified/registry.json'))
 result.update(seconds=time.monotonic()-start,sources_unchanged=all(p.sha(ROOT/n)==h for n,h in plan['sources'].items()))
 p.save(OUT/'result.json',result);print(json.dumps(result));sys.exit(result['status']!='PASS')

from pathlib import Path
import json,hashlib,subprocess,shutil,time,signal,os,tarfile
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';O=V/'voice-startup-fix-build-01';O.mkdir(exist_ok=False)
plan=json.loads((V/'voice-startup-fix-plan-01.json').read_text());before=json.loads((V/'voice-http-01/run/plan.json').read_text())['defaults']
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
H=R/'.q4t-work/serve-file-search-20261112/host';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build'
with tarfile.open(O/'prior-host.tar.gz','w:gz') as f:f.add(H/'q4t_host_tests',arcname='q4t_host_tests')
(O/'prior-host.json').write_text(json.dumps({'sha256':sha(H/'q4t_host_tests'),'archive_sha256':sha(O/'prior-host.tar.gz')})+'\n')
for name,build,target,seconds in [('host',H,'q4t_host_tests',300),('engine',B,'q4t',600)]:
 assert shutil.disk_usage(R).free>256<<20
 start=time.monotonic();cmd=['cmake','--build',str(build),'--target',target,'--parallel','4'];reason=None;minimum=shutil.disk_usage(R).free
 with (O/(name+'.log')).open('wb') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   minimum=min(minimum,shutil.disk_usage(R).free)
   if minimum<256<<20 or time.monotonic()-start>seconds:
    reason='DISK_RESERVE_ABORT' if minimum<256<<20 else 'BUILD_TIMEOUT';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
 log=(O/(name+'.log')).read_text(errors='replace');warnings=[x for x in log.splitlines() if 'warning:' in x]
 result={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'warnings':warnings,'abort':reason,'minimum_free_bytes':minimum,'defaults_unchanged':all(sha(R/n)==v for n,v in before.items())}
 if p.returncode==0:result['binary_sha256']=sha(build/target)
 (O/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,json.dumps(result),flush=True)
 if p.returncode or warnings or reason:print(log[-6000:]);raise SystemExit(1)
 if name=='host':
  out=V/'voice-startup-fix-cpu-01';out.mkdir(exist_ok=False);(out/'required.txt').write_text('\n'.join(plan['required'])+'\n')
  cmd=[str(H/'q4t_host_tests'),'--required-list',str(out/'required.txt')];start=time.monotonic()
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
  (out/'tests.log').write_text(r.stdout);row={'status':'PASS' if r.returncode==0 else 'FAILED','returncode':r.returncode,'seconds':time.monotonic()-start,'cases':len(plan['required']),'binary_sha256':sha(H/'q4t_host_tests'),'command':cmd,'gpu':0}
  (out/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);print(r.stdout,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
C=V/'voice-service-candidate-02';C.mkdir(exist_ok=False)
assert shutil.disk_usage(R).free>(256<<20)+(B/'q4t').stat().st_size
for name in ['q4t','CMakeCache.txt','chat_protocol_sources.json']:shutil.copy2(B/name,C/name)
sources=json.loads((C/'chat_protocol_sources.json').read_text());drift=[p for p,h in sources.items() if sha(R/p)!=h];assert not drift
(C/'identity.json').write_text(json.dumps({'engine_sha256':sha(C/'q4t'),'production_source_count':len(sources),'production_source_drift':drift,'runtime_http_qualified':False,'default_replaced':False},indent=2)+'\n')
print('candidate',sha(C/'q4t'),flush=True)

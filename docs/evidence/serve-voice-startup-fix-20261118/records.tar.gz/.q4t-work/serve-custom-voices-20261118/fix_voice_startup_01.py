from pathlib import Path
import json
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def edit(p,a,b):
 s=p.read_text();assert s.count(a)==1;s=s.replace(a,b);t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
p=R/'src/server/server_options.cpp'
edit(p,'if (options.speaker_model_dir.empty())\n      return Status::Fail("separator-model-dir requires speaker-model-dir");','if (options.speaker_model_dir.empty() || options.aligner_model_dir.empty())\n      return Status::Fail("separator-model-dir requires speaker and aligner");')
edit(p,'    if (options.asr_model_dir.empty() || options.aligner_model_dir.empty() ||\n        options.vad_model_dir.empty())\n      return Status::Fail("speaker-model-dir requires ASR, aligner and VAD");','    // Diarized transcripts need alignment; voice registration instead uses\n    // VAD windows directly. Do not require unused alignment weights for Base.\n    if (options.asr_model_dir.empty() || options.vad_model_dir.empty() ||\n        (options.aligner_model_dir.empty() && options.tts_base_model_dir.empty()))\n      return Status::Fail(\n          "speaker-model-dir requires ASR, VAD and either aligner or TTS Base");')
p=R/'tests/server_options_test.cpp';s=p.read_text()+'''
Q4T_TEST(serve_voice_registration_does_not_require_unused_alignment_assets) {
  auto options = Defaults();
  Q4T_CHECK(Parse({"--tts-base-model-dir", "/base", "--asr-model-dir", "/asr",
                   "--speaker-model-dir", "/speaker", "--vad-model-dir", "/vad"},
                  &options));
  Q4T_CHECK(options.aligner_model_dir.empty() &&
            options.tts_base_model_dir == "/base");
  Q4T_CHECK(!Parse({"--separator-model-dir", "/separator"}, &options));
  Q4T_CHECK(options.separator_model_dir.empty());
  for (const auto missing : {"--asr-model-dir", "--vad-model-dir",
                             "--tts-base-model-dir"}) {
    auto incomplete = Defaults();
    std::vector<std::string_view> args;
    for (const auto flag : {"--tts-base-model-dir", "--asr-model-dir",
                            "--speaker-model-dir", "--vad-model-dir"}) {
      if (std::string_view(flag) == missing) continue;
      args.push_back(flag);
      args.push_back("/optional");
    }
    Q4T_CHECK(!q4t::server::ParseServerOptions(args, &incomplete));
    Q4T_CHECK(incomplete.speaker_model_dir.empty());
  }
  Q4T_CHECK(Parse({"--aligner-model-dir", "/aligner",
                   "--separator-model-dir", "/separator"}, &options));
  return true;
}
''';t=p.with_suffix('.cpp.edit');t.write_text(s);t.replace(p)
required=['serve_voice_registration_does_not_require_unused_alignment_assets','speaker_options_bind_required_components_and_atomic_budgets','separator_options_require_complete_pipeline_and_atomic_limits','serve_base_tts_assets_are_independent_and_name_conflicts_are_atomic','voice_capabilities_distinguish_synthesis_from_registration_assets']
plan={'scope':'Fix Base voice registration CLI dependency, retain diarization/separation dependencies','required':required,'cases':len(required),'seconds':60,'model_loads':0,'gpu':0,'disk_reserve_bytes':256<<20,'original_http_attempt':'voice-http-01','original_attempt_retained':True,'subsequent_http':'same fixed 18 POST checklist; no new cases; one effective core load'}
(V/'voice-startup-fix-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
update='首轮音色HTTP在CLI依赖校验停止：speaker旧配置强制aligner，实际0模型\n加载/0业务请求，清理与默认身份通过。现按实际消费者区分Base注册与\n对齐转写，分离器仍要求aligner；冻结1新增+4受影响CPU/60秒后续验。\n'
for name,marker,text in [('docs/STATUS.md','## 正在推进\n\n',update+'\n'),('docs/log/2026-11-18.md','# 2026-11-18 开发日志\n\n','## 2026-11-18：修复Base音色注册的无关对齐配置依赖\n\n'+update+'\n为什么：VAD窗口声纹不使用aligner，原启动合同遗漏了新消费者。\n下一步针对CPU和同清单HTTP，原失败不覆盖，默认保持。\n\n')]:
 p=R/name;t=p.with_name(p.name+'.edit');t.write_text(p.read_text().replace(marker,marker+text,1));t.replace(p)

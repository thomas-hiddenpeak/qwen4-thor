import hashlib,json,os,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'client-driver-cpu-02';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(R)):sha(p) for p in sorted((R/'tools/serve_live').glob('*')) if p.is_file()}
previous=json.loads((W/'client-driver-cpu-01/result.json').read_text());assert previous['status']=='PASS'
reused={n:previous['sources'][n] for n in ['tools/serve_live/checks.py','tools/serve_live/test_checks.py']};assert all(sha(R/n)==h for n,h in reused.items())
commands=[['node','--test','tools/serve_live/test_client_wait.mjs'],['node','--check','tools/serve_live/client_sdk.mjs'],['python3','-c',"import ast;from pathlib import Path;[ast.parse(p.read_text()) for p in Path('tools/serve_live').glob('*.py')]"]]
(O/'plan.json').write_text(json.dumps(dict(sources=sources,commands=commands,cpu_seconds_limit=60,gpu_actions=0,reason='Bounded missing-handoff wait with structured actor failure; explicit actual TTS query preparation, actor/driver syntax. Ten unchanged wire checks reused by SHA; no model/socket started'),indent=2)+'\n')
rows=[];start=time.monotonic()
for i,c in enumerate(commands):
 with (O/(str(i)+'.log')).open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=max(1,60-(time.monotonic()-start)))
 rows.append(dict(index=i,returncode=r.returncode))
 if r.returncode:break
result=dict(status='PASS' if len(rows)==len(commands) and all(r['returncode']==0 for r in rows) else 'FAIL',commands=rows,seconds=time.monotonic()-start,sources=sources,sources_unchanged=all(sha(R/n)==h for n,h in sources.items()),tests=4,reused_tests=10,reused_sources=reused,gpu_actions=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((O/'0.log').read_text());assert result['status']=='PASS'

import hashlib,json,os,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'client-driver-cpu-03';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(R)):sha(p) for p in sorted((R/'tools/serve_live').glob('*')) if p.is_file()}
previous=json.loads((W/'client-driver-cpu-02/result.json').read_text());assert previous['status']=='PASS'
for n in ['tools/serve_live/client_wait.mjs','tools/serve_live/test_client_wait.mjs']:assert sha(R/n)==previous['sources'][n]
commands=[['python3','-m','unittest','-v',*['tools.serve_live.test_checks.Checks.'+n for n in ['test_real_deltas_accounting_and_quality_are_separate','test_same_generation_preface_is_not_the_tool_result','test_audio_receipt_duration','test_no_duplicate_or_synthetic_audio_metadata','test_silent_bytes_are_not_real_speech']]],['node','--check','tools/serve_live/client_sdk.mjs'],['python3','-c',"import ast;from pathlib import Path;[ast.parse(p.read_text()) for p in Path('tools/serve_live').glob('*.py')]"]]
(O/'plan.json').write_text(json.dumps(dict(sources=sources,commands=commands,cpu_seconds_limit=60,gpu_actions=0,reason='Affected audio segment/answer association checks; native same-generation preface is separate from the correlated project result. Existing four bounded-wait Node checks reused by exact unchanged source SHA; no GPU'),indent=2)+'\n')
rows=[];start=time.monotonic()
for i,c in enumerate(commands):
 with (O/(str(i)+'.log')).open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=max(1,60-(time.monotonic()-start)))
 rows.append(dict(index=i,returncode=r.returncode))
 if r.returncode:break
result=dict(status='PASS' if len(rows)==len(commands) and all(r['returncode']==0 for r in rows) else 'FAIL',commands=rows,seconds=time.monotonic()-start,sources=sources,sources_unchanged=all(sha(R/n)==h for n,h in sources.items()),tests=5,reused_node_tests=4,gpu_actions=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((O/'0.log').read_text());assert result['status']=='PASS'

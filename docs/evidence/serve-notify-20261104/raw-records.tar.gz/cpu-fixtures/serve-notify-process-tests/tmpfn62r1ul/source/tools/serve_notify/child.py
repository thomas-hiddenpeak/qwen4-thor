import time
print("output",flush=True)
while True: time.sleep(.1)

import hashlib,json,subprocess,time,warnings
from pathlib import Path
root=Path.cwd(); out=root/'.q4t-work/auxiliary-isolation-cpu-20261107'
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=sorted(p for p in changed if p.endswith('.py') or p=='tests/host/CMakeLists.txt' or p=='tools/serve_service/README.md')
with warnings.catch_warnings():
 warnings.simplefilter('error')
 for name in files:
  if name.endswith('.py'):compile((root/name).read_text(),name,'exec')
binding={p:hashlib.file_digest((root/p).open('rb'),'sha256').hexdigest() for p in files}
(out/'sources-01.json').write_text(json.dumps(binding,indent=2)+'\n')
suites=[('auxiliary','tools/serve_service/test_auxiliary.py'),('classification','tools/serve_service/test_nvml_policy.py'),('telemetry','tools/serve_service/test_telemetry.py'),('recovery','tools/serve_service/test_monitor_recovery.py'),('query','tools/evalscope/test_nvml_process_query.py'),('strict-guard','tools/evalscope/test_gpu_exclusive.py'),('supervisor','tools/serve_service/test_service.py'),('deadlines','tools.serve_service.test_deadlines'),('memory','tools.serve_service.test_memory'),('gateway','tools.serve_gateway.test_managed'),('inspection','tools.serve_service.test_inspection')]
records=[]
for name,target in suites:
 argv=['/usr/bin/python3','-B','-W','error']+([target] if target.endswith('.py') else ['-m',target])
 started=time.monotonic()
 with (out/(name+'-01.log')).open('w') as stream:
  result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
 record=dict(name=name,argv=argv,returncode=result.returncode,seconds=time.monotonic()-started)
 records.append(record)
 (out/'cpu-results-01.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
raise SystemExit(any(r['returncode'] for r in records))

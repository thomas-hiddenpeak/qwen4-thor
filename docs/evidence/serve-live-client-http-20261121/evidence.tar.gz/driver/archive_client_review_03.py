import hashlib,importlib.util,io,json,subprocess,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-live-client-http-20261121';O.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
summary=read(W/'client-business-03-review-01/result.json');assert summary['status']=='PASS_LIVE_CLIENT_BUSINESS_OFFLINE_REVIEW'
files={}
for folder in ['close-health-plan-01','client-driver-cpu-06','client-driver-cpu-07','client-business-03-review-01']:
 for p in sorted((W/folder).iterdir()):
  if p.is_file():files[folder+'/'+p.name]=p.read_bytes()
for n in ['review_client_03.py','client_driver_cpu_06.py','client_driver_cpu_07.py','archive_client_review_03.py']:
 files['driver/'+n]=(W/n).read_bytes()
for n in ['tools/serve_live/checks.py','tools/serve_live/client_acceptance.py','tools/serve_live/test_health.py','src/server/chat_tts_backend.cpp','src/server/asr_service.cpp']:
 files['reviewed/'+n]=(R/n).read_bytes()
index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as archive:
 for n,raw in sorted(files.items()):
  index[n]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(raw),0o600,0;archive.addfile(info,io.BytesIO(raw))
save(O/'index.json',index);summary['archive_sha256']=sha((O/'evidence.tar.gz').read_bytes());save(O/'result.json',summary)
(O/'README.md').write_text('''# Live原生客户端资料查询真实业务验收

实际运行：候选引擎68bcc25e、原生TLS入口、官方OpenAI JS 7.47.0 LiveWS，
1次模型启动、1个连接、1ASR+2前台生成+1普通Chat，64.040秒。原RPM3
保持；第三轮alpha实际准入3、结算1730 tokens且预留归零。真实转写为
“请查询当前项目版本号。”，客户端读取真实STATUS并回填，原生语音
答复rev426。最终session.closed、1000关闭、普通Chat=42、资源/端口/
租约释放全部核实。62次NVML正常；默认rev426与客户预算未改。

最终旧检查器错误要求ASR和TTS同时常驻ready，故[原始运行](../serve-live-close-health-original-20261121/README.md)
仍保留FAIL和COMMAND_FAILED。实际资源管理在TTS前正常释放ASR权重，
ASR为metadata_ready/device_bytes=0、TTS为ready，二者reason=none、
load/compute failures=0且没有残留清理。独立离线复核使用原始字节、
完整未改的协议观察器和更正后的健康判定，通过5项健康反例及身份、
实际业务、结算、资源和租约检查；没有把原命令状态改成COMPLETED，
也没有追加GPU。验收状态为PASS_LIVE_CLIENT_BUSINESS_OFFLINE_REVIEW。

累计三轮3启动/10实际工作/255.282秒。[第一轮未委派](../serve-live-client-business-failed-20261121/README.md)
和[第二轮静音尾部重复ASR](../serve-live-close-tail-failed-20261121/README.md)
原记录不改写。关闭修复有[18项针对性CPU](../serve-live-close-tail-cpu-20261121/README.md)
及本次实际RPM/关闭证据，不能用提高配额绕过。听感未验。

这里只接受主WSS客户端委派资料闭环，不代表完整Live、主轻资格、
托管恢复或新默认已交付。继续音频fixture、Responses/Decisions、上下文
保留、录制/旁路/fork、媒体、组合发行和全部master任务。

[结果](result.json)、[复核原件](evidence.tar.gz)、[逐文件索引](index.json)。
原始GPU日志、事件和错误断言来源在上方原始运行归档，私钥和客户
策略不进入公共归档。
''')
p=R/'tools/serve_audit/inventory.json';inventory=read(p)
row=inventory['routes']['GET /v1/live/sessions'];row['boundary']='主WSS客户端委派真实资料闭环已验（原最终健康断言FAIL保留，独立离线复核通过）。录制、Responses/Decisions、fixture、旁路与媒体继续实现；主轻/恢复/发行待完成，不宣称完整Live兼容。'
row['evidence'].append('docs/evidence/serve-live-client-http-20261121/README.md')
native=inventory['native_routes']['GET /v1/live/sessions'];native['boundary']=row['boundary'];native['evidence'].append(row['evidence'][-1])
inventory['live_client_business_review_20261121']=dict(evidence=row['evidence'][-1],state=summary['status'],binary_sha256=summary['binary_sha256'],original_command_failed=True,full_live_accepted=False,default_changed=False)
save(p,inventory)
r=subprocess.run(['python3','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(W/'client-business-inventory-reviewed.json').write_text(r.stdout);assert r.returncode==0,r.stdout
p=R/'docs/STATUS.md';s=p.read_text();s=s.replace('## 正在推进\n\n','''## 正在推进

[Live主WSS客户端真实闭环已验](evidence/serve-live-client-http-20261121/README.md)：
正确ASR、真实资料委派/回填、语音rev426、正常closed/1000及后续Chat=42。
1启动/4工作/64.040秒，原RPM3下无额外ASR，1730 tokens结算/预留归零，
62次NVML正常且清理完成。最后的旧健康断言错误要求ASR同时常驻；
原FAIL保持，5项反例与独立原件复核通过，复核新增GPU0。累计三轮
3启动/10实际工作/255.282秒。继续fixture、服务端委派及其余Live/master
任务；默认rev426保持STOPPED，尚未发行本候选。

''',1);p.write_text(s)
p=R/'docs/SERVE_LIVE_2026-11-21.md';p.write_text(p.read_text()+'''
[主WSS客户端委派真实闭环](evidence/serve-live-client-http-20261121/README.md)
已验：ASR查询、真实项目读取/回填、原生语音rev426、关闭及后续普通
Chat均通过。静音尾部额外ASR已修复，原RPM3保持。第三轮最终健康
断言错把正常ASR权重释放当故障，原FAIL保留；5项健康反例及独立
原件复核通过，未追加GPU。累计3启动/10实际工作/255.282秒，默认未改。
L03客户端闭环已验，继续fixture、Responses/Decisions与长上下文保留；
L04—L06及全部master任务仍未完成，不以本组验收作为总目标终点。
''')
p=R/'docs/serve-master-goals-v2.json';master=read(p);live=master['native_live_20261121'];live.update(state='primary_client_business_accepted_remaining_live_implementation',gpu_starts=3,actual_work=10,gpu_seconds=summary['cumulative_live_attempts']['seconds'],distinct_native_cpu_tests=118,binding_tests=12,binding_new_tests=9,close_tail_tests=18,close_tail_new_tests=6,business_evidence='evidence/serve-live-client-http-20261121/README.md',original_health_assertion_failure_retained=True,original_business_failures_retained=True,release_pending=True)
for sub in live['subtasks']:
 if sub['id']=='L02':sub['state']='primary_client_wss_business_accepted_profile_recovery_delivery_pending'
 if sub['id']=='L03':sub['state']='client_delegation_business_accepted_fixture_server_backends_and_retention_in_progress'
save(p,master)
p=R/'docs/log/2026-11-21.md';p.write_text('''## Live关闭修复真实业务通过，原健康断言失败独立复核

日期：2026-11-21。做了什么：1模型/4实际工作/64.040秒，正确ASR、
真实资料委派/回填、语音rev426、session.closed/1000及Chat=42均通过；
alpha原RPM3、实际准入3、结算1730 tokens，无额外尾部ASR。62次NVML
正常，进程/端口/租约释放，默认未改。累计3启动/10工作/255.282秒。

为什么：旧驱动最终要求ASR/TTS同时ready，与实际辅助模型切换释放
合同冲突。原FAIL/COMMAND_FAILED和错误断言源码保留；新增健康检查
要求合法驻留、reason none、真实加载记录、零失败和无待清理。5项
反例通过；独立原件/来源/协议/实际结算/健康/清理复核通过，GPU新增0，
未将原命令改标成功。下一步：继续fixture、服务端委派、上下文保留
以及全部Live/master任务，主轻资格/恢复/可回退发行仍需完成。

'''+p.read_text())
print(json.dumps(dict(status=summary['status'],archive_sha256=summary['archive_sha256'],inventory=r.returncode)))

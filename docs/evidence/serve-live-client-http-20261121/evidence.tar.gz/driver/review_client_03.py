"""Independent offline review; never changes the original failed command result."""
import fcntl,hashlib,json,subprocess,sys,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.serve_live import checks,client_acceptance as driver
from tools.serve_service.package import read,require,save,sha
P=W/'client-business-03';O=W/'client-business-03-review-01';O.mkdir(mode=0o700)
start=time.monotonic();original=R/'docs/evidence/serve-live-close-health-original-20261121';index=read(original/'index.json')
save(O/'plan.json',dict(scope=__doc__,original_archive_sha256=sha(original/'evidence.tar.gz'),original_plan_sha256=sha(P/'plan.json'),cpu=sha(W/'client-driver-cpu-06/result.json'),verifier={str(R/n):sha(R/n) for n in ['tools/serve_live/checks.py','tools/serve_live/client_acceptance.py','tools/serve_live/test_health.py']},seconds_limit=60,new_gpu_starts=0))
for name,item in index.items():
 if name.startswith('original/'):
  require(sha(P/name.removeprefix('original/'))==item['sha256'],'original artifact drift')
plan=read(P/'plan.json');result=read(P/'result.json');lease=read(P/'lease/exit.json');cleanup=read(P/'cleanup.json')
require(result['status']=='FAIL' and result['error'].rstrip().endswith('RuntimeError: actual speech backend health') and result['seconds']<=600,'only known final verifier failure')
require(all(result['counts'][k]==v for k,v in plan['limits'].items() if k not in ['seconds','controls']) and result['counts']['controls']<=2000,'frozen work budgets')
require(lease['status']=='COMMAND_FAILED' and lease['child_returncode']==1 and lease['compute_backend']=='nvml' and lease['lease_inherited_by_child'] is True,'retain actual strict-lease command failure')
queries=[json.loads(line) for line in (P/'lease/nvml-queries.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and q['returncode']==0 for q in queries),'strict monitoring evidence')
require(cleanup['remaining']==[] and cleanup['model_exit']==0 and cleanup['ports_released'] is True and cleanup['lease_continuously_held'] is True,'actual owned process cleanup')
for pid,identity in cleanup['owned'].items():
 current=driver.base.lifecycle.guard.processes().get(int(pid),{})
 require(current.get('start_ticks')!=identity['start_ticks'],'original process still alive')
driver.qualification.background.probe_ports(tuple(plan[k] for k in ['port','operations_port','public_port']))
with driver.base.lifecycle.guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
changed={n for n,h in plan['sources'].items() if sha(R/n)!=h}
require(changed=={'tools/serve_live/client_acceptance.py','tools/serve_live/checks.py'},'unexpected runtime or verifier drift')
old=subprocess.check_output(['git','show',plan['source_commit']+':tools/serve_live/checks.py'],cwd=R,text=True)
current=(R/'tools/serve_live/checks.py').read_text()
require(old[old.index('def observe('):]==current[current.index('def observe('):],'original wire/accounting observation changed')
old=subprocess.check_output(['git','show',plan['source_commit']+':tools/serve_live/client_acceptance.py'],cwd=R,text=True)
expected=old.replace("WORK/'client-driver-cpu-05/result.json'","WORK/'client-driver-cpu-07/result.json'").replace("        for name in ('native_asr_health','native_tts_health'):\n            health=json.loads(raw)[name]\n            require(health['state']=='ready' and health['compute_failures']==0,\n                    'actual speech backend health')", "        save(self.out/'speech-health.json',checks.speech_health(json.loads(raw)))")
require(expected==(R/'tools/serve_live/client_acceptance.py').read_text(),'only reviewed health assertion and CPU source pointer may change')
for n,h in plan['protected'].items():require(sha(n)==h,'default publication changed')
require(sha(plan['binary'])==plan['binary_sha256'] and sha(plan['ingress'])==plan['ingress_sha256'],'executed program identity')
require(read(W/'client-driver-cpu-06/result.json')['status']=='PASS','health counterexample checks')
for n,h in read(W/'client-driver-cpu-07/result.json')['sources'].items():require(sha(R/n)==h,'current verifier qualification drift')
record=plan['record'];require(sha(R/record['path'])==record['sha256'],'original project record drift before review')
journal=[json.loads(line) for line in (P/'client.events.jsonl').read_text().splitlines()]
actual=checks.observe(read(P/'client.sdk.json'),journal,read(P/'before.json'),read(P/'live-drained.json'),record)
require(actual==read(P/'observation.json') and all(q['status']=='PASS' for q in actual['quality']),'actual business and quality differ')
config=read(P/'final-config.wire');require(read(P/'final-config.http.json')['status']==200,'actual final diagnostic HTTP')
health=checks.speech_health(config)
core=read(P/'core-after.wire');choice=core['choices'][0]
require(choice['finish_reason']=='stop' and choice['message']['content'].strip()=='42','actual ordinary core completion')
before=read(P/'before.json');after=read(P/'final-drained.json');key=lambda n:n+'{client="gamma"}'
require(after[key('q4t_client_rate_admitted_total')]-before[key('q4t_client_rate_admitted_total')]==1 and after[key('q4t_client_rate_settled_tokens_total')]-before[key('q4t_client_rate_settled_tokens_total')]==core['usage']['total_tokens'],'actual core admission and exact settlement')
require(all(after[k]==0 for k in ['q4t_active_chats','q4t_realtime_sessions','q4t_realtime_host_reserved_bytes']) and after['q4t_seq_slots_free']==1,'final actual resources')
require(all(v==0 for k,v in after.items() if k.startswith('q4t_client_rate_reserved_tokens{')),'all client reservations released')
policy=read(P/'client-policy.json');token=policy['gateway_token'];secrets=[token]+[hashlib.sha256((token+n).encode()).hexdigest() for n in ['alpha','beta','gamma']]
for name in [n.removeprefix('original/') for n in index if n.startswith('original/')]:
 require(all(secret.encode() not in (P/name).read_bytes() for secret in secrets),'private credential in original public artifact')
require(time.monotonic()-start<60,'bounded offline review')
summary=dict(status='PASS_LIVE_CLIENT_BUSINESS_OFFLINE_REVIEW',original_result='FAIL',original_guard='COMMAND_FAILED',reason='Final assertion mistook normal auxiliary weight eviction for failure; unchanged wire observer and actual saved health verified independently',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],new_gpu_starts=0,actual_run_starts=1,actual_run_work=4,actual_run_seconds=result['seconds'],observation=actual,speech_health=health,core_quality='PASS',core_tokens=core['usage']['total_tokens'],environment=dict(env_abort=False,nvml_queries=len(queries),all_queries_ok=True,owned_cleanup=True,lock_and_ports_released=True,original_command_success=False),default_unchanged=True,review_seconds=time.monotonic()-start,original_public_archive_sha256=sha(original/'evidence.tar.gz'),original_plan_sha256=sha(P/'plan.json'),cumulative_live_attempts=dict(starts=3,actual_work=10,seconds=113.32063404517248+77.92148964898661+result['seconds']),listener_validation=False,managed_recovery=False,master_active=True)
save(O/'result.json',summary);print(json.dumps(summary,ensure_ascii=False))

import hashlib,json,os,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'client-driver-cpu-06';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(R)):sha(p) for p in sorted((R/'tools/serve_live').glob('*')) if p.is_file()}
previous=json.loads((W/'client-driver-cpu-05/result.json').read_text());assert previous['status']=='PASS'
for n in ['tools/serve_live/client_wait.mjs','tools/serve_live/test_client_wait.mjs','tools/serve_live/client_sdk.mjs','tools/serve_live/test_checks.py']:assert sha(R/n)==previous['sources'][n]
import subprocess as sp
old=sp.check_output(['git','show','HEAD:tools/serve_live/checks.py'],cwd=R,text=True)
assert old[old.index('def observe('):]=='def observe('+(R/'tools/serve_live/checks.py').read_text().split('def observe(',1)[1]
commands=[['python3','-m','unittest','-v','tools.serve_live.test_health'],['python3','-c',"import ast;from pathlib import Path;[ast.parse(p.read_text()) for p in Path('tools/serve_live').glob('*.py')]"]]
(O/'plan.json').write_text(json.dumps(dict(sources=sources,commands=commands,cpu_seconds_limit=60,gpu_actions=0,reason='Five affected auxiliary health checker tests; observation function is unchanged and original trace retained; unchanged SDK, checker and bounded-wait implementations reuse their prior accepted CPU checks; no GPU'),indent=2)+'\n')
rows=[];start=time.monotonic()
for i,c in enumerate(commands):
 with (O/(str(i)+'.log')).open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=max(1,60-(time.monotonic()-start)))
 rows.append(dict(index=i,returncode=r.returncode))
 if r.returncode:break
result=dict(status='PASS' if len(rows)==len(commands) and all(r['returncode']==0 for r in rows) else 'FAIL',commands=rows,seconds=time.monotonic()-start,sources=sources,sources_unchanged=all(sha(R/n)==h for n,h in sources.items()),tests=5,reused_node_tests=4,reused_observation_tests=5,observation_function_unchanged=True,gpu_actions=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((O/'0.log').read_text());assert result['status']=='PASS'

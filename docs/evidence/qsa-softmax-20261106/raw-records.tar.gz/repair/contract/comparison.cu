#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
namespace parent {
using u16 = uint16_t;
using f32 = float;
constexpr int kKvPageSize = 16;
__device__ __forceinline__ f32 Bf16ToFloat(u16 x) {
  uint32_t bits = static_cast<uint32_t>(x) << 16;
  float f;
  std::memcpy(&f, &bits, sizeof(f));
  return f;
}
__device__ __forceinline__ u16 FloatToBf16(f32 f) {
  const __nv_bfloat16 b = __float2bfloat16_rn(f);
  return *reinterpret_cast<const u16*>(&b);
}

__device__ __forceinline__ void MmaBf16(float& c0, float& c1, float& c2,
                                        float& c3, uint32_t a0, uint32_t a1,
                                        uint32_t a2, uint32_t a3, uint32_t b0,
                                        uint32_t b1) {
  asm volatile(
      "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
      "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
      : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)
      : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}

// cp.async: asynchronously copy 16 bytes global->shared (Ampere+; SM110
// Blackwell). Used to prefetch the next chunk's scattered paged-KV while the
// current chunk computes, hiding the LPDDR5x scatter latency that makes the
// per-chunk gather->compute serialization the dominant prefill cost.
__device__ __forceinline__ void CpAsync16(void* smem, const void* gmem) {
  const unsigned s = static_cast<unsigned>(__cvta_generic_to_shared(smem));
  asm volatile("cp.async.cg.shared.global [%0], [%1], 16;\n" ::"r"(s),
               "l"(gmem));
}
__device__ __forceinline__ void CpAsyncCommit() {
  asm volatile("cp.async.commit_group;\n");
}
template <int N>
__device__ __forceinline__ void CpAsyncWait() {
  asm volatile("cp.async.wait_group %0;\n" ::"n"(N));
}

__global__ void SparseAttentionKernel(const u16* __restrict__ q,
                                      const u16* __restrict__ kv_cache,
                                      const int* __restrict__ page_table,
                                      const int* __restrict__ topk,
                                      const int* __restrict__ topk_len,
                                      u16* __restrict__ out,
                                      const u16* __restrict__ gate, int nq,
                                      int nkv, int hd, int max_topk,
                                      const int* __restrict__ d_seq_id,
                                      size_t kv_seq_stride, int pt_seq_stride) {
  // Tensor-core GQA-packed QSA attention. grid = (T, nkv); each block reads
  // its kv-head's K/V ONCE and drives all 12 q-heads through mma.sync
  // (12x KV-read reduction vs the old per-q-head kernel). Tile shape is fixed
  // to the model constants (hd=256, nq=24, nkv=2 -> G=12); a runtime guard
  // rejects any other geometry.
  constexpr int kG = 12;      // q-heads per kv-head
  constexpr int kHd = 256;
  // Shift consecutive shared rows by four 32-bit banks. The 8-BF16 pad
  // preserves 16-byte cp.async alignment while separating row accesses
  // in the QK and PV fragments. Global KV and arithmetic stay unchanged.
  constexpr int kSharedHd = kHd + 8;
  constexpr int kChunk = 16;  // positions processed per mma pass
  if (nq / nkv != kG || nkv != 2 || hd != kHd) return;
  // Logical rows remain 256 BF16; only their shared-memory stride is padded.
  __shared__ u16 sQ[16 * kSharedHd];  // Query rows 12..15 are zero-padded.
  __shared__ u16 sK[2 * kChunk * kSharedHd];  // Double-buffered prefetch.
  __shared__ u16 sV[2 * kChunk * kSharedHd];
  __shared__ float sS[16 * 16];    // [16, 16] scores (rows 12..15 unused)
  __shared__ u16 sP[kChunk * 16];  // [16 pos, 16] probs (cols 12..15 = 0)
  // sMax/sSum/sAlpha padded to 16 (PV lanes read [group+8] up to 15 for the
  // unused q-heads 12..15; padding avoids an OOB read).
  __shared__ float sMax[16];       // running softmax max per q-head
  __shared__ float sSum[16];       // running softmax denom per q-head
  __shared__ float sAlpha[16];     // this-chunk rescale factor per q-head
  const int t = blockIdx.x;
  const int kvh = blockIdx.y;
  const int warp_id = threadIdx.x >> 5;
  const int lane = threadIdx.x & 31;
  // B2 multi-seq: select this token's sequence KV + page_table slices.
  const u16* kv = d_seq_id
                      ? kv_cache + static_cast<size_t>(d_seq_id[t]) * kv_seq_stride
                      : kv_cache;
  const int* pt = d_seq_id
                      ? page_table + static_cast<size_t>(d_seq_id[t]) * pt_seq_stride
                      : page_table;
  const int* sel = topk + static_cast<size_t>(t) * max_topk;
  const int nsel_total = topk_len[t];
  const float scale = 1.f / sqrtf(static_cast<float>(kHd));
  // Stage 12 query rows into sQ; zero rows 12..15 (mma reads a 16-row tile).
  const int qh0 = kvh * kG;
  for (int i = threadIdx.x; i < 16 * kHd; i += 256) {
    const int m = i / kHd;
    sQ[m * kSharedHd + i % kHd] =
        (m < kG)
            ? q[(static_cast<size_t>(t) * nq + qh0 + m) * kHd + (i % kHd)]
            : 0;
  }
  for (int i = threadIdx.x; i < kChunk * 16; i += 256) sP[i] = 0;
  if (threadIdx.x < 16) {
    sMax[threadIdx.x] = -1e30f;
    sSum[threadIdx.x] = 0.f;
    sAlpha[threadIdx.x] = 0.f;
  }
  __syncthreads();
  // PV output accumulator in REGISTERS (was shared sO with a per-chunk
  // read-modify-write over [12,256] floats — the dominant shared-memory
  // traffic). Warp w owns n-tiles {w, w+8, w+16, w+24}; each lane owns, per
  // n-tile, the 4 mma C values (2 q-heads x 2 dims). acc[j][0..3] mirrors the
  // mma C fragment (c0,c1 = q-head group; c2,c3 = q-head group+8).
  const int pv_group = lane >> 2;
  const int pv_col = (lane & 3) * 2;
  float acc[4][4];
  #pragma unroll
  for (int j = 0; j < 4; ++j) {
    acc[j][0] = 0.f;
    acc[j][1] = 0.f;
    acc[j][2] = 0.f;
    acc[j][3] = 0.f;
  }
  // KV gather is double-buffered: the next chunk's scattered paged-KV is
  // prefetched (cp.async) into the alternate buffer while this chunk's QK/PV
  // computes, hiding the LPDDR5x scatter latency that dominates this kernel.
  // The staged VALUES are identical to the old synchronous gather, so the
  // QK/softmax/PV math is bit-for-bit unchanged.
  auto stage = [&](int base_sel, int chunk, int buf) {
    u16* dK = sK + static_cast<size_t>(buf) * kChunk * kSharedHd;
    u16* dV = sV + static_cast<size_t>(buf) * kChunk * kSharedHd;
    // One 16-byte cp.async per (position, 8-dim group) for K and V: u in
    // [0,32) copies K dims [u*8, u*8+8); u in [32,64) copies the V dims.
    for (int i = threadIdx.x; i < chunk * 64; i += 256) {
      const int c = i >> 6;
      const int u = i & 63;
      const int is_v = u >> 5;
      const int d8 = (u & 31) * 8;
      const int p = sel[base_sel + c];
      const int sp = p < 0 ? 0 : p;
      const int slot = pt[sp] * kKvPageSize + (sp % kKvPageSize);
      const size_t g = (static_cast<size_t>(slot) * nkv + kvh) * (2 * kHd) +
                       (is_v ? kHd : 0) + d8;
      CpAsync16((is_v ? dV : dK) + c * kSharedHd + d8, kv + g);
    }
    // Zero the [chunk, kChunk) tail (only the final partial chunk needs it);
    // finite so 0*x=0 in the PV mma (uninitialised shared could be a NaN).
    for (int i = threadIdx.x; i < (kChunk - chunk) * kHd; i += 256) {
      const int c = chunk + (i / kHd);
      const int d = i - (i / kHd) * kHd;
      dK[c * kSharedHd + d] = 0;
      dV[c * kSharedHd + d] = 0;
    }
    CpAsyncCommit();
  };
  int nsel = 0;
  int buf = 0;
  if (nsel_total > 0) stage(0, min(kChunk, nsel_total), 0);
  while (nsel < nsel_total) {
    const int chunk = min(kChunk, nsel_total - nsel);
    const int next_nsel = nsel + chunk;
    // Prefetch the next chunk into the alternate buffer (overlaps this chunk's
    // compute), then wait for THIS chunk's gather (issued last iteration /
    // prologue) to land. wait_group<1> keeps the next prefetch in flight.
    if (next_nsel < nsel_total) {
      stage(next_nsel, min(kChunk, nsel_total - next_nsel), buf ^ 1);
      CpAsyncWait<1>();
    } else {
      CpAsyncWait<0>();
    }
    __syncthreads();
    const u16* bK = sK + static_cast<size_t>(buf) * kChunk * kSharedHd;
    const u16* bV = sV + static_cast<size_t>(buf) * kChunk * kSharedHd;
    // ---- QK^T (warps 0-1, one n-tile each): sS[16,16] = sQ @ sK^T via mma. --
    // mma m16n8k16: A = sQ (m=qh, k=dim), B = sK^T (B[k][n]=sK[pos=n][dim=k]).
    // 16 k-tiles per n-tile; the 2 n-tiles (16 positions) run on warps 0 and 1
    // in parallel (was warp 0 serial). Bit-identical: disjoint output columns.
    if (warp_id < kChunk / 8) {
      const int nt = warp_id;
      const int nb = nt * 8;
      const int group = lane >> 2;     // qh row (0..7, and +8)
      const int k0 = (lane & 3) * 2;   // k-pair base
      const int col = (lane & 3) * 2;  // pos-pair base (C fragment)
      float c0 = 0.f, c1 = 0.f, c2 = 0.f, c3 = 0.f;
      for (int kt = 0; kt < kHd / 16; ++kt) {
        const int kb = kt * 16;
        const u16* qa = sQ + group * kSharedHd + kb + k0;
        const u16* qa8 = sQ + (group + 8) * kSharedHd + kb + k0;
        uint32_t a0 = *reinterpret_cast<const uint32_t*>(qa);
        uint32_t a1 = *reinterpret_cast<const uint32_t*>(qa8);
        uint32_t a2 = *reinterpret_cast<const uint32_t*>(qa + 8);
        uint32_t a3 = *reinterpret_cast<const uint32_t*>(qa8 + 8);
        const u16* kbp = bK + (nb + group) * kSharedHd + kb + k0;
        uint32_t b0 = *reinterpret_cast<const uint32_t*>(kbp);
        uint32_t b1 = *reinterpret_cast<const uint32_t*>(kbp + 8);
        MmaBf16(c0, c1, c2, c3, a0, a1, a2, a3, b0, b1);
      }
      sS[group * 16 + nb + col] = c0;
      sS[group * 16 + nb + col + 1] = c1;
      sS[(group + 8) * 16 + nb + col] = c2;
      sS[(group + 8) * 16 + nb + col + 1] = c3;
    }
    __syncthreads();
    // ---- Online softmax per q-head row (thread q handles qh=q). ----
    if (threadIdx.x < kG) {
      const int qrow = threadIdx.x;
      const float m_old = sMax[qrow];
      float mx = m_old;
      for (int p = 0; p < chunk; ++p)
        mx = fmaxf(mx, sS[qrow * 16 + p] * scale);
      const float alpha = expf(m_old - mx);
      sAlpha[qrow] = alpha;
      float s = sSum[qrow] * alpha;
      for (int p = 0; p < kChunk; ++p) {
        const float pr = (p < chunk) ? expf(sS[qrow * 16 + p] * scale - mx)
                                     : 0.f;
        sP[p * 16 + qrow] = FloatToBf16(pr);
        s += pr;
      }
      sSum[qrow] = s;
      sMax[qrow] = mx;
    }
    __syncthreads();
    // ---- PV: acc += sP^T[16,16] @ sV[16,256] via mma (register accum). ----
    // out[qh][d] = sum_pos P[pos][qh] * V[pos][d].
    // mma: A = sP^T (m=qh, k=pos): A[qh][pos] = sP[pos*16 + qh] (stride 16).
    //      B = sV (k=pos, n=d): B[pos][d] = sV[pos*hd + d] (stride hd in k).
    // Warp w handles n-tiles w, w+8, w+16, w+24 (disjoint 8-dim slices); the
    // running accumulator lives in registers (acc[j]) — no shared sO traffic.
    {
      const int k0 = (lane & 3) * 2;   // pos-pair base (mma K)
      const float ag = sAlpha[pv_group];
      const float ag8 = sAlpha[pv_group + 8];
      // A-fragment is the same for every n-tile (depends only on q-heads/pos).
      const u16* pa = sP + pv_group;
      const u16* pa8 = sP + pv_group + 8;
      uint32_t a0 = static_cast<uint32_t>(pa[k0 * 16]) |
                    (static_cast<uint32_t>(pa[(k0 + 1) * 16]) << 16);
      uint32_t a1 = static_cast<uint32_t>(pa8[k0 * 16]) |
                    (static_cast<uint32_t>(pa8[(k0 + 1) * 16]) << 16);
      uint32_t a2 = static_cast<uint32_t>(pa[(k0 + 8) * 16]) |
                    (static_cast<uint32_t>(pa[(k0 + 9) * 16]) << 16);
      uint32_t a3 = static_cast<uint32_t>(pa8[(k0 + 8) * 16]) |
                    (static_cast<uint32_t>(pa8[(k0 + 9) * 16]) << 16);
      #pragma unroll
      for (int j = 0; j < 4; ++j) {
        const int nt = warp_id + j * 8;
        const int nb = nt * 8;
        // B-fragment: elements strided by hd in sV -> scalar load + pack.
        const u16* vb = bV + nb + pv_group;
        uint32_t b0 = static_cast<uint32_t>(vb[k0 * kSharedHd]) |
                      (static_cast<uint32_t>(vb[(k0 + 1) * kSharedHd]) << 16);
        uint32_t b1 = static_cast<uint32_t>(vb[(k0 + 8) * kSharedHd]) |
                      (static_cast<uint32_t>(vb[(k0 + 9) * kSharedHd]) << 16);
        float c0 = 0.f, c1 = 0.f, c2 = 0.f, c3 = 0.f;
        MmaBf16(c0, c1, c2, c3, a0, a1, a2, a3, b0, b1);
        // Fold the per-chunk online-softmax rescale into the register accum.
        acc[j][0] = acc[j][0] * ag + c0;
        acc[j][1] = acc[j][1] * ag + c1;
        acc[j][2] = acc[j][2] * ag8 + c2;
        acc[j][3] = acc[j][3] * ag8 + c3;
      }
    }
    __syncthreads();
    nsel = next_nsel;
    buf ^= 1;
  }
  // ---- Normalize + fused gate + write out (from register accumulators). ----
  // Lane (warp w, lane L) owns q-heads group=L/4 and group+8, dims nb+col,
  // nb+col+1 for n-tiles nt = w + j*8 (j=0..3).
  {
    const float lg = sSum[pv_group];
    const float lg8 = sSum[pv_group + 8];
    const int qh_a = qh0 + pv_group;
    const int qh_b = qh0 + pv_group + 8;
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
      const int nb = (warp_id + j * 8) * 8;
      const int d = nb + pv_col;
      // q-head group (always valid, 0..7 < 12).
      {
        const size_t o0 = (static_cast<size_t>(t) * nq + qh_a) * kHd + d;
        float v0 = (lg > 0.f) ? acc[j][0] / lg : acc[j][0];
        float v1 = (lg > 0.f) ? acc[j][1] / lg : acc[j][1];
        const float g0 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0])));
        const float g1 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0 + 1])));
        out[o0] = FloatToBf16(Bf16ToFloat(FloatToBf16(v0)) * g0);
        out[o0 + 1] = FloatToBf16(Bf16ToFloat(FloatToBf16(v1)) * g1);
      }
      // q-head group+8 (valid only for group 0..3 -> qh 8..11).
      if (pv_group + 8 < kG) {
        const size_t o0 = (static_cast<size_t>(t) * nq + qh_b) * kHd + d;
        float v0 = (lg8 > 0.f) ? acc[j][2] / lg8 : acc[j][2];
        float v1 = (lg8 > 0.f) ? acc[j][3] / lg8 : acc[j][3];
        const float g0 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0])));
        const float g1 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0 + 1])));
        out[o0] = FloatToBf16(Bf16ToFloat(FloatToBf16(v0)) * g0);
        out[o0 + 1] = FloatToBf16(Bf16ToFloat(FloatToBf16(v1)) * g1);
      }
    }
  }
}

}
namespace failed {
using u16 = uint16_t;
using f32 = float;
constexpr int kKvPageSize = 16;
__device__ __forceinline__ f32 Bf16ToFloat(u16 x) {
  uint32_t bits = static_cast<uint32_t>(x) << 16;
  float f;
  std::memcpy(&f, &bits, sizeof(f));
  return f;
}
__device__ __forceinline__ u16 FloatToBf16(f32 f) {
  const __nv_bfloat16 b = __float2bfloat16_rn(f);
  return *reinterpret_cast<const u16*>(&b);
}

__device__ __forceinline__ void MmaBf16(float& c0, float& c1, float& c2,
                                        float& c3, uint32_t a0, uint32_t a1,
                                        uint32_t a2, uint32_t a3, uint32_t b0,
                                        uint32_t b1) {
  asm volatile(
      "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
      "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
      : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)
      : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}

// cp.async: asynchronously copy 16 bytes global->shared (Ampere+; SM110
// Blackwell). Used to prefetch the next chunk's scattered paged-KV while the
// current chunk computes, hiding the LPDDR5x scatter latency that makes the
// per-chunk gather->compute serialization the dominant prefill cost.
__device__ __forceinline__ void CpAsync16(void* smem, const void* gmem) {
  const unsigned s = static_cast<unsigned>(__cvta_generic_to_shared(smem));
  asm volatile("cp.async.cg.shared.global [%0], [%1], 16;\n" ::"r"(s),
               "l"(gmem));
}
__device__ __forceinline__ void CpAsyncCommit() {
  asm volatile("cp.async.commit_group;\n");
}
template <int N>
__device__ __forceinline__ void CpAsyncWait() {
  asm volatile("cp.async.wait_group %0;\n" ::"n"(N));
}

template <bool ParallelSoftmax = false>
__global__ void SparseAttentionKernel(const u16* __restrict__ q,
                                      const u16* __restrict__ kv_cache,
                                      const int* __restrict__ page_table,
                                      const int* __restrict__ topk,
                                      const int* __restrict__ topk_len,
                                      u16* __restrict__ out,
                                      const u16* __restrict__ gate, int nq,
                                      int nkv, int hd, int max_topk,
                                      const int* __restrict__ d_seq_id,
                                      size_t kv_seq_stride, int pt_seq_stride) {
  // Tensor-core GQA-packed QSA attention. grid = (T, nkv); each block reads
  // its kv-head's K/V ONCE and drives all 12 q-heads through mma.sync
  // (12x KV-read reduction vs the old per-q-head kernel). Tile shape is fixed
  // to the model constants (hd=256, nq=24, nkv=2 -> G=12); a runtime guard
  // rejects any other geometry.
  constexpr int kG = 12;      // q-heads per kv-head
  constexpr int kHd = 256;
  // Shift consecutive shared rows by four 32-bit banks. The 8-BF16 pad
  // preserves 16-byte cp.async alignment while separating row accesses
  // in the QK and PV fragments. Global KV and arithmetic stay unchanged.
  constexpr int kSharedHd = kHd + 8;
  constexpr int kChunk = 16;  // positions processed per mma pass
  if (nq / nkv != kG || nkv != 2 || hd != kHd) return;
  // Logical rows remain 256 BF16; only their shared-memory stride is padded.
  __shared__ u16 sQ[16 * kSharedHd];  // Query rows 12..15 are zero-padded.
  __shared__ u16 sK[2 * kChunk * kSharedHd];  // Double-buffered prefetch.
  __shared__ u16 sV[2 * kChunk * kSharedHd];
  __shared__ float sS[16 * 16];    // [16, 16] scores (rows 12..15 unused)
  __shared__ u16 sP[kChunk * 16];  // [16 pos, 16] probs (cols 12..15 = 0)
  // sMax/sSum/sAlpha padded to 16 (PV lanes read [group+8] up to 15 for the
  // unused q-heads 12..15; padding avoids an OOB read).
  __shared__ float sMax[16];       // running softmax max per q-head
  __shared__ float sSum[16];       // running softmax denom per q-head
  __shared__ float sAlpha[16];     // this-chunk rescale factor per q-head
  const int t = blockIdx.x;
  const int kvh = blockIdx.y;
  const int warp_id = threadIdx.x >> 5;
  const int lane = threadIdx.x & 31;
  // B2 multi-seq: select this token's sequence KV + page_table slices.
  const u16* kv = d_seq_id
                      ? kv_cache + static_cast<size_t>(d_seq_id[t]) * kv_seq_stride
                      : kv_cache;
  const int* pt = d_seq_id
                      ? page_table + static_cast<size_t>(d_seq_id[t]) * pt_seq_stride
                      : page_table;
  const int* sel = topk + static_cast<size_t>(t) * max_topk;
  const int nsel_total = topk_len[t];
  const float scale = 1.f / sqrtf(static_cast<float>(kHd));
  // Stage 12 query rows into sQ; zero rows 12..15 (mma reads a 16-row tile).
  const int qh0 = kvh * kG;
  for (int i = threadIdx.x; i < 16 * kHd; i += 256) {
    const int m = i / kHd;
    sQ[m * kSharedHd + i % kHd] =
        (m < kG)
            ? q[(static_cast<size_t>(t) * nq + qh0 + m) * kHd + (i % kHd)]
            : 0;
  }
  for (int i = threadIdx.x; i < kChunk * 16; i += 256) sP[i] = 0;
  if (threadIdx.x < 16) {
    sMax[threadIdx.x] = -1e30f;
    sSum[threadIdx.x] = 0.f;
    sAlpha[threadIdx.x] = 0.f;
  }
  __syncthreads();
  // PV output accumulator in REGISTERS (was shared sO with a per-chunk
  // read-modify-write over [12,256] floats — the dominant shared-memory
  // traffic). Warp w owns n-tiles {w, w+8, w+16, w+24}; each lane owns, per
  // n-tile, the 4 mma C values (2 q-heads x 2 dims). acc[j][0..3] mirrors the
  // mma C fragment (c0,c1 = q-head group; c2,c3 = q-head group+8).
  const int pv_group = lane >> 2;
  const int pv_col = (lane & 3) * 2;
  float acc[4][4];
  #pragma unroll
  for (int j = 0; j < 4; ++j) {
    acc[j][0] = 0.f;
    acc[j][1] = 0.f;
    acc[j][2] = 0.f;
    acc[j][3] = 0.f;
  }
  // KV gather is double-buffered: the next chunk's scattered paged-KV is
  // prefetched (cp.async) into the alternate buffer while this chunk's QK/PV
  // computes, hiding the LPDDR5x scatter latency that dominates this kernel.
  // The staged VALUES are identical to the old synchronous gather, so the
  // QK/softmax/PV math is bit-for-bit unchanged.
  auto stage = [&](int base_sel, int chunk, int buf) {
    u16* dK = sK + static_cast<size_t>(buf) * kChunk * kSharedHd;
    u16* dV = sV + static_cast<size_t>(buf) * kChunk * kSharedHd;
    // One 16-byte cp.async per (position, 8-dim group) for K and V: u in
    // [0,32) copies K dims [u*8, u*8+8); u in [32,64) copies the V dims.
    for (int i = threadIdx.x; i < chunk * 64; i += 256) {
      const int c = i >> 6;
      const int u = i & 63;
      const int is_v = u >> 5;
      const int d8 = (u & 31) * 8;
      const int p = sel[base_sel + c];
      const int sp = p < 0 ? 0 : p;
      const int slot = pt[sp] * kKvPageSize + (sp % kKvPageSize);
      const size_t g = (static_cast<size_t>(slot) * nkv + kvh) * (2 * kHd) +
                       (is_v ? kHd : 0) + d8;
      CpAsync16((is_v ? dV : dK) + c * kSharedHd + d8, kv + g);
    }
    // Zero the [chunk, kChunk) tail (only the final partial chunk needs it);
    // finite so 0*x=0 in the PV mma (uninitialised shared could be a NaN).
    for (int i = threadIdx.x; i < (kChunk - chunk) * kHd; i += 256) {
      const int c = chunk + (i / kHd);
      const int d = i - (i / kHd) * kHd;
      dK[c * kSharedHd + d] = 0;
      dV[c * kSharedHd + d] = 0;
    }
    CpAsyncCommit();
  };
  int nsel = 0;
  int buf = 0;
  if (nsel_total > 0) stage(0, min(kChunk, nsel_total), 0);
  while (nsel < nsel_total) {
    const int chunk = min(kChunk, nsel_total - nsel);
    const int next_nsel = nsel + chunk;
    // Prefetch the next chunk into the alternate buffer (overlaps this chunk's
    // compute), then wait for THIS chunk's gather (issued last iteration /
    // prologue) to land. wait_group<1> keeps the next prefetch in flight.
    if (next_nsel < nsel_total) {
      stage(next_nsel, min(kChunk, nsel_total - next_nsel), buf ^ 1);
      CpAsyncWait<1>();
    } else {
      CpAsyncWait<0>();
    }
    __syncthreads();
    const u16* bK = sK + static_cast<size_t>(buf) * kChunk * kSharedHd;
    const u16* bV = sV + static_cast<size_t>(buf) * kChunk * kSharedHd;
    // ---- QK^T (warps 0-1, one n-tile each): sS[16,16] = sQ @ sK^T via mma. --
    // mma m16n8k16: A = sQ (m=qh, k=dim), B = sK^T (B[k][n]=sK[pos=n][dim=k]).
    // 16 k-tiles per n-tile; the 2 n-tiles (16 positions) run on warps 0 and 1
    // in parallel (was warp 0 serial). Bit-identical: disjoint output columns.
    if (warp_id < kChunk / 8) {
      const int nt = warp_id;
      const int nb = nt * 8;
      const int group = lane >> 2;     // qh row (0..7, and +8)
      const int k0 = (lane & 3) * 2;   // k-pair base
      const int col = (lane & 3) * 2;  // pos-pair base (C fragment)
      float c0 = 0.f, c1 = 0.f, c2 = 0.f, c3 = 0.f;
      for (int kt = 0; kt < kHd / 16; ++kt) {
        const int kb = kt * 16;
        const u16* qa = sQ + group * kSharedHd + kb + k0;
        const u16* qa8 = sQ + (group + 8) * kSharedHd + kb + k0;
        uint32_t a0 = *reinterpret_cast<const uint32_t*>(qa);
        uint32_t a1 = *reinterpret_cast<const uint32_t*>(qa8);
        uint32_t a2 = *reinterpret_cast<const uint32_t*>(qa + 8);
        uint32_t a3 = *reinterpret_cast<const uint32_t*>(qa8 + 8);
        const u16* kbp = bK + (nb + group) * kSharedHd + kb + k0;
        uint32_t b0 = *reinterpret_cast<const uint32_t*>(kbp);
        uint32_t b1 = *reinterpret_cast<const uint32_t*>(kbp + 8);
        MmaBf16(c0, c1, c2, c3, a0, a1, a2, a3, b0, b1);
      }
      sS[group * 16 + nb + col] = c0;
      sS[group * 16 + nb + col + 1] = c1;
      sS[(group + 8) * 16 + nb + col] = c2;
      sS[(group + 8) * 16 + nb + col + 1] = c3;
    }
    __syncthreads();
    // Large-T: distribute independent exponentials over (head, position).
    // Keep the original ordered max and FP32 denominator accumulation.
    // The unrounded probabilities must survive separately from BF16 sP.
    if constexpr (ParallelSoftmax) {
      __shared__ float probabilities[kG * kChunk];
      if (threadIdx.x < kG) {
        const int qrow = threadIdx.x;
        const float m_old = sMax[qrow];
        float mx = m_old;
        for (int p = 0; p < chunk; ++p)
          mx = fmaxf(mx, sS[qrow * 16 + p] * scale);
        sAlpha[qrow] = expf(m_old - mx);
        sMax[qrow] = mx;
      }
      __syncthreads();
      if (threadIdx.x < kG * kChunk) {
        const int qrow = threadIdx.x / kChunk;
        const int p = threadIdx.x % kChunk;
        const float mx = sMax[qrow];
        const float pr = (p < chunk) ? expf(sS[qrow * 16 + p] * scale - mx)
                                     : 0.f;
        probabilities[qrow * kChunk + p] = pr;
        sP[p * 16 + qrow] = FloatToBf16(pr);
      }
      __syncthreads();
      if (threadIdx.x < kG) {
        const int qrow = threadIdx.x;
        float s = sSum[qrow] * sAlpha[qrow];
        // Include the zero tail, in the original left-to-right order. A tree
        // reduction or summing sP would change the numerical contract.
        for (int p = 0; p < kChunk; ++p)
          s += probabilities[qrow * kChunk + p];
        sSum[qrow] = s;
      }
    } else if (threadIdx.x < kG) {
      const int qrow = threadIdx.x;
      const float m_old = sMax[qrow];
      float mx = m_old;
      for (int p = 0; p < chunk; ++p)
        mx = fmaxf(mx, sS[qrow * 16 + p] * scale);
      const float alpha = expf(m_old - mx);
      sAlpha[qrow] = alpha;
      float s = sSum[qrow] * alpha;
      for (int p = 0; p < kChunk; ++p) {
        const float pr = (p < chunk) ? expf(sS[qrow * 16 + p] * scale - mx)
                                     : 0.f;
        sP[p * 16 + qrow] = FloatToBf16(pr);
        s += pr;
      }
      sSum[qrow] = s;
      sMax[qrow] = mx;
    }
    __syncthreads();
    // ---- PV: acc += sP^T[16,16] @ sV[16,256] via mma (register accum). ----
    // out[qh][d] = sum_pos P[pos][qh] * V[pos][d].
    // mma: A = sP^T (m=qh, k=pos): A[qh][pos] = sP[pos*16 + qh] (stride 16).
    //      B = sV (k=pos, n=d): B[pos][d] = sV[pos*hd + d] (stride hd in k).
    // Warp w handles n-tiles w, w+8, w+16, w+24 (disjoint 8-dim slices); the
    // running accumulator lives in registers (acc[j]) — no shared sO traffic.
    {
      const int k0 = (lane & 3) * 2;   // pos-pair base (mma K)
      const float ag = sAlpha[pv_group];
      const float ag8 = sAlpha[pv_group + 8];
      // A-fragment is the same for every n-tile (depends only on q-heads/pos).
      const u16* pa = sP + pv_group;
      const u16* pa8 = sP + pv_group + 8;
      uint32_t a0 = static_cast<uint32_t>(pa[k0 * 16]) |
                    (static_cast<uint32_t>(pa[(k0 + 1) * 16]) << 16);
      uint32_t a1 = static_cast<uint32_t>(pa8[k0 * 16]) |
                    (static_cast<uint32_t>(pa8[(k0 + 1) * 16]) << 16);
      uint32_t a2 = static_cast<uint32_t>(pa[(k0 + 8) * 16]) |
                    (static_cast<uint32_t>(pa[(k0 + 9) * 16]) << 16);
      uint32_t a3 = static_cast<uint32_t>(pa8[(k0 + 8) * 16]) |
                    (static_cast<uint32_t>(pa8[(k0 + 9) * 16]) << 16);
      #pragma unroll
      for (int j = 0; j < 4; ++j) {
        const int nt = warp_id + j * 8;
        const int nb = nt * 8;
        // B-fragment: elements strided by hd in sV -> scalar load + pack.
        const u16* vb = bV + nb + pv_group;
        uint32_t b0 = static_cast<uint32_t>(vb[k0 * kSharedHd]) |
                      (static_cast<uint32_t>(vb[(k0 + 1) * kSharedHd]) << 16);
        uint32_t b1 = static_cast<uint32_t>(vb[(k0 + 8) * kSharedHd]) |
                      (static_cast<uint32_t>(vb[(k0 + 9) * kSharedHd]) << 16);
        float c0 = 0.f, c1 = 0.f, c2 = 0.f, c3 = 0.f;
        MmaBf16(c0, c1, c2, c3, a0, a1, a2, a3, b0, b1);
        // Fold the per-chunk online-softmax rescale into the register accum.
        acc[j][0] = acc[j][0] * ag + c0;
        acc[j][1] = acc[j][1] * ag + c1;
        acc[j][2] = acc[j][2] * ag8 + c2;
        acc[j][3] = acc[j][3] * ag8 + c3;
      }
    }
    __syncthreads();
    nsel = next_nsel;
    buf ^= 1;
  }
  // ---- Normalize + fused gate + write out (from register accumulators). ----
  // Lane (warp w, lane L) owns q-heads group=L/4 and group+8, dims nb+col,
  // nb+col+1 for n-tiles nt = w + j*8 (j=0..3).
  {
    const float lg = sSum[pv_group];
    const float lg8 = sSum[pv_group + 8];
    const int qh_a = qh0 + pv_group;
    const int qh_b = qh0 + pv_group + 8;
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
      const int nb = (warp_id + j * 8) * 8;
      const int d = nb + pv_col;
      // q-head group (always valid, 0..7 < 12).
      {
        const size_t o0 = (static_cast<size_t>(t) * nq + qh_a) * kHd + d;
        float v0 = (lg > 0.f) ? acc[j][0] / lg : acc[j][0];
        float v1 = (lg > 0.f) ? acc[j][1] / lg : acc[j][1];
        const float g0 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0])));
        const float g1 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0 + 1])));
        out[o0] = FloatToBf16(Bf16ToFloat(FloatToBf16(v0)) * g0);
        out[o0 + 1] = FloatToBf16(Bf16ToFloat(FloatToBf16(v1)) * g1);
      }
      // q-head group+8 (valid only for group 0..3 -> qh 8..11).
      if (pv_group + 8 < kG) {
        const size_t o0 = (static_cast<size_t>(t) * nq + qh_b) * kHd + d;
        float v0 = (lg8 > 0.f) ? acc[j][2] / lg8 : acc[j][2];
        float v1 = (lg8 > 0.f) ? acc[j][3] / lg8 : acc[j][3];
        const float g0 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0])));
        const float g1 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0 + 1])));
        out[o0] = FloatToBf16(Bf16ToFloat(FloatToBf16(v0)) * g0);
        out[o0 + 1] = FloatToBf16(Bf16ToFloat(FloatToBf16(v1)) * g1);
      }
    }
  }
}

}
namespace repaired {
using u16 = uint16_t;
using f32 = float;
constexpr int kKvPageSize = 16;
__device__ __forceinline__ f32 Bf16ToFloat(u16 x) {
  uint32_t bits = static_cast<uint32_t>(x) << 16;
  float f;
  std::memcpy(&f, &bits, sizeof(f));
  return f;
}
__device__ __forceinline__ u16 FloatToBf16(f32 f) {
  const __nv_bfloat16 b = __float2bfloat16_rn(f);
  return *reinterpret_cast<const u16*>(&b);
}

__device__ __forceinline__ void MmaBf16(float& c0, float& c1, float& c2,
                                        float& c3, uint32_t a0, uint32_t a1,
                                        uint32_t a2, uint32_t a3, uint32_t b0,
                                        uint32_t b1) {
  asm volatile(
      "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
      "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
      : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)
      : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}

// cp.async: asynchronously copy 16 bytes global->shared (Ampere+; SM110
// Blackwell). Used to prefetch the next chunk's scattered paged-KV while the
// current chunk computes, hiding the LPDDR5x scatter latency that makes the
// per-chunk gather->compute serialization the dominant prefill cost.
__device__ __forceinline__ void CpAsync16(void* smem, const void* gmem) {
  const unsigned s = static_cast<unsigned>(__cvta_generic_to_shared(smem));
  asm volatile("cp.async.cg.shared.global [%0], [%1], 16;\n" ::"r"(s),
               "l"(gmem));
}
__device__ __forceinline__ void CpAsyncCommit() {
  asm volatile("cp.async.commit_group;\n");
}
template <int N>
__device__ __forceinline__ void CpAsyncWait() {
  asm volatile("cp.async.wait_group %0;\n" ::"n"(N));
}

template <bool ParallelSoftmax = false>
__global__ void SparseAttentionKernel(const u16* __restrict__ q,
                                      const u16* __restrict__ kv_cache,
                                      const int* __restrict__ page_table,
                                      const int* __restrict__ topk,
                                      const int* __restrict__ topk_len,
                                      u16* __restrict__ out,
                                      const u16* __restrict__ gate, int nq,
                                      int nkv, int hd, int max_topk,
                                      const int* __restrict__ d_seq_id,
                                      size_t kv_seq_stride, int pt_seq_stride) {
  // Tensor-core GQA-packed QSA attention. grid = (T, nkv); each block reads
  // its kv-head's K/V ONCE and drives all 12 q-heads through mma.sync
  // (12x KV-read reduction vs the old per-q-head kernel). Tile shape is fixed
  // to the model constants (hd=256, nq=24, nkv=2 -> G=12); a runtime guard
  // rejects any other geometry.
  constexpr int kG = 12;      // q-heads per kv-head
  constexpr int kHd = 256;
  // Shift consecutive shared rows by four 32-bit banks. The 8-BF16 pad
  // preserves 16-byte cp.async alignment while separating row accesses
  // in the QK and PV fragments. Global KV and arithmetic stay unchanged.
  constexpr int kSharedHd = kHd + 8;
  constexpr int kChunk = 16;  // positions processed per mma pass
  if (nq / nkv != kG || nkv != 2 || hd != kHd) return;
  // Logical rows remain 256 BF16; only their shared-memory stride is padded.
  __shared__ u16 sQ[16 * kSharedHd];  // Query rows 12..15 are zero-padded.
  __shared__ u16 sK[2 * kChunk * kSharedHd];  // Double-buffered prefetch.
  __shared__ u16 sV[2 * kChunk * kSharedHd];
  __shared__ float sS[16 * 16];    // [16, 16] scores (rows 12..15 unused)
  __shared__ u16 sP[kChunk * 16];  // [16 pos, 16] probs (cols 12..15 = 0)
  // sMax/sSum/sAlpha padded to 16 (PV lanes read [group+8] up to 15 for the
  // unused q-heads 12..15; padding avoids an OOB read).
  __shared__ float sMax[16];       // running softmax max per q-head
  __shared__ float sSum[16];       // running softmax denom per q-head
  __shared__ float sAlpha[16];     // this-chunk rescale factor per q-head
  const int t = blockIdx.x;
  const int kvh = blockIdx.y;
  const int warp_id = threadIdx.x >> 5;
  const int lane = threadIdx.x & 31;
  // B2 multi-seq: select this token's sequence KV + page_table slices.
  const u16* kv = d_seq_id
                      ? kv_cache + static_cast<size_t>(d_seq_id[t]) * kv_seq_stride
                      : kv_cache;
  const int* pt = d_seq_id
                      ? page_table + static_cast<size_t>(d_seq_id[t]) * pt_seq_stride
                      : page_table;
  const int* sel = topk + static_cast<size_t>(t) * max_topk;
  const int nsel_total = topk_len[t];
  const float scale = 1.f / sqrtf(static_cast<float>(kHd));
  // Stage 12 query rows into sQ; zero rows 12..15 (mma reads a 16-row tile).
  const int qh0 = kvh * kG;
  for (int i = threadIdx.x; i < 16 * kHd; i += 256) {
    const int m = i / kHd;
    sQ[m * kSharedHd + i % kHd] =
        (m < kG)
            ? q[(static_cast<size_t>(t) * nq + qh0 + m) * kHd + (i % kHd)]
            : 0;
  }
  for (int i = threadIdx.x; i < kChunk * 16; i += 256) sP[i] = 0;
  if (threadIdx.x < 16) {
    sMax[threadIdx.x] = -1e30f;
    sSum[threadIdx.x] = 0.f;
    sAlpha[threadIdx.x] = 0.f;
  }
  __syncthreads();
  // PV output accumulator in REGISTERS (was shared sO with a per-chunk
  // read-modify-write over [12,256] floats — the dominant shared-memory
  // traffic). Warp w owns n-tiles {w, w+8, w+16, w+24}; each lane owns, per
  // n-tile, the 4 mma C values (2 q-heads x 2 dims). acc[j][0..3] mirrors the
  // mma C fragment (c0,c1 = q-head group; c2,c3 = q-head group+8).
  const int pv_group = lane >> 2;
  const int pv_col = (lane & 3) * 2;
  float acc[4][4];
  #pragma unroll
  for (int j = 0; j < 4; ++j) {
    acc[j][0] = 0.f;
    acc[j][1] = 0.f;
    acc[j][2] = 0.f;
    acc[j][3] = 0.f;
  }
  // KV gather is double-buffered: the next chunk's scattered paged-KV is
  // prefetched (cp.async) into the alternate buffer while this chunk's QK/PV
  // computes, hiding the LPDDR5x scatter latency that dominates this kernel.
  // The staged VALUES are identical to the old synchronous gather, so the
  // QK/softmax/PV math is bit-for-bit unchanged.
  auto stage = [&](int base_sel, int chunk, int buf) {
    u16* dK = sK + static_cast<size_t>(buf) * kChunk * kSharedHd;
    u16* dV = sV + static_cast<size_t>(buf) * kChunk * kSharedHd;
    // One 16-byte cp.async per (position, 8-dim group) for K and V: u in
    // [0,32) copies K dims [u*8, u*8+8); u in [32,64) copies the V dims.
    for (int i = threadIdx.x; i < chunk * 64; i += 256) {
      const int c = i >> 6;
      const int u = i & 63;
      const int is_v = u >> 5;
      const int d8 = (u & 31) * 8;
      const int p = sel[base_sel + c];
      const int sp = p < 0 ? 0 : p;
      const int slot = pt[sp] * kKvPageSize + (sp % kKvPageSize);
      const size_t g = (static_cast<size_t>(slot) * nkv + kvh) * (2 * kHd) +
                       (is_v ? kHd : 0) + d8;
      CpAsync16((is_v ? dV : dK) + c * kSharedHd + d8, kv + g);
    }
    // Zero the [chunk, kChunk) tail (only the final partial chunk needs it);
    // finite so 0*x=0 in the PV mma (uninitialised shared could be a NaN).
    for (int i = threadIdx.x; i < (kChunk - chunk) * kHd; i += 256) {
      const int c = chunk + (i / kHd);
      const int d = i - (i / kHd) * kHd;
      dK[c * kSharedHd + d] = 0;
      dV[c * kSharedHd + d] = 0;
    }
    CpAsyncCommit();
  };
  int nsel = 0;
  int buf = 0;
  if (nsel_total > 0) stage(0, min(kChunk, nsel_total), 0);
  while (nsel < nsel_total) {
    const int chunk = min(kChunk, nsel_total - nsel);
    const int next_nsel = nsel + chunk;
    // Prefetch the next chunk into the alternate buffer (overlaps this chunk's
    // compute), then wait for THIS chunk's gather (issued last iteration /
    // prologue) to land. wait_group<1> keeps the next prefetch in flight.
    if (next_nsel < nsel_total) {
      stage(next_nsel, min(kChunk, nsel_total - next_nsel), buf ^ 1);
      CpAsyncWait<1>();
    } else {
      CpAsyncWait<0>();
    }
    __syncthreads();
    const u16* bK = sK + static_cast<size_t>(buf) * kChunk * kSharedHd;
    const u16* bV = sV + static_cast<size_t>(buf) * kChunk * kSharedHd;
    // ---- QK^T (warps 0-1, one n-tile each): sS[16,16] = sQ @ sK^T via mma. --
    // mma m16n8k16: A = sQ (m=qh, k=dim), B = sK^T (B[k][n]=sK[pos=n][dim=k]).
    // 16 k-tiles per n-tile; the 2 n-tiles (16 positions) run on warps 0 and 1
    // in parallel (was warp 0 serial). Bit-identical: disjoint output columns.
    if (warp_id < kChunk / 8) {
      const int nt = warp_id;
      const int nb = nt * 8;
      const int group = lane >> 2;     // qh row (0..7, and +8)
      const int k0 = (lane & 3) * 2;   // k-pair base
      const int col = (lane & 3) * 2;  // pos-pair base (C fragment)
      float c0 = 0.f, c1 = 0.f, c2 = 0.f, c3 = 0.f;
      for (int kt = 0; kt < kHd / 16; ++kt) {
        const int kb = kt * 16;
        const u16* qa = sQ + group * kSharedHd + kb + k0;
        const u16* qa8 = sQ + (group + 8) * kSharedHd + kb + k0;
        uint32_t a0 = *reinterpret_cast<const uint32_t*>(qa);
        uint32_t a1 = *reinterpret_cast<const uint32_t*>(qa8);
        uint32_t a2 = *reinterpret_cast<const uint32_t*>(qa + 8);
        uint32_t a3 = *reinterpret_cast<const uint32_t*>(qa8 + 8);
        const u16* kbp = bK + (nb + group) * kSharedHd + kb + k0;
        uint32_t b0 = *reinterpret_cast<const uint32_t*>(kbp);
        uint32_t b1 = *reinterpret_cast<const uint32_t*>(kbp + 8);
        MmaBf16(c0, c1, c2, c3, a0, a1, a2, a3, b0, b1);
      }
      sS[group * 16 + nb + col] = c0;
      sS[group * 16 + nb + col + 1] = c1;
      sS[(group + 8) * 16 + nb + col] = c2;
      sS[(group + 8) * 16 + nb + col + 1] = c3;
    }
    __syncthreads();
    // Large-T: distribute independent exponentials over (head, position).
    // Keep the original ordered max and FP32 denominator accumulation.
    // The unrounded probabilities must survive separately from BF16 sP.
    if constexpr (ParallelSoftmax) {
      __shared__ float probabilities[kG * kChunk];
      if (threadIdx.x < kG) {
        const int qrow = threadIdx.x;
        const float m_old = sMax[qrow];
        float mx = m_old;
        for (int p = 0; p < chunk; ++p)
          mx = fmaxf(mx, sS[qrow * 16 + p] * scale);
        sAlpha[qrow] = expf(m_old - mx);
        sMax[qrow] = mx;
      }
      __syncthreads();
      if (threadIdx.x < kG * kChunk) {
        const int qrow = threadIdx.x / kChunk;
        const int p = threadIdx.x % kChunk;
        const float mx = sMax[qrow];
        const float pr = (p < chunk) ? expf(sS[qrow * 16 + p] * scale - mx)
                                     : 0.f;
        probabilities[qrow * kChunk + p] = pr;
        sP[p * 16 + qrow] = FloatToBf16(pr);
      }
      __syncthreads();
      if (threadIdx.x < kG) {
        const int qrow = threadIdx.x;
        // Preserve the parent's separate FMUL rounding before the first add.
        // Otherwise nvcc contracts this multiply and probabilities[0] to FMA.
        float s = __fmul_rn(sSum[qrow], sAlpha[qrow]);
        // Include the zero tail, in the original left-to-right order. A tree
        // reduction or summing sP would change the numerical contract.
        for (int p = 0; p < kChunk; ++p)
          s += probabilities[qrow * kChunk + p];
        sSum[qrow] = s;
      }
    } else if (threadIdx.x < kG) {
      const int qrow = threadIdx.x;
      const float m_old = sMax[qrow];
      float mx = m_old;
      for (int p = 0; p < chunk; ++p)
        mx = fmaxf(mx, sS[qrow * 16 + p] * scale);
      const float alpha = expf(m_old - mx);
      sAlpha[qrow] = alpha;
      float s = sSum[qrow] * alpha;
      for (int p = 0; p < kChunk; ++p) {
        const float pr = (p < chunk) ? expf(sS[qrow * 16 + p] * scale - mx)
                                     : 0.f;
        sP[p * 16 + qrow] = FloatToBf16(pr);
        s += pr;
      }
      sSum[qrow] = s;
      sMax[qrow] = mx;
    }
    __syncthreads();
    // ---- PV: acc += sP^T[16,16] @ sV[16,256] via mma (register accum). ----
    // out[qh][d] = sum_pos P[pos][qh] * V[pos][d].
    // mma: A = sP^T (m=qh, k=pos): A[qh][pos] = sP[pos*16 + qh] (stride 16).
    //      B = sV (k=pos, n=d): B[pos][d] = sV[pos*hd + d] (stride hd in k).
    // Warp w handles n-tiles w, w+8, w+16, w+24 (disjoint 8-dim slices); the
    // running accumulator lives in registers (acc[j]) — no shared sO traffic.
    {
      const int k0 = (lane & 3) * 2;   // pos-pair base (mma K)
      const float ag = sAlpha[pv_group];
      const float ag8 = sAlpha[pv_group + 8];
      // A-fragment is the same for every n-tile (depends only on q-heads/pos).
      const u16* pa = sP + pv_group;
      const u16* pa8 = sP + pv_group + 8;
      uint32_t a0 = static_cast<uint32_t>(pa[k0 * 16]) |
                    (static_cast<uint32_t>(pa[(k0 + 1) * 16]) << 16);
      uint32_t a1 = static_cast<uint32_t>(pa8[k0 * 16]) |
                    (static_cast<uint32_t>(pa8[(k0 + 1) * 16]) << 16);
      uint32_t a2 = static_cast<uint32_t>(pa[(k0 + 8) * 16]) |
                    (static_cast<uint32_t>(pa[(k0 + 9) * 16]) << 16);
      uint32_t a3 = static_cast<uint32_t>(pa8[(k0 + 8) * 16]) |
                    (static_cast<uint32_t>(pa8[(k0 + 9) * 16]) << 16);
      #pragma unroll
      for (int j = 0; j < 4; ++j) {
        const int nt = warp_id + j * 8;
        const int nb = nt * 8;
        // B-fragment: elements strided by hd in sV -> scalar load + pack.
        const u16* vb = bV + nb + pv_group;
        uint32_t b0 = static_cast<uint32_t>(vb[k0 * kSharedHd]) |
                      (static_cast<uint32_t>(vb[(k0 + 1) * kSharedHd]) << 16);
        uint32_t b1 = static_cast<uint32_t>(vb[(k0 + 8) * kSharedHd]) |
                      (static_cast<uint32_t>(vb[(k0 + 9) * kSharedHd]) << 16);
        float c0 = 0.f, c1 = 0.f, c2 = 0.f, c3 = 0.f;
        MmaBf16(c0, c1, c2, c3, a0, a1, a2, a3, b0, b1);
        // Fold the per-chunk online-softmax rescale into the register accum.
        acc[j][0] = acc[j][0] * ag + c0;
        acc[j][1] = acc[j][1] * ag + c1;
        acc[j][2] = acc[j][2] * ag8 + c2;
        acc[j][3] = acc[j][3] * ag8 + c3;
      }
    }
    __syncthreads();
    nsel = next_nsel;
    buf ^= 1;
  }
  // ---- Normalize + fused gate + write out (from register accumulators). ----
  // Lane (warp w, lane L) owns q-heads group=L/4 and group+8, dims nb+col,
  // nb+col+1 for n-tiles nt = w + j*8 (j=0..3).
  {
    const float lg = sSum[pv_group];
    const float lg8 = sSum[pv_group + 8];
    const int qh_a = qh0 + pv_group;
    const int qh_b = qh0 + pv_group + 8;
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
      const int nb = (warp_id + j * 8) * 8;
      const int d = nb + pv_col;
      // q-head group (always valid, 0..7 < 12).
      {
        const size_t o0 = (static_cast<size_t>(t) * nq + qh_a) * kHd + d;
        float v0 = (lg > 0.f) ? acc[j][0] / lg : acc[j][0];
        float v1 = (lg > 0.f) ? acc[j][1] / lg : acc[j][1];
        const float g0 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0])));
        const float g1 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0 + 1])));
        out[o0] = FloatToBf16(Bf16ToFloat(FloatToBf16(v0)) * g0);
        out[o0 + 1] = FloatToBf16(Bf16ToFloat(FloatToBf16(v1)) * g1);
      }
      // q-head group+8 (valid only for group 0..3 -> qh 8..11).
      if (pv_group + 8 < kG) {
        const size_t o0 = (static_cast<size_t>(t) * nq + qh_b) * kHd + d;
        float v0 = (lg8 > 0.f) ? acc[j][2] / lg8 : acc[j][2];
        float v1 = (lg8 > 0.f) ? acc[j][3] / lg8 : acc[j][3];
        const float g0 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0])));
        const float g1 = 1.f / (1.f + expf(-Bf16ToFloat(gate[o0 + 1])));
        out[o0] = FloatToBf16(Bf16ToFloat(FloatToBf16(v0)) * g0);
        out[o0 + 1] = FloatToBf16(Bf16ToFloat(FloatToBf16(v1)) * g1);
      }
    }
  }
}

}
// Appended to verbatim parent, failed, and repaired sparse kernel bodies.
#define CUDA_OK(expression)                         \
  do {                                              \
    const cudaError_t error = (expression);         \
    if (error != cudaSuccess) {                     \
      std::fprintf(stderr, "%s: %s\n", #expression, \
                   cudaGetErrorString(error));      \
      return 1;                                     \
    }                                               \
  } while (0)

// Isolate the denominator's compiled arithmetic. The independent host oracle
// rounds the product to FP32 before the 16 ordered additions, as parent SASS.
template <bool SeparateMultiply>
__global__ void Denominator(const float* input, float* output, int count) {
  const int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= count) return;
  const float* values = input + i * 18;
  float s;
  if constexpr (SeparateMultiply)
    s = __fmul_rn(values[0], values[1]);
  else
    s = values[0] * values[1];
  for (int p = 0; p < 16; ++p) s += values[p + 2];
  output[i] = s;
}

int main() {
  constexpr int kRows = 64;
  constexpr int kNq = 24;
  constexpr int kNkv = 2;
  constexpr int kHd = 256;
  constexpr int kPositions = 4096;
  constexpr int kSequences = 3;
  constexpr int kSelected = 2052;
  constexpr size_t kGuard = 32;
  const std::array<int, 12> lengths = {0,  1,  3,  15,   16,   17,
                                       31, 32, 33, 2048, 2049, 2051};
  const size_t kv_stride = kPositions * kNkv * 2 * kHd;
  const size_t output_count = kRows * kNq * kHd;
  const size_t guarded_count = output_count + 2 * kGuard;
  std::vector<uint16_t> q(output_count), gate(output_count);
  std::vector<uint16_t> kv(kSequences * kv_stride);
  std::vector<int> pages(kSequences * kPositions);
  std::vector<int> selected(kRows * kSelected), sequence(kRows), lens(kRows);
  std::vector<uint16_t> before(guarded_count), bad(guarded_count),
      fixed(guarded_count);
  uint32_t state = 20260921;
  auto fill = [&](std::vector<uint16_t>* data) {
    for (auto& bits : *data) {
      state = state * 1664525u + 1013904223u;
      const float value = (static_cast<int>(state >> 16) - 32768) / 32768.f;
      const __nv_bfloat16 bf = __float2bfloat16_rn(value);
      std::memcpy(&bits, &bf, sizeof(bits));
    }
  };
  fill(&q);
  fill(&gate);
  fill(&kv);
  for (int seq = 0; seq < kSequences; ++seq)
    for (int p = 0; p < kPositions; ++p)
      pages[seq * kPositions + p] = ((p / 16) * 73 + seq * 19) % 256;
  for (int row = 0; row < kRows; ++row) {
    sequence[row] = (row * 2 + 1) % kSequences;
    for (int i = 0; i < kSelected; ++i)
      selected[row * kSelected + i] = (i * 37 + row * 113 + 5) % kPositions;
  }
  uint16_t *dq, *dg, *dkv, *dbefore, *dbad, *dfixed;
  int *dpages, *dselected, *dsequence, *dlens;
  CUDA_OK(cudaMalloc(&dq, q.size() * 2));
  CUDA_OK(cudaMalloc(&dg, gate.size() * 2));
  CUDA_OK(cudaMalloc(&dkv, kv.size() * 2));
  CUDA_OK(cudaMalloc(&dbefore, guarded_count * 2));
  CUDA_OK(cudaMalloc(&dbad, guarded_count * 2));
  CUDA_OK(cudaMalloc(&dfixed, guarded_count * 2));
  CUDA_OK(cudaMalloc(&dpages, pages.size() * sizeof(int)));
  CUDA_OK(cudaMalloc(&dselected, selected.size() * sizeof(int)));
  CUDA_OK(cudaMalloc(&dsequence, sequence.size() * sizeof(int)));
  CUDA_OK(cudaMalloc(&dlens, lens.size() * sizeof(int)));
  CUDA_OK(cudaMemcpy(dq, q.data(), q.size() * 2, cudaMemcpyHostToDevice));
  CUDA_OK(cudaMemcpy(dg, gate.data(), gate.size() * 2, cudaMemcpyHostToDevice));
  CUDA_OK(cudaMemcpy(dkv, kv.data(), kv.size() * 2, cudaMemcpyHostToDevice));
  CUDA_OK(cudaMemcpy(dpages, pages.data(), pages.size() * sizeof(int),
                     cudaMemcpyHostToDevice));
  CUDA_OK(cudaMemcpy(dselected, selected.data(), selected.size() * sizeof(int),
                     cudaMemcpyHostToDevice));
  CUDA_OK(cudaMemcpy(dsequence, sequence.data(), sequence.size() * sizeof(int),
                     cudaMemcpyHostToDevice));
  size_t checked = 0, bad_differences = 0;
  int launches = 0;
  for (bool pooled : {false, true}) {
    for (int rows : {1, 3, 8, 9, 12, kRows}) {
      for (int first : {0, 5, 9}) {
        for (int row = 0; row < rows; ++row)
          lens[row] = lengths[(first + row) % lengths.size()];
        CUDA_OK(cudaMemcpy(dlens, lens.data(), rows * sizeof(int),
                           cudaMemcpyHostToDevice));
        CUDA_OK(cudaMemset(dbefore, 0xa5, guarded_count * 2));
        CUDA_OK(cudaMemset(dbad, 0x5a, guarded_count * 2));
        CUDA_OK(cudaMemset(dfixed, 0xc3, guarded_count * 2));
        const int* seq_ids = pooled ? dsequence : nullptr;
        parent::SparseAttentionKernel<<<dim3(rows, kNkv), 256>>>(
            dq, dkv, dpages, dselected, dlens, dbefore + kGuard, dg, kNq, kNkv,
            kHd, kSelected, seq_ids, kv_stride, kPositions);
        CUDA_OK(cudaGetLastError());
#define LAUNCH_VARIANTS(large)                                                \
  failed::SparseAttentionKernel<large><<<dim3(rows, kNkv), 256>>>(            \
      dq, dkv, dpages, dselected, dlens, dbad + kGuard, dg, kNq, kNkv, kHd,   \
      kSelected, seq_ids, kv_stride, kPositions);                             \
  CUDA_OK(cudaGetLastError());                                                \
  repaired::SparseAttentionKernel<large><<<dim3(rows, kNkv), 256>>>(          \
      dq, dkv, dpages, dselected, dlens, dfixed + kGuard, dg, kNq, kNkv, kHd, \
      kSelected, seq_ids, kv_stride, kPositions);                             \
  CUDA_OK(cudaGetLastError())
        if (rows > 8) {
          LAUNCH_VARIANTS(true);
        } else {
          LAUNCH_VARIANTS(false);
        }
#undef LAUNCH_VARIANTS
        CUDA_OK(cudaMemcpy(before.data(), dbefore, guarded_count * 2,
                           cudaMemcpyDeviceToHost));
        CUDA_OK(cudaMemcpy(bad.data(), dbad, guarded_count * 2,
                           cudaMemcpyDeviceToHost));
        CUDA_OK(cudaMemcpy(fixed.data(), dfixed, guarded_count * 2,
                           cudaMemcpyDeviceToHost));
        const size_t count = rows * kNq * kHd;
        for (size_t i = 0; i < guarded_count; ++i) {
          if (i < kGuard || i >= kGuard + count) {
            if (before[i] != 0xa5a5 || bad[i] != 0x5a5a || fixed[i] != 0xc3c3) {
              std::fprintf(stderr, "FAIL output canary\n");
              return 1;
            }
          } else {
            bad_differences += before[i] != bad[i];
            if (before[i] != fixed[i] || (fixed[i] & 0x7f80) == 0x7f80) {
              std::fprintf(stderr,
                           "FAIL fixed pooled=%d rows=%d first=%d i=%zu "
                           "old=%04x new=%04x\n",
                           pooled, rows, first, i, before[i], fixed[i]);
              return 1;
            }
          }
        }
        checked += count;
        ++launches;
      }
    }
  }
  constexpr int kCases = 65536;
  std::vector<float> inputs(kCases * 18), oracle(kCases), fused(kCases),
      exact(kCases);
  for (int i = 0; i < kCases; ++i) {
    float* values = inputs.data() + i * 18;
    for (int j = 0; j < 18; ++j) {
      state = state * 1664525u + 1013904223u;
      values[j] = (state >> 8) / 16777216.f;
    }
    values[0] *= 2048.f;
    volatile float product = values[0] * values[1];
    volatile float sum = product;
    for (int j = 0; j < 16; ++j) sum = sum + values[j + 2];
    oracle[i] = sum;
  }
  float *din, *dfused, *dexact;
  CUDA_OK(cudaMalloc(&din, inputs.size() * sizeof(float)));
  CUDA_OK(cudaMalloc(&dfused, kCases * sizeof(float)));
  CUDA_OK(cudaMalloc(&dexact, kCases * sizeof(float)));
  CUDA_OK(cudaMemcpy(din, inputs.data(), inputs.size() * sizeof(float),
                     cudaMemcpyHostToDevice));
  Denominator<false><<<(kCases + 255) / 256, 256>>>(din, dfused, kCases);
  CUDA_OK(cudaGetLastError());
  Denominator<true><<<(kCases + 255) / 256, 256>>>(din, dexact, kCases);
  CUDA_OK(cudaGetLastError());
  CUDA_OK(cudaMemcpy(fused.data(), dfused, kCases * sizeof(float),
                     cudaMemcpyDeviceToHost));
  CUDA_OK(cudaMemcpy(exact.data(), dexact, kCases * sizeof(float),
                     cudaMemcpyDeviceToHost));
  size_t fused_differences = 0;
  for (int i = 0; i < kCases; ++i) {
    fused_differences += std::memcmp(&oracle[i], &fused[i], sizeof(float)) != 0;
    if (std::memcmp(&oracle[i], &exact[i], sizeof(float))) {
      std::fprintf(stderr, "FAIL independent denominator i=%d\n", i);
      return 1;
    }
  }
  for (uint16_t* p : {dq, dg, dkv, dbefore, dbad, dfixed}) CUDA_OK(cudaFree(p));
  for (int* p : {dpages, dselected, dsequence, dlens}) CUDA_OK(cudaFree(p));
  for (float* p : {din, dfused, dexact}) CUDA_OK(cudaFree(p));
  if (!bad_differences || !fused_differences) {
    std::fprintf(stderr, "FAIL failed candidate/rounding not reproduced\n");
    return 1;
  }
  std::printf(
      "PASS kernel_cases=%d finite_bf16=%zu repaired_bit_exact=1 canaries=1 "
      "failed_bf16_differences=%zu\n",
      launches, checked, bad_differences);
  std::printf(
      "PASS fp32_denominators=%d repaired_bit_exact=1 fused_differences=%zu\n",
      kCases, fused_differences);
  return 0;
}

"""Qualify exact actual MCP tasks with preserved failed original attempts."""
from pathlib import Path
import copy,fcntl,json,subprocess,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;sys.path.insert(0,str(R))
from tools.serve_recovery import ledger,profile_contract,profile_evidence,profile_record,bundle
from tools.serve_recovery import profile_mcp_evidence as m,profile_mcp_reuse as reuse,profile_mcp_codec as codec
from tools.serve_recovery.profile_mcp_source import REVIEW,OBSERVED,SOURCES
from tools.serve_recovery import profile_acceptance as full
from tools.serve_responses import encryption_acceptance as encrypted
from tools.serve_ops import contracts
from tools.serve_service.package import read,save,sha,require
O=W/'qualified-profiles-02';O.mkdir(mode=0o700)
require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'commit qualification implementation first')
cpu=W/'qualification-cpu-03';require(read(cpu/'result.json')['status']=='PASS','targeted CPU missing')
for n,h in read(cpu/'plan.json')['sources'].items():require(sha(R/n)==h,'CPU source changed')
latest=read(W/'sdk-business-04/plan.json')
for n,h in {**latest['reviewed_sources'],**latest['native_assets'],**latest['protected']}.items():require(sha(R/n)==h,'runtime/assets/default drift: '+n)
require(sha(latest['binary'])==REVIEW['candidate_binary'] and latest['identity']['protocol_sha256']==REVIEW['candidate_protocol'],'runtime identity')
require(sha(W/'sdk-business-04/acceptance.json')==REVIEW['actual_fault_acceptance_sha256'],'actual finalizer identity')
bundle.check_assets(latest['model'],latest['model_assets'])
previous=R/'.q4t-work/serve-realtime-duplex-20261120/composed-profiles-01/qualified';oldregistry=read(previous/'registry.json');require(sha(previous/'registry.json')==REVIEW['prior_registry_sha256'],'prior registry')
indexes={};archived={}
for title in ('serve-realtime-mcp-sdk-followup-cpu-20261120','serve-realtime-mcp-lifecycle-cpu-20261120','serve-realtime-mcp-remaining-http-20261120'):
 p=R/'docs/evidence'/title/'index.json';index=read(p);require(sha(p.parent/'records.tar.gz')==index['archive_sha256'],'archive bytes changed')
 indexes[str(p)]=sha(p)
 for n,v in index['files'].items():archived.setdefault(n,set()).add(v['sha256'])
def original(p):
 n=str(p.relative_to(W));h=sha(p);require(h in archived.get(n,()),'actual raw file not archived: '+n);return h
rows=[];raw_files={};cleanups=[]
for stage in ('sdk-business-02','sdk-business-03','sdk-business-04'):
 path=W/stage;result=read(path/'result.json');exit_record=read(path/'lease/exit.json');success=stage=='sdk-business-04'
 require(result['status']==('PASS_REALTIME_MCP_PRIMARY_LIGHT' if success else 'FAILED') and
         exit_record['status']==('COMPLETED' if success else 'COMMAND_FAILED') and
         exit_record['child_returncode']==(0 if success else 1) and
         exit_record['compute_backend']=='nvml' and exit_record['lease_inherited_by_child'],'original stage/guard result changed')
 queries=[json.loads(l) for l in (path/'lease/nvml-queries.jsonl').read_text().splitlines()]
 events=[json.loads(l) for l in (path/'lease/events.jsonl').read_text().splitlines()]
 require(queries and all(q['status']=='OK' and q['returncode']==0 and not q['observed_errors'] for q in queries) and
         not any(e.get('conflicts') for e in events) and events[-1]['event']=='lease_released','actual environment failed')
 cs=[path/'cleanup.json']+([path/'primary-cleanup.json'] if stage=='sdk-business-03' else [])
 for p in cs:
  v=read(p);require(v['remaining']==[] and v['model_exit']==0 and v['ports_released'] and v['lease_continuously_held'],'owned cleanup failed');cleanups.append(v)
 require(len(cs)==result['counts']['starts'],'actual start count')
 jobs=sum(len(read(p)['responses']) for p in path.glob('*.sdk.json'))
 for p in [path/'plan.json',path/'result.json',*cs,path/'lease/exit.json',path/'lease/events.jsonl',path/'lease/nvml-queries.jsonl']:
  raw_files[str(p.relative_to(W))]=original(p)
 rows.append(dict(stage=stage,original_business_status=result['status'],guard_status=exit_record['status'],actual_starts=result['counts']['starts'],actual_jobs=jobs,reserved_jobs=result['counts']['chats'],seconds=result['seconds'],nvml_queries=len(queries),cleanup_complete=True))
guard=encrypted.foreground.base.lifecycle.guard;processes=guard.processes()
require(not any(processes.get(int(pid),{}).get('start_ticks')==v['start_ticks'] for c in cleanups for pid,v in c['owned'].items()),'owned process remains')
with guard.common_lock().open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
save(O/'environment-composition.json',dict(stages=rows,raw_files=raw_files,archives=indexes,original_failures_preserved=True,new_gpu_starts=0))
environment=dict(status='PASS',env_abort=False,all_queries_ok=True,nvml_queries=sum(r['nvml_queries'] for r in rows),lease_result_sha256=sha(O/'environment-composition.json'),cleanup_complete=True)
plan=copy.deepcopy(latest);plan.update(output=str(O),targeted_format='q4t-reviewed-mcp-composition-v1',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),scope='Actual MCP tasks plus unchanged reviewed business; no new GPU or model quality repair',sources={n:sha(R/n) for n in bundle.SOURCES},observed_source_review=copy.deepcopy(REVIEW))
plan['sources'].update(latest['reviewed_sources']);plan['sources'].update({str(cpu/n):sha(cpu/n) for n in ('plan.json','result.json')});plan['sources'][str(Path(__file__))]=sha(Path(__file__))
save(O/'plan.json',plan);qualified=O/'qualified';qualified.mkdir(mode=0o700)
registry=dict(format=profile_contract.FORMAT,identity=plan['identity'],profiles=plan['profiles'],qualifications={})
for name in profile_contract.NAMES:
 p=previous/(name+'.json');require(sha(p)==SOURCES[name]['record_sha256'],'prior qualified leaf changed')
 old=profile_record.read(p);profile_evidence.validate(old,oldregistry,name,sha(p))
 data=read(W/'qualification-inputs-01'/(name+'-input.json'));require(ledger.digest(data)==OBSERVED[name]['data_digest'],'actual input changed')
 for label,files in OBSERVED[name]['leaves'].items():
  stage='sdk-business-02' if name=='primary' and label=='original' else 'sdk-business-04' if name=='light' and label=='repair' else 'sdk-business-03'
  for n,h in files.items():require(original(W/stage/n)==h,'reviewed actual leaf drift')
 business=copy.deepcopy(old['business']);business['realtime_mcp']=dict(format=m.FORMAT,profile=name,source_review_sha256=ledger.digest(REVIEW),witness=codec.pack(data));m.business(business['realtime_mcp'])
 stage=W/('sdk-business-03' if name=='primary' else 'sdk-business-04')
 caps=read(stage/(name+'-capabilities.json'));config=read(stage/(name+'-config.json'))
 require(caps['protocol_source_sha256']==config['protocol_source_sha256']==REVIEW['candidate_protocol'],'actual config is not candidate')
 for stem in ('-capabilities.json','-config.json'):raw_files[str((stage/(name+stem)).relative_to(W))]=original(stage/(name+stem))
 save(O/(name+'-capabilities.json'),caps);save(O/(name+'-config.json'),config)
 value=reuse.attach(dict(format=profile_evidence.MCP_FORMAT,profile=name,identity=plan['identity'],capacity=plan['profiles'][name],capabilities=caps,configuration=contracts.configuration(config,version=5),startup_memory=config['startup_memory']['checks']['before_allocations'],business=business,environment=environment))
 p=qualified/(name+'.json');profile_record.save(p,value)
 registry['qualifications'][name]=profile_contract.qualification(name,value['capacity'],value['identity'],value['capabilities'],value['configuration'],value['startup_memory'],sha(p))
profile_contract.validate(registry)
for name in profile_contract.NAMES:
 p=qualified/(name+'.json');profile_evidence.validate(profile_record.read(p),registry,name,sha(p))
profile_contract.capability_pair(read(O/'primary-capabilities.json'),read(O/'light-capabilities.json'))
save(O/'source-composition.json',dict(review=REVIEW,observed=OBSERVED,raw_files=raw_files,archives=indexes))
save(qualified/'registry.json',registry)
value=dict(status='ACCEPT_MCP_PRIMARY_LIGHT',registry_sha256=sha(qualified/'registry.json'),source_composition_sha256=sha(O/'source-composition.json'),environment=environment,new_gpu_starts=0,actual_model_starts=sum(r['actual_starts'] for r in rows),actual_jobs=sum(r['actual_jobs'] for r in rows),original_failures_preserved=True,original_model_quality_status='FAIL',model_quality_repaired=False,original_primary_final_metrics_missing=True,default_unchanged=True,managed_recovery_accepted=False,full_matrix=False,master_active=True,profile_bytes={n:(qualified/(n+'.json')).stat().st_size for n in profile_contract.NAMES})
save(O/'acceptance.json',value);print(json.dumps(value))

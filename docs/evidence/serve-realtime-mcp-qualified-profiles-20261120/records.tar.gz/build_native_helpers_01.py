from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
from tools.serve_recovery import bundle
W=Path(__file__).resolve().parent;O=W/'native-build-01';B=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build';O.mkdir(mode=0o700);(O/'before').mkdir()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
protected={str(ROOT/n):sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
engine=sha(B/'q4t');cache=sha(B/'CMakeCache.txt');compiled=sha(B/'generated/q4t/server/chat_protocol_sources.json')
names=['q4t-guardian','q4t-cuda-probe','q4t-ingress','q4t-device-control'];previous={}
for n in names:
 p=B/n;previous[n]=sha(p);os.link(p,O/'before'/n);p.unlink()
archives=['libq4t_guardian_journal.a','libq4t_device_admission.a','libq4t_device_filter.a','libq4t_guardian_process.a','libq4t_ingress_access.a']
detached=[]
for n in archives:
 p=B/n
 if p.is_file() and not p.is_symlink() and p.stat().st_nlink>1:
  h=sha(p);tmp=p.with_name(p.name+'.helper-detach');assert not tmp.exists();shutil.copy2(p,tmp);assert sha(tmp)==h;tmp.replace(p);detached.append(n)
cmd=['cmake','--build',str(B),'--target',*[n.replace('-','_') for n in names],'--parallel','4']
sources={n:sha(ROOT/n) for n in sorted(bundle.NATIVE_SOURCES)}
save('plan.json',dict(scope='Necessary native helper build for current CMake identity; no model execution',command=cmd,sources=sources,protected=protected,previous_binaries=previous,engine_sha256=engine,cache_sha256=cache,compiled_sha256=compiled,detached_dependency_archives=detached,gpu_actions=0))
start=time.monotonic()
with (O/'build.log').open('w') as log:code=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
warnings=[s for s in (O/'build.log').read_text().splitlines() if 'warning:' in s]
unchanged=all(sha(n)==h for n,h in protected.items()) and sha(B/'q4t')==engine and sha(B/'CMakeCache.txt')==cache and sha(B/'generated/q4t/server/chat_protocol_sources.json')==compiled
result=dict(status='PASS' if code==0 and not warnings and unchanged else 'FAIL',returncode=code,seconds=time.monotonic()-start,warnings=warnings,binaries={n:sha(B/n) for n in names if (B/n).is_file()},sources_unchanged=all(sha(ROOT/n)==h for n,h in sources.items()),engine_cache_protocol_default_unchanged=unchanged,gpu_actions=0);save('result.json',result);print(json.dumps(result),flush=True)

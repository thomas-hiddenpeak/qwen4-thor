from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;Q=W/'qualified-profiles-02';O=R/'docs/evidence/serve-realtime-mcp-qualified-profiles-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
a=read(Q/'acceptance.json');assert a['status']=='ACCEPT_MCP_PRIMARY_LIGHT'
files={'archive_profiles_02.py':Path(__file__),'qualify_profiles_02.py':W/'qualify_profiles_02.py','build_native_helpers_01.py':W/'build_native_helpers_01.py'}
for p in Q.rglob('*.json'):files['qualified-profiles-02/'+str(p.relative_to(Q))]=p
for n in ('plan.json','result.json','build.log'):files['native-build-01/'+n]=W/'native-build-01'/n
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as archive:
 for m in archive:assert hashlib.sha256(archive.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
a.update(native_build_seconds=read(W/'native-build-01/result.json')['seconds'],native_build_warnings=0,native_binaries_unchanged=True);save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime MCP主轻资格已签发

2026-11-20。完整v21主轻资格通过校验，登记表SHA256：
`5a44b4a3df68c45cb34f0b0758b51aeb4acd556a98d549db3992a106cb159fa3`。
当前MCP引擎`a84fda9519bdc19d20a725e9c259a74bea89c8c6e70d133876b3e2007c1ebf7b`，
协议`78696063ccaaddf09704dbed2566122fd92824ae0d356057a90e5cb35b6df2c7`。
主轻实际能力声明、启动内存与配置均来自当前引擎，没有投影成未测身份。

保留既有全部业务叶，新增MCP叶绑定原始SDK/远端实读与补验。两次
原始质量失败、首次主档缺最后metrics、原驱动预留与实际计数差异
均明确保留，不称模型质量已修复。累计4模型/10次实际生成，202次
NVML正常；环境组合接受不改写原COMMAND_FAILED业务结果。

主档5631868字节，轻档8340821字节，均在原8MiB上限内；MCP新增
叶解压上限2MiB。原资格门失败文件不获准使用，只有本目录登记表和
对应完整记录可供封包。新增GPU 0，未重跑音频/视觉或完整矩阵。
必要原生helper构建1.768秒/零警告，四个二进制与当前默认完全相同；
当前CMake来源绑定更新，实际引擎、构建cache、协议及默认未改变。

下一步同能力候选/保留包、MCP原生服务恢复短验和可回退发行。
默认rev396 STOPPED保持，总目标active；本记录不代表服务恢复或main
已完成。[接受记录](acceptance.json) · [索引](index.json) ·
[完整资格与来源](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();old='接着重新离线生成；不重跑GPU，恢复/发行继续。';new='''[主轻完整资格已签发](evidence/serve-realtime-mcp-qualified-profiles-20261120/README.md)，
registry为`5a44b4a3df68c45cb34f0b0758b51aeb4acd556a98d549db3992a106cb159fa3`。
主/轻5631868/8340821字节，仍限8MiB；原失败保持，新增GPU 0。
原生helper重建零警告、二进制未改；接着同能力封包和恢复/发行。''';assert old in s;p.write_text(s.replace(old,new))
p=R/'docs/log/2026-11-20.md';p.write_text('''## MCP主轻完整资格签发，原生helper来源更新

日期：2026-11-20。

做了什么：[主轻完整资格通过](../evidence/serve-realtime-mcp-qualified-profiles-20261120/README.md)，
registry为5a44b4a3，分别5631868/8340821字节。旧业务逐叶保留，新增
MCP实际证据与原失败绑定当前引擎/协议/配置；环境组合接受明确区分
原业务失败，没有追认模型质量。必要helper构建1.768秒/零警告，四个
helper二进制未变，engine/cache/protocol/default全部保持。

为什么：将实际MCP业务纳入完整可核验的主轻资格，同时保留有界
元数据、旧版读取和所有已知限制，不能以组件通过代替发行准备。

下一步：准备同能力候选/保留包，推进MCP服务恢复短验与可回退发行，
总目标active，默认rev396 STOPPED保持。

'''+p.read_text())
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n[完整主轻资格已签发](evidence/serve-realtime-mcp-qualified-profiles-20261120/README.md)，
registry 5a44b4a3，当前MCP引擎/协议/实际配置绑定；原失败继续保留。
原生helper必要构建零警告且二进制不变，新增GPU 0。继续封包、
服务恢复与发行，不在资格阶段停止总目标。\n''')
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['realtime_progress']['mcp_20261120'].update(state='primary_light_mcp_profiles_qualified_preparing_managed_recovery',qualified_profiles=a,qualified_profiles_evidence='evidence/serve-realtime-mcp-qualified-profiles-20261120/README.md');save(p,d)
print(json.dumps({k:a[k] for k in ('status','registry_sha256','profile_bytes','native_build_seconds')}))

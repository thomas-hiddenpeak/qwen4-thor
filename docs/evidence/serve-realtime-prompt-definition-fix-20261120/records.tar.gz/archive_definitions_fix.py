from pathlib import Path
import json,hashlib,tarfile,os,fcntl
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=W/'business-01';O=R/'docs/evidence/serve-realtime-prompt-definition-fix-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
r=read(B/'run/result.json');sdk=read(B/'run/alpha.sdk.json');clean=read(B/'run/cleanup.json');cpu=read(W/'definitions-cpu-01/result.json');build=read(W/'definitions-build-01/result.json');plan=read(W/'definitions-plan-01.json')
assert r['status']=='FAIL' and sdk['response_creates']==0 and sdk['http_calls']==1 and clean['model_exit']==0 and clean['remaining']==[] and clean['ports_released'] and clean['lease_continuously_held'] and cpu['status']=='PASS'
lock=os.open(R/'.q4t-work/gpu-exclusive.lock',os.O_RDWR);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN);os.close(lock)
files={}
for prefix in ('lease','lease-02','source'):
 for p in (B/prefix).iterdir():
  if p.is_file():files['business-01/'+str(p.relative_to(B))]=p
for n in ('plan.json','model-command.json','model-identity.json','model.log','counts.json','result.json','cleanup.json','alpha.sdk.json','alpha.stderr','core-before.wire','before.json'):
 p=B/'run'/n
 if p.is_file():files['business-01/run/'+n]=p
files['business-01/launch-failure-01.json']=B/'launch-failure-01.json'
for prefix in ('definitions-cpu-01','definitions-build-01'):
 for p in (W/prefix).iterdir():
  if p.is_file():files[str(p.relative_to(W))]=p
for n in ('definitions-plan-01.json','definitions-required-tests.txt','archive_definitions_fix.py'):files[n]=W/n
for p in (W/'definitions-archive-failure-01').iterdir():files['archive-failure-01/'+p.name]=p
for n,h in plan['sources'].items():assert sha(R/n)==h;files['source/'+n]=R/n
secret=read(B/'run/client-policy.json')['gateway_token'].encode()
for name,p in files.items():
 data=p.read_bytes();assert secret not in data and b'-----BEGIN '+b'PRIVATE KEY-----' not in data,name
O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
queries=[json.loads(line) for line in (B/'lease-02/nvml-queries.jsonl').read_text().splitlines()]
a=dict(status='FAIL_ORIGINAL_PROMPT_BUSINESS_WITH_DRIVER_FIX_CPU_PASS',original_failure='Realtime template used Responses-only effort=none; invalid_prompt correctly rejected',launch_failure='Original invocation omitted --inherit-lease; zero starts; preserved',model_starts=1,actual_chat_requests=1,actual_realtime_creates=0,actual_registry_requests=1,seconds=r['seconds'],nvml_queries=len(queries),cleanup_confirmed=True,lock_released=True,cpu=cpu,build=build,runtime_changed=False,candidate_sha256=r['binary_sha256'],default_unchanged=True,default_revision=356,next='One bounded stage, same binary, at most 13 Realtime + 2 Chat / 900s; no completed Prompt request is replayed',archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a)
(O/'README.md').write_text(f'''# Realtime Prompt 注册失败与精确夹具修正

原业务失败保留：1次模型启动、1条普通Chat通过、1次模板注册400，
0次Realtime生成，{r['seconds']:.3f}秒；{len(queries)}次NVML查询，模型正常
退出，自有进程/端口清理且锁已释放。更早一次命令遗漏`--inherit-lease`
在驱动构造前退出，0次模型启动，也保留原守卫记录。预算预记的
10个response/16个HTTP不是实际请求数，以SDK原始回执为准。

原因已定位到驱动：Responses的`reasoning.effort=none`不能直接作为
固定OpenAI 7.47.0 Realtime枚举。原生schema按合同拒绝；不放宽服务
校验、不修改接口默认值或推理程序。驱动改为共享JSON中的5个精确
模板，省略该字段，仍由Realtime现有默认映射处理内部推理设置。

新增CPU通过真实ObjectStore/PromptRegistry校验这5个模板，逐一加入
原`effort=none`作为5个拒绝反例，另JS语法通过：{cpu['seconds']:.3f}秒/
0GPU，构建{build['seconds']:.3f}秒零警告。原6项验收器反例身份不变复用。

同一候选`f20c3b76`保留。随后单独冻结最多1模型/13 Realtime+2 Chat/
2WSS/32原生HTTP/900秒，完成尚未执行的业务；不覆盖原失败、不重放
已完成Prompt请求。默认rev356和全部master保持，业务资格仍未取得。
''')
intro=f'[Prompt注册失败已定位并修正驱动](evidence/serve-realtime-prompt-definition-fix-20261120/README.md)：\n首轮1模型/1 Chat/0 Realtime/{r["seconds"]:.3f}秒，注册400原件保留，\n自有资源与锁释放。脚本误用了Responses的effort=none；服务正确\n拒绝，5份真实模板+5个原错误反例经原生注册表CPU通过（0.063秒），\nJS语法通过；运行时不变。接下来同候选单模型/13 Realtime+2 Chat/\n900秒继续未执行业务，默认rev356和全部master保持。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Prompt注册400原失败与驱动schema修正\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：Realtime与Responses公开schema并不相同，必须用同一份\n业务模板先经原生注册表校验；不能放宽服务合同掩盖脚本错误。\n\n下一步：冻结补验清单，实际业务后继续能力保持、交付及全部master。\n'+b)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['realtime_progress']['prompt_definition_fix_20261120']=a|dict(evidence='evidence/serve-realtime-prompt-definition-fix-20261120/README.md');save(p,g)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [Realtime Prompt定义修正](evidence/serve-realtime-prompt-definition-fix-20261120/README.md)：原注册失败保留，真实模板原生CPU校验。\n')
os.link(R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests',W/'definitions-cpu-01/qualified-contracts');print(json.dumps(a))

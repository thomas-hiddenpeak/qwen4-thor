from pathlib import Path
import json,hashlib,re,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from tools.serve_audit.check_inventory import current_surface,check
files=['include/q4t/server/realtime_chat_plan.h','src/server/realtime_chat_plan.cpp','include/q4t/server/realtime_file_inputs.h','src/server/realtime_file_inputs.cpp','tests/server_realtime_file_inputs_test.cpp','tests/server_realtime_chat_plan_test.cpp','tests/server_realtime_conversation_session_test.cpp','CMakeLists.txt','cmake/HostTestSources.cmake','cmake/ChatProtocolIdentity.cmake']
p=R/'tools/serve_audit/inventory.json';v=json.loads(p.read_text());a=current_surface(R);changed={n:h for n,h in a['sources_sha256'].items() if v['sources_sha256'].get(n)!=h};assert set(changed)<=set(files),set(changed)-set(files);v['sources_sha256'].update(changed);assert not check(v,a),check(v,a);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
tests=[]
for f in files:
 if not f.startswith('tests/'):continue
 for name in re.findall(r'Q4T_TEST\(\s*(\w+)\s*\)',(R/f).read_text()):
  if 'conversation_session' not in f or name.startswith('realtime_session_prompt_'):tests.append(name)
assert len(tests)==30 and len(tests)==len(set(tests)),len(tests)
plan=dict(scope='Owned Realtime file/media prefix preparation and pure plan readiness; real local inline/stored text, PNG, CSV extraction, tenant isolation, cancellation/expiry, retained bytes, actual history index projection. Model sheet execution and native quota handoff remain next work, no GPU.',maximum_tests=30,maximum_test_seconds=120,new_gpu_starts=0,tests=tests,sources={f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files},maximum_source_bytes=32<<20,maximum_retained_file_bytes=64<<20,maximum_rendered_bytes=16<<20,default_revision=356,default_unchanged=True)
p=W/'files-plan-01.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2)+'\n');(W/'files-required-tests.txt').write_text('\n'.join(tests)+'\n')
intro='Realtime文件前缀准备owner已编写：实际文本/图像走原生文件通道，\n未完成的表格预处理不进入生成；保留输入顺序、权限与取消，资源\n上限为32MiB来源/64MiB文件保留/16MiB展开并遵循更严配置。冻结\n30项针对性CPU/120秒/0GPU；运行时模型预处理、单次RPM与实际用量\n交接继续实现，尚无Prompt业务资格。草稿PR #53已建立，默认rev356\n保持；PR #52已合入，全部master继续。\n\n'
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Realtime文件前缀原生准备与生成就绪边界\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：typed文件变量必须使用实际内容、客户权限与资源合同；\n不能在未准备好时把引用当文本，也不能丢弃需要真实模型处理的表格。\n\n下一步：针对性CPU后完成运行时预处理和计费交接，再做真实SDK短验\n及能力保持/交付；所有master任务继续。\n'+b)
print(json.dumps(dict(tests=len(tests),updated_anchors=sorted(changed))))

from pathlib import Path
import json,hashlib,tarfile,re,os
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-prompt-files-cpu-20261120'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
plan=read(W/'files-plan-01.json');result=read(W/'files-cpu-01/result.json');source=read(W/'files-cpu-01/source-check.stdout');build=read(W/'files-build-01/result.json')
assert result['status']=='PASS' and result['passed']==30 and source['inventory_current'] and source['mutation_checks']==20 and build['exit_code']==0
assert not re.search(r'\bwarning:',(W/'files-build-01/build.log').read_text())
files={}
for prefix in ('files-cpu-01','files-build-01'):
 for p in (W/prefix).rglob('*'):
  if p.is_file() and 'fixtures' not in p.relative_to(W/prefix).parts:files[str(p.relative_to(W))]=p
for n in ('files-plan-01.json','files-required-tests.txt','prepare_files_cpu.py','archive_files_cpu.py'):files[n]=W/n
for f,h in plan['sources'].items():
 assert sha(R/f)==h,f
 files['source/'+f]=R/f
assert not O.exists();O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
a=dict(status='PASS_REALTIME_PROMPT_FILES_CPU',tests=30,new_tests=7,seconds=result['seconds'],build_seconds=build['seconds'],build_warnings=0,source_mutations=20,new_gpu_starts=0,actual_text_png_csv_extraction=True,model_sheet_receipts='CPU fixtures only, not generated summaries or quality acceptance',runtime_model_preparation_and_quota_handoff_pending=True,actual_realtime_business_accepted=False,default_revision=356,default_unchanged=True,pr=53,pr_draft=True,files=len(files),archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a)
(O/'README.md').write_text(f'''# Realtime Prompt 文件／媒体准备 CPU

30项针对性CPU通过，{a['seconds']:.3f}秒、0GPU；7项新文件合同，
19项受影响计划与4项实际Prompt会话合同。构建{a['build_seconds']:.3f}秒
零警告，20来源反例通过。

`RealtimeFileInputs`复用原生文件准备：实际inline/已上传文本、PNG和
CSV解析，权限来自请求owner。跨租户读取拒绝，读取完成后删除原文件
不改变已取得内容；截止时间/取消、模板和顺序变更、配置预算以及
客户输出限制均不导致半成品计划发布。原始请求保留，文件只展开
内容，不改变外层项数和历史下标。文本/图像进入实际Chat计划。

表格在其模型步骤完成前明确保持待准备，CPU显式回执仅验证状态和
用量协议，不能当作真实模型摘要。文件准备限制为来源32MiB、保留
64MiB、展开16MiB，较严部署配置继续优先；原始文件和模型目录未改。

下一步接运行时实际模型预处理、共享一次RPM的配额及失败用量交接，
再必要构建、真实SDK短验、主轻/恢复与可回退交付。本次没有运行
新模型程序或GPU，不表示Prompt业务已验收。草稿PR #53保留开发；
已验PR #52已进main、默认rev356保持，全部master继续。
''')
intro=f'[Prompt文件30项CPU通过](evidence/serve-realtime-prompt-files-cpu-20261120/README.md)：\n{a["seconds"]:.3f}秒/0GPU，真实文本/PNG/CSV解析、租户权限、取消与\n预算、删除后快照及前缀下标通过；构建22.888秒零警告，20来源反例\n通过。表格CPU回执不代表真实摘要；继续运行时模型准备、RPM/用量\n交接和实际SDK业务。草稿PR #53、默认rev356及全部master保持。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Realtime文件准备30项CPU通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：原生文件路径必须先保证权限、真实内容与事务边界；模型\n预处理和真实配额仍须接到运行时，不能凭CPU回执宣称业务完成。\n\n下一步：运行时共享计费、必要构建与实际SDK业务，然后能力保持\n和交付；全部master继续。\n'+b)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['realtime_progress']['prompt_files_20261120']=a|dict(evidence='evidence/serve-realtime-prompt-files-cpu-20261120/README.md');save(p,g)
p=R/'docs/SERVE_REALTIME_PROMPT_2026-11-20.md';detach(p);p.write_text(p.read_text().replace('## 已核实的依据','文件/媒体准备另通过[30项CPU](evidence/serve-realtime-prompt-files-cpu-20261120/README.md)，\n文本/PNG/CSV解析与权限/取消/事务已具备，表格仅CPU回执。接下来\n补运行时模型步骤及共享RPM/实际用量交接，再完成真实SDK业务。\n\n## 已核实的依据',1))
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [Realtime Prompt文件CPU](evidence/serve-realtime-prompt-files-cpu-20261120/README.md)：实际文件准备；模型步骤/配额交接与业务继续。\n')
b=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';assert sha(b)==result['binary_sha256'];os.link(b,W/'files-cpu-01/qualified-contracts');print(json.dumps(a))

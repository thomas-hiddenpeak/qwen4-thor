from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'engine-build-01';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build';O.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
old=B/'q4t';assert sha(old)=='0d1e2ef1f765a725c91225c8f2a8b435d4809508bf1040da9001f6bf6bfedf20'
os.link(old,O/'previous_q4t');old.unlink()
for name in ['generated/q4t/server/chat_protocol_sources.json','CMakeCache.txt']:
 p=B/name;shutil.copy2(p,O/('previous-'+p.name))
detached=[]
for p in [*B.rglob('*.a'),*B.rglob('*.o'),*(B/'generated').rglob('*')]:
 if p.is_symlink() or not p.is_file() or p.stat().st_nlink<2:continue
 s=p.stat();h=sha(p);tmp=p.with_name(p.name+'.prompt-detach');assert not tmp.exists();shutil.copy2(p,tmp);assert sha(tmp)==h;tmp.replace(p);detached.append(dict(path=str(p),sha256=h,old_links=s.st_nlink))
paths=subprocess.check_output(['git','ls-files','src','include','cmake','CMakeLists.txt'],cwd=R,text=True).splitlines();cmd=['cmake','--build',str(B),'--target','q4t','--parallel','4']
save(O/'plan.json',dict(scope='Necessary neutral refusal-format runtime build; no GPU execution/performance/quality test',command=cmd,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources={n:sha(R/n) for n in paths},protected=protected,previous_binary_sha256=sha(O/'previous_q4t'),detached=detached,gpu_actions=0,free_bytes_before=shutil.disk_usage(R).free))
start=time.monotonic()
with (O/'build.log').open('w') as f:
 try:code=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=1800).returncode
 except subprocess.TimeoutExpired:code=124
raw=(O/'build.log').read_text();warnings=raw.count('warning:');unchanged=all(sha(Path(n))==h for n,h in protected.items())
result=dict(status='BUILD_PASS' if code==0 and not warnings and unchanged else 'BUILD_FAIL',exit_code=code,seconds=time.monotonic()-start,warnings=warnings,gpu_actions=0,default_unchanged=unchanged,prior_unchanged=sha(O/'previous_q4t')=='0d1e2ef1f765a725c91225c8f2a8b435d4809508bf1040da9001f6bf6bfedf20',binary_sha256=sha(B/'q4t') if (B/'q4t').exists() else None,free_bytes_after=shutil.disk_usage(R).free)
save(O/'result.json',result);print(json.dumps(result),flush=True)
if code:print(raw[-6000:],flush=True)
raise SystemExit(0 if result['status']=='BUILD_PASS' else 1)

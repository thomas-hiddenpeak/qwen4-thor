from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
ROOT=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent
OUT=W/'cpu-01';OUT.mkdir()
B=ROOT/'.q4t-work/serve-file-search-20261112/host'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
tests='''refusal_template_native_instruction_and_raw_cache_identity
chat_annotations_text_parts_and_refusal_keep_original_offsets
chat_verbosity_preserves_original_message_source_coordinates
chat_schema_prompt_preserves_contract_and_message_boundaries
chat_schema_prompt_preserves_tools_and_unconstrained_template
chat_message_profile_developer_system_equivalence
chat_message_profile_instruction_content_before_media
chat_message_profile_ordered_instructions_and_names
chat_message_profile_refusal_round_trip
chat_message_profile_preserves_history_rules
chat_style_default_null_and_explicit_effort_rendering
chat_style_none_and_nested_precedence_use_native_prefix
realtime_chat_tool_result_history_keeps_actual_content_and_ids
realtime_chat_prompt_prefix_is_real_input_before_public_history
realtime_chat_context_cut_preserves_function_call_result_group
refusal_parser_every_split_preserves_text_and_source_offsets
refusal_parser_incomplete_malformed_and_capacity_terminals
refusal_parser_marker_data_and_natural_language_are_not_signals'''.splitlines()
assert len(tests)==18 and len(set(tests))==18
contents='\n'.join(p.read_text() for p in (ROOT/'tests').glob('*.cpp'))
assert all(re.search(r'Q4T_TEST\(\s*'+n+r'\s*\)',contents) for n in tests)
(OUT/'required.txt').write_text('\n'.join(tests)+'\n')
protected={str(ROOT/n):sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
paths=subprocess.check_output(['git','ls-files','src','include','cmake','CMakeLists.txt','tests'],cwd=ROOT,text=True).splitlines()
old=B/'q4t_host_tests';prior=ROOT/'.q4t-work/serve-realtime-prompt-20261120/profile-cpu-02/qualified-contracts'
assert sha(old)==sha(prior)=='c89ed64ad605a57af2773b76c1fb6826fd01f0a7bff1031f3e671678ef0ec1ec'
os.link(old,OUT/'previous-contracts');old.unlink()
detached=[]
for p in [*B.rglob('*.a'),*B.rglob('*.o'),*(B/'generated').rglob('*')]:
 if p.is_symlink() or not p.is_file() or p.stat().st_nlink<2:continue
 h=sha(p); tmp=p.with_name(p.name+'.detach-refusal');assert not tmp.exists();shutil.copy2(p,tmp);assert sha(tmp)==h;tmp.replace(p);detached.append(dict(path=str(p),sha256=h))
cmd=['cmake','--build',str(B),'--target','q4t_host_tests','--parallel','4']
commands=[[str(B/'q4t_host_tests'),'--required-list',str(OUT/'required.txt')],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
plan=dict(scope='Refusal encoding wording correction: preserve source offsets, ordinary/schema/tool/history and refusal parsing; no new kernels or performance claim',tests=tests,maximum_tests=18,source_counterexamples=20,maximum_test_seconds=120,new_gpu_starts=0,build_command=cmd,commands=commands,sources={n:sha(ROOT/n) for n in paths},protected=protected,previous_sha256=sha(prior),detached=detached)
save(OUT/'plan.json',plan)
start=time.monotonic()
with (OUT/'build.log').open('w') as f:r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
log=(OUT/'build.log').read_text();warnings=log.count('warning:');unchanged=all(sha(n)==h for n,h in protected.items())
build=dict(status='BUILD_PASS' if r.returncode==0 and warnings==0 and unchanged else 'BUILD_FAIL',seconds=time.monotonic()-start,exit_code=r.returncode,warnings=warnings,default_unchanged=unchanged,previous_unchanged=sha(prior)==plan['previous_sha256'],binary_sha256=sha(old) if old.exists() else None,gpu_actions=0)
save(OUT/'build-result.json',build);print(json.dumps(build),flush=True)
if build['status']!='BUILD_PASS':print(log[-8000:]);raise SystemExit(1)
os.link(old,OUT/'qualified-contracts')
started=time.monotonic();runs=[]
for i,cmd in enumerate(commands):
 begin=time.monotonic()
 with (OUT/f'check-{i}.log').open('w') as f:
  try:code=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=max(1,120-(time.monotonic()-started))).returncode
  except subprocess.TimeoutExpired:code=124
 runs.append(dict(command=cmd,exit_code=code,seconds=time.monotonic()-begin))
 save(OUT/'result.json',dict(status='RUNNING',runs=runs))
 if code:break
result=dict(status='PASS' if len(runs)==2 and all(v['exit_code']==0 for v in runs) else 'FAIL',runs=runs,seconds=time.monotonic()-started,native_tests=18 if runs[0]['exit_code']==0 else None,new_gpu_starts=0,binary_sha256=sha(old),sources_unchanged=all(sha(ROOT/n)==h for n,h in plan['sources'].items()),default_unchanged=all(sha(n)==h for n,h in protected.items()))
save(OUT/'result.json',result);print(json.dumps(result),flush=True)
for p in sorted(OUT.glob('check-*.log')):print(p.read_text()[-5000:])
raise SystemExit(0 if result['status']=='PASS' else 1)

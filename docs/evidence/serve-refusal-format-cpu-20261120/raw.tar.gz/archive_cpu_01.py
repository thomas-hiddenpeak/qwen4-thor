from pathlib import Path
import json,hashlib,tarfile
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
OUT=ROOT/'docs/evidence/serve-refusal-format-cpu-20261120';OUT.mkdir()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  data=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(data);p.chmod(mode)
r=json.loads((W/'cpu-01/result.json').read_text());b=json.loads((W/'engine-build-01/result.json').read_text());h=json.loads((W/'cpu-01/build-result.json').read_text())
assert r['status']=='PASS' and b['status']==h['status']=='BUILD_PASS' and b['warnings']==h['warnings']==0
files={}
for folder in ('cpu-01','engine-build-01','dependency-sharing-01'):
 for p in (W/folder).iterdir():
  if p.is_file() and p.suffix in ('.json','.txt','.log','.py'):files[str(p.relative_to(W))]=p
for n in ('archive_cpu_01.py','build_cpu_01.py','build_engine_01.py'):files[n]=W/n
for n in ('include/q4t/server/refusal_frame.h','tests/server_chat_message_profile_test.cpp','src/server/chat_template.cpp','src/server/chat_response_parser.cpp'):
 files['source/'+n]=ROOT/n
index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(OUT/'index.json',index)
with tarfile.open(OUT/'raw.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(OUT/'raw.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
a=dict(status='PASS_REFUSAL_FORMAT_TARGETED_CPU',native_tests=18,source_counterexamples=20,seconds=r['seconds'],cpu_build=h,runtime_build=b,new_gpu_starts=0,actual_business_qualified=False,default_unchanged=True,default_revision=356,raw_sha256=sha(OUT/'raw.tar.gz'))
save(OUT/'acceptance.json',a)
(OUT/'README.md').write_text('''# 拒答格式说明修正：针对性 CPU 与候选构建

18项原生检查、20项来源反例通过，CPU执行0.480秒。主机构建31.037秒、
运行时构建19.082秒，均零警告。候选648d6d68，只改全局拒答格式说明，
与此前原始Completion对照的中性文字逐字相同；拒答帧/grammar分支、
解析、错误终态及流式合同保持。CPU验证消息偏移、schema与工具历史、
拒答分片和不完整帧；不能替代真实拒答质量验收。

下一组冻结1模型（轻配置/MTP关闭）、8次生成、1 WSS、1入口、600秒：
两条历史真实工具输入按固定seed/greedy重验，实际Chat拒答、Responses
流式拒答/schema/拒答历史，以及实际Realtime工具两轮。所有原FAIL保留，
本组通过后仍需主轻与恢复的受影响组合，不自动成为已交付资格。

磁盘维护只共享本任务三对内容/权限相同的Rust依赖副本，释放317074188
字节；原路径和SHA保持，附逐项还原脚本。未删除模型、默认或历史证据。
默认rev356不变，全部Serve master继续。
''')
intro='[拒答说明修正18项CPU通过](evidence/serve-refusal-format-cpu-20261120/README.md)：\n0.480秒/0GPU，20来源反例通过；候选648d6d68零警告构建。\n冻结1模型/8生成/1WSS/1入口/600秒，验证两条真实工具输入、\n实际拒答及正常schema/历史与Realtime工具；不自动循环或更新默认。\n原FAIL、rev356及全部master保持，随后继续受影响资格与交付。\n\n'
p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=ROOT/'docs/log/2026-11-20.md';detach(p);head,tail=p.read_text().split('\n',1);p.write_text(head+'\n\n## 拒答提示干扰修正与针对性CPU通过\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：受控对照复现了模板说明干扰；修正格式指导且保留原拒答功能。\n磁盘同内容副本共享保留路径/校验和可还原记录，释放约302MiB。\n\n下一步：实际普通与拒答业务短验，按受影响范围完成主轻/恢复和交付，\n不追认原失败、不把局部通过当作总目标完成。\n'+tail)
print(json.dumps(a))

import hashlib, io, json, tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1]
O=R/'docs/evidence/serve-live-close-tail-cpu-20261121'
sha=lambda data:hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cpu=read(W/'close-tail-cpu-01/result.json');driver=read(W/'client-driver-cpu-05/result.json');build=read(W/'native-build-02/result.json')
assert cpu['status']==driver['status']=='PASS' and build['status']=='BUILD_PASS'
assert cpu['sources_unchanged'] and cpu['protected_unchanged'] and build['sources_unchanged'] and build['default_unchanged']
files={}
for folder in ['close-tail-plan-01','close-tail-cpu-01','client-driver-cpu-04','client-driver-cpu-05']:
 for p in sorted((W/folder).iterdir()):
  if p.is_file():files[folder+'/'+p.name]=p.read_bytes()
for name in ['plan.json','result.json','0.stdout','0.stderr','1.stdout','1.stderr']:
 files['native-build-02/'+name]=(W/'native-build-02'/name).read_bytes()
for name in ['close_tail_cpu_01.py','client_driver_cpu_04.py','client_driver_cpu_05.py','build_native_02.py','archive_close_tail_01.py','close-tail-inventory-before.json','close-tail-inventory-reviewed.json']:
 files['driver/'+name]=(W/name).read_bytes()
sources=read(W/'close-tail-cpu-01/plan.json')['sources']|driver['sources']
for n,h in sources.items():
 raw=(R/n).read_bytes();assert sha(raw)==h,n;files['accepted/'+n]=raw
for n in ['deduplicated-retired-01/result.json','retired-previous-02/result.json']:
 if (W/n).exists():files['disk/'+n]=(W/n).read_bytes()
O.mkdir();index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as archive:
 for name,raw in sorted(files.items()):
  index[name]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(name)
  info.size,info.mode,info.mtime=len(raw),0o600,0;archive.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
result=dict(status='PASS_LIVE_CLOSE_TAIL_CPU',native_cpu=cpu,driver_cpu=driver,native_build=build,reviewed_sources=6,inventory_mutation_checks=28,new_gpu_starts=0,default_changed=False,original_business_failure_retained=True,real_business_followup_pending=True,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',result)
(O/'README.md').write_text('''# Live关闭尾部的针对性CPU验证

真实短验发现的[额外ASR/RPM失败](../serve-live-close-tail-failed-20261121/README.md)保持原记录。
关闭现在非阻塞等待VAD处理已接收输入；仅清理已判静音、未评分后缀为
数字静音的剩余音频。有声、极短未知及未评分非静音仍使用实际波形
提交ASR，不补样、不退还输入时钟。公共Realtime显式commit语义保持。

18项原生CPU全部通过：6项新增（四种格式静音/有声/未评分尾部、
等待分析与实际LiveSession无额外工作），12项直接关闭/取消/样本/显式
提交保护。模型/VAD评分为受控CPU回调；不能当作真实模型验收。
宿主构建98.607秒零警告，CPU执行0.514182秒。

5项录音复用校验通过。复用第二轮实际合成与正确识别的录音，但整体
原轮仍FAIL；校验器检查实际HTTP/结算、逐字节录音和未提供ASR原文，
不通过重标失败取得接受。首版依赖私有目录的本机PASS保留；随后改为
从公共无凭据归档重建测试夹具，5项仍PASS（0.628629秒）。原观察器和
SDK/等待逻辑按未变SHA复用，不重跑。

6个来源经过语义复核，28项清单反例通过。实际引擎和入口正式构建
通过，准确身份与耗时见[result.json](result.json)。默认rev426及客户状态
未改，GPU新增0。下一步使用同一严格租约、原录音和原RPM3，完成
1启动/1ASR+2前台+1普通Chat/600秒的业务补验，再继续全部任务。

完整来源、测试输出、构建与索引见[evidence.tar.gz](evidence.tar.gz)和
[index.json](index.json)。不包含客户策略、私钥或恢复初始化凭据。
''')
p=R/'docs/STATUS.md';s=p.read_text();old='Live关闭尾部修复已接入源码：非阻塞等待已接受VAD处理完毕，仅清理\n静音尾部；短小未知/有声片段保留实际ASR，显式Realtime commit不改。\n已冻结6项新CPU与12项直接保护，当前等待构建和验证，尚不记通过。\n'
new='[Live关闭尾部修复18项CPU](evidence/serve-live-close-tail-cpu-20261121/README.md)\n通过；另5项录音复用校验通过，6来源语义复核/28项反例通过。实际\n引擎构建零警告，已判静音不多做ASR，未知/有声保留，显式commit\n不改。接着按原RPM3、原录音补1启动/4实际工作/600秒短验；默认不变。\n'
assert old in s;p.write_text(s.replace(old,new,1))
p=R/'docs/log/2026-11-21.md';p.write_text('## Live关闭尾部CPU与实际构建通过\n\n日期：2026-11-21。做了什么：18项原生CPU全部通过，宿主构建\n98.607秒零警告；录音复用5项校验通过，测试夹具已改为公共归档\n可重建，原本机PASS仍保留。6个来源语义复核/28项反例通过，实际\n引擎构建'+f"{build['seconds']:.3f}"+'秒零警告。为什么：关闭静音不应消耗额外\nASR配额，未知信号又不能丢弃。下一步：按原RPM3复用原录音，\n严格租约1启动/4项工作/600秒业务补验；原失败保持，默认未改。\n\n'+p.read_text())
print(json.dumps(dict(status=result['status'],files=len(files),archive_sha256=result['archive_sha256'])))

"""Three fixed observations of the exact failed arithmetic prompt; no retries."""
import copy
import json
from pathlib import Path
import signal
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import profile_acceptance as full
from tools.serve_responses import encryption_acceptance as encrypted
from tools.serve_service.package import read, require, save, sha

WORK = Path(__file__).resolve().parent
OUT = WORK / 'qualification-diagnostic-01'
LIMITS = dict(starts=1, chats=3, controls=1000, seconds=300)


def inputs():
    value = read(WORK / 'qualification-input-review-01/observed.json')[0]
    request = value['generation_request']
    return dict(seed_zero=dict(request, seed=0), greedy=dict(request, temperature=0, seed=0),
        raw_greedy=dict(model=request['model'], prompt=value['measured_prompt'],
            temperature=0, top_p=1, seed=0, max_tokens=128, stream=False))


class Stage(full.Stage):
    limits = LIMITS
    request_templates = staticmethod(inputs)
    success_status = 'OBSERVATIONS_COMPLETE_NOT_QUALIFICATION'

    def __init__(self, plan):
        encrypted.Stage.__init__(self, plan)

    def business(self):
        observed = {}
        for label, body in self.plan['requests'].items():
            path = '/v1/completions' if label == 'raw_greedy' else '/v1/chat/completions'
            save(self.out / (label + '.request.json'), body)
            self.budget('chats')
            status, raw = self.http(path, body, label=label, timeout=120)
            value = json.loads(raw)
            self.same_model(); self.drained(label + '-drain')
            text = None
            if status == 200:
                choice = value['choices'][0]
                text = choice.get('text') if label == 'raw_greedy' else choice['message'].get('content')
            observed[label] = dict(http_status=status, answer=text, raw=value,
                model_quality='PASS' if text and text.strip() == '42' else 'FAIL',
                input_tokens=value.get('usage', {}).get('prompt_tokens'),
                exact_frozen_input=True, default_sampling_changed=False)
            save(self.out / 'observed.json', observed)
        require(self.counts['chats'] == 3, 'missing fixed diagnostic observation')


def prepare():
    OUT.mkdir(mode=0o700)
    plan = copy.deepcopy(read(WORK / 'profiles-01/plan.json'))
    plan.update(output=str(OUT), limits=LIMITS, requests=inputs(),
        scope=__doc__, planned=dict(starts=1, chats=3, controls=1000, seconds=300),
        automatic_retries=False, original_failure_preserved=True,
        original_failure=str(WORK / 'profiles-01/result.json'))
    for path in (Path(__file__), WORK / 'profiles-01/result.json',
                 WORK / 'qualification-input-review-01/observed.json'):
        plan['sources'][str(path)] = sha(path)
    save(OUT / 'plan.json', plan)


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']: prepare()
    else:
        require(sys.argv[1:] == ['run'], 'explicit frozen mode required')
        def stopped(_signum, _frame): raise TimeoutError('bounded diagnosis ended')
        signal.signal(signal.SIGTERM, stopped); signal.signal(signal.SIGALRM, stopped)
        signal.alarm(LIMITS['seconds'])
        try: Stage(read(OUT / 'plan.json')).run()
        finally: signal.alarm(0)

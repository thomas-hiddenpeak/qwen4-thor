"""One start / two creates: identical VP8 inputs through JSON and SSE."""
import argparse,copy,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_responses import video_acceptance as v
from tools.serve_service.package import read,save,sha,require
LIMITS=dict(starts=1,chats=2,controls=2000,seconds=600)
def requests():
    stream=v.requests()['stream'];plain=copy.deepcopy(stream)
    plain.pop('stream');plain.pop('stream_options')
    return dict(json=plain,sse=stream)
class Stage(v.Stage):
    limits=LIMITS;request_templates=staticmethod(requests)
    success_status='COMPLETED_TRANSPORT_DIAGNOSTIC_NOT_ACCEPTANCE'
    def business(self):
        outputs={}
        for label,row in self.plan['requests'].items():
            r=self.sdk(label,'create',row);v.background.check_response(r,'completed')
            outputs[label]=dict(content=[i['content'] for i in r['output'] if i['type']=='message'],usage=r['usage'])
        self.drained('final')
        save(self.out/'diagnostic-summary.json',dict(outputs=outputs,
            equal_content=outputs['json']['content']==outputs['sse']['content'],
            equal_input_tokens=outputs['json']['usage']['input_tokens']==outputs['sse']['usage']['input_tokens'],acceptance=False))
a=argparse.ArgumentParser();a.add_argument('mode',choices=['prepare','run']);a=a.parse_args();w=Path(__file__).resolve().parent/'transport-01'
if a.mode=='prepare':
    opts=argparse.Namespace(binary=ROOT/'.q4t-work/serve-prepared-input-trust-20261116/candidate-01/q4t',output=w,port=18186)
    v.background.prepare(opts,rows=requests(),limits=LIMITS,scope=__doc__)
    p=w/'plan.json';plan=read(p);plan['private_peer_port']=18188
    for f in [Path(__file__),v.ASSETS/'business-identity.json',*(v.ASSETS/x for x in v.CLIPS)]:plan['sources'][str(f.relative_to(ROOT))]=sha(f)
    plan['mutations']=['own model and temporary objects only, no restarts or retries'];plan['derived_requests']=['identical VP8 content and schema; only stream/stream_options differ'];save(p,plan)
else:
    with v.base.lifecycle.child_subreaper():Stage(read(w/'plan.json')).run()

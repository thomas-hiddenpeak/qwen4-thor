"""Neutral refusal wording: historical tools, real refusal/schema/history and WSS.

One light-capacity model, eight generations, one WSS, 600 seconds, no retries.
This is focused runtime acceptance, not full profile or recovery qualification.
"""
import copy,json,signal,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import profile_acceptance as full, profile_conversation
from tools.serve_responses import encryption_acceptance as encrypted
from tools.serve_responses import refusal_acceptance as refusal
from tools.serve_responses import acceptance as foreground, background_acceptance as background
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent;OUT=W/'business-01'
LIMITS=dict(starts=1,chats=8,controls=2000,seconds=600,websocket_sessions=1,ingress_starts=1)

def requests():
 old=refusal.requests();rows={k:old[k] for k in ('chat_refusal','response_refusal','ordinary','history')}
 for item in read(W/'input-review-01/observed.json'):
  rows[item['label']]=dict(item['generation_request'],temperature=0,seed=0)
 return rows

class Stage(full.Stage):
 limits=LIMITS;request_templates=staticmethod(requests)
 success_status='PASS_NEUTRAL_REFUSAL_FOCUSED_BUSINESS'
 def __init__(self,plan):
  require(plan['diagnostic_capacity']=='light' and plan['profiles']['primary']==plan['profiles']['light'] and plan['profiles']['primary']['mtp_enabled'] is False,'actual light capacity required')
  encrypted.Stage.__init__(self,plan)
  self.counts.update(websocket_sessions=0,ingress_starts=0)
 def business(self):
  require(read(self.out/'primary-config.json')['runtime']['mtp_enabled'] is False,'capacity drift')
  rows=self.plan['requests'];observed={}
  for label in ('prompt_tool_failure','light_tool_failure'):
   value=self.request(label,rows[label]);choice=value['choices'][0]
   observed[label]=dict(answer=choice['message'],finish_reason=choice['finish_reason'],usage=value['usage'])
   save(self.out/'observed.json',observed)
   require(choice['finish_reason']=='stop' and choice['message'].get('content','').strip()=='rev356' and not choice['message'].get('refusal'),'historical actual tool answer differs: '+label)
  chat=self.request('chat-refusal',rows['chat_refusal']);choice=chat['choices'][0]
  require(choice['finish_reason']=='stop','Chat refusal incomplete');refusal.check_refusal(choice['message'])
  require(choice['logprobs']['content'] is None and choice['logprobs']['refusal'] and all(len(p['top_logprobs'])==2 for p in choice['logprobs']['refusal']),'actual refusal probabilities absent')
  observed['chat_refusal']=chat;save(self.out/'observed.json',observed)
  response=self.sdk('response-refusal','create',rows['response_refusal'])
  text=refusal.response_refusal(response);events=read(self.out/'response-refusal.sdk.json')['chunks']
  deltas=[e for e in events if e['type']=='response.refusal.delta'];done=[e for e in events if e['type']=='response.refusal.done']
  require(deltas and ''.join(e['delta'] for e in deltas)==text and len(done)==1 and done[0]['refusal']==text and not any(e['type'].startswith('response.output_text.') for e in events),'actual refusal stream lifecycle differs')
  stored=self.sdk('refusal-stored','retrieve',response_id=response['id'])
  require(stored['output']==response['output'],'stored refusal changed')
  replay=self.sdk('refusal-replay','retrieve',response_id=response['id'],query=dict(stream=True,include_obfuscation=False))
  require(replay==response,'refusal replay terminal changed')
  observed['response_refusal']=response;save(self.out/'observed.json',observed)
  ordinary=self.sdk('ordinary-schema','create',rows['ordinary']);background.check_response(ordinary,'completed')
  require(json.loads(foreground.text(ordinary))==dict(answer=42),'ordinary schema answer differs')
  history=self.sdk('refusal-history','create',dict(rows['history'],previous_response_id=response['id']));background.check_response(history,'completed')
  require(foreground.text(history).strip()=='42','public follow-up after refusal differs')
  inputs=self.sdk('history-inputs','input_items',response_id=history['id'],query=dict(order='asc',limit=100))
  require(any(part.get('type')=='refusal' and part.get('refusal')==text for item in inputs['data'] for part in item.get('content',[]) if isinstance(part,dict)),'actual refusal history missing')
  observed.update(ordinary_schema=ordinary,refusal_history=history);save(self.out/'observed.json',observed)
  conversation=profile_conversation.run(self)
  final=self.drained('final')
  require(final['q4t_requests_total']==8 and final['q4t_requests_success_total']==8 and final['q4t_requests_error_total']==0,'actual request accounting differs')
  save(self.out/'business-summary.json',dict(generations=8,model_starts=1,diagnostic_capacity='light',observed=observed,conversation=conversation,original_failures_preserved=True,default_unchanged=True,full_profile_qualification=False,performance_claim=False))

def prepare():
 OUT.mkdir(mode=0o700)
 source=ROOT/'.q4t-work/serve-realtime-prompt-20261120/profiles-02/plan.json';plan=copy.deepcopy(read(source))
 for key in ('continued_primary_text','prompt','targeted_format','source_review','previous_registry'):plan.pop(key,None)
 build=Path(plan['candidate_identity']['build']);binary=build/'q4t'
 base=read(ROOT/'.q4t-work/serve-realtime-conversation-20261119/service-package-01/bundle/engine/manifest.json')
 base,candidate=full.candidate_build_base(base,binary,build)
 plan.update(output=str(OUT),binary=str(binary),binary_sha256=sha(binary),base=base,candidate_identity=candidate,limits=LIMITS,requests=requests(),scope=__doc__,diagnostic_capacity='light',qualification=False,automatic_retries=False,planned=dict(starts=1,chats=8,websocket_sessions=1,ingress_starts=1,seconds=600),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
 plan['identity'].update(binary_sha256=sha(binary),protocol_sha256=base['protocol_sha256'])
 plan['profiles']['primary']=copy.deepcopy(plan['profiles']['light'])
 record=ROOT/'docs/STATUS.md'
 plan['conversation']['source']['sha256']=sha(record)
 plan['conversation']['files'][str(record)]=sha(record)
 plan['sources']={n:sha(ROOT/n) for n in plan['sources']}
 for p in (Path(__file__),source,W/'input-review-01/observed.json',W/'cpu-01/result.json',W/'engine-build-01/result.json'):
  plan['sources'][str(p)]=sha(p)
 for v in candidate.values():
  if type(v) is dict and 'path' in v:plan['sources'][v['path']]=v['sha256']
 require(read(W/'cpu-01/result.json')['status']=='PASS' and read(W/'engine-build-01/result.json')['binary_sha256']==sha(binary),'new candidate not CPU verified')
 save(OUT/'plan.json',plan);print(json.dumps(dict(status='PREPARED',binary_sha256=sha(binary),limits=LIMITS)))

if __name__=='__main__':
 if sys.argv[1:]==['prepare']:prepare()
 else:
  require(sys.argv[1:]==['run'],'explicit frozen mode required')
  def stopped(_s,_f):raise TimeoutError('focused business deadline/interruption')
  signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGALRM,stopped);signal.alarm(600)
  try:
   with foreground.base.lifecycle.child_subreaper():Stage(read(OUT/'plan.json')).run()
  finally:signal.alarm(0)

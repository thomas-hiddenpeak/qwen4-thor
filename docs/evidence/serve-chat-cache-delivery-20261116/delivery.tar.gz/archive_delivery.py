"""Archive public delivery receipts without copying private state or payloads."""
import json
import re
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_service.package import read, require, save, sha

W = Path(__file__).resolve().parent
OUT = ROOT / 'docs/evidence/serve-chat-cache-delivery-20261116'
result = read(W / 'delivery-01/result.json')
current = result['publication']['current']
require(result['status'] == 'PASS_CHAT_CACHE_DELIVERED' and
        result['publication']['revision'] == 174 and
        result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0,
        'delivery not accepted')
for name, key in [('q4t', 'engine_binary_sha256'),
                  ('q4t.release.json', 'engine_release_sha256'),
                  ('service.release.json', 'service_release_sha256'),
                  ('service.acceptance.json', 'service_acceptance_sha256')]:
    require(sha(ROOT / 'build/.q4t-publication/current' / name) == current[key], 'default identity drift')

secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)

for policy in ('build/service/engine/client-policy.json', 'build/service/gateway-policy.json'):
    collect(read(ROOT / policy))
files = [(p, 'delivery-01/' + p.name) for p in (W / 'delivery-01').iterdir()
         if p.is_file() and not p.is_symlink()]
files += [(p, 'publication-archive-01/' + p.name)
          for p in (W / 'publication-archive-01').iterdir()
          if p.is_file() and not p.is_symlink()]
for name in ('archive_delivery.py', 'deliver.py', 'run_delivery.py',
             'archive_generations.py', 'publication-archive-prepared.json',
             'publication-archive-applied.json'):
    files.append((W / name, name))
for stem in ('delivery-prepare-01', 'delivery-run-01', 'publication-archive-01'):
    for extension in ('json', 'stdout', 'stderr'):
        files.append((W / (stem + '.' + extension), stem + '.' + extension))
for path, _ in files:
    raw = path.read_bytes()
    require(not any(secret in raw for secret in secrets), 'secret in public evidence')
    require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', raw), 'private key in evidence')
OUT.mkdir()
with tarfile.open(OUT / 'delivery.tar.gz', 'w:gz') as archive:
    for path, name in sorted(files, key=lambda item: item[1]):
        archive.add(path, arcname=name, recursive=False)
(OUT / 'delivery-01').mkdir()
for name in ('result.json', 'plan.json', 'recovery-anchor.json'):
    (OUT / 'delivery-01' / name).write_bytes((W / 'delivery-01' / name).read_bytes())
save(OUT / 'acceptance.json', dict(
    status='ACCEPT_CHAT_CACHE_DELIVERY', revision=174,
    current=current, commands=len(result['commands']), seconds=result['seconds'],
    new_gpu_starts=0, state='STOPPED',
    core_client_outer_state_preserved=True, profile_budget_preserved=True,
    retained_anchor_generation=result['retained_anchor_generation'],
    files=len(files), archive_sha256=sha(OUT / 'delivery.tar.gz'),
    secret_scan_matches=0, remaining_master_tasks_active=True))
(OUT / 'README.md').write_text(f'''# Chat 标准缓存可回退发行 rev174

默认引擎0851dab3、正式服务包78d6bd7b，generation
{current['generation_sha256']}。17项STOPPED检查通过，{result['seconds']:.3f}秒，
0新增GPU：保留锚点、正式发布、新恢复周期、实际整根回退再前进及
默认check/status/observe/profiles/version/outer/publication核对。

Chat标准mode/TTL、内容断点、默认隐式缓存和最近80断点查找已进入
实际模板/token/SSD状态路径；MTP及target实际恢复、JSON/SSE、不同
suffix和client/key隔离、显式禁缓存均有真实HTTP记录。20项C++、
schema/native及8个不同业务场景通过；首次驱动错误与原捕获保留，
无重复生成，聚合指标只声称已观察7项。媒体状态缓存仍待实现。

控制、四个原生程序和客户端字节不变；core/client/outer状态、容量/
Key/配额、profile历史预算冷却保持，新版本周期保留前驱。最终STOPPED，
outer启用且累计0启动。rev166默认/状态备份及两个无活动引用generation
可恢复归档保留，不删除包或证据，密钥/私钥扫描0命中。

保留c789291b为旧v12控制/当前引擎；自动恢复保持现代根，人工整根
回退旧入口无outer仍须修复，不是独立旧引擎回退。本组实际合main
待完成。其余标准字段、媒体/后端、客户端/资源与冷启动等全部33项
master继续，不宣称完整兼容、性能或长稳通过。
''')
print(json.dumps(dict(status='ACCEPT_DELIVERY', revision=174,
                      files=len(files), secret_scan_matches=0)))

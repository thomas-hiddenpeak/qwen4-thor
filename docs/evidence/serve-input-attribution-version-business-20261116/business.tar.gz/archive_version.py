import json,re,tarfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;out=ROOT/'docs/evidence/serve-input-attribution-version-business-20261116'
require(not out.exists(),'preserve evidence');secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [ROOT/'build/service/engine/client-policy.json',ROOT/'build/service/gateway-policy.json']:collect(read(p))
files=[];decisions={}
for folder in ['retained-business-01','version-business-01']:
 work=W/folder;decision=read(work/'decision.json');business=read(work/'execution/business-final.json')
 require(business['actual_display_geometry'] and all(decision['actual_business']['postflight'].values()),'unfinished actual recovery')
 require(decision['engine_binary_sha256']=='7a23cb3038cdfeac55abd90d05861061642c7abb6663a27efd793798e54129be','wrong engine')
 decisions[folder]=dict(decision=decision,business=business)
 for p in work.rglob('*'):
  if not p.is_file() or 'state' in p.relative_to(work).parts:continue
  files.append((p,folder+'/'+str(p.relative_to(work))))
for name in ['archive_version.py','media_version.py','test_media_version.py','freeze-delivery-01.json','deliver.py','run_delivery.py','archive_generations.py']:files.append((W/name,name))
for stem in ['prepare-retained-business-01','gpu-retained-business-01','finalize-retained-business-01','finalize-retained-business-02','version-driver-cpu-01','prepare-version-business-01','gpu-version-business-01','finalize-version-business-01']:
 for suffix in ['json','stdout','stderr']:files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for p,_ in files:
 raw=p.read_bytes();require(not any(x in raw for x in secrets),'secret in public evidence')
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),'private key')
out.mkdir()
for folder in decisions:
 (out/folder).mkdir()
 for name in ['decision.json','service-release.json']:(out/folder/name).write_bytes((W/folder/name).read_bytes())
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n)
save(out/'acceptance.json',dict(status='ACCEPT_INPUT_ATTRIBUTION_VERSION_COMPOSITION',phases=decisions,files=len(files),archive_sha256=sha(out/'business.tar.gz'),secret_scan_matches=0,engine_binary_sha256='7a23cb3038cdfeac55abd90d05861061642c7abb6663a27efd793798e54129be',default_unchanged=True,delivery_pending=True,remaining_master_tasks_active=True))
ret=decisions['retained-business-01']['decision']['actual_business'];ver=decisions['version-business-01']['decision']['actual_business']
(out/'README.md').write_text(f'''# 输入归属候选精确包及版本回退业务通过

2026-11-16，保留包98b4b47e独立1启动/2生成，正式0bbfd5e6实际
2启动/4生成/1探测，均含启动自检且未超冻结边界。严格租约分别
{ret['strict_lease_seconds']:.3f}/{ver['strict_lease_seconds']:.3f}秒；NVML
{ret['nvml_queries']}/{ver['nvml_queries']}项正常。两侧实际视频几何、冻结历史SSE和
媒体/MCP/embedding能力通过；只对自有网关注入故障，Guardian保留并
换到已验保留版本。归属128字符上限、实际default档位、Responses新
medium默认及旧queued语义保留的能力也逐项核对。STOPPED、进程/端口/
锁清理通过，实际默认rev158保持。

保留包首次finalize误用--output而非--plan，命令解析后因缺计划退出，
原记录保留；改正调用后成功，未改变冻结来源、业务或租约，0重复GPU。
候选7a23cb30与旧v12控制组成回退包，不是独立旧引擎回退。自动恢复
保留现代根；人工整根回退旧入口无outer仍是R09待实现项。控制及四个
原生程序不变，旧压力/外层证据按身份复用。原记录归档且不公开私有
状态和密钥。继续可回退发布、PR实际合main和全部33项master。
''')
print(json.dumps(dict(status='ACCEPT_VERSION_COMPOSITION',files=len(files),secret_scan_matches=0)))

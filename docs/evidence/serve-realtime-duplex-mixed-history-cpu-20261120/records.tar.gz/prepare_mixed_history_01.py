from pathlib import Path
import re,json,subprocess,hashlib
W=Path(__file__).parent
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
for n in files:
 if not n.endswith(('.cpp','.h')):continue
 diff=subprocess.check_output(['git','diff','--unified=0','--',n],text=True);lines=[]
 for b,c in re.findall(r'^@@.*\+(\d+)(?:,(\d+))? @@',diff,re.M):
  if c!='0':lines+=['--lines='+b+':'+str(int(b)+int(c or '1')-1)]
 if lines:subprocess.run(['clang-format','-i',*lines,n],check=True)
new=[]
for n in files:
 if not n.startswith('tests/') or not n.endswith('.cpp'):continue
 prior=set(re.findall(r'Q4T_TEST\(\s*(\w+)',subprocess.check_output(['git','show','HEAD:'+n],text=True)))
 new += [x for x in re.findall(r'Q4T_TEST\(\s*(\w+)',Path(n).read_text()) if x not in prior]
assert len(new)==6,new
affected=['realtime_audio_reservation_hidden_until_owned_commit','realtime_audio_reservation_rejected_commit_is_atomic','realtime_audio_reservation_failure_releases_uncommitted_owner','realtime_audio_capture_freezes_existing_context_while_waiting','realtime_audio_capture_resolves_exact_order_and_real_empty_text','realtime_audio_input_failed_asr_keeps_item_and_healthy_text_context','realtime_audio_input_reservation_and_failed_growth_are_atomic','realtime_audio_input_late_completion_cannot_cross_deleted_generation','realtime_composed_input_private_transcript_still_drives_context','realtime_session_native_input_reaches_actual_chat_planner','realtime_idle_cue_requires_native_provenance_and_never_becomes_transcript','realtime_session_idle_empty_turn_reaches_actual_chat_planner']
p=W/'mixed-history-plan-01.json';plan=json.loads(p.read_text());plan.update(new_tests=new,affected_tests=affected,tests=new+affected);p.write_text(json.dumps(plan,indent=2)+'\n')
p=Path('tools/release/required_host_tests.txt');s=p.read_text();p.write_text(s+''.join(n+'\n' for n in new if n not in s))
p=Path('tools/serve_audit/inventory.json');v=json.loads(p.read_text());v['duplex_mixed_audio_history_20261120']=dict(state='development_targeted_cpu_pending',scope=plan['scope'],tests=new,limits=plan['limits'],default_revision=376)
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
def refresh(x):
 if isinstance(x,dict):
  for k,z in list(x.items()):
   if k in changed and isinstance(z,str) and len(z)==64 and Path(k).is_file():x[k]=hashlib.sha256(Path(k).read_bytes()).hexdigest()
   else:refresh(z)
 elif isinstance(x,list):
  for z in x:refresh(z)
refresh(v);p.write_text(json.dumps(v,indent=2)+'\n')
s=(W/'build_idle_01.py').read_text().replace('idle-build-01','mixed-history-build-01').replace('eaab2e88bf334640fcc4540d5a67a23e46d830ce86cf3ce48ad6b46f7cc41942','d0498c558130b1a0a8cde729dac127e3f514b25985ada896a361eab27ce09442').replace('native idle timeout, actual audio retention and local input recovery','ordered mixed audio history and per-content native ownership');(W/'build_mixed_history_01.py').write_text(s)
s=(W/'run_idle_cpu_01.py').read_text().replace('idle-cpu-01','mixed-history-cpu-01').replace('idle-build-01','mixed-history-build-01').replace('idle-plan-01','mixed-history-plan-01').replace('len(new)==26','len(new)==18').replace('tests=26','tests=18');(W/'run_mixed_history_cpu_01.py').write_text(s)
p=Path('docs/STATUS.md');s=p.read_text();at=s.index('\n## 当前实际默认');s=s[:at]+'''
直接混合音频的历史所有权已开发：同一消息按原顺序保留文字/音频，
每段真实转写独立回填并等待整项完成；公开隐私过滤覆盖全部音频段。
客户端transcript不能获得原生权限，失败/删除/复用不替换已有快照。
冻结6新+12相关CPU及20来源反例/120秒待验，尚未连接直接音频执行。
''' +s[at:];p.write_text(s)
p=Path('docs/log/2026-11-20.md');s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## 直接混合音频的逐内容历史所有权开发

日期：2026-11-20。

做了什么：扩展同一原生输入历史为有序文字/多段音频；预留隐藏，
客户端音频和transcript不进入已处理文本；实际每段转写有独立完成
索引，失败不会被其他成功段覆盖，部分完成保留整项资源预留。隐私
过滤覆盖所有音频段，snapshot仍冻结同一item/generation且等待整项。
冻结6新+12相关CPU和20来源反例/120秒待验，0GPU、默认rev376保持。

为什么：直接混合输入不能打乱内容顺序，也不能借用客户端提供的
转写冒充实际ASR或让迟到结果落在同ID的新消息上。

下一步：针对CPU后继续有限音频原生处理/队列、实际item.create与
response.create接线，再统一业务短验、恢复交付和全部master。
''' +s[i:])

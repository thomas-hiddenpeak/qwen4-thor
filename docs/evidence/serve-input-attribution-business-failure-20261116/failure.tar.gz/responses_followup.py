import argparse,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R));W=Path(__file__).resolve().parent
from tools.serve_protocol import input_attribution_acceptance as a
from tools.serve_service.package import read,save,sha,require
LIMITS=dict(starts=1,chats=2,controls=2000,seconds=600)
def requests():return {k:v for k,v in a.requests().items() if k in ('response_default','response_null')}
def prepare(args):
 a.base.prepare(args,rows=requests(),limits=LIMITS,scope='Only Responses JSON/SSE, actual defaults, explicit full projection and owned deletion; prior four Chat passes reused')
 path=args.output.resolve()/'plan.json';p=read(path)
 for name in subprocess.check_output(['git','ls-files','tools/serve_responses'],cwd=R,text=True).splitlines():p['sources'][name]=sha(R/name)
 p['drivers']={str(Path(__file__).resolve()):sha(Path(__file__)),str(W/'partial-review.json'):sha(W/'partial-review.json')}
 prior=read(W/'partial-review.json');require(p['binary_sha256']==prior['binary_sha256'] and prior['cleanup_complete'],'prior runtime differs')
 p['prior_chat_passes']=prior;p['planned']=dict(starts=1,chats=2,gets=2,deletes=2)
 p['mutations']=['one own model/private object store; graceful cleanup only']
 save(path,p)
class Stage(a.Stage):
 limits=LIMITS;request_templates=staticmethod(requests);success_status='PASS_INPUT_ATTRIBUTION_RESPONSES_FOLLOWUP'
 def __init__(self,plan):
  for n,h in plan['drivers'].items():require(sha(n)==h,'driver/reuse evidence drift')
  super().__init__(plan)
 def business(self):
  values=[]
  for label,body in self.plan['requests'].items():
   value=self.sdk(label,'create',body);a.check_response(value)
   if body.get('stream'):
    events=a.wire_events((self.out/(label+'.wire')).read_text())
    require(all(not a.errors(e,'response_event') for e in events),'SSE schema')
    require(all(e['response']['reasoning']['effort']=='medium' and e['response']['service_tier']=='default' for e in events if 'response' in e),'SSE defaults')
   saved=self.sdk(label+'-get','retrieve',response_id=value['id'],query=dict(include=['message.output_text.logprobs']))
   require(saved==value,'full stored Responses snapshot changed')
   deleted=self.sdk(label+'-delete','delete',response_id=value['id']);require(deleted.get('deleted') is True,'delete did not commit')
   values.append(value)
  metrics=self.drained('final');require(metrics['q4t_requests_total']==metrics['q4t_requests_success_total']==2 and metrics['q4t_requests_error_total']==0,'unexpected replay/error')
  log=(self.out/'model.log').read_text();require(a.IDENTIFIER not in log,'raw attribution in log')
  for label,body in self.plan['requests'].items():
   lines=[l for l in log.splitlines() if '[q4t][request]' in l and 'event=end' in l and 'id='+body['request_id']+' ' in l]
   require(len(lines)==1 and 'outcome=success' in lines[0] and 'safety_identifier_sha256='+a.expected_digest(a.IDENTIFIER) in lines[0],'attribution mismatch')
  save(self.out/'business-summary.json',dict(starts=1,generations=2,actual_tier='default',effort_default='medium',full_stored_snapshots_equal=True,owned_objects_deleted=True,same_model_pid=True,attribution_sha256=a.expected_digest(a.IDENTIFIER),prior_four_chat_passes_reused=True))
def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True);q=sub.add_parser('prepare')
 for n in ('binary','output'):q.add_argument('--'+n,type=Path,required=True)
 q.add_argument('--port',type=int,default=18188);q=sub.add_parser('run');q.add_argument('--plan',type=Path,required=True);args=p.parse_args()
 if args.mode=='prepare':prepare(args)
 else:
  with a.base.lifecycle.child_subreaper():Stage(read(args.plan)).run()
if __name__=='__main__':main()

import copy,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R));W=Path(__file__).resolve().parent;P=W/'business-01'
from tools.serve_protocol import input_attribution_acceptance as a
from tools.serve_service.package import read,save,sha,require
plan=read(P/'plan.json');result=read(P/'result.json');exit=read(P/'lease/exit.json');cleanup=read(P/'cleanup.json')
require(result['status']=='FAILED' and result['counts']['starts']==1 and result['counts']['chats']==5,'unexpected prior result')
require('stored Responses result changed' in result['error'],'different failure')
require(exit['status']=='COMMAND_FAILED' and exit['child_returncode']==1,'environment differs')
queries=[json.loads(s) for s in (P/'lease/nvml-queries.jsonl').read_text().splitlines()]
events=[json.loads(s) for s in (P/'lease/events.jsonl').read_text().splitlines()]
require(queries and all(q['status']=='OK' and not q['observed_errors'] for q in queries),'monitor invalid')
require(all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events),'conflict')
require(cleanup['ports_released'] and cleanup['lease_continuously_held'] and not cleanup['remaining'] and cleanup['model_exit']==0,'cleanup incomplete')
require(sha(plan['binary'])==plan['binary_sha256'],'binary changed')
changes={p for p,h in plan['sources'].items() if sha(R/p)!=h}
require(changes=={'tools/serve_protocol/input_attribution_acceptance.py'},'unexpected source changes: '+str(changes))
wire={}
for label in ('json','sse','tool','follow'):
 body=read(P/(label+'.request.json'));raw=(P/(label+'.wire')).read_bytes();wire[label]=a.chat_wire(raw,body.get('stream',False))
 sdk=read(P/(label+'.sdk.json'));require(sdk['ok'] and sdk['result']['finish_reason'] in ('stop','tool_calls'),'Chat terminal')
 if body.get('stream'):a.style.check_padding(raw,body['stream_options'].get('include_obfuscation',True))
 require(a.IDENTIFIER not in json.loads((P/(label+'-preflight.wire')).read_bytes())['prompt'],'prompt attribution')
 if label in ('json','sse'):require(sdk['result']['message']['content'].strip()=='42','Chat answer')
source=read(P/'tool-execution.json')['result']['source'];actual=json.loads(read(P/'follow.result.json')['message']['content']);title=source['text'].splitlines()[0].split(': ',1)[1]
require(source['sha256']==plan['sources'][a.DOCUMENT]==sha(R/a.DOCUMENT),'document hash')
require(actual['title'] in (title,title.lstrip('# ')) and actual['citation']==source['citation'] and actual['sha256']==source['sha256'],'actual closure')
created=json.loads((P/'response_default.wire').read_bytes());stored=json.loads((P/'response_default-get.wire').read_bytes());a.check_response(created)
expected=copy.deepcopy(created)
for item in expected['output']:
 for content in item.get('content',[]):
  if content.get('type')=='output_text':content.pop('logprobs',None)
require(expected==stored,'failure was not exactly documented include projection')
# This explains the failure only; it does not waive the full-projection GET.
log=(P/'model.log').read_text();require(a.IDENTIFIER not in log,'raw identifier in log')
for label in ('json','sse','tool','follow','response_default'):
 body=plan['requests'][label];lines=[l for l in log.splitlines() if '[q4t][request]' in l and 'event=end' in l and 'id='+body['request_id']+' ' in l]
 digest=a.expected_digest(a.IDENTIFIER) if body.get('safety_identifier') else '-'
 require(len(lines)==1 and 'outcome=success' in lines[0] and 'safety_identifier_sha256='+digest in lines[0],'diagnostic mismatch')
metrics=read(P/'response_default-get-drain.metrics.json')[-1]
require(metrics['q4t_requests_total']==metrics['q4t_requests_success_total']==5 and metrics['q4t_requests_error_total']==0,'core failure')
frozen=subprocess.check_output(['git','show',plan['source_commit']+':tools/serve_protocol/input_attribution_acceptance.py'],cwd=R)
(W/'original-business-driver.py').write_bytes(frozen);require(sha(W/'original-business-driver.py')==plan['sources']['tools/serve_protocol/input_attribution_acceptance.py'],'driver snapshot')
receipt=dict(status='REUSE_FOUR_CHAT_PASSES_RESPONSES_RETRIEVAL_PENDING',binary_sha256=plan['binary_sha256'],prior_plan_sha256=sha(P/'plan.json'),prior_result_sha256=sha(P/'result.json'),partial_cpu_review=True,actual_starts=1,actual_generations=5,nvml_queries=len(queries),strict_lease_seconds=events[-1]['monotonic']-events[0]['monotonic'],cleanup_complete=True,chat_wire=wire,actual_document=actual,original_failure_preserved=True,failure='GET without include intentionally projects logprobs away; full equality requires explicit include',remaining=['Responses JSON full snapshot retrieval','Responses null SSE and full snapshot retrieval','new owned object deletion'],runtime_changed=False)
save(W/'partial-review.json',receipt);print(json.dumps(receipt))

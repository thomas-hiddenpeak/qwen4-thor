"""PR53: ten directly affected fixture/loss-of-ack contracts, no GPU."""
from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'cpu-01'
B=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
scope=json.loads((W/'scope-01.json').read_text());build=json.loads((W/'build-01/result.json').read_text())
assert build['status']=='BUILD_PASS' and sha(B)==build['binary_sha256']
assert sha(W/'required-01.txt')==scope['required_sha256']
for name,digest in scope['source_sha256'].items():assert sha(R/name)==digest,name
assert not O.exists();O.mkdir(mode=0o700);os.link(B,O/'host-tests')
commands=[[str(B),'--required-list',str(W/'required-01.txt')],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
save(O/'plan.json',dict(scope=scope,commands=commands,binary_sha256=sha(B)))
start=time.monotonic();rows=[]
try:
 for i,command in enumerate(commands):
  env=os.environ.copy();env['Q4T_TEST_OUTPUT_DIR']=str(O/'fixtures')
  with (O/f'command-{i}.stdout').open('w') as out,(O/f'command-{i}.stderr').open('w') as err:
   result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=scope['max_seconds']-(time.monotonic()-start))
  rows.append(dict(command=command,exit_code=result.returncode));assert result.returncode==0,command
 assert '10 tests, 10 passed, 0 failed, 0 skipped' in (O/'command-0.stdout').read_text()
 audit=json.loads((O/'command-1.stdout').read_text());assert audit['inventory_current'] and audit['mutation_checks']==20
 assert all(sha(R/name)==digest for name,digest in scope['default'].items())
 result=dict(status='PASS',seconds=time.monotonic()-start,commands=rows,tests=10,source_counterexamples=20,binary_sha256=sha(B),default_unchanged=True,gpu_actions=0,original_ci_failure_preserved=True)
except BaseException as error:
 result=dict(status='FAILED',seconds=time.monotonic()-start,commands=rows,error=repr(error),gpu_actions=0);save(O/'result.json',result);raise
save(O/'result.json',result);print(json.dumps(result))

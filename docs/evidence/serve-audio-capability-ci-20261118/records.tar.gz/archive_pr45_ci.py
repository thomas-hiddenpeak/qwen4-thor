import hashlib,json,subprocess,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;T=W/'pr45-ci-fix'
O=T/'docs/evidence/serve-audio-capability-ci-20261118';O.mkdir()
files=[W/'pr45-ci-failure-01.log',*sorted((W/'pr45-capability-cpu-01').iterdir()),*sorted((W/'pr45-capability-cpu-02').iterdir()),Path(__file__).resolve()]
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(W)),recursive=False)
a=json.loads((W/'pr45-capability-cpu-02/result.json').read_text());assert a['status']=='PASS'
a.update(base='f3268465bbff5a2ffed84bcc5d8589a29cd56a08',original_ci='https://github.com/thomas-hiddenpeak/qwen4-thor/actions/runs/44128660281',source_sha256=hashlib.sha256((T/'tests/server_asr_protocol_test.cpp').read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((O/'records.tar.gz').read_bytes()).hexdigest(),new_gpu_starts=0,default_revision=286,main_merge_pending=True)
(O/'result.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text('''# PR45转录能力声明测试修复（2026-11-18）

公开58组CTest中57组通过；主host组唯一失败为旧断言仍要求三项
remaining_native_work。对齐/完整segment/VAD已实现和实际验收后，
运行时代码正确保留说话人分离一项。修复测试为检查具体名称及各组件
声明/配置状态；没有修改运行时或把未完成说话人能力标记通过。

Thor必要构建零警告；三个直接相关能力用例通过，0.0075秒、0GPU。
首次本地调用误用--tests选项，尚未执行测试，失败原件保留；改用
既有--required-list后执行三项。没有重跑完整模型/性能/已验GPU链。

编译在现有独立host构建目录执行；主工作树新增speaker独立目标未
加入host registry，运行时及host源与PR冻结头相同，只有本测试改动。
本修复通过独立detached工作区只更新PR45；后续speaker代码不混入。
默认rev286保持，等待最终CI和实际合main，全部master继续。
''')
intro='''[PR45能力声明旧测试已修](evidence/serve-audio-capability-ci-20261118/README.md)：
公开CI只有旧remaining数量断言失败；改核对具体待办和组件状态，
3项相关CPU通过、0GPU。原CI及一次本地参数失败保留，运行时和
rev286未变；修复独立进入PR45，等待最终检查及合main，全部master继续。

'''
p=T/'docs/STATUS.md';p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=T/'docs/log/2026-11-18.md';s=p.read_text();h,body=s.split('\n',1);p.write_text(h+'''\n\n## PR45能力声明旧测试修复（2026-11-18）

公开CI暴露旧断言在时间戳/VAD完成后仍要求三项待办。改为检查
具体剩余说话人项以及已实现组件的配置状态，3项CPU通过，0GPU。
原CI及一次测试入口参数错误保留；运行时及rev286未改。
原因：测试须跟随实际能力，不能删掉尚未完成的功能或弱化门禁。
下一步最终CI、实际合main；后续speaker及全部master继续。
[证据](../evidence/serve-audio-capability-ci-20261118/README.md)。\n'''+body)
print(json.dumps(a))

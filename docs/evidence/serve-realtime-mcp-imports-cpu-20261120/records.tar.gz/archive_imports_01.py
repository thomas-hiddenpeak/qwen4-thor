from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-mcp-imports-cpu-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
r=read(W/'imports-cpu-01/result.json');b=read(W/'imports-build-01/result.json');assert r['status']=='PASS' and b['status']=='BUILD_PASS' and b['warnings']==0
assert all(sha(R/p)==h for p,h in r['sources'].items())
files={n:W/n for n in ['imports-plan.json','imports-required.txt','build_imports_01.py','run_imports_cpu_01.py','archive_imports_01.py','imports-build-01/plan.json','imports-build-01/result.json','imports-build-01/build.log','imports-cpu-01/result.json','imports-cpu-01/stdout.txt','imports-cpu-01/stderr.txt']}
files.update({'source/'+p:R/p for p in r['sources']})
O.mkdir();rows={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with tarfile.open(O/'records.tar.gz','w:gz') as a:
 for n,p in sorted(files.items()):a.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as a:
 assert set(a.getnames())==set(rows)
 for m in a:assert hashlib.sha256(a.extractfile(m).read()).hexdigest()==rows[m.name]['sha256']
save(O/'index.json',dict(files=rows,archive_sha256=sha(O/'records.tar.gz')))
accepted=dict(status='PASS_REALTIME_MCP_ASYNC_IMPORT_OWNERSHIP_CPU',distinct_cases=20,new_async_cases=14,new_history_cases=2,affected_existing_cases=4,case_executions=20,failed=0,skipped=0,seconds=r['seconds'],build_seconds=b['seconds'],warnings=0,binary_sha256=r['binary_sha256'],runtime_connected=False,actual_mcp_http_import_evidence_reused='serve-realtime-mcp-catalog-cpu-20261120',maximum_workers=4,maximum_retained_entries=64,maximum_private_bytes=16<<20,maximum_history_bytes=16<<20,maximum_deadline_ms=30000,late_results_cannot_replace_deleted_generation=True,pending_owned_catalog_omitted_from_default_snapshot=True,pending_function_contract_preserved=True,failed_and_unknown_catalogs_grant_no_authority=True,gpu_actions=0,llm_requests=0,default_unchanged=True,default_revision=396,service_state='STOPPED',all_master_tasks_active=True)
save(O/'acceptance.json',accepted)
(O/'README.md').write_text(f'''# Realtime MCP异步目录与历史所有权：CPU

2026-11-20。20项通过、0失败/0跳过，{r['seconds']:.3f}秒：14项异步导入/
事件/错误/边界，2项目录历史，4项直接受影响的原历史合同。必要host
构建{b['seconds']:.3f}秒零警告；原host binary和默认rev396均保持。

会话线程拥有公开历史与事件；最多4个worker、64个保留条目和16MiB
私有目录存储，队列共用有限期限。原历史16MiB另计，worker的导入
结果仍受原生目录上限约束。只有真实完成、身份/凭据/投影一致且
成功保留的目录可取得私有调用依据；空目录成功与导入失败分开。

原生pending目录不阻塞默认文本历史快照；明确引用和函数待完成
合同保持。删除/替换会立即撤销旧代权限，迟到成功不能复活或替换
重用ID；取消会停止自有worker并阻止队列启动。公开事件失败停止
发布，不暗中启动导入；容量失败不驱逐已有条目、不留下半个目录。

本组使用可控导入回调验证线程和终态；真实原生HTTP tools/list的
[12项原证据](../serve-realtime-mcp-catalog-cpu-20261120/README.md)按未改
来源复用。没有新增模型/GPU/远端工具调用，不能据此宣称实际LLM
MCP闭环已验。公开会话入口尚未连接，继续配置事务、调用审批、真实
SDK业务及恢复交付，全部master继续。

[计划](../../SERVE_REALTIME_MCP_2026-11-20.md) · [结果](acceptance.json) ·
[索引](index.json) · [源码与原始记录](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();s=s.replace('本组实现异步目录所有者及历史隔离，冻结20项CPU/120秒，0GPU；\n删除/替换、迟到结果、线程/存储边界一并验证，公开运行时接线继续。','[异步目录与历史隔离20项CPU](evidence/serve-realtime-mcp-imports-cpu-20261120/README.md)\n已通过，0GPU；删除/替换、迟到结果、线程/存储边界一并覆盖。公开\n运行时尚未连接，继续会话配置事务和调用审批。');p.write_text(s)
p=R/'docs/SERVE_REALTIME_MCP_2026-11-20.md';p.write_text(p.read_text()+'''\n本组[20项CPU通过](evidence/serve-realtime-mcp-imports-cpu-20261120/README.md)，\n0.064秒；46.764秒host构建零警告。验证为异步所有权和直接受影响\n历史合同，实际导入网络复用前组来源。继续公开会话事务和调用审批，\n不将目录组件当完整MCP兼容；默认rev396 STOPPED保持。\n''')
p=R/'docs/log/2026-11-20.md';s=p.read_text();at=s.index('\n\n')+2;s=s[:at]+'''## Realtime MCP异步目录与历史隔离20项CPU通过

日期：2026-11-20。

做了什么：[20项CPU](../evidence/serve-realtime-mcp-imports-cpu-20261120/README.md)
0.064秒通过，46.764秒host零警告。4worker/64项/16MiB私有保留和
有限队列期限，成功空目录/失败/未知明确区分；删除或替换后的旧
结果不能写回历史或授予调用权。公开事件失败不暗中启动网络任务。

为什么：辅助工具发现必须有独立生命周期和资源边界；加载中原生
目录不阻塞文本历史快照，同时保留函数待完成及明确引用的原合同。

下一步：连接实际会话配置事务、审批调用及SDK/GPU业务和恢复；
本组是CPU组件接受，公开运行时尚未连接。默认rev396 STOPPED、
0GPU/0模型请求；原生HTTP目录12项证据按未改来源复用，总目标继续。

'''+s[at:];p.write_text(s)
p=R/'docs/README.md';s=p.read_text();at=s.index('\n\n')+2;s=s[:at]+'- [Realtime MCP异步目录与历史隔离CPU](evidence/serve-realtime-mcp-imports-cpu-20261120/README.md)\n\n'+s[at:];p.write_text(s)
p=R/'docs/serve-master-goals-v2.json';j=read(p);m=j['realtime_progress']['mcp_20261120'];m['state']='definitions_native_catalog_and_async_ownership_cpu_accepted_session_integration_next';m['imports_cpu']=accepted;m['imports_evidence']='evidence/serve-realtime-mcp-imports-cpu-20261120/README.md';m['remaining'][0]='connect transactional session/response configuration to native async imports and immutable generation snapshots';save(p,j)
print(json.dumps(accepted))

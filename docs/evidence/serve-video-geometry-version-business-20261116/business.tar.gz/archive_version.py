import json,re,tarfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;out=ROOT/'docs/evidence/serve-video-geometry-version-business-20261116';out.mkdir()
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [ROOT/'build/service/engine/client-policy.json',ROOT/'build/service/gateway-policy.json']:
 collect(read(p))
files=[];decisions={}
for folder in ['retained-business-01','version-business-01']:
 work=W/folder;decision=read(work/'decision.json');business=read(work/'execution/business-final.json')
 require(business['actual_display_geometry'] and all(decision['actual_business']['postflight'].values()),'unfinished actual recovery')
 decisions[folder]=dict(decision=decision,business=business)
 for p in work.rglob('*'):
  if not p.is_file() or 'state' in p.relative_to(work).parts:continue
  files.append((p,folder+'/'+str(p.relative_to(work))))
 for n in ['decision.json','service-release.json']:
  target=out/folder/n;target.parent.mkdir(exist_ok=True);target.write_bytes((work/n).read_bytes())
for name in ['archive_version.py','media_version.py','test_media_version.py','freeze-version-01.json','deliver.py','run_delivery.py','archive_generations.py']:
 files.append((W/name,name))
for stem in ['prepare-version-retained-01','gpu-version-retained-01','finalize-version-retained-01','prepare-version-business-01','gpu-version-business-01','finalize-version-business-01']:
 for suffix in ['json','stdout','stderr']:files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for p,_ in files:
 raw=p.read_bytes();require(not any(x in raw for x in secrets),'secret in public evidence')
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),'private key')
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n)
save(out/'acceptance.json',dict(status='ACCEPT_NATIVE_VIDEO_GEOMETRY_VERSION_COMPOSITION',phases=decisions,files=len(files),archive_sha256=sha(out/'business.tar.gz'),secret_scan_matches=0,engine_binary_sha256='a7bd6785339371a686b940a9edc2eb97b371604f451212a102a0d907c75f119c',default_unchanged=True,delivery_pending=True,remaining_master_tasks_active=True))
(out/'README.md').write_text('''# 显示候选精确包及版本回退业务通过

2026-11-16，保留包a9bd9c73独立1启动/2生成/53.503秒严格租约、51项
NVML正常；正式8d9c07f1实际2启动/4生成/1探测/101.308秒严格租约、
95项NVML正常。生成数含启动自检，均在冻结上限内。

两侧都用原镜像MP4：正确读出四个角点与landscape；只对自有网关注入
一次致命故障，原Guardian保持，模型/控制器/网关按已验保留版本换代。
冻结视频previous_response_id的SSE续答仍正确，能力与profile历史保持。
严格环境、默认源身份、持久STOPPED、自有进程/端口/flock清理通过。

当前a7bd6785引擎与旧控制实现组成回退包，不是独立旧引擎回退。
原控制和辅助二进制不变，既有RAM压力/外层监护证据按原身份复用；
本记录没有重新运行这些场景，也无性能/完整质量/长稳结论。两段
原始记录、驱动与交付准备留存，私有状态/Key不公开。rev142保持，
接着可回退发布与PR30实际合main，全部master继续。
''')
print(json.dumps(dict(status='ACCEPT_VERSION_COMPOSITION',files=len(files),secret_scan_matches=0)))

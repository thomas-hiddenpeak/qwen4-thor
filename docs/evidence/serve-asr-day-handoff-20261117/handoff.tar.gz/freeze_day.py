"""Freeze the existing core-service day workload without running a model."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

R = Path(__file__).resolve().parents[2]; W = Path(__file__).resolve().parent
S = W/'validation-src'; O = W/'frozen-handoff-01'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def protected():
    return {str(R/n):sha(R/n) for n in ['build/q4t', 'build/q4t.release.json',
        'build/service/manifest.json', 'build/service.release.json', 'build/service-native-state/ledger.json']}
os.umask(0o077)
assert S.exists() and O.exists() and not (O/'acceptance.json').exists()
assert sorted(p.name for p in S.iterdir()) == ['.git']
before = protected(); delivered = read(W/'delivery-01/result.json')
assert delivered['status'] == 'PASS_NATIVE_ASR_DELIVERED'
current = delivered['publication']['current']
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=S, text=True).strip()
assert commit == '5ed5f57c08ab906bf5c1dcda41549bf4c3b5bf9a' or commit.startswith('5ed5f57c')
patterns = '/*\n!/*/\n/tools/\n/src/\n/include/\n/tests/\n/cmake/\n/docs/SERVE_MEMORY_STOP_2026-11-03.md\n'
with (O/'read-tree.stdout').open('x') as out, (O/'read-tree.stderr').open('x') as err:
    subprocess.run(['git', '-C', str(S), 'read-tree', '-mu', 'HEAD'],
        stdout=out, stderr=err, check=True, timeout=60)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=S)
assert subprocess.check_output(['git', 'rev-parse', '--git-common-dir'], cwd=S, text=True).strip() == str(R/'.git')
package = Path(current['package'])
links = {'q4t':package/'engine/q4t', 'q4t.release.json':package/'engine/q4t.release.json',
         'service':package, 'service.release.json':W/'delivery-01/candidate-service.release.json'}
(S/'build').mkdir()
for name, path in links.items(): (S/'build'/name).symlink_to(path)
steps = []
for name, args in [('prepare', ['prepare', '--profile', 'day', '--package', 'build/service', '--output', '.q4t-work/day-01']),
                   ('check', ['check', '--plan', '.q4t-work/day-01/plan.json'])]:
    argv = ['/usr/bin/python3', '-I', '-B', 'tools/serve_soak/native_stage.py', *args]
    started = time.monotonic()
    with (O/(name+'.stdout')).open('x') as out, (O/(name+'.stderr')).open('x') as err:
        result = subprocess.run(argv, cwd=S, stdout=out, stderr=err, timeout=90)
    step = dict(name=name, argv=argv, cwd=str(S), exit_code=result.returncode, seconds=time.monotonic()-started)
    (O/(name+'.json')).write_text(json.dumps(step, indent=2)+'\n'); steps.append(step)
    assert result.returncode == 0, name
assert protected() == before
plan = read(S/'.q4t-work/day-01/plan.json')
assert plan['package']['manifest_sha256'] == current['manifest_sha256']
assert not (S/'.q4t-work/day-01/execution').exists()
a = dict(status='PASS_FROZEN_DAY_HANDOFF', source_commit=commit, workspace=str(S), revision=276,
    package=plan['package'], service_id=plan['service_id'], plan=str(S/'.q4t-work/day-01/plan.json'),
    plan_sha256=sha(S/'.q4t-work/day-01/plan.json'), sources=len(plan['sources']),
    links={k:str(v) for k,v in links.items()}, protected_default=before,
    production_unchanged=True, same_git_common_dir=True, sparse_checkout_patterns=patterns.splitlines(),
    steps=steps, model_actions=0, executed=False, owner='user',
    unchanged_existing_core_workload=True, asr_long_stability_accepted=False)
(O/'acceptance.json').write_text(json.dumps(a, indent=2)+'\n')
E = R/'docs/evidence/serve-asr-day-handoff-20261117'; E.mkdir()
with tarfile.open(E/'handoff.tar.gz', 'w:gz') as archive:
    for p in O.iterdir(): archive.add(p, arcname='review/'+p.name, recursive=False)
    for n in ['plan.json', 'handoff.json']: archive.add(S/'.q4t-work/day-01'/n, arcname=n, recursive=False)
    archive.add(W/'freeze_day.py', arcname='freeze_day.py', recursive=False)
    archive.add(W/'freeze_day-01.py', arcname='freeze_day-01.py', recursive=False)
    archive.add(W/'freeze-day-01.log', arcname='freeze-day-01.log', recursive=False)
a['archive_sha256'] = sha(E/'handoff.tar.gz')
(E/'acceptance.json').write_text(json.dumps(a, indent=2)+'\n')
(E/'README.md').write_text('''# rev276固定长稳入口

精确ASR包和独立detached源码的既有core day prepare/check通过，
0模型动作、24小时未运行。稀疏检出保留驱动全部源文件、原生源
和业务文档，避免重复复制大量历史证据；共享原严格GPU锁，所有
实际依赖SHA均已核对。后续开发和默认变更不漂移本计划。

该day继续原有五项核心业务循环，不声称ASR或所有新API的长稳
已经验证。最终Q03需覆盖后续音频等后端的完整长稳交接；长稳
实跑仍由用户负责。原rev266与更早入口保持，全部master继续。
''')
p = R/'docs/SERVE_NATIVE_SOAK_HANDOFF_2026-11-16.md'; text = p.read_text()
start = text.index('当前rev266'); end = text.index('## 当前已准备的入口')
text = text[:start]+f'''当前rev276包`{current['manifest_sha256']}`
已交付原生ASR、固定资源预算与恢复资格。真实主轻2启动12创建，
接入/恢复组合含两TLS原驱动失败累计6启动20创建1探测，316.806秒，
307次NVML正常；原FAILED和组合接受来源明确分列。
[实际交付](evidence/serve-asr-delivery-20261117/README.md)19条STOPPED
命令完成整根回退和再前进，0新增GPU，原周期和预算保持。
连续60秒长稳驱动短验仍属于rev188，[原证据](evidence/serve-native-soak-business-20261116/README.md)保留。

[当前独立day prepare/check](evidence/serve-asr-day-handoff-20261117/README.md)
已完成，24小时未运行。快照固定`{commit[:8]}`及rev276包，采用稀疏
detached检出保留全部驱动依赖；不依赖活动源码或未来默认指针。
此day继续原五项核心业务循环，不额外声称ASR长稳。最终Q03仍需
补齐后续音频等后端的完整长稳交接，实际长稳由用户运行。

''' + text[end:]
text = text.replace('c9cd8195-b1b3-41fb-9392-403de3919727', plan['service_id'])
text = text.replace('serve-native-maintenance-20261117/validation-src', 'serve-audio-native-20261117/validation-src')
text = text.replace('此计划继续验证rev266', '此计划继续验证rev276').replace('把rev266证据移称新版本证据', '把rev276证据移称新版本证据')
text = text.replace('原rev260/rev254/', '原rev266/rev260/rev254/')
p.write_text(text)
p = R/'docs/serve-master-goals-v2.json'; j = read(p)
for task in j['tasks']:
    if task['id'] == 'Q03':
        task['current_native_day_handoff'] = a | dict(evidence='evidence/serve-asr-day-handoff-20261117/README.md')
        required = task.setdefault('remaining_required', [])
        item = 'Final long-run handoff must cover newly implemented audio/backend combinations; actual long runs remain user-owned'
        if item not in required: required.append(item)
j['next'] = 'rev276 core day handoff prepared, not run. Complete PR44 checks and actual merge; continue ASR alignment/segmentation and every remaining master task.'
p.write_text(json.dumps(j, ensure_ascii=False, indent=2)+'\n')
p = R/'docs/STATUS.md'; text = p.read_text().replace('继续独立长稳交接、PR44合main与全部master。', '既有core day已固定且未运行；继续PR44合main、后续后端长稳交接与全部master。'); p.write_text(text)
p = R/'docs/log/2026-11-17.md'; header, rest = p.read_text().split('\n', 1)
p.write_text(header+'''\n\n## rev276核心长稳入口已固定

独立稀疏detached快照完成既有day prepare/check，0模型动作，
默认保持；全部驱动源与包SHA核对，共享严格GPU锁。原rev266及
更早计划保留，不重复复制历史证据。此day仍为原五项核心循环，
不声称ASR长稳；最终Q03继续补音频等后端长稳交接。下一步PR44
检查合main，再推进真实对齐/分段及所有master，长稳实跑由用户负责。\n'''+rest)
print(json.dumps({k:a[k] for k in ('status', 'source_commit', 'revision', 'service_id', 'sources', 'model_actions')}))

import hashlib,json,re,shutil,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-01'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');assert v['status']=='PASS_MODERATION_DELIVERED' and v['publication']['revision']==204
assert len(v['commands'])==18 and all(c['returncode']==0 for c in v['commands'])
c=v['publication']['current'];assert v['state']=='STOPPED' and not v['new_gpu_starts']
files=[(p,'delivery-01/'+p.name) for p in D.iterdir() if p.is_file() and not p.is_symlink()]
for stem in ['delivery-prepare-01','delivery-run-01','archive-generations-01','archive-versions-01']:
 for ext in ['json','stdout','stderr']:files.append((W/(stem+'.'+ext),stem+'.'+ext))
for name in ['archive_delivery.py','deliver.py','run_delivery.py','archive_generations.py','archive_version_cycles.py','publication-archive-applied.json','publication-archive-prepared.json','version-archive-applied.json','version-archive-prepared.json','version-archive-review.json']:
 files.append((W/name,name))
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ['api_key','gateway_token','shared_secret','private_key','token'] and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for p,n in files:
 raw=p.read_bytes();assert not any(x in raw for x in secrets),n
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),n
O=R/'docs/evidence/serve-chat-moderation-delivery-20261117';O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n,recursive=False)
for n in ['result.json','recovery-anchor.json']:shutil.copyfile(D/n,O/n)
business=read(R/'docs/evidence/serve-chat-moderation-business-20261117/acceptance.json')
a=dict(status='ACCEPT_CHAT_MODERATION_DELIVERY',revision=204,current=c,commands=18,seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,core_client_outer_bytes_preserved=True,profile_migration='qualified additive capability and identity; state, history, configuration and clock preserved',root_cycles_preserved=True,manual_root=business['modern_retained']['manifest_sha256'],automatic_payload=business['automatic_fallback']['manifest_sha256'],older_engine_fallback=False,prior_rev196_preserved=True,retired_generations_archived=2,retired_versions_archived=2,deleted_files=0,files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Chat原生审核默认交付 rev204

实际服务包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`。18项STOPPED发布、整根回退和再前进
完成，{v['seconds']:.3f}秒，0新增GPU，最终STOPPED。新引擎与双客户端
一起交付，原生入口和恢复不要求nginx/systemd。

Chat标准moderation可调用实际本地分类，input/output独立score/block，
全choice审核，批准后发布block流和存储，辅助模型消耗进入同一配额。
原失败输入经修复后实际content_filter且原回答usage为0；原失败保留。
本地13类分数是当前模型估计，不冒充云端专用模型校准。

核心/client/outer状态和预算字节保持；profile只增加已验能力/身份，
原history/pending/配置/clock保持。整根切换回填原周期，仅递增revision，
未返还额度。人工回退根`{a['manual_root'][:12]}`保留outer和周期迁移；
自动payload`{a['automatic_payload'][:12]}`使用已验旧控制及当前新引擎，
不是独立旧引擎回退。原rev196包和状态备份另行保留。

退休generation/版本登记各两份通过可恢复归档腾位，0删除。真实
业务修复组4启动/17请求/238.768秒，含原失败累计8/32/443.027秒，
[业务及原失败证据](../serve-chat-moderation-business-20261117/README.md)保持。
当前控制/原生helper复用精确证据；未声称重复完整恢复矩阵、性能或
长稳。继续PR37实际检查/合main和所有剩余master任务，24小时由用户执行。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev204；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；outer/周期及审核能力完整，前驱196/188另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退'}
for label,value in rows.items():
 pattern=r'^\| '+re.escape(label)+r' \| .* \|$';s,n=re.subn(pattern,lambda _:f'| {label} | {value} |',s,count=1,flags=re.M);assert n==1,label
intro=f'''[rev204审核交付](evidence/serve-chat-moderation-delivery-20261117/README.md)已完成18项
STOPPED发布、实际整根回退与再前进，{v['seconds']:.3f}秒、0新增GPU。
输入/输出真实审核、SSE门控、存储及双客户端一起交付；原预算和周期
保持，profile仅增加已验能力/身份。PR37检查与实际合main继续，按新
默认刷新用户day交接，全部33项master保持active。

'''
marker='[rev196引用交付]';s=s.replace(marker,intro+'前驱'+marker,1)
s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro,1);p.write_text(s)
p=R/'docs/log/2026-11-17.md';s=p.read_text();head,rest=s.split('\n',1);p.write_text(head+f'''\n
## rev204审核默认可回退交付

2026-11-17：18项STOPPED发布/整根回退/再前进通过，{v['seconds']:.3f}秒，
0新增GPU；原核心/client/outer预算与周期保持，profile仅增加已验
能力/身份。已验审核引擎与双客户端实际交付；旧包/状态备份保留，
退休发布/登记各两份可恢复归档，0删除。下一步当前默认day交接、
PR37检查与实际合main，以及剩余所有master任务；阶段结束不是终点。
'''+rest)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for task in j['tasks']:
 x=task.get('chat_moderation_20261117')
 if x:x.update(state='delivered_main_pending',revision=204,manifest_sha256=c['manifest_sha256'],delivery_evidence='evidence/serve-chat-moderation-delivery-20261117/README.md',default_unchanged=False)
 if task['id']=='Q02':
  task['state']='latest_release_delivered_main_pending_remaining_tasks_active'
  task['chat_moderation_delivery_20261117']=a|dict(evidence='evidence/serve-chat-moderation-delivery-20261117/README.md')
  task['remaining_required']=['PR37 exact-head checks and actual main merge','Delivery of every remaining implementation']
 if task['id']=='R07':task['current_execution_prerequisite']='Refresh exact cold qualification against rev204 or the then-current default; do not stop camera/jtop or enter device-fence without pending maintenance handoff.'
j['next']=j['next_task']='Refresh current native day handoff, complete PR37 checks and real main merge; continue remaining Chat audio/web-search, media/state-cache/schema combinations, model backends and cold/resource/host tasks. All 33 required tasks remain the completion boundary.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev204审核默认交付](evidence/serve-chat-moderation-delivery-20261117/README.md)：真实分类/SSE/存储与整根回退，预算和原失败保持。\n')
print(json.dumps(dict(revision=204,files=len(files),seconds=v['seconds'],secret_scan_matches=0)))

"""Seal actual native roots; model/native/helper/profile identities unchanged."""
import copy,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from tools.serve_recovery import bundle,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OLD=(R/'build/service').resolve(strict=True)
LEGACY=R/'.q4t-work/serve-chat-cache-20261116/retained-01/bundle'
ALLOWED={'tools/serve_recovery/'+n+'.py' for n in ('bundle','deployment','profile_manager','root_version_policy','root_checkpoints','root_transfer')}
def replace(path,raw,mode=0o400):
 path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 if path.exists():path.chmod(0o600)
 path.write_bytes(raw);path.chmod(mode)
def main():
 os.umask(0o077)
 p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'commit source before sealing')
 protected={n:p.sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json')}
 old=bundle.verify(OLD,p.sha(OLD/'manifest.json'));legacy=bundle.verify(LEGACY,p.sha(LEGACY/'manifest.json'))
 p.require(old['version']==18 and old['files']['bin/q4t-device-control'],'modern predecessor required')
 p.require(all(p.sha(R/n)==h for n,h in p.read(OLD/'native-build.json')['source_files'].items()),'native sources changed')
 delta={n for n in bundle.SOURCES if not (OLD/'source'/n).exists() or p.sha(R/n)!=p.sha(OLD/'source'/n)}
 p.require(delta==ALLOWED,'unexpected source delta: '+str(delta))
 receipt={}
 for name in ('candidate','retained'):
  out=W/(name+'-01');p.require(not out.exists(),'preserve sealed package')
  out.mkdir(mode=0o700);target=out/'bundle';shutil.copytree(OLD,target,symlinks=True)
  manifest=copy.deepcopy(old);manifest.update(version=19,profile='q4t-service-recovery-v19')
  for n in ALLOWED:
   path=target/'source'/n;replace(path,(R/n).read_bytes());manifest['files']['source/'+n]=p.sha(path)
  extra=[]
  if name=='retained':
   rel='source/tools/serve_recovery/controller.py';raw=(LEGACY/rel).read_text()
   p.require(raw.count('from tools.serve_recovery import profile_memory as resource_client')==1 and raw.count('from tools.serve_recovery import profile_memory as resource_memory')==1,'legacy resource adapter shape')
   raw=raw.replace('from tools.serve_recovery import profile_memory as resource_client','from tools.serve_recovery import resource_client').replace('from tools.serve_recovery import profile_memory as resource_memory','from tools.serve_recovery import resource_client as resource_memory')
   replace(target/rel,raw.encode());manifest['files'][rel]=p.sha(target/rel);extra=[rel]
   p.require(manifest['files'][rel]!=old['files'][rel],'retained controller must really differ')
  replace(target/'manifest.json',json.dumps(manifest,indent=2).encode()+b'\n')
  digest=p.sha(target/'manifest.json');replace(target/'bin/q4t',bundle.launcher(digest,manifest['python']['path']),0o500)
  p.require(bundle.verify(target,digest)==manifest,'sealed root differs')
  receipt[name]=dict(package=str(target),manifest_sha256=digest)
  p.save(out/'receipt.json',receipt[name])
  changed={n for n,h in manifest['files'].items() if old['files'].get(n)!=h}
  p.require(changed=={'source/'+n for n in ALLOWED}|set(extra),'unreviewed sealed delta')
  p.save(out/'review.json',dict(status='CPU_ACCEPTED_ROOT_BUSINESS_PENDING',original=dict(package=str(OLD),manifest_sha256=p.sha(OLD/'manifest.json')),changed_files=sorted(changed),engine_manifest_identical=manifest['engine_manifest_sha256']==old['engine_manifest_sha256'],profiles_identical=manifest['recovery_profiles']==old['recovery_profiles'],native_helpers_identical=all(manifest['files'][k]==old['files'][k] for k in old['files'] if k.startswith('bin/')),retained_controller_origin=(dict(package=str(LEGACY),manifest_sha256=p.sha(LEGACY/'manifest.json'),adaptation='Only two resource client import paths; the actual older model-exit reporting behavior remains distinct') if name=='retained' else None),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),default_changed=False,actual_business_pending=True))
 p.save(W/'roots.json',receipt)
 for root in receipt.values():
  permit=version_contract.compatible(version_contract.payload(root),version_contract.payload(dict(package=str(LEGACY),manifest_sha256=p.sha(LEGACY/'manifest.json'))))
  p.require(permit['automatic'],'qualified original fallback differs')
 p.require(all(p.sha(R/n)==h for n,h in protected.items()),'default changed')
 print(json.dumps(receipt))
if __name__=='__main__':main()

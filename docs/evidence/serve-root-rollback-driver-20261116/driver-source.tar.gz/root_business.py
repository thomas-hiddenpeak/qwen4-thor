"""Real root rollback, exact consumed cycles and bounded outer recovery."""
import argparse,copy,io,json,os,runpy,signal,subprocess,sys,time,traceback,uuid
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
VERSION=runpy.run_path(str(ROOT/'tools/serve_recovery/version_acceptance.py'))
MANAGED,LEGACY=VERSION['MANAGED'],VERSION['LEGACY']
LIMITS=dict(starts=6,chats=12,probes=1,controls=3000,seconds=900)
OLD_LIMITS=LEGACY['verify'].__globals__['limits_for']
LEGACY['verify'].__globals__['limits_for']=lambda name: LIMITS if name=='root_rollback' else OLD_LIMITS(name)
VERSION['actor'].__globals__['LIMITS']=LIMITS
VERSION['probe'].__globals__['LIMITS']=LIMITS
VERSION['Stage'].fatal_gateway.__globals__['__file__']=__file__
save=LEGACY['save'];WORK=Path(__file__).resolve().parent


def check_usage(usage,state,deadline,now):
    generation=state['model_generation']
    if (usage['phase']!='active' or usage['generation']!=generation or
        usage['owner']['pid']!=state['model_pid'] or
        usage['owner']['start_ticks']!=state['model_start_ticks']):
        raise ValueError('actual usage ownership differs')
    if usage['source'] is not None:
        if usage['source']['generation']!=generation-1 or usage['snapshot'] is None:
            raise ValueError('sealed predecessor differs')
    elif generation>1:
        if usage['snapshot'] is not None or deadline is None or now<deadline or state['quota_wait_ms']!=0:
            raise ValueError('unknown usage bypassed original conservative gate')


def exact_restoration(before,after):
    if {k:v for k,v in before.items() if k!='revision'}!={k:v for k,v in after.items() if k!='revision'}:
        raise ValueError('root switch erased or changed original recovery state')
    if after['revision']<=before['revision']:raise ValueError('version revision did not advance')


def prepare():
    from tools.serve_recovery import bundle,version_contract
    from tools.serve_service import package as p
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit reviewed source')
    out=WORK/'business-01';p.require(not out.exists(),'preserve actual business evidence')
    roots=p.read(WORK/'roots.json')
    old=ROOT/'.q4t-work/serve-chat-cache-20261116/retained-01/bundle'
    fallback=dict(package=str(old),manifest_sha256=p.sha(old/'manifest.json'))
    accepted=ROOT/'.q4t-work/serve-chat-cache-20261116/retained-business-01'
    receipt={k:dict(path=str(accepted/n),sha256=p.sha(accepted/n)) for k,n in
             [('release','service-release.json'),('decision','decision.json')]}
    registrations={n:version_contract.prepare(v,v,fallback,str(uuid.uuid4()),fallback_acceptance=receipt)
                   for n,v in roots.items()}
    for desc in roots.values():
        manifest=bundle.verify(desc['package'],desc['manifest_sha256'])
        policy=p.read(Path(desc['package'])/'gateway-policy.json')
        p.require(manifest['version']==19 and manifest['ingress_mode']=='native' and not manifest['tls'] and
            policy['listen_host']=='127.0.0.1','private native root required')
    requests=p.read(ROOT/'.q4t-work/serve-chat-cache-20261116/profiles-01/plan.json')['requests']
    names=subprocess.check_output(['git','ls-files','tools/serve_recovery','tools/serve_service',
        'tools/serve_host','tools/serve_gateway','tools/evalscope','tools/examples','tools/release',
        'src/service','include/q4t/service'],cwd=ROOT,text=True).splitlines()
    names += [str(Path(__file__).resolve().relative_to(ROOT)),
              '.q4t-work/serve-root-rollback-20261116/prepare_roots.py',
              'docs/SERVE_MEMORY_STOP_2026-11-03.md']
    plan=dict(version=1,scenario='root_rollback',limits=LIMITS,package=roots['candidate'],roots=roots,
        registrations=registrations,registration=registrations['candidate'],output=str(out),
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        sources={n:p.sha(ROOT/n) for n in sorted(set(names)|bundle.NATIVE_SOURCES)},
        protected=[dict(path=str(ROOT/n),sha256=p.sha(ROOT/n)) for n in
            ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json')],
        requests={n:requests[n] for n in ('schema','tool')},default_replacement=False,
        planned=dict(starts=6,self_checks=6,business_chats=6,probes=1,outer_starts=3),
        sequence=['retained native root JSON, real gateway fatal and consumed fallback SSE',
            'stopped deploy/register candidate, real document tool call',
            'enable native outer once while stopped; rollback original consumed retained cycle',
            'retained fallback tool-result SSE; only owned Guardian fatal then outer resume JSON',
            'forward original candidate cycle; actual structured SSE; durable stop and full cleanup'],
        automatic_request_or_tool_replay=False,performance_acceptance=False)
    out.mkdir(mode=0o700)
    helper=out/'counted-cuda-probe'
    helper.write_text('#!'+sys.executable+'\nimport runpy,sys\nsys.argv='+repr([
        str(Path(__file__).resolve()),'probe','--plan',str(out/'probe-plan.json')])+\
        '\nrunpy.run_path(sys.argv[0],run_name="__main__")\n')
    helper.chmod(0o500);plan['probe_wrapper']=dict(path=str(helper),sha256=p.sha(helper))
    save(out/'plan.json',plan)
    probe_plan=dict(plan,package=roots['retained'],registration=registrations['retained'])
    save(out/'probe-plan.json',probe_plan)
    print(json.dumps(dict(plan=str(out/'plan.json'),limits=LIMITS)))


def launcher(plan,path):
    _,_,_,_,service,p=LEGACY['load_modules'](plan);LEGACY['verify'](plan)
    from tools.serve_recovery import outer_runtime
    guardian=str(Path(plan['package']['package'])/'bin/q4t-guardian')
    original=subprocess.Popen
    def spawn(argv,**options):
        if argv[0]==guardian:
            config=Path(argv[argv.index('--config')+1]);value=p.read(config)
            recovery=value['version_recovery']
            p.require(recovery['registry']==plan['registration']['registry'],'root registry changed')
            evidence=copy.deepcopy(recovery)
            for name,commands in recovery['payloads'].items():
                for role in ('controller','gateway'):
                    commands[role]=[sys.executable,'-I','-B',str(Path(__file__).resolve()),role,
                        '--plan',str(path),'--payload',name,'--config',commands[role][-1]]
            helper=plan['probe_wrapper'];p.require(p.sha(helper['path'])==helper['sha256'],'probe changed')
            recovery['cuda_probe']=helper['path'];p.save(config,value)
            save(Path(plan['output'])/'execution'/('wrapper-'+config.parent.name+'.json'),
                 dict(production=evidence,validation=recovery))
        return original(argv,**options)
    subprocess.Popen=spawn
    try:
        state=Path(plan['output'])/'execution/state'
        if plan['outer']:
            result=outer_runtime.run(state,Path(plan['package']['package']),
                                     plan['package']['manifest_sha256'],activate=True)
            code=int(result['state']!='STOPPED' or not result['cleanup_confirmed'])
        else:
            result=service.launch(plan['package']['package'],plan['package']['manifest_sha256'],state)
            code=int(result['guardian_exit_code']!=0)
        save(Path(plan['output'])/'execution'/('launcher-'+str(plan['ordinal'])+'-result.json'),result)
        return code
    finally:subprocess.Popen=original


class Stage(MANAGED['Stage']):
    def __init__(self,plan,path):
        super().__init__(plan,path);self.ordinal=0;self.is_outer=False
        self.scope=self.output/'state';self.active_registration=None

    def start(self,name,*,outer=False):
        self.ordinal+=1;self.is_outer=outer
        self.active_registration=self.plan['registrations'][name]
        plan=dict(self.plan,package=self.plan['roots'][name],registration=self.active_registration,
                  outer=outer,ordinal=self.ordinal)
        path=self.output/('launch-'+str(self.ordinal)+'.json');save(path,plan)
        with (self.output/('launcher-'+str(self.ordinal)+'.log')).open('xb') as log:
            self.process=subprocess.Popen([sys.executable,'-I','-B',str(Path(__file__).resolve()),
                'launcher','--plan',str(path)],stdin=subprocess.DEVNULL,stdout=log,stderr=log,
                pass_fds=(self.lease,),start_new_session=True,
                env={k:v for k,v in os.environ.items() if k not in
                     ('DBUS_SESSION_BUS_ADDRESS','NOTIFY_SOCKET','WATCHDOG_USEC')})

    def ready_payload(self,generation,name):
        state=self.wait(lambda s:s['model_generation']==generation and s['business_ready'])
        selected=state['version_recovery'];target=self.active_registration['payloads'][name]
        self.engine.require(selected['selected']==name and not selected['pending'] and
            selected['payload_manifest_sha256']==target['descriptor']['manifest_sha256'] and
            not selected['protected'],'runtime recovery payload differs')
        usage=self.family('usage');check_usage(usage,state,self.quota_deadlines.get(generation),time.monotonic())
        save(self.output/f'ready-{generation}.json',state);save(self.output/f'usage-{generation}.json',usage)
        return state

    def state_version(self):
        from tools.serve_recovery import access_store,version_store
        with version_store.open_bound(access_store.binding(self.scope,self.service_id)) as writer:
            return copy.deepcopy(writer.head['state']['policy'])

    def preserved(self):
        from tools.serve_recovery import deployment
        names=['ledger.json',*(w.directory_name+'/policy.json' for w in deployment.FAMILIES.values())]
        if (self.scope/'outer-recovery/policy.json').exists():names+=['outer-recovery/policy.json']
        return {n:self.engine.sha(self.scope/n) for n in names}

    def deploy(self,name,*,restore=None):
        from tools.serve_recovery import deployment
        desc=deployment.read_descriptor(self.scope);target=self.plan['roots'][name]
        before=self.preserved();version_before=self.state_version()
        result=deployment.switch(self.scope,target['package'],target['manifest_sha256'],
            expected=desc['manifest_sha256'],request_id=str(uuid.uuid4()),rollback=restore is not None)
        self.engine.require(self.preserved()==before,'deployment reset core/client/outer state')
        following=self.state_version()
        if restore is not None:
            exact_restoration(restore,following)
            self.engine.require(following['revision']==version_before['revision']+1,'global revision differs')
        save(self.output/('deployment-'+str(result['revision'])+'.json'),
             dict(result=result,protected=before,version_before=version_before,version_after=following))

    def schema(self,label,stream=False):
        body=copy.deepcopy(self.plan['requests']['schema'])
        if stream:
            from tools.examples.chat_client import read_sse
            body.update(stream=True,stream_options=dict(include_usage=True))
            response=read_sse(io.BytesIO(self.chat(label,body,raw_result=True)))
            content,finish=response.message['content'],response.finish_reason
        else:
            value=self.chat(label,body);choice=value['choices'][0]
            content,finish=choice['message']['content'],choice['finish_reason']
        self.engine.require(finish=='stop' and json.loads(content)=={'answer':42},'actual structured answer differs')

    def stop(self):
        if self.process is None:return
        if self.is_outer and self.process.poll() is None:
            from tools.serve_recovery import outer_control
            result=outer_control.request(self.service_id,'stop',timeout=2)
            save(self.output/('outer-stop-'+str(self.ordinal)+'.json'),result)
            self.process.wait(timeout=65)
        LEGACY['Stage'].stop(self)
        save(self.output/('stopped-'+str(self.ordinal)+'.json'),
             dict(preserved=self.preserved(),version=self.state_version()))
        self.process=None

    def exercise(self):
        from tools.serve_recovery import outer_manager,version_registration
        from tools.examples.chat_client import read_sse
        retained=self.plan['roots']['retained'];candidate=self.plan['roots']['candidate']
        initialized=self.service.initialize(retained['package'],retained['manifest_sha256'],self.scope)
        self.service_id=initialized['service_id'];save(self.output/'initialized.json',initialized)
        registration=self.plan['registrations']['retained']
        version_registration.install(self.scope,registration,
            request_id=registration['registry']['cycle_id'],expected_cycle=None)
        self.start('retained');first=self.ready_payload(1,'primary');self.schema('retained-primary-json')
        VERSION['Stage'].fatal_gateway(self,first)
        second=self.ready_payload(2,'fallback');self.schema('retained-consumed-sse',True)
        self.engine.require(second['guardian_pid']==first['guardian_pid'] and
            second['version_recovery']['probe_count']==1,'actual version fallback/probe differs')
        self.stop();spent=self.state_version();self.engine.require(spent['completed'] is not None,'fallback not consumed')
        self.deploy('candidate');registration=self.plan['registrations']['candidate']
        version_registration.install(self.scope,registration,
            request_id=registration['registry']['cycle_id'],expected_cycle=spent['registry']['cycle_id'])
        self.start('candidate');self.ready_payload(3,'primary')
        call=self.chat('candidate-document-tool',self.plan['requests']['tool']);message=call['choices'][0]['message']
        calls=message['tool_calls'];document='docs/SERVE_MEMORY_STOP_2026-11-03.md';digest=self.engine.sha(ROOT/document)
        self.engine.require(call['choices'][0]['finish_reason']=='tool_calls' and len(calls)==1 and
            calls[0]['function']['name']=='project_document' and
            json.loads(calls[0]['function']['arguments'])==dict(path=document) and digest==self.plan['sources'][document],
            'actual document tool selection differs')
        reply=dict(role='tool',tool_call_id=calls[0]['id'],content=json.dumps(dict(path=document,sha256=digest,answer=digest[:12])))
        save(self.output/'tool-execution.json',dict(executions=1,source=dict(path=document,content=(ROOT/document).read_text()),reply=reply))
        self.stop();fresh=self.state_version()
        outer_manager.initialize(self.scope,candidate['package'],candidate['manifest_sha256'])
        outer_manager.configure(self.scope,candidate['package'],candidate['manifest_sha256'],enabled=True)
        self.deploy('retained',restore=spent);self.start('retained',outer=True)
        fourth=self.ready_payload(4,'fallback')
        follow=copy.deepcopy(self.plan['requests']['tool']);follow.update(tool_choice='none',stream=True,stream_options=dict(include_usage=True))
        follow['messages'] += [message,reply]
        answer=read_sse(io.BytesIO(self.chat('rollback-tool-result-sse',follow,raw_result=True)))
        self.engine.require(answer.finish_reason=='stop' and digest[:12] in answer.message['content'],'actual tool result lost on rollback')
        self.kill(fourth,'guardian','owned-retained-root')
        fifth=self.ready_payload(5,'fallback');self.schema('outer-recovered-json')
        self.engine.require(fifth['guardian_pid']!=fourth['guardian_pid'],'outer did not replace failed root')
        self.stop();self.deploy('candidate',restore=fresh);self.start('candidate',outer=True)
        self.ready_payload(6,'primary');self.schema('forward-candidate-sse',True)
        outer=self.engine.read(self.scope/'outer-recovery/policy.json')['state']['policy']
        counts=self.engine.read(self.output/'counts.json')['counts']
        self.engine.require(outer['total']==3 and all(counts[k]==n for k,n in
            [('starts',6),('chats',12),('probes',1)]),'actual dispatch/budget counts differ')
        save(self.output/'business-final.json',dict(status='PASS',outer=outer,counts=counts,
            roots=self.plan['roots'],consumed_cycle_restored=True,forward_cycle_restored=True,
            actual_tool_executions=1,automatic_tool_replay=False))

    def run(self):
        failure=cleanup=None
        def expire(*_):raise TimeoutError('bounded root business deadline; cleanup only')
        previous=signal.signal(signal.SIGALRM,expire);term=signal.signal(signal.SIGTERM,expire)
        signal.setitimer(signal.ITIMER_REAL,LIMITS['seconds']-70)
        try:self.exercise();LEGACY['verify'](self.plan)
        except BaseException:failure=traceback.format_exc()
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            try:self.stop()
            except BaseException:cleanup=traceback.format_exc()
            signal.signal(signal.SIGALRM,previous);signal.signal(signal.SIGTERM,term)
            result=dict(status='PASS_BOUNDED_ROOT_ROLLBACK_BUSINESS' if not failure and not cleanup else 'FAILED',
                failure=failure,cleanup_failure=cleanup,seconds=time.monotonic()-self.started,
                budget=self.engine.read(self.output/'counts.json'),models=self.models,quota_deadlines=self.quota_deadlines,
                source_commit=self.plan['source_commit'],roots=self.plan['roots'],default_replaced=False,performance_acceptance=False)
            save(self.output/'result.json',result);print(json.dumps(result),flush=True)
        return int(failure is not None or cleanup is not None)


def main():
    os.umask(0o077);parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','run','launcher','controller','gateway','probe'))
    parser.add_argument('--plan',type=Path);parser.add_argument('--payload');parser.add_argument('--config',type=Path)
    args=parser.parse_args()
    if args.mode=='prepare':prepare();return 0
    plan=json.loads(args.plan.read_text())
    if args.mode=='launcher':return launcher(plan,args.plan)
    if args.mode in ('controller','gateway'):VERSION['actor'](plan,args.payload,args.mode,args.config);return 0
    if args.mode=='probe':VERSION['probe'](plan);return 0
    from tools.release.release import child_subreaper
    with child_subreaper():return Stage(plan,args.plan).run()
if __name__=='__main__':raise SystemExit(main())

import copy,json,runpy,subprocess,sys,tempfile,unittest
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1]
sys.path.insert(0,str(R));D=runpy.run_path(str(W/'root_business.py'))
class DriverTests(unittest.TestCase):
 def test_both_exact_roots_import_their_own_required_modules(self):
  roots=json.loads((W/'roots.json').read_text())
  script='''import sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from tools.serve_recovery import bundle,service,controller,outer_runtime,root_transfer,root_checkpoints,resource_client
for module in (bundle,service,controller,outer_runtime,root_transfer,root_checkpoints,resource_client):
 assert Path(module.__file__).resolve().is_relative_to(Path(sys.argv[1]))
manifest=bundle.verify(sys.argv[2],sys.argv[3]);assert manifest['version']==19
assert callable(resource_client.validate_binding) and callable(resource_client.validate_worker)
assert 'from tools.serve_recovery import profile_memory as resource' not in Path(controller.__file__).read_text()
print('exact source namespace and native outer/transfer ready')
'''
  for row in roots.values():
   p=subprocess.run([sys.executable,'-I','-B','-c',script,str(Path(row['package'])/'source'),row['package'],row['manifest_sha256']],cwd=W,env={},text=True,capture_output=True,timeout=30)
   self.assertEqual(p.returncode,0,p.stderr)
   self.assertIn('exact source namespace',p.stdout)
 def test_budget_reserves_dispatch_before_sixth_limit_and_rejects_next(self):
  with tempfile.TemporaryDirectory(dir=W) as path:
   budget=D['LEGACY']['Budget'](Path(path),initialize=True,limits=D['LIMITS'])
   for kind,n in [('starts',6),('chats',12),('probes',1)]:
    for i in range(n):self.assertEqual(budget.reserve(kind,'CPU'),i+1)
    with self.assertRaises(Exception):budget.reserve(kind,'MUST_NOT_DISPATCH')
 def test_actual_preserved_cycle_comparator_rejects_refunded_faults_and_ids(self):
  before=dict(revision=9,registry={'cycle_id':'original'},switch={'consumed':True},faults=['actual'],terminal_fault='protected',boot_id='original')
  following=copy.deepcopy(before);following['revision']=15
  D['exact_restoration'](before,following)
  for key,value in [('switch',None),('faults',[]),('registry',{'cycle_id':'new'}),('terminal_fault',None),('boot_id','new'),('revision',9)]:
   wrong=copy.deepcopy(following);wrong[key]=value
   with self.assertRaises(ValueError):D['exact_restoration'](before,wrong)
 def test_unknown_usage_requires_expired_actual_gate_and_matching_owner(self):
  state=dict(model_generation=5,model_pid=123,model_start_ticks=456,quota_wait_ms=0)
  usage=dict(phase='active',generation=5,owner={'pid':123,'start_ticks':456},source=None,snapshot=None)
  D['check_usage'](usage,state,100,101)
  for deadline,now in [(None,101),(102,101)]:
   with self.assertRaises(ValueError):D['check_usage'](usage,state,deadline,now)
  with self.assertRaises(ValueError):D['check_usage'](usage,dict(state,model_pid=124),100,101)
  with self.assertRaises(ValueError):D['check_usage'](usage,dict(state,quota_wait_ms=1),100,101)
  known=copy.deepcopy(usage);known.update(source={'generation':4},snapshot={})
  D['check_usage'](known,state,None,0)
if __name__=='__main__':unittest.main()

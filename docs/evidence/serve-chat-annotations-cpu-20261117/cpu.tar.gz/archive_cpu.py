import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
stems=['engine-build-01','engine-build-02','host-build-01','host-build-02','host-cpu-01','host-cpu-02','frontend-cpu-01','frontend-cpu-02','generated-check-01','source-gate-01','source-gate-02']
for name in stems:
 v=read(W/(name+'.json'));assert v['default_unchanged']
 assert v['exit_code']==(1 if name in ['host-cpu-01','frontend-cpu-01'] else 0)
 if 'build' in name:assert not re.search(r'\bwarning:|\berror:',(W/(name+'.stdout')).read_text()+(W/(name+'.stderr')).read_text())
assert '16 tests, 13 passed, 3 failed, 0 skipped' in (W/'host-cpu-01.stdout').read_text()
assert '3 tests, 3 passed, 0 failed, 0 skipped' in (W/'host-cpu-02.stdout').read_text()
assert 'Ran 8 tests' in (W/'frontend-cpu-01.stderr').read_text()
assert 'Ran 3 tests' in (W/'frontend-cpu-02.stderr').read_text()
files=[]
for name in stems:
 for ext in ['json','stdout','stderr']:files.append((W/(name+'.'+ext),name+'.'+ext))
for parent in [W/'cpu-01',W/'frontend-02']:
 for sub in parent.glob('test_*'):
  for p in sub.iterdir():
   if p.is_file():files.append((p,str(p.relative_to(W))))
for name in ['host-cases-01.txt','run.py','archive_cpu.py','native_citations.py']:
 files.append((W/name,name))
for name in ['tools/serve_protocol/chat_annotations_acceptance.py','tools/serve_protocol/test_chat_annotations.py']:
 files.append((R/name,name))
for p,n in files:assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes()),n
out=R/'docs/evidence/serve-chat-annotations-cpu-20261117';out.mkdir()
with tarfile.open(out/'cpu.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda v:v[1]):tar.add(p,arcname=n)
result=dict(status='PASS_TARGETED_CPU',cpp_unique_tests=16,schema_native_client_unique_cases=8,first_cpp_passed=13,first_frontend_passed=5,repeated_cpp=3,repeated_frontend=3,original_failures_preserved=True,runtime_fix_after_tests=False,capability_description_added_after_tests=True,capability_business_validation_pending=True,source_anchors=723,source_negative_controls=7,zero_warning_builds=True,engine_binary_sha256=sha(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t'),preflight_probe_sha256=sha(R/'.q4t-work/serve-custom-tools-20261108/engine-build/q4t_preflight_probe'),renderer_source_sha256=sha(R/'src/server/chat_template.cpp'),archive_sha256=sha(out/'cpu.tar.gz'),files=len(files),default_revision=188,default_unchanged=True,gpu_starts=0,full_model_quality=False,performance_claim=False,master_complete=False)
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'README.md').write_text('''# Chat引用历史针对性CPU验证

2026-11-17，16项不同C++和8个schema/native预检/双客户端病例最终通过。
首轮13/16及5/8通过；三个预期未沿用已有模板JSON空格/旧函数名称行，
只修正对应断言并各补3项，原失败与wire保留，未改生产渲染器。

覆盖原Unicode字符偏移、文本数组/拒绝内容、nullable与空引用不改
旧模板、元数据控制token转义、非法角色/URI/精确偏移、工具历史、
原请求不变、存储重启和客户隔离。原生预检实际使用只读checkpoint
tokenizer，四个合法病例校验模板字节与token IDs，非法病例比较字段
错误；跨字段偏移由native执行，不冒称标准schema独立可验证。
Python/JS实际消息构造保留引用和内容。probe未执行模型/CUDA。

723来源/7负控、生成物一致性、隔离引擎/host零警告构建通过。最后
增加描述已实现行为的capability字段后仅重建引擎；渲染器/合同不变，
CPU证据复用，新capability将在实际主/轻和密封业务入口核对。
默认rev188未改，0GPU。剩余音频历史、检索生产者及全部master保持。

后续累计最多3启动、12次生成请求、600秒：主/轻既定资格包含6Chat、
2embedding、2media，给Chat加入真实资料引用和持久回读；随后原保留
控制器/新引擎1次自检及1次引用SSE，检查原消息/客户隔离和完整清理。
不是完整质量/性能矩阵；既有数字与发布边界复用，不扩长稳。
''')
print(json.dumps(result))

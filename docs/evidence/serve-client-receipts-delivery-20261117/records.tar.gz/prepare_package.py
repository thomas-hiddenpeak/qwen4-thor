"""Seal the client-only fix, preserving every engine/control configuration."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from tools.serve_recovery import bundle, profile_manager
from tools.serve_service import package as p

def replace(path, data, mode=0o400):
    path.chmod(0o600)
    path.write_bytes(data)
    path.chmod(mode)

os.umask(0o077)
p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=R),
          'commit the reviewed change before sealing')
old = (R/'build/service').resolve(strict=True)
old_sha = p.sha(old/'manifest.json')
p.require(old_sha == '3cd1fdfbcd3888848240b9c164680ea80592897ead117d29c82d0936fefe3b33', 'default differs')
m = bundle.verify(old, old_sha)
e = p.read(old/'engine/manifest.json')
metadata = p.read(old/'engine/q4t.release.json')
protected = {str(R/n):p.sha(R/n) for n in ('build/q4t','build/q4t.release.json',
    'build/service.release.json','build/service-native-state/ledger.json')}
p.require(all(p.sha(R/n)==p.sha(old/'source'/n) for n in bundle.SOURCES), 'control source changed')
p.require(all(p.sha(R/n)==h for n,h in p.read(old/'native-build.json')['source_files'].items()), 'native source changed')
p.require(all(p.sha(R/n)==h for n,h in p.read(metadata['tested_source_manifest']).items()), 'engine sources changed')
prior = metadata['client_artifacts']
delta = {n for n,h in prior['files'].items() if p.sha(R/n)!=h}
p.require(delta == {'tools/serve_protocol/js_client.py'}, 'unreviewed client delta')
evidence = R/'docs/evidence/serve-client-receipts-cpu-20261117/acceptance.json'
accepted = p.read(evidence)
p.require(accepted['status']=='PASS_CLIENT_RECEIPTS_CPU', 'CPU acceptance missing')
p.require(all(p.sha(R/n)==h for n,h in accepted['production_sources'].items()), 'accepted source changed')
out = W/'candidate-01'
p.require(not out.exists(), 'preserve candidate')
out.mkdir(mode=0o700)
clients = out/'clients'
files = sorted(set(prior['files']) | {'tools/examples/tool_recovery.py'})
for n in files:
    target = clients/n
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    shutil.copyfile(R/n,target)
    target.chmod(0o400)
client_record = dict(version='q4t-client-receipts-v1',directory=str(clients),
    files={n:p.sha(clients/n) for n in files},server_dependency=False,
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    cpu_acceptance=str(evidence),cpu_acceptance_sha256=p.sha(evidence),
    packaged_validation_pending=True)
p.save(clients/'manifest.json',client_record)
new_metadata = copy.deepcopy(metadata)
new_metadata['client_artifacts'] = client_record
new_metadata['client_artifacts']['manifest_sha256'] = p.sha(clients/'manifest.json')
new_metadata['client_receipt_update'] = dict(previous_release_sha256=p.sha(old/'engine/q4t.release.json'),
    engine_source_and_acceptance_unchanged=True,changed=sorted(delta),
    added=['tools/examples/tool_recovery.py'],gpu_actions=0)
target = out/'bundle'
shutil.copytree(old,target,symlinks=True)
replace(target/'engine/q4t.release.json',json.dumps(new_metadata,indent=2).encode()+b'\n')
new_e = copy.deepcopy(e)
new_e['files']['q4t.release.json'] = p.sha(target/'engine/q4t.release.json')
replace(target/'engine/manifest.json',json.dumps(new_e,indent=2).encode()+b'\n')
new_m = copy.deepcopy(m)
new_m['engine_manifest_sha256'] = p.sha(target/'engine/manifest.json')
replace(target/'manifest.json',json.dumps(new_m,indent=2).encode()+b'\n')
new_sha = p.sha(target/'manifest.json')
replace(target/'bin/q4t',bundle.launcher(new_sha,new_m['python']['path']),0o500)
p.require(bundle.verify(target,new_sha)==new_m, 'sealed package invalid')
p.require(profile_manager.compatible(m,new_m,old,target) is None, 'profiles changed')
p.require({k:v for k,v in new_e.items() if k!='files'} == {k:v for k,v in e.items() if k!='files'}, 'engine settings changed')
p.require({n for n,h in new_e['files'].items() if e['files'].get(n)!=h} == {'q4t.release.json'}, 'engine payload changed')
p.require({k:v for k,v in new_m.items() if k!='engine_manifest_sha256'} == {k:v for k,v in m.items() if k!='engine_manifest_sha256'}, 'control payload changed')
p.require(all(p.sha(path)==h for path,h in protected.items()),'default changed')
receipt=dict(package=str(target),manifest_sha256=new_sha)
p.save(out/'receipt.json',receipt)
p.save(out/'review.json',dict(status='PASS_CLIENT_ONLY_PACKAGE_SOURCE',previous=dict(package=str(old),manifest_sha256=old_sha),current=receipt,client_artifacts=client_record,client_manifest_sha256=p.sha(clients/'manifest.json'),engine_binary_sha256=p.sha(target/'engine/q4t'),engine_binary_unchanged=True,engine_source_and_acceptance_unchanged=True,control_native_profile_policy_unchanged=True,default_unchanged=True,gpu_actions=0,packaged_validation_pending=True))
print(json.dumps(receipt))

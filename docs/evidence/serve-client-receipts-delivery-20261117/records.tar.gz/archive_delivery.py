import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(W/'delivery-continue-01/result.json');assert v['status']=='PASS_NATIVE_CLIENT_RECEIPTS_DELIVERED' and v['publication']['revision']==260
assert len(v['commands'])==9 and all(x['returncode']==0 for x in v['commands']) and v['successful_commands']==13
assert v['core_client_outer_profile_bytes_preserved'] and v['version_cycles_preserved']
c=v['publication']['current'];assert sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
retention=read(W/'intent-archive-acceptance.json');assert retention['all_other_state_unchanged'] and retention['after_intents']==124
paths=[]
for directory in ['delivery-01','delivery-continue-01','intent-archive-01']:
 paths.extend((p,str(p.relative_to(W))) for p in (W/directory).iterdir() if p.is_file() and not p.is_symlink())
for p in W.iterdir():
 if p.is_file() and (p.suffix=='.py' or p.name.startswith(('delivery-','intent-archive','version-archive','publication-archive','intent-capacity'))):paths.append((p,p.name))
paths=sorted({n:p for p,n in paths}.items());secrets=[]
def collect(x):
 if isinstance(x,dict):
  for k,value in x.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(value,str) and len(value)>=24:secrets.append(value.encode())
   else:collect(value)
 elif isinstance(x,list):
  for value in x:collect(value)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for name,p in paths:assert not any(s in p.read_bytes() for s in secrets),name
O=R/'docs/evidence/serve-client-receipts-delivery-20261117';assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in paths:tar.add(p,arcname=name,recursive=False)
a=dict(status='PASS_NATIVE_CLIENT_RECEIPTS_DELIVERED',revision=260,current=c,successful_commands=13,failed_original_commands=1,seconds=v['original_seconds']+v['seconds'],state='STOPPED',new_gpu_starts=0,engine_control_native_profiles_unchanged=True,version_cycles_and_all_budgets_preserved=True,client_acceptance='evidence/serve-client-receipts-package-20261117/README.md',intent_cpu_acceptance='evidence/serve-publication-intent-cpu-20261117/README.md',archived_intents=4,archived_generations=1,archived_registrations=1,deleted_files=0,original_failure_preserved=True,manual_root='3cd1fdfbcd3888848240b9c164680ea80592897ead117d29c82d0936fefe3b33',automatic_payload='087c383b36060e60ce1a2ddcb515b157524d244366cfb7a10a5d844e47df95a0',older_engine_fallback=False,archive_sha256=sha(O/'records.tar.gz'),secret_scan_matches=0,main_integration_pending=True,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# rev260客户端回执可回退交付

SDK桥接现在保留审核报告/附加用量；恢复器完整核对logprobs和审核
元数据，并明确返回CONTENT_FILTERED终态，不提交被挡历史或派发工具。
12项新CPU、4项旧回归及精确封装内相同12项通过。服务包
`{c['manifest_sha256']}`，引擎`{c['engine_binary_sha256']}`保持。

实际13项STOPPED检查/发布、整根回退及再前进通过，另保留原1次
容量拒绝；累计{a['seconds']:.3f}秒，0模型动作。控制器、原生helper、
模型容量及全部core/client/outer/profile预算字节保持，原周期恢复。
原rev254人工回退包和旧控制/当前引擎自动payload保留；原客户端
字段丢失限制仍属于旧包，未声明独立旧引擎回退。

发布暴露128条意图池容量。新增自有维护工具8项CPU通过，实际在
完整锁下可恢复归档4条旧意图，128→124，其余状态文件逐字节保持；
续做原失败步骤成功，最终126条。退休登记和generation各归档1份，
无删除，不重置预算或放大上限。归档恢复/中断续做已CPU验证，
本次真实服务只执行归档及发布回退；原失败结果没有覆盖。

PR42已实际合main，本组提交/检查/合main继续；用户长稳入口将按
新客户端身份重新固定，24小时未运行。全部Serve总任务保持active。
''')
p=R/'docs/evidence/serve-publication-intent-cpu-20261117/README.md';s=p.read_text().replace('42.200秒','42.311秒');p.write_text(s)
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev260；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','人工整包回退':'rev254根 `'+a['manual_root']+'`；原生outer/周期和媒体能力保持；旧包仍有客户端回执遗漏'}
for k,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(k)+r' \| .* \|$',lambda _:f'| {k} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev260客户端回执交付](evidence/serve-client-receipts-delivery-20261117/README.md)\n已完成13项STOPPED检查/实际回退/再前进，另保留1次意图容量失败，\n累计{a['seconds']:.3f}秒、0GPU。精确客户端封装已验，模型/控制/native\n和profile保持；128条意图容量通过受保护、可恢复归档4条解决，\n其余状态字节和原周期保留。继续新身份day交接、实际合main及全部master。\n\n'''
s=s.replace('[rev254有限透视交付]',intro+'前驱[rev254有限透视交付]',1)
s=s.replace('## 最近完成的实现和验证\n\n','## 最近完成的实现和验证\n\n'+intro,1)
s=s.replace('用户day独立交接已prepare/check且未运行；继续实际合main及全部master。','用户day独立交接已prepare/check且未运行；PR42两组检查通过且\n[实际合main](evidence/serve-pr42-merged-20261117/README.md)（`431ddc13`）；全部master继续。')
s=s.replace('客户端交付在rev256回退步骤遇到发布意图128条容量上限；','已解决的本组原失败：客户端交付在rev256回退步骤遇到发布意图128条容量上限；').replace('随后只续9项未完成检查，累计13项成功命令及1次原失败，不重跑客户端用例。','实际归档后续9项检查已通过，累计13项成功命令及1次原失败，不重跑客户端用例。')
p.write_text(s)
p=R/'docs/log/2026-11-17.md';h,t=p.read_text().split('\n',1);p.write_text(h+f'''\n\n## rev260客户端回执与意图保留实际交付\n\n13项STOPPED发布/回退/再前进完成，原容量失败保留；累计\n{a['seconds']:.3f}秒、0GPU。受保护归档4条意图后续做通过，其余状态\n字节、预算和原周期保持。PR42两组检查成功且实际合main（431ddc13）。\n下一步当前身份day交接、本组实际合main及全部剩余master任务。\n'''+t)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for t in j['tasks']:
 if t['id']=='A10':t['video_projective_20261117'].update(state='delivered_main_merged',main_merge_commit='431ddc136b63cdebfe154d5fcb48e8040f29ca0d',main_evidence='evidence/serve-pr42-merged-20261117/README.md')
 if t['id']=='A12':t['client_receipts_20261117'].update(state='delivered_main_pending',revision=260,delivery_evidence='evidence/serve-client-receipts-delivery-20261117/README.md')
 if t['id']=='N07':t['publication_intent_retention_20261117'].update(state='actual_accepted_main_pending',archived_intents=4,actual_evidence='evidence/serve-client-receipts-delivery-20261117/README.md')
 if t['id']=='Q02':
  t['latest_release']=a|dict(evidence='evidence/serve-client-receipts-delivery-20261117/README.md')
  t['remaining_required']=['Client receipts/intent retention final-head checks and actual main merge','Delivery of every remaining implementation']
 if t['id']=='R07':t['current_execution_prerequisite']='Refresh against rev260 or then-current exact package before cold qualification; pending camera/jtop handoff remains required, do not stop other services.'
j['next_task']='Q02';j['next']='Freeze rev260 day handoff and merge the client/intent-retention repair after exact-head checks; continue every remaining master task.'
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev260客户端回执可回退交付](evidence/serve-client-receipts-delivery-20261117/README.md)：审核信息/恢复终态及发布意图容量的实际修复。\n')
print(json.dumps({k:a[k] for k in ['status','revision','seconds','successful_commands','failed_original_commands','new_gpu_starts']}))

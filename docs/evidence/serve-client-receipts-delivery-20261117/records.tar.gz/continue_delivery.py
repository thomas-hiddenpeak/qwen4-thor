"""Continue only the nine unfinished actions after protected intent retention."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('client_receipt_delivery',W/'deliver.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
p=d.p;O=W/'delivery-continue-01'
os.umask(0o077)
original=p.read(d.O/'result.json');review=p.read(d.O/'review.json');ids=p.read(d.O/'requests.json')
assert original['status']=='FAILED' and len(original['commands'])==5
assert all(r['returncode']==0 for r in original['commands'][:4]) and original['commands'][-1]['label']=='rollback'
assert p.read(W/'intent-archive-acceptance.json')['status']=='PASS_ACTUAL_INTENT_RETENTION'
current=d.publication.status(d.S);target=review['target'];cli=Path(target['package'])/'bin/q4t'
assert current['ready'] and current['revision']==256 and current['current']['manifest_sha256']==target['manifest_sha256']
assert d.preserved()==review['preserved'] and d.version()==p.read(d.O/'candidate-cycle.json')
assert not d.publication.intent_path(d.S,ids['rollback']).exists()
assert not O.exists();O.mkdir(mode=0o700)
rows=[];started=time.monotonic()
def call(label,args):
 assert len(rows)<9 and time.monotonic()-started<240
 argv=list(map(str,args));r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
 (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
 rows.append(dict(label=label,argv=argv,returncode=r.returncode))
 assert r.returncode==0,label
 assert d.preserved()==review['preserved']
 return json.loads(r.stdout)
try:
 result=call('rollback',[cli,'service','publish-rollback','--state',d.S,'--default-root',d.D,'--package',target['package'],'--manifest-sha256',target['manifest_sha256'],'--generation-sha256',review['previous']['current']['generation_sha256'],'--expected-manifest-sha256',target['manifest_sha256'],'--expected-revision',256,'--request-id',ids['rollback']])
 assert result['durable'] and result['revision']==258
 d.exact(review['previous_version'],d.version())
 assert call('rollback-check',[d.D/'q4t','service','check','--state',d.S])['desired']=='STOPPED'
 result=call('forward',[cli,'service','publish','--state',d.S,'--default-root',d.D,'--package',target['package'],'--manifest-sha256',target['manifest_sha256'],'--service-release',d.O/'service.release.json','--expected-manifest-sha256',d.OLD,'--expected-revision',258,'--request-id',ids['forward']])
 assert result['durable'] and result['revision']==260
 d.exact(p.read(d.O/'candidate-cycle.json'),d.version())
 for action in ('check','status','observe'):
  value=call('default-'+action,[d.D/'q4t','service',action,'--state',d.S])
  assert value['status']=='PASS' if action=='check' else value['state']=='STOPPED'
 profiles=call('profiles',[d.D/'q4t','service','profiles-status','--state',d.S]);assert profiles['selected']=='primary'
 outer=call('outer',[d.D/'q4t','service','outer-status','--state',d.S]);assert outer['enabled'] and outer['charged_total']==0
 final=call('publication',[d.D/'q4t','service','publish-status','--state',d.S])
 assert final['ready'] and final['revision']==260 and final['current']['manifest_sha256']==target['manifest_sha256']
 result=dict(status='PASS_NATIVE_CLIENT_RECEIPTS_DELIVERED',seconds=time.monotonic()-started,commands=rows,original_attempts=original['commands'],successful_commands=13,failed_original_commands=1,original_seconds=original['seconds'],publication=final,profiles=profiles,outer=outer,state='STOPPED',new_gpu_starts=0,original_failure_preserved=True,core_client_outer_profile_bytes_preserved=True,version_cycles_preserved=True,all_master_tasks_active=True)
 p.save(O/'result.json',result);print(json.dumps(dict(status=result['status'],revision=260,successful_commands=13,original_failures=1,new_gpu_starts=0)))
except BaseException as error:
 p.save(O/'result.json',dict(status='FAILED',commands=rows,error=repr(error),seconds=time.monotonic()-started));raise

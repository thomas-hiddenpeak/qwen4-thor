import json
import os
from pathlib import Path
import sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tools.serve_recovery import publication_intent_archive as a, publication
from tools.serve_service import package as p
S=R/'build/service-native-state'
os.umask(0o077)
expected=p.read(R/'docs/evidence/serve-publication-intent-cpu-20261117/acceptance.json')
for n,h in expected['source_sha256'].items():assert p.sha(R/n)==h
snapshot=lambda:{str(f.relative_to(S)):p.sha(f) for f in S.rglob('*.json') if publication.INTENTS not in f.relative_to(S).parts}
before=snapshot()
with a.archives.locked(S) as (state,desc,manifest,current):
 assert current['revision']==256 and current['current']['manifest_sha256']=='168477d190e4b0d2c5f2f92410722b39486801500ad4397ff1c717019f022d64'
 rows=a.archives.intents(state,desc);assert len(rows)==128
 keep=a.protected(current,rows);selected=[]
 for row in sorted(rows,key=lambda r:r['base']['revision']):
  if row['request_id'] in keep:continue
  try:a.archives.unreferenced(state,current,publication.intent_path(state,row['request_id']))
  except ValueError:continue
  selected.append(row['request_id'])
  if len(selected)==4:break
 assert len(selected)==4
plan=a.prepare(S,W/'intent-archive-01',selected)
p.save(W/'intent-archive-prepared.json',plan)
receipt=a.apply(plan['plan'],plan['sha256'])
p.save(W/'intent-archive-applied.json',receipt)
assert snapshot()==before and len(list((S/publication.INTENTS).iterdir()))==124
p.save(W/'intent-archive-acceptance.json',dict(status='PASS_ACTUAL_INTENT_RETENTION',publication_revision=256,selected=selected,before_intents=128,after_intents=124,all_other_state_sha256=before,all_other_state_unchanged=True,deleted_files=0,model_actions=0,receipt=receipt))
print(json.dumps(dict(status='PASS_ACTUAL_INTENT_RETENTION',before=128,after=124,all_other_state_unchanged=True,model_actions=0)))

"""Archive real web/profile/retained composition without altering original failures."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=R/'docs/evidence/serve-web-search-composition-20261117'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not O.exists()
feature=read(W/'feature-acceptance.json');qualified=read(W/'profiles-01/acceptance.json')
assert feature['status']=='ACCEPT_NATIVE_WEB_SEARCH_BUSINESS' and qualified['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
candidate={k:read(W/'package-01/receipt.json')[k] for k in ('package','manifest_sha256')}
legacy=read(W/'retained-01/review.json')['fallback'];modern=read(W/'modern-retained-01/receipt.json')
for name,desc in [('legacy-business-01',legacy),('modern-business-02',modern)]:
 a=read(W/name/'decision.json')
 assert a['acceptance']=='ACCEPT_WEB_ISOLATION_SERVICE_RETAINED' and a['manifest_sha256']==desc['manifest_sha256'] and a['engine_binary_sha256']==feature['binary_sha256'] and all(a['actual_business']['postflight'].values())
files=[];stages=[]
for name in ['profiles-01','legacy-business-01','modern-business-02']:
 d=W/name;managed=name!='profiles-01';e=d/'execution' if managed else d
 result=read(e/'result.json');guard=read(d/'lease/exit.json')
 counts=result['budget']['counts'] if managed else result['counts']
 events=[json.loads(x) for x in (d/'lease/events.jsonl').read_text().splitlines()]
 queries=[json.loads(x) for x in (d/'lease/nvml-queries.jsonl').read_text().splitlines()]
 a=[x for x in events if x.get('event')=='lease_acquired'];z=[x for x in events if x.get('event')=='lease_released']
 assert len(a)==len(z)==1 and a[0]['pid']==z[0]['pid']
 assert guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease']
 assert all(x['status']=='OK' and x['returncode']==0 for x in queries)
 expected='COMMAND_FAILED' if name=='legacy-business-01' else 'COMPLETED'
 assert guard['status']==z[0]['status']==expected
 stages.append(dict(name=name,original_status=result['status'],guard_status=guard['status'],counts=counts,strict_lease_seconds=z[0]['monotonic']-a[0]['monotonic'],nvml_queries=len(queries),accepted_separately=name=='legacy-business-01'))
 for folder,prefix in [(d,name),(d/'lease',name+'/lease')]+([(e,name+'/execution')] if managed else []):
  for p in folder.iterdir():
   if p.is_file() and not p.is_symlink() and p.name not in ['client-policy.json','gateway-policy.json','object-store-key.json']:
    files.append((prefix+'/'+p.name,p))
 for p in (d/'qualified').glob('*.json'):files.append((name+'/qualified/'+p.name,p))
for n in ['prepare_package.py','prepare_retained.py','prepare_modern_root.py','review_retained.py','run_managed.py','archive_composition.py','package-delta-review.json','guardian-build-comparison.json','publication-composition.json','package-01/prepare-review.json','package-01/native-build.json','package-01/receipt.json','package-01/decision.json','retained-01/review.json','modern-retained-01/review.json','modern-retained-01/receipt.json','modern-business-01/plan.json']:
 p=W/n
 if p.exists():files.append((n,p))
for pattern in ['retained-driver-cpu-*.*','retained-review-*.*','native-build-*.*','package-prepare-*.*','retained-prepare-*.*','modern-prepare-*.*','legacy-run-*.*','modern-run-*.*']:
 for p in W.glob(pattern):
  if p.is_file():files.append((p.name,p))
secrets=[]
def collect(x):
 if isinstance(x,dict):
  for key,value in x.items():
   if key in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(value,str) and len(value)>=24:secrets.append(value.encode())
   else:collect(value)
 elif isinstance(x,list):
  for item in x:collect(item)
for desc in [candidate,legacy,modern]:
 for n in ['gateway-policy.json','engine/client-policy.json']:collect(read(Path(desc['package'])/n))
collect(read(W/'profiles-01/client-policy.json'))
files=sorted(dict(files).items())
for n,p in files:assert not any(secret in p.read_bytes() for secret in secrets),n
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
starts=sum(x['counts']['starts'] for x in stages);requests=sum(x['counts']['chats'] for x in stages);seconds=sum(x['strict_lease_seconds'] for x in stages)
assert starts==4 and requests==16 and seconds<900
accepted=dict(status='ACCEPT_NATIVE_WEB_SEARCH_COMPOSITION',binary_sha256=feature['binary_sha256'],candidate=candidate,automatic_fallback=legacy,modern_retained_root=modern,stages=stages,composition_starts=starts,composition_requests=requests,composition_lease_seconds=seconds,total_starts=starts+feature['cumulative_starts'],total_external_requests=requests+feature['cumulative_requests'],strict_lease_seconds=seconds+feature['cumulative_lease_seconds'],nvml_queries=sum(x['nvml_queries'] for x in stages)+feature['nvml_ok_samples'],nvml_all_ok=True,cleanup_complete=True,feature_evidence='docs/evidence/serve-web-search-business-20261117/README.md',legacy_original_run_accepted=False,legacy_business_independently_accepted=True,modern_service_acceptance=read(W/'modern-business-02/decision.json'),candidate_control_delta=read(W/'package-delta-review.json')['control'],candidate_whole_package_gpu_run=False,default_unchanged=True,publication_pending=True,older_engine_fallback=False,full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,archive_sha256=sha(O/'records.tar.gz'),secret_scan_matches=0)
(W/'publication-composition.json').write_text(json.dumps(accepted,indent=2)+'\n');(O/'acceptance.json').write_text(json.dumps(accepted,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生网页搜索发行组合接受

同一e430a4bd引擎的真实Chat/Responses搜索证据保持；实际发行容量
的主轻工具/结构化/embedding/媒体通过。旧及现代保留控制包均验证
缺搜索配置503之后同模型/控制器继续实际图片/schema/SSE，存储及
客户端隔离保持。发行组合4启动16请求，{seconds:.3f}秒严格租约。
含网页原失败累计{accepted['total_starts']}启动{accepted['total_external_requests']}请求、
{accepted['strict_lease_seconds']:.3f}秒，{accepted['nvml_queries']}项NVML正常，全部自有清理。

旧包原整轮仍FAILED：所有请求和清理已完成，末尾检查误导入旧包
不存在的管理模块；修复后CPU逐一复核原wire/身份/源码与清理，原
业务独立接受。第一次CPU提前导入也被命名空间隔离正确拒绝并保留。
现代包原01计划未执行，02使用修复驱动正常通过。没有额外模型重验。

默认rev224保持，继续STOPPED能力升级、实际整根回退与再前进。
原生helper保留已验字节，CMake仅新增server源列表；严格C++23重构建
与原GNU C++23 Guardian产生不同字节，新Guardian未选入本次发行。
当前/保留包均采用已验新引擎，不冒称独立旧引擎回退；不作性能或
完整模型质量结论，全部master任务继续。
''')
print(json.dumps({k:accepted[k] for k in ['status','total_starts','total_external_requests','strict_lease_seconds','nvml_queries','archive_sha256']}))

"""Seal accepted native web business and exact primary/light observations."""
import copy
import hashlib
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'package-01'
B=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build'
OLD=(ROOT/'build/service').resolve(strict=True);P=W/'profiles-01'
helpers=runpy.run_path(str(ROOT/'.q4t-work/serve-embeddings-20261111/deliver.py'))
def cp(src,dst):
    dst.parent.mkdir(mode=0o700,parents=True,exist_ok=True);shutil.copyfile(src,dst)
def main():
    os.umask(0o077)
    p.require(not OUT.exists(),'preserve earlier package')
    p.require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'commit reviewed sources first')
    protected={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json']}
    original=bundle.verify(OLD,p.sha(OLD/'manifest.json'));old_metadata=p.read(OLD/'engine/q4t.release.json');base=p.read(OLD/'engine/manifest.json')
    plan=p.read(P/'plan.json');qualification=p.read(P/'acceptance.json');actual=p.read(W/'feature-acceptance.json')
    p.require(actual['status']=='ACCEPT_NATIVE_WEB_SEARCH_BUSINESS' and actual['runtime_accepted'] and actual['cleanup_complete'],'feature business missing')
    p.require(qualification['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION' and qualification['environment']['cleanup_complete'],'profile qualification missing')
    runtime=helpers['source_hashes']();compiled=p.read(B/'generated/q4t/server/chat_protocol_sources.json');runtime.update(compiled)
    p.require(all(p.sha(ROOT/n)==h and plan['sources'].get(n,compiled.get(n))==h for n,h in runtime.items()),'qualified runtime drift')
    p.require(p.sha(B/'q4t')==actual['binary_sha256']==plan['binary_sha256'],'accepted engine identity differs')
    previous=p.read(old_metadata['tested_source_manifest']);delta={n for n,h in runtime.items() if previous.get(n)!=h}
    review_path=W/'package-delta-review.json'
    p.require(p.sha(review_path)=='676ae68ada33264fbc56f33040db0b2a537b139cb301aa691ac2de012e106d83','review changed')
    reviewed=p.read(review_path)
    p.require(delta==set(reviewed['runtime']),'unreviewed runtime delta')
    control={n for n in bundle.SOURCES if p.sha(ROOT/n)!=p.sha(OLD/'source'/n)}
    p.require(control==set(reviewed['control']),'unreviewed management delta')
    cpu=p.read(ROOT/'docs/evidence/serve-web-search-recovery-cpu-20261117/acceptance.json')
    p.require(cpu['status']=='PASS_WEB_RECOVERY_TARGETED_CPU' and cpu['distinct_tests']==7,'direct migration evidence missing')
    native=p.read(OLD/'native-build.json')
    native_delta={n for n,h in native['source_files'].items() if p.sha(ROOT/n)!=h}
    p.require(native_delta=={'CMakeLists.txt'},'unexpected native source delta')
    before=subprocess.check_output(['git','show',old_metadata['source_commit']+':CMakeLists.txt'],cwd=ROOT,text=True)
    p.require(__import__('hashlib').sha256(before.encode()).hexdigest()==native['source_files']['CMakeLists.txt'],'old CMake identity mismatch')
    added=[line for line in __import__('difflib').ndiff(before.splitlines(),(ROOT/'CMakeLists.txt').read_text().splitlines()) if line.startswith(('+ ','- '))]
    expected_added=['+ '+line for line in (ROOT/'CMakeLists.txt').read_text().splitlines() if 'src/server/' in line and any(token in line for token in ('/web_','/chat_web_search.','/responses_web_'))]
    p.require(sorted(added)==sorted(expected_added) and len(added)==14,'CMake changes affect native targets')
    same={}
    for field,name in [('guardian','q4t-guardian'),('cuda_probe','q4t-cuda-probe'),('ingress','q4t-ingress'),('device_control','q4t-device-control')]:
        p.require(p.sha(OLD/'bin'/name)==native[field+'_sha256'],'accepted native helper changed');same[name]=True
    native['source_files']['CMakeLists.txt']=p.sha(ROOT/'CMakeLists.txt')
    native['reuse_review']=dict(previous=str(OLD/'native-build.json'),sha256=p.sha(OLD/'native-build.json'),changed_sources=sorted(native_delta),executable_hashes_identical=same,rationale='Only 14 q4t_server source-list additions; all native target sources and recipes unchanged. Preserve exact accepted GNU C++23 Guardian; strict C++23 rebuild produces different code and is not selected for this web delivery. Other rebuilt helpers identical. No native runtime changes.',build=str(W/'native-build-01.json'),build_sha256=p.sha(W/'native-build-01.json'),rebuild_guardian_selected=False)
    OUT.mkdir(mode=0o700);engine=OUT/'engine'
    for n in ['q4t','CMakeCache.txt']:cp(B/n,engine/n)
    (engine/'q4t').chmod(0o500);p.save(engine/'runtime-source.json',runtime)
    protocol=hashlib.sha256(''.join(n+':'+h+'\n' for n,h in sorted(compiled.items())).encode()).hexdigest()
    caps=p.read(P/'primary-capabilities.json');config=p.read(P/'primary-config.json')
    p.require(caps['protocol_source_sha256']==config['protocol_source_sha256']==protocol,'actual declaration differs')
    decision=dict(status='PASS_NATIVE_WEB_SEARCH',acceptance='ACCEPT_NATIVE_WEB_SEARCH_BUSINESS',binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,source_commit=plan['source_commit'],actual_native_web_search=actual,profile_qualification=qualification,source_delta=sorted(delta),control_delta=sorted(control),cpu_contracts='docs/evidence/serve-web-search-recovery-cpu-20261117/acceptance.json',full_model_quality=False,performance_acceptance=False,version_composition_pending=True,default_changed=False,remaining_master_tasks_open=True)
    metadata=copy.deepcopy(old_metadata)
    metadata.update(version='serve-native-web-search-20261117',source_commit=plan['source_commit'],binary_sha256=plan['binary_sha256'],acceptance=decision['acceptance'],acceptance_decision=str(OUT/'decision.json'),build_cache=str(engine/'CMakeCache.txt'),build_cache_sha256=p.sha(engine/'CMakeCache.txt'),tested_source_manifest=str(engine/'runtime-source.json'),tested_source_manifest_sha256=p.sha(engine/'runtime-source.json'),observed_configuration=config,previous_binary=str(OLD/'engine/q4t'),previous_release=str(OLD/'engine/q4t.release.json'),inherited_release=dict(path=str(OLD/'engine/q4t.release.json'),sha256=p.sha(OLD/'engine/q4t.release.json')),source_note='Native configured-site web search through Chat/Responses JSON and SSE, actual public source/citation, offline history and absent-policy core isolation accepted on this exact engine. Full primary/light application/media/embedding qualification follows the existing publication settings. Optional private policies are sealed and preserved by recovery; full web-provider coverage remains a master task. Original two failed attempts retained. No numerical kernel changes or performance claim. Retained composition and STOPPED reversible publication still required.')
    metadata['native_web_search_acceptance']=decision
    declarations=engine/'declarations';declarations.mkdir(mode=0o700)
    p.save(declarations/'capabilities.json',caps);p.save(declarations/'configuration.json',config)
    metadata['chat_protocol'].update(caps,protocol_sha256=protocol,declaration_evidence='Actual native web business plus exact primary/light observations; original failures and identity-bound prior evidence retained.')
    for name,stem in helpers['SCHEMAS'].items():
        source=ROOT/'docs'/(stem+('.json' if name=='openapi' else '.schema.json'));target=declarations/'schemas'/(name+'.json');cp(source,target)
        metadata['chat_protocol'][name+'_schema']=str(target);metadata['chat_protocol'][name+'_schema_sha256']=p.sha(target)
    metadata['release_declarations']=dict(profile=p.APPLICATION_DECLARATION_PROFILE,directory=str(declarations),binary_sha256=plan['binary_sha256'],protocol_sha256=protocol,files={n:p.sha(declarations/n) for n in p.declaration_files(p.APPLICATION_DECLARATION_PROFILE)})
    for source in (ROOT/'third_party/licenses').rglob('*'):
        if source.is_file():cp(source,engine/'licenses'/source.relative_to(ROOT/'third_party/licenses'))
    metadata['third_party_notices']['source_directory']=str(engine/'licenses/structured_output');metadata['application_notices']['source_directory']=str(engine/'licenses/openai-node')
    for name,record in metadata['file_input_system_dependencies'].items():
        source=Path(record['artifact']);p.require(p.sha(source)==record['sha256'],'notice drift');target=engine/'licenses/system'/name;cp(source,target);record['artifact']=str(target)
    clients=metadata['client_artifacts'];client_delta={n for n,h in clients['files'].items() if p.sha(ROOT/n)!=h}
    p.require(client_delta==set(reviewed['clients']),'unreviewed client delta')
    for n in clients['files']:
        clients['files'][n]=p.sha(ROOT/n);cp(ROOT/n,OUT/'clients'/n)
    decision['client_delta']=sorted(client_delta);p.save(OUT/'decision.json',decision)
    metadata['acceptance_decision_sha256']=p.sha(OUT/'decision.json');clients['directory']=str(OUT/'clients')
    p.save(engine/'q4t.release.json',metadata);p.verify_declarations(metadata,required=True);p.save(OUT/'native-build.json',native)
    kwargs={key:OLD/'engine'/n for key,n in [('access_program_policy','access-program-policy.json'),('file_input_policy','file-input-policy.json'),('mcp_policy','mcp-policy.json'),('web_policy','web-policy.json')] if (OLD/'engine'/n).is_file()}
    settings=base['settings']
    receipt=bundle.prepare(engine/'q4t',engine/'q4t.release.json',base['model_dir'],OLD/'bin/q4t-guardian',OLD/'bin/q4t-cuda-probe',None,OLD/'gateway-policy.json',OLD/'engine/client-policy.json',OUT/'bundle',native_receipt=OUT/'native-build.json',native_ingress=OLD/'bin/q4t-ingress',device_control=OLD/'bin/q4t-device-control',capacity_config=dict(version=2,**{k:v for k,v in settings['profile'].items() if k not in ('name','host')}),application_state={k:v for k,v in settings['application_state'].items() if k!='profile'},embedding_model_dir=Path(settings['native_embedding']['directory']),recovery_profiles=P/'qualified/registry.json',recovery_profile_policy=original['recovery_profile_policy'],**kwargs)
    p.save(OUT/'receipt.json',receipt)
    p.require(p.read(Path(receipt['package'])/'engine/manifest.json')['settings']==settings,'unrelated settings drift')
    p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
    p.save(OUT/'prepare-review.json',dict(previous=str(OLD),previous_manifest_sha256=p.sha(OLD/'manifest.json'),package_sha256=receipt['manifest_sha256'],runtime_source_sha256=runtime,runtime_delta=sorted(delta),control_source_delta=sorted(control),native_source_delta=sorted(native_delta),native_executables_identical=same,client_delta=sorted(client_delta),new_gpu_starts=0,default_changed=False,version_composition_pending=True))
    print(receipt['manifest_sha256'])
if __name__=='__main__':main()

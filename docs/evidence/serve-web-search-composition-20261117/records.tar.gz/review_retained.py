"""Independent acceptance of completed business; preserve the failed original run."""
import ast,fcntl,hashlib,json,runpy,socket,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
D=W/'legacy-business-01';E=D/'execution';L=D/'lease'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(D/'plan.json');result=read(E/'result.json');guard=read(L/'exit.json')
assert result['status']=='FAILED' and result['cleanup_failure'] is None
assert result['failure'].endswith("ModuleNotFoundError: No module named 'tools.serve_recovery.profile_migration'\n")
assert result['budget']['counts']['starts']==1 and result['budget']['counts']['chats']==3 and result['budget']['counts']['probes']==0
assert result['seconds']<plan['limits']['seconds'] and guard['status']=='COMMAND_FAILED' and guard['child_returncode']==1
assert guard['compute_backend']=='nvml' and guard['lease_inherited_by_child'] and not guard['external_lease'] and guard['command']==plan['command']
queries=[json.loads(x) for x in (L/'nvml-queries.jsonl').read_text().splitlines()]
events=[json.loads(x) for x in (L/'events.jsonl').read_text().splitlines()]
assert queries and all(x['status']=='OK' and x['returncode']==0 for x in queries)
a=[x for x in events if x.get('event')=='lease_acquired'];z=[x for x in events if x.get('event')=='lease_released']
assert len(a)==len(z)==1 and a[0]['pid']==z[0]['pid'] and z[0]['status']=='COMMAND_FAILED'
seconds=z[0]['monotonic']-a[0]['monotonic'];assert 0<seconds<180
name='tools/serve_responses/web_service_acceptance.py'
original=subprocess.check_output(['git','show',plan['source_commit']+':'+name],cwd=R)
assert hashlib.sha256(original).hexdigest()==plan['sources'][name]
old_ast=ast.parse(original);new_ast=ast.parse((R/name).read_bytes())
old_nodes=[ast.dump(n,include_attributes=False) for n in old_ast.body if not isinstance(n,ast.FunctionDef) or n.name!='check_business']
new_nodes=[ast.dump(n,include_attributes=False) for n in new_ast.body if not isinstance(n,ast.FunctionDef) or n.name!='check_business']
assert old_nodes==new_nodes,'only postprocessing may change for this independent review'
for n,h in plan['sources'].items():assert (hashlib.sha256(original).hexdigest() if n==name else sha(R/n))==h,n
for item in plan['protected']:assert sha(Path(item['path']))==item['sha256']
module=runpy.run_path(str(R/name));bundle,_,_,journal,_,engine=module['LEGACY']['load_modules'](plan)
package=Path(plan['package']['package']);manifest=bundle.verify(package,plan['package']['manifest_sha256'])
usage=module['check_business'](E)
assert usage['visible_colors'] and usage['web_policy_error_isolated']
assert read(W/'retained-driver-cpu-02.json')['exit_code']==0
stop=read(E/'stop.json');ledger=read(E/'state/ledger.json')['state'];initialized=read(E/'initialized.json')
assert stop['cleanup_confirmed'] and stop['stop_durable'] and ledger['desired']=='STOPPED' and all(v is None for v in ledger['active'].values()) and ledger['service_id']==initialized['service_id']
identities={(int(v['pid']),int(v['start_ticks'])) for v in result['models'].values()}
for line in (E/'status.jsonl').read_text().splitlines():
 v=json.loads(line)
 for role in ('guardian','controller','model','gateway'):
  if v.get(role+'_pid') is not None:identities.add((v[role+'_pid'],v[role+'_start_ticks']))
for pid,ticks in identities:
 try:assert journal.process_start(pid)!=ticks
 except (FileNotFoundError,ProcessLookupError):pass
policy=read(package/'gateway-policy.json')
for port in (policy['listen_port'],policy['upstream_port'],policy['upstream_operations_port']):
 with socket.socket() as sock:sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);sock.bind(('127.0.0.1',port))
with Path(manifest['lock_path']).open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
acceptance='ACCEPT_WEB_ISOLATION_SERVICE_RETAINED';binary=sha(package/'engine/q4t')
review=dict(original_status='FAILED',original_guard_status='COMMAND_FAILED',original_records_unchanged=True,original_run_accepted=False,reason='All planned requests and cleanup completed; only postprocessing imported a newer module absent from sealed v12. The repaired checker runs after the same namespace switch and validates the exact captured responses. No request, launch, service or cleanup implementation changed.',original_driver_sha256=hashlib.sha256(original).hexdigest(),repaired_driver_sha256=sha(R/name),new_model_actions=0,real_business=usage,source_files_checked=len(plan['sources']))
decision=dict(status='PASS_INDEPENDENT_WEB_ISOLATION_SERVICE_RETAINED',acceptance=acceptance,manifest_sha256=plan['package']['manifest_sha256'],engine_binary_sha256=binary,independent_review=review,actual_business=dict(status=acceptance,strict_lease_seconds=seconds,nvml_queries=len(queries),env_abort=False,counts=result['budget']['counts'],source_commit=plan['source_commit'],plan_sha256=sha(D/'plan.json'),result_sha256=sha(E/'result.json'),lease_result_sha256=sha(L/'exit.json'),postflight=dict(sources_unchanged=True,owned_processes_gone=True,ports_free=True,lock_released=True,default_unchanged=True)),default_replaced=False,performance_acceptance=False,long_stability_accepted=False)
assert not (D/'decision.json').exists()
engine.save(D/'decision.json',decision)
engine.save(D/'service-release.json',dict(version=4,profile='q4t-service-recovery-v4',acceptance=acceptance,recovery_accepted=True,acceptance_record=str(D/'decision.json'),acceptance_sha256=sha(D/'decision.json'),**plan['package'],engine_binary_sha256=binary,engine_release_sha256=sha(package/'engine/q4t.release.json'),ingress_mode='native',state=str(E/'state'),service_id=initialized['service_id'],initial_desired='STOPPED',automatically_started=False,scope=plan['scope']+' Original run remains FAILED; completed requests and cleanup accepted by separate CPU review.',default_replaced=False))
(D/'original-driver.py.txt').write_bytes(original)
engine.save(D/'independent-review.json',review)
print(json.dumps(dict(acceptance=acceptance,original_status='FAILED',strict_lease_seconds=seconds,nvml_queries=len(queries),new_model_actions=0)))

from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'task-scoped-cpu-01';O.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();save=lambda n,v:(O/n).write_text(json.dumps(v,indent=2)+'\n')
files=['tools/serve_realtime/'+n for n in ('duplex_sdk.mjs','duplex_checks.py','duplex_task_checks.py','test_duplex_task_checks.py','test_duplex_acceptance.py','speech_checks.py','conversation_checks.mjs','bounded_journal.mjs')]+['tools/serve_recovery/profile_duplex.py','tools/serve_audit/inventory.json','.github/workflows/host-checks.yml',str(W/'task_scoped_business_01.py')]
commands=[['python3','-B','-m','unittest','-v','tools.serve_realtime.test_duplex_task_checks','tools.serve_realtime.test_duplex_acceptance'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check'],['node','--check','tools/serve_realtime/duplex_sdk.mjs']]
plan=dict(scope='Task-scoped actual speech/tool and active-audio VAD interruption; native defaults and runtime unchanged. Original failures preserved.',limits=dict(tests=19,source_counterexamples=20,seconds=120,gpu_starts=0),commands=commands,sources={n:sha(R/n) for n in files},protected={n:sha(R/n) for n in ('build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json')},followup_gpu_limits=dict(starts=1,chats=8,websocket_sessions=2,ingress_starts=1,seconds=600))
save('plan.json',plan);started=time.monotonic();rows=[];status='PASS'
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=120,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',Q4T_TEST_OUTPUT_DIR=str(O)))
 (O/f'{i}.stdout').write_bytes(r.stdout);(O/f'{i}.stderr').write_bytes(r.stderr);rows.append(dict(command=cmd,exit_code=r.returncode))
 if r.returncode:status='FAIL';break
match=re.search(r'Ran (\d+) tests',(O/'0.stderr').read_text());tests=int(match[1]) if match else 0
if tests!=19:status='FAIL'
assert all(sha(R/n)==h for n,h in plan['protected'].items())
result=dict(status=status,tests=tests,commands=rows,seconds=time.monotonic()-started,gpu_starts=0,default_unchanged=True);save('result.json',result);print(json.dumps(result));raise SystemExit(status!='PASS')

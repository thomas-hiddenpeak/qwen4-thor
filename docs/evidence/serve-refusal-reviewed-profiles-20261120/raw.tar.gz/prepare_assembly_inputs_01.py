"""Prepare read-only source projections for review; creates no qualification."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import ledger,profile_refusal_targeted as t,profile_semantic
W=Path(__file__).resolve().parent;OUT=W/'assembly-inputs-01';OUT.mkdir()
P=W/'profiles-02';C=W/'consumers-01';S=W/'semantic-lifecycle-01'
plan=read(C/'plan.json');proof=dict(format='q4t-completed-consumer-assembly-v1',identity=plan['identity'],profiles=plan['profiles'],stages={},files={},profiles_receipts={},failed_observations={})
def get(p):proof['files'][str(p.relative_to(W))]=sha(p);return read(p)
def observation(name,label):
 d=get(C/(name+'-'+label+'-observation.json'));require(d['status']=='PASS','selected failed consumer');return d['result']
def conversation(row):return dict(format='q4t-completed-conversation-observation-v1',**{k:row[k] for k in ('source','session','before','after')})
for stage,r in [('original',P),('consumers',C),('lifecycle',S)]:
 result=get(r/'result.json');exit_record=get(r/'lease/exit.json');cleanup=get(r/'cleanup.json')
 clean=[cleanup]
 if (r/'primary-cleanup.json').exists():clean+=[get(r/'primary-cleanup.json')]
 queries=[json.loads(s) for s in (r/'lease/nvml-queries.jsonl').read_text().splitlines()]
 proof['files'][str((r/'lease/nvml-queries.jsonl').relative_to(W))]=sha(r/'lease/nvml-queries.jsonl')
 require(all(q['status']=='OK' for q in queries) and all(c['remaining']==[] and c['ports_released'] and c['lease_continuously_held'] and c['model_exit']==0 for c in clean),'source environmental failure')
 proof['stages'][stage]=dict(result=result,lease=exit_record,cleanups=[{k:v for k,v in c.items() if k!='owned'} for c in clean],nvml_queries=len(queries),all_queries_ok=True,lease_sha256=sha(r/'lease/exit.json'))
proof['failed_observations']['exact_format']=get(P/'primary-conversation.sdk.json')
proof['failed_observations']['cold_semantic']=get(C/'primary-semantic-complete.sdk.json')
for name in ('primary','light'):
 registry,old=t.original(plan,name)
 if name=='primary':
  follow=get(P/'primary-tool-result.request.json')
  text={k:get(P/('primary-'+n+'.wire')) for k,n in [('schema','schema'),('tool_call','tool'),('tool_result','tool-result')]}
  text['tool_reply']=follow['messages'][-1];text['tool_source']=dict(path=t.full.DOCUMENT,content=(ROOT/t.full.DOCUMENT).read_text())
  conv=conversation(get(S/'conversation-observation.json'))
  first=get(S/'cold-complete-receipt.json');last=get(S/'warm-continuation-receipt.json')
  semantic=dict(format='q4t-completed-semantic-observation-v1',input_sha256=plan['realtime']['clip']['sha256'],settings=t.profile_evidence.semantic_settings(),turns=[get(S/(n+'.sdk.json')) for n in ('cold-complete','warm-continuation')],before=first['before'],after=last['after'],**last['health_after'])
 else:
  text=observation(name,'text');conv=conversation(observation(name,'conversation'));semantic=observation(name,'semantic-vad')
 fresh=dict(text,conversation=conv,semantic_vad=semantic)
 for label,key in [('prompt','prompt'),('media','media'),('chat-audio','chat_audio'),('tts-chat','tts')]:fresh[key]=observation(name,label)
 voice=observation(name,'voice-chat');legacy=observation(name,'legacy-responses')
 caps=get(C/(name+'-capabilities.json'));config=get(C/(name+'-config.json'))
 body=copy.deepcopy(old['business']);body.update(fresh)
 row=dict(business=body,voice=voice,legacy=legacy,capabilities=caps,configuration=config)
 profile_semantic.save_receipt(OUT/(name+'-fresh.json'),dict(fresh=fresh,voice=voice,legacy=legacy))
 proof['profiles_receipts'][name]=dict(fresh={k:ledger.digest(v) for k,v in fresh.items()},voice=ledger.digest(voice),legacy=ledger.digest(legacy),capabilities=ledger.digest(caps),configuration=ledger.digest(t.contracts.configuration(config,version=5)),startup_memory=ledger.digest(config['startup_memory']['checks']['before_allocations']))
save(OUT/'proof.json',proof)
print(json.dumps(dict(status='REVIEW_INPUTS_ONLY',proof_sha256=sha(OUT/'proof.json'),proof_digest=ledger.digest(proof),bytes=(OUT/'proof.json').stat().st_size,stages={k:dict(status=v['result']['status'],nvml=v['nvml_queries']) for k,v in proof['stages'].items()})))

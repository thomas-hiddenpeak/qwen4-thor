from pathlib import Path
import hashlib,json,tarfile,re
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=ROOT/'docs/evidence/serve-refusal-reviewed-profiles-20261120';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  b=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(b);p.chmod(m)
B=W/'profiles-reviewed-01';a=json.loads((B/'acceptance.json').read_text());cpu=json.loads((W/'assembly-cpu-01/result.json').read_text());assert a['status']=='ACCEPT_REVIEWED_REFUSAL_PRIMARY_LIGHT' and cpu['status']=='PASS'
files={}
for directory in ('assembly-cpu-01','assembly-inputs-01','profiles-reviewed-01'):
 for p in (W/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to(W))]=p
for n in ('prepare_assembly_inputs_01.py','assemble_profiles_01.py','assembly_cpu_01.py','archive_assembly_01.py'):files[n]=W/n
# Sources contain no runtime credentials. Catch accidental private material
# before publishing these exact bytes; no redaction of observed answers.
for p in files.values():
 raw=p.read_bytes();assert not re.search(rb'(?:\A|\n)-----BEGIN [A-Z ]*PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{10,}',raw)
 if p.suffix=='.json':
  def scan(v):
   if isinstance(v,dict):
    for k,x in v.items():
     assert k not in ('api_key','gateway_token','bearer_token'),(str(p),k)
     scan(x)
   elif isinstance(v,list):
    for x in v:scan(x)
  scan(json.loads(raw))
index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'raw.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'raw.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
save(O/'acceptance.json',dict(a,cpu_tests=31,cpu_seconds=cpu['seconds'],source_counterexamples=20,archive_sha256=sha(O/'raw.tar.gz')))
(O/'README.md').write_text('''# 已完成消费者的严格复核与主轻资格

候选648d6d68/protocol d4a96aa1，主/轻两配置的受影响消费者均完成严格
复核，registry为489e6fb65146c24df5cc96e904e67d9777f0d47596716ea91259ec1bf64a78b1。
31项CPU及20来源反例通过（1.771秒）；两份真实完整记录复核约1.071秒，
新增GPU启动为0。默认rev356不变，恢复组合和可回退发行继续。

复核要求没有改成“只有协议正确即可”：Realtime仍必须精确返回rev356，
语义停顿仍须接受真实概率、在最大期限前结束、完整转写/历史/计费/关闭。
观察器的PROTOCOL_PASS和OBSERVED_NOT_QUALIFIED原值保持，独立读取器
检查具体成功输出，不能直接把观察状态当资格。反例覆盖错误答案假标PASS、
冷态超时、缺关闭、篡改用量、删除原失败和替换来源。

证据明确组合三个独立严格租约，共4模型/37外部请求/323次正常NVML：
原严格组的3项成功Chat；缺项观察的主/轻Prompt、媒体、音频问答、Chat
语音及轻配置文本/Realtime/语义停顿；最后主配置完整Realtime和冷/热
语义生命周期。未变独立后端保留原v17记录，不重复执行。

原XML精确格式FAIL、原冷ASR评分过期FAIL、原组FAILED和所有原SDK状态
完整保留在固定来源证明中；它们没有被重新标成通过。资格证明这些具体
成功业务及来源闭合，不承诺模型从此每次遵循指令或冷态总能及时评分。
各消费者摘要、模型/后端/容量、配置、失败原件及租约来源均绑定确切复核，
不能任意挑选后续输出替换。不是完整性能、全模型质量或长稳验收。
''')
intro='[受影响主轻资格严格复核通过](evidence/serve-refusal-reviewed-profiles-20261120/README.md)：\n31项CPU/1.771秒、20来源反例及两份实际完整记录通过，新增GPU为0。\n确切来源组合三次独立租约（4模型/37请求/323次NVML），原格式/冷态\nFAIL与观察状态保持；成功输出仍须精确版本和有效早停分类。新registry\n489e6fb6，候选648d6d68；默认rev356不变，继续恢复组合与可回退发行。\n\n'
p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 实际消费者严格复核与主轻资格\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：复用确切已完成工作，按原业务实质检查新观察，保留全部失败与分组环境；避免反复模型重采样或改写状态。\n\n下一步：完成包读取兼容和受影响恢复，保留回退后交付，全部master继续。\n'+t)
print(json.dumps(dict(files=len(files),archive_bytes=(O/'raw.tar.gz').stat().st_size)))

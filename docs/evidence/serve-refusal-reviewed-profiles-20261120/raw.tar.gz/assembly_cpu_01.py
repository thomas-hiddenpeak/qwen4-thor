from pathlib import Path
import hashlib,json,os,subprocess,sys,time,unittest
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_audit.check_inventory import current_surface,check
W=Path(__file__).resolve().parent;OUT=W/'assembly-cpu-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  b=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(b);p.chmod(m)
selected=['tools.serve_recovery.test_profile_refusal','tools.serve_realtime.test_semantic_observation','tools.serve_recovery.test_profile_prompt_reuse',
 'tools.serve_recovery.test_profile_conversation.ConversationEvidence.test_complete_source_bound_stream_and_settlement_are_not_modified',
 'tools.serve_recovery.test_profile_conversation.ConversationEvidence.test_partial_replayed_or_failed_sdk_cannot_qualify',
 'tools.serve_recovery.test_profile_semantic.SemanticEvidence.test_unknown_timeout_or_unbilled_classifier_rejects',
 'tools.serve_recovery.test_native_bundle.BundleTests.test_default_package_has_native_binary_and_no_nginx_dependency',
 'tools.serve_recovery.test_native_bundle.BundleTests.test_historical_source_inventory_versions_remain_verifiable']
if sys.argv[1:]==['prepare']:
 OUT.mkdir()
 suite=unittest.defaultTestLoader.loadTestsFromNames(selected)
 def ids(s):
  for x in s:
   if isinstance(x,unittest.TestSuite):yield from ids(x)
   else:yield x.id()
 tests=list(ids(suite));assert len(tests)<=36 and not any('_FailedTest' in n for n in tests),tests
 p=ROOT/'tools/serve_audit/inventory.json';detach(p);v=json.loads(p.read_text());surface=current_surface(ROOT);v['sources_sha256'].update(surface['sources_sha256']);v['consumer_assembly_review_20261120']=dict(scope='Exact reviewed successful fragments, strict answer and actual classifier, immutable failures and independent leases; no observation status rewritten',cpu_checks_pending=len(tests));save(p,v);assert not check(v,surface),check(v,surface)
 paths=['tools/serve_recovery/'+n+'.py' for n in ('profile_evidence','profile_refusal_reuse','profile_record','test_profile_refusal')]+['tools/serve_audit/inventory.json']
 for n in paths:
  dst=OUT/'source'/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((ROOT/n).read_bytes())
 commands=[['python3','-B','-m','unittest',*selected,'-v'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
 save(OUT/'plan.json',dict(scope='Strict output review for previously collected observations; immutable source, failures, capacities, independent leases; all legacy gates retained',tests=tests,maximum_tests=len(tests),source_counterexamples=20,maximum_seconds=120,new_gpu_starts=0,commands=commands,sources={n:sha(ROOT/n) for n in paths}))
 intro=f'分组证据复核读取器已实现；新观察仍须原精确答案与有效早停分类，\n确切来源摘要绑定各消费者及原失败，三个独立租约不冒充一组。\n冻结{len(tests)}项CPU/20来源反例/120秒/0GPU，随后离线核对两配置实际记录。\n原严格组FAIL和默认保持，无新增推理，恢复及全部master继续。\n\n'
 p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
 p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 分组证据的严格成功输出复核\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：新的观察记录包含完整成功结果，需独立按原实质合同复核，不能仅改SDK状态，也不必再启动模型重采样。\n\n下一步：对应CPU反例与实际记录核对后推进恢复和可回退交付。\n'+t)
 print(json.dumps(dict(status='PREPARED',tests=len(tests),gpu=0)))
else:
 assert sys.argv[1:]==['run'];p=json.loads((OUT/'plan.json').read_text());assert all(sha(ROOT/n)==h for n,h in p['sources'].items())
 started=time.monotonic();rows=[]
 for i,cmd in enumerate(p['commands']):
  run=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=max(1,120-(time.monotonic()-started)))
  (OUT/f'command-{i}.stdout').write_text(run.stdout);(OUT/f'command-{i}.stderr').write_text(run.stderr)
  rows.append(dict(command=cmd,exit_code=run.returncode));print(json.dumps(rows[-1]),flush=True)
  if run.returncode:break
 save(OUT/'result.json',dict(status='PASS' if len(rows)==2 and all(x['exit_code']==0 for x in rows) else 'FAIL',seconds=time.monotonic()-started,commands=rows,sources_unchanged=all(sha(ROOT/n)==h for n,h in p['sources'].items()),new_gpu_starts=0))

"""Independent strict review of fixed completed fragments, without model execution."""
import copy,json,hashlib,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
from tools.serve_recovery import profile_refusal_targeted as t,profile_refusal_reuse as reuse
from tools.serve_recovery import profile_record,profile_contract,profile_evidence,ledger
W=Path(__file__).resolve().parent;OUT=W/'profiles-reviewed-01';INPUT=W/'assembly-inputs-01';C=W/'consumers-01'

def prepare():
 OUT.mkdir(mode=0o700)
 cpu=read(W/'assembly-cpu-01/result.json');require(cpu['status']=='PASS' and cpu['sources_unchanged'],'CPU prerequisite missing')
 paths=[INPUT/'proof.json',INPUT/'primary-fresh.json',INPUT/'light-fresh.json',C/'plan.json',W/'assembly-cpu-01/plan.json',W/'assembly-cpu-01/result.json',Path(__file__)]
 paths += [ROOT/'tools/serve_recovery'/ (n+'.py') for n in ('profile_evidence','profile_refusal_reuse','profile_record','profile_contract')]
 save(OUT/'review-plan.json',dict(scope=__doc__,maximum_profile_reviews=2,maximum_seconds=120,new_gpu_starts=0,automatic_retries=False,source_files={str(p):sha(p) for p in paths},original_failed_stages_unchanged=True))
 print(json.dumps(dict(status='PREPARED_STRICT_REVIEW',profiles=2,gpu=0)))

def run():
 frozen=read(OUT/'review-plan.json');started=time.monotonic()
 require(all(sha(p)==h for p,h in frozen['source_files'].items()),'review source drift')
 proof=read(INPUT/'proof.json');require(ledger.digest(proof)==reuse.ASSEMBLY_DIGEST and sha(INPUT/'proof.json')==reuse.ASSEMBLY_FILE,'unknown input assembly')
 for name,digest in proof['files'].items():require(sha(W/name)==digest,'original observation drift: '+name)
 for name in ('profiles-02','consumers-01','semantic-lifecycle-01'):
  queries=[json.loads(s) for s in (W/name/'lease/nvml-queries.jsonl').read_text().splitlines()]
  require(all(q['status']=='OK' and q['returncode']==0 for q in queries),'NVML evidence unavailable')
 plan=read(C/'plan.json');probe=copy.deepcopy(plan);probe['limits']=t.LIMITS;probe['planned']={k:v for k,v in t.LIMITS.items() if k not in ('seconds','controls')};t.check_plan(probe)
 require(sha(plan['binary'])==reuse.REVIEW['candidate_binary'],'candidate executable drift')
 for p,h in plan['protected'].items():require(sha(p)==h,'default changed')
 environment=dict(status='PASS',env_abort=False,all_queries_ok=True,nvml_queries=323,lease_result_sha256=reuse.ASSEMBLY_FILE,cleanup_complete=True)
 registry=dict(format=profile_contract.FORMAT,identity=plan['identity'],profiles=plan['profiles'],qualifications={});values={}
 for name in profile_contract.NAMES:
  previous,original=t.original(plan,name);fresh=read(INPUT/(name+'-fresh.json'))
  caps=read(C/(name+'-capabilities.json'));config=read(C/(name+'-config.json'))
  business=copy.deepcopy(original['business']);business.update(fresh['fresh'])
  value=dict(format=profile_evidence.PROMPT_FORMAT,profile=name,identity=plan['identity'],capacity=plan['profiles'][name],capabilities=caps,configuration=t.contracts.configuration(config,version=5),startup_memory=config['startup_memory']['checks']['before_allocations'],business=business,environment=environment)
  value=reuse.attach(value,previous,original,fresh['legacy'],fresh['voice'],assembly=proof)
  digest=hashlib.sha256(ledger.canonical(value)+b'\n').hexdigest()
  registry['qualifications'][name]=profile_contract.qualification(name,value['capacity'],value['identity'],caps,value['configuration'],value['startup_memory'],digest)
  values[name]=value
 profile_contract.validate(registry)
 for name,value in values.items():
  digest=hashlib.sha256(ledger.canonical(value)+b'\n').hexdigest()
  profile_evidence.validate(value,registry,name,digest)
 require(time.monotonic()-started<120,'profile review bound')
 qualified=OUT/'qualified';qualified.mkdir(mode=0o700)
 for name,value in values.items():
  path=qualified/(name+'.json');profile_record.save(path,value)
  require(sha(path)==registry['qualifications'][name]['evidence_sha256'],'written qualification digest differs')
  profile_evidence.validate(profile_record.read(path),registry,name,sha(path))
 save(qualified/'registry.json',registry)
 for name in profile_contract.NAMES:
  for kind in ('capabilities','config'):
   (OUT/(name+'-'+kind+'.json')).write_bytes((C/(name+'-'+kind+'.json')).read_bytes())
 (OUT/'combined-environment.json').write_bytes((INPUT/'proof.json').read_bytes())
 plan.update(output=str(OUT),review_only=True,source_review_plan=str(OUT/'review-plan.json'),qualified_source_stages=[str(W/n) for n in ('profiles-02','consumers-01','semantic-lifecycle-01')])
 save(OUT/'plan.json',plan)
 save(OUT/'acceptance.json',dict(status='ACCEPT_REVIEWED_REFUSAL_PRIMARY_LIGHT',environment=environment,new_gpu_starts=0,source_stage_model_starts=4,source_stage_external_requests=37,source_stage_nvml_observations=323,separate_continuous_leases=True,original_failed_stages_preserved=True,observation_statuses_unchanged=True,strict_exact_answer=True,strict_actual_classifier=True,actual_review_seconds=time.monotonic()-started,registry_sha256=sha(qualified/'registry.json'),binary_sha256=reuse.REVIEW['candidate_binary'],protocol_sha256=reuse.REVIEW['candidate_protocol'],default_unchanged=True,managed_switching_accepted=False,performance_claim=False,full_model_quality=False))
 print(json.dumps(dict(status='ACCEPT_REVIEWED_REFUSAL_PRIMARY_LIGHT',seconds=time.monotonic()-started,registry_sha256=sha(qualified/'registry.json'),profile_bytes={n:(qualified/(n+'.json')).stat().st_size for n in values})))

if __name__=='__main__':
 if sys.argv[1:]==['prepare']:prepare()
 else:
  require(sys.argv[1:]==['run'],'explicit mode required')
  try:run()
  except Exception as e:
   save(OUT/'review-failure.json',dict(status='FAIL',error=str(e)));raise

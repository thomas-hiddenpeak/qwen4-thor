import hashlib
import json
import re
import shutil
import tarfile
from pathlib import Path

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = W / 'delivery-01'
O = R / 'docs/evidence/serve-media-state-cache-delivery-20261117'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
v = read(D / 'result.json')
assert v['status'] == 'PASS_MEDIA_STATE_CACHE_DELIVERED'
assert v['publication']['revision'] == 214
assert len(v['commands']) == 19 and all(x['returncode'] == 0 for x in v['commands'])
assert v['state'] == 'STOPPED' and v['new_gpu_starts'] == 0
c = v['publication']['current']
composition = read(W / 'publication-composition.json')
assert c['manifest_sha256'] == composition['candidate']['manifest_sha256']
assert sha(R / 'build/q4t') == c['engine_binary_sha256']
assert sha(R / 'build/service.release.json') == c['service_release_sha256']
files = [(p, 'delivery-01/' + p.name) for p in D.iterdir()
         if p.is_file() and not p.is_symlink()]
for pattern in ('delivery-prepare-*.*', 'delivery-run-*.*',
                'publication-archive-*.*', 'version-archive-*.*'):
    files.extend((p, p.name) for p in W.glob(pattern) if p.is_file())
for name in ('archive_delivery.py', 'deliver.py', 'run_delivery.py',
             'archive_generations.py', 'archive_version_cycles.py',
             'prepare_migration_candidate.py', 'publication-composition.json',
             'package-02/review.json'):
    files.append((W / name, name))
files = sorted({n: p for p, n in files}.items())
secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, x in value.items():
            if key in ('api_key', 'gateway_token', 'shared_secret', 'private_key', 'token') and isinstance(x, str) and len(x) >= 24:
                secrets.append(x.encode())
            else:
                collect(x)
    elif isinstance(value, list):
        for x in value:
            collect(x)
for p in (R/'build/service/gateway-policy.json', R/'build/service/engine/client-policy.json'):
    collect(read(p))
for name, p in files:
    data = p.read_bytes()
    assert not any(x in data for x in secrets), name
    assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', data), name
O.mkdir()
with tarfile.open(O/'records.tar.gz', 'w:gz') as tar:
    for name, p in files:
        tar.add(p, arcname=name, recursive=False)
for name in ('result.json', 'recovery-anchor.json'):
    shutil.copyfile(D/name, O/name)
a = dict(status='ACCEPT_MEDIA_STATE_CACHE_DELIVERY', revision=214,
         current=c, commands=19, seconds=v['seconds'], state='STOPPED',
         new_gpu_starts=0, core_client_outer_bytes_preserved=True,
         profile_migration='Explicit complete media cache/chunked-prefill capability upgrade; historical state and budgets preserved',
         root_cycles_preserved=True,
         manual_root=composition['manual_root']['manifest_sha256'],
         automatic_payload=composition['automatic_fallback']['manifest_sha256'],
         candidate_whole_package_gpu_run=False,
         composed_change='Only publication profile_migration.py differs from the business-qualified candidate; CPU and actual STOPPED migration/rollback validated',
         older_engine_fallback=False, prior_rev204_preserved=True,
         retired_generations_archived=2, retired_versions_archived=2,
         deleted_files=0, files=len(files), secret_scan_matches=0,
         archive_sha256=sha(O/'records.tar.gz'), main_integration_pending=True,
         all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a, indent=2)+'\n')
(O/'README.md').write_text(f'''# 媒体状态缓存与视觉分块默认交付 rev214

实际包`{c['manifest_sha256']}`，generation
`{c['generation_sha256']}`；引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、实际整根回退与再前进完成，{v['seconds']:.3f}秒，
0新增GPU。最终STOPPED，outer已配置且累计启动0次。

实际图片/视频内容、完整视觉块、三轴位置及偏移共同绑定缓存；
分块prefill保留全局视觉特征与位置。原标准视频短尾数值回归已修复，
完整/冷/热输出和logprobs一致，真实SSD写入/恢复成立。
[业务证据](../serve-media-state-cache-business-20261117/README.md)中，新引擎
正式接受6启动26请求；含原失败与诊断累计13/60、636.757秒。

发布预检揭示false→true能力迁移被旧规则拒绝。新包仅增加已验的
发布迁移模块；6项CPU/7次执行通过，随后本记录完成真实STOPPED迁移。
引擎、其发布记录、客户端、live controller与helper保持业务验收身份；
不声称新整包另跑GPU。第一次prepare失败、归档权限拒绝均保留，
工作目录改为0700后重做；没有放松保护。

核心/client/outer账本字节保持，profile只做完整合同的显式能力升级，
history/pending/selected/deadline/clock/configuration保持。先新包迁移，
再安装已实跑的原现代保留根，回退后恢复各自原周期，仅递增revision。
人工回退根`{a['manual_root'][:12]}`、自动payload`{a['automatic_payload'][:12]}`
都使用当前引擎，不冒充独立旧引擎回退；rev204原包和状态另保留。

退休generation/版本登记各两份可恢复归档，0删除。PR38最终检查和
实际合main继续；长稳由用户执行，全部master未完成项继续推进。
''')
p = R/'docs/STATUS.md'
s = p.read_text()
rows = {'发布': 'rev214；服务包 `'+c['manifest_sha256']+'`',
        'Generation': '`'+c['generation_sha256']+'`',
        '引擎': '`'+c['engine_binary_sha256']+'`',
        '引擎发布记录': '`'+c['engine_release_sha256']+'`',
        '人工整包回退': '现代保留根 `'+a['manual_root']+'`；outer/周期及媒体缓存能力完整，前驱204/196另保留',
        '自动payload回退': '已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退'}
for label, value in rows.items():
    s, count = re.subn(r'^\| '+re.escape(label)+r' \| .* \|$',
                      lambda _: f'| {label} | {value} |', s, count=1, flags=re.M)
    assert count == 1, label
intro = f'''[rev214媒体缓存交付](evidence/serve-media-state-cache-delivery-20261117/README.md)
已完成19项STOPPED发布、实际整根回退与再前进，{v['seconds']:.3f}秒、0新增
GPU。原视频数值回归已修复，图片/schema/私有缓存、主轻及保留包真实
业务通过；发布模块仅补显式能力迁移，原预算和周期保持。PR38最终
检查与实际合main继续；用户day准备独立新快照，rev204原入口保留。
全部33项master仍是总目标完成条件，其他缺口继续实现。

'''
s = s.replace('[rev204审核交付]', intro+'前驱[rev204审核交付]', 1)
s = s.replace('## 最近完成的实现和验证\n\n', '## 最近完成的实现和验证\n\n'+intro, 1)
p.write_text(s)
p = R/'docs/log/2026-11-17.md'
head, rest = p.read_text().split('\n', 1)
p.write_text(head+f'''\n
## rev214媒体缓存与视觉分块可回退交付

2026-11-17：实际19项STOPPED发布/整根回退/再前进通过，{v['seconds']:.3f}秒，
0新增GPU；原核心/client/outer预算与各根原周期保持，profile仅做已验
完整媒体能力升级。预检拒绝与归档权限失败保留，未放松合同；新包
只有发布迁移模块与原业务候选不同，CPU及实际发布验证明确补齐。
前驱204和可恢复归档保留。下一步独立day交接、PR38实际合main与
其余全部master，不以该阶段替代缺失协议和后端实现。
'''+rest)
p = R/'docs/serve-master-goals-v2.json'
j = read(p)
for task in j['tasks']:
    item = task.get('media_state_cache_20261117')
    if item:
        item.update(state='delivered_main_pending', revision=214,
                    manifest_sha256=c['manifest_sha256'],
                    delivery_evidence='evidence/serve-media-state-cache-delivery-20261117/README.md')
    if task['id'] == 'A10':
        task['remaining_required'] = [x for x in task['remaining_required'] if x != 'Native media cache/MRoPE state resume']
    if task['id'] == 'A05':
        task['remaining_required'] = ['Stop, constrained-output and private cache combinations with correct final validation; audit remaining combinations against accepted media evidence']
    if task['id'] == 'Q02':
        task['state'] = 'latest_release_delivered_main_pending_remaining_tasks_active'
        task['media_state_cache_delivery_20261117'] = a | dict(evidence='evidence/serve-media-state-cache-delivery-20261117/README.md')
        task['remaining_required'] = ['PR38 final-head checks and actual main merge', 'Delivery of every remaining implementation']
    if task['id'] == 'R07':
        task['current_execution_prerequisite'] = 'Refresh exact cold qualification against rev214 or then-current default; do not stop camera/jtop or enter device-fence without pending maintenance handoff.'
j['next'] = j['next_task'] = 'Freeze rev214 native day handoff; complete PR38 final-head checks and actual main merge; continue remaining Chat audio/web-search, schema/cache combinations, model backends and cold/resource/host tasks. All 33 required tasks remain the completion boundary.'
p.write_text(json.dumps(j, ensure_ascii=False, indent=2)+'\n')
p = R/'docs/README.md'
p.write_text(p.read_text()+'\n- [rev214媒体缓存与视觉分块交付](evidence/serve-media-state-cache-delivery-20261117/README.md)：完整位置/内容身份、数值修复与真实整根回退，原失败保留。\n')
p = R/'docs/SERVE_MEDIA_STATE_CACHE_2026-11-17.md'
p.write_text(p.read_text()+'''\n## 当前阶段实际交付

当前已实际发布rev214，19项STOPPED检查、整根回退与再前进通过，
0新增GPU。新引擎正式接受6启动26请求，含原失败与诊断累计13/60、
636.757秒，均在修订的最终预算内。发布能力升级修复另有6项CPU/
7次执行及真实迁移证据；其余控制/helper身份复用。详见
[交付记录](evidence/serve-media-state-cache-delivery-20261117/README.md)。
本阶段不代表全部schema组合、媒体格式/后端或总计划完成。
''')
print(json.dumps(dict(revision=214, files=len(files), seconds=v['seconds'], secret_scan_matches=0)))

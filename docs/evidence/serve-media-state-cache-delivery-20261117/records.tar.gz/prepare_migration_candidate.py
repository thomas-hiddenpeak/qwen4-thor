"""Re-seal only the reviewed publication capability adapter, preserving actual engine evidence."""
import copy,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import bundle,profile_manager,version_contract
from tools.serve_service import package as p
W=Path(__file__).resolve().parent;OUT=W/'package-02';SOURCE='source/tools/serve_recovery/profile_migration.py'
def main():
 os.umask(0o077)
 p.require(not OUT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),'clean reviewed new package required')
 original=p.read(W/'package-01/receipt.json');old=Path(original['package']);manifest=bundle.verify(old,original['manifest_sha256'])
 cpu=p.read(ROOT/'docs/evidence/serve-media-cache-migration-cpu-20261117/acceptance.json');p.require(cpu['status']=='PASS_TARGETED_MEDIA_CAPABILITY_MIGRATION_CPU','migration CPU missing')
 delta={n for n,h in manifest['files'].items() if n.startswith('source/') and p.sha(ROOT/n[7:])!=h}
 p.require(delta=={SOURCE},'unreviewed control delta')
 protected={n:p.sha(ROOT/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json']}
 OUT.mkdir(mode=0o700);target=OUT/'bundle';shutil.copytree(old,target,symlinks=True)
 path=target/SOURCE;path.chmod(0o600);shutil.copyfile(ROOT/SOURCE[7:],path);path.chmod(0o400)
 changed=copy.deepcopy(manifest);changed['files'][SOURCE]=p.sha(path)
 path=target/'manifest.json';path.chmod(0o600);p.save(path,changed);path.chmod(0o400);digest=p.sha(path)
 path=target/'bin/q4t';path.chmod(0o700);path.write_bytes(bundle.launcher(digest,changed['python']['path']));path.chmod(0o500)
 p.require(bundle.verify(target,digest)==changed,'new package failed verification')
 p.require({n for n,h in changed['files'].items() if manifest['files'].get(n)!=h}=={SOURCE} and changed['engine_manifest_sha256']==manifest['engine_manifest_sha256'] and p.sha(target/'engine/q4t.release.json')==p.sha(old/'engine/q4t.release.json'),'non-publication behavior changed')
 descriptor=dict(package=str(target),manifest_sha256=digest);p.save(OUT/'receipt.json',descriptor)
 prior=(ROOT/'build/service').resolve();prior_manifest=bundle.verify(prior,p.sha(prior/'manifest.json'))
 permit=profile_manager.compatible(prior_manifest,changed,prior,target)
 p.require(permit is not None and not permit['automatic'],'actual migration must be explicit')
 modern=p.read(W/'modern-retained-01/receipt.json');modern_manifest=bundle.verify(modern['package'],modern['manifest_sha256'])
 p.require(profile_manager.compatible(changed,modern_manifest,target,modern['package']) is None,'retained root must keep exactly the migrated capabilities')
 review=dict(status='ACCEPT_REVIEWED_PUBLICATION_MODULE_COMPOSITION',original={k:original[k] for k in ['package','manifest_sha256']},candidate=descriptor,changed_sources=[SOURCE],module_sha256=p.sha(ROOT/SOURCE[7:]),engine_release_helpers_clients_profiles_identical=True,model_restart_and_live_monitoring_unchanged=True,exact_new_package_gpu_run=False,new_gpu_starts=0,migration_cpu_evidence='docs/evidence/serve-media-cache-migration-cpu-20261117/acceptance.json',retained_original_business=modern,actual_upgrade_permit=permit,stopped_publication_pending=True,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
 p.save(OUT/'review.json',review)
 accepted=p.read(ROOT/'docs/evidence/serve-media-state-cache-business-20261117/acceptance.json')
 accepted.update(candidate=descriptor,engine_binary_sha256=accepted['binary_sha256'],modern_service_acceptance=p.read(W/'modern-business-01/decision.json'),candidate_control_reuse=review,profile_qualification=p.read(W/'profiles-02/acceptance.json'),gpu_evidence_original=dict(path=str(ROOT/'docs/evidence/serve-media-state-cache-business-20261117/acceptance.json'),sha256=p.sha(ROOT/'docs/evidence/serve-media-state-cache-business-20261117/acceptance.json')))
 p.save(W/'publication-composition.json',accepted)
 p.require(all(p.sha(ROOT/n)==h for n,h in protected.items()),'default changed')
 print(descriptor)
if __name__=='__main__':main()

import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=R/'docs/evidence/serve-realtime-duplex-ci-boundaries-20261120'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(W/'ci-boundary-repair-01/result.json');b=read(W/'ci-boundary-build-01/result.json')
assert r['status']=='PASS' and r['tests']==10 and r['runtime_source_unchanged'] and b['warnings']==0 and not O.exists();O.mkdir()
paths=[p for p in (W/'ci-boundary-repair-01').iterdir() if p.is_file()]+[W/'ci-c3a-failed.log',W/'build_ci_boundary_host_01.py',Path(__file__)]+[W/'ci-boundary-build-01'/n for n in ['plan.json','result.json','build.log']]
rows=[]
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for p in paths:
  name=str(p.relative_to(W));t.add(p,arcname=name,recursive=False);rows.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
(O/'index.json').write_text(json.dumps(dict(records=rows,archive_sha256=sha(O/'records.tar.gz')),indent=2)+'\n')
(O/'acceptance.json').write_text(json.dumps(dict(result=r,build=b,original=read(W/'ci-boundary-repair-01/original-result.json'),original_ci_run=44695775555,default_revision=386,phase_pr=55),indent=2)+'\n')
(O/'README.md').write_text(f'''# 音频来源边界的五项旧断言修复

2026-11-20。GitHub CI 44695775555失败：5项仍断言原生转写是裸文本或
空字符串，未同步已验的来源标记表示。保留原完整CI记录，本机用原
host程序重现5/5失败，0.040秒。没有改运行时、默认程序或推理参数。

独立JSON解析器检查真实转写内容及conversation/item/content索引；
空音频仍为真实空转写，且未调用ASR。加强反例，客户端参考文本不能
进入模型上下文，公开转录/波形合同仍检查。5项修复加5项直接保护
全部通过，{r['seconds']:.3f}秒；host必要构建{b['seconds']:.3f}秒、零警告。
原GPU、主轻和恢复证据按未变运行时复用，不追加GPU或全模型测试。

另在公共证据扫描中发现恢复归档误含内部网关初始凭据，已删除两份
私有配置的公开副本，原SHA和完整原件保留在私有现场。历史Git值
仍视为已披露；凭据重新签发与发布正在处理，不在完成前合入PR #55。

[结果](acceptance.json)、[索引](index.json)、[原件](records.tar.gz)。
''')
p=R/'docs/STATUS.md';s=p.read_text();key='## 正在推进\n\n';s=s.replace(key,key+'''PR #55合入前发现5项旧音频断言与来源标记表示不一致，已修复并完成
[10项针对性CPU验证](evidence/serve-realtime-duplex-ci-boundaries-20261120/README.md)，
运行时未改。另发现恢复证据误含内部网关初始凭据，公共副本已清理；
历史值按已披露处理，当前服务STOPPED，重新签发候选/回退包凭据与
发布完成前不合入。原验证和错误回答均保留，不用归档清理改写结果。

''',1);p.write_text(s)
p=R/'docs/log/2026-11-20.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## PR #55修复五项旧断言，并处理公开证据中的初始凭据

日期：2026-11-20。

做了什么：原CI和本机5项失败保留；独立解析来源标记后10项CPU通过，
host零警告，运行时未改。恢复公开归档删除误打包的两份私有配置，
原件和SHA保存在私有现场；历史Git中的初始凭据仍按披露处理。

为什么：测试须验证实际音频及来源，不能退回丢失边界的旧表示；
证据发布不能包含私有网关配置，已发布的凭据不能仅删除后假装安全。

下一步：重新签发候选和回退包的初始凭据，保持客户配额和STOPPED；
完成针对性认证检查与可回退发布，再继续PR/main及全部master。

'''+s[i:])
p=R/'docs/serve-master-goals-v2.json';g=read(p);g['realtime_progress']['duplex_input_20261120']['ci_boundary_repair']=dict(evidence=str(O.relative_to(R)/'README.md'),tests=10,original_ci_run=44695775555,runtime_unchanged=True,credential_reissue_pending=True)
p.write_text(json.dumps(g,indent=2,ensure_ascii=False)+'\n')
print('CI_REPAIR_ARCHIVED; credential reissue remains pending')

from pathlib import Path
import json,os,subprocess,sys,time
os.umask(0o077)
phase=Path(__file__).resolve().parent
root=phase/'source'
kind=sys.argv[1]
records=phase/('checks-'+kind)
records.mkdir(exist_ok=False)
commands=[]
def run(label,argv,timeout=300):
    row=dict(label=label,argv=[str(v) for v in argv],cwd=str(root),timeout=timeout)
    start=time.monotonic()
    with (records/(label+'.log')).open('wb') as log:
        try:
            result=subprocess.run(row['argv'],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
            row['returncode']=result.returncode
        except subprocess.TimeoutExpired:
            row['returncode']=124;row['timed_out']=True
    row['seconds']=time.monotonic()-start
    commands.append(row)
    (records/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if row['returncode']:
        print((records/(label+'.log')).read_text(errors='replace')[-6000:],flush=True)
        raise SystemExit(row['returncode'])
if kind=='cpu':
    host=phase/'host';ple=phase/'ple'
    run('host-configure',['cmake','-S',root/'tests/host','-B',host,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DPython3_EXECUTABLE=/usr/bin/python3'])
    run('host-build',['cmake','--build',host,'--target','q4t_host_tests','--parallel','4'],900)
    run('host-contracts',['ctest','--test-dir',host,'--no-tests=error','--output-on-failure','--verbose','-R','^q4t_public_host_contracts$'],240)
    pattern='^q4t_(gpu_exclusive|managed_telemetry|nvml_classification|nvml_query|monitor_resume|auxiliary_isolation|resource_control_isolation|managed_telemetry_exit)_contracts$'
    run('managed-contracts',['ctest','--test-dir',host,'--no-tests=error','--output-on-failure','--verbose','-R',pattern],900)
    run('supervisor-contracts',['/usr/bin/python3','-B',phase/'supervisor_checks.py'],240)
    run('ple-configure',['cmake','-S',root/'tests/ple_health_host','-B',ple,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14'])
    run('ple-build',['cmake','--build',ple,'--parallel','4'],300)
    run('ple-dependencies',['ldd',ple/'q4t_ple_health_tests'])
    run('ple-contracts',['ctest','--test-dir',ple,'--no-tests=error','--output-on-failure','--verbose'],90)
    run('source-inventory',['/usr/bin/python3','-B','tools/serve_audit/check_inventory.py','--self-check'])
    run('generated-contract',['/usr/bin/python3','-B','tools/serve_protocol/build_contract.py','--check'])
elif kind=='compile':
    build=phase/'runtime'
    dependency='/home/rm01/models/dev/qwen4-thor/.q4t-work/structured-control-20261102/xgrammar'
    run('runtime-configure',['cmake','-S',root,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_CUDA_HOST_COMPILER=g++-14','-DCMAKE_CUDA_ARCHITECTURES=110a','-DQ4T_CUDA_ARCHITECTURES=110a','-DQ4T_ENABLE_XGRAMMAR=ON','-DQ4T_BUILD_TESTS=OFF','-DFETCHCONTENT_SOURCE_DIR_Q4T_XGRAMMAR='+dependency],300)
    run('runtime-build',['cmake','--build',build,'--target','q4t','--parallel','2'],1800)
else: raise SystemExit('bad group')
print(json.dumps(dict(group=kind,passed=True,commands=len(commands),model_starts=0,gpu_tests=0)),flush=True)

from pathlib import Path
import importlib,json,os,sys,unittest
os.umask(0o077)
phase=Path(__file__).resolve().parent
root=phase/'source'
sys.path[:0]=[str(root),str(root/'tools/evalscope')]
loader=unittest.defaultTestLoader
unique={}
def flatten(suite):
    for entry in suite:
        if isinstance(entry,unittest.TestSuite):yield from flatten(entry)
        else:yield entry
for name in ('tools.serve_service.test_service','tools.serve_service.test_deadlines'):
    for test in flatten(loader.loadTestsFromModule(importlib.import_module(name))):
        unique.setdefault(test.id(),test)
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(unique.values()))
(phase/'supervisor-inventory.json').write_text(json.dumps(dict(ids=list(unique),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped)),indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())

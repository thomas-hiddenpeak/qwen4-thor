from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
phase=Path(__file__).resolve().parent;root=phase/'source';original=Path('/home/rm01/models/dev/qwen4-thor')
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
inventory=json.loads((phase/'test-inventory.json').read_text())
commands=[row for group in ('cpu','compile') for row in json.loads((phase/('checks-'+group)/'commands.json').read_text())]
assert len(commands)==13 and all(row['returncode']==0 for row in commands)
warning_rows=[]
for folder in (phase/'checks-cpu',phase/'checks-compile'):
    for path in folder.glob('*-build.log'):
        warning_rows.extend([str(path)+':'+line for line in path.read_text().splitlines() if re.search(r'warning:|CMake Warning|nvcc warning',line,re.I)])
assert not warning_rows,warning_rows
protected=json.loads((phase/'before.json').read_text())
assert all(digest(original/name)==value for name,value in protected['protected'].items())
protocol={}
raw=[]
for kind in ('host','runtime'):
    folder=phase/kind/'generated/q4t/server'
    sources=json.loads((folder/'chat_protocol_sources.json').read_text())
    assert all(digest(root/name)==value for name,value in sources.items())
    header=(folder/'chat_protocol_identity.h').read_text()
    protocol[kind]=dict(sha256=re.search(r'kProtocol\[\] = "([0-9a-f]+)"',header)[1],source_count=len(sources),drift={})
    raw.extend([folder/'chat_protocol_sources.json',folder/'chat_protocol_identity.h'])
assert protocol['host']==protocol['runtime']
ldd=(phase/'checks-cpu/ple-dependencies.log').read_text()
assert not re.search(r'libcuda|libnvidia|libnvml',ldd,re.I)
extract=json.loads((phase/'extraction-initial.json').read_text())
sources={row['path']:digest(root/row['path']) for row in extract['extracted']}
binaries={str(path.relative_to(phase)):dict(sha256=digest(path),bytes=path.stat().st_size) for path in (phase/'host/q4t_host_tests',phase/'ple/q4t_ple_health_tests',phase/'runtime/q4t')}
output=root/'docs/evidence/serve-resilience-closeout-20261107';output.mkdir(exist_ok=False)
source=dict(base=extract['base'],research_source=extract['research_source'],extracted_sources=sources,protocol=protocol,binaries=binaries,protected=protected,source_integrity=json.loads((phase/'source-integrity.json').read_text()),new_runtime_executed=False)
save(output/'source-bindings.json',source)
save(output/'test-inventory.json',inventory)
result=dict(status='CPU_INTEGRATION_ACCEPTED_NOT_RELEASED',unique_tests=inventory['unique_tests'],test_executions=inventory['executions'],groups=inventory['groups'],failures=0,skips=0,production_build_passed=True,build_warnings=0,generated_contract_current=True,source_anchors=124,source_mutation_controls=3,prior_archive_records_verified=137,old_v7_verified=True,source_rebindings=['docs/NVML_RESILIENCE_RESEARCH_2026-11-07.md','docs/serve-input-semantics-v1.json','tools/serve_audit/inventory.json'],models_started=0,real_model_http=0,gpu_tests=0,real_nvml_queries=0,real_cgroup_changes=0,production_service_operations=0,model_restarts=0,default_replaced=False,merged_main=False,production_accepted=False,visual_candidate='HOLD',limits=['No real model HTTP or deployment acceptance for the new binary/v9/v10 combination.','No new exporter/grammar cleanup/log blocking/controller takeover work.','Frozen historical v7 business acceptance remains bound to its original manifest.','CPU integrated worker lifetimes use synthetic monitoring/HTTP/cgroup inputs.'])
save(output/'result.json',result)
raw+=list((phase/'checks-cpu').glob('*'))+list((phase/'checks-compile').glob('*'))
raw+=[phase/name for name in ('run_checks.py','supervisor_checks.py','seal.py','before.json','extraction-initial.json','generated-reconciliation.json','source-integrity.json','supervisor-inventory.json','test-inventory.json')]
raw+=[phase/'runtime/CMakeCache.txt',phase/'host/CMakeCache.txt']
rows=[]
with tarfile.open(output/'raw-records.tar.gz','w:gz') as tar:
    for path in sorted(raw):
        assert path.is_file()
        name=str(path.relative_to(phase));tar.add(path,arcname=name,recursive=False)
        rows.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)))
save(output/'manifest.json',dict(local_root=str(phase),archive_sha256=digest(output/'raw-records.tar.gz'),records=rows))
with tarfile.open(output/'raw-records.tar.gz','r:gz') as tar:
    assert set(tar.getnames())=={row['path'] for row in rows}
    for row in rows:
        data=tar.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps(dict(unique_tests=result['unique_tests'],archive_records=len(rows),runtime=binaries['runtime/q4t'],protocol=protocol['runtime'],warnings=0),ensure_ascii=False))

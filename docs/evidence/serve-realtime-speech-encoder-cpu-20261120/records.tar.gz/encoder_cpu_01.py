"""Frozen 13 CPU contracts and source counterexamples, no model execution."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).parent
O = W / 'encoder-cpu-01'
BINARY = ROOT / '.q4t-work/serve-file-search-20261112/host/q4t_host_tests'
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
assert not O.exists()
scope = json.loads((W / 'encoder-scope-03.json').read_text())
build = json.loads((W / 'encoder-build-02/result.json').read_text())
assert build['status'] == 'BUILD_PASS' and sha(BINARY) == build['binary_sha256']
for name, digest in scope['source_sha256'].items():
    assert sha(ROOT / name) == digest, name
assert sha(W / 'required-encoder-01.txt') == scope['required_list_sha256']
O.mkdir(mode=0o700)
os.link(BINARY, O / 'host-tests')
commands = [
    [str(BINARY), '--required-list', str(W / 'required-encoder-01.txt')],
    ['python3', '-B', 'tools/serve_audit/check_inventory.py', '--self-check'],
]
protected = {str(ROOT / name): sha(ROOT / name) for name in (
    'build/q4t', 'build/q4t.release.json', 'build/service.release.json',
    'build/service-native-state/ledger.json')}
save(O / 'plan.json', dict(scope=scope, commands=commands, protected=protected,
                           binary_sha256=sha(BINARY), gpu_starts=0))
start = time.monotonic()
rows = []
try:
    for i, command in enumerate(commands):
        with (O / f'command-{i}.stdout').open('w') as out, (O / f'command-{i}.stderr').open('w') as err:
            result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err,
                                    timeout=120 - (time.monotonic() - start))
        rows.append(dict(command=command, exit_code=result.returncode))
        assert result.returncode == 0, command
    log = (O / 'command-0.stdout').read_text()
    assert '13 tests, 13 passed, 0 failed, 0 skipped' in log
    audit = json.loads((O / 'command-1.stdout').read_text())
    assert audit['inventory_current'] and audit['mutation_checks'] == 20
    assert all(sha(Path(name)) == digest for name, digest in protected.items())
    result = dict(status='PASS', seconds=time.monotonic() - start,
                  commands=rows, tests=13, new_tests=8, existing_protection=5,
                  source_counterexamples=20, binary_sha256=sha(BINARY),
                  default_unchanged=True, gpu_starts=0,
                  endpoint_connected=False, all_master_tasks_active=True)
except BaseException as error:
    result = dict(status='FAILED', seconds=time.monotonic() - start,
                  commands=rows, error=repr(error), gpu_starts=0)
    save(O / 'result.json', result)
    raise
save(O / 'result.json', result)
print(json.dumps(result))

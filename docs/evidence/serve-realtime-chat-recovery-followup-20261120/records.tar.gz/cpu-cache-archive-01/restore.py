from pathlib import Path
import hashlib,json,os,tarfile
out=Path(__file__).resolve().parent;root=out.parent
with tarfile.open(out/'cache.tar.gz','r:gz') as archive:
 for row in json.loads((out/'index.json').read_bytes()):
  path=root/row['path'];data=archive.extractfile(row['path']).read()
  assert hashlib.sha256(data).hexdigest()==row['sha256']
  path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  path.chmod(row['mode'])

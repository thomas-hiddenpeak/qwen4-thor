"""One start/three fixed requests, inspect implicit media cache regression only."""
import argparse,copy,json,signal,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import profile_acceptance as q
from tools.serve_service.package import read,require,save,sha
W=Path(__file__).resolve().parent
LIMITS=dict(starts=1,chats=3,controls=1000,seconds=300)
def requests(media=True):
 original=read(W/'profiles-01/primary-media.request.json')
 original['include']=['message.output_text.logprobs'];original['top_logprobs']=3
 full=copy.deepcopy(original);full['prompt_cache_options']=dict(mode='explicit',ttl='30m')
 return dict(full=full,implicit_cold=original,implicit_warm=copy.deepcopy(original))
q.requests=requests;q.limits_for=lambda _profile:LIMITS
class Stage(q.Stage):
 success_status='COMPLETE_BOUNDED_DIAGNOSTIC_NOT_ACCEPTANCE'
 def business(self):
  results={label:self.request(label,body,'/v1/responses') for label,body in self.plan['requests'].items()}
  save(self.out/'diagnostic.json',dict(results=results,no_acceptance_claim=True,original_failure_preserved=True))
def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run']);p.add_argument('--plan',type=Path);p.add_argument('--output',type=Path)
 args=p.parse_args()
 if args.mode=='prepare':
  args.package=ROOT/'build/service';args.binary=W/'candidate-engine-01/q4t';args.candidate_build=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build';args.candidate_release=None;args.port=19069;args.capacity_config=None
  q.prepare(args);path=args.output/'plan.json';v=read(path);v['sources'][str(Path(__file__))]=sha(Path(__file__));v['sources'][str(W/'profiles-01/primary-media.request.json')]=sha(W/'profiles-01/primary-media.request.json');v['scope']=__doc__;v['planned']=dict(starts=1,requests=3,full_vs_implicit_cold_warm=True,performance_claim=False);save(path,v)
 else:
  def deadline(*_):raise TimeoutError('bounded diagnostic deadline')
  signal.signal(signal.SIGALRM,deadline);signal.setitimer(signal.ITIMER_REAL,260)
  with q.encrypted.foreground.base.lifecycle.child_subreaper():Stage(read(args.plan)).run()
if __name__=='__main__':main()

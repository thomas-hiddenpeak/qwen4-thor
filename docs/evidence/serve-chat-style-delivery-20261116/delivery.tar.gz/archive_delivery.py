"""Archive public delivery receipts without copying private state or payloads."""
import json
import re
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.serve_service.package import read, require, save, sha

W = Path(__file__).resolve().parent
OUT = ROOT / 'docs/evidence/serve-chat-style-delivery-20261116'
result = read(W / 'delivery-01/result.json')
current = result['publication']['current']
require(result['status'] == 'PASS_CHAT_STYLE_STREAM_DELIVERED' and
        result['publication']['revision'] == 158 and
        result['state'] == 'STOPPED' and result['new_gpu_starts'] == 0,
        'delivery not accepted')
for name, key in [('q4t', 'engine_binary_sha256'),
                  ('q4t.release.json', 'engine_release_sha256'),
                  ('service.release.json', 'service_release_sha256'),
                  ('service.acceptance.json', 'service_acceptance_sha256')]:
    require(sha(ROOT / 'build/.q4t-publication/current' / name) == current[key], 'default identity drift')

secrets = []
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'shared_secret', 'private_key', 'token') and isinstance(item, str) and len(item) >= 24:
                secrets.append(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)

for policy in ('build/service/engine/client-policy.json', 'build/service/gateway-policy.json'):
    collect(read(ROOT / policy))
files = [(p, 'delivery-01/' + p.name) for p in (W / 'delivery-01').iterdir()
         if p.is_file() and not p.is_symlink()]
files += [(p, 'publication-archive-01/' + p.name)
          for p in (W / 'publication-archive-01').iterdir()
          if p.is_file() and not p.is_symlink()]
for name in ('archive_delivery.py', 'deliver.py', 'run_delivery.py',
             'archive_generations.py', 'deliver_before_migration.py', 'publication-archive-prepared.json',
             'publication-archive-applied.json'):
    files.append((W / name, name))
for stem in ('delivery-prepare-01', 'delivery-prepare-02', 'delivery-run-01', 'publication-archive-01'):
    for extension in ('json', 'stdout', 'stderr'):
        files.append((W / (stem + '.' + extension), stem + '.' + extension))
for path, _ in files:
    raw = path.read_bytes()
    require(not any(secret in raw for secret in secrets), 'secret in public evidence')
    require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n', raw), 'private key in evidence')
OUT.mkdir()
with tarfile.open(OUT / 'delivery.tar.gz', 'w:gz') as archive:
    for path, name in sorted(files, key=lambda item: item[1]):
        archive.add(path, arcname=name, recursive=False)
(OUT / 'delivery-01').mkdir()
for name in ('result.json', 'plan.json', 'recovery-anchor.json'):
    (OUT / 'delivery-01' / name).write_bytes((W / 'delivery-01' / name).read_bytes())
save(OUT / 'acceptance.json', dict(
    status='ACCEPT_CHAT_STYLE_STREAM_DELIVERY', revision=158,
    current=current, commands=len(result['commands']), seconds=result['seconds'],
    new_gpu_starts=0, state='STOPPED',
    core_client_outer_state_preserved=True, profile_budget_preserved=True,
    retained_anchor_generation=result['retained_anchor_generation'],
    files=len(files), archive_sha256=sha(OUT / 'delivery.tar.gz'),
    secret_scan_matches=0, remaining_master_tasks_active=True))
(OUT / 'README.md').write_text(f'''# Chat 样式与流式合同可回退发行 rev158

默认引擎e0b34b43、正式服务包cba9f596，generation
{current['generation_sha256']}。
17项STOPPED交付检查通过，{result['seconds']:.3f}秒，0新增GPU：保留锚点、
正式发布、新恢复周期、实际整根回退再前进及默认健康检查。

完整effort/null/medium缺省、verbosity真实提示及默认stream obfuscation/
关闭选项已交付；模板和grammar统一none thinking边界。真实JSON/SSE、
多choice、一次实际文档工具/SHA续答通过，首次真实失败保留。主轻和
精确包版本回退已验证，仅profile迁移源新增明确effort枚举升级；四个原生程序及其他控制不变，
旧压力/监护证据复用。新正式包版本恢复重新短验通过。

逐命令core/client/outer字节保持，容量/Key/配额不变；主轻身份迁移保持
历史/预算/冷却/配置，版本新周期保留前驱。最终STOPPED，outer enabled
且累计0启动，GPU释放。rev150默认/状态备份及两个无活动引用generation
可恢复归档保留，包及证据未删除；密钥/私钥扫描0命中。

保留1b90a1bf为旧v12控制/当前引擎；自动恢复保留现代根，人工整根
回退旧入口无outer，不是独立旧引擎回退。PR31检查和实际合main待完成。
其他标准字段、Responses默认medium、媒体缓存/后端、客户端/资源和
冷启动等所有master任务继续，不宣称完整兼容、性能或长稳通过。
''')
print(json.dumps(dict(status='ACCEPT_DELIVERY', revision=158,
                      files=len(files), secret_scan_matches=0)))

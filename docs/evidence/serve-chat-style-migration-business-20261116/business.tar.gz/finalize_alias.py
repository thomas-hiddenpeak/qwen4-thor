"""Reconcile only argv path spelling; preserve raw rejection and all oracles."""
import copy
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
PLAN = WORK / 'retained-business-01/plan.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canonical(command, cwd):
    if len(command) != 6 or command[1] != '-B' or command[3:5] != ['run', '--plan']:
        raise ValueError('unexpected argv grammar')
    executable = shutil.which(command[0]) if '/' not in command[0] else command[0]
    if not executable:
        raise ValueError('missing executable')
    return [str(Path(executable).resolve(strict=True)), '-B',
        str((cwd / command[2]).resolve(strict=True)), 'run', '--plan',
        str((cwd / command[5]).resolve(strict=True))]

def review(plan, guard):
    expected, actual = plan['command'], guard['command']
    if canonical(actual, ROOT) != canonical(expected, ROOT):
        raise ValueError('command identity differs')
    driver = Path(expected[2])
    if sha(driver) != plan['sources'][str(driver.relative_to(ROOT))]:
        raise ValueError('frozen driver changed')
    wrapper = json.loads((WORK/'gpu-retained-business-01.json').read_bytes())
    suffix = wrapper['argv'][wrapper['argv'].index('--')+1:]
    if suffix != actual or not wrapper['default_unchanged'] or wrapper['exit_code'] != 0:
        raise ValueError('recorded invocation differs')
    return dict(status='PASS_ARGV_PATH_EQUIVALENCE', frozen_argv=expected,
        actual_argv=actual, canonical_argv=canonical(actual,ROOT),
        cwd=str(ROOT), cwd_source=str(WORK/'run.py'), cwd_source_sha256=sha(WORK/'run.py'),
        driver_sha256=sha(driver), plan_sha256=sha(PLAN),
        guard_sha256=sha(WORK/'retained-business-01/lease/exit.json'),
        wrapper_sha256=sha(WORK/'gpu-retained-business-01.json'),
        original_rejection=str(WORK/'finalize-retained-business-01.stderr'),
        runtime_or_oracle_changes=False, new_gpu_starts=0)

def main():
    plan=json.loads(PLAN.read_bytes())
    raw=WORK/'retained-business-01/lease/exit.json'
    guard=json.loads(raw.read_bytes())
    evidence=review(plan,guard)
    if sys.argv[1:] == ['--test']:
        count=0
        for index,value in [(0,'/usr/bin/bash'),(1,'-I'),
            (2,str(WORK/'run.py')),(3,'finalize'),(5,str(WORK/'freeze-version-01.json'))]:
            bad=copy.deepcopy(guard);bad['command'][index]=value
            try:review(plan,bad)
            except ValueError:count+=1
            else:raise AssertionError('different command accepted')
        print(json.dumps(dict(status='PASS_ARGV_REVIEW',positive=1,negative=count)))
        return
    target=WORK/'retained-business-01/argv-path-review.json'
    with target.open('x') as out:json.dump(evidence,out,indent=2);out.write('\n')
    original_hash=sha(raw)
    module=runpy.run_path(str(WORK/'media_version.py'))
    original=module['accepted_run']
    def accepted(p,r,g,q,e):
        if p!=plan or g!=guard:raise ValueError('review applies only to frozen original run')
        review(p,g)
        normalized=copy.deepcopy(g);normalized['command']=p['command']
        result=original(p,r,normalized,q,e)
        result['argv_path_review']=dict(path=str(target),sha256=sha(target))
        return result
    module['finalize'].__globals__['accepted_run']=accepted
    module['finalize'](PLAN)
    if sha(raw)!=original_hash:raise AssertionError('raw guard mutated')

if __name__=='__main__':main()

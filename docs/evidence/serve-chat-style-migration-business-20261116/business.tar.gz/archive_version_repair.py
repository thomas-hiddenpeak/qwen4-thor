import json,re,tarfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_service.package import read,save,sha,require
W=Path(__file__).resolve().parent;out=ROOT/'docs/evidence/serve-chat-style-migration-business-20261116';out.mkdir()
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for p in [ROOT/'build/service/engine/client-policy.json',ROOT/'build/service/gateway-policy.json']:
 collect(read(p))
files=[];decisions={}
for folder in ['retained-business-01','version-business-02']:
 work=W/folder;decision=read(work/'decision.json');business=read(work/'execution/business-final.json')
 require(business['actual_display_geometry'] and all(decision['actual_business']['postflight'].values()),'unfinished actual recovery')
 decisions[folder]=dict(decision=decision,business=business)
 for p in work.rglob('*'):
  if not p.is_file() or 'state' in p.relative_to(work).parts:continue
  files.append((p,folder+'/'+str(p.relative_to(work))))
 for n in ['decision.json','service-release.json']:
  target=out/folder/n;target.parent.mkdir(exist_ok=True);target.write_bytes((work/n).read_bytes())
for name in ['archive_version_repair.py','refresh_package.py','freeze-migration-01.json','media_version.py','test_media_version.py','freeze-version-01.json','deliver.py','run_delivery.py','archive_generations.py','finalize_alias.py']:
 files.append((W/name,name))
for stem in ['prepare-retained-business-01','gpu-retained-business-01','finalize-retained-business-01','finalize-retained-business-02','argv-review-cpu-01','prepare-version-business-02','gpu-version-business-02','finalize-version-business-02','prepare-package-02','sealed-package-02-cpu','sealed-package-02-cpu-repair']:
 for suffix in ['json','stdout','stderr']:files.append((W/(stem+'.'+suffix),stem+'.'+suffix))
for p,_ in files:
 raw=p.read_bytes();require(not any(x in raw for x in secrets),'secret in public evidence')
 require(not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',raw),'private key')
with tarfile.open(out/'business.tar.gz','w:gz') as tar:
 for p,n in sorted(files,key=lambda x:x[1]):tar.add(p,arcname=n)
save(out/'acceptance.json',dict(status='ACCEPT_CHAT_STYLE_MIGRATION_VERSION_COMPOSITION',phases=decisions,files=len(files),archive_sha256=sha(out/'business.tar.gz'),secret_scan_matches=0,engine_binary_sha256='e0b34b43a61054b29304b9907d7d8bd0df901133403fe8c2cda7f2395073cc8f',default_unchanged=True,delivery_pending=True,remaining_master_tasks_active=True))
(out/'README.md').write_text(f'''# Chat 样式候选精确包及版本回退业务通过

2026-11-16，保留包1b90a1bf独立1启动/2生成，正式cba9f596实际
2启动/4生成/1探测。生成数含启动自检，均在冻结上限内。严格租约
分别 {decisions['retained-business-01']['decision']['actual_business']['strict_lease_seconds']:.3f}/
{decisions['version-business-02']['decision']['actual_business']['strict_lease_seconds']:.3f} 秒；NVML
{decisions['retained-business-01']['decision']['actual_business']['nvml_queries']}/
{decisions['version-business-02']['decision']['actual_business']['nvml_queries']} 项均正常。

两侧实际视频角点/布局正确，只有自有网关注入一次致命故障；保留
Guardian，按已验保留版本换代。冻结视频历史SSE续答、媒体/MCP/embedding、
Chat medium缺省及padding能力保留。持久STOPPED、进程/端口/锁清理通过。

首次保留包最终核验因命令相对/绝对路径字符串不同拒绝；原记录未改。
补充审计证明相同解释器/驱动/计划，参数和冻结来源相同，并有1正向及
5负控CPU。归一化只用于这次已记录调用，原环境/业务判定保持；0追加GPU。

正式cba9f596只更新profile_migration.py的一处已审查effort集合规则，
精确e0b34b43引擎/主轻资格及保留1b90a1bf复用，新正式包重新完成版本
短验。一次sealed CPU调用也因相对路径断言失败；改为绝对路径后原
断言通过，失败记录保留，生产源不变。

当前e0b34b43引擎与旧v12控制组成回退包，不是独立旧引擎回退。
自动恢复保留现代根，人工整根回退旧入口无outer；该缺口仍须实现。
其余控制/四个原生程序未改，RAM压力/外层监护按原身份复用；没有
性能/完整质量/长稳结论。原始记录及驱动归档，私有状态/Key不公开。
rev150保持，继续可回退发布和PR31实际合main，全部master继续。
''')
print(json.dumps(dict(status='ACCEPT_VERSION_COMPOSITION',files=len(files),secret_scan_matches=0)))

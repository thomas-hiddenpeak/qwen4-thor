import hashlib,json,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;C=W/'assets-cpu-01';O=R/'docs/evidence/serve-speaker-service-assets-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(C/'plan.json');r=read(C/'result.json');g=read(C/'lease/exit.json');launch=read(C/'launch.json')
assert r['status']=='PASS_CPU_PENDING_LEASE' and r['returncode']==0 and r['tests']==12 and r['seconds']<=180
assert launch['returncode']==0 and g['status']=='COMPLETED' and g['child_returncode']==0 and g['command']==p['command']
assert g['compute_backend']=='nvml' and g['lease_inherited_by_child'] and not g['external_lease']
# Only the public host target's unused loader object was removed after testing.
# The actual opt-in model-asset test target and tested source remain unchanged.
host=R/'cmake/HostTestSources.cmake';old=host.read_text().replace('  ${CMAKE_CURRENT_LIST_DIR}/../src/server/speaker_service.cpp\n','  ${CMAKE_CURRENT_LIST_DIR}/../src/server/speaker_assets.cpp\n  ${CMAKE_CURRENT_LIST_DIR}/../src/server/speaker_service.cpp\n',1)
(C/'host-sources-tested.cmake').write_text(old)
assert sha(C/'host-sources-tested.cmake')==p['identities'][str(host)]
for path,digest in p['identities'].items():
 assert sha(C/'host-sources-tested.cmake' if path==str(host) else Path(path))==digest,path
for path,digest in read(W/'component-01/plan.json')['protected'].items():assert sha(R/path)==digest
for path in ['assets-runtime-build-01/result.json','assets-public-build-02/result.json']:
 assert read(W/path)['returncode']==0
nvml=[json.loads(l) for l in (C/'lease/nvml-queries.jsonl').read_text().splitlines()];assert nvml and all(q['status']=='OK' for q in nvml)
events=[json.loads(l) for l in (C/'lease/events.jsonl').read_text().splitlines()]
assert events[0]['event']=='lease_acquired' and events[-1]['event']=='lease_released' and events[-1]['status']=='COMPLETED'
assert all(not e.get('conflicts') and not e.get('unreadable_processes') for e in events)
assert all(not Path('/proc',str(e['child_pid'])).exists() for e in events if e['event']=='child_started')
assert not list((C/'tmp').iterdir())
files=[Path(__file__).resolve(),W/'run_assets_cpu.py']
for name in ['assets-build-01','assets-runtime-build-01','assets-public-build-01','assets-public-build-02','assets-cpu-01']:
 files += [f for f in (W/name).rglob('*') if f.is_file()]
O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for f in sorted(set(files)):archive.add(f,arcname=str(f.relative_to(W)),recursive=False)
a=dict(status='ACCEPT_SPEAKER_ASSET_RESOURCE_HEALTH_CPU',tests=12,seconds=r['seconds'],gpu_model_loads=0,http_requests=0,strict_lease=True,nvml_ok=len(nvml),cleanup_complete=True,default_revision=286,defaults_unchanged=True,actual_fixed_weights_read_only=True,original_public_link_failure_preserved=True,public_target_only_fix_after_cpu=True,affected_optin_target_unchanged=True,archive_sha256=sha(O/'records.tar.gz'),speaker_http_delivered=False,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# Speaker独立资产、资源与健康（2026-11-18）

12项CPU/{r['seconds']:.3f}秒通过，0GPU模型加载/0HTTP。实际83MB权重
经原隔离worker读取，按已有完整资产测试约定持严格租约，{len(nvml)}次NVML
正常，自有worker和租约清理。metadata不打开FIFO权重；坏哈希、
错误profile/符号链接、取消/超时/预算、worker坏协议及未回收占槽
均通过。两项原ASR保护通过；普通失败只投影speaker降级，真正
设备故障保持sticky共享保护。此处CPU状态验证不替代实际服务短验。

预算覆盖10秒已知参考，即使滑窗配置更短；工作区/宿主暂存/原始
文件页与设备副本均计入统一RAM估计，实际服务总量仍须合并各owner。
必要运行时与公开host目标构建零警告。首次公开host目标误挂了不在
该目标依赖内的资产loader，链接失败保留；移除多余对象后构建通过。
实际loader保留在运行时与已验独立资产目标，未删除能力/测试。
此CMake单行整理不影响12项测试；原测试时文件按SHA保留，不改原计划。

默认rev286保持。原ECAPA数值已验复用；继续实际切换/参考/聚类、
JSON/SSE/SDK和原生恢复/交付，全部master active。
''')
intro=f'''[Speaker资产/资源/健康12CPU通过](evidence/serve-speaker-service-assets-20261118/README.md)
（{r['seconds']:.3f}秒、0GPU模型/0HTTP）；固定权重读取、隔离/取消/预算、
原ASR保护及设备状态通过。运行时/公开host零警告构建；原公开目标
误挂loader的链接失败保留，依赖修正未删能力。继续真实分段/参考/
API/恢复交付与全部master，默认rev286不变。

'''
pth=R/'docs/STATUS.md';pth.write_text(pth.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
pth=R/'docs/log/2026-11-18.md';s=pth.read_text();h,b=s.split('\n',1);pth.write_text(h+f'''\n\n## Speaker独立资产/资源/健康12项通过（2026-11-18）

12CPU/{r['seconds']:.3f}秒、0GPU/HTTP，固定实际权重只读、取消/坏资产/
worker和预算隔离、原ASR保护/真实设备状态均通过。运行时构建零警告；
公开host误挂loader链接失败保留，移除多余对象后通过，实际loader
及独立验证目标保留，已过12项不重复运行。原因：辅助失能须不拖
健康核心，资源要覆盖参考音频。下一步真实分段/匹配/API/恢复交付，
全部master继续。[证据](../evidence/serve-speaker-service-assets-20261118/README.md)。\n'''+b)
print(json.dumps(a))

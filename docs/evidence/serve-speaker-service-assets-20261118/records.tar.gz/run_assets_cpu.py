import argparse,json,os,subprocess,time,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args();o=args.output
plan=json.loads((o/'plan.json').read_text());assert os.environ.get('Q4T_MANAGED_LEASE_FD')
for path,digest in plan['identities'].items():assert sha(Path(path))==digest
assert not (o/'result.json').exists();t=time.monotonic()
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',Q4T_SPEAKER_ASSETS=plan['speaker_assets'],Q4T_ASR_ASSETS=plan['asr_assets'],Q4T_TEST_OUTPUT_DIR=str(o/'tmp'),TMPDIR=str(o/'tmp'));(o/'tmp').mkdir()
with (o/'tests.log').open('w') as f:rc=subprocess.run(plan['tests_command'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,pass_fds=(int(os.environ['Q4T_MANAGED_LEASE_FD']),),timeout=180).returncode
result=dict(status='PASS_CPU_PENDING_LEASE' if rc==0 else 'FAILED',returncode=rc,seconds=time.monotonic()-t,gpu_model_loads=0,http_requests=0,tests=12);(o/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(rc)

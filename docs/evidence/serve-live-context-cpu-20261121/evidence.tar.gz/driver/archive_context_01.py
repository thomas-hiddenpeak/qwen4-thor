"""Archive the frozen Live client context/delegation and affected scheduling group."""
import hashlib,importlib.util,io,json,subprocess,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-live-context-cpu-20261121'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
result=read(W/'context-cpu-01/result.json');plan=read(W/'context-cpu-01/plan.json')
assert result['status']=='PASS' and result['sources_unchanged'] and result['protected_unchanged']
spec=importlib.util.spec_from_file_location('inventory',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=R/'tools/serve_audit/inventory.json';inventory=read(p);actual=m.current_surface(R)
expected={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','include/q4t/server/live_frontend.h','src/server/live_frontend.cpp','include/q4t/server/live_client_context.h','src/server/live_client_context.cpp'}
diff={n for n,h in actual['sources_sha256'].items() if inventory['sources_sha256'].get(n)!=h}
if not diff:
 assert set(read(W/'context-inventory-before.json')['changed_sources'])==expected
 assert not m.check(inventory,actual)
 assert set(inventory['live_context_review_20261121']['sources'])==expected
 assert (W/'context-inventory-reviewed.json').read_text().strip()
else:
 save(W/'context-inventory-before.json',dict(changed_sources=sorted(diff),errors=m.check(inventory,actual)));assert diff==expected,(diff,expected)
 # Reviewed: native private tool finite-result and session ownership proof;
 # handoff receipt means created, never external task success. Actual tokenizer
 # binding required; frontend context/response queue atomic; metadata-only
 # publication and delayed acknowledgements are bounded, cancellable, no replay.
 for n in sorted(expected):inventory['sources_sha256'][n]=actual['sources_sha256'][n]
 inventory['live_context_review_20261121']=dict(sources=sorted(expected),evidence='docs/evidence/serve-live-context-cpu-20261121/README.md',status='CPU verified client context/delegation with actual native frontend workers and controlled model/tokenizer callbacks; actual model/route binding pending',no_route_accepted=True)
 save(p,inventory)
 r=subprocess.run(['python3','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (W/'context-inventory-reviewed.json').write_text(r.stdout);assert r.returncode==0,r.stdout
files={}
for folder in ('context-plan-01','context-cpu-01'):
 for p in sorted((W/folder).iterdir()):assert p.is_file();files[folder+'/'+p.name]=p.read_bytes()
for name in ('context_cpu_01.py','archive_context_01.py','context-inventory-before.json','context-inventory-reviewed.json'):files['driver/'+name]=(W/name).read_bytes()
for n,h in plan['sources'].items():
 raw=(R/n).read_bytes();assert sha(raw)==h,n;files['accepted/'+n]=raw
assert not O.exists();O.mkdir();index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,raw in sorted(files.items()):
  index[n]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(raw),0o600,0;t.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
result.update(status='PASS_NATIVE_LIVE_CLIENT_CONTEXT_CPU_PREPARATION',distinct_tests=13,new_tests=10,direct_existing_tests=3,inventory_reviewed_sources=6,inventory_mutation_checks=22,real_model_business_accepted=False,new_gpu_starts=0,default_revision=426,default_changed=False,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('commands','command')}))

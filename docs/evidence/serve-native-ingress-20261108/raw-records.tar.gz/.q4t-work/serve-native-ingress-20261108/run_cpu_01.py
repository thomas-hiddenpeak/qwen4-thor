from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
output = stage/'cpu-01'
output.mkdir(mode=0o700)
build = stage/'host-build'
ingress = build/'q4t-ingress'
nginx = root/'.q4t-work/serve-recovery-b2-20261108/package-attempt-02/bundle/bin/nginx'
changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines())
sources = {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(changed)}
reader_names = re.findall(r'Q4T_TEST\((\w+)\)', (root/'tests/server_http_request_test.cpp').read_text())
required = output/'http-reader-required.txt'
required.write_text('\n'.join(reader_names)+'\n')
commands = [
    ('http-reader', [str(build/'q4t_host_tests'), '--required-list', str(required)]),
    ('native-ingress', [sys.executable, '-B', 'tools/serve_recovery/test_native_ingress.py', '--ingress', str(ingress), '-v']),
    ('native-admission', [sys.executable, '-B', 'tools/serve_recovery/test_native_admission.py', '--ingress', str(ingress), '-v']),
    ('native-bundle', [sys.executable, '-B', 'tools/serve_recovery/test_native_bundle.py', '-v']),
    ('gateway-policy', [sys.executable, '-B', 'tools/serve_recovery/test_gateway.py', '-v']),
    ('production', [sys.executable, '-B', 'tools/serve_recovery/test_production.py', '-v']),
    ('legacy-nginx', [sys.executable, '-B', 'tools/serve_recovery/test_gateway_nginx.py', '--nginx', str(nginx), '-v']),
    ('optional-proxy', [sys.executable, '-B', 'tools/serve_recovery/test_native_proxy.py', '--ingress', str(ingress), '--nginx', str(nginx), '-v']),
    ('source-inventory', [sys.executable, '-B', 'tools/serve_audit/check_inventory.py', '--self-check']),
    ('diff', ['git', 'diff', '--check']),
    ('dynamic-dependencies', ['readelf', '-d', str(ingress)]),
]
result = dict(cpu_only=True, gpu_starts=0, real_nvml_queries=0, sources=sources,
              binary_sha256=hashlib.sha256(ingress.read_bytes()).hexdigest(),
              reader_required=len(reader_names), results=[])
for name in changed:
    if name.endswith('.py'):
        compile((root/name).read_text(), name, 'exec')
result['syntax_ok'] = True
for label, args in commands:
    directory = output/label
    directory.mkdir(mode=0o700)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
               Q4T_TEST_OUTPUT_DIR=str(directory), TMPDIR=str(directory))
    started = time.monotonic()
    timed_out = False
    with (directory/'run.log').open('xb') as log:
        process = subprocess.Popen(args, cwd=root, env=env, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            status = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            status = 124
    text = (directory/'run.log').read_text(errors='replace')
    row = dict(label=label, command=args, exit_code=status, timeout=timed_out,
               seconds=time.monotonic()-started)
    result['results'].append(row)
    print(json.dumps(row), flush=True)
    if status:
        print(text[-4500:], flush=True)
    (output/'result.json').write_text(json.dumps(result, indent=2)+'\n')
result['source_unchanged'] = all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
                               for name, digest in sources.items())
dependencies = (output/'dynamic-dependencies/run.log').read_text()
result['dependencies'] = re.findall(r'Shared library: \[([^]]+)\]', dependencies)
result['no_optional_link_dependencies'] = not any(
    any(word in name.lower() for word in ('cuda', 'nvml', 'ssl', 'python', 'nginx'))
    for name in result['dependencies'])
result['passed'] = (result['source_unchanged'] and result['no_optional_link_dependencies'] and
                    all(row['exit_code']==0 for row in result['results']))
(output/'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ('passed', 'source_unchanged', 'dependencies')}), flush=True)
sys.exit(0 if result['passed'] else 1)

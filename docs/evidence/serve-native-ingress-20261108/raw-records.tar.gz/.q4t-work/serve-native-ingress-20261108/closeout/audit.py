"""Offline review of the native entrypoint acceptance; no model/GPU queries."""
from dataclasses import asdict
import fcntl
import hashlib
import io
import json
from pathlib import Path
import socket
import subprocess
import sys

ROOT = Path('/home/rm01/models/dev/qwen4-thor')
WORK = ROOT/'.q4t-work/serve-native-ingress-20261108'
RUN = WORK/'business-attempt-01'
EXEC = RUN/'execution'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools.examples import chat_client
from tools.serve_recovery import bundle, journal

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]

receipt = read(WORK/'package-attempt-01/receipt.json')
package = Path(receipt['package'])
manifest = bundle.verify(package, receipt['manifest_sha256'])
assert manifest['version'] == 2 and manifest['ingress_mode'] == 'native'
assert not (package/'bin/nginx').exists()
assert {p.name for p in (package/'bin').iterdir()} == {
    'q4t', 'q4t-ingress', 'q4t-guardian', 'q4t-cuda-probe'}
for name in bundle.SOURCES:
    assert sha(ROOT/name) == sha(package/'source'/name), name
native = read(package/'native-build.json')
for name, digest in native['source_files'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in native['build_record_sha256'].items():
    assert sha(name) == digest, name
assert sha(ROOT/'build/q4t') == receipt['engine_binary_sha256']
assert sha(ROOT/'build/q4t.release.json') == sha(package/'engine/q4t.release.json')
cpu = read(WORK/'cpu-01/result.json')
assert cpu['passed'] and cpu['source_unchanged'] and cpu['no_optional_link_dependencies']
assert all(row['exit_code'] == 0 for row in read(WORK/'guardian-cpu-01/result.json'))
assert read(WORK/'peer-fix-01/negative.json')['exit_code'] == 1
assert '200 != 403' in (WORK/'peer-fix-01/negative.log').read_text()
peer = read(WORK/'peer-fix-01/result.json')
assert peer['exit_code'] == 0 and peer['binary_sha256'] == native['ingress_sha256']
assert peer['source_sha256'] == native['source_files']['src/service/ingress_main.cpp']
assert 'Ran 17 tests' in (WORK/'peer-fix-01/run.log').read_text()
assert 'Ran 8 tests' in (WORK/'acceptance-cpu-01/run.log').read_text()
assert (WORK/'acceptance-cpu-01/run.log').read_text().rstrip().endswith('OK')

plan, result, outer = (read(path) for path in
    (RUN/'plan.json', EXEC/'result.json', RUN/'lease/exit.json'))
assert result['status'] == 'PASS_BOUNDED_RECOVERY_BUSINESS'
assert result['failure'] is None and result['cleanup_failure'] is None
assert outer['status'] == 'COMPLETED' and outer['child_returncode'] == 0
assert outer['lease_inherited_by_child'] and outer['compute_backend'] == 'nvml'
assert plan['package'] == result['package'] == receipt
assert plan['ingress_mode'] == 'native' and plan['scenario'] == 'full_recovery'
assert plan['limits'] == dict(starts=4, chats=20, probes=1, controls=10000, seconds=1800)
assert read(EXEC/'counts.json') == result['budget']
counts = result['budget']['counts']
assert (counts['starts'], counts['chats'], counts['probes']) == (3, 18, 1)
assert len(result['models']) == 3
for kind in ('starts', 'chats', 'probes'):
    events = [e for e in result['budget']['events'] if e['kind'] == kind]
    assert [e['ordinal'] for e in events] == list(range(1, counts[kind]+1))
queries, events = rows(RUN/'lease/nvml-queries.jsonl'), rows(RUN/'lease/events.jsonl')
assert queries and all(q['status'] == 'OK' for q in queries) and not queries[-1]['pids']
assert not any(e.get('conflicts') or e.get('event') == 'environment_abort' for e in events)
acquired = [e for e in events if e['event'] == 'lease_acquired']
assert len(acquired) == 1
lease_seconds = outer['finished']['monotonic']-acquired[0]['monotonic']
assert lease_seconds < 1800 and result['seconds'] < 1800
for row in plan['protected']:
    assert sha(row['path']) == row['sha256']
references = [plan['source_commit']+':'+name for name in plan['sources']]
stream = io.BytesIO(subprocess.check_output(['git', 'cat-file', '--batch'],
    input=('\n'.join(references)+'\n').encode(), cwd=ROOT))
for name, digest in plan['sources'].items():
    header = stream.readline().split()
    assert header[1] == b'blob', name
    data = stream.read(int(header[2])); assert stream.read(1) == b'\n'
    assert hashlib.sha256(data).hexdigest() == digest == sha(ROOT/name), name
assert not stream.read()

reparse = []
for path in sorted(EXEC.glob('*-response.json')):
    response = read(path)
    if 'self-check' in path.name:
        assert response['http_status'] == 200
        parsed = chat_client.read_json(io.BytesIO(response['body'].encode()))
        assert parsed.finish_reason == 'stop' and json.loads(parsed.message['content']) == {'ok': True}
        reparse.append(dict(label=path.stem, quality='self-check'))
        continue
    label = path.name.removesuffix('-response.json')
    raw = (EXEC/(label+'-wire.bin')).read_bytes()
    if response['status'] != 200:
        assert json.loads(raw) == response['value']
        reparse.append(dict(label=label, status=response['status']))
        continue
    request = read(EXEC/(label+'-request.json'))
    parse = chat_client.read_sse if request['stream'] else chat_client.read_json
    parsed = parse(io.BytesIO(raw))
    assert asdict(parsed) == response['value']
    assert parsed.id == request['request_id'] and parsed.model == request['model']
    if label.endswith(('-json', '-sse')):
        assert parsed.finish_reason == 'stop' and parsed.message['content'].strip() == '42'
    elif label.endswith('-tool-call'):
        calls = parsed.message['tool_calls']
        assert parsed.finish_reason == 'tool_calls' and len(calls) == 1
        assert calls[0]['function']['name'] == 'read_project_record'
        assert json.loads(calls[0]['function']['arguments']) == dict(path='docs/MODEL.md', start_line=1, line_count=16)
        tool = read(EXEC/(label.removesuffix('-call')+'-result.json'))
        assert tool['executions'] == 1 and tool['call_id'] == calls[0]['id'] and tool['result']['ok']
        assert tool['result']['source']['sha256'] == sha(ROOT/'docs/MODEL.md')
    elif label.endswith('-tool-final'):
        assert parsed.finish_reason == 'stop' and not parsed.message.get('tool_calls')
        assert '[docs/MODEL.md:L1-L16]' in parsed.message['content']
    else:
        raise AssertionError(label)
    reparse.append(dict(label=label, status=200, seconds=response['seconds']))
assert read(EXEC/'beta-minute-quota-response.json')['status'] == 429
first, second, third, rebound = (read(EXEC/n) for n in (
    'ready-1.json', 'ready-2.json', 'ready-3.json', 'gateway-recovered.json'))
assert first['guardian_pid'] == second['guardian_pid'] == third['guardian_pid'] == rebound['guardian_pid']
assert first['controller_pid'] == second['controller_pid'] != third['controller_pid'] == rebound['controller_pid']
assert first['gateway_pid'] == second['gateway_pid'] == third['gateway_pid'] != rebound['gateway_pid']
assert len({s['model_pid'] for s in (first, second, third)}) == 3
assert third['model_pid'] == rebound['model_pid']
assert second['probe_used_for_generation'] == 1 and third['controller_generation'] == 2
assert rebound['gateway_generation'] == 2
fault = read(EXEC/'fault-counts-1.json'); gap = read(EXEC/'auxiliary-gap.json')
assert fault['nvml_injected'] > 0 and fault['log_errors'] > 0 and fault['metrics_attempts'] == 0
assert gap['business_ready'] and gap['model_pid'] == first['model_pid']
assert gap['controller_health']['observation'] == 'UNKNOWN'
assert gap['controller_health']['reason'] == 'nvml_timeout'
assert read(EXEC/'interrupted-sse-result.json')['killed']
assert b'[DONE]' not in (EXEC/'interrupted-sse-wire.bin').read_bytes()
for role in ('model', 'controller'):
    assert read(EXEC/(role+'-recovery-503-response.json'))['status'] == 503
    assert read(EXEC/(role+'-recovery-503-unauthorized-response.json'))['status'] == 401
drains = {}
for generation in (2, 3):
    drain = read(EXEC/f'generation-{generation}-metrics.json')['observations']
    final = drain[-1]['values']
    assert final['q4t_requests_total'] == final['q4t_requests_success_total'] == 5
    assert final['q4t_seq_slots_free'] == final['q4t_seq_slots_total'] == 1
    assert final['q4t_structured_workers_started_total'] == final['q4t_structured_workers_reaped_total'] == 3
    drains[generation] = drain[-1]['monotonic']-drain[0]['monotonic']
    assert drains[generation] < 5
samples = rows(EXEC/'status.jsonl'); known = set(); recovery_seconds = {}
for sample in samples:
    assert not sample['business_ready'] or sample['quota_wait_ms'] == 0
    for role in ('guardian', 'controller', 'gateway', 'journal', 'model'):
        if sample[role+'_pid']:
            known.add((sample[role+'_pid'], sample[role+'_start_ticks']))
for role in ('model', 'controller', 'gateway'):
    start = read(EXEC/(role+'-exit-fault.json'))['monotonic']
    ready = next(s for s in samples if s['monotonic'] > start and s['business_ready'] and s[role+'_generation'] == 2)
    recovery_seconds[role] = ready['monotonic']-start
assert (RUN/'owned-process-observations-summary.json').is_file()
observed = [role for sample in rows(RUN/'owned-process-observations.jsonl')
            for role in sample['roles']]
native_pids = {row['pid'] for row in observed if Path(row['executable']).name == 'q4t-ingress'}
assert len(native_pids) == 2 and not any(Path(row['executable']).name == 'nginx' for row in observed)
for row in observed:
    known.add((row['pid'], row['start_ticks']))
    if Path(row['executable']).name == 'q4t-ingress':
        assert row['sha256'] == native['ingress_sha256']
for pid, ticks in known:
    try:
        assert journal.process_start(pid) != ticks, (pid, ticks)
    except (FileNotFoundError, ProcessLookupError):
        pass
stop, ledger = read(EXEC/'stop.json'), read(EXEC/'stopped-ledger.json')
assert stop['state'] == 'STOPPED' and stop['stop_durable'] and stop['cleanup_confirmed']
assert ledger['desired'] == 'STOPPED' and all(v is None for v in ledger['active'].values())
for port in (18161, 18162, 18163):
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', port))
with open(manifest['lock_path'], 'rb') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
accepted = dict(status='ACCEPT_BOUNDED_NATIVE_INGRESS', package=receipt, source_commit=plan['source_commit'],
    cpu_distinct=151, cpu_groups=dict(http_reader=10, native_ingress=17, admission_races=4,
        native_bundle=7, gateway_policy=14, production=22, legacy_nginx=6, optional_proxy=3,
        acceptance_driver=8, guardian_process=18, guardian_journal=7, guardian_lifecycle=35),
    counts=counts, seconds=result['seconds'], lease_seconds=lease_seconds, nvml_queries=len(queries),
    all_nvml_ok=True, source_entries_verified=len(plan['sources']),
    packaged_python_sources=len(bundle.SOURCES), native_build_sources=len(native['source_files']),
    responses=reparse, known_process_identities_retired=len(known), native_entrypoint_generations=len(native_pids),
    nginx_packaged=False, nginx_observed=False, observation_limit='Periodic process observations are not continuous tracing',
    lock_free=True, ports_free=[18161, 18162, 18163], final_compute_pids=[],
    recovery_seconds=recovery_seconds, grammar_drain_seconds=drains,
    negative_cidr_reproduction_preserved=True, all_business_checks_in_one_lease=True,
    engine_default_unchanged=True, performance_acceptance=False, long_stability_acceptance=False)
with (WORK/'closeout/result.json').open('x') as output:
    json.dump(accepted, output, indent=2, ensure_ascii=False); output.write('\n')
print(json.dumps({k:v for k,v in accepted.items() if k not in ('responses', 'package')}, ensure_ascii=False))

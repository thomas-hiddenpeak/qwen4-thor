"""Replace the unused local service alias with the accepted native bundle."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/home/rm01/models/dev/qwen4-thor')
WORK = ROOT/'.q4t-work/serve-native-ingress-20261108'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools.serve_recovery import bundle

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write('\n')

def sync(path):
    fd = os.open(path, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)

os.umask(0o077)
accepted = read(WORK/'closeout/result.json')
assert accepted['status'] == 'ACCEPT_BOUNDED_NATIVE_INGRESS'
receipt = accepted['package']; package = Path(receipt['package'])
manifest = bundle.verify(package, receipt['manifest_sha256'])
entry, metadata = ROOT/'build/service', ROOT/'build/service.release.json'
old_bytes = metadata.read_bytes(); old = json.loads(old_bytes)
assert old['manifest_sha256'] == '1d414218fbb108d1c1f1689fd3b42cfdab14f0ffaa12c1a81d86b3f8e760c472'
old_package, old_state = Path(old['package']), Path(old['state'])
assert entry.is_symlink() and entry.resolve() == old_package
old_target = os.readlink(entry)
bundle.verify(old_package, old['manifest_sha256'])
target = WORK/'delivery-attempt-01'; target.mkdir(mode=0o700)
rollback = target/'rollback'; rollback.mkdir(mode=0o700)
state = ROOT/'build/service-native-state'
assert not state.exists()
checks = []
def invoke(which, arguments, expected):
    result = subprocess.run([str(which/'bin/q4t'), 'service', *arguments],
        capture_output=True, text=True, timeout=10)
    row = dict(entry=str(which/'bin/q4t'), argv=arguments, exit_code=result.returncode,
               stdout=result.stdout, stderr=result.stderr)
    checks.append(row); save(target/f'entry-check-{len(checks)}.json', row)
    assert result.returncode == expected, row
    return result.stdout

# Serialize with all cooperative service launches; no CUDA or model is used.
with open(manifest['lock_path'], 'rb') as lease, open(old_state/'writer.lock', 'rb') as writer:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(writer, fcntl.LOCK_EX | fcntl.LOCK_NB)
    old_ledger = read(old_state/'ledger.json')['state']
    assert old_ledger['desired'] == 'STOPPED' and old_ledger['revision'] == 0
    assert not any(old_ledger['attempts'].values()) and not any(old_ledger['active'].values())
    assert not list((old_state/'runs').iterdir())
    old_status = json.loads(invoke(old_package, ['status', '--state', str(old_state)], 1))
    assert not old_status['live_control'] and old_status['state'] == 'UNKNOWN'
    preserved = []
    for source, name in ((metadata, 'service.release.json'),
                         (old_state/'ledger.json', 'unused-state-ledger.json'),
                         (old_state/'service.json', 'unused-state-descriptor.json')):
        dest = rollback/name; shutil.copy2(source, dest); dest.chmod(0o400)
        assert sha(source) == sha(dest)
        preserved.append(dict(path=str(source), rollback=str(dest), sha256=sha(dest)))
    for name in ('q4t', 'q4t.release.json'):
        assert sha(ROOT/'build'/name) == sha(old_package/'engine'/name)
        preserved.append(dict(path=str(ROOT/'build'/name), rollback=str(old_package/'engine'/name),
                              sha256=sha(ROOT/'build'/name)))
    save(rollback/'receipt.json', dict(previous_service_entry=old_target,
        previous_service_metadata=str(rollback/'service.release.json'),
        previous_state=str(old_state), previous_state_revision=0, previous_state_used=False,
        previous_manifest_sha256=old['manifest_sha256'], preserved=preserved,
        instructions='Stop the exact new state before rollback. Restore the known old symlink and metadata together; use its original STOPPED state. Keep both bundles and both ledgers. No recovery budget was reset: old state has revision 0 and has never launched.'))
    invoke(package, ['--help'], 0)
    initialized = json.loads(invoke(package, ['init', '--state', str(state)], 0))
    assert initialized['desired'] == 'STOPPED' and initialized['automatic_start'] is False
    status = json.loads(invoke(package, ['status', '--state', str(state)], 1))
    assert status['state'] == 'UNKNOWN' and not status['business_ready'] and not status['live_control']
    value = dict(version=2, profile='q4t-service-recovery-v2', ingress_mode='native',
        acceptance=accepted['status'], recovery_accepted=True,
        acceptance_record=str(WORK/'closeout/result.json'), acceptance_sha256=sha(WORK/'closeout/result.json'),
        package=str(package), manifest_sha256=receipt['manifest_sha256'],
        ingress_sha256=manifest['files']['bin/q4t-ingress'], nginx_required=False,
        engine_binary_sha256=receipt['engine_binary_sha256'], engine_release_sha256=sha(ROOT/'build/q4t.release.json'),
        entry=str(entry/'bin/q4t'), state=str(state), service_id=initialized['service_id'],
        initial_desired='STOPPED', automatically_started=False,
        listen=old['listen'], upstream=old['upstream'], operations=old['operations'], clients=old['clients'],
        scope='single-slot text/MTP, loopback, process resource mode; bounded native ingress and recovery only',
        rollback_receipt=str(rollback/'receipt.json'), rollback_sha256=sha(rollback/'receipt.json'),
        engine_default_replaced=False, gpu_starts_for_install=0, long_stability_accepted=False, tls_lan_accepted=False,
        dependencies=['q4t native entrypoint and Guardian', 'pinned Python control/journal/monitor runtime',
                      'CUDA/driver, model assets and system C/C++ libraries'],
        limitations=old['limitations'])
    new_metadata = metadata.with_name('service.release.installing.json')
    temporary = entry.with_name('service.installing')
    assert not temporary.exists() and not temporary.is_symlink() and not new_metadata.exists()
    save(new_metadata, value); sync(new_metadata)
    temporary.symlink_to(package, target_is_directory=True)
    assert entry.resolve() == old_package and metadata.read_bytes() == old_bytes
    changed = False
    try:
        os.replace(temporary, entry); changed = True
        os.replace(new_metadata, metadata); sync(entry.parent)
        assert entry.resolve() == package and read(metadata) == value
        bundle.verify(entry, receipt['manifest_sha256'])
    except BaseException:
        if changed:
            temporary.symlink_to(old_target, target_is_directory=True); os.replace(temporary, entry)
            new_metadata.write_bytes(old_bytes); sync(new_metadata); os.replace(new_metadata, metadata)
            sync(entry.parent)
        raise
    for row in preserved:
        assert sha(row['rollback']) == row['sha256']
        if row['path'] != str(metadata): assert sha(row['path']) == row['sha256']
    result = dict(status='DELIVERED_STOPPED', release=value, release_sha256=sha(metadata),
        initialized=initialized, checks=checks, old_state_untouched=True,
        engine_default_unchanged=True, model_starts=0, chats=0)
    save(target/'result.json', result)
print(json.dumps(dict(status=result['status'], entry=value['entry'], metadata=str(metadata),
    manifest_sha256=value['manifest_sha256'], state=str(state), live_service=False)))

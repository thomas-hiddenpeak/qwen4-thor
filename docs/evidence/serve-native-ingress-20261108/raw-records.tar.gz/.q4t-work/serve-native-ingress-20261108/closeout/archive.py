"""Archive selected immutable records, excluding runtime credentials/configs."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/rm01/models/dev/qwen4-thor')
WORK = ROOT/'.q4t-work/serve-native-ingress-20261108'
DEST = ROOT/'docs/evidence/serve-native-ingress-20261108'
DEST.mkdir(parents=True, exist_ok=True)
assert not list(DEST.iterdir()), 'refuse to overwrite evidence'
records = {}
def include(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    records[str(path.relative_to(ROOT))] = path.read_bytes()

for path in WORK.iterdir():
    if path.is_file() and path.suffix in ('.json', '.log', '.py'):
        include(path)
for name in ('cpu-01', 'guardian-cpu-01', 'acceptance-cpu-01', 'peer-fix-01', 'probe-build-01'):
    directory = WORK/name
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.json', '.log', '.txt'):
            include(path)
        elif path.is_dir() and name in ('cpu-01', 'guardian-cpu-01'):
            if (path/'run.log').exists(): include(path/'run.log')
native = json.loads((WORK/'native-build-02.json').read_text())
for path in native['build_records']: include(path)
run = WORK/'business-attempt-01'
for directory in (run, run/'execution', run/'lease'):
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.json', '.jsonl', '.log', '.bin'):
            include(path)
plan = json.loads((run/'plan.json').read_text())
for name in sorted(set(native['source_files']) | {
        'tools/serve_recovery/acceptance.py', 'tools/serve_recovery/test_acceptance.py',
        'tools/serve_recovery/native_ingress.py', 'tools/serve_recovery/bundle.py',
        'tools/serve_recovery/gateway_config.py', 'tools/serve_recovery/service.py',
        'tools/serve_recovery/test_native_ingress.py', 'tools/serve_recovery/test_native_admission.py',
        'tools/serve_recovery/test_native_bundle.py', 'tools/serve_recovery/test_native_proxy.py'}):
    records['source-snapshots/'+plan['source_commit']+'/'+name] = subprocess.check_output(
        ['git', 'show', plan['source_commit']+':'+name], cwd=ROOT)
for name in ('receipt.json', 'command.json', 'prepare.stdout', 'prepare.stderr',
             'acceptance-prepare.stdout', 'acceptance-prepare.stderr',
             'bundle/manifest.json', 'bundle/native-build.json', 'bundle/engine/manifest.json'):
    include(WORK/'package-attempt-01'/name)
for name in ('audit.py', 'audit.log', 'result.json', 'deliver.py', 'delivery.log', 'archive.py'):
    include(WORK/'closeout'/name)
for path in (WORK/'delivery-attempt-01').glob('*.json'): include(path)
include(WORK/'delivery-attempt-01/rollback/receipt.json')
include(WORK/'delivery-attempt-01/rollback/service.release.json')
include(ROOT/'build/service.release.json')

secrets = set()
def visit(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('api_key', 'gateway_token', 'token') and isinstance(item, str) and len(item) >= 16:
                secrets.add(item.encode())
            visit(item)
    elif isinstance(value, list):
        for item in value: visit(item)
for name in ('client-policy.json', 'gateway-policy.json', 'gateway.json', 'ingress.json'):
    for path in WORK.rglob(name):
        visit(json.loads(path.read_text()))
assert secrets
for name, data in records.items():
    assert not any(secret in data for secret in secrets), 'private credential in '+name
    assert not re.search(br'(?m)^-----BEGIN (?:.* )?PRIVATE KEY-----$', data), name

archive = DEST/'raw-records.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as output:
    for name, data in sorted(records.items()):
        info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0; info.mode = 0o444
        output.addfile(info, io.BytesIO(data))
manifest = dict(version=1, archive='raw-records.tar.gz',
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), count=len(records),
    records=[dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest())
             for name, data in sorted(records.items())],
    excluded=['API keys and internal generation credentials', 'private configs, ledger trees, model assets',
              'native executables and build trees except explicit build receipts'],
    known_credentials_scanned=len(secrets), negative_cidr_reproduction_preserved=True)
(DEST/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
(DEST/'result.json').write_bytes((WORK/'closeout/result.json').read_bytes())
(DEST/'delivery.json').write_bytes((WORK/'delivery-attempt-01/result.json').read_bytes())
with tarfile.open(archive) as preserved:
    for row in manifest['records']:
        data = preserved.extractfile(row['path']).read()
        assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps(dict(records=len(records), bytes=archive.stat().st_size,
    sha256=manifest['sha256'], known_credentials_excluded=len(secrets))))

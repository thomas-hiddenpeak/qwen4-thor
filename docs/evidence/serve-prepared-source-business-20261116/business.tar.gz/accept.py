"""One start/four creates: affected native prepared-source adapters."""
import argparse,base64,copy,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_responses import video_acceptance as video
from tools.serve_responses import file_integration_acceptance as files
from tools.serve_chat_storage import acceptance as chats
from tools.serve_service.package import read,save,sha,require
from tools.serve_protocol import build_contract as api
from jsonschema import Draft202012Validator
LIMITS=dict(starts=1,chats=4,controls=2000,seconds=600)
IMAGE='tests/fixtures/file_images/webp/lossless.webp'
DOCUMENT='docs/MODEL.md'
WORK=Path(__file__).resolve().parent

def source():return '\n'.join((ROOT/DOCUMENT).read_text().splitlines()[:3])+'\n'
def requests():
    pdf=files.requests()['pdf']
    image=copy.deepcopy(pdf);image.update(stream=True,stream_options=dict(include_usage=True))
    image['messages']=[dict(role='user',content=[dict(type='image_url',image_url=dict(url='data:image/webp;base64,'+base64.b64encode((ROOT/IMAGE).read_bytes()).decode(),detail='original')),dict(type='text',text='Inspect the supplied image. Is its appearance multicolor or monochrome? Return appearance as JSON.')])]
    image['response_format']['json_schema']=dict(name='image_appearance',strict=True,schema=video.base.closed(dict(appearance=dict(type='string',enum=['multicolor','monochrome']))))
    document=dict(model=video.foreground.MODEL,temperature=0,reasoning=dict(effort='none'),max_output_tokens=128,text=dict(format=dict(type='json_schema',name='project_title',strict=True,schema=video.base.closed(dict(title=dict(type='string'))))),input=[dict(role='user',content=[dict(type='input_file',filename='project-record.txt',file_data=base64.b64encode(source().encode()).decode()),dict(type='input_text',text='Return the title from the attached project record without its Markdown heading marker.')])])
    return dict(pdf=pdf,image=image,document=document,plain=video.foreground.requests()['chat'])

class Stage(video.Stage):
    limits=LIMITS;request_templates=staticmethod(requests)
    success_status='PASS_PREPARED_SOURCE_AFFECTED_BUSINESS'
    sdk_chat=chats.Stage.sdk_chat
    def post_control(self,label,path,body):
        self.budget('controls');status,raw=self.http(path,body,label=label)
        require(status==200,label+' failed');return json.loads(raw)
    def business(self):
        rows=self.plan['requests']
        preflight=self.post_control('pdf-preflight','/v1/chat/preflight',dict(request=rows['pdf']))
        pdf=self.sdk_chat('pdf-json','create',rows['pdf']);files.pdf_answer(pdf)
        require(preflight['prompt_tokens']==pdf['usage']['prompt_tokens'] and preflight['file_preparation']['pdf_pages_rasterized']==1,'PDF preflight/generation mismatch')
        image=self.sdk_chat('webp-sse','create',rows['image'])
        require(image['choices'][0]['finish_reason']=='stop' and json.loads(image['choices'][0]['message']['content'])==dict(appearance='multicolor'),'WebP perception differs')
        count=self.post_control('document-count','/v1/responses/input_tokens',files.tokens.count_request(rows['document']))
        doc=self.sdk('document-json','create',rows['document']);video.background.check_response(doc,'completed')
        require(json.loads(video.foreground.text(doc))==dict(title=source().splitlines()[0].removeprefix('# ')),'actual project title differs')
        require(count['input_tokens']==doc['usage']['input_tokens'],'document count/generation mismatch')
        plain=self.sdk_chat('ordinary-chat','create',rows['plain'])
        require(plain['choices'][0]['finish_reason']=='stop' and plain['choices'][0]['message']['content'].strip()=='42','ordinary same-PID Chat differs')
        self.drained('final')
        save(self.out/'business-summary.json',dict(starts=1,creates=4,pdf_number_and_color=True,pdf_preflight_parity=True,actual_webp_sse=True,stored_stream_parity=True,real_document_title=True,document_count_parity=True,same_model_pid=True,new_mcp_calls=0,full_quality_or_performance_claim=False))

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run']);args=p.parse_args();out=WORK/'business-01'
    if args.mode=='prepare':
        rows=requests()
        for name in ['pdf','image','plain']:Draft202012Validator(api.vision_schema() if name!='plain' else api.chat_schema()).validate(rows[name])
        require(not video.background.wire_errors(rows['document'],'response_create'),'document schema')
        options=argparse.Namespace(binary=ROOT/'.q4t-work/serve-video-group-timing-20261116/candidate-01/q4t',output=out,port=18186)
        video.background.prepare(options,rows=rows,limits=LIMITS,scope=__doc__)
        plan=read(out/'plan.json');plan['private_peer_port']=18188
        for f in [Path(__file__),ROOT/IMAGE,ROOT/DOCUMENT,ROOT/files.PDF]:plan['sources'][str(f.relative_to(ROOT))]=sha(f)
        plan['planned'].update(starts=1,creates=4,model_steps=4)
        plan['mutations']=['own isolated model/storage only; graceful cleanup; no model restarts or request retries']
        plan['derived_requests']=['unchanged accepted PDF question/oracle; real WebP image classification; project first-three-line source with no title answer in instructions; original plain Chat', 'Chat SSE storage GET is control only; actual preflight/count does not generate']
        save(out/'plan.json',plan)
    else:
        with video.base.lifecycle.child_subreaper():Stage(read(out/'plan.json')).run()
if __name__=='__main__':main()

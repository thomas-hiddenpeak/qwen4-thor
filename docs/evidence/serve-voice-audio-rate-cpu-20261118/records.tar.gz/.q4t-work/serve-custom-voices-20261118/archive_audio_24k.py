from pathlib import Path
import json,hashlib,tarfile,sys
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118';E=R/'docs/evidence/serve-voice-audio-rate-cpu-20261118'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
sys.path.insert(0,str(R));from tools.serve_audit.check_inventory import current_surface,check,mutation_checks
surface=current_surface(R);p=R/'tools/serve_audit/inventory.json';inv=read(p);changes={n:{'old':inv['sources_sha256'].get(n),'new':h} for n,h in surface['sources_sha256'].items() if inv['sources_sha256'].get(n)!=h}
expected={'include/q4t/server/file_audio.h','src/server/file_audio_protocol.h','src/server/file_audio.cpp','src/server/file_audio_worker.cpp'};assert set(changes)==expected,changes
review={'sources':changes,'scope':'Explicit 16/24 kHz CPU audio decode, same-ELF IPC magic updated for extended limits','contracts':['Existing default 16k samples and metadata semantics unchanged','24k derived directly from decoded original source, never from a forced 16k intermediate','actual output rate included in PCM and verified conversion identity','rational sample-duration admission, rounded nanosecond receipt cannot bypass limit','bounded verified system CPU libraries and owned isolated worker, no GPU discovery']}
(V/'audio-24k-source-review-01.json').write_text(json.dumps(review,indent=2)+'\n')
for n,d in changes.items():inv['sources_sha256'][n]=d['new']
inv['native_audio_output_rate_2026_11_18']={'state':'NATIVE_16_24K_CPU_QUALIFIED','evidence':['docs/evidence/serve-voice-audio-rate-cpu-20261118/README.md'],'reviewed_sources':sorted(changes),'voice_api_accepted':False};write(p,json.dumps(inv,ensure_ascii=False,indent=2)+'\n');assert not check(inv,surface);mutations=mutation_checks(inv,surface)
(V/'audio-24k-inventory-01.json').write_text(json.dumps({'inventory_current':True,'source_anchors':len(surface['sources_sha256']),'mutation_checks':mutations},indent=2)+'\n')
E.mkdir(exist_ok=False)
files={R/n for n in expected|{'tests/server_file_audio_test.cpp','tests/server_file_audio_rate_test.cpp','cmake/HostTestSources.cmake','tools/native_asr/codec_fixtures.py'}}
for folder in ['audio-24k-build-01','audio-24k-cpu-01']:
 files|={p for p in (V/folder).rglob('*') if p.is_file() and p.suffix in ('.json','.txt','.log','.f32')}
for name in ['audio-24k-plan-01.json','audio-24k-source-review-01.json','audio-24k-inventory-01.json','develop_audio_24k.py','build_audio_24k.py','run_audio_24k_cpu.py','archive_audio_24k.py']:files.add(V/name)
index={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}
with tarfile.open(E/'records.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
(E/'index.json').write_text(json.dumps(index,indent=2)+'\n');result=read(V/'audio-24k-cpu-01/result.json');result.update(state='NATIVE_16_24K_CPU_QUALIFIED',new_cases=8,direct_existing_cases=6,build=read(V/'audio-24k-build-01/result.json'),archive_sha256=sha(E/'records.tar.gz'),archive_files=len(index),voice_api_accepted=False,full_task_complete=False)
(E/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(E/'README.md').write_text('''# 原生24kHz声纹输入与16kHz ASR保护

8项新增、6项直接受影响旧合同全部通过，1.016秒；必要构建28.608秒，
零警告，0模型/GPU。复用既有只读合成音频夹具和独立解析器/worker。
[结果](result.json)、[身份](index.json)、[源码与原始记录](records.tar.gz)。

输出采样率由受信调用方显式选16/24kHz，默认16kHz保持。24kHz直接
从原始解码流经原有质量10滤波产生，逐值原生PCM、真实低频及11kHz
保真通过：440Hz振幅0.374999947，11kHz振幅0.149999942；后者排除
先丢弃8kHz以上成分再上采样的伪路径。44.1/8/48kHz来源转换保持
ceil样本数与相位，RMS最大8.033e-6，冻结门1e-4未更改。

时长回执是采样数/输出率向下取纳秒，但准入使用精确有理数界限；
一纳秒/一样本越界仍拒绝。实际采样率、元数据与PCM摘要绑定，不能
只改标签。FLAC/MP3实际转换、故障隔离、16k原逐值/相位/预算/取消
全部通过。私有IPC随limits布局更新magic，父子始终同一ELF，不混用
历史对象ABI；未增加依赖、GPU探测、视频或硬件解码范围。

自定义音色HTTP、实际授权短语/说话人匹配、新文本合成、旧包有状态
回退继续。默认rev316及五份发布身份不变，总目标仍active。
''')
note='''[24kHz声纹输入14项CPU通过](evidence/serve-voice-audio-rate-cpu-20261118/README.md)：
1.016秒，构建28.608秒零警告；0GPU、默认保持。原生PCM逐值、\n11kHz成分、非整数采样相位与精确时长边界通过，既有16kHz及\nworker失败隔离保持。继续真实授权验证、Base按需服务和音色ID\n合成新文本，持久对象旧包兼容仍须随发布闭合。\n\n'''
p=R/'docs/STATUS.md';s=p.read_text();write(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：原生24kHz音频与16kHz保护14项通过\n\n'+note+'复用原CPU codec隔离，没有引入新依赖；下一步按全部master继续\n实际服务接入与业务验收，不将采样率组件当作音色API完成。\n\n'+s.split('\n',1)[1].lstrip('\n'))
p=R/'docs/serve-master-goals-v2.json';d=read(p);d['native_tts_progress']['custom_voice']['audio_input']={'state':result['state'],'evidence':str((E/'README.md').relative_to(R/'docs')),'cpu_cases':14,'gpu_loads':0};write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':result['state'],'archive_files':len(index),'source_anchors':len(surface['sources_sha256']),'mutation_checks':mutations}))

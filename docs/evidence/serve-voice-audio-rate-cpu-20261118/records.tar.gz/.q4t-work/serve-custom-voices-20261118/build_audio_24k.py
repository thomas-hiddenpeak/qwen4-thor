from pathlib import Path
import json,re,subprocess,hashlib,time,shutil
R=Path.cwd();V=R/'.q4t-work/serve-custom-voices-20261118'
def write(p,s):
 t=p.with_suffix(p.suffix+'.edit');t.write_text(s);t.replace(p)
p=R/'cmake/HostTestSources.cmake';s=p.read_text();anchor='  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_file_audio_test.cpp';assert s.count(anchor)==1;write(p,s.replace(anchor,anchor+'\n  ${CMAKE_CURRENT_LIST_DIR}/../tests/server_file_audio_rate_test.cpp'))
files=['include/q4t/server/file_audio.h','src/server/file_audio.cpp','src/server/file_audio_protocol.h','src/server/file_audio_worker.cpp','tests/server_file_audio_rate_test.cpp']
for n in files:
 p=R/n;r=subprocess.run(['clang-format',str(p)],capture_output=True,check=True);t=p.with_suffix(p.suffix+'.edit');t.write_bytes(r.stdout);t.replace(p)
required=re.findall(r'Q4T_TEST\(\s*([a-z0-9_]+)\s*\)',(R/'tests/server_file_audio_rate_test.cpp').read_text())+['file_audio_pcm16_wave_matches_every_source_sample','file_audio_pcm24_resamples_and_averages_channels_without_aliasing','file_audio_noninteger_and_upsample_keep_phase_and_length','file_audio_actual_source_decode_and_output_budgets','file_audio_hang_crash_inflight_cancel_have_bounded_cleanup','file_audio_conversion_rejects_source_pcm_and_policy_tampering']
assert len(required)==14
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan={'scope':'Explicit native 24k audio decode for Base conditions, existing 16k ASR default preserved','cases':14,'new_cases':8,'direct_existing_cases':6,'required':required,'seconds':120,'model_loads':0,'gpu_actions':0,'disk_reserve_bytes':256<<20,'max_artifact_bytes':4<<20,'source_sha256':{n:sha(R/n) for n in files+['tests/server_file_audio_test.cpp']},'numeric_contracts':{'native_24k':'PCM16 every source sample exact','voice_band':'440Hz amplitude 0.375+-0.005 and 11kHz 0.12..0.18 from 48k original','resample':'source ceil length and phase RMS < 0.0001 for 44.1k, 8k and 48k','duration':'floor nanosecond receipt; exact rational duration admitted separately'},'runtime_api_pending':True}
(V/'audio-24k-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
note='''24kHz原生音频输入已接入开发，ASR默认16kHz保持；显式输出率、\n实际采样率身份和精确有理数时长预算一起校验。冻结8新增+6直接\n受影响CPU/120秒、0模型/GPU，含11kHz保真、非整数采样、边界与\nworker隔离；通过后继续真实音色登记后端，不改变默认程序。\n\n'''
p=R/'docs/STATUS.md';s=p.read_text();write(p,s.replace('## 正在推进\n\n','## 正在推进\n\n'+note,1))
p=R/'docs/log/2026-11-18.md';s=p.read_text();write(p,s.split('\n',1)[0]+'\n\n## 2026-11-18：自定义声纹原生24kHz输入开发\n\n'+note+'持久登记检查点058bf839已推送；此处解决原始声纹采样率，避免\n丢弃高频后再上采样。下一步冻结CPU和真实授权/新文本HTTP。\n\n'+s.split('\n',1)[1].lstrip('\n'))
O=V/'audio-24k-build-01';O.mkdir(exist_ok=False);assert shutil.disk_usage(R).free>=256<<20
cmd=['cmake','--build','.q4t-work/serve-file-search-20261112/host','--target','q4t_host_tests','--parallel','4'];start=time.monotonic()
with (O/'build.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=360)
result={'status':'PASS_BUILD_ONLY' if r.returncode==0 else 'FAIL_BUILD','seconds':time.monotonic()-start,'command':cmd,'returncode':r.returncode,'warnings':(O/'build.log').read_text().count('warning:')}
if r.returncode==0:result['binary_sha256']=sha(R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests')
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)

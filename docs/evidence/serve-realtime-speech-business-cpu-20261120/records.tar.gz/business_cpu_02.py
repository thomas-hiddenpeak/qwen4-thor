from pathlib import Path
import hashlib,json,os,re,subprocess,time,traceback
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'business-cpu-02';P=W/'business-cpu-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
assert not O.exists()
old=json.loads((P/'result.json').read_text());assert old['status']=='FAILED' and all(v['exit_code']==0 for v in old['commands'])
assert old['error'].endswith('AssertionError\n') and "'# pass 5'" in old['error']
assert re.search(r'Ran 11 tests in [\d.]+s\s+OK', (P/'0.stderr').read_text())
node=(P/'1.stdout').read_text();assert re.search(r'ℹ tests 5\n',node) and re.search(r'ℹ pass 5\nℹ fail 0\n',node)
audit=json.loads((P/'3.stdout').read_text());assert audit['inventory_current'] and audit['mutation_checks']==20
O.mkdir(mode=0o700)
cmd=['python3','-B','-m','unittest','tools.serve_realtime.test_speech_acceptance.SpeechEvidence.test_auxiliary_release_is_healthy_but_failures_are_not_hidden','-v']
files=['tools/serve_realtime/speech_acceptance.py','tools/serve_realtime/speech_checks.py','tools/serve_realtime/speech_sdk.mjs','tools/serve_realtime/test_speech_acceptance.py']
save(O/'plan.json',dict(scope='One new health-boundary check, source-reviewed unchanged receipt checks reuse 11 Python + 5 Node passes. Original failed ASCII-only report assertion is preserved; validate Unicode Node footer and all zero exits offline. No rerun of accepted tests.',seconds=120,gpu_starts=0,command=cmd,sources={n:sha(R/n) for n in files},original={str(p):sha(p) for p in P.iterdir() if p.is_file()},reused_tests=16,reused_source_counterexamples=20))
start=time.monotonic()
with (O/'stdout').open('w') as out,(O/'stderr').open('w') as err:
 run=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=120,env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O/'fixtures')))
result=dict(status='PASS' if run.returncode==0 else 'FAILED',seconds=time.monotonic()-start,exit_code=run.returncode,new_tests=1,reused_tests=16,total_tests=17,source_counterexamples=20,original_report_failure_preserved=True,gpu_starts=0)
save(O/'result.json',result);print(json.dumps(result));assert run.returncode==0

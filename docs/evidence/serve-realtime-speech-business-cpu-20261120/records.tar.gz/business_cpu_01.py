from pathlib import Path
import ast,hashlib,json,os,subprocess,time,traceback
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;O=W/'business-cpu-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
scope=json.loads((W/'business-scope-01.json').read_text());assert not O.exists()
for n,h in scope['sources'].items():
 assert sha(R/n)==h,n
 if n.endswith('.py'):ast.parse((R/n).read_text())
O.mkdir(mode=0o700)
commands=[['python3','-B','-m','unittest','tools.serve_realtime.test_speech_acceptance','-v'],['node','--test','tools/serve_realtime/conversation_checks.test.mjs'],['node','--check','tools/serve_realtime/speech_sdk.mjs'],['python3','-B','tools/serve_audit/check_inventory.py','--self-check']]
protected={str(R/n):sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service.release.json','build/service-native-state/ledger.json']}
save(O/'plan.json',dict(scope=scope,commands=commands,protected=protected))
start=time.monotonic();rows=[]
try:
 for i,cmd in enumerate(commands):
  with (O/f'{i}.stdout').open('w') as out,(O/f'{i}.stderr').open('w') as err:
   run=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=120-(time.monotonic()-start),env=dict(os.environ,Q4T_TEST_OUTPUT_DIR=str(O/'fixtures')))
  rows.append(dict(command=cmd,exit_code=run.returncode));assert run.returncode==0,cmd
 assert 'Ran 11 tests' in (O/'0.stderr').read_text()
 assert '# pass 5' in (O/'1.stdout').read_text()
 audit=json.loads((O/'3.stdout').read_text());assert audit['inventory_current'] and audit['mutation_checks']==20
 assert all(sha(Path(n))==h for n,h in protected.items())
 result=dict(status='PASS',seconds=time.monotonic()-start,python_tests=11,node_tests=5,source_counterexamples=20,commands=rows,gpu_starts=0,default_unchanged=True)
except BaseException:
 result=dict(status='FAILED',seconds=time.monotonic()-start,error=traceback.format_exc(),commands=rows,gpu_starts=0);save(O/'result.json',result);raise
save(O/'result.json',result);print(json.dumps(result))

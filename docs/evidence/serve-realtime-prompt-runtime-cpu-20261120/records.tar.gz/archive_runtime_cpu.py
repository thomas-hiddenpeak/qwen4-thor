from pathlib import Path
import json,hashlib,tarfile,re,os
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'docs/evidence/serve-realtime-prompt-runtime-cpu-20261120'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
p1=read(W/'runtime-plan-01.json');p2=read(W/'runtime-plan-02.json');r1=read(W/'runtime-cpu-01/result.json');r2=read(W/'runtime-cpu-02/result.json');source=read(W/'runtime-cpu-01/source-check.stdout');b1=read(W/'runtime-build-01/result.json');b2=read(W/'runtime-build-02/result.json')
assert r1['status']=='FAIL' and r1['passed']==21 and r2['status']=='PASS' and r2['passed']==1 and source['inventory_current'] and source['mutation_checks']==20
for n in ('runtime-build-01','runtime-build-02'):assert read(W/n/'result.json')['exit_code']==0 and not re.search(r'\bwarning:',(W/n/'build.log').read_text())
test='tests/server_realtime_chat_execution_test.cpp';original=(R/test).read_bytes().replace(b'{\\"version\\":2,\\"fair_queue\\":false,\\"gateway_token\\":\\"',b'{\\"version\\":2,\\"gateway_token\\":\\"',1);assert hashlib.sha256(original).hexdigest()==p1['sources'][test];(W/'runtime-cpu-01/failed-test-source.cpp').write_bytes(original)
files={}
for prefix in ('runtime-cpu-01','runtime-cpu-02','runtime-build-01','runtime-build-02'):
 for p in (W/prefix).iterdir():
  if p.is_file() and p.name not in ('failed-contracts','qualified-contracts'):files[str(p.relative_to(W))]=p
for n in ('runtime-plan-01.json','runtime-plan-02.json','runtime-required-tests.txt','runtime-retry-tests.txt','runtime-detach-01.json','prepare_runtime_cpu.py','archive_runtime_cpu.py'):files[n]=W/n
for f,h in p2['sources'].items():
 assert sha(R/f)==h,f
 if f!=test:assert h==p1['sources'][f]
 files['source/'+f]=R/f
assert not O.exists();O.mkdir();index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};save(O/'index.json',index)
with tarfile.open(O/'records.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'records.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
a=dict(status='PASS_REALTIME_PROMPT_RUNTIME_OWNERSHIP_CPU',tests=22,new_tests=8,test_attempts=23,seconds=r1['seconds']+r2['seconds'],initial_passed=21,retry_passed=1,reused_tests=21,original_failure='Missing mandatory fair_queue in CPU fixture; retained unchanged',production_sources_unchanged_for_retry=True,build_seconds=[b1['seconds'],b2['seconds']],build_warnings=0,source_mutations=20,new_gpu_starts=0,cpu_model_receipts_only=True,runtime_business_accepted=False,default_revision=356,default_unchanged=True,pr=53,pr_draft=True,archive_sha256=sha(O/'records.tar.gz'))
save(O/'acceptance.json',a)
(O/'README.md').write_text('''# Realtime Prompt 运行时所有权 CPU

22项针对性合同通过：首轮21/22，补齐夹具必填`fair_queue`后仅重验
失败的一项并通过。23次用例尝试合计0.016秒，0GPU；首轮原失败、
原测试源码、二次构建和复验记录均保留。生产源码在复验间完全一致。
两次构建151.926/9.059秒零警告，20来源反例通过。

8项新合同覆盖模型输入准备前即取得执行凭据、同请求不能重放、
不同客户/请求或已结算租约不得交接、完整媒体/工具计划保留、主生成
拒绝的已知零新增用量，以及真正缺失用量继续未知。配额模型通过
实际原生租约和嵌套HTTP执行器检查：准备20输入/7输出，主生成30输入/
4输出，共计一次RPM、61TPM、预留归零；缓存和推理细分亦仅累计一次。
CPU模型回调仅是所有权验证，不能代表真实表格摘要或模型质量。

运行时已接原生文件解析、实际表格模型步骤、上下文测量及最终Chat，
沿用同一客户/请求/取消和配额；准备失败、异常、取消及主生成拒绝
仍归集并结算已发生用量。未开始主生成不虚构用量，缺失观察不记零。
实际运行时仍需独立构建和SDK/GPU短验；当前不能宣称Prompt业务已
交付。草稿PR #53、默认rev356保持，Serve master全部任务继续。
''')
intro='[Prompt运行时22项CPU闭合](evidence/serve-realtime-prompt-runtime-cpu-20261120/README.md)：\n8项新合同，首轮21/22、夹具必填字段修正后仅补验1项；原失败\n保留，生产源码未变，23次尝试共0.016秒/0GPU。两次构建零警告、\n20来源反例通过；实际模型准备与主生成共用一次RPM、累计TPM/用量\n交接具备CPU证据。继续必要运行时构建与真实SDK业务；当前无Prompt\n业务资格，草稿PR #53、默认rev356及全部master保持。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Realtime运行时所有权22项CPU闭合\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：实际表格准备与回答必须有单一配额owner和可核对用量；\n把失败隐藏或把CPU回调当模型业务通过均不能完成交付。\n\n下一步：必要构建、真实SDK短验，能力保持与可回退交付，全部master继续。\n'+b)
p=R/'docs/serve-master-goals-v2.json';detach(p);g=read(p);g['realtime_progress']['prompt_runtime_cpu_20261120']=a|dict(evidence='evidence/serve-realtime-prompt-runtime-cpu-20261120/README.md');save(p,g)
p=R/'docs/SERVE_REALTIME_PROMPT_2026-11-20.md';detach(p);s=p.read_text();s=s.replace('当前\n`PlanRealtimeChat` 对非空 `prompt` 返回处理器未接入；既有','初始缺口是\n`PlanRealtimeChat` 对非空 `prompt` 未接处理器；既有',1);s=s.replace('尚未接会话或执行路径，仍按下列总合同继续。','此为注册表阶段结论；后续会话/执行进度见下文，仍按总合同继续。',1);s=s.replace('已具备；实际会话和执行仍待接线。','已具备；该设置阶段未表示实际会话和业务已接通。',1);s=s.replace('## 已核实的依据','运行时所有权另通过[22项CPU](evidence/serve-realtime-prompt-runtime-cpu-20261120/README.md)：\n实际表格模型入口、单次RPM/TPM租约及完整Chat计划已接线，失败用量\n交接和反例通过；原夹具失败保留。继续必要运行时构建与真实SDK业务。\n\n## 已核实的依据',1);p.write_text(s)
p=R/'docs/README.md';detach(p);p.write_text(p.read_text()+'\n- [Realtime Prompt运行时CPU](evidence/serve-realtime-prompt-runtime-cpu-20261120/README.md)：请求、配额、完整计划及失败用量交接；真实业务继续。\n')
b=R/'.q4t-work/serve-file-search-20261112/host/q4t_host_tests';assert sha(b)==r2['binary_sha256'];os.link(b,W/'runtime-cpu-02/qualified-contracts');print(json.dumps(a))

from pathlib import Path
import json,hashlib,re,sys,subprocess
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from tools.serve_audit.check_inventory import current_surface,check
files=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
files=[f for f in files if f.startswith(('include/','src/','tests/'))]
p=R/'tools/serve_audit/inventory.json';v=json.loads(p.read_text());a=current_surface(R);changed={n:h for n,h in a['sources_sha256'].items() if v['sources_sha256'].get(n)!=h};assert set(changed)<=set(files),set(changed)-set(files);v['sources_sha256'].update(changed);assert not check(v,a),check(v,a);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
tests=[]
for f in ('tests/server_realtime_chat_execution_test.cpp','tests/server_client_policy_test.cpp'):
 for name in re.findall(r'Q4T_TEST\(\s*(\w+)\s*\)',(R/f).read_text()):
  if f.endswith('execution_test.cpp') or name.startswith(('model_preparation_','internal_model_wrapper_')):tests.append(name)
assert len(tests)==22 and len(tests)==len(set(tests))
plan=dict(scope='Realtime prepared plan and request invocation ownership, one RPM/TPM lease across file model preparation and primary, actual usage and cancellation/exception accounting. CPU callbacks validate ownership, not model summaries. Actual ChatServer wiring requires separate runtime build and business qualification.',maximum_tests=22,maximum_test_seconds=120,new_gpu_starts=0,tests=tests,sources={f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files},default_revision=356,default_unchanged=True)
p=W/'runtime-plan-01.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2)+'\n');(W/'runtime-required-tests.txt').write_text('\n'.join(tests)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  d=p.read_bytes();m=p.stat().st_mode&0o777;p.unlink();p.write_bytes(d);p.chmod(m)
intro='Realtime输入准备已接运行时：表格内部模型步骤与最终回答共享\n一次请求凭据和RPM/TPM租约，原生媒体/工具计划直接交接，取消、\n异常和主生成准入失败保留并结算实际预处理用量。冻结22项针对性\nCPU/120秒/0GPU及来源检查；尚未构建新运行时或取得Prompt业务\n资格，默认rev356保持。随后必要构建与真实SDK短验，全部master继续。\n\n'
p=R/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=R/'docs/log/2026-11-20.md';detach(p);h,b=p.read_text().split('\n',1);p.write_text(h+'\n\n## Realtime文件模型准备与单次请求配额接线\n\n日期：2026-11-20。\n\n做了什么：'+intro+'为什么：单独展开文件不足以交付；实际模型准备必须服从同一请求、\n客户和配额，不能重放、丢失媒体证明、重复RPM或吞掉失败实际用量。\n\n下一步：针对性CPU与必要运行时构建，完成真实SDK业务及能力保持\n后可回退交付，不把当前代码准备当作验收。\n'+b)
print(json.dumps(dict(tests=len(tests),source_anchors=sorted(changed))))

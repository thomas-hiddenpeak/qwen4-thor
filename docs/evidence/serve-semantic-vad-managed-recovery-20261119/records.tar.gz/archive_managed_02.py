"""Read actual finalized stages; publish nonsecret evidence without audio or reruns."""
from pathlib import Path
import hashlib,json,tarfile,shutil
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
P=W/'managed-publication-02'  # Export unchanged to docs/evidence after STOPPED delivery.
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert not P.exists() and not (W/'publication-composition-02.json').exists()
rows=[];files={};semantic={};total_bytes=0
for name in ('retained-service-02','tls-service-02','version-service-02'):
 d=W/name;plan=read(d/'plan.json');result=read(d/'execution/result.json');decision=read(d/'decision.json');lease=read(d/'lease/exit.json');business=read(d/'execution/media-usage.json')
 assert result['status']=='PASS_BOUNDED_FEATURE_SERVICE' and result['failure'] is None and result['cleanup_failure'] is None
 assert lease['status']=='COMPLETED' and lease['child_returncode']==0 and lease['compute_backend']=='nvml' and lease['lease_inherited_by_child']
 assert all(v is True for v in decision['actual_business']['postflight'].values())
 assert all(sha(Path(row['path']))==row['sha256'] for row in plan['protected'])
 nvml=[json.loads(line) for line in (d/'lease/nvml-queries.jsonl').read_text().splitlines()];assert nvml and all(r['status']=='OK' for r in nvml)
 counts=result['budget']['counts'];assert len(result['models'])==counts['starts']==plan['limits']['starts']
 assert counts['chats']==plan['limits']['chats'] and counts['websocket_sessions']==plan['limits']['websocket_sessions']
 actual={k:v for k,v in business['results'].items() if k.endswith('-semantic')}
 assert len(actual)==(1 if name.startswith('retained') else 2)
 assert all(v['actual_classifier'] and v['actual_tokens']>0 and v['resources_released'] and not v['automatic_replay'] for v in actual.values())
 semantic[name]=actual
 size=sum(p.stat().st_size for p in d.rglob('*') if p.is_file());total_bytes+=size
 rows.append(dict(name=name,counts=counts,actual_model_execs=len(result['models']),seconds=result['seconds'],strict_lease_seconds=decision['actual_business']['strict_lease_seconds'],nvml_queries=len(nvml),business=business,postflight=decision['actual_business']['postflight'],artifact_bytes=size))
 for relative in ('plan.json','decision.json','service-release.json','execution/result.json','execution/media-usage.json','execution/business-final.json','execution/core-continuity.json','execution/counts.json','execution/stop.json','lease/exit.json'):
  files[name+'/'+relative]=d/relative
 # Raw voice and processed PCM stay private; retain their exact witness hashes.
 witnesses={str(p.relative_to(d)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in (d/'execution').glob('*semantic*') if p.is_file()}
 save(d/'semantic-witness-index.json',witnesses);files[name+'/semantic-witness-index.json']=d/'semantic-witness-index.json'
profile=read(W/'profiles-02/acceptance.json');assert profile['status']=='ACCEPT_PRIMARY_LIGHT_QUALIFICATION'
roots={n:{k:read(W/path/'receipt.json')[k] for k in ('package','manifest_sha256')} for n,path in [('candidate','service-package-02'),('retained','retained-01'),('tls','tls-package-01')]}
starts=sum(r['counts']['starts'] for r in rows);work=sum(r['counts']['chats'] for r in rows);sessions=sum(r['counts']['websocket_sessions'] for r in rows)
assert starts==4 and work==73 and sessions==10 and sum(r['seconds'] for r in rows)<=1500
old=read(W/'retained-service-01/execution/result.json');assert old['budget']['counts']['starts']==old['budget']['counts']['chats']==0
composition=dict(status='ACCEPT_NATIVE_SEMANTIC_VAD_SERVICE_COMPOSITION',binary_sha256=read(W/'service-package-02/receipt.json')['engine_binary_sha256'],candidate=roots['candidate'],automatic_fallback=roots['retained'],modern_retained_root=roots['retained'],tls_package=roots['tls'],stages=rows,semantic_turns=semantic,actual_model_starts=starts,service_requests=work-sessions,realtime_tasks=sessions,semantic_tasks=5,service_work_items=work,service_probes=sum(r['counts']['probes'] for r in rows),service_seconds=sum(r['seconds'] for r in rows),nvml_queries=sum(r['nvml_queries'] for r in rows),nvml_all_ok=True,cleanup_complete=True,strict_finalizers_all_passed=True,strict_runtime_environment_checks_passed=True,original_version_driver_passed=True,tls_composition=read(W/'tls-service-02/decision.json'),candidate_service_acceptance=read(W/'version-service-02/decision.json'),modern_service_acceptance=read(W/'retained-service-02/decision.json'),candidate_whole_package_gpu_run=True,default_unchanged=True,publication_pending=True,older_engine_fallback=False,full_model_quality=False,performance_claim=False,all_master_tasks_complete=False,original_failed_stage=dict(directory=str(W/'retained-service-01'),starts=0,http_requests=0,seconds=old['seconds'],nvml_ok=4,evidence='docs/evidence/serve-semantic-vad-managed-import-20261119/README.md'),original_failure_relabelled=False,cumulative_model_starts=starts,cumulative_http_requests=work-sessions,cumulative_work_items=work,listening='PENDING_BY_OWNER',primary_light_evidence='docs/evidence/serve-semantic-vad-primary-light-20261119/README.md',normal_speed_voice_similarity_accepted=False,strict_fp_boundary_accepted=True,artifact_bytes=total_bytes)
prior=read(W/'publication-composition.json');old_version=next(r for r in prior['stages'] if r['name']=='version-service-01')
composition.update(original_candidate_version=old_version,cumulative_model_starts=starts+old_version['counts']['starts'],cumulative_http_requests=work-sessions+old_version['counts']['chats']-old_version['counts']['websocket_sessions'],cumulative_websocket_sessions=sessions+old_version['counts']['websocket_sessions'],cumulative_service_seconds=sum(r['seconds'] for r in rows)+old_version['seconds'],publication_migration_failure_preserved=True,original_candidate_version_passed=True,changed_candidate_sources=['source/tools/serve_recovery/profile_migration.py'])
for relative in ('plan.json','decision.json','service-release.json','execution/result.json','lease/exit.json'):
 files['original-version-service-01/'+relative]=W/'version-service-01'/relative
for name in ('managed-supplement-freeze-01.json','delivery-prepare-failure-01.json'):
 files[name]=W/name
save(W/'publication-composition-02.json',composition)
for name in ('publication-composition-02.json','managed-freeze-01.json','managed-freeze-02.json','version-plan-binding-01.json','archive_managed_02.py'):
 files[name]=W/name
for name in ('plan.json','result.json','restore.py'):
 files['cpu-binary-archive-21/'+name]=R/'.q4t-work/serve-realtime-20261119/cpu-binary-archive-21'/name
for directory in ('link-cache-cleanup-01','old-link-cache-cleanup-01'):
 for name in ('plan.json','result.json'):files[directory+'/'+name]=W/directory/name
for name in ('cleanup_link_caches.py','cleanup_old_link_caches.py'):files[name]=W/name
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(x,str) and len(x)>=24:secrets.append(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
for root in roots.values():
 for name in ('gateway-policy.json','engine/client-policy.json'):collect(read(Path(root['package'])/name))
for name,p in files.items():
 raw=p.read_bytes();assert not any(s in raw for s in secrets),name;assert b'-----BEGIN '+b'PRIVATE KEY-----' not in raw,name
P.mkdir();save(P/'index.json',{n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()})
with tarfile.open(P/'records.tar.gz','w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
summary={k:v for k,v in composition.items() if k not in ('stages','tls_composition','candidate_service_acceptance','modern_service_acceptance')}
summary.update(archive_sha256=sha(P/'records.tar.gz'),archive_files=len(files),secret_scan_matches=0)
save(P/'acceptance.json',summary)
(P/'README.md').write_text(f'''# 语义 VAD 实际 Guardian 恢复验收（2026-11-19）

三组全程严格租约与独立 finalize 均通过：4 次模型启动、63 条 HTTP
（含 4 自检）+10 个 Realtime 会话、1 次设备探测，{composition['service_seconds']:.3f} 秒；
{composition['nvml_queries']} 次 NVML 全部正常。进程、端口、锁与默认身份后查通过。

其中 5 个真实语义回合分别覆盖保留控制器、TLS 恢复前后、整包回退前后；
实际 ASR 与主模型评分、完整转录、私有评分用量结算和资源释放同时通过。
TLS 使用官方 OpenAIRealtimeWS 7.47.0，明文回环使用固定 ws 客户端，身份
分别记录。TLS 故障保持模型/控制器 PID，入口换代；整包恢复换控制器、
模型与入口。同一参考音色、持久历史及配额保持，客户端显式新连接继续，
不自动重放音频或业务。未完成手动转录另行覆盖中断取消结算。

引擎 945775bb 和 v16 主轻资格保持。两控制包共享同一已验语义引擎，
不宣称旧引擎回退。原命名空间导入失败（0 模型/0 业务）保持原 FAIL，
原0模型导入失败未消耗模型预算；随后发布预检发现待办元数据迁移遗漏，
只修正候选控制包并补此版本组，保留/TLS及主轻复用。原候选版本组仍为PASS，
全部累计6模型/87HTTP+14Realtime；原exact-code、声纹失败与用户延期听感保持。

非秘密身份、结果与实际运维投影归档；原始录音、完整 PCM 和秘密配置
仅保留本机，公开其 SHA 见证。两个已被后续交付替代的独立历史备份
无损压缩归档并逐字节验证，恢复器保留；默认、在用与恢复程序不变。
默认 rev336 仍 STOPPED；继续可回退发行、主线合入及全部 Serve 任务。
本阶段没有完整性能、全模型质量或长稳通过声明。
''')
print(json.dumps({k:composition[k] for k in ('status','actual_model_starts','service_requests','realtime_tasks','semantic_tasks','service_seconds','nvml_queries')}))

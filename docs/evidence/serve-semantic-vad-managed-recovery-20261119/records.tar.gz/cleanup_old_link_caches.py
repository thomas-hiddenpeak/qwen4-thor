"""Bounded cleanup of 21 rebuilt static-library caches from completed Serve stages."""
from pathlib import Path
import hashlib,json,re,os,shutil
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=W/'old-link-cache-cleanup-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
names={'serve-device-memory-20261103','serve-admission-20261103','serve-media-failure-20261103','serve-observability-20261103','serve-backend-cleanup-20261103','serve-media-integration-20261103','serve-stage-a-20261102'}
assert not O.exists();O.mkdir(mode=0o700);rows=[];protected={}
for name in (W/'build-cache-paths.txt').read_text().splitlines():
 p=R/name
 if p.relative_to(R).parts[1] not in names or p.name!='libxgrammar.a':continue
 s=p.lstat();assert p.is_file() and not p.is_symlink() and s.st_nlink==1
 build=p.parent.parent.parent;cache=build/'CMakeCache.txt'
 src=Path(re.search(r'^xgrammar_SOURCE_DIR:STATIC=(.+)$',cache.read_text(),re.M)[1])
 assert (src/'CMakeLists.txt').is_file() and (src/'cpp/compiled_grammar.cc').is_file()
 rows.append(dict(path=str(p),bytes=s.st_size,sha256=sha(p),inode=s.st_ino,source=str(src),cmake_cache_sha256=sha(cache)))
 for q in [build/'q4t',build/'q4t_host_tests',cache,src/'CMakeLists.txt',src/'cpp/compiled_grammar.cc']:
  if q.is_file():protected[str(q)]=sha(q)
assert len(rows)==21 and sum(r['bytes'] for r in rows)==546849412
paths={r['path'] for r in rows}
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:argv=(d/'cmdline').read_bytes().split(b'\0');name=Path(os.fsdecode(argv[0])).name;exe=(d/'exe').resolve()
 except (OSError,IndexError):continue
 assert name not in ('cmake','ninja','make','gmake','nvcc','g++-14','cc1plus','ld','cicc')
 assert not any(exe.is_relative_to(R/'.q4t-work'/n) for n in names)
for stage in ('retained-service-02','tls-service-02','version-service-01'):
 plan=json.loads((W/stage/'plan.json').read_bytes())
 assert not paths.intersection(str((R/p).resolve()) for p in plan['sources'])
 for row in plan['protected']:protected[row['path']]=row['sha256']
assert all(sha(Path(p))==h for p,h in protected.items())
save(O/'plan.json',dict(files=rows,protected=protected,free_before=shutil.disk_usage(R).free,scope='21 inactive build-produced libxgrammar.a caches only; source/config, all binaries, snapshots, evidence, production and recovery packs retained.'))
for row in rows:
 p=Path(row['path']);s=p.stat();assert s.st_ino==row['inode'] and s.st_nlink==1 and sha(p)==row['sha256'];p.unlink()
assert all(sha(Path(p))==h for p,h in protected.items())
save(O/'result.json',dict(status='REBUILDABLE_OLD_LINK_CACHES_REMOVED',files=len(rows),bytes=sum(r['bytes'] for r in rows),protected_unchanged=True,gpu_actions=0,free_after=shutil.disk_usage(R).free))
print((O/'result.json').read_text())

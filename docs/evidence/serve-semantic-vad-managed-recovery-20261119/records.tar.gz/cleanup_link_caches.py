"""Remove only reproducible inactive compiler/linker caches, retain every executable."""
from pathlib import Path
import hashlib,json,os,shutil
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
O=W/'link-cache-cleanup-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
roots=[R/'.q4t-work/serve-custom-tools-20261108/engine-build',R/'.q4t-work/serve-file-search-20261112/host']
assert not O.exists();O.mkdir(mode=0o700)
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:cmd=(d/'cmdline').read_bytes().split(b'\0');name=Path(os.fsdecode(cmd[0])).name
 except (OSError,IndexError):continue
 assert name not in ('cmake','ninja','make','gmake','nvcc','g++-14','cc1plus','ld','cicc'),'active compiler/linker'
files=[p for root in roots for p in root.rglob('*.o')]
files += [roots[0]/'q4t-regex/libq4t_regex.a', roots[0]/'_deps/q4t_xgrammar-build/libxgrammar.a']
files=sorted(set(files));rows=[]
for p in files:
 s=p.lstat();assert not p.is_symlink() and p.is_file() and s.st_nlink==1 and any(p.resolve().is_relative_to(root.resolve()) for root in roots)
 rows.append(dict(path=str(p),bytes=s.st_size,sha256=sha(p),inode=s.st_ino))
protected={str(p):sha(p) for p in [R/'build/q4t',R/'build/q4t.release.json',R/'build/service/manifest.json',R/'build/service.release.json',R/'build/service-native-state/ledger.json',roots[0]/'q4t',roots[1]/'q4t_host_tests']}
for n in ('service-package-01','retained-01','tls-package-01'):
 for p in [W/n/'bundle/manifest.json',W/n/'bundle/engine/q4t']:protected[str(p)]=sha(p)
save(O/'plan.json',dict(files=rows,protected=protected,free_before=shutil.disk_usage(R).free,scope='Only source-rebuildable object and static-link caches. No executable, model, source, evidence, package, default or state removed.'))
for row in rows:
 p=Path(row['path']);s=p.stat();assert s.st_ino==row['inode'] and s.st_nlink==1 and sha(p)==row['sha256'];p.unlink()
assert all(sha(Path(p))==h for p,h in protected.items())
save(O/'result.json',dict(status='REBUILDABLE_LINK_CACHES_REMOVED',files=len(rows),bytes=sum(r['bytes'] for r in rows),protected_unchanged=True,gpu_actions=0,free_after=shutil.disk_usage(R).free))
print((O/'result.json').read_text())

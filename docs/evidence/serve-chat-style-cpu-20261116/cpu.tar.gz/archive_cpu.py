import hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,j:p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
for name in ['host-build-01','host-build-02','engine-build-01','probe-build-01','host-test-02','schema-client-01','python-client-01','js-client-01','driver-cpu-01','source-audit-01','generated-check-01','contract-test-01']:
 j=json.loads((W/(name+'.json')).read_text());assert j['exit_code']==0 and j['default_unchanged'],name
 if 'build' in name:
  assert not re.search(r'(^|\s)warning:',(W/(name+'.stdout')).read_text()+(W/(name+'.stderr')).read_text()),name
passed={}
for name in ['host-test-01','host-test-02']:
 for status,test in re.findall(r'\[(PASS|FAIL)\] (\w+)',(W/(name+'.stdout')).read_text()):passed[test]=dict(status=status,run=name)
assert len(passed)==15 and all(v['status']=='PASS' for v in passed.values())
b=ROOT/'.q4t-work/serve-custom-tools-20261108/engine-build';c=W/'candidate-01';c.mkdir()
for src,dst in [(b/'q4t',c/'q4t'),(b/'generated/q4t/server/chat_protocol_sources.json',c/'chat_protocol_sources.json')]:shutil.copy2(src,dst)
manifest=json.loads((c/'chat_protocol_sources.json').read_text())
assert all(sha(ROOT/n)==h for n,h in manifest.items())
protocol=re.search(r'kProtocol\[\] = "([0-9a-f]+)"',(b/'generated/q4t/server/chat_protocol_identity.h').read_text())[1]
identity=dict(binary=str(c/'q4t'),binary_sha256=sha(c/'q4t'),compiled_sources_sha256=sha(c/'chat_protocol_sources.json'),protocol_sha256=protocol,compiled_sources=manifest)
save(W/'identity.json',identity)
e=ROOT/'docs/evidence/serve-chat-style-cpu-20261116';e.mkdir()
files=[p for p in W.iterdir() if p.is_file() and p.name!='openai-chat-create.md']
with tarfile.open(e/'cpu.tar.gz','w:gz') as tar:
 for p in sorted(files):
  assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n',p.read_bytes())
  tar.add(p,arcname=p.name)
 tar.add(W/'contract-01',arcname='contract-01')
 tar.add(c/'chat_protocol_sources.json',arcname='candidate/chat_protocol_sources.json')
receipt=dict(status='ACCEPT_CHAT_STYLE_TARGETED_CPU',cpp_distinct=15,cpp_executions=16,cpp_final=passed,schema_and_client_driver_tests=6,differential_contracts=32,source_anchors=715,source_negative_checks=7,build_warnings=0,first_failure='Fixture included message framing in expected content; verify source_size bytes and exact message terminator separately. No runtime fix.',binary_sha256=identity['binary_sha256'],protocol_sha256=protocol,default_revision=150,default_unchanged=True,gpu_starts=0,business_pending=True,master_active=True,archive_sha256=sha(e/'cpu.tar.gz'))
save(e/'acceptance.json',receipt)
(e/'README.md').write_text('''# Chat 样式与流式合同针对性 CPU 通过

15项不同C++最终通过，含首轮失败共16次执行；6项schema、Python/JS
客户端及驱动检查，32项公开schema/生产原生解析对照、715来源锚点/
7项负控通过。主机、引擎和原生probe构建零警告。真实SDK类型、随机
padding对工具/概率/Unicode/终态的保留、null/缺省和原生提示均覆盖。

首轮一项夹具错误把prompt_end视为正文末端；现有合同包含消息终止符，
修正为按source_size核对原内容，再独立核对终止符。仅该项复验，14项
成功直接复用，原失败保留；运行时代码未因此改变。

候选身份、编译来源、原始记录及冻结清单在acceptance.json/cpu.tar.gz。
默认rev150未改，0GPU；接下来最多1启动/6Chat/900秒实际业务。没有
完整质量/性能声明，其他标准字段及全部33项master继续。公开归档不
包含抓取的完整官方页面；其引用URL/私有哈希保留。
''')
p=ROOT/'docs/STATUS.md';s=p.read_text();h='## 最近完成的实现和验证\n\n'
s=s.replace(h,h+'''[Chat 样式/流式针对性CPU通过](evidence/serve-chat-style-cpu-20261116/README.md)：
15项不同C++、6项schema/客户端/驱动、32项公开/原生解析对照通过；
715来源/7负控及生成物一致性通过，主机/引擎/probe零警告。首轮夹具
误读prompt_end，按既有合同修正后单项复验，14项成功复用。候选
`'''+identity['binary_sha256'][:8]+'''`待最多1启动/6Chat/900秒业务，rev150未改；全部master继续。

''',1);p.write_text(s)
p=ROOT/'docs/log/2026-11-16.md';s=p.read_text();h='# 开发日志（2026-11-16）\n\n';p.write_text(h+'''## Chat 样式 CPU 与直接解析对照通过

- 日期：2026-11-16。15项不同C++、6项schema/客户端/驱动、32项公开
  schema对生产原生解析、715来源/7负控及生成物一致性通过；零警告。
- 首轮1项夹具误读prompt_end为内容结束；既有合同含消息终止符，
  按source_size核对正文并独立核对终止符后单项通过，14项成功复用。
  原失败保留，未因夹具问题修改运行时。
- 为什么：实际输入/模板/输出/客户端一致才是兼容，不以字段出现
  代替执行；公共fixture的旧effort-null/stream-only预期同步。
- 下一步：最多1启动/6Chat/900秒实际JSON/SSE及文档工具闭环，当前
  rev150未改，0GPU；全部master继续。
- 证据：[CPU记录](../evidence/serve-chat-style-cpu-20261116/README.md)。

'''+s[len(h):])
p=ROOT/'docs/serve-master-goals-v2.json';j=json.loads(p.read_text())
for t in j['tasks']:
 if 'chat_style_parity_20261116' in t:
  t['chat_style_parity_20261116'].update(state='targeted_cpu_accepted_business_pending',evidence='evidence/serve-chat-style-cpu-20261116/README.md',binary_sha256=identity['binary_sha256'])
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=ROOT/'docs/SERVE_CHAT_CONTRACT_PARITY_2026-11-16.md';p.write_text(p.read_text()+'''
## 当前结果

[针对性CPU证据](evidence/serve-chat-style-cpu-20261116/README.md)通过；
15项不同C++，6项schema/客户端/驱动，32项输入对照。首轮夹具失败和
定点修正保留；业务与发行仍待完成。其他未改行为不重复全矩阵。
''')
print(json.dumps(dict(candidate=identity['binary_sha256'],status=receipt['status'],files=len(files))))

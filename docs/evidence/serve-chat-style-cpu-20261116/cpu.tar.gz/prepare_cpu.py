import copy,hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(ROOT))
from tools.serve_audit.check_inventory import current_surface
from tools.serve_protocol import build_contract
save=lambda p,j:p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=ROOT/'tools/serve_audit/inventory.json';j=json.loads(P.read_text());before=copy.deepcopy(j)
actual=current_surface(ROOT)
assert set(actual['fields'])-set(j['fields'])=={'verbosity'}
assert set(j['fields'])-set(actual['fields'])==set()
for group in ['routes','native_routes','completion_fields']:
 assert set(j[group])==set(actual[group])
report='docs/SERVE_CHAT_CONTRACT_PARITY_2026-11-16.md'
rows={
 'reasoning_effort':('none/minimal/low/medium/high/xhigh/max/null；缺省或null为medium；嵌套存在优先，包括null。','none选择原生关闭thinking前缀；其他级别为实际模型提示适配，不承诺数值计算预算。候选实现，业务/发行待验。'),
 'stream_options':('object/null；对象要求stream=true；include_usage bool默认false，include_obfuscation bool默认true。','Chat角色、正文、推理、工具和choice结束delta带随机padding；usage-only/DONE/错误/心跳保持，false关闭。候选待CPU和业务验收。'),
 'verbosity':('low/medium/high/null；缺省/null为medium；需要messages。','low/high加入真实模型指令；不插入来源消息、不承诺固定答案长度。候选尚未发行，其他标准字段仍须实现。')}
for k,(semantics,boundary) in rows.items():
 row=j['fields'].setdefault(k,dict(evidence=[]));row.update(semantics=semantics,boundary=boundary)
 for p in [report,'tests/server_chat_contract_test.cpp','tests/server_chat_message_profile_test.cpp','tests/server_http_response_test.cpp']:
  if p not in row['evidence']:row['evidence'].append(p)
diff={p:dict(before=before['sources_sha256'].get(p),after=h) for p,h in actual['sources_sha256'].items() if before['sources_sha256'].get(p)!=h}
expected={'cmake/ChatProtocolIdentity.cmake','include/q4t/server/generation_style.h','include/q4t/server/http_response.h','src/server/chat_capabilities.cpp','src/server/chat_contract.cpp','src/server/chat_generation.cpp','src/server/chat_template.cpp','src/server/completion_response.cpp','src/server/http_response.cpp','src/server/responses_plan.cpp'}
assert set(diff)==expected,(set(diff)-expected,expected-set(diff))
assert not set(before['sources_sha256'])-set(actual['sources_sha256'])
j['sources_sha256']=actual['sources_sha256'];j['whitelists']=actual['whitelists']
j['chat_style_development_20261116']=dict(report=report,status='implemented_targeted_validation_pending',actual_default_revision=150,master_active=True)
save(W/'reviewed-source-diff.json',dict(sources=diff,whitelists_before=before['whitelists'],whitelists_after=actual['whitelists']))
save(P,j)
subprocess.run([sys.executable,'tools/serve_protocol/build_contract.py'],cwd=ROOT,check=True)
required=['chat_contract_standard_style_and_stream_options','chat_style_default_null_and_explicit_effort_rendering','chat_style_none_and_nested_precedence_use_native_prefix','chat_verbosity_preserves_original_message_source_coordinates','chat_stream_padding_preserves_delta_probability_and_finish','chat_contract_error_param_is_explicit','chat_contract_greedy_neutral_options','chat_contract_template_options_are_explicit','chat_contract_nullable_defaults_are_field_specific','responses_plan_reasoning_effort_and_verbosity_model_adaptation','responses_plan_defaults_keep_real_storage_requirement','completion_sse_shape_usage_and_optional_padding','chat_capabilities_option_contract','chat_plan_native_template_and_constraint_adapter','chat_preflight_envelope_and_opt_in_preview']
(W/'required-01.txt').write_text('\n'.join(required)+'\n')
save(W/'freeze-cpu-01.json',dict(cpp=required,python=['tools.serve_protocol.test_chat_style.ChatStyleContracts','test_chat_client.ClientContracts.test_stream_obfuscation_preserves_tools_usage_and_request_options'],js=['Chat stream obfuscation preserves SDK deltas and explicit request options'],source_check=['tools/serve_audit/check_inventory.py --self-check','tools/serve_protocol/build_contract.py --check'],gpu_starts=0,full_suite=False,source_sha256={p:sha(ROOT/p) for p in subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines() if (ROOT/p).is_file()}))
shutil.copy2(ROOT/'.q4t-work/serve-video-geometry-20261116/run.py',W/'run.py')
print(json.dumps(dict(changed_sources=len(diff),anchors=len(actual['sources_sha256']),cpp=len(required))))

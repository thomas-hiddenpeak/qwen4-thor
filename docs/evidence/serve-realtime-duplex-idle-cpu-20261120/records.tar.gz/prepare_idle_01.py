from pathlib import Path
import re,json,subprocess,hashlib
W=Path(__file__).parent
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=[]
for n in files:
 if not n.startswith('tests/') or not n.endswith('.cpp'):continue
 prior=set(re.findall(r'Q4T_TEST\(\s*(\w+)',subprocess.check_output(['git','show','HEAD:'+n],text=True)))
 new += [x for x in re.findall(r'Q4T_TEST\(\s*(\w+)',Path(n).read_text()) if x not in prior]
assert len(new)==10,new
affected=['realtime_queue_resume_requires_ack_and_preserves_clock_sequence','realtime_queue_cancellation_keeps_worker_storage_until_ack','realtime_audio_reservation_hidden_until_owned_commit','realtime_composed_input_private_transcript_still_drives_context','realtime_composed_input_recovery_preserves_audio_context_and_clock','realtime_composed_input_recovery_is_two_attempts_per_minute','realtime_composed_input_fatal_processor_does_not_poison_text','realtime_session_native_vad_controls_do_not_invent_response','realtime_session_native_vad_interrupt_preserves_out_of_band','realtime_session_native_input_wait_uses_original_deadline','realtime_session_recovers_new_audio_after_borrowed_fault_without_replay','realtime_session_native_input_delete_retains_worker_borrow','realtime_chat_capabilities_bind_real_storage_and_pending_processors','realtime_session_audio_events_retrieve_delete_and_text_followup','realtime_session_g711_retrieves_actual_bytes_and_playback_clock','realtime_duplex_idle_timeout_is_server_vad_only_and_bounded']
p=W/'idle-plan-01.json';plan=json.loads(p.read_text());plan.update(new_tests=new,affected_tests=affected,tests=new+affected);p.write_text(json.dumps(plan,indent=2)+'\n')
p=Path('tools/release/required_host_tests.txt');s=p.read_text();p.write_text(s+''.join(n+'\n' for n in new if n not in s))
p=Path('tools/serve_audit/inventory.json');v=json.loads(p.read_text())
v['duplex_idle_timeout_20261120']=dict(state='development_targeted_cpu_pending',scope=plan['scope'],tests=new,limits=plan['limits'],default_revision=376)
v['duplex_local_input_recovery_20261120']['state']='targeted_cpu_accepted_actual_business_pending'
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
def refresh(x):
 if isinstance(x,dict):
  for k,z in list(x.items()):
   if k in changed and isinstance(z,str) and len(z)==64 and Path(k).is_file():x[k]=hashlib.sha256(Path(k).read_bytes()).hexdigest()
   else:refresh(z)
 elif isinstance(x,list):
  for z in x:refresh(z)
refresh(v);p.write_text(json.dumps(v,indent=2)+'\n')
p=W/'build_idle_01.py';s=(W/'build_recovery_01.py').read_text().replace('recovery-build-01','idle-build-01').replace('1c0f42e5bde7c95c60687fd820cf81458a2cdbbb134efa4992e0ddc7f9090e2c','eaab2e88bf334640fcc4540d5a67a23e46d830ce86cf3ce48ad6b46f7cc41942').replace('Necessary incremental host build for actual conversation input owner, deferred responses and native scheduling; no test execution/GPU action','Necessary incremental host build for native idle timeout, actual audio retention and local input recovery; no test execution/GPU action');p.write_text(s)
p=Path('docs/STATUS.md');s=p.read_text();at=s.index('\n## 当前实际默认');s=s[:at]+'''
空闲触发已成组开发：回答终态加实际播放时长后计时，同一ring有界
保留接收音频，静音/漏检音频仍经ASR；零样本只记录原生空输入，
不伪造ASR执行/转写。清除/语音开始/故障/断连解除计时，旁路不重置。
冻结10新+16相关CPU及20来源反例/120秒，尚待构建/验证；0GPU。
''' +s[at:];p.write_text(s)
p=Path('docs/log/2026-11-20.md');s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''
## server VAD空闲计时与真实输入保留开发

日期：2026-11-20。

做了什么：完成回答终态加实际输出样本播放时长的空闲计时，同一ring
保留最多30秒/单项上限内的真实静音；等待VAD分析积压后才触发，漏检
音频经ASR。零样本不调用ASR、不伪造转写事件，原生空输入使用私有
执行提示让模型继续对话，提示不写入公开transcript；客户端不能伪造
该来源。关闭自动回答、清除、语音、故障和断连均有独立处理，旁路/
失败回答不重置默认计时。冻结10新+16相关CPU/20来源反例/120秒待验。

为什么：已解析的idle_timeout_ms必须有实际执行，且不能用合成静音、
旧输入重放或空转写成功掩盖ASR失败。0GPU，默认rev376保持。

下一步：构建与针对CPU，继续直接混合输入和WSS/ASR/TTS统一业务短验、
恢复交付与全部master。
''' +s[i:])

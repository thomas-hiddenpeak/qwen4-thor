"""Archive the exact native auxiliary delivery and its interrupted maintenance."""
import hashlib,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
D=W/'delivery-01';O=R/'docs/evidence/serve-speaker-delivery-20261118'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(D/'result.json');composition=read(W/'publication-composition.json')
assert v['status']=='PASS_NATIVE_SPEAKER_DELIVERED' and v['publication']['revision']==296
assert len(v['commands'])==19 and all(x['returncode']==0 for x in v['commands'])
assert v['state']=='STOPPED' and v['new_gpu_starts']==0 and v['outer']['charged_total']==0
c=v['publication']['current'];assert c['manifest_sha256']==composition['candidate']['manifest_sha256']
assert sha(R/'build/q4t')==c['engine_binary_sha256'] and sha(R/'build/service.release.json')==c['service_release_sha256']
release=read((R/'build/service.release.json').resolve());capacity=read(W/'capacity-02/result.json')
assert capacity['status']=='PASS_DELIVERY_CAPACITY_RESERVED' and read(W/'capacity-01/result.json')['status']=='FAILED'
assert not capacity['deleted_files'] and capacity['default_unchanged'] and capacity['recovery_budget_unchanged']
files={}
for d in [D,W/'capacity-01',W/'capacity-02']:
 for p in d.iterdir():
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(W))]=p
for pattern in ['delivery-prepare-*.*','delivery-run-*.*']:
 for p in W.glob(pattern):
  if p.is_file():files[p.name]=p
for name in ['archive_delivery.py','deliver.py','reserve_delivery_capacity.py','reserve_delivery_capacity-02.py','maintenance-before.json','publication-composition.json','service-package-01/prepare-review.json']:
 files[name]=W/name
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,item in v.items():
   if k in ('api_key','gateway_token','shared_secret','private_key','token') and isinstance(item,str) and len(item)>=24:secrets.append(item.encode())
   else:collect(item)
 elif isinstance(v,list):
  for item in v:collect(item)
for p in [R/'build/service/gateway-policy.json',R/'build/service/engine/client-policy.json']:collect(read(p))
for name,p in files.items():
 raw=p.read_bytes();assert not any(secret in raw for secret in secrets),name
 assert b'-----BEGIN '+b'PRIVATE KEY-----\n' not in raw,name
assert not O.exists();O.mkdir()
with tarfile.open(O/'records.tar.gz','w:gz') as archive:
 for name,p in sorted(files.items()):archive.add(p,arcname=name,recursive=False)
a=dict(status='ACCEPT_NATIVE_SPEAKER_DELIVERY',revision=296,current=c,
 commands=len(v['commands']),seconds=v['seconds'],state='STOPPED',new_gpu_starts=0,
 manual_root=composition['modern_retained_root']['manifest_sha256'],automatic_payload=composition['automatic_fallback']['manifest_sha256'],
 candidate_whole_package_gpu_run=True,older_engine_fallback=False,previous_rev286_preserved=True,
 retired_intents_archived=4,retired_generations_archived=4,retired_versions_archived=3,
 maintenance_original_rejected_plan_preserved=True,maintenance_cumulative_seconds=capacity['seconds']+read(W/'capacity-01/result.json')['seconds'],deleted_files=0,
 files=len(files),secret_scan_matches=0,archive_sha256=sha(O/'records.tar.gz'),main_integration_pending=True,
 full_model_quality=False,performance_claim=False,long_stability_run=False,full_openai_compatibility=False,all_master_tasks_active=True)
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'README.md').write_text(f'''# 原生说话人可回退交付 rev296

默认服务包`{c['manifest_sha256']}`，引擎`{c['engine_binary_sha256']}`。
19项STOPPED检查/发布、实际整根回退与再前进全部完成，{v['seconds']:.3f}秒，
0新增GPU；outer启用且累计启动0，服务保持STOPPED。

同人、换人回访、已知参考、JSON/SSE、双SDK、原生TLS、主轻及
整包回退后的实际A/B/A已验，原ASR/对齐/VAD与核心业务保护保持。
参见[直接HTTP](../serve-speaker-http-20261118/README.md)、
[主轻](../serve-speaker-profiles-20261118/README.md)和
[原生服务/恢复](../serve-speaker-service-20261118/README.md)。

核心/client/outer预算字节保持，profile仅显式增加已验speaker身份
及预算；原history/pending/selected/deadline保持，实际整根回退恢复
各根原版本周期。人工根`{a['manual_root']}`、自动payload
`{a['automatic_payload']}`均使用当前引擎与保留控制；未宣称独立
旧引擎具备新增能力。前驱rev286及原day入口保留。

4 intent/4 generation/3 version可恢复归档，0删除；原5项plan
被现有4项保护拒绝的失败保留，修正私有脚本后完成。资产/辅助
故障只降级对应能力，真正设备故障保护保留。已验托管配置使用
8个声音窗口，CLI默认256；预算均显式绑定，不将容量拒绝算成功。

下一步完成主线检查和合入；重叠语音实际检测分离、Chat音频/
合成/Realtime和其余全部master继续。没有宣称完整OpenAI兼容、
全模型质量、性能或长稳通过，总目标仍active。
''')
p=R/'docs/STATUS.md';s=p.read_text()
rows={'发布':'rev296；服务包 `'+c['manifest_sha256']+'`','Generation':'`'+c['generation_sha256']+'`','引擎':'`'+c['engine_binary_sha256']+'`','引擎发布记录':'`'+c['engine_release_sha256']+'`','Guardian':'`'+release['guardian_sha256']+'`','原生入口':'`'+release['ingress_sha256']+'`','人工整包回退':'现代保留根 `'+a['manual_root']+'`；实际speaker/原周期/原生入口已验，前驱rev286另保留','自动payload回退':'已验旧控制/当前引擎包 `'+a['automatic_payload']+'`；不是独立旧引擎回退','外部依赖':'原生入口/自监护不要求nginx/systemd；ASR/对齐/VAD/speaker资产按部署显式启用，codec按请求隔离，辅助失能不拖停健康Chat'}
for name,value in rows.items():
 s,n=re.subn(r'^\| '+re.escape(name)+r' \| .* \|$',lambda _:f'| {name} | {value} |',s,count=1,flags=re.M);assert n==1
intro=f'''[rev296说话人可回退交付](evidence/serve-speaker-delivery-20261118/README.md)
完成，19项STOPPED命令/{v['seconds']:.3f}秒，0新增GPU。实际整根回退
再前进通过，原预算/历史保持；前驱rev286和day保留。接着主线
检查合入、真实重叠检测分离与全部master，不在本阶段结束总目标。

'''
s=s.replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1);p.write_text(s)
p=R/'docs/log/2026-11-18.md';h,b=p.read_text().split('\n',1);p.write_text(h+f'''\n\n## rev296说话人可回退交付（2026-11-18）

19项STOPPED命令/{v['seconds']:.3f}秒，0新增GPU；实际整根回退及
再前进完成，原历史/预算保持，speaker实际资格进入默认。
可恢复归档0删除，原维护plan选择上限失败保留。原因：已验功能
须进入可用发行并验证回退。前驱rev286/day保留；下一步主线
检查合入、重叠真实路径和全部master继续。
[证据](../evidence/serve-speaker-delivery-20261118/README.md)。\n'''+b)
p=R/'docs/serve-master-goals-v2.json';j=read(p)
for t in j['tasks']:
 if t['id'] in ['A10','A12','Q01','Q02']:t['speaker_delivery_20261118']=a|dict(evidence='evidence/serve-speaker-delivery-20261118/README.md')
 if t['id']=='Q02':
  t['latest_release']=t['speaker_delivery_20261118'];t['remaining_required']=['Speaker PR final-head checks and actual main merge','Delivery of every remaining implementation']
 if t['id']=='R07':t['current_execution_prerequisite']='Refresh exact cold qualification against rev296 or then-current default; pending host/camera maintenance handoff remains required.'
j['next_task']='Speaker main integration and A10 overlap separation plus all remaining master tasks';j['next']='Complete speaker main integration, actual overlap detection/separation, Chat audio/synthesis/Realtime and every remaining A/N/R/Q task.';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'docs/README.md';p.write_text(p.read_text()+'\n- [rev296说话人交付](evidence/serve-speaker-delivery-20261118/README.md)：真实分人/参考/JSON/SSE与可回退原生服务。\n')
print(json.dumps({k:a[k] for k in ['status','revision','commands','seconds']}))

"""Only missing consumers, with all failures retained; never writes qualification.

Primary's already completed three Chat and two Realtime turns are not repeated.
Two starts, at most29 external requests, seven WSS, five entries,900 seconds.
"""
import copy,hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from tools.serve_recovery import profile_refusal_targeted as audited
from tools.serve_recovery import profile_prompt,profile_semantic,profile_realtime
from tools.serve_realtime import conversation_managed,conversation_observation
from tools.serve_realtime.ingress_fixture import NativeIngress
from tools.serve_responses import prompt_acceptance as legacy
from tools.serve_service.package import read,require,save,sha
full=audited.full;encrypted=audited.encrypted;evidence=audited.profile_evidence
W=Path(__file__).resolve().parent;OUT=W/'consumers-01';OLD=W/'profiles-02'
LIMITS=dict(starts=2,chats=29,controls=2000,seconds=900,websocket_sessions=7,ingress_starts=5,prompt_registry_requests=10)

def check(plan):
 require(plan['observation_only'] is True and plan['limits']==LIMITS and plan['qualification']==False and plan['automatic_retries'] is False,'fixed missing-work envelope')
 original=read(OLD/'result.json');require(original['status']=='FAILED' and original['counts']['starts']==1 and original['counts']['chats']==5,'original failure missing')
 require(sha(OLD/'completed-output-review.json')==plan['original_review_sha256'],'original output review changed')
 probe=copy.deepcopy(plan);probe['limits']=audited.LIMITS;probe['planned']={k:v for k,v in audited.LIMITS.items() if k not in ('controls','seconds')}
 audited.check_plan(probe)

class Stage(audited.Stage):
 limits=LIMITS
 success_status='OBSERVATIONS_COMPLETE_NOT_QUALIFICATION'
 def __init__(self,plan):
  check(plan);encrypted.Stage.__init__(self,plan)
  self.counts.update(websocket_sessions=0,ingress_starts=0,prompt_registry_requests=0)
  self.observations=[]
 def observe(self,label,action):
  before=copy.deepcopy(self.counts);begin=time.monotonic()
  try:
   result=action();entry=dict(profile=self.profile_name,label=label,status='PASS',result=result)
  except (ValueError,RuntimeError) as error:
   entry=dict(profile=self.profile_name,label=label,status='FAIL',error=str(error),traceback=traceback.format_exc())
  entry.update(seconds=time.monotonic()-begin,budget_before=before,budget_after=copy.deepcopy(self.counts))
  receipt=self.out/(self.profile_name+'-'+label+'-observation.json')
  profile_semantic.save_receipt(receipt,entry)
  self.observations.append(dict(profile=self.profile_name,label=label,status=entry['status'],seconds=entry['seconds'],path=str(receipt),sha256=sha(receipt)))
  save(self.out/'observations.json',self.observations)
  self.same_model();self.drained(self.profile_name+'-'+label+'-observation-drain')
  status,_=self.http('/readyz');require(status==200,'core unhealthy after consumer; stop rather than recover/replay')
 def text_only(self):
  rows=self.plan['requests'];schema=self.request('schema',rows['schema'])
  require(json.loads(evidence.message(schema,'stop')['content'])==dict(answer=42),'schema answer differs')
  call=self.request('tool',rows['tool']);message=evidence.message(call,'tool_calls');calls=message.get('tool_calls',[])
  require(len(calls)==1 and calls[0]['function']['name']=='project_document' and json.loads(calls[0]['function']['arguments'])==dict(path=full.DOCUMENT),'tool call differs')
  digest=sha(ROOT/full.DOCUMENT);require(digest==self.plan['sources'][full.DOCUMENT],'document drift')
  reply=dict(role='tool',tool_call_id=calls[0]['id'],content=json.dumps(dict(path=full.DOCUMENT,sha256=digest,answer=digest[:12])))
  follow=copy.deepcopy(rows['tool']);follow['tool_choice']='none';follow['messages'] += [message,reply]
  final=self.request('tool-result',follow);msg=evidence.message(final,'stop')
  require(digest[:12] in msg.get('content','') and not msg.get('tool_calls'),'tool result differs')
  return dict(schema=schema,tool_call=call,tool_result=final,tool_reply=reply,tool_source=dict(path=full.DOCUMENT,content=(ROOT/full.DOCUMENT).read_text()))
 def conversation(self):
  fixed=self.plan['conversation'];label=self.profile_name+'-conversation-observation';client=encrypted.CLIENT
  policy=read(self.out/'client-policy.json');key=hashlib.sha256(os.urandom(32)).hexdigest()
  def state(suffix):
   status,raw=self.http('/metrics',label=label+'-'+suffix);require(status==200,'metrics absent')
   return profile_realtime.state(encrypted.foreground.base.lifecycle.parse_metrics(raw),client)
  before=state('before');self.budget('ingress_starts')
  edge=NativeIngress(self.out/label,fixed['ingress'],fixed['public_port'],self.plan['port'],self.plan['operations_port'],policy['gateway_token'],{client:key},fixed['tls'],lambda:self.model.poll() is None)
  self.history[edge.process.pid]=encrypted.foreground.base.lifecycle.guard.processes()[edge.process.pid]
  try:
   self.budget('websocket_sessions');self.budget('chats');self.budget('chats')
   args=dict(base_url=f"https://127.0.0.1:{fixed['public_port']}/v1",api_key=key,ca_file=fixed['tls']['certificate'],mode='complete',quality_policy=conversation_managed.QUALITY_POLICY,record_file=str(ROOT/fixed['source']['path']),record_sha256=fixed['source']['sha256'],expected_version=fixed['source']['version'])
   env={k:v for k,v in os.environ.items() if k not in ('NODE_OPTIONS','NODE_PATH','LD_PRELOAD')};env['Q4T_NODE_SDK_DIR']=self.plan['sdk']['sdk_directory']
   process=subprocess.run([self.plan['sdk']['node']['path'],str(ROOT/'tools/serve_realtime/conversation_recovery_sdk.mjs')],input=json.dumps(args),text=True,capture_output=True,env=env,timeout=210)
   (self.out/(label+'.sdk.json')).write_text(process.stdout);(self.out/(label+'.stderr')).write_text(process.stderr)
   require(process.returncode==0 and len(process.stdout.encode())<=4<<20,'actual observed conversation failed')
   raw=json.loads(process.stdout);total=conversation_managed.check_session(raw,'complete','official-openai-wss',fixed['source'],conversation_managed.QUALITY_POLICY)
   self.same_model();self.drained(label+'-drain');end=time.monotonic()+5;after=state('after-0');i=0
   while (after['sessions'] or after['host_bytes']) and time.monotonic()<end:
    time.sleep(.02);i+=1;after=state('after-'+str(i))
   require(all(after[k]==0 for k in ('reserved','active','sessions','host_bytes')) and after['free_slots']==1 and after['admitted']-before['admitted']==2 and after['settled']-before['settled']==total,'observed conversation settlement differs')
   return dict(source=fixed['source'],before=before,after=after,session=raw,quality=raw['model_quality'],strict_profile_qualified=False)
  finally:
   edge.close();save(self.out/(label+'-entry-cleanup.json'),dict(exit_code=edge.process.returncode,pid=edge.process.pid,port_released=True))
 def media(self):
  body=self.plan['requests']['media'];v=dict(request=body,response=self.request('media',body,'/v1/responses'));evidence.media_business(v);return v
 def audio(self,old):
  source=old['business']['asr']['source_base64'];response=self.request('chat-audio',evidence.chat_audio_request(source));status,raw=self.http('/v1/config',label=self.profile_name+'-chat-audio-config');require(status==200,'audio config missing')
  value=evidence.chat_audio_witness(source,response,json.loads(raw));evidence.chat_audio_business(value,self.plan['identity'],source);return value
 def tts(self,old):
  value=copy.deepcopy(old['business']['tts']);value['chat_response']=self.request('chat-output',evidence.tts_requests()['chat']);status,raw=self.http('/v1/config',label=self.profile_name+'-tts-config');require(status==200,'tts config missing');value['health']=json.loads(raw)['native_tts_health'];evidence.tts_business(value,self.plan['identity']);return value
 def legacy(self):
  self.budget('prompt_registry_requests');definition=audited.targeted.reuse.legacy_definition();registered=legacy.Stage.admin(self,self.profile_name+'-legacy-register','POST','/v1/prompts',dict(definition=definition));request=audited.targeted.reuse.legacy_request(registered['id']);response=self.request('legacy-responses',request,'/v1/responses');value=dict(definition=definition,registered=registered,request=request,response=response);audited.targeted.reuse.legacy_business(value);return value
 def profile_business(self):
  _,old=audited.original(self.plan,self.profile_name)
  if self.profile_name=='light':
   self.observe('text',self.text_only);self.observe('conversation',self.conversation)
  self.observe('prompt',lambda:profile_prompt.run(self))
  self.observe('media',self.media)
  self.observe('chat-audio',lambda:self.audio(old))
  self.observe('voice-chat',lambda:self.voice_chat(old['business']['voice']))
  self.observe('tts-chat',lambda:self.tts(old))
  self.observe('semantic-vad',lambda:profile_semantic.run(self))
  self.observe('legacy-responses',self.legacy)


def prepare():
 OUT.mkdir(mode=0o700);plan=copy.deepcopy(read(OLD/'plan.json'))
 plan.update(output=str(OUT),limits=LIMITS,planned={k:v for k,v in LIMITS.items() if k not in ('controls','seconds')},scope=__doc__,observation_only=True,qualification=False,automatic_retries=False,original_review_sha256=sha(OLD/'completed-output-review.json'),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
 record=ROOT/'docs/STATUS.md';plan['conversation']['source']['sha256']=sha(record);plan['conversation']['files'][str(record)]=sha(record)
 plan['sources']={n:sha(ROOT/n) for n in plan['sources']}
 for f in [Path(__file__),OLD/'plan.json',OLD/'result.json',OLD/'completed-output-review.json',OLD/'primary-conversation.sdk.json']:
  plan['sources'][str(f)]=sha(f)
 check(plan);save(OUT/'plan.json',plan);print(json.dumps(dict(status='PREPARED_OBSERVATIONS_ONLY',limits=LIMITS,original_quality_failure_preserved=True)))

if __name__=='__main__':
 if sys.argv[1:]==['prepare']:prepare()
 else:
  require(sys.argv[1:]==['run'],'explicit frozen mode required')
  def stopped(_s,_f):raise TimeoutError('missing consumers deadline/interruption')
  signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGALRM,stopped);signal.alarm(900)
  try:
   with encrypted.foreground.base.lifecycle.child_subreaper():Stage(read(OUT/'plan.json')).run()
  finally:signal.alarm(0)

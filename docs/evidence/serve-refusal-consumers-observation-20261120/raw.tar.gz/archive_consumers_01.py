from pathlib import Path
import hashlib,json,tarfile
ROOT=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent
B=W/'consumers-01'; O=ROOT/'docs/evidence/serve-refusal-consumers-observation-20261120'; O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def detach(p):
 if p.stat().st_nlink>1:
  raw=p.read_bytes();mode=p.stat().st_mode&0o777;p.unlink();p.write_bytes(raw);p.chmod(mode)
result=json.loads((B/'result.json').read_text()); guard=json.loads((B/'lease/exit.json').read_text())
assert result['status']=='OBSERVATIONS_COMPLETE_NOT_QUALIFICATION' and guard['status']=='COMPLETED'
rows=json.loads((B/'observations.json').read_text()); assert len(rows)==16 and sum(v['status']=='PASS' for v in rows)==15
for row in rows: assert sha(Path(row['path']))==row['sha256']
for n in ['cleanup.json','primary-cleanup.json']:
 c=json.loads((B/n).read_text());assert c['remaining']==[] and c['ports_released'] and c['lease_continuously_held'] and c['model_exit']==0
queries=[json.loads(s) for s in (B/'lease/nvml-queries.jsonl').read_text().splitlines()];assert len(queries)==208 and all(x['status']=='OK' for x in queries)
plan=json.loads((B/'plan.json').read_text())
for n,h in plan['protected'].items():assert sha(Path(n))==h
for n,h in plan['sources'].items():assert sha(ROOT/n)==h
semantic=json.loads((B/'primary-semantic-complete.sdk.json').read_text())
terminal=[e for e in semantic['events'] if e['type']=='conversation.item.input_audio_transcription.completed'][0]
review=dict(status='MISSING_CONSUMERS_OBSERVED_NOT_QUALIFIED',counts=result['counts'],seconds=result['seconds'],passed_groups=15,failed_groups=1,nvml_ok=208,default_unchanged=True,strict_profile_status='FAIL',observations=rows,semantic_failure=dict(sdk_error=semantic['error'],terminal=terminal,diagnosis='Cold ASR load 3627.018 ms; classifier cancelled at absolute silence deadline, stale=1; complete actual ASR and accounted score. No normal-close or retained-audio receipt because strict SDK stopped. Warm light both turns scored successfully.'),next=dict(scope='Separate bounded cold fallback and warm actual classification; finish missing main conversation lifecycle with quality separately retained',starts=1,external_requests=4,websocket_sessions=3,seconds=600,automatic_retries=False),cleanup='owned processes, ports and cooperative GPU lease released')
save(B/'review.json',review)
files={'observe_remaining_01.py':W/'observe_remaining_01.py','archive_consumers_01.py':Path(__file__)}; omitted={}; secrets=[]
def scan(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k in ('api_key','gateway_token','bearer_token') and isinstance(x,str):secrets.append(x)
   else:scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
for p in B.rglob('*.json'):
 if p.stat().st_size<65536:
  try:scan(json.loads(p.read_text()))
  except ValueError:pass
for p in [*B.iterdir(),*(B/'lease').iterdir()]:
 if not p.is_file() or p.suffix not in ('.json','.jsonl','.wire','.log','.stderr','.py'):continue
 name=str(p.relative_to(W))
 if p.name=='client-policy.json' or any(s.encode() in p.read_bytes() for s in secrets if s):omitted[name]=dict(sha256=sha(p),reason='private test authentication; original retained');continue
 files[name]=p
index={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()};save(O/'index.json',dict(files=index,omitted=omitted))
with tarfile.open(O/'raw.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(O/'raw.tar.gz','r:gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
save(O/'review.json',dict(review,archive_sha256=sha(O/'raw.tar.gz')))
(O/'README.md').write_text('''# 缺项消费者观察与冷态语义降级

候选648d6d68保持；2模型/28实际外部请求/6WSS/5入口/223.416秒。
208次NVML观察正常，自有进程/端口/锁清理完成，默认rev356不变。
16组中15组通过；这组从未写主轻资格，原严格格式FAIL不变。

主/轻Prompt、媒体、音频问答、注册声线Chat/独立ASR、内置Chat语音和
旧Responses模板通过；轻配置新增文本及完整Realtime工具/关闭/结算也通过。
主配置已完成的文本工具问题没有重放。

主配置语义停顿发生冷ASR装载约3.627秒，评分开始后约0.822秒被绝对
停顿期限取消；stale=1、maximum_wait=true、没有采信过期概率。
实际转写完整，评分287输入/4输出计入总用量。原严格SDK因accepted=0
中断，缺少正常关闭/重取观察，不能据此伪造主配置分类已通过。
轻配置完整/续说两轮均实际分类成功。

接着固定1模型/4外部请求/3WSS/600秒：分别检查冷态有界降级和热态
实际分类，补主配置Realtime工具正常关闭及结算；原错误答案独立保留。
不重跑已通过消费者，不调整模型/API默认值，不把监控退出0等同资格。
原始SDK/日志/指标/清理见归档；认证原件只列摘要，保留私有路径。
''')
intro='[缺项消费者观察已完成](evidence/serve-refusal-consumers-observation-20261120/README.md)：\n2模型/28外部请求/223.416秒，208次NVML正常并完成清理；16组15通过。\n主配置冷ASR使语义评分触及绝对停顿期限，转写/计费完整但未采信概率；\n轻配置两轮实际分类通过。原格式FAIL与本组语义FAIL不改写，默认rev356保持。\n固定1模型/4请求/3WSS/600秒补冷态降级、热态分类和主配置正常关闭结算；\n先做对应观察器CPU，全部master继续。\n\n'
p=ROOT/'docs/STATUS.md';detach(p);p.write_text(p.read_text().replace('## 正在推进\n\n','## 正在推进\n\n'+intro,1))
p=ROOT/'docs/log/2026-11-20.md';detach(p);h,t=p.read_text().split('\n',1);p.write_text(h+'\n\n## 缺项消费者观察与冷态评分取消定位\n\n日期：2026-11-20。\n\n做了什么：'+intro.replace('(evidence/','(../evidence/')+'为什么：实际冷启动降级和成功分类是不同合同，不能抹去失败或仅因最后转写正确宣布分类通过。\n\n下一步：保留严格资格失败，验证降级与热态分类的完整生命周期，再推进恢复和交付及总计划。\n'+t)
print(json.dumps(dict(files=len(files),omitted=len(omitted),archive_bytes=(O/'raw.tar.gz').stat().st_size)))

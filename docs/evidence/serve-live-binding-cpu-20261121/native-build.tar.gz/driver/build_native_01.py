import gzip,hashlib,importlib.util,json,os,re,signal,subprocess,time
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=W/'native-build-01';O.mkdir(mode=0o700);(O/'tmp').mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('audit',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
H=R/'.q4t-work/serve-file-search-20261112/host';B=R/'.q4t-work/serve-custom-tools-20261108/engine-build'
protected={n:sha(R/n) for n in ['build/q4t','build/q4t.release.json','build/service/manifest.json','build/service-native-state/ledger.json']}
sources=m.current_surface(R)['sources_sha256']
assert json.loads((W/'binding-cpu-01/result.json').read_text())['status']=='PASS'
previous={}
for label,p in [('engine',B/'q4t'),('ingress',H/'q4t-ingress')]:
 raw=p.read_bytes();archive=O/('previous-'+label+'.gz');archive.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(archive.read_bytes())==raw
 previous[label]=dict(path=str(p),sha256=sha(p),archive=str(archive),archive_sha256=sha(archive),mode=p.stat().st_mode&0o777,bytes=len(raw))
commands=[['cmake','--build',str(H),'--target','q4t_ingress','--parallel','2'],['cmake','--build',str(B),'--target','q4t','--parallel','2']]
save(O/'plan.json',dict(scope='Native Live client WSS binding, actual tokenizer/ASR/LLM/TTS; necessary build, no GPU',sources=sources,protected=protected,previous=previous,commands=commands,build_limit_seconds=600))
rows=[];start=time.monotonic()
for i,c in enumerate(commands):
 with (O/(str(i)+'.stdout')).open('w') as out,(O/(str(i)+'.stderr')).open('w') as err:
  p=subprocess.Popen(c,cwd=R,stdout=out,stderr=err,env=dict(os.environ,TMPDIR=str(O/'tmp')),start_new_session=True)
  try:code=p.wait(timeout=max(1,600-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124
 raw=(O/(str(i)+'.stdout')).read_text()+(O/(str(i)+'.stderr')).read_text();warnings=len(re.findall(r'warning:|CMake Warning',raw))
 rows.append(dict(index=i,returncode=code,warnings=warnings))
 if code or warnings:break
unchanged=all(sha(R/n)==h for n,h in protected.items());same=all(sha(R/n)==h for n,h in sources.items())
r=dict(status='BUILD_PASS' if len(rows)==2 and all(not x['returncode'] and not x['warnings'] for x in rows) and unchanged and same else 'BUILD_FAIL',commands=rows,seconds=time.monotonic()-start,default_unchanged=unchanged,sources_unchanged=same,new_gpu_starts=0,binary_sha256=sha(B/'q4t'),ingress_sha256=sha(H/'q4t-ingress'))
save(O/'result.json',r);print(json.dumps(r),flush=True);assert r['status']=='BUILD_PASS'

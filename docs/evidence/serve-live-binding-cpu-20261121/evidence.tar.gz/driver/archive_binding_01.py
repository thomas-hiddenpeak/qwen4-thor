import hashlib,importlib.util,io,json,subprocess,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[1];O=R/'docs/evidence/serve-live-binding-cpu-20261121'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
result=read(W/'binding-cpu-01/result.json');plan=read(W/'binding-cpu-01/plan.json')
assert result['status']=='PASS' and result['sources_unchanged'] and result['protected_unchanged']
spec=importlib.util.spec_from_file_location('inventory',R/'tools/serve_audit/check_inventory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=R/'tools/serve_audit/inventory.json';inventory=read(p);actual=m.current_surface(R)
expected={'CMakeLists.txt','cmake/ChatProtocolIdentity.cmake','include/q4t/server/chat_server.h','include/q4t/server/live_native_backend.h','src/server/chat_live.cpp','src/server/chat_realtime.cpp','src/server/live_configuration.cpp','src/server/live_native_backend.cpp'}
diff={n for n,h in actual['sources_sha256'].items() if inventory['sources_sha256'].get(n)!=h}
save(W/'binding-inventory-before.json',dict(changed_sources=sorted(diff),errors=m.check(inventory,actual)));assert diff==expected,(diff,expected)
assert set(actual['routes'])-inventory['routes'].keys()=={'GET /v1/live/sessions'}
assert inventory['routes'].keys()-set(actual['routes'])==set()
# Exact primary route + optional startup types; current identity and retained
# policy snapshot; actual bounded tokenizer counts; existing ASR/model execution
# owns admission/quota; no synthetic session completion before real drain/Join.
# Other delegation/media processors remain implementation tasks, not certified.
for n in sorted(expected):inventory['sources_sha256'][n]=actual['sources_sha256'][n]
row=dict(semantics='原生Live主WebSocket，SDK合同、启动配置与客户端上下文，复用实际tokenizer及原生ASR/LLM/TTS执行入口。',boundary='开发中：客户端委派及主连接组合已有针对性CPU；真实SDK/WSS业务尚待验。录制、Responses/Decisions、fixture、旁路与媒体继续实现，未发行；不宣称完整Live兼容。',evidence=['src/server/chat_live.cpp','src/server/live_native_backend.cpp','tests/server_live_frontend_test.cpp','docs/evidence/serve-live-binding-cpu-20261121/README.md'])
inventory['routes']['GET /v1/live/sessions']=row
inventory['native_routes']['GET /v1/live/sessions']['boundary']=row['boundary']
inventory['native_routes']['GET /v1/live/sessions']['evidence'].append(row['evidence'][-1])
inventory['live_binding_review_20261121']=dict(sources=sorted(expected),evidence=row['evidence'][-1],status='Concrete native binding CPU preparation, actual model HTTP pending; default unchanged',real_business_accepted=False)
save(p,inventory)
r=subprocess.run(['python3','tools/serve_audit/check_inventory.py','--self-check'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(W/'binding-inventory-reviewed.json').write_text(r.stdout);assert r.returncode==0,r.stdout
files={}
for folder in ('binding-plan-01','binding-cpu-01'):
 for p in sorted((W/folder).iterdir()):assert p.is_file();files[folder+'/'+p.name]=p.read_bytes()
for name in ('binding_cpu_01.py','archive_binding_01.py','binding-inventory-before.json','binding-inventory-reviewed.json'):files['driver/'+name]=(W/name).read_bytes()
for n,h in plan['sources'].items():
 raw=(R/n).read_bytes();assert sha(raw)==h,n;files['accepted/'+n]=raw
assert not (O/'evidence.tar.gz').exists();index={}
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n,raw in sorted(files.items()):
  index[n]=dict(sha256=sha(raw),bytes=len(raw));info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(raw),0o600,0;t.addfile(info,io.BytesIO(raw))
save(O/'index.json',index)
result.update(status='PASS_NATIVE_LIVE_PRIMARY_BINDING_CPU_PREPARATION',distinct_tests=12,new_tests=9,direct_existing_tests=3,inventory_reviewed_sources=8,inventory_mutation_checks=28,real_model_business_accepted=False,new_gpu_starts=0,default_revision=426,default_changed=False,master_active=True,archive_sha256=sha((O/'evidence.tar.gz').read_bytes()))
save(O/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('commands','command')}))
